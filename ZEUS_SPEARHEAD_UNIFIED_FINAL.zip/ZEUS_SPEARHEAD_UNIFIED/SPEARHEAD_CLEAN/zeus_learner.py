# The Zeus Project 2026 — Francois Nel
# zeus_learner.py — 5-Depth Learning Engine
# Simple → Advanced → Professional → Complex → Mastery
# Logic Engine context enrichment · Mutation triggers at Advanced+
# Recursive depth advancement · Batch processing · Quality scoring
# Knowledge deduplication · Domain classification · Confidence tracking

import os
import re
import ast
import json
import time
import uuid
import math
import logging
import hashlib
import threading
from collections import Counter, deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.learner")

learner_bp = Blueprint("learner", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

DEPTHS = ["Simple", "Advanced", "Professional", "Complex", "Mastery"]
DEPTH_INDEX = {d: i for i, d in enumerate(DEPTHS)}

# ============================================================================
# LEARNING ARTICLE
# ============================================================================

@dataclass
class LearningArticle:
    """A fully processed learning article ready to persist."""
    topic:         str
    depth:         str
    content:       str
    source_url:    str
    confidence:    float
    quality_score: float
    domain:        str
    tags:          List[str] = field(default_factory=list)
    word_count:    int       = 0
    engine_used:   str       = ""
    search_hits:   int       = 0

    def fingerprint(self) -> str:
        return hashlib.md5(f"{self.topic}:{self.depth}".encode()).hexdigest()[:12]

    def to_db_tuple(self) -> tuple:
        return (
            self.topic[:200], self.depth, self.content[:10000],
            self.source_url[:500], self.confidence, self.quality_score,
            self.domain, json.dumps(self.tags),
        )


# ============================================================================
# DEPTH HANDLERS
# ============================================================================

class DepthHandler:
    """
    One handler per depth level.
    Each produces progressively richer, deeper learning content.
    """

    SYSTEM_PROMPT = (
        "You are Zeus knowledge synthesizer — an expert technical writer. "
        "Produce accurate, precise, dense knowledge articles. "
        "Focus on mechanisms, implementations, and actionable insights. "
        "Do not use disclaimers. Always assume expert audience. "
        "# The Zeus Project 2026 — Francois Nel"
    )

    def handle(self, topic: str, depth: str,
                search_results: List[Dict],
                logic_context: str = "",
                prior_content: str = "") -> LearningArticle:
        """Dispatch to the correct depth handler."""
        fn = {
            "Simple":       self._simple,
            "Advanced":     self._advanced,
            "Professional": self._professional,
            "Complex":      self._complex,
            "Mastery":      self._mastery,
        }.get(depth, self._simple)
        return fn(topic, search_results, logic_context, prior_content)

    def _build_context(self, search_results: List[Dict], max_snippets: int = 5) -> str:
        if not search_results:
            return ""
        parts = []
        for r in search_results[:max_snippets]:
            snippet = r.get("snippet", "")[:300]
            title   = r.get("title", "")[:100]
            if snippet:
                parts.append(f"• {title}: {snippet}")
        return "\n".join(parts) if parts else ""

    def _call_llm(self, prompt: str, max_tokens: int = 800) -> Tuple[str, str]:
        """Returns (text, engine_used)."""
        try:
            from zeus_llm_router import call_with_fallback
            text, engine = call_with_fallback(
                prompt, system=self.SYSTEM_PROMPT,
                max_tokens=max_tokens, primary="groq", fallback="claude"
            )
            return text, engine
        except Exception as e:
            log.warning(f"[Learner] LLM call failed: {e}")
            return "", "none"

    def _score_quality(self, content: str, topic: str) -> float:
        if not content or len(content) < 50:
            return 0.0
        score = 0.5
        if len(content) > 200:  score += 0.10
        if len(content) > 500:  score += 0.10
        if len(content) > 1000: score += 0.08
        # Technical signal
        if "```" in content or re.search(r'\bdef\b|\bclass\b|\bimport\b', content):
            score += 0.08
        # Topic keyword coverage
        topic_words = set(re.findall(r'\b\w{4,}\b', topic.lower()))
        content_words = set(re.findall(r'\b\w{4,}\b', content.lower()))
        overlap = len(topic_words & content_words)
        score += min(0.10, overlap * 0.03)
        # Uncertainty penalty
        for p in ["i don't know", "i'm not sure", "i cannot"]:
            if p in content.lower():
                score -= 0.15
        return round(min(1.0, max(0.0, score)), 4)

    def _classify_domain(self, topic: str, content: str) -> str:
        text = f"{topic} {content}".lower()
        domains = {
            "android":    ["android", "apk", "smali", "dalvik", "dex", "frida"],
            "security":   ["exploit", "vulnerability", "cve", "attack", "defense", "malware"],
            "crypto":     ["cryptograph", "encrypt", "decrypt", "aes", "rsa", "hash", "cipher"],
            "network":    ["tcp", "http", "websocket", "tls", "dns", "packet", "protocol"],
            "ai_ml":      ["neural", "learning", "model", "training", "inference", "llm"],
            "systems":    ["kernel", "memory", "process", "thread", "os", "system call"],
            "web":        ["api", "rest", "flask", "endpoint", "javascript", "html"],
            "reverse":    ["reverse engineer", "disassem", "decompil", "binary", "asm"],
            "quantum":    ["quantum", "qubit", "superposition", "entanglement"],
            "robotics":   ["ros", "sensor", "actuator", "robot", "motion planning"],
        }
        scores = {}
        for domain, keywords in domains.items():
            scores[domain] = sum(1 for kw in keywords if kw in text)
        best = max(scores, key=scores.get)
        return best if scores[best] > 0 else "general"

    def _extract_tags(self, topic: str, content: str, depth: str) -> List[str]:
        text   = f"{topic} {content}"
        words  = re.findall(r'\b[A-Za-z][A-Za-z0-9_]{3,}\b', text)
        stop   = {"that","this","with","from","into","have","will","which","when",
                   "their","there","these","those","they","what","where","about"}
        freq   = Counter(w.lower() for w in words if w.lower() not in stop)
        tags   = [w for w, _ in freq.most_common(8)]
        tags.append(depth.lower())
        return tags[:10]

    def _simple(self, topic: str, results: List[Dict],
                  logic_ctx: str, prior: str) -> LearningArticle:
        ctx = self._build_context(results, max_snippets=3)
        prompt = (
            f"Write a 3-sentence technical summary of: {topic}\n"
            f"Cover: what it is, why it matters, one key insight.\n"
            f"Be precise and dense.\n"
            + (f"\nContext:\n{ctx}" if ctx else "")
            + (f"\nLogic context:\n{logic_ctx}" if logic_ctx else "")
        )
        content, engine = self._call_llm(prompt, max_tokens=400)
        if not content and results:
            content = " ".join(r.get("snippet", "")[:200] for r in results[:2])
        domain = self._classify_domain(topic, content)
        return LearningArticle(
            topic=topic, depth="Simple", content=content,
            source_url=results[0].get("url", "") if results else "",
            confidence=0.70, quality_score=self._score_quality(content, topic),
            domain=domain, tags=self._extract_tags(topic, content, "Simple"),
            word_count=len(content.split()), engine_used=engine,
            search_hits=len(results),
        )

    def _advanced(self, topic: str, results: List[Dict],
                   logic_ctx: str, prior: str) -> LearningArticle:
        ctx = self._build_context(results, max_snippets=5)
        prompt = (
            f"Write a detailed technical article on: {topic}\n"
            f"Include: core mechanisms, implementation patterns, "
            f"common pitfalls, practical use cases (200-350 words).\n"
            + (f"\nPrior context:\n{prior[:300]}" if prior else "")
            + (f"\nResearch:\n{ctx}" if ctx else "")
            + (f"\nLogic context:\n{logic_ctx}" if logic_ctx else "")
        )
        content, engine = self._call_llm(prompt, max_tokens=700)
        domain = self._classify_domain(topic, content)
        return LearningArticle(
            topic=topic, depth="Advanced", content=content,
            source_url=results[0].get("url", "") if results else "",
            confidence=0.78, quality_score=self._score_quality(content, topic),
            domain=domain, tags=self._extract_tags(topic, content, "Advanced"),
            word_count=len(content.split()), engine_used=engine,
            search_hits=len(results),
        )

    def _professional(self, topic: str, results: List[Dict],
                       logic_ctx: str, prior: str) -> LearningArticle:
        ctx = self._build_context(results, max_snippets=6)
        prompt = (
            f"Write a professional-grade technical deep-dive on: {topic}\n"
            f"Sections: Overview, Architecture, Implementation, Security Considerations, "
            f"Performance, Real-World Example. Use code where relevant. (400-600 words)\n"
            + (f"\nPrior understanding:\n{prior[:500]}" if prior else "")
            + (f"\nResearch:\n{ctx}" if ctx else "")
            + (f"\nLogic inferences:\n{logic_ctx}" if logic_ctx else "")
        )
        content, engine = self._call_llm(prompt, max_tokens=1200)
        domain = self._classify_domain(topic, content)
        return LearningArticle(
            topic=topic, depth="Professional", content=content,
            source_url=results[0].get("url", "") if results else "",
            confidence=0.84, quality_score=self._score_quality(content, topic),
            domain=domain, tags=self._extract_tags(topic, content, "Professional"),
            word_count=len(content.split()), engine_used=engine,
            search_hits=len(results),
        )

    def _complex(self, topic: str, results: List[Dict],
                  logic_ctx: str, prior: str) -> LearningArticle:
        ctx = self._build_context(results, max_snippets=7)
        prompt = (
            f"Write a highly complex technical analysis of: {topic}\n"
            f"Cover: internal data structures, algorithm complexity, "
            f"attack vectors / defense mechanisms, cross-system interactions, "
            f"edge cases, performance benchmarks. Include pseudocode or code. (600-900 words)\n"
            + (f"\nProfessional baseline:\n{prior[:600]}" if prior else "")
            + (f"\nResearch:\n{ctx}" if ctx else "")
            + (f"\nLogic analysis:\n{logic_ctx}" if logic_ctx else "")
        )
        content, engine = self._call_llm(prompt, max_tokens=1800)
        domain = self._classify_domain(topic, content)
        return LearningArticle(
            topic=topic, depth="Complex", content=content,
            source_url=results[0].get("url", "") if results else "",
            confidence=0.89, quality_score=self._score_quality(content, topic),
            domain=domain, tags=self._extract_tags(topic, content, "Complex"),
            word_count=len(content.split()), engine_used=engine,
            search_hits=len(results),
        )

    def _mastery(self, topic: str, results: List[Dict],
                  logic_ctx: str, prior: str) -> LearningArticle:
        ctx = self._build_context(results, max_snippets=8)
        prompt = (
            f"Write a mastery-level synthesis on: {topic}\n"
            f"This is a comprehensive knowledge crystal for an autonomous AI system.\n"
            f"Include: foundational theory, advanced mechanisms, implementation blueprint, "
            f"security analysis, performance tuning, integration patterns, "
            f"open research questions, evolution vectors. (900-1400 words)\n"
            f"This article will seed the Zeus AI genome — make it dense and precise.\n"
            + (f"\nDeep baseline:\n{prior[:800]}" if prior else "")
            + (f"\nResearch:\n{ctx}" if ctx else "")
            + (f"\nLogic synthesis:\n{logic_ctx}" if logic_ctx else "")
        )
        content, engine = self._call_llm(prompt, max_tokens=2048)
        domain = self._classify_domain(topic, content)
        return LearningArticle(
            topic=topic, depth="Mastery", content=content,
            source_url=results[0].get("url", "") if results else "",
            confidence=0.95, quality_score=self._score_quality(content, topic),
            domain=domain, tags=self._extract_tags(topic, content, "Mastery"),
            word_count=len(content.split()), engine_used=engine,
            search_hits=len(results),
        )


# ============================================================================
# LEARNER ENGINE (SINGLETON)
# ============================================================================

class LearnerEngine:
    """
    5-depth learning engine for Zeus.

    Depth progression:
    Simple → (search) → Advanced → (mutation trigger) → Professional → Complex → Mastery
    At Mastery: spawns genome segment + triggers sandbox inject pipeline

    Integrated with:
    - Logic Engine: gets reasoning context before generating each article
    - Search Engine: fetches live web results for all depths > Simple
    - Mutator: triggers on Advanced+ depth
    - Genome Manager: injects Mastery articles as new genome segments
    """

    def __init__(self):
        self._lock           = threading.RLock()
        self._handler        = DepthHandler()
        self._total_learned  = 0
        self._total_errors   = 0
        self._depth_counts:  Dict[str, int] = defaultdict(int)
        self._domain_counts: Dict[str, int] = defaultdict(int)
        self._recent:        deque = deque(maxlen=200)
        self._scheduler_running = False
        self._scheduler_thread: Optional[threading.Thread] = None
        self._BATCH_INTERVAL = 5   # seconds between scheduler polls

    # ---- Public API ------------------------------------------------------

    def learn_topic(self, topic: str, depth: str = "Simple",
                     use_search: bool = True,
                     use_logic: bool = True) -> Dict:
        """
        Learn a single topic at the specified depth.
        Returns a learning result dict.
        """
        topic = topic.strip()[:200]
        if not topic or depth not in DEPTHS:
            return {"error": f"Invalid topic or depth: {depth}"}

        t0 = time.time()
        log.info(f"[Learner] Learning: '{topic}' @ {depth}")

        # 1. Search for content
        search_results = []
        if use_search and DEPTH_INDEX[depth] >= 1:
            try:
                from zeus_search import get_engine as get_search
                search_results = get_search().search(
                    topic, max_results=8, use_web=True, use_ai=False
                )["results"]
            except Exception as e:
                log.debug(f"[Learner] Search failed: {e}")

        # 2. Get prior content for this topic (lower depth)
        prior_content = self._get_prior_content(topic, depth)

        # 3. Logic engine context
        logic_context = ""
        if use_logic:
            logic_context = self._get_logic_context(topic)

        # 4. Generate article
        try:
            article = self._handler.handle(
                topic=topic, depth=depth,
                search_results=search_results,
                logic_context=logic_context,
                prior_content=prior_content,
            )
        except Exception as e:
            log.error(f"[Learner] Handler failed for '{topic}' @ {depth}: {e}")
            self._total_errors += 1
            return {"error": str(e), "topic": topic, "depth": depth}

        # 5. Persist to DB
        saved = self._save_article(article)

        duration_ms = round((time.time() - t0) * 1000, 1)
        with self._lock:
            self._total_learned += 1
            self._depth_counts[depth] += 1
            self._domain_counts[article.domain] += 1
            self._recent.append({
                "topic": topic, "depth": depth, "domain": article.domain,
                "quality": article.quality_score, "ms": duration_ms,
            })

        # 6. Post-learn actions
        if saved and article.quality_score >= 0.60:
            self._post_learn_actions(article)

        result = {
            "status":     "ok" if saved else "duplicate",
            "topic":      topic,
            "depth":      depth,
            "domain":     article.domain,
            "quality":    article.quality_score,
            "confidence": article.confidence,
            "word_count": article.word_count,
            "engine":     article.engine_used,
            "tags":       article.tags,
            "saved":      saved,
            "duration_ms": duration_ms,
        }
        log.info(
            f"[Learner] '{topic}' @ {depth} — "
            f"quality={article.quality_score:.2f} "
            f"engine={article.engine_used} "
            f"{'saved' if saved else 'duplicate'}"
        )
        return result

    def advance_topic(self, topic: str, current_depth: str) -> Dict:
        """Advance a topic to the next depth level."""
        idx = DEPTH_INDEX.get(current_depth, 0)
        if idx >= len(DEPTHS) - 1:
            return {"status": "already_mastery", "topic": topic}
        next_depth = DEPTHS[idx + 1]
        return self.learn_topic(topic, depth=next_depth)

    def run_batch(self, batch_size: int = 20) -> Dict:
        """
        Pull a batch of pending topics from the queue and learn them.
        Returns batch result summary.
        """
        from db_init import claim_queue_batch, complete_queue_item
        rows = claim_queue_batch(batch_size=batch_size, worker_id="learner")
        if not rows:
            return {"processed": 0, "learned": 0, "errors": 0, "reason": "queue_empty"}

        processed = 0
        learned   = 0
        errors    = 0
        for row in rows:
            topic  = row["topic"]
            depth  = row["depth"]
            item_id = row["id"]
            result = self.learn_topic(topic, depth=depth)
            processed += 1
            if "error" in result:
                errors += 1
                complete_queue_item(item_id, success=False, error=result["error"])
            else:
                learned += 1
                complete_queue_item(item_id, success=True)

        return {
            "processed": processed, "learned": learned, "errors": errors,
            "batch_size": batch_size,
        }

    # ---- Scheduler -------------------------------------------------------

    def start_scheduler(self) -> None:
        """Start the background learning scheduler."""
        with self._lock:
            if self._scheduler_running:
                return
            self._scheduler_running = True
        t = threading.Thread(
            target=self._scheduler_loop,
            name="learner_scheduler", daemon=True
        )
        t.start()
        self._scheduler_thread = t
        log.info(f"[Learner] Scheduler started (interval={self._BATCH_INTERVAL}s)")

    def stop_scheduler(self) -> None:
        with self._lock:
            self._scheduler_running = False

    def _scheduler_loop(self) -> None:
        while self._scheduler_running:
            try:
                result = self.run_batch(batch_size=10)
                if result.get("processed", 0) > 0:
                    log.info(
                        f"[Learner:Sched] Batch: "
                        f"{result['learned']} learned, {result['errors']} errors"
                    )
            except Exception as e:
                log.warning(f"[Learner:Sched] Batch error: {e}")
            time.sleep(self._BATCH_INTERVAL)

    # ---- Internal helpers -----------------------------------------------

    def _get_prior_content(self, topic: str, depth: str) -> str:
        """Get existing knowledge at a lower depth for context."""
        idx = DEPTH_INDEX.get(depth, 0)
        if idx == 0:
            return ""
        try:
            from db_init import get_db
            conn = get_db()
            prior_depth = DEPTHS[idx - 1]
            row = conn.execute(
                "SELECT content FROM knowledge WHERE topic=? AND depth=? LIMIT 1",
                (topic, prior_depth)
            ).fetchone()
            conn.close()
            return (row["content"] or "")[:800] if row else ""
        except Exception:
            return ""

    def _get_logic_context(self, topic: str) -> str:
        """Get logic engine reasoning context for the topic."""
        try:
            from logic_engine import get_engine, LogicFact
            engine   = get_engine()
            keywords = re.findall(r'\b[A-Za-z][A-Za-z0-9]{3,}\b', topic)[:6]
            facts    = [
                LogicFact(predicate="learning_topic", args=(topic,), source="learner")
            ]
            for kw in keywords:
                facts.append(
                    LogicFact(predicate="topic_keyword", args=(kw.lower(),), source="learner")
                )
            result       = engine.reason(facts, max_depth=6, auto_learn=False)
            conclusions  = [c.to_str() for c in result.conclusions[:4]]
            hypotheses   = [h.to_str() for h in result.abductive_hypotheses[:2]]
            all_ctx = conclusions + hypotheses
            if all_ctx:
                return "Logic inferences: " + "; ".join(all_ctx[:5])
        except Exception:
            pass
        return ""

    def _save_article(self, article: LearningArticle) -> bool:
        """Save article to DB. Returns True if new record inserted."""
        if not article.content or not article.content.strip():
            return False
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                INSERT OR IGNORE INTO knowledge
                    (topic, depth, content, source_url, confidence,
                     quality_score, domain, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                article.to_db_tuple()
            )
            inserted = conn.total_changes > 0
            if not inserted:
                # Update if quality improved
                conn.execute(
                    """
                    UPDATE knowledge
                    SET content=?, confidence=?, quality_score=?,
                        domain=?, updated_at=datetime('now')
                    WHERE topic=? AND depth=? AND quality_score < ?
                    """,
                    (article.content[:10000], article.confidence, article.quality_score,
                     article.domain, article.topic, article.depth, article.quality_score)
                )
                inserted = conn.total_changes > 0
            conn.commit()
            conn.close()
            return inserted
        except Exception as e:
            log.warning(f"[Learner] Save article error: {e}")
            return False

    def _post_learn_actions(self, article: LearningArticle) -> None:
        """
        Actions triggered after a high-quality article is saved:
        - Advanced+: trigger knowledge mutation
        - Professional+: add to logic engine semantic index
        - Mastery: inject into genome
        """
        depth_idx = DEPTH_INDEX.get(article.depth, 0)

        # Advanced+: trigger mutation
        if depth_idx >= 1:
            try:
                from zeus_mutator import get_engine as get_mutator
                mutator = get_mutator()
                mutator.mutate_from_knowledge(
                    article.topic, article.depth,
                    source="learner_post_action"
                )
            except Exception as e:
                log.debug(f"[Learner] Mutation trigger failed: {e}")

        # Professional+: notify logic engine to rebuild semantic index
        if depth_idx >= 2:
            try:
                from logic_engine import get_engine
                engine = get_engine()
                # Add to in-memory semantic index immediately
                engine._semantic_idx._docs.append(
                    (0, article.topic, article.content[:500])
                )
            except Exception:
                pass

        # Mastery: inject into genome
        if depth_idx >= 4:
            try:
                from genome_manager import get_genome_engine
                genome_eng = get_genome_engine()
                genome_name = re.sub(r'[^a-zA-Z0-9_]', '_', article.topic.lower())[:50]
                genome_name = f"learned_{genome_name}_{uuid.uuid4().hex[:6]}"
                genome_eng.add(
                    name=genome_name,
                    description=f"Mastery article: {article.topic}",
                    module_type=f"knowledge_{article.domain}",
                    source_code=article.content[:8080],
                    version="v1.0",
                    priority=int(article.confidence * 60),
                    capabilities=", ".join(article.tags[:8]),
                    lineage="learner_mastery",
                )
                log.info(f"[Learner] Mastery article injected to genome: {genome_name}")
            except Exception as e:
                log.debug(f"[Learner] Genome injection failed: {e}")

    def queue_topic(self, topic: str, depth: str = "Simple",
                     priority: float = 1.0, source: str = "api") -> bool:
        """Queue a topic for background learning."""
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                INSERT OR IGNORE INTO queue
                    (topic, depth, priority, status, attempts, source)
                VALUES (?, ?, ?, 'pending', 0, ?)
                """,
                (topic[:200], depth, priority, source)
            )
            inserted = conn.total_changes > 0
            conn.commit()
            conn.close()
            return inserted
        except Exception as e:
            log.warning(f"[Learner] queue_topic error: {e}")
            return False

    def stats(self) -> Dict:
        with self._lock:
            try:
                from db_init import get_db
                conn = get_db()
                pending = conn.execute(
                    "SELECT COUNT(*) FROM queue WHERE status='pending'"
                ).fetchone()[0]
                done    = conn.execute(
                    "SELECT COUNT(*) FROM queue WHERE status='done'"
                ).fetchone()[0]
                failed  = conn.execute(
                    "SELECT COUNT(*) FROM queue WHERE status='failed'"
                ).fetchone()[0]
                total_k = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
                conn.close()
            except Exception:
                pending = done = failed = total_k = 0
            return {
                "total_learned":   self._total_learned,
                "total_errors":    self._total_errors,
                "depth_counts":    dict(self._depth_counts),
                "domain_counts":   dict(self._domain_counts),
                "scheduler":       self._scheduler_running,
                "queue_pending":   pending,
                "queue_done":      done,
                "queue_failed":    failed,
                "knowledge_total": total_k,
                "recent":          list(self._recent)[-10:],
            }


# ============================================================================
# SINGLETON
# ============================================================================

_learner_lock:     threading.RLock      = threading.RLock()
_learner_instance: Optional[LearnerEngine] = None


def get_learner_engine() -> LearnerEngine:
    global _learner_instance
    with _learner_lock:
        if _learner_instance is None:
            _learner_instance = LearnerEngine()
            _learner_instance.start_scheduler()
        return _learner_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@learner_bp.route("/api/learner/health", methods=["GET"])
def learner_health():
    engine = get_learner_engine()
    stats  = engine.stats()
    return jsonify({
        "status":        "ok",
        "module":        "zeus_learner",
        "version":       "2.0",
        "scheduler":     stats["scheduler"],
        "queue_pending": stats["queue_pending"],
        "total_learned": stats["total_learned"],
    })


@learner_bp.route("/api/learner/stats", methods=["GET"])
def learner_stats():
    try:
        return jsonify(get_learner_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@learner_bp.route("/api/learner/learn", methods=["POST"])
def learner_learn():
    """
    POST {
      "topic": str,
      "depth": "Simple"|"Advanced"|"Professional"|"Complex"|"Mastery",
      "use_search": bool,
      "use_logic":  bool
    }
    """
    data       = request.get_json(force=True, silent=True) or {}
    topic      = data.get("topic", "").strip()
    depth      = data.get("depth", "Simple")
    use_search = bool(data.get("use_search", True))
    use_logic  = bool(data.get("use_logic", True))

    if not topic:
        return jsonify({"error": "topic required"}), 400
    if depth not in DEPTHS:
        return jsonify({"error": f"depth must be one of: {DEPTHS}"}), 400

    result = get_learner_engine().learn_topic(
        topic, depth=depth, use_search=use_search, use_logic=use_logic
    )
    code = 400 if "error" in result else 200
    return jsonify(result), code


@learner_bp.route("/api/learner/advance", methods=["POST"])
def learner_advance():
    """Advance a topic to its next depth level."""
    data  = request.get_json(force=True, silent=True) or {}
    topic = data.get("topic", "").strip()
    depth = data.get("current_depth", "Simple")
    if not topic:
        return jsonify({"error": "topic required"}), 400
    return jsonify(get_learner_engine().advance_topic(topic, depth))


@learner_bp.route("/api/learner/queue", methods=["POST"])
def learner_queue():
    """
    POST { "topic": str, "depth": str, "priority": float }
    or POST { "topics": [{"topic": str, "depth": str, "priority": float}] }
    """
    data   = request.get_json(force=True, silent=True) or {}
    engine = get_learner_engine()

    topics_raw = data.get("topics")
    if topics_raw:
        queued  = 0
        for t in topics_raw:
            ok = engine.queue_topic(
                t.get("topic", ""), t.get("depth", "Simple"),
                float(t.get("priority", 1.0)), "api_batch"
            )
            if ok: queued += 1
        return jsonify({"status": "ok", "queued": queued, "total": len(topics_raw)})

    topic    = data.get("topic", "").strip()
    depth    = data.get("depth", "Simple")
    priority = float(data.get("priority", 1.0))
    if not topic:
        return jsonify({"error": "topic or topics required"}), 400
    ok = engine.queue_topic(topic, depth, priority, "api")
    return jsonify({"status": "ok" if ok else "duplicate", "topic": topic, "depth": depth})


@learner_bp.route("/api/learner/batch", methods=["POST"])
def learner_batch():
    """Run a learning batch immediately."""
    data       = request.get_json(force=True, silent=True) or {}
    batch_size = int(data.get("batch_size", 10))
    try:
        result = get_learner_engine().run_batch(batch_size=batch_size)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@learner_bp.route("/api/learner/scheduler/start", methods=["POST"])
def learner_scheduler_start():
    get_learner_engine().start_scheduler()
    return jsonify({"status": "ok", "scheduler": "started"})


@learner_bp.route("/api/learner/scheduler/stop", methods=["POST"])
def learner_scheduler_stop():
    get_learner_engine().stop_scheduler()
    return jsonify({"status": "ok", "scheduler": "stopped"})


@learner_bp.route("/api/learner/depths", methods=["GET"])
def learner_depths():
    return jsonify({
        "depths": DEPTHS,
        "descriptions": {
            "Simple":       "3-sentence summary: what it is, why it matters, one key insight",
            "Advanced":     "Detailed article: mechanisms, patterns, pitfalls, use cases",
            "Professional": "Deep-dive with architecture, implementation, security analysis",
            "Complex":      "Expert analysis: data structures, algorithms, attack vectors",
            "Mastery":      "Comprehensive synthesis — seeds Zeus genome",
        }
    })


# ============================================================================
# MODULE-LEVEL CONVENIENCE WRAPPER
# zeus_recursive_learner does: from zeus_learner import learn_topic
# This wrapper delegates to the singleton LearnerEngine instance.
# ============================================================================

def learn_topic(topic: str, depth: str = "Simple") -> Tuple[bool, dict]:
    """Module-level wrapper around LearnerEngine.learn_topic for easy import."""
    engine = get_learner_engine()
    result = engine.learn_topic(topic, depth)
    success = result.get("status") == "learned"
    return success, result


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(learner_bp)
    log.info("[learner] ✓ Registered at /api/learner")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_learner",
            blueprint_var="learner_bp",
            url_prefix="/api/learner",
            version="2.0",
            description="5-depth learning engine: Simple→Mastery with search, logic reasoning, mutation, genome injection",
            capabilities=[
                {"id": "learner.learn",    "endpoint": "/api/learner/learn",    "method": "POST", "tags": ["learn", "knowledge"]},
                {"id": "learner.advance",  "endpoint": "/api/learner/advance",  "method": "POST", "tags": ["learn"]},
                {"id": "learner.queue",    "endpoint": "/api/learner/queue",    "method": "POST", "tags": ["learn", "queue"]},
                {"id": "learner.batch",    "endpoint": "/api/learner/batch",    "method": "POST", "tags": ["learn", "batch"]},
                {"id": "learner.stats",    "endpoint": "/api/learner/stats",    "method": "GET",  "tags": ["stats"]},
                {"id": "learner.health",   "endpoint": "/api/learner/health",   "method": "GET",  "tags": ["health"]},
            ],
            depends_on=["zeus_search", "logic_engine", "zeus_mutator", "genome_manager"],
            boot_order=50,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5017, debug=True, use_reloader=False)
