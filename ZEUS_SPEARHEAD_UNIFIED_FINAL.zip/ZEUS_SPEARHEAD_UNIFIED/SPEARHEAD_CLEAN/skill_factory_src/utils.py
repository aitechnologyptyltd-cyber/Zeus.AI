# src/utils.py
# Zeus Skill Factory — Archive & Dependency Helpers
# FIXED: zip-slip / path-traversal protection on extraction.
# FIXED: version resolution is cached, timeout-bounded, and never
#        shells out per-skill inside the autonomous improvement loop.

import zipfile
import tarfile
import subprocess
import tempfile
import shutil
import logging
from pathlib import Path
from functools import lru_cache

log = logging.getLogger("zeus.skill_factory.utils")

# Known-safe pins for common libraries. Preferred over hitting PyPI at all —
# no network call, no supply-chain surprise, no autonomous-loop stall.
KNOWN_SAFE_VERSIONS = {
    "Pillow": "10.4.0",
    "requests": "2.32.3",
    "numpy": "1.26.4",
    "pandas": "2.2.2",
}


class UnsafeArchiveError(Exception):
    """Raised when an archive contains a path-traversal ('zip-slip') entry."""
    pass


def _is_within_directory(directory: Path, target: Path) -> bool:
    """Verify `target` resolves to a path inside `directory`."""
    try:
        directory = directory.resolve()
        target = target.resolve()
        return str(target).startswith(str(directory) + "/") or target == directory
    except Exception:
        return False


def _safe_extract_zip(zf: zipfile.ZipFile, extract_dir: Path):
    for member in zf.infolist():
        target_path = extract_dir / member.filename
        if not _is_within_directory(extract_dir, target_path):
            raise UnsafeArchiveError(
                f"Blocked path-traversal entry in archive: {member.filename}"
            )
    zf.extractall(extract_dir)


def _safe_extract_tar(tf: tarfile.TarFile, extract_dir: Path):
    for member in tf.getmembers():
        target_path = extract_dir / member.name
        if not _is_within_directory(extract_dir, target_path):
            raise UnsafeArchiveError(
                f"Blocked path-traversal entry in archive: {member.name}"
            )
        # Also reject symlinks/hardlinks pointing outside the extraction dir
        if member.issym() or member.islnk():
            link_target = (extract_dir / member.name).parent / member.linkname
            if not _is_within_directory(extract_dir, link_target):
                raise UnsafeArchiveError(
                    f"Blocked unsafe link entry in archive: {member.name}"
                )
    tf.extractall(extract_dir)


def unpack_archive(archive_path: Path) -> Path:
    """
    Extract any supported archive to a temp dir.
    SAFE: rejects entries that would escape the extraction directory
    (zip-slip / path traversal), which the original implementation did not.
    """
    archive_path = Path(archive_path)
    extract_dir = Path(tempfile.mkdtemp(prefix="skill_extract_"))

    try:
        if archive_path.suffix == ".zip":
            with zipfile.ZipFile(archive_path, "r") as zf:
                _safe_extract_zip(zf, extract_dir)
        elif archive_path.suffix in (".tar", ".gz", ".bz2", ".tgz"):
            with tarfile.open(archive_path, "r:*") as tf:
                _safe_extract_tar(tf, extract_dir)
        elif archive_path.is_dir():
            shutil.copytree(archive_path, extract_dir, dirs_exist_ok=True)
        else:
            raise ValueError(f"Unsupported archive type: {archive_path.suffix}")
    except (UnsafeArchiveError, ValueError):
        shutil.rmtree(extract_dir, ignore_errors=True)
        raise
    except Exception as e:
        shutil.rmtree(extract_dir, ignore_errors=True)
        raise RuntimeError(f"Failed to extract archive: {e}") from e

    return extract_dir


@lru_cache(maxsize=256)
def resolve_pypi_version(pkg_name: str) -> str:
    """
    Resolve a pinned version for a package.

    FIX vs original: checks a local known-safe table first (no network,
    no autonomous-loop stall, no per-skill subprocess spawn). Falls back
    to a single bounded `pip index versions` call, cached so it only
    ever runs once per package name per process.
    """
    if pkg_name in KNOWN_SAFE_VERSIONS:
        return KNOWN_SAFE_VERSIONS[pkg_name]

    try:
        result = subprocess.run(
            ["pip", "index", "versions", pkg_name],
            capture_output=True, text=True, timeout=5
        )
        for line in result.stdout.splitlines():
            if "Available versions:" in line:
                versions = line.split(":", 1)[1].split(",")
                for v in versions:
                    v = v.strip().strip("()")
                    if v and not any(x in v for x in ["a", "b", "rc", "dev"]):
                        return v
        return "latest"
    except Exception as e:
        log.warning(f"[skill_factory] Could not resolve version for {pkg_name}: {e}")
        return "latest"
