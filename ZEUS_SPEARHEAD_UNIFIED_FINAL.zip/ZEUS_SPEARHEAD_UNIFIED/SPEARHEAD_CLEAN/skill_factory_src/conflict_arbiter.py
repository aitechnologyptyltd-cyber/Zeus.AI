# src/conflict_arbiter.py
# Zeus Skill Factory — Conflict Arbiter
# FIXED: original called `raw._fields.get('params', {})` — RawSkill is a
#        Pydantic model, not a namedtuple, and never had a `params` field
#        at all. This crashed on the first merge. Now uses raw.params
#        (added to the model) directly.

import logging
from typing import List
from src.models import SkillCandidate, RawSkill, MergedSkill
from src.utils import resolve_pypi_version

log = logging.getLogger("zeus.skill_factory.arbiter")


class ConflictArbiter:
    def merge(self, candidates: List[SkillCandidate], raw_skills: List[RawSkill]) -> List[MergedSkill]:
        merged = []
        raw_map = {r.name: r for r in raw_skills}
        matched_names = set()

        # FIX: multiple heuristic sources (README regex scan + code docstring
        # scan) can independently discover the same function name, producing
        # duplicate candidates. Dedup by name, preferring the richer entry
        # (more params, or longer description) before merging.
        deduped = {}
        for cand in candidates:
            existing = deduped.get(cand.name)
            if existing is None:
                deduped[cand.name] = cand
            else:
                richer = cand if (len(cand.params) + len(cand.description)) > \
                                  (len(existing.params) + len(existing.description)) else existing
                deduped[cand.name] = richer
        candidates = list(deduped.values())

        for cand in candidates:
            raw = raw_map.get(cand.name)

            if raw:
                matched_names.add(cand.name)
                deps = {
                    dep: resolve_pypi_version(dep)
                    for dep in raw.dependencies if dep
                }

                # FIX: was `raw._fields.get(...)` — now uses raw.params directly.
                # Heuristic params (human-labeled types) win when both exist;
                # AST params (verified from signature) fill any gaps.
                params = dict(raw.params)
                params.update(cand.params)

                merged.append(MergedSkill(
                    name=cand.name,
                    body=raw.body,
                    imports=sorted(set(raw.imports)),
                    dependencies=deps,
                    parameters=params,
                    description=cand.description,
                    test_examples=[],
                    is_complete=True,
                    source_file=raw.source_file,
                ))
            else:
                # No AST match — heuristic-only candidate. Marked incomplete;
                # generator will either use a known intent mapping or
                # explicitly refuse (never silently emit a stub).
                merged.append(MergedSkill(
                    name=cand.name,
                    body="",
                    imports=[],
                    dependencies={},
                    parameters=cand.params,
                    description=cand.description,
                    test_examples=[],
                    is_complete=False,
                ))

        # Raw skills with no heuristic match are still real, verified code —
        # don't drop them just because no doc/comment described them.
        for raw in raw_skills:
            if raw.name in matched_names:
                continue
            deps = {dep: resolve_pypi_version(dep) for dep in raw.dependencies if dep}
            merged.append(MergedSkill(
                name=raw.name,
                body=raw.body,
                imports=sorted(set(raw.imports)),
                dependencies=deps,
                parameters=dict(raw.params),
                description=f"Extracted function '{raw.name}' (no accompanying doc found)",
                test_examples=[],
                is_complete=True,
                source_file=raw.source_file,
            ))

        return merged
