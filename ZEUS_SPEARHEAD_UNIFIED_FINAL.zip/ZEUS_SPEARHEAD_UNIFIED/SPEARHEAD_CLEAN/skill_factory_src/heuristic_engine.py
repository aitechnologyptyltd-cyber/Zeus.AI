# src/heuristic_engine.py
# Zeus Skill Factory — Heuristic Scout
# FIXED: rake-nltk is optional (graceful fallback), not a hard crash if
#        the nltk punkt corpus isn't downloaded in this environment.
# FIXED: also scans code-file docstrings, not just prose docs, so the
#        candidate list doesn't silently collapse to empty on typical
#        code-only archives (the original only scanned .md/.txt/.rst/.pdf).

import re
import ast
import logging
from pathlib import Path
from typing import List
from src.models import SkillCandidate

log = logging.getLogger("zeus.skill_factory.heuristic")

try:
    from rake_nltk import Rake
    _RAKE_AVAILABLE = True
except Exception:
    _RAKE_AVAILABLE = False


class HeuristicEngine:
    def __init__(self):
        self._rake = None
        if _RAKE_AVAILABLE:
            try:
                self._rake = Rake(min_length=1, max_length=4)
            except Exception as e:
                # Common failure: punkt corpus not downloaded. Don't crash
                # the whole pipeline over a keyword-extraction nicety.
                log.warning(f"[heuristic] RAKE unavailable, using fallback: {e}")
                self._rake = None

        self.patterns = {
            "function_def": re.compile(
                r'(?:def|function|public|private)\s+(\w+)\s*\(([^)]*)\)', re.MULTILINE
            ),
            "api_route": re.compile(
                r'@(?:app|router|api)\.(?:route|get|post|put|delete)\([\'"]([^\'"]+)[\'"]'
            ),
        }

    def _keywords(self, text: str) -> List[str]:
        """Extract keywords, falling back to naive frequency if RAKE is unavailable."""
        if self._rake:
            try:
                self._rake.extract_keywords_from_text(text)
                return self._rake.get_ranked_phrases()[:5]
            except Exception:
                pass
        # Naive fallback: most common words > 4 chars, excluding stopwords-ish
        words = re.findall(r"[A-Za-z]{4,}", text.lower())
        seen = []
        for w in words:
            if w not in seen:
                seen.append(w)
            if len(seen) >= 5:
                break
        return seen

    def scan(self, text: str) -> List[SkillCandidate]:
        """Scan prose text (README, docs) for skill-like descriptions."""
        candidates = []
        text = text.replace("\r", "\n")

        for match in self.patterns["function_def"].finditer(text):
            name = match.group(1)
            params_str = match.group(2)
            params = {}
            for p in params_str.split(","):
                p = p.strip()
                if not p:
                    continue
                if "=" in p:
                    p_name, _ = p.split("=", 1)
                    params[p_name.strip()] = "optional"
                elif ":" in p:
                    p_name, p_type = p.split(":", 1)
                    params[p_name.strip()] = p_type.strip()
                else:
                    params[p] = "unknown"

            start = max(0, match.start() - 200)
            context = text[start:match.end()]
            keywords = self._keywords(context)
            description = (
                f"Skill {name} related to {', '.join(keywords)}"
                if keywords else f"Function {name}"
            )

            candidates.append(SkillCandidate(
                name=name, description=description,
                params=params, source_text=context
            ))

        if not candidates:
            for match in self.patterns["api_route"].finditer(text):
                candidates.append(SkillCandidate(
                    name=f"endpoint_{match.group(1).replace('/', '_')}",
                    description=f"HTTP endpoint {match.group(1)}",
                    params={}, source_text=match.group(0)
                ))

        return candidates

    def scan_code_docstrings(self, directory: Path) -> List[SkillCandidate]:
        """
        FIX: New capability. Scan .py files directly for function docstrings
        so archives with real code but sparse README docs still yield
        candidates instead of falling through to the generation crash path.
        """
        candidates = []
        for filepath in directory.rglob("*.py"):
            try:
                source = filepath.read_text(encoding="utf-8", errors="ignore")
                tree = ast.parse(source)
            except (SyntaxError, UnicodeDecodeError, OSError):
                continue

            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node) or ""
                    params = {a.arg: "unknown" for a in node.args.args if a.arg != "self"}
                    keywords = self._keywords(doc) if doc else []
                    description = (
                        doc.strip().split("\n")[0] if doc
                        else (f"Function {node.name}" +
                              (f" related to {', '.join(keywords)}" if keywords else ""))
                    )
                    candidates.append(SkillCandidate(
                        name=node.name,
                        description=description,
                        params=params,
                        source_text=doc or f"def {node.name}(...)"
                    ))

        return candidates
