# src/models.py
# Zeus Skill Factory — Core Data Models
# FIXED: RawSkill now has 'params' field (conflict_arbiter needs it).
# FIXED: All list fields use validators to strip None/empty entries.

from pydantic import BaseModel, Field, field_validator
from typing import List, Dict, Optional, Any


class SkillCandidate(BaseModel):
    """Output of Heuristic Engine — human-readable intent, no verified code."""
    name: str
    description: str
    params: Dict[str, str] = Field(default_factory=dict)
    input_example: Optional[Any] = None
    output_example: Optional[Any] = None
    source_text: str = ""


class RawSkill(BaseModel):
    """Output of AST Surgeon — verified, verbatim source code."""
    name: str
    body: str                                   # ast.unparse() output, verbatim
    imports: List[str] = Field(default_factory=list)
    dependencies: List[str] = Field(default_factory=list)
    params: Dict[str, str] = Field(default_factory=dict)   # FIX: was missing entirely
    return_type: Optional[str] = None
    complexity: int = 0
    source_file: str = ""
    language: str = "python"

    @field_validator("imports", "dependencies", mode="before")
    @classmethod
    def _strip_falsy(cls, v):
        """FIX: ast_surgeon was putting None/'' into these lists, which
        breaks Pydantic validation. Strip them at the boundary instead of
        trusting every caller to filter correctly."""
        if v is None:
            return []
        return [x for x in v if x]


class MergedSkill(BaseModel):
    """Output of Conflict Arbiter — ready for code generation."""
    name: str
    body: str = ""
    imports: List[str] = Field(default_factory=list)
    dependencies: Dict[str, str] = Field(default_factory=dict)   # pkg -> pinned version
    parameters: Dict[str, str] = Field(default_factory=dict)
    description: str = ""
    test_examples: List[Dict[str, Any]] = Field(default_factory=list)
    is_complete: bool = False
    source_file: str = ""


class TestResult(BaseModel):
    passed: bool
    stdout: str = ""
    stderr: str = ""
    coverage: float = 0.0
    errors: List[str] = Field(default_factory=list)
    skill_name: str = ""
