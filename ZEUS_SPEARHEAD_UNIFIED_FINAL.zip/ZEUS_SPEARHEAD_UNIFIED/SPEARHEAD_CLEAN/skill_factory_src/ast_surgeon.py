# src/ast_surgeon.py
# Zeus Skill Factory — AST Surgeon
# FIXED: uses ast.unparse() instead of astor — matches the convention
#        already established in zeus_refactoring_engine.py, drops the
#        astor dependency entirely.
# FIXED: JS parser no longer inserts None/'' into imports/dependencies
#        (the Pydantic validator in models.py also guards this now, but
#        it's cleaner to not produce garbage in the first place).
# FIXED: params are now populated on RawSkill (arbiter needs them).

import ast
import logging
from pathlib import Path
from typing import List
from src.models import RawSkill

log = logging.getLogger("zeus.skill_factory.surgeon")

try:
    import esprima
    _ESPRIMA_AVAILABLE = True
except Exception:
    _ESPRIMA_AVAILABLE = False


DEP_MAP = {
    "Image": "Pillow",
    "pd": "pandas",
    "np": "numpy",
    "requests": "requests",
    # stdlib — explicitly mapped to None so they're never mistaken for
    # missing entries; filtered out before reaching RawSkill.
    "json": None, "os": None, "sys": None, "re": None, "pathlib": None,
}


class ASTSurgeon:
    def __init__(self):
        self.extensions = {".py": self._parse_python}
        if _ESPRIMA_AVAILABLE:
            self.extensions[".js"] = self._parse_javascript
            self.extensions[".ts"] = self._parse_javascript
        else:
            log.warning("[surgeon] esprima not installed — skipping JS/TS extraction")

    def extract_skills(self, directory: Path) -> List[RawSkill]:
        skills = []
        for ext, parser in self.extensions.items():
            for filepath in directory.rglob(f"*{ext}"):
                try:
                    skills.extend(parser(filepath))
                except Exception as e:
                    log.warning(f"[surgeon] Could not parse {filepath}: {e}")
        return skills

    def _cyclomatic_complexity(self, node: ast.AST) -> int:
        complexity = 1
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler, ast.With)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        return complexity

    def _parse_python(self, filepath: Path) -> List[RawSkill]:
        source = filepath.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(source)
        skills = []

        imports = [f"import {n.names[0].name}" for n in ast.walk(tree)
                   if isinstance(n, ast.Import)]
        imports += [
            f"from {n.module} import {', '.join(a.name for a in n.names)}"
            for n in ast.walk(tree)
            if isinstance(n, ast.ImportFrom) and n.module
        ]

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                body = ast.unparse(node)   # FIX: matches zeus_refactoring_engine convention

                deps = set()
                for child in ast.walk(node):
                    if isinstance(child, ast.Name) and child.id in DEP_MAP:
                        mapped = DEP_MAP[child.id]
                        if mapped:  # skip stdlib (mapped to None)
                            deps.add(mapped)

                params = {}
                for a in node.args.args:
                    if a.arg == "self":
                        continue
                    ann = ast.unparse(a.annotation) if a.annotation else "unknown"
                    params[a.arg] = ann

                return_type = ast.unparse(node.returns) if node.returns else None

                skills.append(RawSkill(
                    name=node.name,
                    body=body.strip(),
                    imports=sorted(set(imports)),
                    dependencies=sorted(deps),
                    params=params,
                    return_type=return_type,
                    complexity=self._cyclomatic_complexity(node),
                    source_file=str(filepath),
                    language="python",
                ))
        return skills

    def _parse_javascript(self, filepath: Path) -> List[RawSkill]:
        source = filepath.read_text(encoding="utf-8", errors="ignore")
        tree = esprima.parseScript(source, {"range": True})
        skills = []

        for node in tree.body:
            if node.type == "FunctionDeclaration":
                body = source[node.range[0]:node.range[1]]

                imports = ['const fs = require("fs")'] if "fs." in body or "require('fs')" in body else []
                dependencies = ["axios"] if "axios" in body else []

                params = {p.name: "unknown" for p in node.params if hasattr(p, "name")}

                skills.append(RawSkill(
                    name=node.id.name if node.id else "anonymous",
                    body=body,
                    imports=imports,           # FIX: no more [None]
                    dependencies=dependencies, # FIX: no more ['']
                    params=params,
                    return_type=None,
                    complexity=0,
                    source_file=str(filepath),
                    language="javascript",
                ))
        return skills
