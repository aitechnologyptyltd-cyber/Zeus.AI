# src/validation_rig.py
# Zeus Skill Factory — Validation Rig
# FIXED (architecture change): the original stood up a brand-new
#        Docker/venv sandbox per skill — duplicating zeus_sandbox.py,
#        which already exists in SPEARHEAD, is already covered by
#        tests/test_sandbox.py, and already blocks dangerous imports.
#        This rig now uses zeus_sandbox as the primary execution path,
#        with an isolated-venv fallback ONLY when zeus_sandbox isn't
#        importable (e.g. running this factory standalone, outside Zeus).
# FIXED: `pylint --fail-under=7.0` + `check=True` treated ordinary
#        convention warnings as hard failures via bit-flag exit codes.
#        Static analysis is now advisory (logged, scored) rather than a
#        blocking gate — the real gate is "does it execute correctly and
#        does pytest pass," which is what actually proves the skill works.
# FIXED: dependency installation from an untrusted archive's inferred
#        requirements.txt is no longer performed automatically — pinned
#        deps are recorded in the manifest for a human/CI step to install
#        deliberately, rather than pip-installing arbitrary packages
#        inline during autonomous validation.

import logging
import subprocess
import tempfile
import textwrap
from pathlib import Path
from typing import Optional
from src.models import TestResult

log = logging.getLogger("zeus.skill_factory.validation")

try:
    from zeus_sandbox import get_sandbox
    _ZEUS_SANDBOX_AVAILABLE = True
except Exception:
    _ZEUS_SANDBOX_AVAILABLE = False


class ValidationRig:
    def __init__(self, use_docker: bool = False):
        # use_docker retained for API compatibility with the original
        # design, but ignored when zeus_sandbox is available — Zeus's own
        # sandbox is the standard, not a per-skill container.
        self.use_docker = use_docker and not _ZEUS_SANDBOX_AVAILABLE
        if not _ZEUS_SANDBOX_AVAILABLE:
            log.warning(
                "[validation_rig] zeus_sandbox not importable — falling back "
                "to isolated subprocess execution. This should only happen "
                "when running the skill factory outside a SPEARHEAD deployment."
            )

    def validate(self, skill_dir: Path) -> TestResult:
        skill_dir = Path(skill_dir)
        py_files = [f for f in skill_dir.glob("*.py") if not f.name.startswith("test_")]
        if not py_files:
            return TestResult(passed=False, errors=["No skill module found"], skill_name=skill_dir.name)

        module_file = py_files[0]
        skill_name = module_file.stem

        # 1. Advisory static analysis (never blocks — just informs)
        lint_warnings = self._run_pylint_advisory(module_file)

        # 2. Real execution + test verification
        if _ZEUS_SANDBOX_AVAILABLE:
            result = self._validate_with_zeus_sandbox(module_file, skill_dir, skill_name)
        else:
            result = self._validate_with_subprocess(module_file, skill_dir, skill_name)

        if lint_warnings:
            result.errors = result.errors + [f"lint_advisory: {w}" for w in lint_warnings[:5]]

        return result

    # ===== Primary path: Zeus's own sandbox =====

    def _validate_with_zeus_sandbox(self, module_file: Path, skill_dir: Path, skill_name: str) -> TestResult:
        source = module_file.read_text(encoding="utf-8")
        sandbox = get_sandbox()

        # Syntax + safety check: does the skill's own code execute cleanly
        # under Zeus's blocked-import policy?
        result = sandbox.run_python(source, strict=True)

        if not result.success:
            return TestResult(
                passed=False,
                stdout=getattr(result, "stdout", ""),
                stderr=getattr(result, "error", ""),
                errors=[f"Sandbox execution failed: {getattr(result, 'error', 'unknown error')}"],
                skill_name=skill_name,
            )

        # Test file execution (the smoke test from generator.py) is run via
        # pytest directly against the skill dir, isolated to a temp copy —
        # pytest itself needs real filesystem/import access that the
        # in-process sandbox doesn't provide, so this stage uses a
        # subprocess with a short timeout as a secondary, bounded check.
        test_result = self._run_pytest(skill_dir, skill_name)
        return test_result

    # ===== Fallback path: isolated subprocess (no zeus_sandbox available) =====

    def _validate_with_subprocess(self, module_file: Path, skill_dir: Path, skill_name: str) -> TestResult:
        # Minimal safety check before even attempting execution.
        source = module_file.read_text(encoding="utf-8")
        banned = ["subprocess", "os.system", "eval(", "exec(", "__import__"]
        hits = [b for b in banned if b in source]
        if hits:
            return TestResult(
                passed=False,
                errors=[f"Blocked pattern(s) found in skill source: {hits}"],
                skill_name=skill_name,
            )

        try:
            compile(source, str(module_file), "exec")
        except SyntaxError as e:
            return TestResult(passed=False, errors=[f"SyntaxError: {e}"], skill_name=skill_name)

        return self._run_pytest(skill_dir, skill_name)

    # ===== Shared: pytest execution + coverage =====

    def _run_pytest(self, skill_dir: Path, skill_name: str) -> TestResult:
        try:
            result = subprocess.run(
                ["pytest", str(skill_dir), "-v", "--tb=short",
                 f"--cov={skill_dir}", "--cov-report=term"],
                capture_output=True, text=True, timeout=60,
                cwd=str(skill_dir.parent),
            )
        except FileNotFoundError:
            return TestResult(
                passed=False, errors=["pytest not installed"], skill_name=skill_name
            )
        except subprocess.TimeoutExpired:
            return TestResult(
                passed=False, errors=["Test execution timed out (60s)"], skill_name=skill_name
            )

        coverage = self._extract_coverage(result.stdout)

        return TestResult(
            passed=(result.returncode == 0),
            stdout=result.stdout,
            stderr=result.stderr,
            coverage=coverage,
            errors=[] if result.returncode == 0 else ["pytest reported failures — see stdout"],
            skill_name=skill_name,
        )

    def _extract_coverage(self, pytest_stdout: str) -> float:
        for line in pytest_stdout.splitlines():
            if "TOTAL" in line:
                parts = line.split()
                if parts and parts[-1].endswith("%"):
                    try:
                        return float(parts[-1].strip("%"))
                    except ValueError:
                        pass
        return 0.0

    # ===== Advisory lint (never blocks) =====

    def _run_pylint_advisory(self, module_file: Path) -> list:
        try:
            result = subprocess.run(
                ["pylint", str(module_file), "--disable=C0114,C0115,C0116", "--score=n"],
                capture_output=True, text=True, timeout=15,
            )
            warnings = [
                line for line in result.stdout.splitlines()
                if line.strip() and (":" in line) and not line.startswith("*")
            ]
            return warnings
        except FileNotFoundError:
            log.debug("[validation_rig] pylint not installed — skipping advisory lint")
            return []
        except subprocess.TimeoutExpired:
            return ["pylint timed out"]
        except Exception as e:
            log.debug(f"[validation_rig] pylint advisory pass failed: {e}")
            return []
