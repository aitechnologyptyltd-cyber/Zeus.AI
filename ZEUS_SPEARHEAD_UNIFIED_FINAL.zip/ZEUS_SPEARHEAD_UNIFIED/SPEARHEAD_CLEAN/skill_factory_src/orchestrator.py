# src/orchestrator.py
# Zeus Skill Factory — Pipeline Orchestrator
# FIXED: SkillGenerationError (and any other single-skill failure) no
#        longer kills the whole run — it's caught, logged, recorded, and
#        the orchestrator moves on to the next skill.
# NEW: wired into genome_manager.py (successful skills register as DNA)
#      and hive_bridge.py (extraction/validation events published), using
#      the same optional-injection pattern as zeus_test_feedback_bridge.py
#      and zeus_refactoring_engine.py — works standalone, integrates
#      automatically when those modules are present.

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from src.utils import unpack_archive, UnsafeArchiveError
from src.heuristic_engine import HeuristicEngine
from src.ast_surgeon import ASTSurgeon
from src.conflict_arbiter import ConflictArbiter
from src.generator import ZeroFluffGenerator, SkillGenerationError
from src.validation_rig import ValidationRig
from src.models import TestResult

log = logging.getLogger("zeus.skill_factory.orchestrator")


class Orchestrator:
    def __init__(self, output_dir: str = "./generated_skills",
                 genome_manager=None, hive_bridge=None):
        self.output_dir = Path(output_dir)
        self.heuristic = HeuristicEngine()
        self.surgeon = ASTSurgeon()
        self.arbiter = ConflictArbiter()
        self.generator = ZeroFluffGenerator(self.output_dir)
        self.rig = ValidationRig(use_docker=False)

        # Optional integration points — injected by caller, or auto-discovered
        # below if this runs inside a full SPEARHEAD deployment.
        self.genome_manager = genome_manager or self._try_load_genome_manager()
        self.hive_bridge = hive_bridge or self._try_load_hive_bridge()

    def _try_load_genome_manager(self):
        try:
            from genome_manager import get_genome_engine
            return get_genome_engine()
        except Exception:
            return None

    def _try_load_hive_bridge(self):
        try:
            import zeus_hive_bridge
            if hasattr(zeus_hive_bridge, "get_hive_memory"):
                return zeus_hive_bridge.get_hive_memory()
        except Exception:
            pass
        return None

    def _publish_event(self, stream: str, event: dict):
        if not self.hive_bridge:
            return
        try:
            self.hive_bridge.publish_event(stream, event)
        except Exception as e:
            log.debug(f"[orchestrator] hive_bridge publish failed (non-fatal): {e}")

    def _register_genome(self, skill_name: str, skill, result: TestResult):
        if not self.genome_manager or not result.passed:
            return
        try:
            self.genome_manager.add(
                name=f"skill_{skill_name}",
                description=skill.description,
                module_type="generated_skill",
                source_code=skill.body,
                capabilities=",".join(skill.parameters.keys()) or "general",
                priority=80,
            )
            log.info(f"[orchestrator] Registered '{skill_name}' as new genome (DNA)")
        except Exception as e:
            log.debug(f"[orchestrator] genome registration failed (non-fatal): {e}")

    def run(self, archive_path: str) -> List[TestResult]:
        started_at = datetime.now(timezone.utc).isoformat()
        log.info(f"[orchestrator] Unpacking {archive_path}...")

        try:
            src_dir = unpack_archive(Path(archive_path))
        except UnsafeArchiveError as e:
            log.error(f"[orchestrator] Refusing unsafe archive: {e}")
            self._publish_event("skill_factory_stream", {
                "type": "archive_rejected", "reason": str(e), "timestamp": started_at
            })
            return [TestResult(passed=False, errors=[str(e)], skill_name="ARCHIVE")]

        log.info("[orchestrator] Scanning with Heuristic Engine...")
        text_corpus = ""
        for f in src_dir.rglob("*"):
            if f.suffix in (".md", ".txt", ".rst"):
                try:
                    text_corpus += f.read_text(encoding="utf-8", errors="ignore") + "\n"
                except OSError:
                    pass

        candidates = self.heuristic.scan(text_corpus)
        # FIX: also mine code-file docstrings so real-code-only archives
        # (the common case) still produce candidates.
        candidates += self.heuristic.scan_code_docstrings(src_dir)

        log.info("[orchestrator] Extracting with AST Surgeon...")
        raw_skills = self.surgeon.extract_skills(src_dir)

        log.info(f"[orchestrator] {len(candidates)} candidates, {len(raw_skills)} raw skills. Merging...")
        merged_skills = self.arbiter.merge(candidates, raw_skills)

        results = []
        for skill in merged_skills:
            log.info(f"[orchestrator] Generating and validating '{skill.name}'...")
            try:
                module_path = self.generator.emit(skill)
            except SkillGenerationError as e:
                # FIX: previously this ValueError propagated up and killed
                # the entire run. Now it's recorded and the run continues.
                log.warning(f"[orchestrator] Skipped '{skill.name}': {e}")
                result = TestResult(passed=False, errors=[str(e)], skill_name=skill.name)
                results.append(result)
                self._publish_event("skill_factory_stream", {
                    "type": "skill_generation_skipped",
                    "skill": skill.name, "reason": str(e),
                })
                continue
            except Exception as e:
                log.error(f"[orchestrator] Unexpected error generating '{skill.name}': {e}")
                results.append(TestResult(passed=False, errors=[f"generation_error: {e}"], skill_name=skill.name))
                continue

            result = self.rig.validate(module_path.parent)
            results.append(result)

            if result.passed:
                log.info(f"[orchestrator] PASSED '{skill.name}' (coverage: {result.coverage}%)")
                self._register_genome(skill.name, skill, result)
            else:
                log.warning(f"[orchestrator] FAILED '{skill.name}': {result.errors}")

            self._publish_event("skill_factory_stream", {
                "type": "skill_validated",
                "skill": skill.name,
                "passed": result.passed,
                "coverage": result.coverage,
            })

        summary = {
            "type": "skill_factory_run_complete",
            "started_at": started_at,
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "total_skills": len(results),
            "passed": sum(1 for r in results if r.passed),
            "failed": sum(1 for r in results if not r.passed),
        }
        self._publish_event("skill_factory_stream", summary)
        log.info(f"[orchestrator] Run complete: {summary['passed']}/{summary['total_skills']} skills passed")

        return results
