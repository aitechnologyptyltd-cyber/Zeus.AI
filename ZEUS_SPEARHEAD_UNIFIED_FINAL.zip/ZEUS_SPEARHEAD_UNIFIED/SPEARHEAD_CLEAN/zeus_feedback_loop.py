# zeus_feedback_loop.py
# The Zeus Project 2026 — Francois Nel
# FEEDBACK LOOP COORDINATOR
# Collects test results, refactoring outcomes, and performance metrics
# Feeds intelligence back to the Hive Mind for autonomous improvement

import os
import json
import time
import sqlite3
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from pathlib import Path
import logging

log = logging.getLogger("zeus.feedback")

class FeedbackLoopCoordinator:
    """
    Centralizes all system health data: test results, refactoring outcomes,
    performance metrics, and failure patterns.
    
    This is the NERVE CENTER that feeds intelligence to the Hive Mind.
    """
    
    def __init__(self, db_path: str = "zeus_feedback.db"):
        self.db_path = db_path
        self._init_db()
        self.hive_mind = None  # Will be injected by HiveMindCoordinator
    
    def _init_db(self):
        """Initialize feedback database with all tracking tables."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        # Test results tracking
        c.execute("""
            CREATE TABLE IF NOT EXISTS test_runs (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                test_file TEXT,
                test_name TEXT,
                status TEXT,
                duration_ms REAL,
                error_message TEXT,
                stack_trace TEXT,
                module_affected TEXT
            )
        """)
        
        # Refactoring outcomes
        c.execute("""
            CREATE TABLE IF NOT EXISTS refactor_attempts (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                source_file TEXT,
                refactor_type TEXT,
                change_description TEXT,
                before_metrics JSON,
                after_metrics JSON,
                tests_passed BOOLEAN,
                rollback_count INTEGER,
                impact_score REAL
            )
        """)
        
        # Performance metrics per module
        c.execute("""
            CREATE TABLE IF NOT EXISTS module_performance (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                module_name TEXT,
                response_time_ms REAL,
                memory_mb REAL,
                error_count INTEGER,
                success_count INTEGER,
                health_status TEXT
            )
        """)
        
        # Failure patterns (for gap detection)
        c.execute("""
            CREATE TABLE IF NOT EXISTS failure_patterns (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                pattern_type TEXT,
                description TEXT,
                occurrences INTEGER,
                last_seen TEXT,
                gap_identified TEXT,
                severity TEXT
            )
        """)
        
        # Gap registry (what's missing)
        c.execute("""
            CREATE TABLE IF NOT EXISTS detected_gaps (
                id INTEGER PRIMARY KEY,
                timestamp_detected TEXT,
                gap_type TEXT,
                description TEXT,
                affected_modules TEXT,
                priority TEXT,
                auto_fill_attempted BOOLEAN,
                auto_fill_success BOOLEAN,
                suggested_solution TEXT
            )
        """)
        
        # Autonomous improvements applied
        c.execute("""
            CREATE TABLE IF NOT EXISTS autonomous_improvements (
                id INTEGER PRIMARY KEY,
                timestamp_applied TEXT,
                improvement_type TEXT,
                description TEXT,
                code_generated TEXT,
                tests_passed BOOLEAN,
                performance_gain_percent REAL,
                hive_consensus_score REAL,
                rollback_required BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        log.info(f"[feedback_loop] Database initialized: {self.db_path}")
    
    # ===== TEST RESULT TRACKING =====
    
    def record_test_result(self, test_file: str, test_name: str, 
                          status: str, duration_ms: float, 
                          error_msg: str = "", stack_trace: str = "",
                          module_affected: str = "") -> Dict:
        """Record a test result in the feedback system."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        timestamp = datetime.now(datetime.timezone.utc).isoformat()
        
        c.execute("""
            INSERT INTO test_runs 
            (timestamp, test_file, test_name, status, duration_ms, 
             error_message, stack_trace, module_affected)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (timestamp, test_file, test_name, status, duration_ms,
              error_msg, stack_trace, module_affected))
        
        conn.commit()
        result_id = c.lastrowid
        conn.close()
        
        # If test failed, notify hive mind to investigate
        if status == "FAILED" and self.hive_mind:
            self.hive_mind.notify_failure(
                module=module_affected or test_name,
                error=error_msg,
                severity="HIGH" if "CRITICAL" in error_msg else "MEDIUM"
            )
        
        log.info(f"[feedback] Test recorded: {test_file}::{test_name} -> {status}")
        return {"recorded_id": result_id, "status": status}
    
    def get_test_summary(self, hours: int = 24) -> Dict:
        """Get test summary for the last N hours."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        cutoff_time = (datetime.now(datetime.timezone.utc) - 
                      timedelta(hours=hours)).isoformat()
        
        c.execute("""
            SELECT status, COUNT(*) as count, AVG(duration_ms) as avg_duration
            FROM test_runs
            WHERE timestamp > ?
            GROUP BY status
        """, (cutoff_time,))
        
        summary = {}
        for row in c.fetchall():
            status, count, avg_duration = row
            summary[status] = {"count": count, "avg_duration_ms": avg_duration}
        
        conn.close()
        return summary
    
    # ===== REFACTORING OUTCOME TRACKING =====
    
    def record_refactor_outcome(self, source_file: str, refactor_type: str,
                               change_desc: str, before_metrics: Dict,
                               after_metrics: Dict, tests_passed: bool,
                               rollback_count: int = 0) -> Dict:
        """Record the outcome of a refactoring attempt."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        timestamp = datetime.now(datetime.timezone.utc).isoformat()
        
        # Calculate impact score
        impact_score = self._calculate_impact_score(before_metrics, after_metrics)
        
        c.execute("""
            INSERT INTO refactor_attempts
            (timestamp, source_file, refactor_type, change_description,
             before_metrics, after_metrics, tests_passed, rollback_count, impact_score)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (timestamp, source_file, refactor_type, change_desc,
              json.dumps(before_metrics), json.dumps(after_metrics),
              tests_passed, rollback_count, impact_score))
        
        conn.commit()
        conn.close()
        
        log.info(f"[feedback] Refactor recorded: {source_file} "
                f"({refactor_type}) - Impact: {impact_score:.2f}")
        
        # Notify hive mind of successful improvements
        if tests_passed and impact_score > 0:
            if self.hive_mind:
                self.hive_mind.learn_improvement(
                    refactor_type=refactor_type,
                    impact_score=impact_score,
                    success=True
                )
        
        return {"impact_score": impact_score, "success": tests_passed}
    
    def _calculate_impact_score(self, before: Dict, after: Dict) -> float:
        """Calculate how much the refactoring improved the system."""
        score = 0.0
        
        # Code quality improvement
        if before.get("loc") and after.get("loc"):
            loc_reduction = (before["loc"] - after["loc"]) / before["loc"]
            score += loc_reduction * 0.3  # 30% weight
        
        # Complexity reduction
        if before.get("avg_function_length") and after.get("avg_function_length"):
            complexity_reduction = ((before["avg_function_length"] - 
                                    after["avg_function_length"]) / 
                                   before["avg_function_length"])
            score += complexity_reduction * 0.3  # 30% weight
        
        # Performance improvement
        if before.get("response_time_ms") and after.get("response_time_ms"):
            perf_gain = (before["response_time_ms"] - after["response_time_ms"]) / before["response_time_ms"]
            score += perf_gain * 0.4  # 40% weight
        
        return max(0, min(1, score))  # Normalize to 0-1
    
    # ===== PERFORMANCE MONITORING =====
    
    def record_module_performance(self, module_name: str, response_time_ms: float,
                                 memory_mb: float, error_count: int,
                                 success_count: int) -> Dict:
        """Record performance metrics for a module."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        timestamp = datetime.now(datetime.timezone.utc).isoformat()
        
        # Determine health status
        health_status = self._determine_health(response_time_ms, memory_mb,
                                              error_count, success_count)
        
        c.execute("""
            INSERT INTO module_performance
            (timestamp, module_name, response_time_ms, memory_mb, 
             error_count, success_count, health_status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (timestamp, module_name, response_time_ms, memory_mb,
              error_count, success_count, health_status))
        
        conn.commit()
        conn.close()
        
        # Alert if degradation
        if health_status == "UNHEALTHY":
            if self.hive_mind:
                self.hive_mind.notify_failure(
                    module=module_name,
                    error=f"Performance degradation: {response_time_ms}ms, {memory_mb}MB",
                    severity="HIGH"
                )
        
        return {"module": module_name, "health_status": health_status}
    
    def _determine_health(self, response_time_ms: float, memory_mb: float,
                         error_count: int, success_count: int) -> str:
        """Determine module health status."""
        if response_time_ms > 5000 or memory_mb > 1000:
            return "UNHEALTHY"
        if error_count > success_count * 0.1:  # >10% error rate
            return "DEGRADED"
        if response_time_ms > 1000 or memory_mb > 500:
            return "STRESSED"
        return "HEALTHY"
    
    # ===== FAILURE PATTERN DETECTION =====
    
    def detect_failure_pattern(self, pattern_type: str, description: str,
                             occurrences: int = 1, severity: str = "MEDIUM") -> Dict:
        """
        Detect a pattern in failures.
        This feeds into gap detection and autonomous improvements.
        """
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        timestamp = datetime.now(datetime.timezone.utc).isoformat()
        
        # Check if pattern already exists
        c.execute("""
            SELECT id, occurrences FROM failure_patterns
            WHERE pattern_type = ? AND description = ?
            ORDER BY timestamp DESC LIMIT 1
        """, (pattern_type, description))
        
        existing = c.fetchone()
        
        if existing:
            pattern_id = existing[0]
            new_count = existing[1] + occurrences
            c.execute("""
                UPDATE failure_patterns
                SET occurrences = ?, last_seen = ?
                WHERE id = ?
            """, (new_count, timestamp, pattern_id))
        else:
            c.execute("""
                INSERT INTO failure_patterns
                (timestamp, pattern_type, description, occurrences, last_seen, severity)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (timestamp, pattern_type, description, occurrences, timestamp, severity))
            pattern_id = c.lastrowid
        
        conn.commit()
        conn.close()
        
        log.warning(f"[feedback] Failure pattern detected: {pattern_type} - {description}")
        
        # Notify hive mind about pattern
        if self.hive_mind:
            self.hive_mind.analyze_pattern(pattern_type, description, occurrences)
        
        return {"pattern_id": pattern_id, "occurrences": occurrences}
    
    # ===== GAP DETECTION =====
    
    def detect_gap(self, gap_type: str, description: str, affected_modules: List[str],
                  priority: str = "MEDIUM") -> Dict:
        """
        Identify a gap in the system's capabilities.
        Gap can be: missing_feature, missing_handler, missing_integration, etc.
        """
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        timestamp = datetime.now(datetime.timezone.utc).isoformat()
        modules_str = ",".join(affected_modules)
        
        c.execute("""
            INSERT INTO detected_gaps
            (timestamp_detected, gap_type, description, affected_modules, priority,
             auto_fill_attempted, auto_fill_success)
            VALUES (?, ?, ?, ?, ?, 0, 0)
        """, (timestamp, gap_type, description, modules_str, priority))
        
        gap_id = c.lastrowid
        conn.commit()
        conn.close()
        
        log.warning(f"[feedback] Gap detected: {gap_type} ({priority}) - {description}")
        
        # Notify hive mind to fill the gap
        if self.hive_mind:
            self.hive_mind.detect_gap(gap_type, description, affected_modules, priority)
        
        return {"gap_id": gap_id, "status": "detected"}
    
    # ===== AUTONOMOUS IMPROVEMENT LOGGING =====
    
    def record_autonomous_improvement(self, improvement_type: str, description: str,
                                     code_generated: str, tests_passed: bool,
                                     performance_gain_percent: float = 0.0,
                                     hive_consensus_score: float = 1.0) -> Dict:
        """Record an autonomous improvement that was applied by the system."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        timestamp = datetime.now(datetime.timezone.utc).isoformat()
        
        c.execute("""
            INSERT INTO autonomous_improvements
            (timestamp_applied, improvement_type, description, code_generated,
             tests_passed, performance_gain_percent, hive_consensus_score,
             rollback_required)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0)
        """, (timestamp, improvement_type, description, code_generated,
              tests_passed, performance_gain_percent, hive_consensus_score))
        
        conn.commit()
        improvement_id = c.lastrowid
        conn.close()
        
        log.info(f"[feedback] Autonomous improvement recorded: {improvement_type} "
                f"(consensus: {hive_consensus_score:.2f}, gain: {performance_gain_percent:.1f}%)")
        
        return {
            "improvement_id": improvement_id,
            "applied": tests_passed,
            "performance_gain": performance_gain_percent
        }
    
    # ===== LEARNING & ANALYTICS =====
    
    def get_system_health_report(self, hours: int = 24) -> Dict:
        """Generate a comprehensive health report for the system."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        cutoff_time = (datetime.now(datetime.timezone.utc) - 
                      timedelta(hours=hours)).isoformat()
        
        # Get test stats
        c.execute("""
            SELECT status, COUNT(*) FROM test_runs
            WHERE timestamp > ? GROUP BY status
        """, (cutoff_time,))
        test_stats = dict(c.fetchall())
        
        # Get refactor success rate
        c.execute("""
            SELECT COUNT(*) as total, SUM(CASE WHEN tests_passed THEN 1 ELSE 0 END) as passed
            FROM refactor_attempts WHERE timestamp > ?
        """, (cutoff_time,))
        refactor_stats = c.fetchone()
        
        # Get detected gaps
        c.execute("""
            SELECT COUNT(*), SUM(CASE WHEN auto_fill_success THEN 1 ELSE 0 END)
            FROM detected_gaps WHERE timestamp_detected > ?
        """, (cutoff_time,))
        gap_stats = c.fetchone()
        
        # Get module health
        c.execute("""
            SELECT module_name, health_status, COUNT(*) as count
            FROM module_performance
            WHERE timestamp > ?
            GROUP BY module_name, health_status
        """, (cutoff_time,))
        module_health = {}
        for row in c.fetchall():
            module, status, count = row
            if module not in module_health:
                module_health[module] = {}
            module_health[module][status] = count
        
        conn.close()
        
        return {
            "period_hours": hours,
            "test_results": test_stats,
            "refactoring": {
                "total_attempts": refactor_stats[0] if refactor_stats[0] else 0,
                "successful": refactor_stats[1] if refactor_stats[1] else 0,
                "success_rate": (refactor_stats[1] / refactor_stats[0] * 100 
                               if refactor_stats[0] else 0)
            },
            "gaps": {
                "detected": gap_stats[0] if gap_stats[0] else 0,
                "auto_filled": gap_stats[1] if gap_stats[1] else 0
            },
            "module_health": module_health
        }
    
    def get_improvement_suggestions(self) -> List[Dict]:
        """Get suggestions for autonomous improvements based on detected patterns."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        suggestions = []
        
        # Suggest refactoring for large files
        c.execute("""
            SELECT DISTINCT module_affected FROM test_runs
            WHERE status = 'FAILED'
            GROUP BY module_affected HAVING COUNT(*) > 5
        """)
        for row in c.fetchall():
            module = row[0]
            suggestions.append({
                "type": "refactor_large_module",
                "module": module,
                "reason": "Multiple test failures suggest complexity"
            })
        
        # Suggest adding handlers for missing patterns
        c.execute("""
            SELECT gap_type, COUNT(*) as count FROM detected_gaps
            WHERE auto_fill_success = 0
            GROUP BY gap_type HAVING count > 2
        """)
        for row in c.fetchall():
            gap_type, count = row
            suggestions.append({
                "type": "add_missing_handler",
                "gap_type": gap_type,
                "occurrences": count,
                "reason": f"Pattern detected {count} times"
            })
        
        conn.close()
        return suggestions


# Export
def get_feedback_coordinator() -> FeedbackLoopCoordinator:
    """Get or create the feedback loop coordinator."""
    if not hasattr(get_feedback_coordinator, '_instance'):
        get_feedback_coordinator._instance = FeedbackLoopCoordinator()
    return get_feedback_coordinator._instance
