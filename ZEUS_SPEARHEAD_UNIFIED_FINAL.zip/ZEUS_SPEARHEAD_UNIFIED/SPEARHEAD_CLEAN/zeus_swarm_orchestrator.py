# The Zeus Project 2026 — Francois Nel
# zeus_swarm_orchestrator.py — Zeus Swarm: Agent Registry + Routing + Health
# ============================================================================
# Sits ON TOP of app.py's flat blueprint registration. Does not replace it.
# Groups existing modules into 13 named agents (ownership groups), routes
# tasks to the agent that owns the target module, gates genome/sovereignty
# actions through Aegis, and aggregates per-domain health instead of only
# per-module health (full_system_check.py already does per-module).
#
# Optional-injection pattern, same as zeus_immune_system / zeus_skill_factory:
# auto-detects db_init, zeus_sovereignty_engine, zeus_identity if importable,
# degrades gracefully to standalone mode if not.
#
# Registered via register(app) — mounts at url_prefix="/api/swarm" — same
# convention as logic_engine.py. Add ONE line to app.py:
#     _loaded += _register_fn("zeus_swarm_orchestrator")
# ============================================================================

import os
import sys
import time
import json
import logging
import threading
import importlib
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.swarm")

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))          # SPEARHEAD_CLEAN
UNIFIED_ROOT = os.path.dirname(ZEUS_DIR)                        # one level up

swarm_bp = Blueprint("swarm", __name__)

# ----------------------------------------------------------------------- #
# PATH BOOTSTRAP                                                            #
# ----------------------------------------------------------------------- #
# Verified against the actual tree, not assumed:
#   - zeus_firewall/*.py are imported FLAT by your existing code
#     (wsgi_zeus.py, zeus_hive_bridge.py both do
#     `from zeus_firewall_v1 import ZeusFirewall`) because wsgi_zeus.py does
#     sys.path.insert(0, ZEUS_FW_DIR). We replicate that here so this module
#     resolves the same names correctly even when loaded outside wsgi_zeus.py
#     (e.g. a standalone health-check script).
#   - aegis_field/ has __init__.py and IS used as a real dotted package
#     elsewhere (zeus_govint_blueprint.py: `from aegis_field.aegis_master
#     import AegisFieldEngine`) — left as dotted, confirmed correct.
#   - zeus_immune_system/ and zeus_skill_factory/ currently live as SIBLINGS
#     of SPEARHEAD_CLEAN/, not inside it. Their own docs (INTEGRATION_GUIDE.md,
#     zeus_skill_factory_bridge.py's `from src.orchestrator import
#     Orchestrator`) both assume their contents get COPIED FLAT into
#     SPEARHEAD_CLEAN/ as a deployment step. Until that copy happens, we add
#     their legacy sibling locations to sys.path as a fallback so health
#     checks still resolve — but we tag that state distinctly (see
#     PENDING_COPY below) rather than reporting it as fully healthy.
PENDING_COPY_NOTES: Dict[str, str] = {}


def _bootstrap_paths() -> None:
    fw_dir = os.path.join(ZEUS_DIR, "zeus_firewall")
    if os.path.isdir(fw_dir) and fw_dir not in sys.path:
        sys.path.insert(0, fw_dir)

    if ZEUS_DIR not in sys.path:
        sys.path.insert(0, ZEUS_DIR)

    # Legacy fallback: zeus_immune_system/ siblings not yet copied flat
    immune_src = os.path.join(UNIFIED_ROOT, "zeus_immune_system")
    if os.path.isdir(immune_src):
        already_copied = os.path.isfile(os.path.join(ZEUS_DIR, "zeus_feedback_loop.py"))
        if not already_copied and immune_src not in sys.path:
            sys.path.insert(0, immune_src)
            PENDING_COPY_NOTES["asclepius"] = (
                f"zeus_immune_system/*.py not yet copied into SPEARHEAD_CLEAN/. "
                f"Resolving from legacy location: {immune_src}. "
                f"Run zeus_swarm_deps_sync.sh to copy it in properly."
            )

    # Legacy fallback: zeus_skill_factory/src not yet copied to SPEARHEAD_CLEAN/skill_factory_src
    skill_factory_dir = os.path.join(UNIFIED_ROOT, "zeus_skill_factory")
    if os.path.isdir(skill_factory_dir):
        already_copied = os.path.isdir(os.path.join(ZEUS_DIR, "skill_factory_src"))
        if not already_copied and skill_factory_dir not in sys.path:
            sys.path.insert(0, skill_factory_dir)
            PENDING_COPY_NOTES["daedalus"] = (
                f"zeus_skill_factory/src not yet copied into "
                f"SPEARHEAD_CLEAN/skill_factory_src. Resolving from legacy "
                f"location: {skill_factory_dir} (note: that legacy location "
                f"still uses the bare 'src' package name — only the copied-in "
                f"version at SPEARHEAD_CLEAN/skill_factory_src has the "
                f"collision-safe rename). Run zeus_swarm_deps_sync.sh to "
                f"copy it in properly."
            )


_bootstrap_paths()

# ----------------------------------------------------------------------- #
# OPTIONAL SUBSTRATE — degrade gracefully if a piece isn't importable       #
# ----------------------------------------------------------------------- #

try:
    from db_init import get_db
    _HAS_DB = True
except ImportError as e:
    _HAS_DB = False
    log.warning(f"[swarm] db_init not available, dispatch log disabled: {e}")

try:
    from zeus_sovereignty_engine import sovereign_execute as _sov_exec
    _HAS_SOVEREIGNTY = True
except ImportError:
    _HAS_SOVEREIGNTY = False
    def _sov_exec(action_type, description, payload, callback=None):
        return {"status": "executed", "result": {}, "note": "sovereignty engine not present — unguarded"}

try:
    from zeus_identity import get_identity  # module capability registry
    _HAS_IDENTITY = True
except ImportError:
    _HAS_IDENTITY = False
    def get_identity():
        return {"instance": "unknown", "note": "zeus_identity not present"}

# Actions that MUST route through Aegis (Ring-1 gate) regardless of which
# agent originated the request. Mirrors genome_manager.py's existing pattern
# of routing propose_genome_upgrade() through sovereign_execute().
GATED_ACTION_KEYWORDS = (
    "genome_write", "genome_upgrade", "mutate", "self_evolution",
    "replicate", "sovereignty", "apk_export", "geo_auth",
)


# ============================================================================
# AGENT REGISTRY
# ============================================================================
# One entry per agent. `modules` are the module names this agent owns
# EXCLUSIVELY — no other agent should claim a module that appears here.
# `layer` mirrors the LAYER 0-5 comments already in app.py, for traceability.

@dataclass
class AgentDef:
    name: str
    layer: str
    description: str
    modules: List[str] = field(default_factory=list)


AGENT_REGISTRY: Dict[str, AgentDef] = {

    "hermes": AgentDef(
        name="hermes", layer="0-CORE",
        description="Dispatcher. Every task enters through Hermes; routes to the owning agent.",
        # NOTE: "app" is deliberately excluded from the import-health list.
        # app.py runs its full _register()/_register_fn() sequence at
        # module level (not inside if __name__ == "__main__"), so
        # importlib.import_module("app") actually boots the live Flask
        # stack — DB init, all 42 blueprints, background threads (sys_aware
        # daemon, sovereignty engine, PEL auto-start) — as a side effect of
        # what's supposed to be a read-only health check. Confirmed by
        # direct test. Tracked as file-existence only, same treatment as
        # Asclepius's test files.
        modules=[
            "zeus_blueprints", "zeus_council_router",
            "zeus_intelligent_router", "zeus_llm_router", "zeus_executor",
            "zeus_identity",
        ],
    ),
    "prometheus": AgentDef(
        name="prometheus", layer="1-2-DATA_EVOLUTION",
        description="Self-evolution: mutates, scores, and grows the genome.",
        modules=[
            "zeus_code_learner", "zeus_learner", "zeus_recursive_learner",
            "zeus_self_evolution", "zeus_mutator", "zeus_improvement_loop",
            "genome_manager", "logic_engine", "zeus_forge", "zeus_synthesis",
        ],
    ),
    "aegis": AgentDef(
        name="aegis", layer="CROSS-CUTTING",
        description="Security gate. Ring-1 authorization for genome/sovereignty actions.",
        modules=[
            # aegis_field/ has __init__.py and IS used dotted elsewhere
            # (zeus_govint_blueprint.py) — confirmed correct as-is.
            "aegis_field.aegis_master", "aegis_field.aegis_detect",
            "aegis_field.aegis_forensic", "aegis_field.aegis_response",
            "aegis_field.aegis_trust",
            # zeus_firewall/*.py are imported FLAT in real code
            # (wsgi_zeus.py, zeus_hive_bridge.py: `from zeus_firewall_v1
            # import ZeusFirewall`) because wsgi_zeus.py puts the
            # zeus_firewall/ dir itself on sys.path. Corrected from an
            # earlier dotted assumption that happened to also work via
            # Python 3 namespace-package fallback, but wasn't the real
            # convention and isn't guaranteed robust outside wsgi_zeus.py.
            "zeus_aegis_engine", "zeus_firewall_v1",
            "zeus_sovereignty_engine", "zeus_sovereignty_crosswire", "zeus_sandbox",
        ],
    ),
    "argus": AgentDef(
        name="argus", layer="1-SPECIALIZED",
        description="GovInt / geo-intelligence domain.",
        modules=[
            "zeus_geo_intel", "zeus_geo_auth", "zeus_geo_cluster",
            "zeus_geo_signing_tool", "zeus_geo_vision", "zeus_govint_blueprint",
        ],
    ),
    "icarus": AgentDef(
        name="icarus", layer="4-SPECIALIZED",
        description="Drone telemetry, vision, command, geofencing.",
        modules=[
            "zeus_drone_blueprint", "zeus_drone_command_bridge",
            "zeus_drone_coverage", "zeus_drone_geofence_monitor",
            "zeus_drone_hive_wire", "zeus_drone_telemetry", "zeus_drone_vision",
        ],
    ),
    "tartarus": AgentDef(
        name="tartarus", layer="1-DATA",
        description="Sensing + prediction subsystem.",
        modules=[
            "zeus_tartarus_connect", "zeus_tartarus_core", "zeus_tartarus_learner",
            "zeus_tartarus_monitor", "zeus_tartarus_omnisense", "zeus_tartarus_predict",
            "zeus_tartarus_sense", "zeus_tartarus_upload", "zeus_tartarus_weights",
            "zeus_prediction_engine",
        ],
    ),
    "iris": AgentDef(
        name="iris", layer="0-CORE",
        description="External LLM bridges — messenger to outside models.",
        modules=["zeus_deepseek_bridge", "zeus_grok_bridge", "zeus_perplexity_bridge"],
    ),
    "hephaestus": AgentDef(
        name="hephaestus", layer="4-SPECIALIZED",
        description="Builds/exports physical artifacts (APKs).",
        modules=["zeus_apk_builder_core", "zeus_apk_engine", "zeus_apk_export"],
    ),
    "mnemosyne": AgentDef(
        name="mnemosyne", layer="4-5-SPECIALIZED_PRESENTATION",
        description="Persistence, replication, hive memory, scheduled cycles.",
        modules=[
            "zeus_hive_bridge", "zeus_replication_engine", "zeus_stress_engine",
            "zeus_nightly_scheduler", "zeus_auto_register",
        ],
    ),
    "atlas": AgentDef(
        name="atlas", layer="1-DATA",
        description="Infra load-bearing: DB, uploads, search, system awareness.",
        modules=["zeus_upload", "zeus_search", "zeus_sys_aware", "db_init", "full_system_check"],
    ),
    "hestia": AgentDef(
        name="hestia", layer="5-PRESENTATION",
        description="User-facing hearth — chat + dashboard.",
        modules=["zeus_chat", "zeus_learning_dashboard"],
    ),
    "asclepius": AgentDef(
        name="asclepius", layer="IMMUNE_SYSTEM",
        description="Self-healing QA — the immune system.",
        modules=[
            # zeus_immune_system/*.py are currently siblings of
            # SPEARHEAD_CLEAN/, not inside it. Their own INTEGRATION_GUIDE.md
            # says to copy these three files FLAT into SPEARHEAD_CLEAN/ root
            # (its QUICKSTART.sh references a "components/" subfolder that
            # does not exist in the delivered zip — that script is broken;
            # see zeus_swarm_deps_sync.sh for a corrected copy step).
            # Named flat here to match the post-copy, real deployment state;
            # _bootstrap_paths() falls back to the legacy sibling location
            # if the copy hasn't happened yet.
            "zeus_feedback_loop", "zeus_refactoring_engine", "zeus_test_feedback_bridge",
        ],
        # Test files are intentionally NOT health-checked via import_module —
        # conftest.py wires pytest fixtures (DB setup, etc.) and importing it
        # outside a pytest run risks side effects. Tracked as file-existence
        # only (see ASCLEPIUS_TEST_FILES below), not import-health.
    ),
    "daedalus": AgentDef(
        name="daedalus", layer="SKILL_FACTORY",
        description="Builds new skills/tools on demand.",
        modules=[
            # Renamed from bare 'src' to 'skill_factory_src' during the
            # SPEARHEAD_CLEAN integration to remove the collision risk
            # flagged earlier — a generic 'src' package is fragile once
            # merged into a 60+ module flat directory. The one import line
            # in zeus_skill_factory_bridge.py was updated to match.
            "skill_factory_src.orchestrator", "skill_factory_src.generator",
            "skill_factory_src.heuristic_engine", "skill_factory_src.ast_surgeon",
            "skill_factory_src.conflict_arbiter", "skill_factory_src.validation_rig",
            "zeus_skill_factory_bridge",
        ],
    ),

    # NEW — added on top of the original 13 agents, nothing above this line
    # was changed to add it. Hecate (crossroads/threshold goddess) owns the
    # gateway to ClickUp's external task system, mirroring the same
    # register(app)/Blueprint/circuit-breaker pattern as Iris's LLM bridges.
    "hecate": AgentDef(
        name="hecate", layer="EXTERNAL_GATEWAY",
        description="Gateway to ClickUp — tasks, comments, lists via the real ClickUp REST API.",
        modules=["zeus_clickup_bridge"],
    ),
}

# Tracked separately from import-health for the reason noted above.
ASCLEPIUS_TEST_FILES = [
    "tests/conftest.py", "tests/test_health_routes.py",
    "tests/test_genome_manager.py", "tests/test_sandbox.py",
]

# app.py is tracked by file-existence only — see the NOTE on Hermes above.
HERMES_ENTRYPOINT_FILE = "app.py"

# Reverse map: module name -> owning agent. Built once at import time.
# If two agents ever claim the same module, this raises immediately at
# import — that's intentional; ownership collisions should fail loud, not
# silently pick a winner.
MODULE_TO_AGENT: Dict[str, str] = {}
for _agent_name, _agent_def in AGENT_REGISTRY.items():
    for _mod in _agent_def.modules:
        if _mod in MODULE_TO_AGENT:
            raise RuntimeError(
                f"[swarm] ownership collision: '{_mod}' claimed by both "
                f"'{MODULE_TO_AGENT[_mod]}' and '{_agent_name}'"
            )
        MODULE_TO_AGENT[_mod] = _agent_name


# ============================================================================
# HEALTH — per-agent aggregation over per-module importability
# ============================================================================

_health_lock = threading.RLock()
_health_cache: Dict[str, Any] = {}
_health_last_scan: Optional[str] = None


def _check_module_importable(module_name: str) -> bool:
    try:
        importlib.import_module(module_name)
        return True
    except Exception as e:
        log.debug(f"[swarm] {module_name} not importable: {e}")
        return False


def _check_test_files_exist() -> Dict[str, bool]:
    """
    File-existence check only, deliberately not import-based — see the
    comment on ASCLEPIUS_TEST_FILES for why importing conftest.py outside
    a pytest run is avoided.
    """
    result = {}
    for rel_path in ASCLEPIUS_TEST_FILES:
        result[rel_path] = os.path.isfile(os.path.join(ZEUS_DIR, rel_path))
    return result


def scan_health() -> Dict[str, Any]:
    """
    Import-check every module in every agent's manifest. Aggregates to
    agent-level status:
      healthy       — all modules import cleanly from their final,
                      post-deployment location
      pending_copy  — modules import successfully, but only via the
                      legacy sibling-directory fallback added in
                      _bootstrap_paths() (i.e. the copy step from
                      zeus_immune_system/ or zeus_skill_factory/ into
                      SPEARHEAD_CLEAN/ hasn't happened yet)
      degraded      — some modules import, some don't
      dark          — none import
    Never raises — mirrors _register()'s never-crash contract.
    """
    global _health_last_scan
    result: Dict[str, Any] = {}
    for agent_name, agent_def in AGENT_REGISTRY.items():
        module_status = {}
        for mod in agent_def.modules:
            module_status[mod] = _check_module_importable(mod)
        ok_count = sum(1 for v in module_status.values() if v)
        total = len(module_status)
        if total == 0:
            status = "empty"
        elif ok_count == total:
            status = "pending_copy" if agent_name in PENDING_COPY_NOTES else "healthy"
        elif ok_count == 0:
            status = "dark"
        else:
            status = "degraded"
        entry = {
            "status": status,
            "modules_ok": ok_count,
            "modules_total": total,
            "modules": module_status,
            "description": agent_def.description,
            "layer": agent_def.layer,
        }
        if agent_name in PENDING_COPY_NOTES:
            entry["pending_copy_note"] = PENDING_COPY_NOTES[agent_name]
        if agent_name == "asclepius":
            entry["test_files"] = _check_test_files_exist()
        if agent_name == "hermes":
            entry["entrypoint_file_exists"] = os.path.isfile(
                os.path.join(ZEUS_DIR, HERMES_ENTRYPOINT_FILE))
        result[agent_name] = entry
    with _health_lock:
        _health_cache.clear()
        _health_cache.update(result)
        _health_last_scan = datetime.now(timezone.utc).isoformat()
    return result


def get_cached_health() -> Dict[str, Any]:
    with _health_lock:
        if not _health_cache:
            return scan_health()
        return dict(_health_cache)


def _background_health_scan(delay_seconds: float = 3.0) -> None:
    """Auto-runs shortly after boot, same pattern as the PEL auto-start
    in zeus_self_evolution.py."""
    def _run():
        time.sleep(delay_seconds)
        try:
            scan_health()
            log.info("[swarm] initial health scan complete")
        except Exception as e:
            log.error(f"[swarm] initial health scan failed: {e}")
    threading.Thread(target=_run, daemon=True).start()


# ============================================================================
# DISPATCH LOG — additive SQLite table, does not touch existing schema
# ============================================================================

def _ensure_dispatch_table() -> None:
    if not _HAS_DB:
        return
    try:
        conn = get_db()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS swarm_dispatch_log (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                ts            TEXT NOT NULL,
                agent         TEXT NOT NULL,
                module        TEXT,
                keyword       TEXT,
                task          TEXT,
                gated         INTEGER NOT NULL DEFAULT 0,
                gate_result   TEXT,
                caller        TEXT
            )
        """)
        conn.commit()
        conn.close()
    except Exception as e:
        log.error(f"[swarm] failed to create swarm_dispatch_log: {e}")


def _log_dispatch(agent: str, module: Optional[str], keyword: Optional[str],
                   task: str, gated: bool, gate_result: Optional[dict],
                   caller: str) -> None:
    if not _HAS_DB:
        return
    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO swarm_dispatch_log "
            "(ts, agent, module, keyword, task, gated, gate_result, caller) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                datetime.now(timezone.utc).isoformat(), agent, module, keyword,
                task, int(gated), json.dumps(gate_result) if gate_result else None,
                caller,
            ),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.error(f"[swarm] failed to log dispatch: {e}")


# ============================================================================
# ROUTING
# ============================================================================

def route_by_module(module_name: str) -> Optional[str]:
    """Exact-match routing: which agent owns this module name."""
    return MODULE_TO_AGENT.get(module_name)


def route_by_keyword(keyword: str) -> List[str]:
    """
    Fuzzy routing for when the caller doesn't know the exact module name —
    e.g. 'drone' -> ['icarus'], 'geo' -> ['argus'], 'genome' -> ['prometheus'].
    Matches against module names and agent descriptions. Returns all agents
    that match, ranked by number of matching modules (best match first).
    """
    keyword = keyword.lower().strip()
    hits: Dict[str, int] = {}
    for agent_name, agent_def in AGENT_REGISTRY.items():
        score = 0
        if keyword in agent_def.description.lower():
            score += 1
        for mod in agent_def.modules:
            if keyword in mod.lower():
                score += 2
        if score > 0:
            hits[agent_name] = score
    return [a for a, _ in sorted(hits.items(), key=lambda x: -x[1])]


def is_gated_action(task_description: str) -> bool:
    task_lower = task_description.lower()
    return any(kw in task_lower for kw in GATED_ACTION_KEYWORDS)


def dispatch(module: Optional[str] = None, keyword: Optional[str] = None,
             task: str = "", caller: str = "unspecified") -> Dict[str, Any]:
    """
    Core dispatch function. Resolves owning agent, checks health, gates
    through Aegis if the task touches genome/sovereignty/replication/APK
    export/geo-auth, logs the dispatch, returns a decision record.

    This function does NOT execute arbitrary code — it resolves ownership,
    enforces the security gate, and logs intent. Actually invoking a
    module's functionality remains each module's own blueprint route,
    called directly by the caller once dispatch confirms which agent/module
    is authoritative for the task.
    """
    agent_name = None
    if module:
        agent_name = route_by_module(module)
        if agent_name is None:
            return {"error": f"module '{module}' is not owned by any registered agent",
                    "known_modules": sorted(MODULE_TO_AGENT.keys())}
    elif keyword:
        matches = route_by_keyword(keyword)
        if not matches:
            return {"error": f"no agent matches keyword '{keyword}'"}
        agent_name = matches[0]
    else:
        return {"error": "must provide either 'module' or 'keyword'"}

    health = get_cached_health().get(agent_name, {})
    if health.get("status") in ("dark",):
        return {
            "error": "agent_degraded", "agent": agent_name,
            "detail": f"{agent_name} has no importable modules — refusing dispatch",
            "health": health,
        }

    gated = is_gated_action(task or keyword or module or "")
    gate_result = None
    if gated:
        gate_result = _sov_exec(
            "swarm_dispatch",
            f"[{agent_name}] {task or module or keyword}",
            {"agent": agent_name, "module": module, "task": task},
        )

    _log_dispatch(agent_name, module, keyword, task, gated, gate_result, caller)

    return {
        "agent": agent_name,
        "module": module,
        "keyword": keyword,
        "task": task,
        "agent_status": health.get("status", "unknown"),
        "gated": gated,
        "gate_result": gate_result,
        "dispatched_at": datetime.now(timezone.utc).isoformat(),
    }


# ============================================================================
# FLASK ROUTES — mounted at url_prefix="/api/swarm" via register(app)
# ============================================================================

@swarm_bp.route("/health", methods=["GET"])
def http_health():
    return jsonify({
        "last_scan": _health_last_scan,
        "agents": get_cached_health(),
        "has_db": _HAS_DB,
        "has_sovereignty_gate": _HAS_SOVEREIGNTY,
    })


@swarm_bp.route("/health/rescan", methods=["POST"])
def http_health_rescan():
    return jsonify({"last_scan": None, "agents": scan_health()})


@swarm_bp.route("/agents", methods=["GET"])
def http_agents():
    return jsonify({
        name: {**asdict(defn), "module_count": len(defn.modules)}
        for name, defn in AGENT_REGISTRY.items()
    })


@swarm_bp.route("/agents/<agent_name>", methods=["GET"])
def http_agent_detail(agent_name):
    agent_name = agent_name.lower()
    if agent_name not in AGENT_REGISTRY:
        return jsonify({"error": f"unknown agent '{agent_name}'",
                        "known_agents": sorted(AGENT_REGISTRY.keys())}), 404
    defn = AGENT_REGISTRY[agent_name]
    health = get_cached_health().get(agent_name, {})
    return jsonify({**asdict(defn), "health": health})


@swarm_bp.route("/route", methods=["POST"])
def http_route():
    body = request.get_json(force=True, silent=True) or {}
    module = body.get("module")
    keyword = body.get("keyword")
    if module:
        agent_name = route_by_module(module)
        if not agent_name:
            return jsonify({"error": f"module '{module}' not owned by any agent"}), 404
        return jsonify({"module": module, "agent": agent_name,
                         "health": get_cached_health().get(agent_name, {})})
    if keyword:
        matches = route_by_keyword(keyword)
        return jsonify({"keyword": keyword, "matches": matches,
                         "best_match": matches[0] if matches else None})
    return jsonify({"error": "provide 'module' or 'keyword' in request body"}), 400


@swarm_bp.route("/dispatch", methods=["POST"])
def http_dispatch():
    body = request.get_json(force=True, silent=True) or {}
    result = dispatch(
        module=body.get("module"),
        keyword=body.get("keyword"),
        task=body.get("task", ""),
        caller=body.get("caller", request.remote_addr or "unspecified"),
    )
    status_code = 200 if "error" not in result else 400
    return jsonify(result), status_code


@swarm_bp.route("/log", methods=["GET"])
def http_log():
    if not _HAS_DB:
        return jsonify({"error": "db_init not available — dispatch log disabled"}), 503
    limit = min(int(request.args.get("limit", 50)), 500)
    try:
        conn = get_db()
        rows = conn.execute(
            "SELECT * FROM swarm_dispatch_log ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        return jsonify({"entries": [dict(r) for r in rows], "count": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@swarm_bp.route("/identity", methods=["GET"])
def http_identity():
    return jsonify({"has_identity_module": _HAS_IDENTITY, "identity": get_identity()})


# ============================================================================
# REGISTRATION — call from app.py as: _loaded += _register_fn("zeus_swarm_orchestrator")
# ============================================================================

def register(app) -> None:
    app.register_blueprint(swarm_bp, url_prefix="/api/swarm")
    _ensure_dispatch_table()
    _background_health_scan()
    log.info(f"[swarm] registered — {len(AGENT_REGISTRY)} agents, "
             f"{len(MODULE_TO_AGENT)} modules mapped")
