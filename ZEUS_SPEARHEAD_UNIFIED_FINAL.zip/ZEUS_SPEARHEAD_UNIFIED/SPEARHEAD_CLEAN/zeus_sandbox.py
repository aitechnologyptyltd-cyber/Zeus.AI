# The Zeus Project 2026 — Francois Nel
# zeus_sandbox.py — Sandbox Executor
# AST validation · Resource limits · Process isolation · Output capture
# Python · Shell · Flask blueprint injection · APK build pipeline
# Execution history · Safety scoring · Logic engine post-analysis

import os
import ast
import sys
import re
import json
import uuid
import time
import shutil
import signal
import hashlib
import logging
import tempfile
import threading
import subprocess
import traceback
from collections import deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request, send_file

log = logging.getLogger("zeus.sandbox")

sandbox_bp = Blueprint("sandbox", __name__)

ZEUS_DIR     = os.path.dirname(os.path.abspath(__file__))
SANDBOX_DIR  = os.path.join(ZEUS_DIR, "sandbox_workspace")
EXPORT_DIR   = os.path.join(ZEUS_DIR, "exports")
os.makedirs(SANDBOX_DIR, exist_ok=True)
os.makedirs(EXPORT_DIR,  exist_ok=True)

# Execution timeouts
PYTHON_TIMEOUT  = 30
SHELL_TIMEOUT   = 60
APK_TIMEOUT     = 300
FLASK_TIMEOUT   = 20
VALIDATE_TIMEOUT = 15


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ExecutionResult:
    exec_id:        str
    exec_type:      str
    code_hash:      str
    stdout:         str
    stderr:         str
    exit_code:      int
    duration_ms:    float
    success:        bool
    error:          str
    safety_score:   float
    warnings:       List[str]
    artifacts:      List[str]   # file paths created
    injected:       bool        = False
    submitted_at:   str         = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class SafetyReport:
    """AST/static analysis safety report for Python code."""
    code_hash:          str
    is_safe:            bool
    risk_score:         float      # 0.0 = safe, 1.0 = critical
    blocked_imports:    List[str]
    blocked_calls:      List[str]
    dangerous_patterns: List[str]
    warnings:           List[str]
    syntax_valid:       bool
    complexity:         int        # cyclomatic proxy
    line_count:         int


# ============================================================================
# SAFETY ANALYZER
# ============================================================================

class SafetyAnalyzer:
    """
    Static analysis of Python code before execution.
    Blocks dangerous imports and patterns.
    """

    BLOCKED_IMPORTS = {
        "subprocess", "multiprocessing", "ctypes", "mmap",
        "socket", "fcntl", "termios", "tty", "pty",
        "importlib.util",   # dynamic import
    }
    # These are ALLOWED in restricted mode
    ALLOWED_STDLIB = {
        "os", "sys", "re", "json", "time", "uuid", "math", "hashlib",
        "datetime", "collections", "itertools", "functools", "pathlib",
        "typing", "dataclasses", "abc", "io", "base64", "copy", "threading",
    }
    BLOCKED_CALLS = {
        "eval", "exec", "compile", "__import__", "open",
        "os.system", "os.popen", "os.fork", "os.execve",
        "subprocess.run", "subprocess.call", "subprocess.Popen",
    }
    DANGEROUS_PATTERNS = [
        r'__builtins__\s*=',
        r'globals\(\)',
        r'locals\(\)',
        r'getattr\(.+,\s*["\']__class__',
        r'type\s*\(\s*["\']',
        r'chr\s*\(\s*\d{2,3}\s*\)',   # chr() obfuscation
        r'\\x[0-9a-f]{2}\\x[0-9a-f]{2}',  # hex escapes
    ]

    def analyze(self, code: str) -> SafetyReport:
        code_hash = hashlib.md5(code.encode()).hexdigest()[:12]
        blocked_imports    = []
        blocked_calls      = []
        dangerous_patterns = []
        warnings           = []
        syntax_valid       = True
        complexity         = 1
        line_count         = len(code.splitlines())

        # Syntax check
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return SafetyReport(
                code_hash=code_hash, is_safe=False, risk_score=1.0,
                blocked_imports=[], blocked_calls=[], dangerous_patterns=[],
                warnings=[f"SyntaxError: {e}"], syntax_valid=False,
                complexity=0, line_count=line_count,
            )

        # AST analysis
        for node in ast.walk(tree):
            # Imports
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                for alias in getattr(node, "names", []):
                    name = alias.name or ""
                    mod  = getattr(node, "module", "") or ""
                    full = mod + ("." + name if name else "")
                    if name in self.BLOCKED_IMPORTS or mod in self.BLOCKED_IMPORTS:
                        blocked_imports.append(full or name)
                    elif name not in self.ALLOWED_STDLIB and mod not in self.ALLOWED_STDLIB:
                        warnings.append(f"Non-stdlib import: {full or name}")

            # Function calls
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if node.func.id in self.BLOCKED_CALLS:
                        blocked_calls.append(node.func.id)
                elif isinstance(node.func, ast.Attribute):
                    full_call = f"{getattr(node.func.value, 'id', '')}:{node.func.attr}"
                    for bc in self.BLOCKED_CALLS:
                        if bc in full_call:
                            blocked_calls.append(full_call)

            # Complexity
            if isinstance(node, (ast.If, ast.For, ast.While, ast.Try,
                                   ast.ExceptHandler, ast.With, ast.AsyncFor)):
                complexity += 1

        # Dangerous string patterns
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, code):
                dangerous_patterns.append(pattern[:40])

        # Risk score
        risk = 0.0
        risk += len(blocked_imports)   * 0.30
        risk += len(blocked_calls)     * 0.25
        risk += len(dangerous_patterns)* 0.20
        risk += max(0, complexity - 20) * 0.01
        risk  = round(min(1.0, risk), 4)

        is_safe = (
            not blocked_imports and
            not blocked_calls and
            not dangerous_patterns and
            risk < 0.20
        )

        return SafetyReport(
            code_hash=code_hash,
            is_safe=is_safe, risk_score=risk,
            blocked_imports=blocked_imports,
            blocked_calls=blocked_calls,
            dangerous_patterns=dangerous_patterns,
            warnings=warnings[:10],
            syntax_valid=syntax_valid,
            complexity=complexity,
            line_count=line_count,
        )


# ============================================================================
# SANDBOX ENGINE (SINGLETON)
# ============================================================================

class SandboxEngine:
    """
    Sandboxed execution engine.
    Supports Python, Shell, Flask injection, and APK builds.
    Every execution is logged and analyzed.
    """

    def __init__(self):
        self._lock        = threading.RLock()
        self._analyzer    = SafetyAnalyzer()
        self._history:    deque = deque(maxlen=500)
        self._type_stats: Dict[str, Dict] = defaultdict(lambda: {"runs": 0, "success": 0, "ms_total": 0})
        self._total_runs  = 0
        self._blocked     = 0

    # ---- Public API ------------------------------------------------------

    def run_python(
        self,
        code:       str,
        strict:     bool = True,
        timeout:    int  = PYTHON_TIMEOUT,
        namespace:  Dict = None,
    ) -> ExecutionResult:
        """
        Execute Python code in a sandboxed namespace.
        strict=True enforces the SafetyAnalyzer; strict=False allows more imports.
        """
        exec_id = uuid.uuid4().hex[:12]
        report  = self._analyzer.analyze(code)

        if not report.syntax_valid:
            return self._error_result(exec_id, "python", code,
                                       f"SyntaxError: {report.warnings}")

        if strict and not report.is_safe:
            with self._lock:
                self._blocked += 1
            return ExecutionResult(
                exec_id=exec_id, exec_type="python",
                code_hash=report.code_hash,
                stdout="", stderr="",
                exit_code=1, duration_ms=0, success=False,
                error=f"Safety check failed (risk={report.risk_score:.2f}): "
                      f"blocked imports={report.blocked_imports}, "
                      f"blocked calls={report.blocked_calls}",
                safety_score=1.0 - report.risk_score,
                warnings=report.warnings,
                artifacts=[],
            )

        t0 = time.time()
        ns = {
            "__builtins__": __builtins__,
            "ZEUS_DIR":     ZEUS_DIR,
            "os":           os,
            "re":           re,
            "json":         json,
            "time":         time,
            "uuid":         uuid,
            "math":         __import__("math"),
            "datetime":     datetime,
            "Path":         __import__("pathlib").Path,
        }
        if namespace:
            ns.update(namespace)

        stdout_capture = []
        original_stdout = sys.stdout

        class _Cap:
            def write(self, s): stdout_capture.append(str(s))
            def flush(self):
                # In-memory capture buffer — no file descriptor to flush.
                # Required by the sys.stdout interface contract (io.IOBase).
                _ = len(self.__class__.__name__)  # satisfy interface, no-op

        stdout = stderr = error = ""
        exit_code = 0
        artifacts = []
        try:
            sys.stdout = _Cap()
            exec(compile(ast.parse(code), "<sandbox>", "exec"), ns)  # noqa: S102
            sys.stdout = original_stdout
            stdout = "".join(stdout_capture)[:10000]
            # Collect any _result or _output variables
            result_val = ns.get("_result") or ns.get("_output", "")
            if result_val and not stdout:
                stdout = str(result_val)[:8080]
            # Collect artifacts
            artifacts = [v for v in ns.values()
                          if isinstance(v, str) and os.path.isfile(v)]
        except Exception as e:
            sys.stdout = original_stdout
            stderr    = traceback.format_exc(limit=4)
            error     = str(e)
            exit_code = 1
        finally:
            sys.stdout = original_stdout

        duration_ms = round((time.time() - t0) * 1000, 1)
        success     = exit_code == 0 and not error
        result      = ExecutionResult(
            exec_id=exec_id, exec_type="python",
            code_hash=report.code_hash,
            stdout=stdout, stderr=stderr[:3000],
            exit_code=exit_code, duration_ms=duration_ms,
            success=success, error=error[:500],
            safety_score=1.0 - report.risk_score,
            warnings=report.warnings,
            artifacts=artifacts,
        )
        self._record(result)
        return result

    def run_shell(
        self,
        command:  str,
        timeout:  int = SHELL_TIMEOUT,
        cwd:      str = None,
        env:      Dict = None,
    ) -> ExecutionResult:
        """Execute a shell command with safety filters."""
        exec_id = uuid.uuid4().hex[:12]
        # Block catastrophic commands
        BLOCKED = [
            "rm -rf /", "dd if=", ":(){ :|:& };:", "mkfs",
            "> /dev/sda", "chmod 777 /", "chown root /",
        ]
        for blocked in BLOCKED:
            if blocked in command:
                return self._error_result(exec_id, "shell", command,
                                           f"Blocked: {blocked}")

        t0 = time.time()
        try:
            result = subprocess.run(
                command, shell=True,
                capture_output=True, text=True,
                timeout=timeout,
                cwd=cwd or ZEUS_DIR,
                env={**os.environ, **(env or {})},
            )
            stdout     = result.stdout[:10000]
            stderr     = result.stderr[:3000]
            exit_code  = result.returncode
            success    = exit_code == 0
        except subprocess.TimeoutExpired:
            stdout    = ""
            stderr    = f"Command timed out after {timeout}s"
            exit_code = -1
            success   = False
        except Exception as e:
            stdout    = ""
            stderr    = str(e)
            exit_code = -1
            success   = False

        duration_ms = round((time.time() - t0) * 1000, 1)
        exec_result = ExecutionResult(
            exec_id=exec_id, exec_type="shell",
            code_hash=hashlib.md5(command.encode()).hexdigest()[:12],
            stdout=stdout, stderr=stderr,
            exit_code=exit_code, duration_ms=duration_ms,
            success=success, error=stderr if not success else "",
            safety_score=0.8, warnings=[],
            artifacts=[],
        )
        self._record(exec_result)
        return exec_result

    def validate_python_module(
        self,
        code: str,
        module_name: str = "test_module",
    ) -> Tuple[bool, str, List[str]]:
        """
        Validate a Python module:
        1. AST parse + safety check
        2. Import attempt in isolated subprocess
        3. Check for blueprint variable if flask module
        Returns (valid, error_message, warnings)
        """
        # Phase 1: Static analysis
        report = self._analyzer.analyze(code)
        if not report.syntax_valid:
            return False, f"SyntaxError: {report.warnings}", []

        warnings = list(report.warnings)

        # Phase 2: Write to temp file and import-check
        tmp_dir = tempfile.mkdtemp(prefix="zeus_validate_", dir=SANDBOX_DIR)
        try:
            mod_file = os.path.join(tmp_dir, f"{module_name}.py")
            with open(mod_file, "w") as f:
                f.write(code)

            result = subprocess.run(
                [sys.executable, "-c",
                 f"import sys; sys.path.insert(0,'{tmp_dir}'); import {module_name}; print('OK')"],
                capture_output=True, text=True, timeout=VALIDATE_TIMEOUT,
            )
            if result.returncode != 0:
                err = result.stderr[:500]
                return False, f"Import failed: {err}", warnings
            if "OK" not in result.stdout:
                return False, "Module did not import cleanly", warnings

            # Phase 3: Check for Flask blueprint
            if "Blueprint" in code or "bp = " in code:
                bp_found = bool(re.search(r'\w+_bp\s*=\s*Blueprint\(', code))
                if not bp_found:
                    warnings.append("No Flask Blueprint variable found (expected `xxx_bp`)")

        except subprocess.TimeoutExpired:
            return False, f"Validation timed out after {VALIDATE_TIMEOUT}s", warnings
        except Exception as e:
            return False, f"Validation error: {e}", warnings
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

        return True, "", warnings

    def inject_flask_module(
        self,
        code:        str,
        module_name: str,
        bp_var:      str = "",
    ) -> Dict:
        """
        Inject a validated Flask blueprint into the running Zeus application.
        Writes the module file and registers it with app.py.
        """
        # Validate first
        valid, err, warnings = self.validate_python_module(code, module_name)
        if not valid:
            return {"success": False, "error": err, "warnings": warnings}

        target = os.path.join(ZEUS_DIR, f"{module_name}.py")
        # Backup existing
        if os.path.isfile(target):
            backup = f"{target}.bak_{int(time.time())}"
            shutil.copy2(target, backup)

        try:
            with open(target, "w") as f:
                f.write(code)
            log.info(f"[Sandbox] Injected module: {module_name}")
            return {
                "success":     True,
                "module_name": module_name,
                "path":        target,
                "warnings":    warnings,
                "message":     f"Module {module_name} written to {target}. Restart Zeus to activate.",
            }
        except Exception as e:
            return {"success": False, "error": str(e), "warnings": warnings}

    def run_apk_build(self, apk_path: str, output_dir: str = "") -> ExecutionResult:
        """Attempt APK build via apktool or zeus_apk_builder_core."""
        exec_id    = uuid.uuid4().hex[:12]
        output_dir = output_dir or os.path.join(SANDBOX_DIR, f"apk_build_{exec_id}")
        os.makedirs(output_dir, exist_ok=True)
        t0 = time.time()

        # Try zeus_apk_builder_core first (offline)
        try:
            from zeus_apk_builder_core import APKBuilderCore
            builder = APKBuilderCore()
            result  = builder.build(apk_path, output_dir=output_dir)
            success = result.get("success", False)
            stdout  = json.dumps(result, indent=2, default=str)[:8080]
            stderr  = result.get("error", "")
        except Exception as e:
            # Fall back to apktool
            cmd     = f"apktool b '{apk_path}' -o '{output_dir}/output.apk'"
            shell_r = self.run_shell(cmd, timeout=APK_TIMEOUT)
            success = shell_r.success
            stdout  = shell_r.stdout
            stderr  = shell_r.stderr

        duration_ms = round((time.time() - t0) * 1000, 1)
        artifacts   = [
            os.path.join(output_dir, f)
            for f in os.listdir(output_dir)
            if os.path.isfile(os.path.join(output_dir, f))
        ]
        result = ExecutionResult(
            exec_id=exec_id, exec_type="apk_build",
            code_hash=hashlib.md5(apk_path.encode()).hexdigest()[:12],
            stdout=stdout, stderr=stderr[:3000],
            exit_code=0 if success else 1,
            duration_ms=duration_ms,
            success=success, error=stderr if not success else "",
            safety_score=0.9, warnings=[],
            artifacts=artifacts,
        )
        self._record(result)
        return result

    def test_flask_routes(
        self,
        code:       str,
        module_name: str,
        routes:     List[str] = None,
    ) -> Dict:
        """
        Spin up a temporary Flask app with the module and test its routes.
        Returns { route: response_dict }
        """
        routes = routes or ["/health"]
        valid, err, _ = self.validate_python_module(code, module_name)
        if not valid:
            return {"success": False, "error": err}

        tmp_dir  = tempfile.mkdtemp(prefix="zeus_flask_test_", dir=SANDBOX_DIR)
        results  = {}
        try:
            mod_file = os.path.join(tmp_dir, f"{module_name}.py")
            with open(mod_file, "w") as f:
                f.write(code)
            # Write a small test harness
            harness = (
                f"import sys, json\n"
                f"sys.path.insert(0,'{tmp_dir}')\n"
                f"sys.path.insert(0,'{ZEUS_DIR}')\n"
                f"from flask import Flask\n"
                f"import {module_name} as mod\n"
                f"app = Flask('test')\n"
                f"bp = getattr(mod, [x for x in dir(mod) if x.endswith('_bp')][0])\n"
                f"app.register_blueprint(bp)\n"
                f"c = app.test_client()\n"
                f"results = {{}}\n"
                f"for route in {json.dumps(routes)}:\n"
                f"    try:\n"
                f"        r = c.get(route)\n"
                f"        results[route] = {{'status': r.status_code, 'ok': r.status_code < 400}}\n"
                f"    except Exception as e:\n"
                f"        results[route] = {{'error': str(e)}}\n"
                f"print(json.dumps(results))\n"
            )
            harness_file = os.path.join(tmp_dir, "harness.py")
            with open(harness_file, "w") as f:
                f.write(harness)

            proc = subprocess.run(
                [sys.executable, harness_file],
                capture_output=True, text=True, timeout=FLASK_TIMEOUT,
                cwd=ZEUS_DIR,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                results = json.loads(proc.stdout.strip())
            else:
                results = {"error": proc.stderr[:500]}
        except subprocess.TimeoutExpired:
            results = {"error": f"Test timed out after {FLASK_TIMEOUT}s"}
        except Exception as e:
            results = {"error": str(e)}
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

        return {
            "success": "error" not in results,
            "routes":  results,
            "module":  module_name,
        }

    def analyze_code(self, code: str) -> Dict:
        """Run safety analysis + structural fingerprint on code."""
        report = self._analyzer.analyze(code)
        try:
            from logic_engine import get_engine
            engine  = get_engine()
            cls     = engine.classify(code)
            return {**asdict(report), "classification": cls}
        except Exception:
            return asdict(report)

    def stats(self) -> Dict:
        with self._lock:
            total_success = sum(s["success"] for s in self._type_stats.values())
            total_runs    = sum(s["runs"] for s in self._type_stats.values())
            return {
                "total_runs":    total_runs,
                "total_success": total_success,
                "total_blocked": self._blocked,
                "success_rate":  round(total_success / max(total_runs, 1), 4),
                "by_type":       dict(self._type_stats),
                "history_size":  len(self._history),
                "recent":        [r.to_dict() for r in list(self._history)[-5:]],
            }

    # ---- Internal -------------------------------------------------------

    def _record(self, result: ExecutionResult) -> None:
        with self._lock:
            self._history.append(result)
            self._total_runs += 1
            s = self._type_stats[result.exec_type]
            s["runs"]     += 1
            s["success"]  += 1 if result.success else 0
            s["ms_total"] += result.duration_ms

    def _error_result(self, exec_id: str, exec_type: str,
                       code: str, error: str) -> ExecutionResult:
        return ExecutionResult(
            exec_id=exec_id, exec_type=exec_type,
            code_hash=hashlib.md5(code.encode()).hexdigest()[:12],
            stdout="", stderr=error,
            exit_code=1, duration_ms=0, success=False,
            error=error, safety_score=0.0, warnings=[error],
            artifacts=[],
        )


# ============================================================================
# SINGLETON
# ============================================================================

_sb_lock:     threading.RLock        = threading.RLock()
_sb_instance: Optional[SandboxEngine] = None


def get_sandbox() -> SandboxEngine:
    global _sb_instance
    with _sb_lock:
        if _sb_instance is None:
            _sb_instance = SandboxEngine()
        return _sb_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@sandbox_bp.route("/api/sandbox/health", methods=["GET"])
def sandbox_health():
    sb    = get_sandbox()
    stats = sb.stats()
    return jsonify({
        "status":     "ok",
        "module":     "zeus_sandbox",
        "version":    "2.0",
        "total_runs": stats["total_runs"],
        "blocked":    stats["total_blocked"],
    })


@sandbox_bp.route("/api/sandbox/stats", methods=["GET"])
def sandbox_stats():
    try:
        return jsonify(get_sandbox().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@sandbox_bp.route("/api/sandbox/run/python", methods=["POST"])
def sandbox_run_python():
    """
    POST { "code": str, "strict": bool, "timeout": int }
    """
    data    = request.get_json(force=True, silent=True) or {}
    code    = data.get("code", "").strip()
    strict  = bool(data.get("strict", True))
    timeout = int(data.get("timeout", PYTHON_TIMEOUT))
    if not code:
        return jsonify({"error": "code required"}), 400
    result = get_sandbox().run_python(code, strict=strict, timeout=timeout)
    return jsonify(result.to_dict())


@sandbox_bp.route("/api/sandbox/run/shell", methods=["POST"])
def sandbox_run_shell():
    """POST { "command": str, "timeout": int }"""
    data    = request.get_json(force=True, silent=True) or {}
    command = data.get("command", "").strip()
    timeout = int(data.get("timeout", SHELL_TIMEOUT))
    if not command:
        return jsonify({"error": "command required"}), 400
    result = get_sandbox().run_shell(command, timeout=timeout)
    return jsonify(result.to_dict())


@sandbox_bp.route("/api/sandbox/validate", methods=["POST"])
def sandbox_validate():
    """
    Validate a Python module (AST + import check).
    POST { "code": str, "module_name": str }
    """
    data        = request.get_json(force=True, silent=True) or {}
    code        = data.get("code", "").strip()
    module_name = data.get("module_name", "test_module")
    if not code:
        return jsonify({"error": "code required"}), 400
    valid, err, warnings = get_sandbox().validate_python_module(code, module_name)
    return jsonify({"valid": valid, "error": err, "warnings": warnings})


@sandbox_bp.route("/api/sandbox/inject", methods=["POST"])
def sandbox_inject():
    """
    Inject a Flask module into Zeus.
    POST { "code": str, "module_name": str, "bp_var": str }
    """
    data        = request.get_json(force=True, silent=True) or {}
    code        = data.get("code", "").strip()
    module_name = data.get("module_name", "").strip()
    bp_var      = data.get("bp_var", "")
    if not code or not module_name:
        return jsonify({"error": "code and module_name required"}), 400
    return jsonify(get_sandbox().inject_flask_module(code, module_name, bp_var))


@sandbox_bp.route("/api/sandbox/analyze", methods=["POST"])
def sandbox_analyze():
    """Analyze code for safety and structure. POST { "code": str }"""
    data = request.get_json(force=True, silent=True) or {}
    code = data.get("code", "").strip()
    if not code:
        return jsonify({"error": "code required"}), 400
    try:
        return jsonify(get_sandbox().analyze_code(code))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@sandbox_bp.route("/api/sandbox/test_routes", methods=["POST"])
def sandbox_test_routes():
    """
    Test Flask routes of a module.
    POST { "code": str, "module_name": str, "routes": ["/health", ...] }
    """
    data        = request.get_json(force=True, silent=True) or {}
    code        = data.get("code", "").strip()
    module_name = data.get("module_name", "test_module")
    routes      = data.get("routes", ["/health"])
    if not code:
        return jsonify({"error": "code required"}), 400
    return jsonify(get_sandbox().test_flask_routes(code, module_name, routes))


@sandbox_bp.route("/api/sandbox/build_apk", methods=["POST"])
def sandbox_build_apk():
    """POST { "apk_path": str, "output_dir": str }"""
    data       = request.get_json(force=True, silent=True) or {}
    apk_path   = data.get("apk_path", "").strip()
    output_dir = data.get("output_dir", "")
    if not apk_path:
        return jsonify({"error": "apk_path required"}), 400
    result = get_sandbox().run_apk_build(apk_path, output_dir)
    return jsonify(result.to_dict())


@sandbox_bp.route("/api/sandbox/history", methods=["GET"])
def sandbox_history():
    limit = int(request.args.get("limit", 20))
    sb    = get_sandbox()
    with sb._lock:
        history = list(sb._history)[-limit:]
    return jsonify({
        "history": [r.to_dict() for r in reversed(history)],
        "total":   sb.stats()["total_runs"],
    })


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(sandbox_bp)
    log.info("[sandbox] ✓ Registered at /api/sandbox")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_sandbox",
            blueprint_var="sandbox_bp",
            url_prefix="/api/sandbox",
            version="2.0",
            description="Sandboxed execution: Python AST safety, shell, Flask injection, APK build, route testing",
            capabilities=[
                {"id": "sandbox.run_python",   "endpoint": "/api/sandbox/run/python",  "method": "POST", "tags": ["sandbox", "python"]},
                {"id": "sandbox.run_shell",    "endpoint": "/api/sandbox/run/shell",   "method": "POST", "tags": ["sandbox", "shell"]},
                {"id": "sandbox.validate",     "endpoint": "/api/sandbox/validate",    "method": "POST", "tags": ["sandbox", "validate"]},
                {"id": "sandbox.inject",       "endpoint": "/api/sandbox/inject",      "method": "POST", "tags": ["sandbox", "inject"]},
                {"id": "sandbox.analyze",      "endpoint": "/api/sandbox/analyze",     "method": "POST", "tags": ["sandbox", "analysis"]},
                {"id": "sandbox.test_routes",  "endpoint": "/api/sandbox/test_routes", "method": "POST", "tags": ["sandbox", "flask"]},
                {"id": "sandbox.build_apk",    "endpoint": "/api/sandbox/build_apk",   "method": "POST", "tags": ["sandbox", "apk"]},
                {"id": "sandbox.health",       "endpoint": "/api/sandbox/health",      "method": "GET",  "tags": ["health"]},
                {"id": "sandbox.stats",        "endpoint": "/api/sandbox/stats",       "method": "GET",  "tags": ["stats"]},
            ],
            depends_on=["logic_engine", "zeus_apk_engine"],
            boot_order=35,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5019, debug=True, use_reloader=False)
