#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
# The Zeus Project 2026 — Francois Nel
# zeus_install_armv7l.sh — ARMv7l Dedicated Full Installer
# Built for: Hisense Y82 Pro / Termux UserLand Ubuntu / 32-bit ARM
# Python 3.14 compatible — all packages built from source
# ══════════════════════════════════════════════════════════════════════════════
#
# USAGE:
#   sudo bash zeus_install_armv7l.sh [--no-miners] [--quiet]
#
# FLAGS:
#   --no-miners   Skip XMRig / cpuminer build steps
#   --quiet       Less output (errors still shown)
#   --help        Show this help
# ══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# ── Arg parse ─────────────────────────────────────────────────────────────────
OPT_NO_MINERS=0
OPT_QUIET=0
for arg in "$@"; do
    case "$arg" in
        --no-miners) OPT_NO_MINERS=1 ;;
        --quiet)     OPT_QUIET=1     ;;
        --help|-h)   head -25 "$0" | grep "^#"; exit 0 ;;
    esac
done

# ── Arch warning ──────────────────────────────────────────────────────────────
ARCH="$(uname -m)"
if [[ "$ARCH" != "armv7l" && "$ARCH" != "armv7" && "$ARCH" != "armhf" ]]; then
    echo "[WARN] This script is tuned for armv7l -- detected: $ARCH"
    read -r -p "       Continue anyway? [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]] || exit 1
fi

# ── Paths & globals ───────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$SCRIPT_DIR/zeus_install_armv7l.log"
TMP_DIR="/tmp/zeus_arm_$$"
BIN_DIR="$SCRIPT_DIR/bin"
mkdir -p "$BIN_DIR" "$TMP_DIR"

PY_BIN="$(command -v python3 2>/dev/null || command -v python || echo python3)"
CPU_COUNT="$(nproc 2>/dev/null || grep -c processor /proc/cpuinfo 2>/dev/null || echo 2)"
BUILD_JOBS="$(( CPU_COUNT > 1 ? CPU_COUNT - 1 : 1 ))"

IS_TERMUX=0; PKG_MGR="apt"
if [ -n "${TERMUX_VERSION:-}" ] || [ -d "/data/data/com.termux" ]; then
    IS_TERMUX=1; PKG_MGR="pkg"
fi

ERRORS=0; WARNS=0; SKIPPED=0; INSTALLED=0; UPGRADED=0

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GRN='\033[0;32m'; YEL='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; RST='\033[0m'

log_step()    { echo -e "\n${BLD}${CYN}=== STEP $1: $2 ===${RST}" | tee -a "$LOG"; }
log_ok()      { echo -e "  ${GRN}[ OK ]${RST}  $*" | tee -a "$LOG"; }
log_warn()    { echo -e "  ${YEL}[WARN]${RST}  $*" | tee -a "$LOG"; WARNS=$((WARNS+1)); }
log_err()     { echo -e "  ${RED}[FAIL]${RST}  $*" | tee -a "$LOG"; ERRORS=$((ERRORS+1)); }
log_skip()    { echo -e "  ${YEL}[SKIP]${RST}  $*" | tee -a "$LOG"; SKIPPED=$((SKIPPED+1)); }
log_info()    { echo -e "  ${CYN}[ -- ]${RST}  $*" | tee -a "$LOG"; }
log_upgrade() { echo -e "  ${GRN}[ UP ]${RST}  $*" | tee -a "$LOG"; UPGRADED=$((UPGRADED+1)); }

# ── apt helper: skip if already installed ─────────────────────────────────────
apt_install() {
    local pkg="$1"
    if dpkg -s "$pkg" > /dev/null 2>&1; then
        log_skip "$pkg (already installed)"
        return 0
    fi
    log_info "apt install: $pkg"
    if [ "$OPT_QUIET" -eq 1 ]; then
        apt-get install -y --no-install-recommends "$pkg" >> "$LOG" 2>&1 \
            && { log_ok "$pkg"; INSTALLED=$((INSTALLED+1)); } \
            || log_warn "$pkg -- not available, skipped"
    else
        apt-get install -y --no-install-recommends "$pkg" 2>&1 | tee -a "$LOG" \
            && { log_ok "$pkg"; INSTALLED=$((INSTALLED+1)); } \
            || log_warn "$pkg -- not available, skipped"
    fi
}

# ── pip smart installer ────────────────────────────────────────────────────────
# Tries in order:
#   1. Skip if already installed
#   2. Build from source with --no-binary :all: --break-system-packages
#   3. Build from source WITHOUT --break-system-packages
#   4. Allow binary wheel WITH --break-system-packages
#   5. Allow binary wheel WITHOUT --break-system-packages
#   6. Try piwheels (pre-compiled armv7l wheels)
#   7. WARN — could not install
pip_smart() {
    local pkg="$1"
    local required="${2:-0}"   # 1 = must-have, 0 = optional
    local bare
    bare="$(echo "$pkg" | sed 's/[>=<!].*//' | tr '[:upper:]' '[:lower:]' \
          | sed 's/-/_/g')"

    # ── Skip check ────────────────────────────────────────────────────────────
    if "$PY_BIN" -m pip show "$bare" > /dev/null 2>&1 || \
       "$PY_BIN" -m pip show "${bare//_/-}" > /dev/null 2>&1; then
        log_skip "$pkg (already installed)"
        return 0
    fi

    log_info "Installing: $pkg (source build, armv7l)"

    # ── Attempt 1: source + break-system-packages ─────────────────────────────
    if "$PY_BIN" -m pip install "$pkg" \
        --no-binary :all: \
        --break-system-packages \
        --quiet --no-warn-script-location \
        >> "$LOG" 2>&1; then
        log_ok "$pkg (source + break-system-packages)"
        INSTALLED=$((INSTALLED+1)); return 0
    fi

    log_info "$pkg source+bsp failed -- trying source without bsp"

    # ── Attempt 2: source without break-system-packages ───────────────────────
    if "$PY_BIN" -m pip install "$pkg" \
        --no-binary :all: \
        --quiet --no-warn-script-location \
        >> "$LOG" 2>&1; then
        log_ok "$pkg (source, no bsp)"
        INSTALLED=$((INSTALLED+1)); return 0
    fi

    log_info "$pkg source build failed -- trying binary wheel + break-system-packages"

    # ── Attempt 3: binary wheel + break-system-packages ──────────────────────
    if "$PY_BIN" -m pip install "$pkg" \
        --break-system-packages \
        --quiet --no-warn-script-location \
        >> "$LOG" 2>&1; then
        log_ok "$pkg (binary wheel + break-system-packages)"
        INSTALLED=$((INSTALLED+1)); return 0
    fi

    log_info "$pkg binary+bsp failed -- trying binary wheel without bsp"

    # ── Attempt 4: binary wheel without break-system-packages ─────────────────
    if "$PY_BIN" -m pip install "$pkg" \
        --quiet --no-warn-script-location \
        >> "$LOG" 2>&1; then
        log_ok "$pkg (binary wheel, no bsp)"
        INSTALLED=$((INSTALLED+1)); return 0
    fi

    log_info "$pkg all PyPI attempts failed -- trying piwheels (armv7l pre-built)"

    # ── Attempt 5: piwheels ───────────────────────────────────────────────────
    if "$PY_BIN" -m pip install "$pkg" \
        --break-system-packages \
        --extra-index-url https://www.piwheels.org/simple \
        --quiet --no-warn-script-location \
        >> "$LOG" 2>&1; then
        log_ok "$pkg (piwheels)"
        INSTALLED=$((INSTALLED+1)); return 0
    fi

    # ── All attempts failed ───────────────────────────────────────────────────
    if [ "$required" -eq 1 ]; then
        log_err "$pkg -- ALL install attempts failed (REQUIRED package)"
    else
        log_warn "$pkg -- ALL install attempts failed (optional, continuing)"
    fi
    return 1
}

# ── pip upgrade: upgrade a package to latest, same fallback chain ─────────────
pip_upgrade() {
    local pkg="$1"
    local bare
    bare="$(echo "$pkg" | sed 's/[>=<!].*//' | tr '[:upper:]' '[:lower:]' \
          | sed 's/-/_/g')"

    # Get current installed version
    local current
    current="$("$PY_BIN" -m pip show "$bare" 2>/dev/null | grep '^Version:' | awk '{print $2}' || \
               "$PY_BIN" -m pip show "${bare//_/-}" 2>/dev/null | grep '^Version:' | awk '{print $2}' || \
               echo "")"

    if [ -z "$current" ]; then
        log_skip "$pkg (not installed, skipping upgrade)"
        return 0
    fi

    log_info "Upgrading: $pkg (current: $current)"

    # Try source upgrade first, fall back through same chain
    for attempt in \
        "--no-binary :all: --break-system-packages" \
        "--no-binary :all:" \
        "--break-system-packages" \
        "" \
        "--break-system-packages --extra-index-url https://www.piwheels.org/simple"; do
        if "$PY_BIN" -m pip install --upgrade "$pkg" $attempt \
            --quiet --no-warn-script-location >> "$LOG" 2>&1; then
            local new_ver
            new_ver="$("$PY_BIN" -m pip show "$bare" 2>/dev/null | grep '^Version:' | awk '{print $2}' || echo "?")"
            if [ "$new_ver" = "$current" ]; then
                log_skip "$pkg already at latest ($current)"
            else
                log_upgrade "$pkg $current → $new_ver"
            fi
            return 0
        fi
    done
    log_warn "$pkg upgrade failed -- keeping $current"
}

# ── Banner ────────────────────────────────────────────────────────────────────
echo "" | tee -a "$LOG"
echo -e "${BLD}${CYN}" | tee -a "$LOG"
echo "  ╔══════════════════════════════════════════════════════════════╗" | tee -a "$LOG"
echo "  ║   THE ZEUS PROJECT 2026 — FRANCOIS NEL                      ║" | tee -a "$LOG"
echo "  ║   zeus_install_armv7l.sh  —  ARMv7l Full Installer          ║" | tee -a "$LOG"
echo "  ╚══════════════════════════════════════════════════════════════╝" | tee -a "$LOG"
echo -e "${RST}" | tee -a "$LOG"
log_info "Arch       : $ARCH"
log_info "Python     : $("$PY_BIN" --version 2>&1)"
log_info "Pkg mgr    : $PKG_MGR"
log_info "CPU cores  : $CPU_COUNT  (build jobs: $BUILD_JOBS)"
log_info "Termux     : $IS_TERMUX"
log_info "Log        : $LOG"
[ $OPT_NO_MINERS -eq 1 ] && log_info "Mode       : --no-miners"
echo "Zeus install started: $(date)" >> "$LOG"

# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — Package index update
# ══════════════════════════════════════════════════════════════════════════════
log_step "1/16" "Updating package index"
if [ "$PKG_MGR" = "apt" ]; then
    apt-get update -y >> "$LOG" 2>&1 && log_ok "apt-get update" || log_warn "update had warnings"
else
    pkg update -y >> "$LOG" 2>&1 && log_ok "pkg update" || log_warn "update had warnings"
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 2 — Build tools
# ══════════════════════════════════════════════════════════════════════════════
log_step "2/16" "Build tools"
if [ "$PKG_MGR" = "apt" ]; then
    for p in build-essential gcc g++ make automake autoconf libtool pkg-config; do
        apt_install "$p"
    done
else
    for p in make automake autoconf libtool pkg-config clang; do
        pkg_install "$p"
    done
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 3 — Download + version control
# ══════════════════════════════════════════════════════════════════════════════
log_step "3/16" "Download + version control tools"
if [ "$PKG_MGR" = "apt" ]; then
    for p in git wget curl unzip ca-certificates gnupg; do
        apt_install "$p"
    done
else
    for p in git wget curl unzip; do
        apt_install "$p"
    done
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 4 — Python + dev headers
# ══════════════════════════════════════════════════════════════════════════════
log_step "4/16" "Python + dev headers"
if [ "$PKG_MGR" = "apt" ]; then
    for p in python3 python3-pip python3-dev python3-venv python3-setuptools python3-wheel; do
        apt_install "$p"
    done
else
    apt_install "python"
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 5 — SSL / crypto / DB / compression headers
# ══════════════════════════════════════════════════════════════════════════════
log_step "5/16" "SSL / crypto / DB / compression headers"
if [ "$PKG_MGR" = "apt" ]; then
    for p in libssl-dev libffi-dev libgmp-dev libsqlite3-dev zlib1g-dev \
              libcurl4-openssl-dev libjansson-dev libuv1-dev; do
        apt_install "$p"
    done
else
    for p in openssl libgmp; do
        apt_install "$p"
    done
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 6 — Image / font / OCR / TTS headers (required for Pillow + reportlab)
# ══════════════════════════════════════════════════════════════════════════════
log_step "6/16" "Image / font / OCR / TTS system headers"
if [ "$PKG_MGR" = "apt" ]; then
    for p in \
        screen sqlite3 procps file \
        libjpeg-dev libpng-dev libfreetype6-dev liblcms2-dev \
        libwebp-dev libtiff-dev libopenjp2-7-dev \
        tesseract-ocr tesseract-ocr-eng libtesseract-dev libleptonica-dev \
        espeak-ng; do
        apt_install "$p"
    done
else
    for p in screen tesseract espeak; do
        apt_install "$p"
    done
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 7 — cmake (skip if >= 3.15, build from source if not)
# ══════════════════════════════════════════════════════════════════════════════
log_step "7/16" "cmake (need >= 3.15)"

CMAKE_NEEDED_MAJOR=3; CMAKE_NEEDED_MINOR=15
CMAKE_BUILD_VER="3.28.3"; NEED_CMAKE=0

if command -v cmake > /dev/null 2>&1; then
    CMAKE_VER="$(cmake --version 2>/dev/null | grep -o '[0-9][0-9]*\.[0-9][0-9]*' | head -1)"
    CMAKE_MAJ="$(echo "$CMAKE_VER" | cut -d. -f1)"
    CMAKE_MIN="$(echo "$CMAKE_VER" | cut -d. -f2)"
    CMAKE_MAJ="${CMAKE_MAJ:-0}"; CMAKE_MIN="${CMAKE_MIN:-0}"
    if [ "$CMAKE_MAJ" -lt "$CMAKE_NEEDED_MAJOR" ] || \
       { [ "$CMAKE_MAJ" -eq "$CMAKE_NEEDED_MAJOR" ] && [ "$CMAKE_MIN" -lt "$CMAKE_NEEDED_MINOR" ]; }; then
        log_warn "cmake $CMAKE_VER too old"; NEED_CMAKE=1
    else
        log_skip "cmake $CMAKE_VER already meets requirement"
    fi
else
    log_info "cmake not found -- trying apt first"
    NEED_CMAKE=1
    [ "$PKG_MGR" = "apt" ] && apt_install "cmake" || true
    if command -v cmake > /dev/null 2>&1; then
        CMAKE_VER="$(cmake --version 2>/dev/null | grep -o '[0-9][0-9]*\.[0-9][0-9]*' | head -1)"
        CMAKE_MAJ="$(echo "$CMAKE_VER" | cut -d. -f1)"
        CMAKE_MIN="$(echo "$CMAKE_VER" | cut -d. -f2)"
        [ "${CMAKE_MAJ:-0}" -ge "$CMAKE_NEEDED_MAJOR" ] && \
        [ "${CMAKE_MIN:-0}" -ge "$CMAKE_NEEDED_MINOR" ] && NEED_CMAKE=0 && \
        log_ok "cmake $CMAKE_VER from apt is sufficient"
    fi
fi

if [ $NEED_CMAKE -eq 1 ]; then
    CMAKE_SRC="$TMP_DIR/cmake_src"
    CMAKE_TAR="cmake-${CMAKE_BUILD_VER}.tar.gz"
    CMAKE_URL="https://github.com/Kitware/CMake/releases/download/v${CMAKE_BUILD_VER}/${CMAKE_TAR}"
    mkdir -p "$CMAKE_SRC"
    log_info "Downloading cmake $CMAKE_BUILD_VER source..."
    wget -q -O "$CMAKE_SRC/$CMAKE_TAR" "$CMAKE_URL" >> "$LOG" 2>&1 \
        || curl -L -o "$CMAKE_SRC/$CMAKE_TAR" "$CMAKE_URL" >> "$LOG" 2>&1
    if [ -f "$CMAKE_SRC/$CMAKE_TAR" ] && [ -s "$CMAKE_SRC/$CMAKE_TAR" ]; then
        cd "$CMAKE_SRC"
        tar -xzf "$CMAKE_TAR" >> "$LOG" 2>&1
        cd "cmake-${CMAKE_BUILD_VER}"
        log_info "Bootstrapping cmake (10-40 min on armv7l -- please wait)..."
        ./bootstrap --prefix=/usr/local --parallel="$BUILD_JOBS" >> "$LOG" 2>&1
        make -j"$BUILD_JOBS" >> "$LOG" 2>&1
        make install >> "$LOG" 2>&1
        cd "$SCRIPT_DIR"
        command -v cmake > /dev/null 2>&1 \
            && log_ok "cmake $(cmake --version | head -1) built from source" \
            || log_err "cmake source build failed"
    else
        log_err "cmake source download failed"
    fi
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 8 — Upgrade pip + setuptools
# ══════════════════════════════════════════════════════════════════════════════
log_step "8/16" "Upgrade pip + setuptools + wheel"
"$PY_BIN" -m pip install --upgrade pip setuptools wheel \
    --break-system-packages --quiet >> "$LOG" 2>&1 \
    && log_ok "pip / setuptools / wheel upgraded" \
    || log_warn "pip upgrade had warnings"

# cmake Python module — required by ccxt → pycares dependency
pip_smart "cmake" 1

# ══════════════════════════════════════════════════════════════════════════════
# STEP 9 — Web framework  [REQUIRED]
# ══════════════════════════════════════════════════════════════════════════════
log_step "9/16" "Web framework [REQUIRED]"
for p in "flask>=3.0.0" "gunicorn>=20.1.0" "fastapi>=0.110.0" \
          "uvicorn>=0.29.0" "werkzeug" "jinja2" "itsdangerous" "click"; do
    pip_smart "$p" 1
done

# ══════════════════════════════════════════════════════════════════════════════
# STEP 10 — LLM / AI / networking  [REQUIRED]
# ══════════════════════════════════════════════════════════════════════════════
log_step "10/16" "LLM / AI / networking [REQUIRED]"
for p in "groq>=0.4.0" "anthropic>=0.20.0" "openai>=1.0.0" \
          "requests>=2.31.0" "httpx" "aiohttp" \
          "websocket-client>=1.6.0" \
          "apscheduler>=3.10.0" \
          "duckduckgo-search>=6.0.0" \
          "feedparser>=6.0.0" \
          "beautifulsoup4" "lxml"; do
    pip_smart "$p" 1
done

# ══════════════════════════════════════════════════════════════════════════════
# STEP 11 — File processing / OCR / reporting  [REQUIRED]
# ══════════════════════════════════════════════════════════════════════════════
log_step "11/16" "File processing / OCR / reporting [REQUIRED]"

for p in "pdfminer.six>=20221105" "pypdf>=3.0.0" "openpyxl>=3.1.0"; do
    pip_smart "$p" 1
done

# Pillow — needs libjpeg-dev etc. (installed in step 6), force source build
log_info "Installing Pillow from source (requires libjpeg-dev / libpng-dev / libfreetype6-dev)"
if "$PY_BIN" -m pip show pillow > /dev/null 2>&1; then
    log_skip "Pillow (already installed)"
else
    PILLOW_OK=0
    for attempt in \
        "--no-binary :all: --break-system-packages" \
        "--no-binary :all:" \
        "--break-system-packages" \
        "--break-system-packages --extra-index-url https://www.piwheels.org/simple"; do
        if "$PY_BIN" -m pip install "Pillow>=10.0.0" $attempt \
            --quiet --no-warn-script-location >> "$LOG" 2>&1; then
            log_ok "Pillow ($attempt)"
            PILLOW_OK=1; INSTALLED=$((INSTALLED+1)); break
        fi
    done
    [ $PILLOW_OK -eq 0 ] && log_err "Pillow -- ALL attempts failed (REQUIRED)"
fi

pip_smart "pytesseract>=0.3.10" 1

# reportlab needs libfreetype6-dev (installed in step 6)
log_info "Installing reportlab from source (requires libfreetype6-dev)"
if "$PY_BIN" -m pip show reportlab > /dev/null 2>&1; then
    log_skip "reportlab (already installed)"
else
    REPORTLAB_OK=0
    for attempt in \
        "--no-binary :all: --break-system-packages" \
        "--no-binary :all:" \
        "--break-system-packages" \
        "--break-system-packages --extra-index-url https://www.piwheels.org/simple"; do
        if "$PY_BIN" -m pip install "reportlab>=4.0.0" $attempt \
            --quiet --no-warn-script-location >> "$LOG" 2>&1; then
            log_ok "reportlab ($attempt)"
            REPORTLAB_OK=1; INSTALLED=$((INSTALLED+1)); break
        fi
    done
    [ $REPORTLAB_OK -eq 0 ] && log_err "reportlab -- ALL attempts failed (REQUIRED)"
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 12 — Security / crypto  [REQUIRED]
# ══════════════════════════════════════════════════════════════════════════════
log_step "12/16" "Security / crypto [REQUIRED]"
for p in "cryptography>=41.0.0" "pyotp" "pyjwt" "bcrypt"; do
    pip_smart "$p" 1
done
# sha3 package is dead/py3.14-incompatible — stdlib hashlib covers it natively
log_info "sha3 -- stdlib hashlib.sha3_256() covers this natively in Python 3.14, skipping"
log_skip "sha3 (Python 3.14 hashlib built-in replacement)"

# ══════════════════════════════════════════════════════════════════════════════
# STEP 13 — System monitoring + data  [REQUIRED]
# ══════════════════════════════════════════════════════════════════════════════
log_step "13/16" "System monitoring + data [REQUIRED]"

pip_smart "psutil>=5.9.0" 1

# numpy — optional, trader degrades gracefully without it
pip_smart "numpy" 0

# HAS_PANDAS=False fallback is built in, Zeus runs fine without it
log_skip "pandas (not required -- trader has built-in HAS_PANDAS=False fallback)"

# scipy / scikit-learn — optional, no direct Zeus imports
for p in "scipy" "scikit-learn"; do
    pip_smart "$p" 0
done

# ══════════════════════════════════════════════════════════════════════════════
# STEP 14 — NLP / TTS / trading  [REQUIRED]
# ══════════════════════════════════════════════════════════════════════════════
log_step "14/16" "NLP / TTS / trading [REQUIRED]"

for p in "vaderSentiment" "gTTS>=2.5.0" "plyer"; do
    pip_smart "$p" 1
done

pip_smart "ccxt" 1

# pandas-ta blocked by numba on py3.14 — use 'ta' library as direct replacement
# 'ta' provides identical RSI/MACD/etc. indicators, pure Python, py3.14 safe
log_info "pandas-ta is blocked on Python 3.14 (numba dependency) -- installing 'ta' as replacement"
log_info "'ta' provides RSI, MACD, Bollinger Bands, EMA, SMA, etc. -- functionally equivalent"
pip_smart "ta" 1

# ══════════════════════════════════════════════════════════════════════════════
# STEP 15 — Miners
# ══════════════════════════════════════════════════════════════════════════════

# ── XMRig ─────────────────────────────────────────────────────────────────────
log_step "15a/16" "XMRig (RandomX CPU miner)"
if [ $OPT_NO_MINERS -eq 1 ]; then
    log_skip "XMRig -- --no-miners flag set"
else
    XMRIG_DEST="$BIN_DIR/xmrig"
    XMRIG_VER="6.22.0"

    if [ -f "$XMRIG_DEST" ]; then
        log_skip "XMRig already installed at $XMRIG_DEST"
    else
        BUILD_OK=0
        XMRIG_SRC="$TMP_DIR/xmrig_src"
        log_info "Cloning XMRig source (--depth 1)..."
        if git clone --depth=1 https://github.com/xmrig/xmrig.git "$XMRIG_SRC" >> "$LOG" 2>&1; then
            mkdir -p "$XMRIG_SRC/build"
            cd "$XMRIG_SRC/build"
            log_info "cmake configure (armv7l: no hwloc/opencl/cuda/asm/avx, donate=0)..."
            if cmake .. \
                -DCMAKE_BUILD_TYPE=Release \
                -DXMRIG_DONATE_LEVEL=0 \
                -DWITH_HWLOC=OFF \
                -DWITH_OPENCL=OFF \
                -DWITH_CUDA=OFF \
                -DWITH_ASM=OFF \
                -DWITH_AVX=OFF \
                >> "$LOG" 2>&1; then
                log_info "Compiling XMRig with $BUILD_JOBS jobs (5-30 min on armv7l)..."
                if make -j"$BUILD_JOBS" >> "$LOG" 2>&1 && [ -f "$XMRIG_SRC/build/xmrig" ]; then
                    cp "$XMRIG_SRC/build/xmrig" "$XMRIG_DEST"
                    chmod +x "$XMRIG_DEST"
                    log_ok "XMRig built from source → $XMRIG_DEST"
                    BUILD_OK=1
                else
                    log_warn "XMRig make finished but binary not found -- trying pre-built"
                fi
            else
                log_warn "XMRig cmake configure failed -- trying pre-built armv7l binary"
            fi
            cd "$SCRIPT_DIR"
        else
            log_warn "XMRig git clone failed -- trying pre-built armv7l binary"
        fi

        if [ $BUILD_OK -eq 0 ]; then
            PREBUILT="xmrig-${XMRIG_VER}-linux-static-armv7.tar.gz"
            URL="https://github.com/xmrig/xmrig/releases/download/v${XMRIG_VER}/${PREBUILT}"
            log_info "Downloading pre-built XMRig armv7: $PREBUILT"
            wget -q -O "$TMP_DIR/$PREBUILT" "$URL" >> "$LOG" 2>&1 \
                || curl -L -o "$TMP_DIR/$PREBUILT" "$URL" >> "$LOG" 2>&1
            if [ -f "$TMP_DIR/$PREBUILT" ] && [ -s "$TMP_DIR/$PREBUILT" ]; then
                tar -xzf "$TMP_DIR/$PREBUILT" -C "$TMP_DIR" >> "$LOG" 2>&1
                FOUND="$(find "$TMP_DIR" -name 'xmrig' -type f | grep -v src | head -1)"
                if [ -n "$FOUND" ]; then
                    cp "$FOUND" "$XMRIG_DEST"
                    chmod +x "$XMRIG_DEST"
                    log_ok "XMRig pre-built armv7 installed → $XMRIG_DEST"
                else
                    log_err "XMRig binary not found in archive"
                fi
            else
                log_err "XMRig pre-built download failed"
            fi
        fi
    fi
fi

# ── cpuminer-multi ────────────────────────────────────────────────────────────
log_step "15b/16" "cpuminer-multi (multi-algo CPU miner)"
if [ $OPT_NO_MINERS -eq 1 ]; then
    log_skip "cpuminer-multi -- --no-miners flag set"
else
    CPUMINER_DEST="$BIN_DIR/cpuminer-multi"

    if [ -f "$CPUMINER_DEST" ]; then
        log_skip "cpuminer-multi already installed at $CPUMINER_DEST"
    else
        CPU_SRC="$TMP_DIR/cpuminer_src"
        log_info "Cloning cpuminer-multi source (--depth 1)..."
        if git clone --depth=1 https://github.com/tpruvot/cpuminer-multi.git "$CPU_SRC" >> "$LOG" 2>&1; then
            cd "$CPU_SRC"
            log_info "Running autogen..."
            [ -f "./autogen.sh" ] && ./autogen.sh >> "$LOG" 2>&1 \
                || autoreconf --install >> "$LOG" 2>&1 || true
            log_info "Configure (--with-crypto --with-curl --disable-assembly)..."
            if ./configure --with-crypto --with-curl --disable-assembly >> "$LOG" 2>&1; then
                log_info "Compiling cpuminer-multi with $BUILD_JOBS jobs..."
                make -j"$BUILD_JOBS" >> "$LOG" 2>&1
                if [ -f "$CPU_SRC/cpuminer" ]; then
                    cp "$CPU_SRC/cpuminer" "$CPUMINER_DEST"
                    chmod +x "$CPUMINER_DEST"
                    log_ok "cpuminer-multi built → $CPUMINER_DEST"
                else
                    log_err "cpuminer-multi binary not found after build"
                fi
            else
                log_err "cpuminer-multi configure failed"
            fi
            cd "$SCRIPT_DIR"
        else
            log_err "cpuminer-multi git clone failed"
        fi
    fi
fi

# ══════════════════════════════════════════════════════════════════════════════
# STEP 16 — Upgrade ALL installed packages to latest
# ══════════════════════════════════════════════════════════════════════════════
log_step "16/16" "Upgrading ALL installed packages to latest"

# Get full list of installed pip packages
INSTALLED_PKGS="$("$PY_BIN" -m pip list --format=freeze 2>/dev/null | cut -d= -f1)"

UPGRADE_COUNT=0
TOTAL_PKGS=$(echo "$INSTALLED_PKGS" | wc -l)
log_info "Found $TOTAL_PKGS installed packages to check for upgrades..."

for pkg in $INSTALLED_PKGS; do
    [ -z "$pkg" ] && continue
    UPGRADE_COUNT=$((UPGRADE_COUNT+1))
    log_info "[$UPGRADE_COUNT/$TOTAL_PKGS] Checking: $pkg"
    pip_upgrade "$pkg"
done

# Final chmod +x
log_info "chmod +x all .py .sh scripts..."
find "$SCRIPT_DIR" -type f \( -name "*.py" -o -name "*.sh" -o -name "*.bash" \) \
    -exec chmod +x {} \;
[ -d "$BIN_DIR" ] && find "$BIN_DIR" -type f -exec chmod +x {} \;
EXEC_COUNT=$(find "$SCRIPT_DIR" -type f \( -name "*.py" -o -name "*.sh" \) | wc -l)
log_ok "$EXEC_COUNT scripts made executable"

rm -rf "$TMP_DIR"

# ── Final summary ─────────────────────────────────────────────────────────────
get_ver() { "$PY_BIN" -c "import $1; print($1.__version__)" 2>/dev/null || echo "—"; }

echo "" | tee -a "$LOG"
echo -e "${BLD}${GRN}  ╔══════════════════════════════════════════════════════════════╗${RST}" | tee -a "$LOG"
echo -e "${BLD}${GRN}  ║   ZEUS ARMv7l INSTALL + UPGRADE COMPLETE                    ║${RST}" | tee -a "$LOG"
echo -e "${BLD}${GRN}  ╚══════════════════════════════════════════════════════════════╝${RST}" | tee -a "$LOG"
echo "" | tee -a "$LOG"
echo -e "  ${CYN}Architecture   :${RST} $ARCH"                                           | tee -a "$LOG"
echo -e "  ${CYN}Python         :${RST} $("$PY_BIN" --version 2>&1)"                     | tee -a "$LOG"
echo -e "  ${CYN}flask          :${RST} $(get_ver flask)"                                | tee -a "$LOG"
echo -e "  ${CYN}numpy          :${RST} $(get_ver numpy)"                                | tee -a "$LOG"
echo -e "  ${CYN}pandas         :${RST} not installed (not required)"                      | tee -a "$LOG"
echo -e "  ${CYN}cryptography   :${RST} $(get_ver cryptography)"                         | tee -a "$LOG"
echo -e "  ${CYN}groq           :${RST} $(get_ver groq)"                                 | tee -a "$LOG"
echo -e "  ${CYN}requests       :${RST} $(get_ver requests)"                             | tee -a "$LOG"
echo -e "  ${CYN}ccxt           :${RST} $(get_ver ccxt)"                                 | tee -a "$LOG"
echo -e "  ${CYN}ta             :${RST} $(get_ver ta)"                                   | tee -a "$LOG"
echo -e "  ${CYN}Pillow         :${RST} $(get_ver PIL)"                                  | tee -a "$LOG"
echo -e "  ${CYN}reportlab      :${RST} $(get_ver reportlab)"                            | tee -a "$LOG"
echo -e "  ${CYN}xmrig          :${RST} $([ -f "$BIN_DIR/xmrig" ]          && echo "✓ $BIN_DIR/xmrig"          || echo "not installed")" | tee -a "$LOG"
echo -e "  ${CYN}cpuminer-multi :${RST} $([ -f "$BIN_DIR/cpuminer-multi" ] && echo "✓ $BIN_DIR/cpuminer-multi" || echo "not installed")" | tee -a "$LOG"
echo "" | tee -a "$LOG"
echo -e "  ${CYN}Installed      :${RST} $INSTALLED"   | tee -a "$LOG"
echo -e "  ${CYN}Upgraded       :${RST} $UPGRADED"    | tee -a "$LOG"
echo -e "  ${CYN}Skipped        :${RST} $SKIPPED"     | tee -a "$LOG"
echo -e "  ${CYN}Warnings       :${RST} $WARNS"       | tee -a "$LOG"
echo -e "  ${CYN}Errors         :${RST} $ERRORS"      | tee -a "$LOG"
echo -e "  ${CYN}Log            :${RST} $LOG"          | tee -a "$LOG"
echo "" | tee -a "$LOG"

if [ "$ERRORS" -eq 0 ]; then
    echo -e "  ${GRN}${BLD}✓  All steps completed successfully.${RST}" | tee -a "$LOG"
else
    echo -e "  ${YEL}${BLD}⚠  $ERRORS error(s) -- check $LOG${RST}" | tee -a "$LOG"
fi

echo "" | tee -a "$LOG"
echo -e "  ${CYN}Next steps:${RST}"                                                      | tee -a "$LOG"
echo -e "    cd 02_zeus_arch && gunicorn wsgi_zeus:app -b 0.0.0.0:8080"                  | tee -a "$LOG"
echo -e "    cd 03_ump       && gunicorn wsgi:app      -b 0.0.0.0:8080"                  | tee -a "$LOG"
echo "" | tee -a "$LOG"
