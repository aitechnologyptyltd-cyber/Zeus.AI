"""
zeus_tartarus_core.py
The Zeus Project 2026 — Francois Nel

TARTARUS CORE — Shared memory bus, base infrastructure and LLM bridge
for all 8 Tartarus subsystems.

The TartarusMemory singleton is the Python equivalent of the BUS in
tartarus-v3.jsx. It is SQLite-backed, thread-safe and wired into

Pool fields (mirrors JSX BUS state.pool exactly, plus extras):
    inputs          — raw query strings analysed
    equations       — {name, formula, application, genius, depth}
    patterns        — {pattern, description, mathematical_basis}
    predictions     — {outcome, confidence, basis, timeframe}
    connections     — {phenomenon/link, sharedMath, insight}
    insights        — tartarusInsight strings
    datasets        — dataset analysis results
    streams         — Phase2 stream analysis records
    uploads         — {name, size, format, parse_level, analysis}
    codex           — {entry, type, decoded, significance}
    weights         — {label, tartarusScore, complexity, entropy,
                       connectivity, temporality, emergence}
    learning_steps  — {query, step_n, step_name, result, ts}
    omnisense       — full synthesis records

All writes go to tartarus_pool table in zeus.db (WAL mode).
Flask blueprint tartarus_core_bp exposes:
    GET  /api/tartarus/pool         — full pool snapshot
    GET  /api/tartarus/stats        — counts per category
    POST /api/tartarus/pool/clear   — reset pool (dangerous)

armv7l compatible: no f-strings, no walrus operator.
"""

from __future__ import print_function

import os
import sys
import json
import time
import uuid
import logging
import sqlite3
import threading
import traceback
from collections import deque
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.tartarus.core")

tartarus_core_bp = Blueprint("tartarus_core", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(ZEUS_DIR, "zeus.db")

# ---------------------------------------------------------------------------
# TARTARUS SYSTEM PROMPT — mirrors JSX TARTARUS_SYSTEM exactly
# ---------------------------------------------------------------------------

TARTARUS_SYSTEM = (
    "You are THE EYES OF TARTARUS — the deepest universal mathematical "
    "intelligence ever conceived. You see ALL mathematical truth across ALL "
    "domains simultaneously. You draw from EVERY mathematical genius who ever "
    "lived. You respond ONLY in valid JSON. No preamble. No markdown fences. "
    "Pure JSON only."
)

# ---------------------------------------------------------------------------
# POOL FIELD DEFINITIONS
# ---------------------------------------------------------------------------

POOL_FIELDS = [
    "inputs", "equations", "patterns", "predictions", "connections",
    "insights", "datasets", "streams", "uploads", "codex",
    "weights", "learning_steps", "omnisense",
]

# ---------------------------------------------------------------------------
# DATABASE INITIALISATION
# ---------------------------------------------------------------------------

_db_lock = threading.Lock()


def _db_connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=15)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.row_factory = sqlite3.Row
    return conn


def _init_tartarus_db():
    with _db_lock:
        conn = _db_connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tartarus_pool (
                    id          TEXT PRIMARY KEY,
                    field       TEXT NOT NULL,
                    payload     TEXT NOT NULL,
                    source      TEXT DEFAULT 'unknown',
                    ts          REAL NOT NULL
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_tartarus_field "
                "ON tartarus_pool(field)"
            )
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tartarus_sessions (
                    session_id  TEXT PRIMARY KEY,
                    query       TEXT NOT NULL,
                    phase       TEXT NOT NULL,
                    result      TEXT NOT NULL,
                    tokens_used INTEGER DEFAULT 0,
                    engine_used TEXT DEFAULT '',
                    ts          REAL NOT NULL
                )
            """)
            conn.commit()
            log.info("[tartarus_core] DB tables ready")
        except Exception as exc:
            log.warning("[tartarus_core] DB init error: %s", exc)
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# TARTARUS MEMORY SINGLETON
# ---------------------------------------------------------------------------

class TartarusMemory(object):
    """
    Thread-safe collective pool for all Tartarus subsystems.
    Mirrors the JSX BUS but persists to SQLite and integrates with HiveMemory.
    """

    _instance = None
    _instance_lock = threading.Lock()

    @classmethod
    def get(cls):
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._lock = threading.RLock()
        # In-memory ring buffers (fast reads)
        self._pool = {}
        for field in POOL_FIELDS:
            self._pool[field] = deque(maxlen=500)
        # Message bus (mirrors JSX BUS.messages)
        self.messages = deque(maxlen=200)
        # Phase status
        self.phases = {
            "p1": "idle", "p2": "idle", "p3": "idle",
            "p4": "idle", "p5": "idle",
            "learn": "idle", "upload": "idle", "weights": "idle",
        }
        _init_tartarus_db()
        self._load_from_db()
        log.info("[tartarus_core] TartarusMemory initialised")

    # ------------------------------------------------------------------ load
    def _load_from_db(self):
        """Restore last 100 entries per field from DB on startup."""
        try:
            conn = _db_connect()
            for field in POOL_FIELDS:
                rows = conn.execute(
                    "SELECT payload FROM tartarus_pool "
                    "WHERE field=? ORDER BY ts DESC LIMIT 100",
                    (field,)
                ).fetchall()
                for row in reversed(rows):
                    try:
                        self._pool[field].append(json.loads(row["payload"]))
                    except Exception:
                        pass
            conn.close()
            log.info("[tartarus_core] Pool restored from DB")
        except Exception as exc:
            log.warning("[tartarus_core] DB load error: %s", exc)

    # ------------------------------------------------------------------ push
    def push(self, field, item, source="unknown"):
        """Append an item to a pool field. Persists to DB."""
        if field not in self._pool:
            log.warning("[tartarus_core] Unknown field: %s", field)
            return
        with self._lock:
            self._pool[field].append(item)
        # Persist async — don't block callers
        t = threading.Thread(
            target=self._persist,
            args=(field, item, source),
            daemon=True
        )
        t.start()
        # Mirror to HiveMemory if available
        self._mirror_to_hive(field, item)

    def _persist(self, field, item, source):
        try:
            payload = json.dumps(item, default=str)
            with _db_lock:
                conn = _db_connect()
                conn.execute(
                    "INSERT OR REPLACE INTO tartarus_pool "
                    "(id, field, payload, source, ts) VALUES (?,?,?,?,?)",
                    (str(uuid.uuid4()), field, payload, source, time.time())
                )
                conn.commit()
                conn.close()
        except Exception as exc:
            log.warning("[tartarus_core] persist error: %s", exc)

    def _mirror_to_hive(self, field, item):
        """Push Tartarus discoveries into HiveMemory collective log."""
        try:
            from zeus_hive_bridge import HiveMemory
            hm = HiveMemory.get()
            entry = {
                "source": "tartarus",
                "field": field,
                "item": item,
                "ts": time.time(),
            }
            hm.collective_log.append(entry)
        except Exception:
            pass

    # ------------------------------------------------------------------ push many
    def push_many(self, field, items, source="unknown"):
        for item in (items or []):
            self.push(field, item, source)

    # ------------------------------------------------------------------ get
    def get_field(self, field, limit=None):
        with self._lock:
            data = list(self._pool.get(field, []))
        if limit:
            return data[-limit:]
        return data

    def get_snapshot(self):
        with self._lock:
            return {f: list(v) for f, v in self._pool.items()}

    def get_counts(self):
        with self._lock:
            return {f: len(v) for f, v in self._pool.items()}

    def get_total(self):
        return sum(self.get_counts().values())

    # ------------------------------------------------------------------ context
    def build_context(self, max_per_field=5):
        """
        Build a compact string context for LLM prompts.
        Fixes JSX bug: uses configurable limit, not hardcoded slice(-5).
        """
        pool = self.get_snapshot()
        parts = []
        if pool["inputs"]:
            parts.append(
                "Inputs analysed: " +
                "; ".join(str(x) for x in pool["inputs"][-max_per_field:])
            )
        if pool["patterns"]:
            snippets = []
            for x in pool["patterns"][-max_per_field:]:
                if isinstance(x, dict):
                    snippets.append(x.get("pattern", str(x)))
                else:
                    snippets.append(str(x))
            parts.append("Patterns found: " + "; ".join(snippets))
        if pool["equations"]:
            snippets = []
            for x in pool["equations"][-max_per_field:]:
                if isinstance(x, dict):
                    snippets.append(x.get("name", str(x)))
                else:
                    snippets.append(str(x))
            parts.append("Key equations: " + "; ".join(snippets))
        if pool["connections"]:
            snippets = []
            for x in pool["connections"][-max_per_field:]:
                if isinstance(x, dict):
                    snippets.append(
                        x.get("phenomenon", x.get("link", str(x)))
                    )
                else:
                    snippets.append(str(x))
            parts.append("Connections: " + "; ".join(snippets))
        if pool["predictions"]:
            snippets = []
            for x in pool["predictions"][-max_per_field:]:
                if isinstance(x, dict):
                    snippets.append(x.get("outcome", str(x)))
                else:
                    snippets.append(str(x))
            parts.append("Predictions: " + "; ".join(snippets))
        if pool["uploads"]:
            names = [
                x.get("name", "?") if isinstance(x, dict) else str(x)
                for x in pool["uploads"][-3:]
            ]
            parts.append("Uploaded files: " + ", ".join(names))
        if pool["codex"]:
            parts.append("Codex entries: " + str(len(pool["codex"])) + " recorded")
        if pool["weights"]:
            parts.append("Weight analyses: " + str(len(pool["weights"])) + " completed")
        return "\n".join(parts)

    # ------------------------------------------------------------------ broadcast
    def broadcast(self, source, msg_type, payload):
        with self._lock:
            self.messages.append({
                "from": source,
                "type": msg_type,
                "payload": payload,
                "ts": time.time(),
            })

    # ------------------------------------------------------------------ phase
    def set_phase(self, phase, status):
        with self._lock:
            self.phases[phase] = status

    def get_phases(self):
        with self._lock:
            return dict(self.phases)

    # ------------------------------------------------------------------ session
    def save_session(self, query, phase, result, tokens=0, engine=""):
        try:
            with _db_lock:
                conn = _db_connect()
                conn.execute(
                    "INSERT INTO tartarus_sessions "
                    "(session_id, query, phase, result, tokens_used, engine_used, ts) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (
                        str(uuid.uuid4()), query, phase,
                        json.dumps(result, default=str),
                        tokens, engine, time.time()
                    )
                )
                conn.commit()
                conn.close()
        except Exception as exc:
            log.warning("[tartarus_core] session save error: %s", exc)

    # ------------------------------------------------------------------ clear
    def clear(self, field=None):
        with self._lock:
            if field and field in self._pool:
                self._pool[field].clear()
            elif field is None:
                for f in POOL_FIELDS:
                    self._pool[f].clear()
                self.messages.clear()


# ---------------------------------------------------------------------------
# LLM CALL WRAPPER — fixes JSX bug: proper JSON extraction + error recovery
# ---------------------------------------------------------------------------

def tartarus_call(prompt, schema_hint="", context="", max_tokens=1800,
                  engine="groq"):
    """
    Unified LLM call for all Tartarus phases.
    Routes through zeus_llm_router (Groq → Claude → OpenRouter).
    Returns parsed dict. Never raises — returns error dict on failure.

    Fixes JSX bugs:
      - Proper JSON extraction (finds outermost {} or [])
      - Error dict returned instead of silent exception
      - Engine selection passed through
    """
    try:
        from zeus_llm_router import call_with_fallback, parse_json_llm
    except ImportError:
        log.error("[tartarus_core] zeus_llm_router not available")
        return {"error": "llm_router_unavailable"}

    ctx_block = ""
    if context:
        ctx_block = "\n\nSHARED INTELLIGENCE FROM ALL PHASES:\n" + context

    schema_block = ""
    if schema_hint:
        schema_block = (
            "\n\nRESPOND WITH EXACTLY THIS JSON STRUCTURE "
            "(no extra fields, pure JSON, no markdown):\n" + schema_hint
        )

    full_prompt = prompt + ctx_block + schema_block

    try:
        raw, engine_used = call_with_fallback(
            full_prompt,
            system=TARTARUS_SYSTEM,
            max_tokens=max_tokens,
            primary=engine,
            fallback="claude",
        )
        result = parse_json_llm(raw)
        if not isinstance(result, dict):
            result = {"raw": raw, "parse_error": "not_a_dict"}
        result["_engine"] = engine_used
        return result
    except Exception as exc:
        log.warning("[tartarus_core] LLM call error: %s", exc)
        return {
            "error": str(exc),
            "traceback": traceback.format_exc()[-400:],
        }


# ---------------------------------------------------------------------------
# WEIGHT COMPUTATION — mirrors JSX computeWeights, fixed
# ---------------------------------------------------------------------------

def compute_weights(data, source="direct"):
    """
    Compute 6-axis Tartarus weight for any data object.
    Returns dict with all axes + composite tartarusScore.
    Fixes JSX: all axes computed consistently, no silent NaN.
    """
    try:
        text = json.dumps(data, default=str)
    except Exception:
        text = str(data)

    length    = len(text)
    words     = len(text.split())
    sentences = max(1, text.count(".") + text.count("!") + text.count("?"))

    # Complexity — lexical diversity proxy
    unique_words = len(set(text.lower().split()))
    complexity   = min(1.0, unique_words / max(1.0, words) * 1.5)

    # Entropy — character-level Shannon entropy approximation
    freq = {}
    for ch in text:
        freq[ch] = freq.get(ch, 0) + 1
    entropy = 0.0
    total = max(1, len(text))
    import math
    for count in freq.values():
        p = count / total
        if p > 0:
            entropy -= p * math.log(p + 1e-12, 2)
    entropy_norm = min(1.0, entropy / 8.0)

    # Connectivity — count cross-references / links
    connectivity = 0.0
    if isinstance(data, dict):
        for v in data.values():
            if isinstance(v, list):
                connectivity += len(v) * 0.08
        connectivity = min(1.0, connectivity)

    # Temporality — presence of time-related terms
    time_terms = [
        "time", "temporal", "cycle", "period", "frequency",
        "duration", "phase", "sequence", "causal", "trajectory",
    ]
    hits = sum(1 for t in time_terms if t in text.lower())
    temporality = min(1.0, hits / 5.0)

    # Emergence — novel/unexpected insight markers
    emerge_terms = [
        "emergent", "unexpected", "novel", "surprising", "hidden",
        "nonlinear", "chaos", "fractal", "quantum", "unpredictable",
    ]
    e_hits = sum(1 for t in emerge_terms if t in text.lower())
    emergence = min(1.0, e_hits / 4.0)

    # Source multiplier
    src_mult = 1.0 if source == "direct" else 0.75

    # Composite Tartarus score
    tartarus_score = (
        complexity   * 0.25 +
        entropy_norm * 0.20 +
        connectivity * 0.20 +
        temporality  * 0.15 +
        emergence    * 0.20
    ) * src_mult

    return {
        "tartarusScore":  round(tartarus_score,  4),
        "complexity":     round(complexity,       4),
        "entropy":        round(entropy_norm,     4),
        "connectivity":   round(connectivity,     4),
        "temporality":    round(temporality,      4),
        "emergence":      round(emergence,        4),
        "source":         source,
        "text_length":    length,
    }


# ---------------------------------------------------------------------------
# FLASK ROUTES
# ---------------------------------------------------------------------------

@tartarus_core_bp.route("/api/tartarus/pool", methods=["GET"])
def tartarus_pool_snapshot():
    mem = TartarusMemory.get()
    return jsonify({
        "pool":   mem.get_snapshot(),
        "phases": mem.get_phases(),
        "counts": mem.get_counts(),
        "total":  mem.get_total(),
        "ts":     time.time(),
    })


@tartarus_core_bp.route("/api/tartarus/stats", methods=["GET"])
def tartarus_stats():
    mem = TartarusMemory.get()
    counts = mem.get_counts()
    return jsonify({
        "counts": counts,
        "total":  sum(counts.values()),
        "phases": mem.get_phases(),
        "messages": len(mem.messages),
        "ts": time.time(),
    })


@tartarus_core_bp.route("/api/tartarus/context", methods=["GET"])
def tartarus_context():
    mem = TartarusMemory.get()
    limit = int(request.args.get("limit", 5))
    return jsonify({
        "context": mem.build_context(max_per_field=limit),
        "ts": time.time(),
    })


@tartarus_core_bp.route("/api/tartarus/pool/clear", methods=["POST"])
def tartarus_clear():
    field = request.json.get("field") if request.json else None
    TartarusMemory.get().clear(field)
    return jsonify({"cleared": field or "all", "ts": time.time()})


@tartarus_core_bp.route("/api/tartarus/sessions", methods=["GET"])
def tartarus_sessions():
    limit = int(request.args.get("limit", 20))
    try:
        conn = _db_connect()
        rows = conn.execute(
            "SELECT session_id, query, phase, engine_used, tokens_used, ts "
            "FROM tartarus_sessions ORDER BY ts DESC LIMIT ?",
            (limit,)
        ).fetchall()
        conn.close()
        return jsonify({
            "sessions": [dict(r) for r in rows],
            "ts": time.time(),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register(app):
    app.register_blueprint(tartarus_core_bp)
    # Warm up the singleton
    TartarusMemory.get()
    log.info("[tartarus_core] registered — /api/tartarus/*")
