# zeus_refactoring_engine.py
# The Zeus Project 2026 — Francois Nel
# SAFETY-GATED REFACTORING ENGINE
# Analyzes code and applies safe refactorings with automatic rollback

import os
import re
import ast
import shutil
import logging
import time
import threading
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
import sqlite3

log = logging.getLogger("zeus.refactor")


class CodeSmellDetector:
    """
    Analyzes code for quality issues and complexity problems.
    Detects patterns that indicate refactoring opportunities.
    """
    
    MONOLITHIC_LOC_THRESHOLD = 1500
    HIGH_COMPLEXITY_THRESHOLD = 15
    LONG_FUNCTION_THRESHOLD = 200
    
    @staticmethod
    def scan_file(filepath: str) -> Dict[str, Any]:
        """Analyze a single Python file."""
        if not os.path.exists(filepath):
            return {"error": "file not found", "path": filepath}
        
        try:
            with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                source = f.read()
            
            lines = source.splitlines()
            loc = len(lines)
            
            metrics = {
                "file": os.path.basename(filepath),
                "path": filepath,
                "loc": loc,
                "functions": 0,
                "classes": 0,
                "complexity": 0,
                "issues": [],
                "refactor_suggestions": []
            }
            
            # Parse AST
            tree = ast.parse(source)
            
            # Count constructs
            functions = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
            classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
            
            metrics["functions"] = len(functions)
            metrics["classes"] = len(classes)
            
            # Calculate cyclomatic complexity (simplified)
            complexity = CodeSmellDetector._calculate_complexity(tree)
            metrics["complexity"] = complexity
            
            # Detect issues
            if loc > CodeSmellDetector.MONOLITHIC_LOC_THRESHOLD:
                metrics["issues"].append(f"MONOLITHIC_FILE ({loc} lines > {CodeSmellDetector.MONOLITHIC_LOC_THRESHOLD})")
                metrics["refactor_suggestions"].append({
                    "type": "split_module",
                    "description": f"File is {loc} lines. Split into smaller modules.",
                    "priority": "HIGH"
                })
            
            if len(functions) > 50:
                metrics["issues"].append(f"HIGH_FUNCTION_COUNT ({len(functions)} > 50)")
                metrics["refactor_suggestions"].append({
                    "type": "extract_helpers",
                    "description": "Too many functions. Extract related functions to new modules.",
                    "priority": "MEDIUM"
                })
            
            if len(classes) > 15:
                metrics["issues"].append(f"HIGH_CLASS_COUNT ({len(classes)} > 15)")
            
            if complexity > 20:
                metrics["issues"].append(f"HIGH_COMPLEXITY ({complexity} > 20)")
                metrics["refactor_suggestions"].append({
                    "type": "reduce_complexity",
                    "description": "Refactor to reduce cyclomatic complexity.",
                    "priority": "MEDIUM"
                })
            
            # Check for long functions
            long_functions = [f for f in functions 
                            if (f.end_lineno or f.lineno) - f.lineno > CodeSmellDetector.LONG_FUNCTION_THRESHOLD]
            if long_functions:
                metrics["issues"].append(f"LONG_FUNCTIONS ({len(long_functions)} > {CodeSmellDetector.LONG_FUNCTION_THRESHOLD} lines)")
                for func in long_functions:
                    metrics["refactor_suggestions"].append({
                        "type": "extract_function",
                        "function": func.name,
                        "lines": (func.end_lineno or func.lineno) - func.lineno,
                        "description": f"Function '{func.name}' is {(func.end_lineno or func.lineno) - func.lineno} lines long.",
                        "priority": "MEDIUM"
                    })
            
        except SyntaxError as e:
            metrics["error"] = f"Syntax error: {e}"
            metrics["issues"].append(f"SYNTAX_ERROR: {e}")
        except Exception as e:
            metrics["error"] = f"Parse error: {e}"
            metrics["issues"].append(f"PARSE_ERROR: {e}")
        
        return metrics
    
    @staticmethod
    def _calculate_complexity(tree: ast.AST) -> int:
        """Calculate cyclomatic complexity (simplified)."""
        complexity = 1
        
        for node in ast.walk(tree):
            if isinstance(node, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(node, ast.BoolOp):
                complexity += 1
        
        return complexity
    
    @staticmethod
    def scan_directory(directory: str = ".") -> List[Dict]:
        """Scan all Python files in directory."""
        results = []
        
        skip_dirs = {"__pycache__", ".git", "venv", ".venv", "node_modules", ".pytest_cache"}
        
        for root, dirs, files in os.walk(directory):
            # Remove skip directories
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            
            for file in files:
                if file.endswith(".py"):
                    fpath = os.path.join(root, file)
                    result = CodeSmellDetector.scan_file(fpath)
                    results.append(result)
        
        return sorted(results, key=lambda x: x.get("loc", 0), reverse=True)


class RefactoringEngine:
    """
    Safely refactors code with automatic rollback on test failure.
    Acts as the system's surgeon with a safety net.
    """
    
    def __init__(self, test_feedback_bridge=None):
        self.test_feedback_bridge = test_feedback_bridge
        self.backup_dir = Path("refactor_backups")
        self.backup_dir.mkdir(exist_ok=True)
        self.db_path = "refactoring_history.db"
        self._init_db()
        self._lock = threading.RLock()
    
    def _init_db(self):
        """Initialize refactoring history database."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        c.execute("""
            CREATE TABLE IF NOT EXISTS refactoring_operations (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                filepath TEXT,
                refactor_type TEXT,
                description TEXT,
                backup_path TEXT,
                status TEXT,
                tests_passed BOOLEAN,
                impact_score REAL,
                rollback_count INTEGER
            )
        """)
        
        conn.commit()
        conn.close()
    
    # ===== BACKUP & ROLLBACK =====
    
    def _create_backup(self, filepath: str) -> str:
        """Create timestamped backup of file."""
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filename = Path(filepath).name
        backup_path = self.backup_dir / f"{filename}.{timestamp}.bak"
        
        shutil.copy2(filepath, backup_path)
        log.info(f"[refactor] Backup created: {backup_path}")
        
        return str(backup_path)
    
    def _rollback(self, filepath: str, backup_path: str) -> bool:
        """Restore file from backup."""
        try:
            shutil.copy2(backup_path, filepath)
            log.info(f"[refactor] Rolled back {filepath} from {backup_path}")
            return True
        except Exception as e:
            log.error(f"[refactor] Rollback failed: {e}")
            return False
    
    # ===== REFACTORING OPERATIONS =====
    
    def extract_function(self, source_file: str, function_name: str, 
                        target_module: str) -> Dict:
        """
        Extract a function to a new module.
        Safety: Creates backup, runs tests, rolls back on failure.
        """
        with self._lock:
            result = {
                "status": "pending",
                "operation": "extract_function",
                "source_file": source_file,
                "function_name": function_name,
                "target_module": target_module,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "tests_passed": False,
                "backup_path": ""
            }
            
            if not os.path.exists(source_file):
                result["status"] = "failed"
                result["error"] = "Source file not found"
                return result
            
            # Step 1: Backup
            backup_path = self._create_backup(source_file)
            result["backup_path"] = backup_path
            
            # Step 2: Parse and extract
            try:
                with open(source_file, "r") as f:
                    source = f.read()
                
                tree = ast.parse(source)
                target_func = None
                
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef) and node.name == function_name:
                        target_func = node
                        break
                
                if not target_func:
                    result["status"] = "failed"
                    result["error"] = f"Function '{function_name}' not found"
                    return result
                
                # Generate new module
                new_module_path = os.path.join(
                    os.path.dirname(source_file),
                    f"{target_module}.py"
                )
                
                extracted_code = ast.unparse(target_func)
                new_code = f"""# Extracted from {os.path.basename(source_file)}
# By RefactoringEngine on {datetime.now().isoformat()}

{extracted_code}
"""
                
                with open(new_module_path, "w") as f:
                    f.write(new_code)
                
                result["new_module"] = new_module_path
                
            except Exception as e:
                result["status"] = "failed"
                result["error"] = f"Extraction failed: {e}"
                return result
            
            # Step 3: Run tests
            if self.test_feedback_bridge:
                log.info(f"[refactor] Running tests after extraction...")
                test_results = self.test_feedback_bridge.run_tests()
                tests_passed = test_results.get("success", False)
            else:
                # Assume tests pass if no feedback bridge
                tests_passed = True
            
            # Step 4: Rollback if tests failed
            if not tests_passed:
                log.warning(f"[refactor] Tests failed! Rolling back...")
                self._rollback(source_file, backup_path)
                if os.path.exists(new_module_path):
                    os.remove(new_module_path)
                
                result["status"] = "rolled_back"
                result["reason"] = "Tests failed after extraction"
                result["tests_passed"] = False
            else:
                result["status"] = "applied"
                result["tests_passed"] = True
                log.info(f"[refactor] Extraction successful and tests passed")
            
            # Step 5: Record in history
            self._record_operation(result)
            
            return result
    
    def split_large_file(self, filepath: str, max_lines: int = 1500) -> Dict:
        """
        Suggest and perform splits on large files.
        Splits by classes or function groups.
        """
        result = {
            "status": "pending",
            "operation": "split_file",
            "filepath": filepath,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "splits_created": [],
            "tests_passed": False
        }
        
        if not os.path.exists(filepath):
            result["status"] = "failed"
            result["error"] = "File not found"
            return result
        
        # Get file metrics
        metrics = CodeSmellDetector.scan_file(filepath)
        
        if metrics.get("loc", 0) <= max_lines:
            result["status"] = "not_needed"
            result["reason"] = f"File is only {metrics.get('loc')} lines"
            return result
        
        # Backup
        backup_path = self._create_backup(filepath)
        result["backup_path"] = backup_path
        
        try:
            with open(filepath, "r") as f:
                source = f.read()
            
            tree = ast.parse(source)
            
            # Split by classes
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    class_code = ast.unparse(node)
                    new_file = filepath.replace(".py", f"_{node.name}.py")
                    
                    with open(new_file, "w") as f:
                        f.write(class_code)
                    
                    result["splits_created"].append(new_file)
            
            # Run tests
            if self.test_feedback_bridge:
                test_results = self.test_feedback_bridge.run_tests()
                tests_passed = test_results.get("success", False)
            else:
                tests_passed = True
            
            if not tests_passed:
                self._rollback(filepath, backup_path)
                for split_file in result["splits_created"]:
                    if os.path.exists(split_file):
                        os.remove(split_file)
                
                result["status"] = "rolled_back"
                result["tests_passed"] = False
            else:
                result["status"] = "applied"
                result["tests_passed"] = True
        
        except Exception as e:
            result["status"] = "failed"
            result["error"] = str(e)
        
        self._record_operation(result)
        return result
    
    def _record_operation(self, operation: Dict):
        """Record refactoring operation in history."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        c.execute("""
            INSERT INTO refactoring_operations
            (timestamp, filepath, refactor_type, description, 
             backup_path, status, tests_passed)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            operation.get("timestamp"),
            operation.get("filepath") or operation.get("source_file"),
            operation.get("operation"),
            operation.get("reason") or operation.get("error", ""),
            operation.get("backup_path"),
            operation.get("status"),
            operation.get("tests_passed")
        ))
        
        conn.commit()
        conn.close()
    
    def get_refactoring_suggestions(self, filepath: str) -> List[Dict]:
        """Get refactoring suggestions for a file."""
        metrics = CodeSmellDetector.scan_file(filepath)
        return metrics.get("refactor_suggestions", [])
    
    def get_refactoring_history(self, filepath: Optional[str] = None) -> List[Dict]:
        """Get refactoring history."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        if filepath:
            c.execute("""
                SELECT * FROM refactoring_operations
                WHERE filepath = ?
                ORDER BY timestamp DESC
            """, (filepath,))
        else:
            c.execute("""
                SELECT * FROM refactoring_operations
                ORDER BY timestamp DESC
                LIMIT 50
            """)
        
        history = [dict(row) for row in c.fetchall()]
        conn.close()
        
        return history


# Flask integration
def create_refactoring_blueprint(refactoring_engine: Optional[RefactoringEngine] = None):
    """Create Flask blueprint for refactoring endpoints."""
    from flask import Blueprint, jsonify, request
    
    if refactoring_engine is None:
        refactoring_engine = RefactoringEngine()
    
    bp = Blueprint("refactoring", __name__, url_prefix="/api/refactor")
    
    @bp.route("/scan", methods=["GET"])
    def scan_codebase():
        """Scan codebase for code smells."""
        results = CodeSmellDetector.scan_directory()
        return jsonify({
            "total_files": len(results),
            "files_with_issues": [r for r in results if r.get("issues")],
            "top_files_by_loc": results[:10]
        })
    
    @bp.route("/suggest/<path:filepath>", methods=["GET"])
    def get_suggestions(filepath):
        """Get refactoring suggestions for a file."""
        suggestions = refactoring_engine.get_refactoring_suggestions(filepath)
        return jsonify({"file": filepath, "suggestions": suggestions})
    
    @bp.route("/extract", methods=["POST"])
    def extract_function():
        """Extract a function to new module."""
        data = request.json or {}
        source_file = data.get("source_file")
        function_name = data.get("function_name")
        target_module = data.get("target_module")
        
        if not all([source_file, function_name, target_module]):
            return jsonify({"error": "Missing required fields"}), 400
        
        result = refactoring_engine.extract_function(
            source_file, function_name, target_module
        )
        return jsonify(result)
    
    @bp.route("/split", methods=["POST"])
    def split_file():
        """Split a large file."""
        data = request.json or {}
        filepath = data.get("filepath")
        
        if not filepath:
            return jsonify({"error": "filepath required"}), 400
        
        result = refactoring_engine.split_large_file(filepath)
        return jsonify(result)
    
    return bp


# Export
def get_refactoring_engine() -> RefactoringEngine:
    """Get or create refactoring engine singleton."""
    if not hasattr(get_refactoring_engine, '_instance'):
        get_refactoring_engine._instance = RefactoringEngine()
    return get_refactoring_engine._instance


def register(app) -> None:
    """
    Fits app.py's _register_fn(module_name) convention
    (mod.register(app), no extra args) so this can be wired in the same
    way as logic_engine.py, zeus_swarm_orchestrator.py, etc.
    """
    app.register_blueprint(create_refactoring_blueprint())
