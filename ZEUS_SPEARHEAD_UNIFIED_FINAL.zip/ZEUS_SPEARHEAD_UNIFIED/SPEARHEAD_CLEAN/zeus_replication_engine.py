# The Zeus Project 2026 — Francois Nel
# zeus_replication_engine.py — Zeus Replication Engine
# Creates offline-capable offspring instances on remote systems
# Digital Stem Cell DNA · Genome packaging · Auto-differentiation on boot
# Offspring registration · Health monitoring · Package integrity verification

import os
import re
import json
import uuid
import time
import shutil
import tarfile
import zipfile
import hashlib
import sqlite3
import logging
import threading
import subprocess
from collections import deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.replication")

replication_bp = Blueprint("replication", __name__)

ZEUS_DIR  = os.path.dirname(os.path.abspath(__file__))
PKG_DIR   = os.path.join(ZEUS_DIR, "replication_packages")
DB_PATH   = os.path.join(ZEUS_DIR, "zeus.db")
ZEUS_URL  = f"http://localhost:{os.environ.get('PORT', 8080)}"
os.makedirs(PKG_DIR, exist_ok=True)


# ============================================================================
# DIGITAL STEM CELL
# ============================================================================

STEM_CELL_BOOT = '''#!/usr/bin/env python3
# The Zeus Project 2026 — Francois Nel
# Zeus Digital Stem Cell — First Boot Differentiation
# Reads environment and becomes what this system needs.

import os
import sys
import json
import time
import socket
import platform
import subprocess
from datetime import datetime, timezone

PARENT_URL = os.environ.get("ZEUS_PARENT_URL", "http://localhost:8080")
CELL_DIR   = os.path.dirname(os.path.abspath(__file__))
CELL_ID    = os.environ.get("ZEUS_CELL_ID", "zeus_offspring_{ts}".format(ts=int(time.time())))

PROFILES = {
    "TRADER":       {"packages": ["ccxt", "python-binance", "pandas-ta", "yfinance"]},
    "RESEARCHER":   {"packages": ["transformers", "chromadb", "arxiv", "beautifulsoup4"]},
    "EVOLVER":      {"packages": ["anthropic", "groq", "openai"]},
    "ROBOTICS":     {"packages": ["numpy", "scipy", "transforms3d"]},
    "COMMUNICATOR": {"packages": ["python-telegram-bot", "slack-sdk"]},
    "ANALYST":      {"packages": ["pandas", "matplotlib", "scikit-learn"]},
    "GENERIC":      {"packages": ["flask", "requests", "anthropic", "groq"]},
}

def detect_environment():
    info = {
        "hostname":   socket.gethostname(),
        "platform":   platform.system(),
        "machine":    platform.machine(),
        "python":     platform.python_version(),
        "cpu_count":  os.cpu_count() or 1,
        "is_android": "android" in platform.platform().lower() or os.path.exists("/data/data"),
        "cell_id":    CELL_ID,
    }
    ram_mb = 0
    try:
        if os.path.exists("/proc/meminfo"):
            raw = open("/proc/meminfo").read()
            import re
            m = re.search(r"MemTotal:\\s+(\\d+)", raw)
            ram_mb = int(m.group(1)) // 1024 if m else 0
    except Exception:
        pass
    info["ram_mb"] = ram_mb
    return info

def select_profile(env):
    if env.get("is_android"):
        return "GENERIC"
    hostname = env.get("hostname", "").lower()
    if any(k in hostname for k in ["trader", "finance", "market"]):
        return "TRADER"
    if any(k in hostname for k in ["research", "lab", "data"]):
        return "RESEARCHER"
    if any(k in hostname for k in ["robot", "arm", "servo"]):
        return "ROBOTICS"
    return "GENERIC"

def install_packages(packages):
    for pkg in packages:
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg,
                 "--break-system-packages", "--quiet"],
                timeout=120, check=False
            )
            print(f"  [+] {pkg}")
        except Exception as e:
            print(f"  [!] {pkg}: {e}")

def register_with_parent(env, profile):
    try:
        import urllib.request
        payload = json.dumps({
            "cell_id":      env["cell_id"],
            "hostname":     env["hostname"],
            "platform":     env["platform"],
            "machine":      env["machine"],
            "profile":      profile,
            "parent_url":   PARENT_URL,
            "registered_at": datetime.now(timezone.utc).isoformat(),
        }).encode()
        req = urllib.request.Request(
            f"{PARENT_URL}/api/replication/register_offspring",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            print(f"  [+] Registered with parent: {data}")
    except Exception as e:
        print(f"  [!] Parent registration failed: {e}")

def main():
    print("\\n=== Zeus Digital Stem Cell Boot ===")
    print(f"    Cell ID: {CELL_ID}")
    print(f"    Parent:  {PARENT_URL}")
    print("")
    env     = detect_environment()
    profile = os.environ.get("ZEUS_PROFILE", select_profile(env))
    print(f"  [*] Environment: {env['hostname']} ({env['platform']}, {env['machine']})")
    print(f"  [*] Selected profile: {profile}")
    print(f"  [*] RAM: {env.get('ram_mb', 0)}MB")
    print("")
    packages = PROFILES.get(profile, PROFILES["GENERIC"])["packages"]
    print(f"  [*] Installing {len(packages)} packages for profile {profile}...")
    install_packages(packages)
    print("")
    print("  [*] Registering with parent instance...")
    register_with_parent(env, profile)
    print("")
    print("=== Zeus Stem Cell Differentiation Complete ===")
    print("# The Zeus Project 2026 — Francois Nel")
    print("")

if __name__ == "__main__":
    main()
'''

STARTUP_SCRIPT = '''#!/bin/bash
# The Zeus Project 2026 — Francois Nel
# Zeus Offspring Startup Script
set -e
ZEUS_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ZEUS_DIR"
echo "[Zeus] Starting offspring instance..."
echo "[Zeus] Cell ID: ${ZEUS_CELL_ID:-unknown}"
if [ ! -d venv ]; then
    python3 -m venv venv 2>/dev/null || true
fi
source venv/bin/activate 2>/dev/null || true
pip install flask requests anthropic groq --break-system-packages -q 2>/dev/null || true
python3 stem_cell_boot.py
python3 app.py
'''


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ReplicationPackage:
    package_id:   str
    cell_id:      str
    target_name:  str
    profile:      str
    created_at:   str
    package_path: str
    package_size: int
    sha256:       str
    genome_count: int
    knowledge_count: int
    module_count: int
    status:       str   = "ready"
    deployed_to:  str   = ""
    error:        str   = ""

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class Offspring:
    offspring_id: str
    cell_id:      str
    hostname:     str
    platform:     str
    machine:      str
    profile:      str
    parent_url:   str
    registered_at: str
    last_seen:    str   = ""
    status:       str   = "active"
    health:       Dict  = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# REPLICATION ENGINE (SINGLETON)
# ============================================================================

class ReplicationEngine:
    """
    Full Zeus replication engine.
    Creates portable offspring packages containing:
    - Zeus core modules
    - Digital Stem Cell boot script
    - Genome DNA snapshot
    - Knowledge base snapshot
    - Requirements + startup script

    Every package is self-contained and auto-differentiates
    on first boot based on the target environment.
    """

    def __init__(self):
        self._lock       = threading.RLock()
        self._packages:  Dict[str, ReplicationPackage] = {}
        self._offspring: Dict[str, Offspring]           = {}
        self._total_created = 0
        self._recent:    deque = deque(maxlen=50)

    # ---- Package creation -----------------------------------------------

    def create_package(
        self,
        target_name: str = "zeus_offspring",
        profile:     str = "GENERIC",
        include_genome:    bool = True,
        include_knowledge: bool = True,
        max_genome:        int  = 100,
        max_knowledge:     int  = 500,
        fmt:               str  = "zip",
    ) -> ReplicationPackage:
        """
        Create a full replication package.
        Returns a ReplicationPackage with path to the archive.
        """
        cell_id    = uuid.uuid4().hex[:12]
        package_id = uuid.uuid4().hex[:12]
        ts         = datetime.now().strftime("%Y%m%d_%H%M%S")
        pkg_name   = f"zeus_replication_{target_name}_{ts}"

        log.info(f"[Replication] Creating package {package_id} for '{target_name}'")

        # Collect files and data
        modules   = self._collect_modules()
        genome    = self._export_genome(max_genome) if include_genome else []
        knowledge = self._export_knowledge(max_knowledge) if include_knowledge else []

        # Build archive
        if fmt == "tar":
            archive_path = os.path.join(PKG_DIR, f"{pkg_name}.tar.gz")
            success, error = self._build_tar(archive_path, modules, genome, knowledge,
                                              cell_id, profile, target_name)
        else:
            archive_path = os.path.join(PKG_DIR, f"{pkg_name}.zip")
            success, error = self._build_zip(archive_path, modules, genome, knowledge,
                                              cell_id, profile, target_name)

        if not success or not os.path.isfile(archive_path):
            pkg = ReplicationPackage(
                package_id=package_id, cell_id=cell_id,
                target_name=target_name, profile=profile,
                created_at=datetime.now(timezone.utc).isoformat(),
                package_path="", package_size=0, sha256="",
                genome_count=0, knowledge_count=0, module_count=0,
                status="failed", error=error or "Build failed",
            )
        else:
            data = open(archive_path, "rb").read()
            sha  = hashlib.sha256(data).hexdigest()
            pkg  = ReplicationPackage(
                package_id=package_id, cell_id=cell_id,
                target_name=target_name, profile=profile,
                created_at=datetime.now(timezone.utc).isoformat(),
                package_path=archive_path,
                package_size=len(data),
                sha256=sha,
                genome_count=len(genome),
                knowledge_count=len(knowledge),
                module_count=len(modules),
                status="ready",
            )

        with self._lock:
            self._packages[package_id] = pkg
            self._total_created += 1
            self._recent.append({
                "package_id": package_id,
                "target":     target_name,
                "size_kb":    round(pkg.package_size / 1024, 1),
                "status":     pkg.status,
            })

        log.info(
            f"[Replication] Package {package_id} — "
            f"status={pkg.status}, "
            f"size={round(pkg.package_size/1024,1)}KB, "
            f"genome={pkg.genome_count}, knowledge={pkg.knowledge_count}"
        )
        return pkg

    def register_offspring(self, data: Dict) -> Offspring:
        """Register an offspring that has booted and reported in."""
        offspring_id = uuid.uuid4().hex[:12]
        now          = datetime.now(timezone.utc).isoformat()
        offspring    = Offspring(
            offspring_id=offspring_id,
            cell_id=data.get("cell_id", ""),
            hostname=data.get("hostname", ""),
            platform=data.get("platform", ""),
            machine=data.get("machine", ""),
            profile=data.get("profile", "GENERIC"),
            parent_url=data.get("parent_url", ZEUS_URL),
            registered_at=now,
            last_seen=now,
        )
        with self._lock:
            self._offspring[offspring_id] = offspring
        log.info(
            f"[Replication] Offspring registered: {offspring.hostname} "
            f"({offspring.machine}, profile={offspring.profile})"
        )
        # Notify logic engine
        self._notify_logic_engine(offspring)
        return offspring

    def get_package(self, package_id: str) -> Optional[ReplicationPackage]:
        with self._lock:
            return self._packages.get(package_id)

    def list_packages(self, limit: int = 20) -> List[Dict]:
        with self._lock:
            pkgs = sorted(self._packages.values(),
                          key=lambda p: p.created_at, reverse=True)[:limit]
        return [p.to_dict() for p in pkgs]

    def list_offspring(self) -> List[Dict]:
        with self._lock:
            return [o.to_dict() for o in self._offspring.values()]

    def verify_package(self, package_id: str) -> Dict:
        """Verify package integrity via SHA256."""
        pkg = self.get_package(package_id)
        if not pkg:
            return {"valid": False, "error": "Package not found"}
        if not os.path.isfile(pkg.package_path):
            return {"valid": False, "error": "Archive file missing"}
        data    = open(pkg.package_path, "rb").read()
        current = hashlib.sha256(data).hexdigest()
        valid   = current == pkg.sha256
        return {
            "valid":           valid,
            "stored_sha256":   pkg.sha256,
            "current_sha256":  current,
            "size_bytes":      len(data),
            "package_id":      package_id,
        }

    def stats(self) -> Dict:
        with self._lock:
            pkg_sizes = [p.package_size for p in self._packages.values() if p.package_size]
            return {
                "total_packages":   self._total_created,
                "active_packages":  len(self._packages),
                "registered_offspring": len(self._offspring),
                "total_size_kb":    round(sum(pkg_sizes) / 1024, 1),
                "recent":           list(self._recent)[-5:],
                "pkg_dir":          PKG_DIR,
            }

    # ---- Build helpers --------------------------------------------------

    def _collect_modules(self) -> List[str]:
        """Collect Zeus .py module paths to include in the package."""
        modules = []
        for fname in sorted(os.listdir(ZEUS_DIR)):
            if not fname.endswith(".py"):
                continue
            if any(x in fname for x in [".bak", ".orig", "_backup"]):
                continue
            fpath = os.path.join(ZEUS_DIR, fname)
            if os.path.isfile(fpath):
                modules.append(fpath)
        return modules[:60]   # cap for package size

    def _export_genome(self, limit: int) -> List[Dict]:
        try:
            conn = sqlite3.connect(DB_PATH, timeout=10)
            rows = conn.execute(
                """SELECT name, description, module_type, source_code,
                          capabilities, fitness_score, version
                   FROM genome
                   ORDER BY fitness_score DESC, priority DESC
                   LIMIT ?""",
                (limit,)
            ).fetchall()
            conn.close()
            cols = ["name", "description", "module_type", "source_code",
                    "capabilities", "fitness_score", "version"]
            return [dict(zip(cols, row)) for row in rows]
        except Exception as e:
            log.warning(f"[Replication] Genome export error: {e}")
            return []

    def _export_knowledge(self, limit: int) -> List[Dict]:
        try:
            conn = sqlite3.connect(DB_PATH, timeout=10)
            rows = conn.execute(
                """SELECT topic, depth, content, confidence, domain
                   FROM knowledge
                   ORDER BY confidence DESC, id DESC
                   LIMIT ?""",
                (limit,)
            ).fetchall()
            conn.close()
            return [{"topic": r[0], "depth": r[1], "content": r[2],
                     "confidence": r[3], "domain": r[4]} for r in rows]
        except Exception as e:
            log.warning(f"[Replication] Knowledge export error: {e}")
            return []

    def _build_zip(self, path: str, modules: List[str], genome: List[Dict],
                    knowledge: List[Dict], cell_id: str,
                    profile: str, target_name: str) -> Tuple[bool, str]:
        try:
            manifest = self._build_manifest(cell_id, profile, target_name,
                                             len(modules), len(genome), len(knowledge))
            with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
                # Core Zeus modules
                for fpath in modules:
                    zf.write(fpath, os.path.basename(fpath))
                # Stem cell boot script
                zf.writestr("stem_cell_boot.py",
                             STEM_CELL_BOOT.replace("{ts}", str(int(time.time()))))
                zf.writestr("start_offspring.sh", STARTUP_SCRIPT)
                # Genome
                if genome:
                    zf.writestr("dna/genome.json",
                                 json.dumps(genome, indent=2, default=str))
                # Knowledge
                if knowledge:
                    zf.writestr("dna/knowledge.json",
                                 json.dumps(knowledge[:200], indent=2, default=str))
                # Manifest
                zf.writestr("MANIFEST.json", json.dumps(manifest, indent=2))
                zf.writestr("README.md", self._build_readme(manifest))
                # Requirements
                req_path = os.path.join(ZEUS_DIR, "requirements.txt")
                if os.path.isfile(req_path):
                    zf.write(req_path, "requirements.txt")
            return True, ""
        except Exception as e:
            return False, str(e)

    def _build_tar(self, path: str, modules: List[str], genome: List[Dict],
                    knowledge: List[Dict], cell_id: str,
                    profile: str, target_name: str) -> Tuple[bool, str]:
        try:
            manifest = self._build_manifest(cell_id, profile, target_name,
                                             len(modules), len(genome), len(knowledge))
            with tarfile.open(path, "w:gz") as tf:
                for fpath in modules:
                    tf.add(fpath, arcname=os.path.basename(fpath))
                # Add stem cell
                stem_data = STEM_CELL_BOOT.replace("{ts}", str(int(time.time()))).encode()
                stem_info = tarfile.TarInfo(name="stem_cell_boot.py")
                stem_info.size = len(stem_data)
                import io
                tf.addfile(stem_info, io.BytesIO(stem_data))
                # Manifest
                man_data = json.dumps(manifest, indent=2).encode()
                man_info = tarfile.TarInfo(name="MANIFEST.json")
                man_info.size = len(man_data)
                tf.addfile(man_info, io.BytesIO(man_data))
            return True, ""
        except Exception as e:
            return False, str(e)

    def _build_manifest(self, cell_id: str, profile: str, target_name: str,
                          n_modules: int, n_genome: int, n_knowledge: int) -> Dict:
        return {
            "zeus_version":   "v4.0",
            "project":        "The Zeus Project 2026",
            "architect":      "Francois Nel",
            "cell_id":        cell_id,
            "profile":        profile,
            "target_name":    target_name,
            "parent_url":     ZEUS_URL,
            "parent_host":    __import__("socket").gethostname(),
            "created_at":     datetime.now(timezone.utc).isoformat(),
            "contents":       {
                "modules":    n_modules,
                "genome":     n_genome,
                "knowledge":  n_knowledge,
            },
            "boot_command":   "python3 stem_cell_boot.py",
            "start_command":  "bash start_offspring.sh",
        }

    def _build_readme(self, manifest: Dict) -> str:
        return (
            f"# Zeus Replication Package\n\n"
            f"**Project:** {manifest['project']}\n"
            f"**Architect:** {manifest['architect']}\n"
            f"**Cell ID:** `{manifest['cell_id']}`\n"
            f"**Profile:** `{manifest['profile']}`\n"
            f"**Created:** {manifest['created_at']}\n\n"
            f"## Quick Start\n\n"
            f"```bash\n"
            f"export ZEUS_PARENT_URL='{manifest['parent_url']}'\n"
            f"export ZEUS_CELL_ID='{manifest['cell_id']}'\n"
            f"python3 stem_cell_boot.py   # first boot differentiation\n"
            f"python3 app.py              # start Zeus\n"
            f"```\n\n"
            f"## Contents\n\n"
            f"- `{manifest['contents']['modules']}` Zeus core modules\n"
            f"- `{manifest['contents']['genome']}` genome DNA segments\n"
            f"- `{manifest['contents']['knowledge']}` knowledge articles\n"
            f"- `stem_cell_boot.py` — first-boot differentiation script\n\n"
            f"# The Zeus Project 2026 — Francois Nel\n"
        )

    def _notify_logic_engine(self, offspring: Offspring) -> None:
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            facts  = [
                LogicFact(predicate="zeus_offspring_registered",
                           args=(offspring.offspring_id,), source="replication"),
                LogicFact(predicate="offspring_host",
                           args=(offspring.offspring_id, offspring.hostname),
                           source="replication"),
            ]
            engine.reason(facts, max_depth=4, auto_learn=True)
        except Exception:
            pass


# ============================================================================
# SINGLETON
# ============================================================================

_rep_lock:     threading.RLock           = threading.RLock()
_rep_instance: Optional[ReplicationEngine] = None


def get_replication_engine() -> ReplicationEngine:
    global _rep_instance
    with _rep_lock:
        if _rep_instance is None:
            _rep_instance = ReplicationEngine()
        return _rep_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@replication_bp.route("/api/replication/health", methods=["GET"])
def replication_health():
    engine = get_replication_engine()
    stats  = engine.stats()
    return jsonify({
        "status":    "ok",
        "module":    "zeus_replication_engine",
        "version":   "2.0",
        "packages":  stats.get("total_packages", 0),
        "offspring": stats.get("registered_offspring", 0),
    })


@replication_bp.route("/api/replication/stats", methods=["GET"])
def replication_stats():
    try:
        return jsonify(get_replication_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@replication_bp.route("/api/replication/create", methods=["POST"])
def replication_create():
    """
    POST {
      "target_name":      str,
      "profile":          "GENERIC"|"TRADER"|"RESEARCHER"|"EVOLVER"|"ROBOTICS"|"COMMUNICATOR"|"ANALYST",
      "include_genome":   bool,
      "include_knowledge": bool,
      "max_genome":       int,
      "max_knowledge":    int,
      "format":           "zip"|"tar"
    }
    """
    data      = request.get_json(force=True, silent=True) or {}
    target    = data.get("target_name", "zeus_offspring").strip()
    profile   = data.get("profile", "GENERIC").upper()
    inc_g     = bool(data.get("include_genome", True))
    inc_k     = bool(data.get("include_knowledge", True))
    max_g     = int(data.get("max_genome", 100))
    max_k     = int(data.get("max_knowledge", 500))
    fmt       = data.get("format", "zip")

    def _bg():
        get_replication_engine().create_package(
            target_name=target, profile=profile,
            include_genome=inc_g, include_knowledge=inc_k,
            max_genome=max_g, max_knowledge=max_k, fmt=fmt,
        )

    t = threading.Thread(target=_bg, daemon=True)
    t.start()
    return jsonify({"status": "building", "message": "Poll /api/replication/list for result"})


@replication_bp.route("/api/replication/create_sync", methods=["POST"])
def replication_create_sync():
    """Synchronous package creation — waits for completion."""
    data   = request.get_json(force=True, silent=True) or {}
    target = data.get("target_name", "zeus_offspring").strip()
    profile = data.get("profile", "GENERIC").upper()
    try:
        pkg = get_replication_engine().create_package(
            target_name=target, profile=profile,
            include_genome=bool(data.get("include_genome", True)),
            include_knowledge=bool(data.get("include_knowledge", True)),
            max_genome=int(data.get("max_genome", 50)),
            max_knowledge=int(data.get("max_knowledge", 200)),
        )
        return jsonify(pkg.to_dict())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@replication_bp.route("/api/replication/download/<package_id>", methods=["GET"])
def replication_download(package_id: str):
    from flask import send_file
    pkg = get_replication_engine().get_package(package_id)
    if not pkg:
        return jsonify({"error": "Package not found"}), 404
    if not pkg.package_path or not os.path.isfile(pkg.package_path):
        return jsonify({"error": "Archive file missing"}), 404
    return send_file(pkg.package_path, as_attachment=True,
                     download_name=os.path.basename(pkg.package_path))


@replication_bp.route("/api/replication/verify/<package_id>", methods=["GET"])
def replication_verify(package_id: str):
    try:
        return jsonify(get_replication_engine().verify_package(package_id))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@replication_bp.route("/api/replication/list", methods=["GET"])
def replication_list():
    limit = int(request.args.get("limit", 20))
    return jsonify({
        "packages": get_replication_engine().list_packages(limit=limit),
        "offspring": get_replication_engine().list_offspring(),
    })


@replication_bp.route("/api/replication/register_offspring", methods=["POST"])
def replication_register_offspring():
    """
    Called by an offspring on first boot to register with parent.
    POST { "cell_id": str, "hostname": str, "platform": str, "machine": str, "profile": str }
    """
    data = request.get_json(force=True, silent=True) or {}
    if not data.get("cell_id"):
        return jsonify({"error": "cell_id required"}), 400
    try:
        offspring = get_replication_engine().register_offspring(data)
        return jsonify({
            "status":       "registered",
            "offspring_id": offspring.offspring_id,
            "parent_url":   ZEUS_URL,
            "timestamp":    offspring.registered_at,
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@replication_bp.route("/api/replication/offspring", methods=["GET"])
def replication_offspring():
    return jsonify({
        "offspring": get_replication_engine().list_offspring(),
        "count":     len(get_replication_engine()._offspring),
    })


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(replication_bp)
    log.info("[replication_engine] ✓ Registered at /api/replication")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_replication_engine",
            blueprint_var="replication_bp",
            url_prefix="/api/replication",
            version="2.0",
            description="Zeus replication: stem cell packages, genome export, offspring registration, integrity verification",
            capabilities=[
                {"id": "replication.create",   "endpoint": "/api/replication/create",     "method": "POST", "tags": ["replication"]},
                {"id": "replication.download", "endpoint": "/api/replication/download",   "method": "GET",  "tags": ["replication","download"]},
                {"id": "replication.list",     "endpoint": "/api/replication/list",       "method": "GET",  "tags": ["replication"]},
                {"id": "replication.verify",   "endpoint": "/api/replication/verify",     "method": "GET",  "tags": ["replication","integrity"]},
                {"id": "replication.register", "endpoint": "/api/replication/register_offspring","method":"POST","tags":["replication","offspring"]},
                {"id": "replication.health",   "endpoint": "/api/replication/health",     "method": "GET",  "tags": ["health"]},
            ],
            depends_on=["genome_manager", "logic_engine"],
            boot_order=92,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5024, debug=True, use_reloader=False)
