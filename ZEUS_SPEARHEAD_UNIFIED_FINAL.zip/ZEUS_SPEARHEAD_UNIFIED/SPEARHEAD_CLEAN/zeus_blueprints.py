# The Zeus Project 2026 — Francois Nel
# zeus_blueprints.py — Blueprint Engine
# Logic Engine synthesis blueprint generation · Forge → Store → Mutate → Forge cycle
# APK build pipeline · Export handler · Quality gates · Lineage tracking
# Blueprint versioning · Synthesis directives · Full interconnect

import os
import io
import json
import uuid
import time
import shutil
import zipfile
import logging
import hashlib
import threading
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request, send_file, Response

log = logging.getLogger("zeus.blueprints")

blueprints_bp = Blueprint("blueprints", __name__)

ZEUS_DIR   = os.path.dirname(os.path.abspath(__file__))
EXPORT_DIR = os.path.join(ZEUS_DIR, "exports")
os.makedirs(EXPORT_DIR, exist_ok=True)


# ============================================================================
# BLUEPRINT DATA STRUCTURES
# ============================================================================

@dataclass
class BlueprintRecord:
    """A stored blueprint in the Zeus blueprint DB."""
    blueprint_id:    str
    goal:            str
    output_type:     str
    status:          str           # pending | running | done | failed
    plan_json:       Dict
    architecture:    str
    dna_context:     Dict
    forge_log:       str
    result_path:     str
    result_size:     int
    quality_score:   float
    stages_complete: int
    stages_total:    int
    error_msg:       str
    created_at:      str
    completed_at:    str

    @classmethod
    def from_db_row(cls, row) -> "BlueprintRecord":
        d = dict(row)
        for field_name in ("plan_json", "dna_context"):
            try:
                d[field_name] = json.loads(d.get(field_name) or "{}")
            except Exception:
                d[field_name] = {}
        return cls(**{k: d.get(k, "") for k in cls.__dataclass_fields__})

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["quality_class"] = self._quality_class()
        return d

    def _quality_class(self) -> str:
        if self.quality_score >= 0.85: return "elite"
        if self.quality_score >= 0.70: return "high"
        if self.quality_score >= 0.50: return "medium"
        return "low"


@dataclass
class SynthesisDirective:
    """A directive extracted from a logic engine SynthesisBlueprint."""
    directive_id: str
    blueprint_id: str
    directive:    str
    category:     str   # security | quality | architecture | pattern | interface
    priority:     int   = 5
    applied:      bool  = False


# ============================================================================
# DNA RETRIEVER (enhanced)
# ============================================================================

class BlueprintDNARetriever:
    """
    Enhanced DNA retrieval for blueprint engine.
    Pulls from knowledge, genome, and logic engine synthesis blueprints.
    """

    def retrieve(self, description: str, output_type: str = "",
                  max_knowledge: int = 10, max_genome: int = 8) -> Dict:
        from db_init import get_db
        keywords  = self._extract_keywords(description)
        knowledge = []
        genome    = []
        synth_bps = []
        seen_k, seen_g = set(), set()

        try:
            conn = get_db()
            for kw in keywords[:6]:
                rows = conn.execute(
                    """
                    SELECT topic, depth, content, confidence
                    FROM knowledge
                    WHERE topic LIKE ? OR content LIKE ?
                    ORDER BY confidence DESC, id DESC LIMIT 3
                    """,
                    (f"%{kw}%", f"%{kw}%")
                ).fetchall()
                for row in rows:
                    key = (row["topic"], row["depth"])
                    if key not in seen_k:
                        seen_k.add(key)
                        knowledge.append(dict(row))

                rows = conn.execute(
                    """
                    SELECT name, description, module_type, capabilities, fitness_score
                    FROM genome
                    WHERE name LIKE ? OR description LIKE ? OR capabilities LIKE ?
                    ORDER BY fitness_score DESC, priority DESC LIMIT 3
                    """,
                    (f"%{kw}%", f"%{kw}%", f"%{kw}%")
                ).fetchall()
                for row in rows:
                    if row["name"] not in seen_g:
                        seen_g.add(row["name"])
                        genome.append(dict(row))

            # Pull recent synthesis blueprints for context
            rows = conn.execute(
                """
                SELECT goal, module_name, architecture, confidence
                FROM synthesis_blueprints
                ORDER BY created_at DESC LIMIT 5
                """
            ).fetchall()
            synth_bps = [dict(r) for r in rows]
            conn.close()
        except Exception as e:
            log.warning(f"[Blueprints] DNA retrieval error: {e}")

        # Logic engine context
        logic_ctx = self._get_logic_context(description, keywords)

        return {
            "keywords":      keywords,
            "knowledge":     knowledge[:max_knowledge],
            "genome":        genome[:max_genome],
            "synth_bps":     synth_bps,
            "logic_context": logic_ctx,
            "has_apk_dna":   any(
                "apk" in g.get("module_type", "") or "android" in g.get("capabilities", "")
                for g in genome
            ),
        }

    def _extract_keywords(self, text: str) -> List[str]:
        words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9_]{2,}\b', text.lower()) if text else []
        stop = {
            "the","and","for","with","that","this","from","into","have","build",
            "make","create","generate","write","using","use","should","will",
        }
        unique = list(dict.fromkeys(w for w in words if w not in stop))
        return unique[:12]

    def _get_logic_context(self, description: str, keywords: List[str]) -> str:
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            facts  = [
                LogicFact(predicate="blueprint_goal", args=(description[:100],),
                           source="blueprints")
            ]
            for kw in keywords[:6]:
                facts.append(LogicFact(predicate="goal_keyword", args=(kw,),
                                        source="blueprints"))
            result  = engine.reason(facts, max_depth=8, auto_learn=False)
            ctx     = [c.to_str() for c in result.conclusions[:6]]
            hyp     = [f"[hypothesis] {h.to_str()}" for h in result.abductive_hypotheses[:3]]
            all_ctx = ctx + hyp
            return "; ".join(all_ctx) if all_ctx else ""
        except Exception as e:
            log.debug(f"[Blueprints] Logic context skipped: {e}")
            return ""


import re


# ============================================================================
# BLUEPRINT ENGINE (SINGLETON)
# ============================================================================

class BlueprintEngine:
    """
    Full blueprint lifecycle engine:
    1. Create blueprint (from goal)
    2. Enrich with logic engine synthesis blueprint
    3. Pass to forge for code generation
    4. Validate output through sandbox
    5. Package and export
    6. Trigger mutator on successful completion
    7. Feed synthesis result back to logic engine for learning
    """

    def __init__(self):
        self._lock            = threading.RLock()
        self._dna_retriever   = BlueprintDNARetriever()
        self._total_created   = 0
        self._total_completed = 0
        self._total_failed    = 0
        self._recent:         deque = deque(maxlen=100)
        self._active_jobs:    Dict[str, str] = {}   # blueprint_id → status

    # ---- DB helpers ------------------------------------------------------

    def _db(self):
        from db_init import get_db
        return get_db()

    def _ensure_table(self) -> None:
        try:
            conn = self._db()
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS blueprints (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    blueprint_id    TEXT NOT NULL UNIQUE DEFAULT '',
                    goal            TEXT NOT NULL,
                    output_type     TEXT DEFAULT 'python_module',
                    status          TEXT DEFAULT 'pending',
                    plan_json       TEXT DEFAULT '{}',
                    architecture    TEXT DEFAULT '',
                    dna_context     TEXT DEFAULT '{}',
                    forge_log       TEXT DEFAULT '',
                    result_path     TEXT DEFAULT '',
                    result_size     INTEGER DEFAULT 0,
                    quality_score   REAL DEFAULT 0.0,
                    stages_complete INTEGER DEFAULT 0,
                    stages_total    INTEGER DEFAULT 5,
                    error_msg       TEXT DEFAULT '',
                    created_at      TEXT DEFAULT (datetime('now')),
                    completed_at    TEXT DEFAULT ''
                )
                """
            )
            conn.commit()
            conn.close()
        except Exception:
            pass

    # ---- Blueprint creation ---------------------------------------------

    def create(
        self,
        goal:        str,
        output_type: str  = "python_module",
        context:     Dict = None,
        deep_plan:   bool = True,
        auto_forge:  bool = False,
    ) -> Dict:
        """
        Create a blueprint for a given goal.
        Generates a logic engine synthesis blueprint, stores it, and
        optionally triggers the forge pipeline.
        """
        self._ensure_table()
        goal        = goal.strip()[:500]
        blueprint_id = uuid.uuid4().hex[:16]
        context      = context or {}
        t0           = time.time()

        log.info(f"[Blueprints] Creating blueprint: '{goal[:60]}' type={output_type}")

        # 1. Retrieve DNA context
        dna = self._dna_retriever.retrieve(goal, output_type)

        # 2. Generate synthesis blueprint via logic engine
        synthesis_bp = None
        plan_dict    = {}
        architecture = ""
        try:
            from logic_engine import get_engine
            engine = get_engine()
            if deep_plan:
                synthesis_bp = engine.deep_plan(goal, context)
                plan_dict    = synthesis_bp.to_dict()
                architecture = synthesis_bp.architecture_style
                # Learn from synthesis result
                engine.learn_from_synthesis({
                    "module_name":    synthesis_bp.module_name,
                    "module_type":    synthesis_bp.module_type,
                    "design_patterns": synthesis_bp.design_patterns,
                    "quality_score":  synthesis_bp.critique_score,
                })
                # Persist synthesis blueprint
                self._persist_synthesis_blueprint(synthesis_bp)
            else:
                plan_obj  = engine.plan(goal, context)
                plan_dict = engine._planner.plan_to_dict(plan_obj)
        except Exception as e:
            log.warning(f"[Blueprints] Logic engine plan failed: {e}")
            plan_dict = {"goal": goal, "error": str(e)}

        # 3. Persist blueprint record
        quality = plan_dict.get("confidence", 0.0) if synthesis_bp else 0.5
        self._persist_blueprint(
            blueprint_id=blueprint_id,
            goal=goal,
            output_type=output_type,
            plan_json=plan_dict,
            architecture=architecture,
            dna_context=dna,
            quality_score=quality,
        )
        with self._lock:
            self._total_created += 1
            self._active_jobs[blueprint_id] = "pending"

        duration_ms = round((time.time() - t0) * 1000, 1)

        result = {
            "status":         "ok",
            "blueprint_id":   blueprint_id,
            "goal":           goal,
            "output_type":    output_type,
            "architecture":   architecture,
            "quality_score":  quality,
            "dna_knowledge":  len(dna["knowledge"]),
            "dna_genome":     len(dna["genome"]),
            "logic_context":  dna.get("logic_context", "")[:200],
            "plan_steps":     len(plan_dict.get("steps", [])),
            "duration_ms":    duration_ms,
        }

        if synthesis_bp:
            result["synthesis"] = {
                "blueprint_id":  synthesis_bp.blueprint_id,
                "module_name":   synthesis_bp.module_name,
                "module_type":   synthesis_bp.module_type,
                "confidence":    synthesis_bp.confidence,
                "critique_score": synthesis_bp.critique_score,
                "design_patterns": synthesis_bp.design_patterns[:5],
                "quality_gates": synthesis_bp.quality_gates[:5],
                "directives":    synthesis_bp.synthesis_directives[:8],
            }

        # 4. Optionally kick off forge immediately
        if auto_forge:
            threading.Thread(
                target=self._run_forge_pipeline,
                args=(blueprint_id, goal, output_type, dna, synthesis_bp),
                daemon=True,
            ).start()
            result["forge_triggered"] = True

        log.info(f"[Blueprints] Blueprint {blueprint_id[:8]} created in {duration_ms}ms")
        self._recent.append({**result, "ts": time.time()})
        return result

    def run_forge(self, blueprint_id: str) -> Dict:
        """
        Trigger forge pipeline for an existing blueprint.
        Returns job status (forge runs in background).
        """
        bp = self.get(blueprint_id)
        if not bp:
            return {"error": f"Blueprint {blueprint_id} not found"}
        if bp.get("status") == "running":
            return {"error": "Blueprint already running"}
        goal        = bp.get("goal", "")
        output_type = bp.get("output_type", "python_module")
        dna_context = bp.get("dna_context", {})
        threading.Thread(
            target=self._run_forge_pipeline,
            args=(blueprint_id, goal, output_type, dna_context, None),
            daemon=True,
        ).start()
        self._update_status(blueprint_id, "running")
        return {"status": "ok", "blueprint_id": blueprint_id, "message": "Forge started"}

    def get(self, blueprint_id: str) -> Optional[Dict]:
        try:
            conn = self._db()
            row  = conn.execute(
                "SELECT * FROM blueprints WHERE blueprint_id=?", (blueprint_id,)
            ).fetchone()
            conn.close()
            if not row:
                return None
            rec = BlueprintRecord.from_db_row(row)
            return rec.to_dict()
        except Exception as e:
            return {"error": str(e)}

    def list_blueprints(
        self,
        status:      str = "",
        output_type: str = "",
        limit:       int = 50,
        offset:      int = 0,
    ) -> List[Dict]:
        try:
            conn   = self._db()
            where  = []
            params = []
            if status:
                where.append("status=?"); params.append(status)
            if output_type:
                where.append("output_type=?"); params.append(output_type)
            sql = "SELECT * FROM blueprints"
            if where:
                sql += " WHERE " + " AND ".join(where)
            sql += " ORDER BY id DESC LIMIT ? OFFSET ?"
            params += [limit, offset]
            rows = conn.execute(sql, params).fetchall()
            conn.close()
            return [BlueprintRecord.from_db_row(r).to_dict() for r in rows]
        except Exception as e:
            log.warning(f"[Blueprints] list error: {e}")
            return []

    def export(self, blueprint_id: str, format_: str = "zip") -> Optional[str]:
        """
        Export blueprint result as zip/pdf.
        Returns export file path or None on failure.
        """
        bp = self.get(blueprint_id)
        if not bp:
            return None

        export_id   = uuid.uuid4().hex[:8]
        export_path = os.path.join(EXPORT_DIR, f"blueprint_{blueprint_id[:8]}_{export_id}.zip")

        try:
            with zipfile.ZipFile(export_path, "w", zipfile.ZIP_DEFLATED) as zf:
                # Metadata
                meta = {
                    "blueprint_id":  blueprint_id,
                    "goal":          bp.get("goal", ""),
                    "output_type":   bp.get("output_type", ""),
                    "quality_score": bp.get("quality_score", 0),
                    "architecture":  bp.get("architecture", ""),
                    "exported_at":   datetime.now(timezone.utc).isoformat(),
                    "project":       "The Zeus Project 2026",
                    "architect":     "Francois Nel",
                }
                zf.writestr("blueprint_meta.json", json.dumps(meta, indent=2, default=str))

                # Plan
                plan = bp.get("plan_json", {})
                zf.writestr("synthesis_blueprint.json",
                             json.dumps(plan, indent=2, default=str))

                # Forge output file (if exists)
                result_path = bp.get("result_path", "")
                if result_path and os.path.isfile(result_path):
                    zf.write(result_path, os.path.basename(result_path))

                # DNA context
                dna = bp.get("dna_context", {})
                zf.writestr("dna_context.json", json.dumps(dna, indent=2, default=str))

                # Forge log
                if bp.get("forge_log"):
                    zf.writestr("forge.log", bp["forge_log"])

            log.info(f"[Blueprints] Exported {blueprint_id[:8]} → {export_path}")
            return export_path
        except Exception as e:
            log.warning(f"[Blueprints] Export failed: {e}")
            return None

    def stats(self) -> Dict:
        with self._lock:
            try:
                conn = self._db()
                total = conn.execute("SELECT COUNT(*) FROM blueprints").fetchone()[0]
                by_status = conn.execute(
                    "SELECT status, COUNT(*) FROM blueprints GROUP BY status"
                ).fetchall()
                avg_quality = conn.execute(
                    "SELECT AVG(quality_score) FROM blueprints WHERE status='done'"
                ).fetchone()[0] or 0.0
                conn.close()
                return {
                    "total_blueprints":  total,
                    "by_status":         {r[0]: r[1] for r in by_status},
                    "avg_quality":       round(avg_quality, 4),
                    "total_created":     self._total_created,
                    "total_completed":   self._total_completed,
                    "total_failed":      self._total_failed,
                    "active_jobs":       len(self._active_jobs),
                }
            except Exception as e:
                return {"error": str(e)}

    # ---- Internal -------------------------------------------------------

    def _run_forge_pipeline(
        self,
        blueprint_id: str,
        goal:         str,
        output_type:  str,
        dna_context:  Dict,
        synthesis_bp: Any,
    ) -> None:
        """Run the forge pipeline for a blueprint. Called in a background thread."""
        try:
            from zeus_forge import get_forge_engine
            forge  = get_forge_engine()
            result = forge.run(goal, output_type=output_type, inject=False)
            success = result.get("status") == "ok"
            quality = result.get("quality_score", 0.5)
            path    = result.get("result_path", "")
            size    = result.get("result_size", 0)

            self._update_blueprint_result(
                blueprint_id=blueprint_id,
                status="done" if success else "failed",
                result_path=path, result_size=size,
                quality_score=quality,
                forge_log=result.get("log", ""),
                error_msg="" if success else result.get("error", ""),
                stages_complete=5,
            )
            with self._lock:
                self._total_completed += 1 if success else 0
                self._total_failed    += 0 if success else 1
                self._active_jobs.pop(blueprint_id, None)

            # Post-success actions
            if success and synthesis_bp:
                try:
                    from logic_engine import get_engine
                    get_engine().learn_from_synthesis({
                        "module_name":    getattr(synthesis_bp, "module_name", ""),
                        "module_type":    getattr(synthesis_bp, "module_type", ""),
                        "design_patterns": getattr(synthesis_bp, "design_patterns", []),
                        "quality_score":  quality,
                    })
                except Exception:
                    pass
                # Trigger mutation on high-quality blueprints
                if quality >= 0.75:
                    try:
                        from zeus_mutator import get_engine as get_mutator
                        get_mutator().mutate(
                            [{"topic": goal[:100], "priority": 1.5, "depth": "Professional"}],
                            source="blueprint_post_forge", use_ai=False,
                        )
                    except Exception:
                        pass

            log.info(
                f"[Blueprints] Forge pipeline {blueprint_id[:8]} "
                f"{'✓' if success else '✗'} quality={quality:.2f}"
            )
        except Exception as e:
            log.error(f"[Blueprints] Forge pipeline error for {blueprint_id[:8]}: {e}")
            self._update_blueprint_result(
                blueprint_id=blueprint_id, status="failed",
                error_msg=str(e)[:500],
            )

    def _persist_blueprint(self, blueprint_id: str, goal: str, output_type: str,
                             plan_json: Dict, architecture: str, dna_context: Dict,
                             quality_score: float) -> None:
        try:
            conn = self._db()
            conn.execute(
                """
                INSERT OR IGNORE INTO blueprints
                    (blueprint_id, goal, output_type, status, plan_json,
                     architecture, dna_context, quality_score, stages_total)
                VALUES (?, ?, ?, 'pending', ?, ?, ?, ?, 5)
                """,
                (blueprint_id, goal[:500], output_type,
                 json.dumps(plan_json, default=str)[:20000],
                 architecture,
                 json.dumps(dna_context, default=str)[:10000],
                 quality_score)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning(f"[Blueprints] persist error: {e}")

    def _persist_synthesis_blueprint(self, synthesis_bp: Any) -> None:
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                INSERT OR IGNORE INTO synthesis_blueprints
                    (blueprint_id, goal, module_name, module_type, architecture,
                     blueprint_json, critique_score, confidence, iterations,
                     quality_gate_pass)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    synthesis_bp.blueprint_id, synthesis_bp.goal[:500],
                    synthesis_bp.module_name, synthesis_bp.module_type,
                    synthesis_bp.architecture_style,
                    json.dumps(synthesis_bp.to_dict(), default=str)[:20000],
                    synthesis_bp.critique_score, synthesis_bp.confidence,
                    synthesis_bp.improvement_iterations,
                    1 if synthesis_bp.critique_score >= 0.70 else 0,
                )
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.debug(f"[Blueprints] Synthesis BP persist skipped: {e}")

    def _update_status(self, blueprint_id: str, status: str) -> None:
        try:
            conn = self._db()
            conn.execute(
                "UPDATE blueprints SET status=? WHERE blueprint_id=?",
                (status, blueprint_id)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning(f"[Blueprints] _update_status error: {e}")

    def _update_blueprint_result(
        self,
        blueprint_id:    str,
        status:          str,
        result_path:     str  = "",
        result_size:     int  = 0,
        quality_score:   float = 0.0,
        forge_log:       str  = "",
        error_msg:       str  = "",
        stages_complete: int  = 0,
    ) -> None:
        try:
            conn = self._db()
            conn.execute(
                """
                UPDATE blueprints
                SET status=?, result_path=?, result_size=?, quality_score=?,
                    forge_log=?, error_msg=?, stages_complete=?,
                    completed_at=datetime('now')
                WHERE blueprint_id=?
                """,
                (status, result_path, result_size, quality_score,
                 forge_log[:8080], error_msg[:500], stages_complete,
                 blueprint_id)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning(f"[Blueprints] _update_result error: {e}")


# ============================================================================
# SINGLETON
# ============================================================================

_bp_lock:     threading.RLock        = threading.RLock()
_bp_instance: Optional[BlueprintEngine] = None


def get_blueprint_engine() -> BlueprintEngine:
    global _bp_instance
    with _bp_lock:
        if _bp_instance is None:
            _bp_instance = BlueprintEngine()
        return _bp_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@blueprints_bp.route("/api/blueprints/health", methods=["GET"])
def blueprints_health():
    engine = get_blueprint_engine()
    stats  = engine.stats()
    return jsonify({
        "status":  "ok",
        "module":  "zeus_blueprints",
        "version": "2.0",
        "total":   stats.get("total_blueprints", 0),
        "active":  stats.get("active_jobs", 0),
    })


@blueprints_bp.route("/api/blueprints/stats", methods=["GET"])
def blueprints_stats():
    try:
        return jsonify(get_blueprint_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@blueprints_bp.route("/api/blueprints/create", methods=["POST"])
def blueprints_create():
    """
    POST {
      "goal":        str,
      "output_type": str,  (python_module|flask_blueprint|apk|shell_script)
      "context":     {},
      "deep_plan":   bool,
      "auto_forge":  bool
    }
    """
    data        = request.get_json(force=True, silent=True) or {}
    goal        = data.get("goal", "").strip()
    output_type = data.get("output_type", "python_module")
    context     = data.get("context", {})
    deep_plan   = bool(data.get("deep_plan", True))
    auto_forge  = bool(data.get("auto_forge", False))

    if not goal:
        return jsonify({"error": "goal required"}), 400

    result = get_blueprint_engine().create(
        goal=goal, output_type=output_type, context=context,
        deep_plan=deep_plan, auto_forge=auto_forge,
    )
    return jsonify(result)


@blueprints_bp.route("/api/blueprints/forge/<blueprint_id>", methods=["POST"])
def blueprints_forge(blueprint_id: str):
    """Trigger forge pipeline for a stored blueprint."""
    result = get_blueprint_engine().run_forge(blueprint_id)
    code   = 400 if "error" in result else 200
    return jsonify(result), code


@blueprints_bp.route("/api/blueprints/get/<blueprint_id>", methods=["GET"])
def blueprints_get(blueprint_id: str):
    result = get_blueprint_engine().get(blueprint_id)
    if result is None:
        return jsonify({"error": "Blueprint not found"}), 404
    return jsonify(result)


@blueprints_bp.route("/api/blueprints/list", methods=["GET"])
def blueprints_list():
    status      = request.args.get("status", "")
    output_type = request.args.get("type", "")
    limit       = int(request.args.get("limit", 50))
    offset      = int(request.args.get("offset", 0))
    try:
        bps = get_blueprint_engine().list_blueprints(
            status=status, output_type=output_type,
            limit=limit, offset=offset,
        )
        return jsonify({"blueprints": bps, "count": len(bps)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@blueprints_bp.route("/api/blueprints/export/<blueprint_id>", methods=["GET"])
def blueprints_export(blueprint_id: str):
    """Download blueprint as zip."""
    fmt  = request.args.get("format", "zip")
    path = get_blueprint_engine().export(blueprint_id, format_=fmt)
    if not path or not os.path.isfile(path):
        return jsonify({"error": "Export failed or blueprint not found"}), 404
    return send_file(path, as_attachment=True,
                     download_name=os.path.basename(path),
                     mimetype="application/zip")


@blueprints_bp.route("/api/blueprints/exports/list", methods=["GET"])
def blueprints_export_list():
    """List all export files."""
    try:
        files = []
        for fname in sorted(os.listdir(EXPORT_DIR), reverse=True):
            fpath = os.path.join(EXPORT_DIR, fname)
            if os.path.isfile(fpath):
                files.append({
                    "filename": fname,
                    "size_kb":  round(os.path.getsize(fpath) / 1024, 1),
                    "modified": datetime.fromtimestamp(
                        os.path.getmtime(fpath), tz=timezone.utc
                    ).isoformat(),
                })
        return jsonify({"exports": files, "count": len(files)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@blueprints_bp.route("/api/blueprints/synthesis/list", methods=["GET"])
def blueprints_synthesis_list():
    """List all stored synthesis blueprints from the logic engine."""
    limit = int(request.args.get("limit", 20))
    try:
        from db_init import get_db
        conn = get_db()
        rows = conn.execute(
            """
            SELECT blueprint_id, goal, module_name, module_type, architecture,
                   critique_score, confidence, iterations, quality_gate_pass, created_at
            FROM synthesis_blueprints
            ORDER BY created_at DESC LIMIT ?
            """,
            (limit,)
        ).fetchall()
        conn.close()
        return jsonify({"synthesis_blueprints": [dict(r) for r in rows], "count": len(rows)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(blueprints_bp)
    log.info("[blueprints] ✓ Registered at /api/blueprints")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_blueprints",
            blueprint_var="blueprints_bp",
            url_prefix="/api/blueprints",
            version="2.0",
            description="Blueprint engine: logic synthesis, forge pipeline, APK build, export, mutation triggers",
            capabilities=[
                {"id": "blueprints.create",   "endpoint": "/api/blueprints/create",   "method": "POST", "tags": ["blueprints", "synthesis"]},
                {"id": "blueprints.forge",    "endpoint": "/api/blueprints/forge",    "method": "POST", "tags": ["blueprints", "forge"]},
                {"id": "blueprints.get",      "endpoint": "/api/blueprints/get",      "method": "GET",  "tags": ["blueprints"]},
                {"id": "blueprints.list",     "endpoint": "/api/blueprints/list",     "method": "GET",  "tags": ["blueprints"]},
                {"id": "blueprints.export",   "endpoint": "/api/blueprints/export",   "method": "GET",  "tags": ["blueprints", "export"]},
                {"id": "blueprints.stats",    "endpoint": "/api/blueprints/stats",    "method": "GET",  "tags": ["stats"]},
                {"id": "blueprints.health",   "endpoint": "/api/blueprints/health",   "method": "GET",  "tags": ["health"]},
            ],
            depends_on=["logic_engine", "zeus_forge", "zeus_mutator", "genome_manager"],
            boot_order=60,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5018, debug=True, use_reloader=False)
