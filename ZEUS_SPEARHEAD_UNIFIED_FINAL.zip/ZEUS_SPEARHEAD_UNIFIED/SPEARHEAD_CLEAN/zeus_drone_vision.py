"""
zeus_drone_vision.py
=======================
Zeus Drone ISR — Sensor & Imagery Processing
The Zeus Project 2026 — additive extension (v2.2)

Processes still/video frames captured during an ISR mission for
mapping and situational-awareness purposes:
  - Geotagging: stamps each captured frame with the position/attitude
    telemetry active at capture time (for photogrammetry/orthomosaic
    pipelines downstream — this module does not build the mosaic
    itself, it produces correctly-tagged inputs for one).
  - Change detection: diffs two captures of the same area taken at
    different times, useful for "what changed here since last pass"
    ISR review — flags regions of difference for a HUMAN ANALYST to
    review. It does not classify, track, or act on what changed.
  - Coverage-quality scoring: estimates how much of a planned mission
    polygon was actually photographically covered, for mission
    completeness QA.

Explicitly out of scope, by design: object tracking-to-engage, target
classification for weapons cueing, or any output structured as a
"this is the target, here are its coordinates for engagement" record.
Every output of this module is framed as an analyst-review artifact,
never an engagement instruction.

Optional dependency: opencv-python (cv2). Degrades gracefully — change
detection and quality scoring return a clear UNAVAILABLE status rather
than raising if cv2 is not installed, consistent with zeus_geo_vision.py.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("zeus.drone_vision")

try:
    import cv2
    import numpy as np
    CV2_OK = True
except ImportError:
    CV2_OK = False

DRONE_VISION_RING_TYPES = {
    "drone_frame_geotag":      2,   # routine capture metadata write
    "drone_change_detect":     3,   # read-only analysis over stored frames
    "drone_coverage_score":    3,
}


@dataclass
class GeotaggedFrame:
    frame_id: str
    mission_id: str
    captured_utc: str
    lat: float
    lon: float
    alt_m: float
    heading_deg: float
    gimbal_pitch_deg: float
    file_path: str
    sha256: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class FrameGeotagger:
    """
    Pairs an image file on disk with the telemetry sample active at
    capture time, producing a GeotaggedFrame record. Intended to be
    called once per captured frame, with the matching
    zeus_drone_telemetry.TelemetryStore.latest(mission_id) result
    passed in as `telemetry`.
    """

    def tag(self, image_path: str, mission_id: str, telemetry: Dict[str, Any]) -> Dict[str, Any]:
        if not os.path.exists(image_path):
            return {"success": False, "reason": "IMAGE_FILE_NOT_FOUND", "path": image_path}

        frame = GeotaggedFrame(
            frame_id="frame_" + uuid.uuid4().hex[:12],
            mission_id=mission_id,
            captured_utc=telemetry.get("timestamp_utc", datetime.now(timezone.utc).isoformat()),
            lat=telemetry.get("lat", 0.0),
            lon=telemetry.get("lon", 0.0),
            alt_m=telemetry.get("alt_m", 0.0),
            heading_deg=telemetry.get("heading_deg", 0.0),
            gimbal_pitch_deg=telemetry.get("gimbal_pitch_deg", -90.0),
            file_path=image_path,
            sha256=_sha256_of_file(image_path),
        )
        result = frame.to_dict()
        result["success"] = True
        return result


class ChangeDetector:
    """
    Frame-differencing change detection between two geotagged captures
    of (approximately) the same area. Returns bounding boxes of
    changed regions for analyst review — a list of rectangles and a
    change-magnitude score, nothing more. This is the same structural
    pattern as zeus_geo_vision.py's OCR ROI handling (preprocess,
    threshold, structural analysis) applied to change detection
    instead of text.
    """

    def compare(self, image_path_before: str, image_path_after: str,
                min_area_px: int = 400) -> Dict[str, Any]:
        if not CV2_OK:
            return {"success": False, "reason": "CV2_UNAVAILABLE_MISSING_DEPENDENCY"}
        if not (os.path.exists(image_path_before) and os.path.exists(image_path_after)):
            return {"success": False, "reason": "ONE_OR_BOTH_IMAGES_NOT_FOUND"}

        img_a = cv2.imread(image_path_before)
        img_b = cv2.imread(image_path_after)
        if img_a is None or img_b is None:
            return {"success": False, "reason": "IMAGE_DECODE_FAILED"}

        h = min(img_a.shape[0], img_b.shape[0])
        w = min(img_a.shape[1], img_b.shape[1])
        img_a = cv2.resize(img_a, (w, h))
        img_b = cv2.resize(img_b, (w, h))

        gray_a = cv2.cvtColor(img_a, cv2.COLOR_BGR2GRAY)
        gray_b = cv2.cvtColor(img_b, cv2.COLOR_BGR2GRAY)
        gray_a = cv2.GaussianBlur(gray_a, (5, 5), 0)
        gray_b = cv2.GaussianBlur(gray_b, (5, 5), 0)

        diff = cv2.absdiff(gray_a, gray_b)
        _, thresh = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)
        thresh = cv2.dilate(thresh, None, iterations=2)

        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        regions = []
        for c in contours:
            area = cv2.contourArea(c)
            if area < min_area_px:
                continue
            x, y, bw, bh = cv2.boundingRect(c)
            regions.append({"x": x, "y": y, "width": bw, "height": bh, "area_px": int(area)})

        regions.sort(key=lambda r: r["area_px"], reverse=True)
        change_pct = round(100.0 * (thresh > 0).sum() / thresh.size, 2)

        return {
            "success": True,
            "change_magnitude_pct": change_pct,
            "changed_region_count": len(regions),
            "changed_regions": regions[:50],   # cap for sane response size
            "note": "Regions flagged for analyst review only — no automated "
                    "classification or action is taken on detected changes.",
        }


class CoverageQualityScorer:
    """
    Compares a mission's actual geotagged-frame footprint against its
    planned coverage polygon, to QA whether the area was actually
    photographed as intended (gaps from wind drift, gimbal issues,
    early RTL on low battery, etc).
    """

    def score(self, planned_polygon: List[Tuple[float, float]],
              frames: List[Dict[str, Any]], grid_cells_per_side: int = 20) -> Dict[str, Any]:
        if not frames:
            return {"success": False, "reason": "NO_FRAMES_PROVIDED"}

        from zeus_drone_coverage import polygon_bounds, point_in_polygon
        min_lat, max_lat, min_lon, max_lon = polygon_bounds(planned_polygon)
        if max_lat <= min_lat or max_lon <= min_lon:
            return {"success": False, "reason": "DEGENERATE_POLYGON"}

        lat_step = (max_lat - min_lat) / grid_cells_per_side
        lon_step = (max_lon - min_lon) / grid_cells_per_side

        planned_cells = set()
        for i in range(grid_cells_per_side):
            for j in range(grid_cells_per_side):
                clat = min_lat + (i + 0.5) * lat_step
                clon = min_lon + (j + 0.5) * lon_step
                if point_in_polygon(clat, clon, planned_polygon):
                    planned_cells.add((i, j))

        covered_cells = set()
        for f in frames:
            lat, lon = f.get("lat"), f.get("lon")
            if lat is None or lon is None:
                continue
            i = int((lat - min_lat) / lat_step) if lat_step else 0
            j = int((lon - min_lon) / lon_step) if lon_step else 0
            if (i, j) in planned_cells:
                covered_cells.add((i, j))

        coverage_pct = round(100.0 * len(covered_cells) / max(len(planned_cells), 1), 1)
        gap_cells = planned_cells - covered_cells

        return {
            "success": True,
            "planned_cells": len(planned_cells),
            "covered_cells": len(covered_cells),
            "coverage_pct": coverage_pct,
            "gap_cell_count": len(gap_cells),
            "grid_resolution": grid_cells_per_side,
            "quality_flag": "COMPLETE" if coverage_pct >= 95 else
                            "PARTIAL_GAPS" if coverage_pct >= 70 else
                            "SIGNIFICANT_GAPS_RECOMMEND_RESORTIE",
        }
