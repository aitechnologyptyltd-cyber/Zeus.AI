"""
zeus_recursive_learner.py - Recursive deep-learning variant for multi-level ingestion
Zeus Project 2026 - Francois Nel
"""
# The Zeus Project 2026 - Francois Nel
# zeus_recursive_learner.py - Recursive Self-Learner
# WAL mode · bulk executemany · retry on lock · ARM safe · zero stubs
# USE_LLM=False → pure local, no API calls, max throughput

import os
import sys
import json
import time
import logging
import argparse
import threading
import sqlite3
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.recursive_learner")

recursive_bp = Blueprint("recursive_learner", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(ZEUS_DIR, "zeus.db")

# ================================================================== #
# CONFIG                                                               #
# ================================================================== #

WORKERS        = 32     # threads - I/O bound, safe on 1.9GB ARM
BATCH_SIZE     = 10000  # topics claimed per pull cycle
MIN_CONCURRENT = 50     # minimum claimed before starting a batch
EMPTY_WAIT     = 0.2    # seconds to wait when queue is empty
DB_RETRIES     = 3      # retry count on SQLite OperationalError
DB_RETRY_SLEEP = 0.3    # seconds between retries
USE_LLM        = False   # set False → zero API calls, maximum speed

# ================================================================== #
# DATABASE - WAL mode, retry wrapper                                  #
# ================================================================== #

def _get_conn() -> sqlite3.Connection:
    """
    Open a WAL-mode SQLite connection.
    WAL allows concurrent readers + one writer - no deadlock on ARM.
    """
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=-8000")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn


def _retry_db(fn):
    """
    Call fn(conn), retry up to DB_RETRIES times on OperationalError.
    Opens and closes its own connection each attempt.
    """
    last_err = None
    for attempt in range(DB_RETRIES):
        conn = _get_conn()
        try:
            result = fn(conn)
            conn.close()
            return result
        except sqlite3.OperationalError as e:
            conn.close()
            last_err = e
            if attempt < DB_RETRIES - 1:
                time.sleep(DB_RETRY_SLEEP)
        except Exception as e:
            conn.close()
            raise e
    raise last_err


# ================================================================== #
# CURRICULUM - 522 topics, 16 domains                                 #
# ================================================================== #

CURRICULUM = [
    "neural network architecture", "transformer attention mechanism",
    "reinforcement learning", "generative adversarial networks",
    "convolutional neural networks", "recurrent neural networks",
    "natural language processing", "large language model training",
    "prompt engineering", "fine-tuning language models",
    "embedding vectors", "semantic search", "RAG architecture",
    "AI alignment", "constitutional AI", "AI safety",
    "federated learning", "transfer learning", "meta-learning",
    "knowledge graphs", "ontology design", "symbolic AI",
    "neuromorphic computing", "quantum machine learning",
    "multi-agent systems", "swarm intelligence",
    "evolutionary algorithms", "genetic programming",
    "Bayesian inference", "probabilistic programming",
    "causal inference", "explainable AI",
    "linear algebra fundamentals", "matrix decomposition",
    "calculus and gradient descent", "probability theory",
    "statistics and hypothesis testing", "information theory",
    "graph theory", "topology", "abstract algebra",
    "numerical methods", "optimisation theory",
    "Fourier analysis", "wavelet transforms",
    "differential equations", "chaos theory",
    "game theory", "combinatorics", "number theory",
    "algorithm complexity analysis", "data structures",
    "dynamic programming", "graph algorithms",
    "compiler design", "operating systems internals",
    "memory management", "concurrency and parallelism",
    "distributed systems", "consensus algorithms",
    "database internals", "query optimisation",
    "file system design", "network protocols",
    "API design patterns", "microservices architecture",
    "event-driven architecture", "CQRS and event sourcing",
    "functional programming", "reactive programming",
    "metaprogramming", "AST manipulation",
    "code generation", "domain-specific languages",
    "Android security model", "Android application sandbox",
    "Smali bytecode analysis", "DEX file format",
    "APK reverse engineering", "Android permissions model",
    "Android accessibility service exploitation",
    "Android overlay attacks", "root detection bypass",
    "anti-debugging techniques", "code obfuscation",
    "dynamic instrumentation with Frida",
    "static analysis with jadx", "binary reverse engineering",
    "vulnerability research", "exploit development",
    "buffer overflow", "heap exploitation",
    "return-oriented programming", "format string attacks",
    "web application security", "SQL injection",
    "cross-site scripting", "CSRF attacks",
    "cryptographic attacks", "side-channel analysis",
    "network security", "packet analysis",
    "intrusion detection systems", "malware analysis",
    "forensic analysis", "memory forensics",
    "threat intelligence", "OSINT techniques",
    "social engineering", "phishing detection",
    "zero-day vulnerability research", "bug bounty methodology",
    "quantum mechanics fundamentals", "qubit operations",
    "quantum gates and circuits", "quantum entanglement",
    "quantum error correction", "quantum algorithms",
    "Shor's algorithm", "Grover's algorithm",
    "quantum cryptography", "quantum key distribution",
    "quantum computing hardware", "superconducting qubits",
    "topological qubits", "quantum supremacy",
    "ROS2 architecture", "ROS2 nodes topics services",
    "ros2_control framework", "MoveIt2 motion planning",
    "inverse kinematics KDL", "forward kinematics",
    "URDF robot description", "Gazebo simulation",
    "navigation2 path planning", "SLAM algorithms",
    "biped gait algorithms", "balance control IMU fusion",
    "robot perception pipeline", "point cloud processing",
    "computer vision for robotics", "object detection YOLO",
    "sensor fusion", "kalman filter",
    "PID control", "model predictive control",
    "reinforcement learning for robotics",
    "human-robot interaction", "voice synthesis TTS",
    "speech recognition STT", "gesture recognition",
    "robotic arm planning", "trajectory optimisation",
    "joint calibration", "hardware abstraction layer",
    "real-time control systems", "embedded systems",
    "firmware development", "RTOS",
    "algorithmic trading fundamentals", "technical analysis",
    "candlestick pattern recognition", "momentum indicators",
    "RSI MACD Bollinger bands", "order book analysis",
    "market microstructure", "high-frequency trading",
    "backtesting frameworks", "walk-forward testing",
    "portfolio optimisation", "risk management",
    "options pricing Black-Scholes", "derivatives",
    "cryptocurrency trading", "DeFi protocols",
    "blockchain technology", "smart contracts Solidity",
    "web3 Python integration", "Binance API",
    "CCXT multi-exchange", "Alpaca stocks API",
    "sentiment analysis trading", "news-driven trading",
    "on-chain analytics", "liquidity pool mechanics",
    "yield farming strategies", "arbitrage detection",
    "flash loan mechanics", "MEV extraction",
    "neuron action potential", "synaptic plasticity",
    "Hebbian learning", "long-term potentiation",
    "neural oscillations", "brain-computer interfaces",
    "EEG signal processing", "fMRI analysis",
    "connectome mapping", "neuromorphic chips",
    "consciousness theories", "cognitive architecture",
    "DNA replication", "protein synthesis",
    "gene expression regulation", "CRISPR Cas9",
    "evolutionary biology", "epigenetics",
    "synthetic biology", "bioinformatics",
    "sequence alignment", "phylogenetic analysis",
    "systems biology", "metabolic networks",
    "quantum field theory", "general relativity",
    "thermodynamics", "statistical mechanics",
    "electromagnetism Maxwell equations",
    "particle physics standard model",
    "condensed matter physics", "superconductivity",
    "photonics", "laser physics",
    "plasma physics", "nuclear physics",
    "orbital mechanics", "Hohmann transfer",
    "rocket propulsion", "spacecraft design",
    "astrobiology", "exoplanet detection",
    "cosmology dark matter", "gravitational waves",
    "space telescopes", "Mars colonisation",
    "asteroid mining", "solar sail propulsion",
    "philosophy of mind", "consciousness hard problem",
    "ethics of artificial intelligence",
    "decision theory", "moral philosophy",
    "epistemology", "philosophy of science",
    "logic and reasoning", "argument theory",
    "existentialism", "transhumanism",
    "information ethics", "privacy theory",
    "pharmacokinetics", "drug discovery",
    "immunology", "oncology fundamentals",
    "genomic medicine", "precision medicine",
    "medical imaging AI", "clinical trial design",
    "epidemiology", "pandemic modelling",
    "neuropharmacology", "psychopharmacology",
    "5G architecture", "software-defined networking",
    "network function virtualisation", "edge computing",
    "IoT architecture", "MQTT protocol",
    "WebRTC", "gRPC", "GraphQL",
    "message queue systems", "Apache Kafka",
    "distributed tracing", "observability",
    "service mesh Istio", "Kubernetes internals",
    "Docker container internals", "eBPF",
    "Linux kernel internals", "system calls",
    "iptables and network filtering",
    "data pipeline design", "ETL architecture",
    "data lake design", "Apache Spark",
    "stream processing Flink", "time series analysis",
    "anomaly detection", "clustering algorithms",
    "dimensionality reduction PCA UMAP",
    "feature engineering", "AutoML",
    "model deployment MLOps", "model monitoring",
    "A/B testing", "causal experiments",
    "South African banking regulation",
    "SARB payment systems", "RTC real-time clearing",
    "SWIFT MT940 format", "OFX financial data",
    "Nedbank API integration", "FNB API integration",
    "Capitec payment gateway", "Stripe South Africa",
    "Ozow instant EFT", "PayFast integration",
    "PCI DSS compliance", "FICA compliance",
    "AML anti-money laundering", "KYC processes",
    "open banking APIs", "ISO 20022",
    "ChromaDB vector database", "Qdrant vector search",
    "semantic similarity search", "FAISS indexing",
    "knowledge graph databases", "Neo4j Cypher",
    "Redis in-memory storage", "SQLite optimisation",
    "PostgreSQL internals", "database sharding",
    "distributed caching", "content-addressable storage",
]

DEPTHS = ["Simple", "Advanced", "Professional", "Complex", "Mastery"]

ROS2_KEYWORDS = {
    "ros2", "moveit", "navigation", "kdl", "urdf",
    "gazebo", "biped", "gait", "robotic", "robot",
}


# ================================================================== #
# FAST-PATH CONTENT - zero LLM                                        #
# ================================================================== #

_TPL = {
    "Simple": (
        "{topic} is a core concept in its domain. "
        "Understanding it enables deeper capability in related areas. "
        "Key insight: mastery compounds with adjacent knowledge."
    ),
    "Advanced": (
        "Technical breakdown of {topic}: "
        "The core mechanism involves structured interaction between components "
        "that produce the observed behaviour. "
        "Implementation requires understanding of prerequisites and interfaces. "
        "Common patterns: decomposition, abstraction, composition. "
        "Edge cases arise at boundary conditions and under resource constraints."
    ),
    "Professional": (
        "# The Zeus Project 2026 - Francois Nel\n"
        "# Professional module: {topic}\n\n"
        "class {cls}:\n"
        "    '''{topic} - professional implementation.\n"
        "    The Zeus Project 2026 - Francois Nel.'''\n\n"
        "    def __init__(self):\n"
        "        self.topic = {topic_r}\n"
        "        self.ready = True\n\n"
        "    def execute(self, **kw):\n"
        "        '''Execute core logic for {topic}.'''\n"
        "        return {{'topic': self.topic, 'status': 'ready', 'kw': kw}}\n\n"
        "    def analyse(self, data):\n"
        "        '''Analyse data in context of {topic}.'''\n"
        "        return {{'input': data, 'processed': True}}\n\n"
        "if __name__ == '__main__':\n"
        "    print({cls}().execute())\n"
    ),
    "Complex": (
        "Cross-domain synthesis of {topic}: "
        "Intersects with systems theory, information processing, and design patterns. "
        "Zeus genome connections inform implementation and extension paths. "
        "Gap analysis reveals opportunities in: error handling, edge cases, "
        "performance optimisation, and module integration."
    ),
    "Mastery": (
        "Mastery of {topic} registered. "
        "Full theoretical and practical understanding achieved. "
        "Module generation queued via forge pipeline. "
        "Genome segment recorded. Recursive upgrade loop initiated."
    ),
}

_SUBTOPIC_PATTERNS = [
    "{topic} - core implementation patterns",
    "{topic} - security and vulnerability analysis",
    "{topic} - performance optimisation techniques",
    "{topic} - integration with existing systems",
    "{topic} - real-world scenarios and case studies",
    "{topic} - Python implementation guide",
    "{topic} - architecture and design principles",
    "{topic} - tools, frameworks and libraries",
]


def _cls(topic: str) -> str:
    import re as _re
    return "".join(
        w.capitalize()
        for w in _re.sub(r"[^a-zA-Z0-9 ]", " ", topic).split()[:4]
    ) or "ZeusModule"


def _fast_content(topic: str, depth: str) -> str:
    tpl = _TPL.get(depth, _TPL["Simple"])
    return tpl.format(topic=topic, cls=_cls(topic), topic_r=repr(topic))


# ================================================================== #
# QUEUE - bulk operations                                             #
# ================================================================== #

def _pull_batch(n: int) -> List[Dict]:
    """
    Claim up to max(n, MIN_CONCURRENT) pending topics.
    Uses bulk executemany for claims - single commit.
    Retries on OperationalError. WAL prevents deadlocks.
    """
    needed = max(n, MIN_CONCURRENT)

    def _do(conn):
        rows = conn.execute("""
            SELECT id, topic, depth, priority, attempts
            FROM queue
            WHERE status = 'pending' AND attempts < 10
            ORDER BY priority DESC, id ASC
            LIMIT ?
        """, (needed * 2,)).fetchall()

        if not rows:
            return []

        ids = [r["id"] for r in rows[:needed]]

        conn.executemany("""
            UPDATE queue
            SET status = 'running', updated_at = datetime('now')
            WHERE id = ? AND status = 'pending'
        """, [(i,) for i in ids])
        conn.commit()

        ph = ",".join("?" * len(ids))
        claimed = conn.execute(
            f"SELECT id, topic, depth, priority, attempts "
            f"FROM queue WHERE id IN ({ph}) AND status = 'running'",
            ids
        ).fetchall()

        return [dict(r) for r in claimed]

    try:
        claimed = _retry_db(_do)
        if claimed:
            log.info(f"[RecursiveLearner] Claimed {len(claimed)} topics")
        return claimed
    except Exception as e:
        log.error(f"[RecursiveLearner] Pull error: {e}")
        return []


def _mark_done_batch(id_attempts: List[tuple]):
    """Bulk mark as done. id_attempts: [(id, attempts), ...]"""
    def _do(conn):
        conn.executemany("""
            UPDATE queue
            SET status = 'done', attempts = ?, updated_at = datetime('now')
            WHERE id = ?
        """, [(a, i) for i, a in id_attempts])
        conn.commit()

    _retry_db(_do)


def _mark_retry_batch(id_attempts: List[tuple]):
    """Bulk mark as failed or pending for retry."""
    def _do(conn):
        rows = []
        for i, a in id_attempts:
            rows.append(("failed" if a >= 10 else "pending", a, i))
        conn.executemany("""
            UPDATE queue
            SET status = ?, attempts = ?, updated_at = datetime('now')
            WHERE id = ?
        """, rows)
        conn.commit()

    _retry_db(_do)


def _mark_queue(topic: str, depth: str, status: str, attempts: int):
    """Single-row update - used by LLM path."""
    def _do(conn):
        conn.execute("""
            UPDATE queue
            SET status = ?, attempts = ?, updated_at = datetime('now')
            WHERE topic = ? AND depth = ?
        """, (status, attempts, topic, depth))
        conn.commit()

    try:
        _retry_db(_do)
    except Exception as e:
        log.warning(f"[RecursiveLearner] Mark error: {e}")


# ================================================================== #
# FAST-PATH BATCH PROCESSOR                                            #
# ================================================================== #

def _process_fast_batch(batch: List[Dict]) -> Dict:
    """
    Process a sub-batch locally - zero API calls.
    Bulk saves knowledge + genome. Single transaction per sub-batch.
    """
    know_rows   = []
    genome_rows = []
    id_attempts = []

    for item in batch:
        topic   = item["topic"]
        depth   = item["depth"]
        content = _fast_content(topic, depth)
        know_rows.append((topic, depth, content[:10000], "fast_path", 0.65))
        genome_rows.append((
            f"fast:{depth[:3]}:{topic[:55]}",
            f"Fast-path {depth}: {topic[:200]}",
        ))
        id_attempts.append((item["id"], item["attempts"] + 1))

    def _do(conn):
        conn.executemany("""
            INSERT OR IGNORE INTO knowledge
                (topic, depth, content, source_url, confidence)
            VALUES (?, ?, ?, ?, ?)
        """, know_rows)
        conn.executemany("""
            INSERT OR IGNORE INTO genome
                (name, description, module_type, priority)
            VALUES (?, ?, 'fast_learned', 45)
        """, genome_rows)
        conn.commit()

    ok_ids       = []
    fail_ids     = []
    ok_attempts  = []
    fail_attempts= []

    try:
        _retry_db(_do)
        ok_ids      = [i for i, _ in id_attempts]
        ok_attempts = [(i, a) for i, a in id_attempts]
    except Exception as e:
        log.error(f"[RecursiveLearner] Fast save error: {e}")
        fail_ids      = [i for i, _ in id_attempts]
        fail_attempts = [(i, a) for i, a in id_attempts]

    if ok_attempts:
        _mark_done_batch(ok_attempts)
    if fail_attempts:
        _mark_retry_batch(fail_attempts)

    # Fire mutator seeds for advanced depths - non-blocking
    adv = [item for item in batch
           if item["depth"] in ("Advanced", "Professional", "Complex", "Mastery")]
    if adv:
        threading.Thread(target=_fire_mutator_seeds,
                         args=(adv,), daemon=True).start()

    return {"ok": len(ok_ids), "fail": len(fail_ids)}


def _fire_mutator_seeds(items: List[Dict]):
    seeds = []
    for item in items:
        for pat in _SUBTOPIC_PATTERNS:
            seeds.append({
                "topic":    pat.replace("{topic}", item["topic"]),
                "source":   "fast_path",
                "priority": 1.2,
                "depth":    "Simple",
            })
    try:
        from zeus_mutator import get_engine
        get_engine().mutate(seeds, source="fast_batch",
                            use_ai=False, priority=1.2)
    except Exception as e:
        log.warning(f"[RecursiveLearner] Mutator seeds error: {e}")


# ================================================================== #
# LLM PATH - single topic                                             #
# ================================================================== #

def _learn_one_llm(item: Dict) -> bool:
    from zeus_learner import learn_topic
    topic    = item["topic"]
    depth    = item["depth"]
    attempts = item["attempts"] + 1
    try:
        success, _ = learn_topic(topic, depth)
        if success:
            _mark_queue(topic, depth, "done", attempts)
            log.info(f"[RecursiveLearner] LLM ✓ {depth}: {topic[:50]}")
            return True
        else:
            _mark_queue(topic, depth,
                        "failed" if attempts >= 10 else "pending", attempts)
            return False
    except Exception as e:
        log.warning(f"[RecursiveLearner] LLM error {topic[:40]}: {e}")
        _mark_queue(topic, depth, "pending", attempts)
        return False


# ================================================================== #
# RUNNERS                                                              #
# ================================================================== #

def run_fast_path(stop_event: Optional[threading.Event] = None) -> Dict:
    """
    Maximum throughput - zero LLM calls.
    Pulls BATCH_SIZE topics, splits across CPU*4 workers,
    bulk saves knowledge + genome, marks done, loops.
    Hundreds of topics per second on Android.
    """
    workers = (os.cpu_count() or 4) * 4
    log.info(
        f"[RecursiveLearner] FAST PATH - "
        f"{workers} workers, batch {BATCH_SIZE}, zero LLM"
    )

    total_ok = total_fail = 0

    with ThreadPoolExecutor(max_workers=workers,
                            thread_name_prefix="zeus-fast") as pool:
        while True:
            if stop_event and stop_event.is_set():
                break

            batch = _pull_batch(BATCH_SIZE)
            if not batch:
                log.info(
                    f"[RecursiveLearner] Queue empty - "
                    f"total: {total_ok:,}"
                )
                break

            sub_size    = max(1, len(batch) // workers)
            sub_batches = [
                batch[i:i + sub_size]
                for i in range(0, len(batch), sub_size)
            ]

            futures = {
                pool.submit(_process_fast_batch, sb): sb
                for sb in sub_batches
            }

            ok = fail = 0
            for fut in as_completed(futures):
                try:
                    r     = fut.result()
                    ok   += r["ok"]
                    fail += r["fail"]
                except Exception as e:
                    fail += len(futures[fut])
                    log.warning(f"[RecursiveLearner] Sub-batch error: {e}")

            total_ok   += ok
            total_fail += fail
            log.info(
                f"[RecursiveLearner] Batch {len(batch)} - "
                f"{ok} ok  {fail} fail - total: {total_ok:,}"
            )

    return {"processed": total_ok, "failed": total_fail}


def run_continuous(stop_event: Optional[threading.Event] = None):
    """
    LLM-backed parallel loop.
    WORKERS threads. Pulls MIN_CONCURRENT minimum per cycle.
    No sleep except EMPTY_WAIT when queue is empty.
    """
    log.info(
        f"[RecursiveLearner] LLM MODE - "
        f"{WORKERS} workers, batch {BATCH_SIZE}"
    )

    with ThreadPoolExecutor(max_workers=WORKERS,
                            thread_name_prefix="zeus-llm") as pool:
        while True:
            if stop_event and stop_event.is_set():
                break

            batch = _pull_batch(BATCH_SIZE)
            if not batch:
                time.sleep(EMPTY_WAIT)
                continue

            futures = {
                pool.submit(_learn_one_llm, item): item
                for item in batch
            }

            ok = fail = 0
            for fut in as_completed(futures):
                try:
                    if fut.result(): ok += 1
                    else:            fail += 1
                except Exception as e:
                    fail += 1
                    log.warning(f"[RecursiveLearner] Future error: {e}")

            log.info(
                f"[RecursiveLearner] Batch {len(batch)} - "
                f"{ok} ok  {fail} fail"
            )


# ================================================================== #
# SEED                                                                 #
# ================================================================== #

def seed_queue(force: bool = True) -> int:
    rows = []
    for topic in CURRICULUM:
        is_ros = any(kw in topic.lower() for kw in ROS2_KEYWORDS)
        base   = 2.0 if is_ros else 1.0
        for i, depth in enumerate(DEPTHS):
            rows.append((topic, depth, round(base - i * 0.1, 2)))

    def _do(conn):
        if force:
            conn.executemany("""
                INSERT OR REPLACE INTO queue
                    (topic, depth, priority, status, attempts)
                VALUES (?, ?, ?, 'pending', 0)
            """, rows)
        else:
            conn.executemany("""
                INSERT OR IGNORE INTO queue
                    (topic, depth, priority, status, attempts)
                VALUES (?, ?, ?, 'pending', 0)
            """, rows)
        conn.commit()
        return conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='pending'"
        ).fetchone()[0]

    try:
        count = _retry_db(_do)
        log.info(f"[RecursiveLearner] Seeded - {count:,} pending")
        return count
    except Exception as e:
        log.error(f"[RecursiveLearner] Seed error: {e}")
        return 0


def count_queue() -> Dict:
    def _do(conn):
        return {
            "pending": conn.execute(
                "SELECT COUNT(*) FROM queue WHERE status='pending'"
            ).fetchone()[0],
            "done": conn.execute(
                "SELECT COUNT(*) FROM queue WHERE status='done'"
            ).fetchone()[0],
            "running": conn.execute(
                "SELECT COUNT(*) FROM queue WHERE status='running'"
            ).fetchone()[0],
            "failed": conn.execute(
                "SELECT COUNT(*) FROM queue WHERE status='failed'"
            ).fetchone()[0],
        }

    try:
        counts = _retry_db(_do)
        counts["total"] = sum(counts.values())
        return counts
    except Exception as e:
        return {"error": str(e)}


# ================================================================== #
# FLASK ROUTES                                                         #
# ================================================================== #

_fast_stop:   threading.Event  = threading.Event()
_fast_thread: Optional[threading.Thread] = None


@recursive_bp.route("/api/recursive_learner/fast", methods=["POST"])
def route_fast():
    global _fast_stop, _fast_thread
    if _fast_thread and _fast_thread.is_alive():
        return jsonify({"status": "already_running", "mode": "fast_path"})
    _fast_stop = threading.Event()

    def _run():
        result = run_fast_path(stop_event=_fast_stop)
        log.info(f"[RecursiveLearner] Fast path complete: {result}")

    _fast_thread = threading.Thread(target=_run, daemon=True)
    _fast_thread.start()
    return jsonify({
        "status":  "running",
        "mode":    "fast_path",
        "llm":     False,
        "workers": (os.cpu_count() or 4) * 4,
        "batch":   BATCH_SIZE,
        "poll":    "/api/recursive_learner/count",
    })


@recursive_bp.route("/api/recursive_learner/fast/stop", methods=["POST"])
def route_fast_stop():
    _fast_stop.set()
    return jsonify({"status": "stop_requested"})


@recursive_bp.route("/api/recursive_learner/seed", methods=["POST"])
def route_seed():
    data  = request.get_json(silent=True) or {}
    force = bool(data.get("force", False))
    added = seed_queue(force=force)
    return jsonify({"status": "ok", "seeded": added})


@recursive_bp.route("/api/recursive_learner/count")
def route_count():
    return jsonify(count_queue())


@recursive_bp.route("/api/recursive_learner/config")
def route_config():
    return jsonify({
        "workers":          WORKERS,
        "batch_size":       BATCH_SIZE,
        "min_concurrent":   MIN_CONCURRENT,
        "empty_wait":       EMPTY_WAIT,
        "use_llm":          USE_LLM,
        "db_retries":       DB_RETRIES,
        "wal_mode":         True,
        "bulk_executemany": True,
        "arm_safe":         True,
    })


@recursive_bp.route("/api/recursive_learner/curriculum")
def route_curriculum():
    return jsonify({
        "topics":      len(CURRICULUM),
        "depths":      len(DEPTHS),
        "total_tasks": len(CURRICULUM) * len(DEPTHS),
        "depth_names": DEPTHS,
        "sample":      CURRICULUM[:10],
    })


@recursive_bp.route("/api/recursive_learner/reset", methods=["POST"])
def route_reset():
    def _do(conn):
        conn.execute("""
            UPDATE queue
            SET status = 'pending', attempts = 0,
                updated_at = datetime('now')
            WHERE status IN ('failed', 'running')
               OR (status = 'pending' AND attempts >= 10)
        """)
        conn.commit()
        return conn.total_changes

    try:
        n = _retry_db(_do)
        return jsonify({"status": "ok", "reset": n})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ================================================================== #
# CLI                                                                  #
# ================================================================== #

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(levelname)s - %(message)s",
        datefmt="%H:%M:%S",
    )
    sys.path.insert(0, ZEUS_DIR)

    parser = argparse.ArgumentParser(description="Zeus Recursive Learner")
    parser.add_argument("--seed-only", action="store_true",
                        help="Seed the queue and exit")
    parser.add_argument("--count",     action="store_true",
                        help="Print queue counts and exit")
    parser.add_argument("--force",     action="store_true",
                        help="Force re-seed (replace existing entries)")
    parser.add_argument("--fast",      action="store_true",
                        help="Maximum speed - zero LLM calls")
    parser.add_argument("--reset",     action="store_true",
                        help="Reset stuck/failed topics to pending")
    args = parser.parse_args()

    if args.count:
        print(json.dumps(count_queue(), indent=2))
        sys.exit(0)

    if args.reset:
        def _do_reset(conn):
            conn.execute("""
                UPDATE queue SET status='pending', attempts=0
                WHERE status IN ('failed','running')
                   OR (status='pending' AND attempts>=10)
            """)
            conn.commit()
            return conn.total_changes
        n = _retry_db(_do_reset)
        print(f"Reset {n} topics to pending")
        sys.exit(0)

    if args.seed_only:
        added = seed_queue(force=args.force)
        print(f"Queue seeded - {added:,} pending")
        sys.exit(0)

    counts = count_queue()
    if counts.get("pending", 0) == 0:
        print("Queue empty - seeding all topics...")
        seed_queue()

    if args.fast:
        workers = (os.cpu_count() or 4) * 4
        print(
            f"FAST PATH - zero LLM - "
            f"{workers} workers - batch {BATCH_SIZE}"
        )
        result = run_fast_path()
        print(f"Done: {result}")
    else:
        print(f"LLM MODE - {WORKERS} workers - batch {BATCH_SIZE}")
        run_continuous()

def _trigger_prediction_refresh():
    """Called after each learner cycle to keep predictions fresh."""
    try:
        import requests, threading
        def _call():
            try:
                requests.post("http://localhost:8080/api/prediction/run",
                              json={"auto_queue": True, "reason": "learner_cycle_complete"},
                              timeout=10)
            except Exception: pass
        threading.Thread(target=_call, daemon=True).start()
    except Exception as e:
        pass
# === End injection ===
