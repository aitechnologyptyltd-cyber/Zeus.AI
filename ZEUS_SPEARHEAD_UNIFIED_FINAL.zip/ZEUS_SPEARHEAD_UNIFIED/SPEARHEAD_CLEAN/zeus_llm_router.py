# The Zeus Project 2026 — Francois Nel
# zeus_llm_router.py — Unified LLM Router
# Circuit Breaker · Retry with back-off · Token tracking · Model selection
# Engine chain: Groq (fast) → Claude (deep) → OpenRouter (fallback)
# Importable by every Zeus module — never bypass this router.

import os
import re
import time
import json
import uuid
import math
import logging
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.llm")

llm_bp = Blueprint("llm", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================================
# MODEL CONSTANTS
# ============================================================================

GROQ_MODEL_FAST   = os.environ.get("GROQ_MODEL_FAST",   "llama-3.1-8b-instant")
GROQ_MODEL_SMART  = os.environ.get("GROQ_MODEL",        "llama-3.3-70b-versatile")
CLAUDE_MODEL      = os.environ.get("LLM_MODEL",         "claude-sonnet-4-6")
OPENROUTER_MODEL  = os.environ.get("OPENROUTER_MODEL",  "x-ai/grok-3")

# OFFLINE engine — no API key required, always available. Tries a local
# Ollama server first (real local inference, zero-config if installed —
# https://ollama.com, free, cross-platform), then falls back to a
# deterministic template responder so Zeus never hard-fails just because
# no cloud LLM key is configured. See _offline() below.
OLLAMA_HOST       = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL      = os.environ.get("OLLAMA_MODEL", "llama3.2")
OLLAMA_TIMEOUT_S  = float(os.environ.get("OLLAMA_TIMEOUT_S", "4"))

DEFAULT_MAX_TOKENS = 2048
DEFAULT_TEMPERATURE = 0.7

# ============================================================================
# CIRCUIT BREAKER
# ============================================================================

class CircuitState(Enum):
    CLOSED   = auto()   # normal operation
    OPEN     = auto()   # blocking calls
    HALF_OPEN = auto()  # testing recovery


@dataclass
class CircuitBreaker:
    """
    Per-engine circuit breaker.
    CLOSED → failure threshold → OPEN → cooldown → HALF_OPEN → success → CLOSED.
    """
    name:              str
    failure_threshold: int   = 5
    success_threshold: int   = 2
    cooldown_s:        float = 60.0

    _state:           CircuitState = field(default=CircuitState.CLOSED, init=False, repr=False)
    _failure_count:   int          = field(default=0,    init=False, repr=False)
    _success_count:   int          = field(default=0,    init=False, repr=False)
    _last_failure_ts: float        = field(default=0.0,  init=False, repr=False)
    _lock:            Any          = field(default_factory=threading.RLock, init=False, repr=False)

    def allow_request(self) -> bool:
        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True
            if self._state == CircuitState.OPEN:
                if time.time() - self._last_failure_ts >= self.cooldown_s:
                    self._state = CircuitState.HALF_OPEN
                    log.info(f"[LLM:CB:{self.name}] → HALF_OPEN")
                    return True
                return False
            # HALF_OPEN
            return True

    def record_success(self) -> None:
        with self._lock:
            self._failure_count = 0
            if self._state == CircuitState.HALF_OPEN:
                self._success_count += 1
                if self._success_count >= self.success_threshold:
                    self._state         = CircuitState.CLOSED
                    self._success_count = 0
                    log.info(f"[LLM:CB:{self.name}] → CLOSED (recovered)")

    def record_failure(self) -> None:
        with self._lock:
            self._failure_count += 1
            self._last_failure_ts = time.time()
            self._success_count   = 0
            if self._failure_count >= self.failure_threshold or self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
                log.warning(
                    f"[LLM:CB:{self.name}] → OPEN "
                    f"(failures={self._failure_count}, "
                    f"cooldown={self.cooldown_s}s)"
                )

    def state_info(self) -> Dict:
        with self._lock:
            return {
                "name":           self.name,
                "state":          self._state.name,
                "failure_count":  self._failure_count,
                "success_count":  self._success_count,
                "last_failure_ts": self._last_failure_ts,
                "cooldown_s":     self.cooldown_s,
            }


# ============================================================================
# RETRY POLICY
# ============================================================================

def _retry(fn, retries: int = 3, base_sleep: float = 0.5,
           on_error: callable = None):
    """
    Retry fn() up to `retries` times with exponential back-off.
    Calls on_error(exc) after each failure if provided.
    """
    last_exc = None
    for attempt in range(retries):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            if on_error:
                on_error(exc)
            if attempt < retries - 1:
                wait = base_sleep * (2 ** attempt)
                log.debug(f"[LLM] Retry {attempt+1}/{retries} in {wait:.1f}s: {exc}")
                time.sleep(wait)
    raise last_exc


# ============================================================================
# ENGINE STATS TRACKER
# ============================================================================

@dataclass
class EngineStats:
    name:          str
    calls:         int   = 0
    successes:     int   = 0
    failures:      int   = 0
    total_tokens:  int   = 0
    total_ms:      float = 0.0
    last_call_ts:  float = 0.0
    recent_errors: deque = field(default_factory=lambda: deque(maxlen=10))

    def record_call(self, tokens: int, ms: float, success: bool, error: str = "") -> None:
        self.calls        += 1
        self.last_call_ts  = time.time()
        self.total_ms     += ms
        if success:
            self.successes    += 1
            self.total_tokens += tokens
        else:
            self.failures += 1
            if error:
                self.recent_errors.append({"error": error[:200], "ts": time.time()})

    def success_rate(self) -> float:
        return round(self.successes / max(self.calls, 1), 4)

    def avg_ms(self) -> float:
        return round(self.total_ms / max(self.calls, 1), 1)

    def to_dict(self) -> Dict:
        return {
            "name":         self.name,
            "calls":        self.calls,
            "successes":    self.successes,
            "failures":     self.failures,
            "success_rate": self.success_rate(),
            "total_tokens": self.total_tokens,
            "avg_ms":       self.avg_ms(),
            "last_call":    datetime.fromtimestamp(self.last_call_ts, tz=timezone.utc).isoformat()
                            if self.last_call_ts else None,
            "recent_errors": list(self.recent_errors)[-3:],
        }


# ============================================================================
# LLM ROUTER (SINGLETON)
# ============================================================================

class LLMRouter:
    """
    Unified LLM router for all Zeus modules.
    Engine priority:
      1. Groq SMART  — fast, high token limit, best for bulk
      2. Groq FAST   — instant, small context, best for simple prompts
      3. Claude      — deepest reasoning, best for architecture/code
      4. OpenRouter  — last resort fallback
    Each engine has its own circuit breaker and stats tracker.
    """

    def __init__(self):
        self._lock     = threading.RLock()
        self._circuits = {
            "groq_smart":   CircuitBreaker("groq_smart",  failure_threshold=4, cooldown_s=45),
            "groq_fast":    CircuitBreaker("groq_fast",   failure_threshold=4, cooldown_s=30),
            "claude":       CircuitBreaker("claude",      failure_threshold=3, cooldown_s=60),
            "openrouter":   CircuitBreaker("openrouter",  failure_threshold=5, cooldown_s=90),
            # High threshold / short cooldown: offline should almost never
            # trip, but if Ollama is flapping we don't want to hammer it.
            "offline":      CircuitBreaker("offline",     failure_threshold=10, cooldown_s=5),
        }
        self._stats = {
            "groq_smart":  EngineStats("groq_smart"),
            "groq_fast":   EngineStats("groq_fast"),
            "claude":      EngineStats("claude"),
            "openrouter":  EngineStats("openrouter"),
            "offline":     EngineStats("offline"),
        }
        self._call_history: deque = deque(maxlen=200)
        self._total_calls:  int   = 0

    # ---- Public API ------------------------------------------------------

    def call(
        self,
        prompt:      str,
        system:      str  = "",
        engine:      str  = "auto",      # auto | groq | groq_fast | claude | openrouter
        max_tokens:  int  = DEFAULT_MAX_TOKENS,
        temperature: float = DEFAULT_TEMPERATURE,
        json_mode:   bool = False,
        retries:     int  = 2,
    ) -> str:
        """
        Route a prompt to the best available engine.
        Returns the text response or raises RuntimeError.
        """
        engines = self._resolve_engine_order(engine, len(prompt))
        last_exc = None

        for eng_name in engines:
            cb = self._circuits.get(eng_name)
            if cb and not cb.allow_request():
                log.debug(f"[LLM] {eng_name} circuit OPEN — skipping")
                continue
            try:
                t0  = time.time()
                txt = self._call_engine(
                    eng_name, prompt, system, max_tokens, temperature, json_mode, retries
                )
                ms  = round((time.time() - t0) * 1000, 1)
                tokens = self._estimate_tokens(prompt + txt)
                self._stats[eng_name].record_call(tokens, ms, True)
                cb and cb.record_success()
                self._log_call(eng_name, prompt, txt, ms, tokens, success=True)
                return txt
            except Exception as exc:
                ms = round((time.time() - t0) * 1000, 1) if 't0' in dir() else 0
                self._stats[eng_name].record_call(0, ms, False, str(exc))
                cb and cb.record_failure()
                self._log_call(eng_name, prompt, "", ms, 0, success=False, error=str(exc))
                last_exc = exc
                log.warning(f"[LLM] {eng_name} failed: {exc}")

        raise RuntimeError(
            f"All LLM engines exhausted. Last error: {last_exc}"
        )

    def call_groq(
        self,
        prompt:      str,
        system:      str  = "",
        max_tokens:  int  = DEFAULT_MAX_TOKENS,
        fast:        bool = False,
        retries:     int  = 2,
    ) -> str:
        """Direct Groq call. Raises RuntimeError on failure."""
        engine = "groq_fast" if fast else "groq_smart"
        return self.call(prompt, system=system, engine=engine,
                         max_tokens=max_tokens, retries=retries)

    def call_claude(
        self,
        prompt:      str,
        system:      str  = "",
        max_tokens:  int  = DEFAULT_MAX_TOKENS,
        retries:     int  = 2,
    ) -> str:
        """Direct Claude call. Raises RuntimeError on failure."""
        return self.call(prompt, system=system, engine="claude",
                         max_tokens=max_tokens, retries=retries)

    def call_with_fallback(
        self,
        prompt:      str,
        system:      str  = "",
        max_tokens:  int  = DEFAULT_MAX_TOKENS,
        primary:     str  = "groq",
        fallback:    str  = "claude",
    ) -> Tuple[str, str]:
        """
        Try primary engine; if it fails, try fallback.
        Returns (text, engine_used).
        """
        for eng in [primary, fallback]:
            try:
                txt = self.call(prompt, system=system, engine=eng, max_tokens=max_tokens)
                return txt, eng
            except Exception as e:
                log.warning(f"[LLM] {eng} failed in fallback chain: {e}")
        raise RuntimeError(f"Both {primary} and {fallback} engines failed")

    def parse_json_response(self, raw: str) -> Any:
        """
        Attempt to parse a JSON response from an LLM, stripping markdown fences.
        Returns parsed object or raises ValueError.
        """
        cleaned = re.sub(r"```(?:json)?\s*", "", raw).strip().rstrip("```").strip()
        # Try direct parse
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass
        # Try to extract JSON object/array
        for pattern in (r'\{.*\}', r'\[.*\]'):
            m = re.search(pattern, cleaned, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group(0))
                except json.JSONDecodeError:
                    pass
        raise ValueError(f"Cannot parse JSON from LLM response: {raw[:300]}")

    def stats(self) -> Dict:
        with self._lock:
            return {
                "total_calls":  self._total_calls,
                "engines":      {k: v.to_dict() for k, v in self._stats.items()},
                "circuits":     {k: v.state_info() for k, v in self._circuits.items()},
                "recent_calls": list(self._call_history)[-10:],
            }

    def engine_availability(self) -> Dict[str, bool]:
        return {
            "groq_smart": bool(os.environ.get("GROQ_API_KEY")),
            "groq_fast":  bool(os.environ.get("GROQ_API_KEY")),
            "claude":     bool(os.environ.get("ANTHROPIC_API_KEY")),
            "openrouter": bool(os.environ.get("OPENROUTER_API_KEY")),
            "offline":    True,  # no API key needed — always available
        }

    # ---- Engine call implementations ------------------------------------

    def _call_engine(
        self,
        engine:      str,
        prompt:      str,
        system:      str,
        max_tokens:  int,
        temperature: float,
        json_mode:   bool,
        retries:     int,
    ) -> str:
        if engine in ("groq_smart", "groq_fast"):
            return _retry(
                lambda: self._groq(engine, prompt, system, max_tokens, temperature),
                retries=retries,
            )
        elif engine == "claude":
            return _retry(
                lambda: self._claude(prompt, system, max_tokens),
                retries=retries,
            )
        elif engine == "openrouter":
            return _retry(
                lambda: self._openrouter(prompt, system, max_tokens),
                retries=retries,
            )
        elif engine == "offline":
            # No retry wrapper — _offline() never raises, it always
            # returns something (Ollama reply or template stub).
            return self._offline(prompt, system, max_tokens, json_mode)
        raise RuntimeError(f"Unknown engine: {engine}")

    def _groq(self, engine: str, prompt: str, system: str,
               max_tokens: int, temperature: float) -> str:
        api_key = os.environ.get("GROQ_API_KEY", "")
        if not api_key:
            raise RuntimeError("GROQ_API_KEY not configured")
        model = GROQ_MODEL_FAST if engine == "groq_fast" else GROQ_MODEL_SMART
        from groq import Groq
        client   = Groq(api_key=api_key)
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        resp = client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return resp.choices[0].message.content.strip()

    def _claude(self, prompt: str, system: str, max_tokens: int) -> str:
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            raise RuntimeError("ANTHROPIC_API_KEY not configured")
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)
        kwargs = dict(
            model=CLAUDE_MODEL,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        if system:
            kwargs["system"] = system
        msg = client.messages.create(**kwargs)
        return msg.content[0].text.strip()

    def call_claude_raw_messages(self, messages: list,
                                 max_tokens: int = DEFAULT_MAX_TOKENS,
                                 system: str = "") -> str:
        """
        Direct Claude call with a pre-built messages list (for vision/multipart).
        Used by zeus_tartarus_upload for image vision analysis.
        """
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            raise RuntimeError("ANTHROPIC_API_KEY not configured")
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)
        kwargs = dict(
            model=CLAUDE_MODEL,
            max_tokens=max_tokens,
            messages=messages,
        )
        if system:
            kwargs["system"] = system
        msg = client.messages.create(**kwargs)
        return msg.content[0].text.strip()

    def _openrouter(self, prompt: str, system: str, max_tokens: int) -> str:
        api_key = os.environ.get("OPENROUTER_API_KEY", "")
        if not api_key:
            raise RuntimeError("OPENROUTER_API_KEY not configured")
        import urllib.request
        headers = {
            "Authorization":  f"Bearer {api_key}",
            "Content-Type":   "application/json",
            "HTTP-Referer":   "https://zeus.project2026",
            "X-Title":        "Zeus v4.0",
        }
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        body = json.dumps({
            "model":      OPENROUTER_MODEL,
            "messages":   messages,
            "max_tokens": max_tokens,
        }).encode()
        req = urllib.request.Request(
            "https://openrouter.ai/api/v1/chat/completions",
            data=body, headers=headers, method="POST"
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
        return data["choices"][0]["message"]["content"].strip()

    # ---- Helpers ---------------------------------------------------------

    def _offline(self, prompt: str, system: str, max_tokens: int,
                 json_mode: bool = False) -> str:
        """
        No API key required — always available. Two tiers:
          1. Local Ollama server (real inference, zero-config if the user
             has Ollama installed — https://ollama.com, free, runs fully
             offline on CPU or GPU, no account/key needed).
          2. Deterministic template stub — guarantees Zeus never hard-fails
             just because no cloud LLM is configured. Clearly labeled as
             offline-mode output so it's never mistaken for a real model
             response.
        Never raises.
        """
        ollama_reply = self._try_ollama(prompt, system, max_tokens)
        if ollama_reply is not None:
            return ollama_reply

        log.info("[LLM] offline: Ollama unavailable, using template stub")
        if json_mode:
            return json.dumps({
                "offline_mode": True,
                "note": ("No cloud LLM API key configured and no local Ollama "
                         "server reachable at " + OLLAMA_HOST + ". Install "
                         "Ollama (https://ollama.com) and run "
                         "`ollama pull " + OLLAMA_MODEL + "` for real local "
                         "inference, or set GROQ_API_KEY / ANTHROPIC_API_KEY "
                         "/ OPENROUTER_API_KEY in .env for cloud inference."),
                "prompt_echo": prompt[:200],
            })
        return (
            "[ZEUS OFFLINE MODE] No cloud LLM API key is configured and no "
            f"local Ollama server was reachable at {OLLAMA_HOST}. This is a "
            "template response, not model output.\n\n"
            f"To get real answers: install Ollama (https://ollama.com) and "
            f"run `ollama pull {OLLAMA_MODEL}`, or set GROQ_API_KEY / "
            f"ANTHROPIC_API_KEY / OPENROUTER_API_KEY in your .env file.\n\n"
            f"Your prompt was: {prompt[:300]}"
        )

    def _try_ollama(self, prompt: str, system: str, max_tokens: int) -> Optional[str]:
        """Best-effort call to a local Ollama server. Returns None (not an
        exception) on any failure, so _offline() can fall through cleanly."""
        try:
            import urllib.request
            body = json.dumps({
                "model": OLLAMA_MODEL,
                "prompt": (f"{system}\n\n{prompt}" if system else prompt),
                "stream": False,
                "options": {"num_predict": max_tokens},
            }).encode()
            req = urllib.request.Request(
                f"{OLLAMA_HOST}/api/generate",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT_S) as resp:
                data = json.loads(resp.read())
            text = data.get("response", "").strip()
            return text or None
        except Exception as e:
            log.debug(f"[LLM] Ollama not reachable at {OLLAMA_HOST}: {e}")
            return None

    def _resolve_engine_order(self, engine: str, prompt_len: int) -> List[str]:
        """Return ordered list of engines to try based on engine hint and
        availability. 'offline' is always appended last — it needs no API
        key and never raises, so the chain always has a guaranteed final
        rung instead of ending in 'All LLM engines exhausted'."""
        avail = self.engine_availability()
        if engine == "auto":
            order = []
            if prompt_len < 500 and avail["groq_fast"]:
                order.append("groq_fast")
            elif avail["groq_smart"]:
                order.append("groq_smart")
            if avail["claude"]:
                order.append("claude")
            if avail["openrouter"]:
                order.append("openrouter")
            if not order:
                order = ["groq_smart", "claude", "openrouter"]
            order.append("offline")
            return order
        if engine == "groq":
            return ["groq_smart", "claude", "openrouter", "offline"]
        if engine in ("groq_smart", "groq_fast", "claude", "openrouter"):
            fallbacks = [e for e in ["groq_smart", "claude", "openrouter"] if e != engine]
            return [engine] + fallbacks + ["offline"]
        if engine == "offline":
            return ["offline"]
        return ["groq_smart", "claude", "openrouter", "offline"]

    def _estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)

    def _log_call(self, engine: str, prompt: str, response: str,
                   ms: float, tokens: int, success: bool, error: str = "") -> None:
        with self._lock:
            self._total_calls += 1
            self._call_history.append({
                "engine":   engine,
                "prompt_len": len(prompt),
                "resp_len": len(response),
                "ms":       ms,
                "tokens":   tokens,
                "success":  success,
                "error":    error[:100] if error else "",
                "ts":       time.time(),
            })


# ============================================================================
# SINGLETON
# ============================================================================

_router_lock: threading.RLock = threading.RLock()
_router_instance: Optional[LLMRouter] = None


def get_router() -> LLMRouter:
    global _router_instance
    with _router_lock:
        if _router_instance is None:
            _router_instance = LLMRouter()
        return _router_instance


# ============================================================================
# MODULE-LEVEL CONVENIENCE FUNCTIONS
# ============================================================================

def call_groq(prompt: str, system: str = "", max_tokens: int = DEFAULT_MAX_TOKENS,
              fast: bool = False) -> str:
    """Importable by any Zeus module. Uses the singleton router."""
    return get_router().call_groq(prompt, system=system, max_tokens=max_tokens, fast=fast)


def call_claude(prompt: str, system: str = "",
                max_tokens: int = DEFAULT_MAX_TOKENS) -> str:
    """Importable by any Zeus module. Uses the singleton router."""
    return get_router().call_claude(prompt, system=system, max_tokens=max_tokens)


def call_llm(prompt: str, system: str = "",
             engine: str = "auto",
             max_tokens: int = DEFAULT_MAX_TOKENS) -> str:
    """Importable by any Zeus module. Auto-selects best engine."""
    return get_router().call(prompt, system=system, engine=engine, max_tokens=max_tokens)


def call_with_fallback(prompt: str, system: str = "",
                        max_tokens: int = DEFAULT_MAX_TOKENS,
                        primary: str = "groq",
                        fallback: str = "claude") -> Tuple[str, str]:
    """Returns (text, engine_used)."""
    return get_router().call_with_fallback(
        prompt, system=system, max_tokens=max_tokens, primary=primary, fallback=fallback
    )


def parse_json_llm(raw: str) -> Any:
    """Parse JSON from LLM response, stripping markdown fences."""
    return get_router().parse_json_response(raw)


# ============================================================================
# FLASK ROUTES
# ============================================================================

@llm_bp.route("/api/llm/health", methods=["GET"])
def llm_health():
    router = get_router()
    avail  = router.engine_availability()
    return jsonify({
        "status":   "ok",
        "module":   "zeus_llm_router",
        "engines":  avail,
        "circuits": {k: v.state_info()["state"] for k, v in router._circuits.items()},
        "total_calls": router._total_calls,
        "timestamp":   datetime.now(timezone.utc).isoformat(),
    })


@llm_bp.route("/api/llm/stats", methods=["GET"])
def llm_stats():
    try:
        return jsonify(get_router().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@llm_bp.route("/api/llm/call", methods=["POST"])
def llm_call_route():
    """
    POST { "prompt": str, "system": str, "engine": str, "max_tokens": int }
    Returns { "text": str, "engine": str }
    """
    data   = request.get_json(force=True, silent=True) or {}
    prompt = data.get("prompt", "").strip()
    if not prompt:
        return jsonify({"error": "prompt required"}), 400
    try:
        router = get_router()
        engine = data.get("engine", "auto")
        max_t  = int(data.get("max_tokens", DEFAULT_MAX_TOKENS))
        system = data.get("system", "")
        text, used_engine = router.call_with_fallback(
            prompt, system=system, max_tokens=max_t,
            primary=engine if engine != "auto" else "groq",
            fallback="claude",
        )
        return jsonify({"text": text, "engine": used_engine, "length": len(text)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@llm_bp.route("/api/llm/circuits", methods=["GET"])
def llm_circuits():
    """Return circuit breaker states for all engines."""
    try:
        router = get_router()
        return jsonify({
            k: v.state_info() for k, v in router._circuits.items()
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@llm_bp.route("/api/llm/reset_circuit", methods=["POST"])
def llm_reset_circuit():
    """
    Manually reset a circuit breaker.
    POST { "engine": "groq_smart" }
    """
    data   = request.get_json(force=True, silent=True) or {}
    engine = data.get("engine", "")
    router = get_router()
    if engine not in router._circuits:
        return jsonify({"error": f"Unknown engine: {engine}", "available": list(router._circuits)}), 400
    cb = router._circuits[engine]
    with cb._lock:
        cb._state         = CircuitState.CLOSED
        cb._failure_count = 0
        cb._success_count = 0
    log.info(f"[LLM] Circuit reset: {engine}")
    return jsonify({"status": "ok", "engine": engine, "state": "CLOSED"})


@llm_bp.route("/api/llm/status", methods=["GET"])
def llm_status_detail():
    """Full LLM status with circuit-breaker detail and live availability."""
    router = get_router()
    avail  = router.engine_availability()
    models = {
        "groq_smart":  GROQ_MODEL_SMART,
        "groq_fast":   GROQ_MODEL_FAST,
        "claude":      CLAUDE_MODEL,
        "openrouter":  OPENROUTER_MODEL,
    }
    return jsonify({
        "primary":    {"engine": "groq_smart",  "model": GROQ_MODEL_SMART,
                       "status": "configured" if avail["groq_smart"] else "missing"},
        "secondary":  {"engine": "groq_fast",   "model": GROQ_MODEL_FAST,
                       "status": "configured" if avail["groq_fast"] else "missing"},
        "deep":       {"engine": "claude",       "model": CLAUDE_MODEL,
                       "status": "configured" if avail["claude"] else "missing"},
        "last_resort":{"engine": "openrouter",   "model": OPENROUTER_MODEL,
                       "status": "configured" if avail["openrouter"] else "missing"},
        "models":     models,
        "total_calls": router._total_calls,
    })


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(llm_bp)
    log.info("[llm_router] ✓ Registered at /api/llm")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_llm_router",
            blueprint_var="llm_bp",
            url_prefix="/api/llm",
            version="2.0",
            description="Unified LLM router with circuit breaker, retry, and multi-engine fallback",
            capabilities=[
                {"id": "llm.call",          "endpoint": "/api/llm/call",          "method": "POST", "tags": ["llm", "ai"]},
                {"id": "llm.status",        "endpoint": "/api/llm/status",        "method": "GET",  "tags": ["llm"]},
                {"id": "llm.health",        "endpoint": "/api/llm/health",        "method": "GET",  "tags": ["health"]},
                {"id": "llm.stats",         "endpoint": "/api/llm/stats",         "method": "GET",  "tags": ["stats"]},
                {"id": "llm.circuits",      "endpoint": "/api/llm/circuits",      "method": "GET",  "tags": ["circuit_breaker"]},
                {"id": "llm.reset_circuit", "endpoint": "/api/llm/reset_circuit", "method": "POST", "tags": ["circuit_breaker"]},
            ],
            boot_order=10,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5011, debug=True, use_reloader=False)
