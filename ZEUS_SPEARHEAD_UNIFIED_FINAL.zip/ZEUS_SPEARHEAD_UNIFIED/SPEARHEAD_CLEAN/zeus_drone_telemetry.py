"""
zeus_drone_telemetry.py
=========================
Zeus Drone ISR — Telemetry Ingestion & Live State
The Zeus Project 2026 — additive extension (v2.2)

Ingests live flight telemetry (position, attitude, battery, link
quality, gimbal state) from an airframe and persists it to SQLite for
the dashboard and for mission post-analysis. Designed to accept
telemetry from any source that can hand it a JSON dict matching
TelemetrySample's fields — a MAVLink bridge, a DJI SDK bridge, or a
simulator can all feed this without this module needing to know which.

This module has no outbound command path to the airframe — it is
strictly a telemetry SINK plus a query/alert layer. Mission commands
flow the other direction, through zeus_drone_coverage.py's planner and
whatever airframe-specific command bridge an operator wires in
separately; that boundary is deliberate so this module cannot become
a control surface by accretion.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

log = logging.getLogger("zeus.drone_telemetry")

DRONE_TELEMETRY_RING_TYPES = {
    "drone_telemetry_ingest": 2,   # high-frequency, low-risk — audited but not gated per-sample
    "drone_alert_ack":        3,
}


@dataclass
class TelemetrySample:
    mission_id: str
    timestamp_utc: str
    lat: float
    lon: float
    alt_m: float
    heading_deg: float = 0.0
    speed_mps: float = 0.0
    battery_pct: float = 100.0
    link_quality_pct: float = 100.0
    gimbal_pitch_deg: float = -90.0
    gps_fix_type: str = "3D_FIX"          # NO_FIX | 2D_FIX | 3D_FIX | RTK
    satellites: int = 0
    flight_mode: str = "AUTO"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TelemetryStore:
    """SQLite-backed telemetry log + simple threshold alerting, reusing
    the same lightweight 'open connection per call' pattern already
    used throughout SPEARHEAD's other SQLite-backed modules."""

    def __init__(self, db_path: str = "zeus_drone_isr.db"):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_db()
        self._latest: Dict[str, TelemetrySample] = {}   # mission_id -> last sample, in-memory

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS telemetry_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mission_id TEXT NOT NULL,
                    timestamp_utc TEXT NOT NULL,
                    epoch REAL NOT NULL,
                    lat REAL, lon REAL, alt_m REAL,
                    heading_deg REAL, speed_mps REAL,
                    battery_pct REAL, link_quality_pct REAL,
                    gimbal_pitch_deg REAL, gps_fix_type TEXT,
                    satellites INTEGER, flight_mode TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS drone_alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mission_id TEXT NOT NULL,
                    timestamp_utc TEXT NOT NULL,
                    epoch REAL NOT NULL,
                    severity TEXT NOT NULL,
                    code TEXT NOT NULL,
                    detail TEXT,
                    acknowledged INTEGER DEFAULT 0
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_telemetry_mission ON telemetry_log(mission_id, epoch)")

    def ingest(self, sample: TelemetrySample) -> List[Dict[str, Any]]:
        """Persists one telemetry sample, returns any alerts it triggered."""
        epoch = time.time()
        with self._lock:
            self._latest[sample.mission_id] = sample
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO telemetry_log
                (mission_id, timestamp_utc, epoch, lat, lon, alt_m, heading_deg, speed_mps,
                 battery_pct, link_quality_pct, gimbal_pitch_deg, gps_fix_type, satellites, flight_mode)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (sample.mission_id, sample.timestamp_utc, epoch, sample.lat, sample.lon, sample.alt_m,
                  sample.heading_deg, sample.speed_mps, sample.battery_pct, sample.link_quality_pct,
                  sample.gimbal_pitch_deg, sample.gps_fix_type, sample.satellites, sample.flight_mode))

        alerts = self._check_thresholds(sample, epoch)

        # ── Hive + Tartarus wiring (v2.4, additive) ──────────────────────────
        # Publish telemetry and any triggered alerts into the Hive Memory bus
        # and Tartarus learning pool so drone observations flow into the
        # system's learning loop alongside AEGIS and sovereignty events.
        try:
            from zeus_drone_hive_wire import get_wire
            wire = get_wire()
            wire.publish_telemetry_sample(sample.to_dict())
            for a in alerts:
                wire.publish_alert(sample.mission_id, a)
        except Exception as _hive_err:
            log.debug("[telemetry_store] hive wire: %s", _hive_err)
        # ─────────────────────────────────────────────────────────────────────

        return alerts

    def _check_thresholds(self, s: TelemetrySample, epoch: float) -> List[Dict[str, Any]]:
        triggered = []

        def alert(severity: str, code: str, detail: str):
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT INTO drone_alerts (mission_id, timestamp_utc, epoch, severity, code, detail)
                    VALUES (?,?,?,?,?,?)
                """, (s.mission_id, s.timestamp_utc, epoch, severity, code, detail))
            triggered.append({"severity": severity, "code": code, "detail": detail})

        if s.battery_pct <= 15:
            alert("CRITICAL", "BATTERY_CRITICAL", f"{s.battery_pct}% remaining — RTL recommended")
        elif s.battery_pct <= 30:
            alert("WARN", "BATTERY_LOW", f"{s.battery_pct}% remaining")

        if s.link_quality_pct <= 20:
            alert("CRITICAL", "LINK_DEGRADED", f"link quality {s.link_quality_pct}%")

        if s.gps_fix_type in ("NO_FIX", "2D_FIX"):
            alert("WARN", "GPS_FIX_DEGRADED", f"fix type {s.gps_fix_type}, sats={s.satellites}")

        return triggered

    def latest(self, mission_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            s = self._latest.get(mission_id)
        return s.to_dict() if s else None

    def track(self, mission_id: str, limit: int = 500) -> List[Dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT timestamp_utc, lat, lon, alt_m, heading_deg, speed_mps,
                       battery_pct, link_quality_pct, flight_mode
                FROM telemetry_log WHERE mission_id = ?
                ORDER BY epoch ASC LIMIT ?
            """, (mission_id, limit))
            cols = [d[0] for d in cursor.description]
            return [dict(zip(cols, row)) for row in cursor.fetchall()]

    def active_alerts(self, mission_id: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            if mission_id:
                cursor = conn.execute("""
                    SELECT id, mission_id, timestamp_utc, severity, code, detail, acknowledged
                    FROM drone_alerts WHERE mission_id = ? AND acknowledged = 0
                    ORDER BY epoch DESC LIMIT ?
                """, (mission_id, limit))
            else:
                cursor = conn.execute("""
                    SELECT id, mission_id, timestamp_utc, severity, code, detail, acknowledged
                    FROM drone_alerts WHERE acknowledged = 0
                    ORDER BY epoch DESC LIMIT ?
                """, (limit,))
            cols = [d[0] for d in cursor.description]
            return [dict(zip(cols, row)) for row in cursor.fetchall()]

    def acknowledge_alert(self, alert_id: int) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute("UPDATE drone_alerts SET acknowledged = 1 WHERE id = ?", (alert_id,))
            return cur.rowcount > 0

    def active_missions(self) -> List[str]:
        with self._lock:
            return list(self._latest.keys())
