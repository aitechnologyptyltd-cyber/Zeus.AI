"""
zeus_drone_coverage.py
========================
Zeus Drone ISR — Coverage Pattern & Flight Planning Engine
The Zeus Project 2026 — additive extension (v2.2)

Scope, explicitly: This module computes flight paths and area-coverage
patterns for SURVEILLANCE / GEO-INTELLIGENCE / MAPPING drone missions
only. It has no concept of a "target" in the weapons sense — every
"target" in this file is a geographic polygon, search box, or waypoint
to fly OVER and observe, never a coordinate to direct a payload at.
No fire-control, munitions, or weapons-release logic exists here or
anywhere in this extension, and none will be added to it.

What this provides:
  - Geofence validation (a mission may not be planned outside an
    approved operating boundary)
  - Coverage pattern generators: lawnmower/grid (area search),
    expanding-spiral (point search), perimeter/orbit (asset watch)
  - Waypoint mission builder with altitude, speed, and camera-gimbal
    pointing hints per waypoint
  - Battery/range feasibility check (does this mission fit the
    airframe's flight envelope)

Units: all lat/lon in decimal degrees, distances in metres, altitude
in metres AGL (above ground level) unless noted.
"""
from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

EARTH_RADIUS_M = 6371000.0

# Ring classification for drone ISR actions. Mission planning itself
# is read-only computation (Ring 3); actually commanding the airframe
# to fly is a Ring 5 autonomous-execution action (non-destructive,
# crosswire-scanned, consistent with SPEARHEAD's existing Ring 5
# definition for "Full Auto" operations); leaving an approved geofence
# is escalated to Ring 6 (advisory, human veto + Council) because it
# is a safety/airspace-legality boundary, not a routine flight event.
DRONE_RING_TYPES = {
    "drone_mission_plan":       3,
    "drone_coverage_compute":   3,
    "drone_mission_execute":    5,
    "drone_geofence_breach":    6,
}


# ── Geometry helpers ──────────────────────────────────────────────────────────

def _meters_to_deg_lat(m: float) -> float:
    return m / 111320.0

def _meters_to_deg_lon(m: float, at_lat: float) -> float:
    return m / (111320.0 * max(math.cos(math.radians(at_lat)), 1e-6))

def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2
         + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2))
         * math.sin(dlon / 2) ** 2)
    return EARTH_RADIUS_M * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def point_in_polygon(lat: float, lon: float, polygon: List[Tuple[float, float]]) -> bool:
    """Standard ray-casting point-in-polygon test. polygon = [(lat,lon), ...]."""
    n = len(polygon)
    inside = False
    j = n - 1
    for i in range(n):
        lat_i, lon_i = polygon[i]
        lat_j, lon_j = polygon[j]
        if ((lon_i > lon) != (lon_j > lon)) and \
           (lat < (lat_j - lat_i) * (lon - lon_i) / ((lon_j - lon_i) or 1e-12) + lat_i):
            inside = not inside
        j = i
    return inside

def polygon_bounds(polygon: List[Tuple[float, float]]) -> Tuple[float, float, float, float]:
    lats = [p[0] for p in polygon]
    lons = [p[1] for p in polygon]
    return min(lats), max(lats), min(lons), max(lons)


# ── Geofence ───────────────────────────────────────────────────────────────────

@dataclass
class Geofence:
    """An approved operating boundary. A mission's every waypoint must
    fall inside this polygon, or planning fails closed."""
    fence_id: str
    polygon: List[Tuple[float, float]]     # [(lat, lon), ...], closed or open ring
    max_altitude_m: float = 120.0          # default matches common civil UAV ceiling
    min_altitude_m: float = 10.0
    label: str = ""

    def validate_point(self, lat: float, lon: float, alt_m: float) -> Tuple[bool, str]:
        if not point_in_polygon(lat, lon, self.polygon):
            return False, "OUTSIDE_GEOFENCE_BOUNDARY"
        if alt_m > self.max_altitude_m:
            return False, f"ALTITUDE_EXCEEDS_CEILING_{self.max_altitude_m}m"
        if alt_m < self.min_altitude_m:
            return False, f"ALTITUDE_BELOW_FLOOR_{self.min_altitude_m}m"
        return True, "OK"


# ── Waypoint / mission model ────────────────────────────────────────────────────

@dataclass
class Waypoint:
    seq: int
    lat: float
    lon: float
    alt_m: float
    speed_mps: float = 5.0
    gimbal_pitch_deg: float = -90.0   # -90 = camera pointing straight down (nadir/mapping)
    action: str = "FLY_THROUGH"       # FLY_THROUGH | HOVER_CAPTURE | ORBIT_POINT
    hold_seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class FlightMission:
    mission_id: str
    pattern_type: str
    geofence_id: str
    waypoints: List[Waypoint] = field(default_factory=list)
    estimated_distance_m: float = 0.0
    estimated_duration_s: float = 0.0
    created_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mission_id": self.mission_id,
            "pattern_type": self.pattern_type,
            "geofence_id": self.geofence_id,
            "waypoint_count": len(self.waypoints),
            "waypoints": [w.to_dict() for w in self.waypoints],
            "estimated_distance_m": round(self.estimated_distance_m, 1),
            "estimated_duration_s": round(self.estimated_duration_s, 1),
            "created_utc": self.created_utc,
        }


@dataclass
class AirframeProfile:
    """Flight envelope used for feasibility checking. No payload/weapon
    fields exist on this dataclass by design."""
    name: str = "generic_isr_quad"
    max_speed_mps: float = 12.0
    cruise_speed_mps: float = 7.0
    max_flight_time_s: float = 1500.0     # ~25 min typical small ISR quad
    battery_reserve_pct: float = 20.0     # held back as safety margin


# ── Coverage pattern generators ──────────────────────────────────────────────────

class CoveragePlanner:
    """
    Generates ISR/mapping flight patterns. Every method validates every
    generated waypoint against the supplied Geofence before returning —
    a mission that would breach the fence is never produced; the
    method returns a failure result instead (fail-closed, consistent
    with AEGIS-FIELD's design philosophy elsewhere in SPEARHEAD).
    """

    def __init__(self, geofence: Geofence, airframe: Optional[AirframeProfile] = None):
        self.geofence = geofence
        self.airframe = airframe or AirframeProfile()

    # -- Lawnmower / grid search: full-area mapping coverage ------------------
    def lawnmower(self, polygon: List[Tuple[float, float]], alt_m: float,
                  swath_width_m: float, speed_mps: float = 7.0,
                  heading_deg: float = 0.0) -> Dict[str, Any]:
        """
        Boustrophedon ("lawnmower") grid pattern over a polygon area.
        swath_width_m should be set from the camera's ground footprint
        at the given altitude (e.g. sensor FOV math done by the caller)
        so adjacent passes overlap correctly for photogrammetry/mapping.
        """
        min_lat, max_lat, min_lon, max_lon = polygon_bounds(polygon)
        lat_step = _meters_to_deg_lat(swath_width_m)
        lon_span_m = haversine_m(min_lat, min_lon, min_lat, max_lon)

        # Inset the sweep bounds by a small margin so that when the
        # coverage polygon's edge coincides exactly with the geofence
        # boundary (the common case — flying right up to an approved
        # perimeter), ray-casting's strict on-edge ambiguity doesn't
        # reject otherwise-valid boundary waypoints. Margin is tiny
        # relative to swath_width_m and has no operational effect on
        # coverage quality.
        edge_margin_m = max(0.5, swath_width_m * 0.02)
        lat_margin = _meters_to_deg_lat(edge_margin_m)
        lon_margin = _meters_to_deg_lon(edge_margin_m, (min_lat + max_lat) / 2)
        min_lat += lat_margin
        max_lat -= lat_margin
        min_lon += lon_margin
        max_lon -= lon_margin
        if min_lat >= max_lat or min_lon >= max_lon:
            return {"success": False, "reason": "AREA_TOO_SMALL_FOR_SWATH_AND_EDGE_MARGIN"}

        waypoints: List[Waypoint] = []
        seq = 0
        lat = min_lat
        row = 0
        while lat <= max_lat:
            left = (lat, min_lon)
            right = (lat, max_lon)
            pair = [left, right] if row % 2 == 0 else [right, left]
            for plat, plon in pair:
                ok, reason = self.geofence.validate_point(plat, plon, alt_m)
                if not ok:
                    return {"success": False, "reason": reason,
                            "failed_at": {"lat": plat, "lon": plon, "alt_m": alt_m}}
                waypoints.append(Waypoint(
                    seq=seq, lat=plat, lon=plon, alt_m=alt_m,
                    speed_mps=speed_mps, gimbal_pitch_deg=-90.0,
                    action="FLY_THROUGH",
                ))
                seq += 1
            lat += lat_step
            row += 1

        return self._finalize(waypoints, "LAWNMOWER_GRID", speed_mps)

    # -- Expanding spiral: efficient for point/area search of unknown extent --
    def expanding_spiral(self, center_lat: float, center_lon: float, alt_m: float,
                          max_radius_m: float, ring_spacing_m: float = 30.0,
                          points_per_ring: int = 12,
                          speed_mps: float = 5.0) -> Dict[str, Any]:
        waypoints: List[Waypoint] = []
        seq = 0
        radius = ring_spacing_m
        while radius <= max_radius_m:
            for i in range(points_per_ring):
                theta = 2 * math.pi * i / points_per_ring
                d_lat = _meters_to_deg_lat(radius * math.sin(theta))
                d_lon = _meters_to_deg_lon(radius * math.cos(theta), center_lat)
                plat, plon = center_lat + d_lat, center_lon + d_lon
                ok, reason = self.geofence.validate_point(plat, plon, alt_m)
                if not ok:
                    return {"success": False, "reason": reason,
                            "failed_at": {"lat": plat, "lon": plon, "alt_m": alt_m}}
                waypoints.append(Waypoint(
                    seq=seq, lat=plat, lon=plon, alt_m=alt_m,
                    speed_mps=speed_mps, gimbal_pitch_deg=-45.0,
                    action="FLY_THROUGH",
                ))
                seq += 1
            radius += ring_spacing_m

        return self._finalize(waypoints, "EXPANDING_SPIRAL", speed_mps)

    # -- Perimeter orbit: sustained watch on a fixed point (asset protection,
    #    border/perimeter monitoring) --------------------------------------------
    def perimeter_orbit(self, center_lat: float, center_lon: float, alt_m: float,
                         orbit_radius_m: float, points: int = 16,
                         speed_mps: float = 4.0, loiter_seconds_per_point: float = 0.0
                         ) -> Dict[str, Any]:
        waypoints: List[Waypoint] = []
        for i in range(points):
            theta = 2 * math.pi * i / points
            d_lat = _meters_to_deg_lat(orbit_radius_m * math.sin(theta))
            d_lon = _meters_to_deg_lon(orbit_radius_m * math.cos(theta), center_lat)
            plat, plon = center_lat + d_lat, center_lon + d_lon
            ok, reason = self.geofence.validate_point(plat, plon, alt_m)
            if not ok:
                return {"success": False, "reason": reason,
                        "failed_at": {"lat": plat, "lon": plon, "alt_m": alt_m}}
            # gimbal points inward at the orbit centre — classic "orbit/POI" ISR shot
            bearing_to_center = (math.degrees(math.atan2(
                math.sin(math.radians(center_lon - plon)) * math.cos(math.radians(center_lat)),
                math.cos(math.radians(plat)) * math.sin(math.radians(center_lat))
                - math.sin(math.radians(plat)) * math.cos(math.radians(center_lat))
                * math.cos(math.radians(center_lon - plon))
            )) + 360) % 360
            waypoints.append(Waypoint(
                seq=i, lat=plat, lon=plon, alt_m=alt_m, speed_mps=speed_mps,
                gimbal_pitch_deg=-30.0, action="ORBIT_POINT",
                hold_seconds=loiter_seconds_per_point,
            ))
        return self._finalize(waypoints, "PERIMETER_ORBIT", speed_mps)

    # -- shared finalize / feasibility check ------------------------------------
    def _finalize(self, waypoints: List[Waypoint], pattern_type: str,
                  speed_mps: float) -> Dict[str, Any]:
        if not waypoints:
            return {"success": False, "reason": "EMPTY_MISSION_NO_WAYPOINTS_GENERATED"}

        dist = 0.0
        for a, b in zip(waypoints, waypoints[1:]):
            dist += haversine_m(a.lat, a.lon, b.lat, b.lon)
        duration_s = dist / max(speed_mps, 0.1)
        duration_s += sum(w.hold_seconds for w in waypoints)

        feasible, feasibility_reason = self._check_feasibility(duration_s)

        mission = FlightMission(
            mission_id="mission_" + uuid.uuid4().hex[:12],
            pattern_type=pattern_type,
            geofence_id=self.geofence.fence_id,
            waypoints=waypoints,
            estimated_distance_m=dist,
            estimated_duration_s=duration_s,
        )

        result = mission.to_dict()
        result["success"] = True
        result["feasible"] = feasible
        result["feasibility_note"] = feasibility_reason
        result["airframe"] = self.airframe.name
        return result

    def _check_feasibility(self, duration_s: float) -> Tuple[bool, str]:
        usable_s = self.airframe.max_flight_time_s * (1 - self.airframe.battery_reserve_pct / 100.0)
        if duration_s <= usable_s:
            margin_pct = round(100 * (usable_s - duration_s) / usable_s, 1)
            return True, f"Within flight envelope — {margin_pct}% time margin after reserve"
        return False, (f"EXCEEDS_FLIGHT_ENVELOPE: mission needs {duration_s:.0f}s, "
                        f"airframe usable time is {usable_s:.0f}s after "
                        f"{self.airframe.battery_reserve_pct}% reserve — split into "
                        f"multiple sorties or reduce coverage area")
