# The Zeus Project 2026 — Francois Nel SA ID 8708275089084
# zeus_perplexity_bridge.py — Perplexity Sonar API Bridge v1.0
# =============================================================
#
# Follows the same pattern as zeus_grok_bridge.py and zeus_deepseek_bridge.py.
#
# Perplexity uses an OpenAI-compatible API endpoint.
# API key: PERPLEXITY_API_KEY in .env
# Default model: sonar (online, citation-backed)
# Alt model: sonar-pro (extended reasoning + citations)
#
# Council role: Citation-based retrieval, real-time fact-checking,
#               web-grounded answers. The council's "fact-checker."
#
# APP.PY: No separate route registration needed.
#         Imported directly by zeus_council_router.py.
# =============================================================

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass
from typing import Dict, List, Optional

log = logging.getLogger("zeus.perplexity")

PERPLEXITY_API_KEY  = os.environ.get("PERPLEXITY_API_KEY", "")
PERPLEXITY_BASE_URL = "https://api.perplexity.ai"
DEFAULT_MODEL       = os.environ.get("PERPLEXITY_MODEL", "sonar")
PRO_MODEL           = "sonar-pro"
DEFAULT_MAX_TOKENS  = 2000
DEFAULT_TIMEOUT     = 55


# ─── CIRCUIT BREAKER ─────────────────────────────────────────────────────────

class PerplexityCircuitBreaker:
    def __init__(self, failure_threshold: int = 4, cooldown_s: float = 90.0):
        self._threshold  = failure_threshold
        self._cooldown   = cooldown_s
        self._failures   = 0
        self._tripped_at: Optional[float] = None
        self._lock       = threading.Lock()

    def allow(self) -> bool:
        with self._lock:
            if self._tripped_at is None:
                return True
            if time.time() - self._tripped_at >= self._cooldown:
                self._failures   = 0
                self._tripped_at = None
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            self._failures   = 0
            self._tripped_at = None

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._tripped_at = time.time()
                log.warning("[perplexity] Circuit breaker OPEN (%d failures)", self._failures)

    def state(self) -> str:
        with self._lock:
            if self._tripped_at is None:
                return "CLOSED"
            if time.time() - self._tripped_at >= self._cooldown:
                return "HALF_OPEN"
            return "OPEN"


# ─── STATS ───────────────────────────────────────────────────────────────────

@dataclass
class PerplexityStats:
    model:         str
    total_calls:   int   = 0
    success_calls: int   = 0
    error_calls:   int   = 0
    total_tokens:  int   = 0
    total_ms:      float = 0.0
    last_error:    str   = ""
    citations_seen: int  = 0

    def record(self, tokens: int, ms: float, success: bool,
               citations: int = 0, error: str = "") -> None:
        self.total_calls    += 1
        self.total_ms       += ms
        self.total_tokens   += tokens
        self.citations_seen += citations
        if success:
            self.success_calls += 1
        else:
            self.error_calls += 1
            self.last_error   = error[:200]

    def success_rate(self) -> float:
        return self.success_calls / max(self.total_calls, 1)

    def avg_ms(self) -> float:
        return self.total_ms / max(self.total_calls, 1)

    def to_dict(self) -> Dict:
        return {
            "model":          self.model,
            "total_calls":    self.total_calls,
            "success_rate":   round(self.success_rate(), 3),
            "avg_ms":         round(self.avg_ms(), 1),
            "total_tokens":   self.total_tokens,
            "citations_seen": self.citations_seen,
            "last_error":     self.last_error,
        }


# ─── ENGINE ──────────────────────────────────────────────────────────────────

class PerplexityEngine:
    """
    Perplexity Sonar engine.
    Uses openai-compatible SDK — same openai package as DeepSeek bridge.
    Extracts citations from the response and appends them.
    """

    def __init__(self):
        self._cb_sonar  = PerplexityCircuitBreaker()
        self._cb_pro    = PerplexityCircuitBreaker()
        self._stats     = PerplexityStats(model=DEFAULT_MODEL)
        self._stats_pro = PerplexityStats(model=PRO_MODEL)
        self._client    = None
        self._lock      = threading.Lock()

    def _get_client(self):
        if self._client is not None:
            return self._client
        with self._lock:
            if self._client is not None:
                return self._client
            try:
                from openai import OpenAI
                api_key = PERPLEXITY_API_KEY
                if not api_key:
                    raise RuntimeError("PERPLEXITY_API_KEY not set in environment")
                self._client = OpenAI(
                    api_key=api_key,
                    base_url=PERPLEXITY_BASE_URL,
                )
                log.info("[perplexity] Client initialised (base_url=%s)", PERPLEXITY_BASE_URL)
            except ImportError:
                raise RuntimeError("openai package required: pip install openai --break-system-packages")
        return self._client

    def call(self, prompt: str, context: str = "",
             use_pro: bool = False,
             max_tokens: int = DEFAULT_MAX_TOKENS,
             timeout: int = DEFAULT_TIMEOUT) -> str:
        """
        Single call to Perplexity Sonar.
        use_pro=True → sonar-pro (more citations, better coverage)
        """
        target_model = PRO_MODEL if use_pro else DEFAULT_MODEL
        cb    = self._cb_pro if use_pro else self._cb_sonar
        stats = self._stats_pro if use_pro else self._stats

        if not cb.allow():
            raise RuntimeError(f"[perplexity] Circuit breaker OPEN for model {target_model}")

        system = (
            f"Context:\n{context}\n\n"
            "You are the Fact-Checker of the Zeus AI Council. "
            "Provide web-grounded, citation-backed answers. "
            "Always include your sources and flag any uncertainty."
        ) if context else (
            "You are the Fact-Checker of the Zeus AI Council. "
            "Provide web-grounded, citation-backed answers. "
            "Always include your sources and flag any uncertainty."
        )

        messages = [
            {"role": "system", "content": system},
            {"role": "user",   "content": prompt},
        ]

        t0 = time.time()
        try:
            client   = self._get_client()
            response = client.chat.completions.create(
                model=target_model,
                messages=messages,
                max_tokens=max_tokens,
                timeout=timeout,
            )
            elapsed = (time.time() - t0) * 1000
            text    = response.choices[0].message.content or ""
            tokens  = getattr(response.usage, "total_tokens", 0)

            # Extract citations if present in response object
            citations: List[str] = []
            try:
                citations = getattr(response, "citations", []) or []
            except Exception:
                pass

            # Append citations to response text
            if citations:
                citation_block = "\n\nSources:\n" + "\n".join(
                    f"[{i+1}] {c}" for i, c in enumerate(citations)
                )
                text += citation_block

            stats.record(tokens, elapsed, True, len(citations))
            cb.record_success()
            log.info("[perplexity] %s success %.0fms %d tokens %d citations",
                     target_model, elapsed, tokens, len(citations))
            return text

        except Exception as e:
            elapsed = (time.time() - t0) * 1000
            stats.record(0, elapsed, False, error=str(e))
            cb.record_failure()
            log.error("[perplexity] %s error: %s", target_model, e)
            raise

    def call_with_context(self, prompt: str, context: str = "",
                          use_pro: bool = False) -> str:
        return self.call(prompt, context=context, use_pro=use_pro)

    def is_available(self) -> bool:
        return bool(PERPLEXITY_API_KEY) and self._cb_sonar.allow()

    def stats(self) -> Dict:
        return {
            "available":     self.is_available(),
            "api_key_set":   bool(PERPLEXITY_API_KEY),
            "circuit_sonar": self._cb_sonar.state(),
            "circuit_pro":   self._cb_pro.state(),
            "stats_sonar":   self._stats.to_dict(),
            "stats_pro":     self._stats_pro.to_dict(),
        }


# ─── SINGLETON ───────────────────────────────────────────────────────────────

_INSTANCE: Optional[PerplexityEngine] = None
_LOCK = threading.Lock()


def get_perplexity_engine() -> PerplexityEngine:
    global _INSTANCE
    if _INSTANCE is None:
        with _LOCK:
            if _INSTANCE is None:
                _INSTANCE = PerplexityEngine()
    return _INSTANCE


def call_perplexity(prompt: str, context: str = "", use_pro: bool = False) -> str:
    """Module-level convenience function."""
    return get_perplexity_engine().call_with_context(prompt, context, use_pro)
