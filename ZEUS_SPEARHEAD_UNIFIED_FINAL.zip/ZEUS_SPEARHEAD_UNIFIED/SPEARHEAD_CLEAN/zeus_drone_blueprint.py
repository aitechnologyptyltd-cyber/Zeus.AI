"""
zeus_drone_blueprint.py
=========================
Zeus Drone ISR — Flask Blueprint
The Zeus Project 2026 — additive extension (v2.2)

Registers Drone ISR routes into the Zeus v8 Flask app.
Routes prefix: /drone/...
Dashboard:     /drone/dashboard

SCOPE: surveillance / geo-intelligence / mapping mission planning,
telemetry monitoring, and post-mission imagery analysis. There is no
command-and-control path to weapons, payload release, or any
fire-control function anywhere in this blueprint or the modules it
wires together (zeus_drone_coverage.py, zeus_drone_telemetry.py,
zeus_drone_vision.py). Every mutating action still passes through
zeus_sovereignty_engine.sovereign_execute() exactly like every other
Zeus subsystem — no bypass of the Ring/Council/audit model is
introduced by this blueprint.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from flask import Blueprint, request, jsonify, render_template_string

log = logging.getLogger("zeus.drone")

drone_bp = Blueprint("drone", __name__, url_prefix="/drone")

_telemetry_store = None
_init_lock = threading.Lock()
_command_bridge = None
_fences: dict = {}   # fence_id -> Geofence (in-process registry, see api_create_geofence)


def _get_store():
    global _telemetry_store
    if _telemetry_store is not None:
        return _telemetry_store
    with _init_lock:
        if _telemetry_store is not None:
            return _telemetry_store
        from zeus_drone_telemetry import TelemetryStore
        drone_dir = Path(__file__).parent
        _telemetry_store = TelemetryStore(db_path=str(drone_dir / "zeus_drone_isr.db"))
        log.info("Drone ISR telemetry store initialized.")
        return _telemetry_store


def _get_command_bridge():
    """
    Returns the process-wide CommandBridge, wired to a SimulatorTransport
    by default. To use a real airframe, set this blueprint's transport
    before first use — e.g. in app startup code:
        import zeus_drone_blueprint as db
        from zeus_drone_command_bridge import CommandBridge
        db._command_bridge = CommandBridge(your_real_transport_instance)
    No route in this blueprint changes if the transport changes — only
    the transport object's class differs.
    """
    global _command_bridge
    if _command_bridge is not None:
        return _command_bridge
    with _init_lock:
        if _command_bridge is not None:
            return _command_bridge
        from zeus_drone_command_bridge import CommandBridge, SimulatorTransport
        _command_bridge = CommandBridge(SimulatorTransport())
        log.info("Drone ISR command bridge initialized with SimulatorTransport "
                 "(no real airframe will be commanded). See _get_command_bridge() "
                 "docstring to attach a real MAVLink/DJI transport.")
        from zeus_drone_geofence_monitor import get_monitor
        get_monitor().set_command_bridge(_command_bridge)
        return _command_bridge


DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Zeus Drone ISR</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{--bg:#0a0e27;--bg2:#1a1f3a;--accent:#00ffcc;--accent2:#0088ff;
  --warn:#ff9900;--crit:#ff3366;--ok:#00cc66;--txt:#c0c8d8;--dim:#4a5570;}
body{font-family:"Courier New",monospace;background:linear-gradient(135deg,var(--bg),var(--bg2));
  color:var(--txt);height:100vh;display:flex;flex-direction:column;overflow:hidden;}
.hdr{background:rgba(0,0,0,.8);border-bottom:2px solid var(--accent);
  padding:12px 20px;display:flex;align-items:center;flex-shrink:0;}
.hdr h1{font-size:1.2em;color:var(--accent);text-shadow:0 0 8px var(--accent);}
.hdr .sub{font-size:.68em;color:var(--dim);margin-left:16px;}
.hdr .clk{margin-left:auto;font-size:.7em;color:var(--dim);}
.scope-bar{background:rgba(0,255,204,.04);border-bottom:1px solid rgba(0,255,204,.12);
  padding:5px 20px;font-size:.7em;color:#7af5de;flex-shrink:0;}
.kpi{display:flex;border-bottom:1px solid var(--dim);flex-shrink:0;}
.ki{flex:1;padding:8px 6px;text-align:center;border-right:1px solid var(--dim);}
.ki:last-child{border-right:none;}
.kv{font-size:1.5em;font-weight:bold;color:var(--crit);}
.kv.ok{color:var(--ok);}
.kl{font-size:.6em;color:var(--dim);margin-top:2px;}
.breach{display:none;background:rgba(255,51,102,.2);border-bottom:1px solid var(--crit);
  color:var(--crit);padding:6px 20px;font-size:.76em;text-align:center;flex-shrink:0;}
.main{display:flex;flex:1;min-height:0;}
#map{flex:1;}
.side{width:340px;display:flex;flex-direction:column;background:rgba(0,0,0,.5);
  border-left:1px solid var(--dim);overflow-y:auto;flex-shrink:0;}
.ph{padding:8px 12px;font-size:.75em;font-weight:bold;color:var(--accent);
  letter-spacing:.07em;border-bottom:1px solid var(--dim);background:rgba(0,0,0,.3);
  flex-shrink:0;position:sticky;top:0;z-index:1;}
.ms-list{padding:6px;}
.ms-item{padding:7px 10px;border:1px solid var(--dim);border-radius:4px;cursor:pointer;
  margin-bottom:5px;font-size:.75em;transition:.12s;}
.ms-item:hover,.ms-item.active{border-color:var(--accent);color:var(--accent);}
.ms-none{padding:10px;font-size:.74em;color:var(--dim);}
.tgrid{padding:8px 12px;display:grid;grid-template-columns:1fr 1fr;gap:5px 10px;}
.tf .tl{font-size:.66em;color:var(--dim);}
.tf .tv{font-size:.8em;color:var(--accent2);font-weight:bold;}
.bat-wrap{padding:0 12px 8px;}
.bat-bar{height:6px;background:var(--dim);border-radius:3px;overflow:hidden;}
.bat-fill{height:100%;background:var(--ok);transition:width .5s,background .5s;}
.mc{padding:8px 10px;display:flex;flex-wrap:wrap;gap:6px;}
.mc button{font-family:"Courier New",monospace;font-size:.72em;padding:5px 10px;
  border-radius:4px;cursor:pointer;border:1px solid var(--dim);
  background:rgba(0,0,0,.5);color:var(--txt);transition:.12s;}
.mc button:hover{border-color:var(--accent);color:var(--accent);}
.mc .safe{border-color:var(--ok);color:var(--ok);}
.mc .safe:hover{background:rgba(0,204,102,.1);}
.alert-list{padding:5px 8px;}
.arow{padding:6px 9px;border-radius:4px;margin-bottom:4px;font-size:.72em;
  display:flex;justify-content:space-between;align-items:center;gap:6px;}
.arow.CRITICAL{background:rgba(255,51,102,.15);border-left:3px solid var(--crit);}
.arow.WARN{background:rgba(255,153,0,.1);border-left:3px solid var(--warn);}
.ack{cursor:pointer;color:var(--dim);padding:2px 5px;border:1px solid var(--dim);
  border-radius:2px;font-size:.85em;}
.ack:hover{color:var(--accent);border-color:var(--accent);}
.ano{padding:10px;font-size:.73em;color:var(--dim);}
#toast{display:none;position:fixed;bottom:18px;left:50%;transform:translateX(-50%);
  background:rgba(10,14,39,.95);border:1px solid var(--accent);color:#fff;
  padding:8px 20px;border-radius:5px;font-size:.78em;z-index:9999;}
</style>
</head>
<body>
<div class="hdr">
  <h1>⬡ ZEUS DRONE ISR</h1>
  <span class="sub">Surveillance / Mapping / Geo-Intelligence &nbsp;|&nbsp; The Zeus Project 2026</span>
  <span class="clk" id="clk">--:--:-- UTC</span>
</div>
<div class="scope-bar">SCOPE: Flight planning · Telemetry · Imagery analysis &nbsp;|&nbsp; No weapons · No payload release · No fire-control</div>
<div class="kpi">
  <div class="ki"><div class="kv" id="k-m">0</div><div class="kl">Missions</div></div>
  <div class="ki"><div class="kv" id="k-a">0</div><div class="kl">Alerts</div></div>
  <div class="ki"><div class="kv ok" id="k-b">--</div><div class="kl">Battery %</div></div>
  <div class="ki"><div class="kv ok" id="k-l">--</div><div class="kl">Link %</div></div>
  <div class="ki"><div class="kv" id="k-z">--</div><div class="kl">Alt (m)</div></div>
</div>
<div class="breach" id="breach">&#9888; GEOFENCE BREACH &mdash; Automatic RTL issued &mdash; Ring 6 escalated to Council</div>
<div class="main">
  <div id="map"></div>
  <div class="side">
    <div class="ph">MISSIONS</div>
    <div id="mslist" class="ms-list"><div class="ms-none">No active missions</div></div>
    <div class="ph">TELEMETRY</div>
    <div class="tgrid">
      <div class="tf"><div class="tl">Lat</div><div class="tv" id="t-lat">--</div></div>
      <div class="tf"><div class="tl">Lon</div><div class="tv" id="t-lon">--</div></div>
      <div class="tf"><div class="tl">Alt (m)</div><div class="tv" id="t-alt">--</div></div>
      <div class="tf"><div class="tl">Speed</div><div class="tv" id="t-spd">--</div></div>
      <div class="tf"><div class="tl">Heading</div><div class="tv" id="t-hdg">--</div></div>
      <div class="tf"><div class="tl">Mode</div><div class="tv" id="t-mode">--</div></div>
      <div class="tf"><div class="tl">GPS Fix</div><div class="tv" id="t-gps">--</div></div>
      <div class="tf"><div class="tl">Sats</div><div class="tv" id="t-sat">--</div></div>
      <div class="tf"><div class="tl">Gimbal</div><div class="tv" id="t-gim">--</div></div>
      <div class="tf"><div class="tl">Link %</div><div class="tv" id="t-lnk">--</div></div>
    </div>
    <div class="bat-wrap">
      <div style="font-size:.64em;color:var(--dim);margin-bottom:3px;">Battery</div>
      <div class="bat-bar"><div class="bat-fill" id="bat" style="width:100%"></div></div>
    </div>
    <div class="ph">MISSION CONTROL</div>
    <div class="mc">
      <button class="safe" onclick="cmd('hold')">&#9646;&#9646; HOLD</button>
      <button class="safe" onclick="cmd('rtl')">&#8617; RTL</button>
      <button class="safe" onclick="cmd('land')">&#8609; LAND</button>
      <button onclick="cmd('disarm')">&#9675; DISARM</button>
    </div>
    <div class="ph">ALERTS</div>
    <div id="alist" class="alert-list"><div class="ano">No active alerts</div></div>
  </div>
</div>
<div id="toast"></div>
<script>
var sel=null, trail=null, marker=null;
var map=L.map("map",{zoomControl:true}).setView([0,0],3);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
  {attribution:"&copy; OpenStreetMap contributors",maxZoom:19}).addTo(map);
var icon=L.divIcon({html:'<div style="width:16px;height:16px;background:#ff3366;border:2px solid #fff;border-radius:50%;box-shadow:0 0 7px #ff3366;"></div>',iconSize:[16,16],iconAnchor:[8,8],className:""});

setInterval(()=>{document.getElementById("clk").innerText=new Date().toISOString().replace("T"," ").slice(0,19)+" UTC";},1000);

function pc(v){return v>50?"var(--ok)":v>25?"var(--warn)":"var(--crit)";}
function kpi(id,v,c){var e=document.getElementById(id);if(!e)return;e.innerText=v;if(c)e.style.color=c;}
function tv(id,v){var e=document.getElementById(id);if(e)e.innerText=v;}

async function loadMissions(){
  var r=await fetch("/drone/api/missions/active"),d=await r.json(),ms=d.missions||[];
  kpi("k-m",ms.length);
  var box=document.getElementById("mslist");
  if(!ms.length){box.innerHTML='<div class="ms-none">No active missions</div>';return;}
  if(!sel||ms.indexOf(sel)<0) sel=ms[0];
  box.innerHTML=ms.map(m=>'<div class="ms-item'+(m===sel?" active":"")
    +'" onclick="pick(\''+m+'\')"><div style="word-break:break-all">'+m+'</div></div>').join("");
}

function pick(m){sel=m;loadMissions();refreshTrack();}

async function refreshTelem(){
  if(!sel)return;
  var r;try{r=await fetch("/drone/api/telemetry/"+sel+"/latest");}catch(e){return;}
  if(!r.ok)return;
  var d=await r.json();
  tv("t-lat",d.lat!=null?d.lat.toFixed(6):"--");
  tv("t-lon",d.lon!=null?d.lon.toFixed(6):"--");
  tv("t-alt",d.alt_m!=null?d.alt_m.toFixed(1)+"m":"--");
  tv("t-spd",d.speed_mps!=null?d.speed_mps.toFixed(1)+"m/s":"--");
  tv("t-hdg",d.heading_deg!=null?d.heading_deg.toFixed(0)+"°":"--");
  tv("t-mode",d.flight_mode||"--");
  tv("t-gps",d.gps_fix_type||"--");
  tv("t-sat",d.satellites!=null?d.satellites:"--");
  tv("t-gim",d.gimbal_pitch_deg!=null?d.gimbal_pitch_deg.toFixed(0)+"°":"--");
  tv("t-lnk",d.link_quality_pct!=null?d.link_quality_pct.toFixed(0)+"%":"--");
  var bat=d.battery_pct!=null?d.battery_pct:100;
  var bf=document.getElementById("bat");
  bf.style.width=bat+"%";bf.style.background=pc(bat);
  kpi("k-b",bat.toFixed(0)+"%",pc(bat));
  kpi("k-l",d.link_quality_pct!=null?d.link_quality_pct.toFixed(0)+"%":"--",pc(d.link_quality_pct??100));
  kpi("k-z",d.alt_m!=null?d.alt_m.toFixed(1)+"m":"--");
  if(d.lat!=null&&d.lon!=null){
    if(!marker){marker=L.marker([d.lat,d.lon],{icon:icon}).addTo(map);map.setView([d.lat,d.lon],15);}
    else marker.setLatLng([d.lat,d.lon]);
  }
}

async function refreshTrack(){
  if(!sel)return;
  var r=await fetch("/drone/api/telemetry/"+sel+"/track?limit=500");
  var d=await r.json(),pts=(d.track||[]).map(t=>[t.lat,t.lon]);
  if(!pts.length)return;
  if(trail) trail.setLatLngs(pts);
  else{trail=L.polyline(pts,{color:"#00ffcc",weight:2,opacity:.7}).addTo(map);
    if(pts.length>1)map.fitBounds(trail.getBounds(),{padding:[20,20]});}
}

async function refreshAlerts(){
  var url=sel?"/drone/api/alerts?mission_id="+sel:"/drone/api/alerts";
  var r=await fetch(url),d=await r.json(),al=d.alerts||[];
  kpi("k-a",al.length,al.length>0?"var(--crit)":"var(--ok)");
  var box=document.getElementById("alist");
  if(!al.length){box.innerHTML='<div class="ano">No active alerts</div>';return;}
  box.innerHTML=al.map(a=>'<div class="arow '+a.severity+'"><div>'
    +'<div style="font-weight:bold;color:'+(a.severity==="CRITICAL"?"var(--crit)":"var(--warn)")+'">'+a.severity+" &mdash; "+a.code+"</div>"
    +'<div style="color:var(--dim);font-size:.9em;margin-top:1px;">'+(a.detail||"")+"</div></div>"
    +'<span class="ack" onclick="ack('+a.id+')">ACK</span></div>').join("");
  var hasBreach=al.some(a=>a.code&&a.code.indexOf("GEOFENCE")>=0);
  document.getElementById("breach").style.display=hasBreach?"block":"none";
}

async function ack(id){await fetch("/drone/api/alerts/"+id+"/ack",{method:"POST"});refreshAlerts();}

async function cmd(c){
  if(!sel){toast("Select an active mission first","var(--warn)");return;}
  var eps={hold:"/drone/api/cmd/hold",rtl:"/drone/api/cmd/rtl",
           land:"/drone/api/cmd/land",disarm:"/drone/api/cmd/disarm"};
  var r=await fetch(eps[c],{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({mission_id:sel})});
  var d=await r.json();
  var ok=d.accepted!==undefined?d.accepted:true;
  toast(ok?"&#10003; "+c.toUpperCase()+" accepted":"&#10007; "+c.toUpperCase()+" rejected &mdash; "+(d.detail||""),ok?"var(--ok)":"var(--crit)");
}

function toast(msg,col){
  var t=document.getElementById("toast");
  t.innerHTML=msg;t.style.borderColor=col||"var(--accent)";
  t.style.color=col||"var(--accent)";t.style.display="block";
  clearTimeout(t._t);t._t=setTimeout(()=>{t.style.display="none";},3500);
}

async function tick(){await loadMissions();await refreshTelem();await refreshAlerts();}
async function trackTick(){await refreshTrack();}
tick();setInterval(tick,3000);setInterval(trackTick,8000);
</script>
</body>
</html>
"""


@drone_bp.route("/dashboard")
def dashboard():
    return render_template_string(DASHBOARD_HTML)


# ── Mission planning routes ────────────────────────────────────────────────────

@drone_bp.route("/api/geofence", methods=["POST"])
def api_create_geofence():
    """Defines an operating boundary. Ring 3 — local config write, no flight commanded."""
    from zeus_sovereignty_engine import sovereign_execute
    from zeus_drone_coverage import Geofence

    data = request.get_json() or {}
    polygon = data.get("polygon")
    if not polygon or len(polygon) < 3:
        return jsonify({"error": "polygon (>=3 [lat,lon] points) required"}), 400

    gate_result = sovereign_execute(
        "drone_mission_plan", f"Geofence definition: {data.get('label', 'unlabeled')}", data,
    )
    fence_id = "fence_" + str(int(time.time() * 1000))
    fence = Geofence(
        fence_id=fence_id,
        polygon=[tuple(p) for p in polygon],
        max_altitude_m=data.get("max_altitude_m", 120.0),
        min_altitude_m=data.get("min_altitude_m", 10.0),
        label=data.get("label", ""),
    )
    _fences[fence_id] = fence

    # If the caller also supplied a mission_id, register this fence
    # for live monitoring now — every subsequent telemetry sample for
    # that mission_id will be checked against it (see api_ingest_telemetry).
    mission_id = data.get("mission_id")
    if mission_id:
        from zeus_drone_geofence_monitor import get_monitor
        get_monitor().register_mission(mission_id, fence)
        _get_command_bridge()   # ensure the monitor has a bridge attached for auto-RTL

    return jsonify({"success": True, "fence_id": fence_id, "fence": {
        "fence_id": fence.fence_id, "polygon": fence.polygon,
        "max_altitude_m": fence.max_altitude_m, "min_altitude_m": fence.min_altitude_m,
        "label": fence.label,
    }, "sovereignty_gate": gate_result})


@drone_bp.route("/api/mission/plan", methods=["POST"])
def api_plan_mission():
    """
    Computes a coverage mission. Ring 3 — pure computation, no airframe
    is commanded by this call. pattern: lawnmower | spiral | orbit
    """
    from zeus_sovereignty_engine import sovereign_execute
    from zeus_drone_coverage import CoveragePlanner, Geofence, AirframeProfile

    data = request.get_json() or {}
    pattern = data.get("pattern", "lawnmower")
    fence_data = data.get("geofence")
    if not fence_data or not fence_data.get("polygon"):
        return jsonify({"error": "geofence with polygon required"}), 400

    gate_result = sovereign_execute(
        "drone_coverage_compute", f"{pattern} mission plan", data,
    )

    fence = Geofence(
        fence_id=fence_data.get("fence_id", "adhoc"),
        polygon=[tuple(p) for p in fence_data["polygon"]],
        max_altitude_m=fence_data.get("max_altitude_m", 120.0),
        min_altitude_m=fence_data.get("min_altitude_m", 10.0),
    )
    airframe = AirframeProfile(
        name=data.get("airframe_name", "generic_isr_quad"),
        max_speed_mps=data.get("max_speed_mps", 12.0),
        cruise_speed_mps=data.get("cruise_speed_mps", 7.0),
        max_flight_time_s=data.get("max_flight_time_s", 1500.0),
        battery_reserve_pct=data.get("battery_reserve_pct", 20.0),
    )
    planner = CoveragePlanner(fence, airframe)

    if pattern == "lawnmower":
        result = planner.lawnmower(
            polygon=[tuple(p) for p in data.get("area_polygon", fence.polygon)],
            alt_m=data.get("alt_m", 60.0),
            swath_width_m=data.get("swath_width_m", 40.0),
            speed_mps=data.get("speed_mps", 7.0),
        )
    elif pattern == "spiral":
        result = planner.expanding_spiral(
            center_lat=data["center_lat"], center_lon=data["center_lon"],
            alt_m=data.get("alt_m", 60.0),
            max_radius_m=data.get("max_radius_m", 200.0),
            ring_spacing_m=data.get("ring_spacing_m", 30.0),
            speed_mps=data.get("speed_mps", 5.0),
        )
    elif pattern == "orbit":
        result = planner.perimeter_orbit(
            center_lat=data["center_lat"], center_lon=data["center_lon"],
            alt_m=data.get("alt_m", 60.0),
            orbit_radius_m=data.get("orbit_radius_m", 80.0),
            speed_mps=data.get("speed_mps", 4.0),
            loiter_seconds_per_point=data.get("loiter_seconds_per_point", 0.0),
        )
    else:
        return jsonify({"error": f"unknown pattern '{pattern}' — use lawnmower|spiral|orbit"}), 400

    result["sovereignty_gate"] = gate_result
    return jsonify(result)


@drone_bp.route("/api/mission/execute", methods=["POST"])
def api_execute_mission():
    """
    Submits an already-planned, geofence-validated mission for
    execution. Ring 5 — full autonomous, crosswire-scanned. The
    mission dict passed in `mission` should be the full output of
    /api/mission/plan (mission_id + waypoints).

    v2.3: this route now actually issues commands through
    zeus_drone_command_bridge.CommandBridge — by default against
    SimulatorTransport (no real airframe is ever touched unless an
    operator explicitly attaches a real transport via
    _get_command_bridge()'s documented override hook). Every
    individual command (ARM/TAKEOFF/GOTO/RTL) is still independently
    ring-gated inside the bridge — this route's own
    drone_mission_execute gate is the umbrella authorization for
    starting the sequence, not a bypass of the per-command gates.
    """
    from zeus_sovereignty_engine import sovereign_execute
    data = request.get_json() or {}
    mission_id = data.get("mission_id", "")
    mission = data.get("mission")
    if not mission_id:
        return jsonify({"error": "mission_id required"}), 400

    gate_result = sovereign_execute(
        "drone_mission_execute", f"Execute mission {mission_id}", data,
    )

    if gate_result.get("status") != "executed":
        return jsonify({"mission_id": mission_id, "sovereignty_gate": gate_result,
                        "command_results": [], "note": "Umbrella gate did not authorize "
                        "immediate execution; no commands were issued."})

    command_results = []
    if mission and mission.get("waypoints"):
        bridge = _get_command_bridge()
        results = bridge.fly_mission(mission)
        command_results = [r.to_dict() for r in results]
    else:
        log.info("api_execute_mission: no waypoints supplied for %s — gate recorded, "
                 "no commands issued (pass full mission dict from /api/mission/plan "
                 "in the 'mission' field to actually fly).", mission_id)

    return jsonify({"mission_id": mission_id, "sovereignty_gate": gate_result,
                    "command_results": command_results})


# ── Telemetry routes ────────────────────────────────────────────────────────────

@drone_bp.route("/api/telemetry/ingest", methods=["POST"])
def api_ingest_telemetry():
    from zeus_sovereignty_engine import sovereign_execute
    from zeus_drone_telemetry import TelemetrySample

    data = request.get_json() or {}
    required = ("mission_id", "lat", "lon", "alt_m")
    if not all(k in data for k in required):
        return jsonify({"error": f"required fields: {required}"}), 400

    sovereign_execute("drone_telemetry_ingest", f"Telemetry sample for {data['mission_id']}", data)

    sample = TelemetrySample(
        mission_id=data["mission_id"],
        timestamp_utc=data.get("timestamp_utc", datetime.now(timezone.utc).isoformat()),
        lat=data["lat"], lon=data["lon"], alt_m=data["alt_m"],
        heading_deg=data.get("heading_deg", 0.0), speed_mps=data.get("speed_mps", 0.0),
        battery_pct=data.get("battery_pct", 100.0), link_quality_pct=data.get("link_quality_pct", 100.0),
        gimbal_pitch_deg=data.get("gimbal_pitch_deg", -90.0),
        gps_fix_type=data.get("gps_fix_type", "3D_FIX"), satellites=data.get("satellites", 0),
        flight_mode=data.get("flight_mode", "AUTO"),
    )
    alerts = _get_store().ingest(sample)

    # Live geofence check (v2.3, additive) — only affects missions that
    # were registered via /api/geofence with a mission_id; unregistered/
    # ad-hoc telemetry is unaffected and unmonitored, same as before.
    from zeus_drone_geofence_monitor import get_monitor
    fence_check = get_monitor().check(sample.mission_id, sample.lat, sample.lon, sample.alt_m)

    return jsonify({"success": True, "alerts_triggered": alerts, "geofence_check": fence_check})


@drone_bp.route("/api/telemetry/<mission_id>/latest")
def api_telemetry_latest(mission_id: str):
    latest = _get_store().latest(mission_id)
    if not latest:
        return jsonify({"error": "no telemetry for this mission_id"}), 404
    return jsonify(latest)


@drone_bp.route("/api/telemetry/<mission_id>/track")
def api_telemetry_track(mission_id: str):
    limit = int(request.args.get("limit", 500))
    return jsonify({"mission_id": mission_id, "track": _get_store().track(mission_id, limit)})


@drone_bp.route("/api/missions/active")
def api_active_missions():
    return jsonify({"missions": _get_store().active_missions()})


@drone_bp.route("/api/alerts")
def api_alerts():
    mission_id = request.args.get("mission_id")
    return jsonify({"alerts": _get_store().active_alerts(mission_id)})


@drone_bp.route("/api/alerts/<int:alert_id>/ack", methods=["POST"])
def api_ack_alert(alert_id: int):
    from zeus_sovereignty_engine import sovereign_execute
    sovereign_execute("drone_alert_ack", f"Acknowledge alert {alert_id}", {"alert_id": alert_id})
    success = _get_store().acknowledge_alert(alert_id)
    return jsonify({"success": success, "alert_id": alert_id})


# ── Imagery / sensor processing routes ───────────────────────────────────────────

@drone_bp.route("/api/vision/geotag", methods=["POST"])
def api_geotag_frame():
    from zeus_sovereignty_engine import sovereign_execute
    from zeus_drone_vision import FrameGeotagger

    data = request.get_json() or {}
    image_path = data.get("image_path", "")
    mission_id = data.get("mission_id", "")
    if not image_path or not mission_id:
        return jsonify({"error": "image_path and mission_id required"}), 400

    sovereign_execute("drone_frame_geotag", f"Geotag frame for {mission_id}", data)

    telemetry = data.get("telemetry") or _get_store().latest(mission_id) or {}
    result = FrameGeotagger().tag(image_path, mission_id, telemetry)
    return jsonify(result)


@drone_bp.route("/api/vision/change_detect", methods=["POST"])
def api_change_detect():
    from zeus_sovereignty_engine import sovereign_execute
    from zeus_drone_vision import ChangeDetector

    data = request.get_json() or {}
    before = data.get("image_path_before", "")
    after = data.get("image_path_after", "")
    if not before or not after:
        return jsonify({"error": "image_path_before and image_path_after required"}), 400

    gate_result = sovereign_execute("drone_change_detect", "Change detection analysis", data)
    result = ChangeDetector().compare(before, after, min_area_px=data.get("min_area_px", 400))
    result["sovereignty_gate"] = gate_result

    # ── Hive + Tartarus wiring (v2.4, additive) ──────────────────────────────
    if result.get("success"):
        try:
            from zeus_drone_hive_wire import get_wire
            get_wire().publish_change_detection(data.get("mission_id", "unknown"), result)
        except Exception as _hw:
            log.debug("[drone_blueprint] hive wire change_detect: %s", _hw)
    # ─────────────────────────────────────────────────────────────────────────

    return jsonify(result)


@drone_bp.route("/api/vision/coverage_score", methods=["POST"])
def api_coverage_score():
    from zeus_sovereignty_engine import sovereign_execute
    from zeus_drone_vision import CoverageQualityScorer

    data = request.get_json() or {}
    polygon = data.get("planned_polygon")
    frames = data.get("frames", [])
    if not polygon:
        return jsonify({"error": "planned_polygon required"}), 400

    gate_result = sovereign_execute("drone_coverage_score", "Mission coverage QA scoring", data)
    result = CoverageQualityScorer().score(
        planned_polygon=[tuple(p) for p in polygon],
        frames=frames,
        grid_cells_per_side=data.get("grid_cells_per_side", 20),
    )
    result["sovereignty_gate"] = gate_result

    # ── Hive + Tartarus wiring (v2.4, additive) ──────────────────────────────
    if result.get("success"):
        try:
            from zeus_drone_hive_wire import get_wire
            get_wire().publish_coverage_score(data.get("mission_id", "unknown"), result)
        except Exception as _hw:
            log.debug("[drone_blueprint] hive wire coverage_score: %s", _hw)
    # ─────────────────────────────────────────────────────────────────────────

    return jsonify(result)


# ── Direct command routes (wired to CommandBridge, v2.3) ─────────────────────

def _cmd_route(cmd_name: str, bridge_method_name: str, description: str):
    """Shared logic for HOLD/RTL/LAND/DISARM dashboard button routes."""
    from zeus_sovereignty_engine import sovereign_execute
    data = request.get_json() or {}
    mission_id = data.get("mission_id", "")
    if not mission_id:
        return jsonify({"error": "mission_id required"}), 400
    bridge = _get_command_bridge()
    method = getattr(bridge, bridge_method_name)
    result = method(mission_id, reason=f"Dashboard {cmd_name}")
    return jsonify(result.to_dict())


@drone_bp.route("/api/cmd/hold", methods=["POST"])
def api_cmd_hold():
    return _cmd_route("hold", "hold", "operator-requested hold")


@drone_bp.route("/api/cmd/rtl", methods=["POST"])
def api_cmd_rtl():
    return _cmd_route("rtl", "return_to_launch", "operator-requested RTL")


@drone_bp.route("/api/cmd/land", methods=["POST"])
def api_cmd_land():
    return _cmd_route("land", "land", "operator-requested land")


@drone_bp.route("/api/cmd/disarm", methods=["POST"])
def api_cmd_disarm():
    return _cmd_route("disarm", "disarm", "operator-requested disarm")


@drone_bp.route("/api/cmd/arm", methods=["POST"])
def api_cmd_arm():
    data = request.get_json() or {}
    mission_id = data.get("mission_id", "")
    if not mission_id:
        return jsonify({"error": "mission_id required"}), 400
    result = _get_command_bridge().arm(mission_id)
    return jsonify(result.to_dict())


@drone_bp.route("/api/cmd/goto", methods=["POST"])
def api_cmd_goto():
    data = request.get_json() or {}
    mission_id = data.get("mission_id", "")
    if not mission_id or "lat" not in data or "lon" not in data:
        return jsonify({"error": "mission_id, lat, lon required"}), 400
    result = _get_command_bridge().goto(
        mission_id, data["lat"], data["lon"],
        data.get("alt_m", 60.0), data.get("speed_mps", 5.0))
    return jsonify(result.to_dict())


# ── Geofence monitor routes (v2.3) ───────────────────────────────────────────

@drone_bp.route("/api/geofence/register_monitor", methods=["POST"])
def api_register_monitor():
    """Register an existing fence_id + mission_id pair for live monitoring.
    Useful if the geofence was created without a mission_id originally."""
    data = request.get_json() or {}
    fence_id = data.get("fence_id", "")
    mission_id = data.get("mission_id", "")
    if not fence_id or not mission_id:
        return jsonify({"error": "fence_id and mission_id required"}), 400
    fence = _fences.get(fence_id)
    if not fence:
        return jsonify({"error": f"fence_id {fence_id!r} not found — create it first "
                        "via POST /drone/api/geofence"}), 404
    from zeus_drone_geofence_monitor import get_monitor
    get_monitor().register_mission(mission_id, fence)
    _get_command_bridge()
    return jsonify({"success": True, "mission_id": mission_id, "fence_id": fence_id})


@drone_bp.route("/api/geofence/monitored")
def api_monitored_missions():
    from zeus_drone_geofence_monitor import get_monitor
    return jsonify({"monitored_missions": get_monitor().registered_missions()})


@drone_bp.route("/api/geofence/unregister/<mission_id>", methods=["DELETE"])
def api_unregister_monitor(mission_id: str):
    from zeus_drone_geofence_monitor import get_monitor
    get_monitor().unregister_mission(mission_id)
    return jsonify({"success": True, "mission_id": mission_id})


# ── Zeus v8 registration ──────────────────────────────────────────────────────

def register(app):
    """Register blueprint into Zeus v8 Flask app."""
    app.register_blueprint(drone_bp)
    log.info("[ok] zeus_drone_blueprint registered at /drone")
    return True
