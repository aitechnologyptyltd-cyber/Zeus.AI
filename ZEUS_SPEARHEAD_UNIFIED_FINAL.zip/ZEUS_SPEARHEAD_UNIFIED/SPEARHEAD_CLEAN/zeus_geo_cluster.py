"""
zeus_geo_cluster.py
====================
Zeus GovInt — Geo-Intelligence Clustering & Pattern Engine
The Zeus Project 2026 — additive GovInt extension (v2.1)

Origin: generalised from ATLAS.AI's atlas_map.py spatial clustering
(haversine_distance + assign_cluster), which assigned real geographic
cluster IDs to plot coordinates using nearest-centre matching. Here
it is repurposed from "cluster game plots" to "cluster a target's
accumulated geolocation_queries history" — turning a flat list of
past locate() results into a small number of meaningful "places of
interest" (frequent locations, dwell clusters, movement corridors)
for analyst review.

This module reads from the SAME govint_warrants.db SQLite file that
zeus_geo_auth.AuthorizationGate already writes geolocation_queries
into. It does not create a parallel data store, and it does not
write back into authorization_documents or authorization_audit —
those remain exclusively owned by AuthorizationGate.

Nothing in zeus_geo_intel.py or zeus_geo_auth.py is modified by this
module. It is purely additive — a read-side analytics layer.
"""
from __future__ import annotations

import logging
import math
import sqlite3
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("zeus.geo_cluster")

# Ring classification for cluster/pattern analysis actions — read-only
# aggregation over already-authorized, already-logged query history, so
# this sits at Ring 3 (system_info_query-equivalent) rather than Ring 6;
# it derives no NEW location data, it only summarises what GovInt has
# already lawfully collected and logged.
GEO_CLUSTER_RING_TYPES = {
    "geo_cluster_analyze": 3,
    "geo_pattern_report":  3,
}


def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2
         + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2))
         * math.sin(dlon / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


@dataclass
class GeoCluster:
    cluster_id: int
    centroid_lat: float
    centroid_lon: float
    point_count: int = 0
    first_seen_utc: Optional[str] = None
    last_seen_utc: Optional[str] = None
    radius_km: float = 0.0          # max distance from centroid to any member point
    member_methods: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cluster_id": self.cluster_id,
            "centroid": {"lat": round(self.centroid_lat, 6), "lon": round(self.centroid_lon, 6)},
            "point_count": self.point_count,
            "first_seen_utc": self.first_seen_utc,
            "last_seen_utc": self.last_seen_utc,
            "radius_km": round(self.radius_km, 3),
            "methods_observed": sorted(set(self.member_methods)),
        }


class GeoClusterEngine:
    """
    Nearest-centre haversine clustering over a target's logged
    geolocation_queries, plus simple pattern-of-life summarisation
    (most-frequent place, dwell estimate, movement spread).

    Deliberately uses the same lightweight incremental nearest-centre
    approach as ATLAS.AI rather than pulling in scikit-learn/K-means —
    consistent with GovInt's existing zero-heavy-dependency design
    (see zeus_council_router.py's local heuristic scorer for the same
    philosophy applied elsewhere in the v2 codebase).
    """

    def __init__(self, db_path: str, merge_radius_km: float = 0.5):
        self.db_path = db_path
        self.merge_radius_km = merge_radius_km

    def _load_points(self, target_identifier: str, since_epoch: Optional[float] = None) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            q = """
                SELECT timestamp_utc, epoch, result_lat, result_lon, method, query_type
                FROM geolocation_queries
                WHERE target_identifier = ?
                  AND result_lat IS NOT NULL AND result_lon IS NOT NULL
                  AND NOT (result_lat = 0 AND result_lon = 0)
            """
            params: List[Any] = [target_identifier]
            if since_epoch is not None:
                q += " AND epoch >= ?"
                params.append(since_epoch)
            q += " ORDER BY epoch ASC"
            cursor = conn.execute(q, params)
            cols = [d[0] for d in cursor.description]
            return [dict(zip(cols, row)) for row in cursor.fetchall()]

    def cluster(self, target_identifier: str, since_epoch: Optional[float] = None) -> Dict[str, Any]:
        """
        Clusters all logged location points for a target into a small
        number of "places of interest" using incremental nearest-centre
        assignment (merge_radius_km controls cluster granularity).
        """
        points = self._load_points(target_identifier, since_epoch)
        if not points:
            return {
                "target_identifier": target_identifier,
                "point_count": 0,
                "clusters": [],
                "note": "No logged geolocation_queries with valid coordinates for this target.",
            }

        clusters: List[GeoCluster] = []

        for p in points:
            lat, lon = p["result_lat"], p["result_lon"]
            best_idx, best_dist = None, float("inf")
            for i, c in enumerate(clusters):
                d = haversine_distance_km(lat, lon, c.centroid_lat, c.centroid_lon)
                if d < best_dist:
                    best_dist, best_idx = d, i

            if best_idx is not None and best_dist <= self.merge_radius_km:
                c = clusters[best_idx]
                # incremental centroid update (running mean)
                n = c.point_count
                c.centroid_lat = (c.centroid_lat * n + lat) / (n + 1)
                c.centroid_lon = (c.centroid_lon * n + lon) / (n + 1)
                c.point_count += 1
                c.last_seen_utc = p["timestamp_utc"]
                c.radius_km = max(c.radius_km, best_dist)
                c.member_methods.append(p.get("method") or "")
            else:
                clusters.append(GeoCluster(
                    cluster_id=len(clusters),
                    centroid_lat=lat, centroid_lon=lon,
                    point_count=1,
                    first_seen_utc=p["timestamp_utc"],
                    last_seen_utc=p["timestamp_utc"],
                    radius_km=0.0,
                    member_methods=[p.get("method") or ""],
                ))

        clusters.sort(key=lambda c: c.point_count, reverse=True)
        for i, c in enumerate(clusters):
            c.cluster_id = i

        return {
            "target_identifier": target_identifier,
            "point_count": len(points),
            "cluster_count": len(clusters),
            "merge_radius_km": self.merge_radius_km,
            "clusters": [c.to_dict() for c in clusters],
            "primary_cluster": clusters[0].to_dict() if clusters else None,
        }

    def pattern_report(self, target_identifier: str, since_epoch: Optional[float] = None) -> Dict[str, Any]:
        """
        Builds a human-readable pattern-of-life summary on top of
        cluster() — frequency-weighted "place of interest" ranking,
        rough activity span, and a flag for single-point vs.
        multi-location targets (useful triage signal for an analyst
        deciding whether escalation to a higher GovInt tier is
        warranted).
        """
        result = self.cluster(target_identifier, since_epoch)
        clusters = result.get("clusters", [])
        total = result.get("point_count", 0)

        ranked = []
        for c in clusters:
            pct = round(100.0 * c["point_count"] / total, 1) if total else 0.0
            ranked.append({**c, "frequency_pct": pct})

        summary = {
            "target_identifier": target_identifier,
            "total_observations": total,
            "distinct_places_of_interest": len(clusters),
            "ranked_places": ranked,
            "single_location_target": len(clusters) <= 1,
            "generated_utc": datetime.now(timezone.utc).isoformat(),
        }
        return summary


# ── Integration note (read, do not auto-run) ──────────────────────────────────
# This module is consumed by:
#   - zeus_govint_blueprint.py -> GET /govint/api/cluster/<target>,
#                                  GET /govint/api/pattern/<target>
# Both call zeus_sovereignty_engine.sovereign_execute() with action_type
# values from GEO_CLUSTER_RING_TYPES above, and read auth_gate.db_path
# from the already-initialised _get_systems() singleton in the blueprint
# rather than opening a second, divergent database connection elsewhere.
