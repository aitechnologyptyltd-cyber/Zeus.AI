"""
zeus_drone_hive_wire.py
=========================
Zeus Drone ISR — Hive Mind & Tartarus Integration
The Zeus Project 2026 — additive extension (v2.4)

This is the piece Grok correctly identified as missing: drone sensor
observations feeding back into the system's learning loop. Before this
module, zeus_drone_telemetry.TelemetryStore and zeus_drone_vision.*
produced structured data that went nowhere except their own SQLite
tables. After this module, every significant drone event is:

  1. Published to the Hive Memory bus (zeus_hive_bridge._hive.publish)
     under the "drone_isr" source — making drone events visible in
     /api/hive/events, in the collective_log SSE stream, and to any
     other Zeus subsystem that subscribes to the bus.

  2. Pushed into TartarusMemory (zeus_tartarus_core.TartarusMemory.get())
     under appropriate pool fields so the Tartarus learning engine and
     omnisense cross-domain synthesiser can incorporate drone-derived
     spatial/temporal patterns into its reasoning, exactly as AEGIS
     and sovereignty events already feed it.

  3. Written to the hive's sovereign stream with a sovereignty_ring
     annotation so the Ring/Council audit trail links drone observations
     to the ring-classified action that produced them.

DESIGN — two layers:

  HivePublisher  — thin wrapper around zeus_hive_bridge._hive.publish()
                   that degrades gracefully when _hive is not yet
                   initialised (process startup race) or when the class
                   body is absent (known v2 cleanup gap documented in
                   the SPEARHEAD tech reference). Never raises; always
                   logs the miss so it's visible without crashing.

  DroneHiveWire  — the actual integration bridge. Provides one method
                   per drone event type:
                     publish_telemetry_sample()
                     publish_alert()
                     publish_geofence_breach()
                     publish_mission_complete()
                     publish_change_detection()
                     publish_coverage_score()
                   Each method calls both HivePublisher and Tartarus.

WIRING — this module is called from three existing modules, additively:
  - zeus_drone_telemetry.TelemetryStore.ingest()
      → publish_telemetry_sample() per sample
      → publish_alert() per triggered threshold alert
  - zeus_drone_geofence_monitor.GeofenceMonitor._escalate_breach()
      → publish_geofence_breach()
  - zeus_drone_blueprint.api_change_detect() / api_coverage_score()
      → publish_change_detection() / publish_coverage_score()

No existing method signatures change. All calls are additive appends
inside those methods, wrapped in try/except so a hive-wire failure
never disrupts the primary telemetry/command path.
"""
from __future__ import annotations

import logging
import time
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

log = logging.getLogger("zeus.drone_hive_wire")

# ── HivePublisher — graceful wrapper around _hive.publish ────────────────────

class HivePublisher:
    """
    Resolves zeus_hive_bridge._hive at call time (not at import time)
    so we don't fail if this module is imported before register_zeus_bridge()
    runs. Two fallback levels:

      Level 1: _hive.publish() exists and works — normal operation.
      Level 2: _hive exists but publish() is missing or HiveMemory class
               body was stripped in the v2 cleanup — log the miss, write
               directly to collective_log deque if accessible.
      Level 3: _hive doesn't exist yet (startup race or disabled) —
               buffer the event in-memory and retry on the next publish.

    This triple-fallback means drone hive-wiring never crashes the
    telemetry ingest path regardless of initialization order.
    """

    def __init__(self, buffer_size: int = 200):
        self._lock = threading.Lock()
        self._buffer: List[Dict[str, Any]] = []
        self._buffer_size = buffer_size

    def _get_hive(self):
        try:
            import zeus_hive_bridge as zhb
            # _hive may be a module-level variable set by register_zeus_bridge
            return getattr(zhb, "_hive", None)
        except Exception:
            return None

    def publish(self, source: str, event_type: str, payload: Dict[str, Any]) -> bool:
        """
        Publishes one event. Returns True if published to the live hive,
        False if buffered or discarded (with a debug log in either case).
        """
        entry = {
            "source":     source,
            "event_type": event_type,
            "payload":    payload,
            "ts":         time.time(),
        }

        # Drain any buffered events first
        self._drain_buffer()

        hive = self._get_hive()
        if hive is None:
            self._buffer_event(entry)
            return False

        # Level 1: full publish()
        if hasattr(hive, "publish") and callable(hive.publish):
            try:
                hive.publish(source, event_type, payload)
                return True
            except Exception as e:
                log.debug("[drone_hive_wire] publish() raised: %s — falling through", e)

        # Level 2: direct collective_log append
        if hasattr(hive, "collective_log"):
            try:
                hive.collective_log.append(entry)
                return True
            except Exception as e:
                log.debug("[drone_hive_wire] collective_log.append raised: %s", e)

        # Level 3: buffer
        self._buffer_event(entry)
        return False

    def _buffer_event(self, entry: Dict[str, Any]) -> None:
        with self._lock:
            if len(self._buffer) < self._buffer_size:
                self._buffer.append(entry)
            else:
                # Drop oldest — ring-buffer semantics
                self._buffer.pop(0)
                self._buffer.append(entry)
        log.debug("[drone_hive_wire] event buffered (hive not ready): %s",
                  entry.get("event_type"))

    def _drain_buffer(self) -> None:
        with self._lock:
            if not self._buffer:
                return
            to_drain = list(self._buffer)
            self._buffer.clear()

        hive = self._get_hive()
        if hive is None:
            with self._lock:
                self._buffer = to_drain + self._buffer
            return

        drained = 0
        for entry in to_drain:
            try:
                if hasattr(hive, "publish") and callable(hive.publish):
                    hive.publish(entry["source"], entry["event_type"], entry["payload"])
                    drained += 1
                elif hasattr(hive, "collective_log"):
                    hive.collective_log.append(entry)
                    drained += 1
            except Exception:
                pass

        if drained:
            log.info("[drone_hive_wire] drained %d buffered events to hive", drained)


# ── TartarusPusher — graceful wrapper around TartarusMemory.push ─────────────

class TartarusPusher:
    """
    Resolves TartarusMemory at call time. Degrades gracefully if
    zeus_tartarus_core is not importable (missing optional dependency)
    or TartarusMemory.get() fails.
    """

    def push(self, field: str, item: Any, source: str = "drone_isr") -> bool:
        try:
            from zeus_tartarus_core import TartarusMemory, POOL_FIELDS
            if field not in POOL_FIELDS:
                log.debug("[drone_hive_wire] Tartarus field %r not in POOL_FIELDS — skip", field)
                return False
            TartarusMemory.get().push(field, item, source)
            return True
        except Exception as e:
            log.debug("[drone_hive_wire] Tartarus push failed: %s", e)
            return False


# ── DroneHiveWire — the integration bridge ───────────────────────────────────

class DroneHiveWire:
    """
    Singleton bridge. All drone modules call the module-level
    get_wire() function to get this — they never instantiate it
    directly.
    """

    SOURCE = "drone_isr"

    def __init__(self):
        self._pub  = HivePublisher()
        self._tart = TartarusPusher()

    # ── Telemetry ─────────────────────────────────────────────────────────────

    def publish_telemetry_sample(self, sample: Dict[str, Any]) -> None:
        """
        Called by TelemetryStore.ingest() for every ingested sample.
        Publishes to hive bus. Also pushes a compact sensor reading
        into Tartarus 'streams' field for time-series learning.
        Low-frequency Tartarus push (every 10th sample by default)
        to avoid flooding the learning pool with raw telemetry.
        """
        self._pub.publish(self.SOURCE, "drone_telemetry_sample", {
            "mission_id":   sample.get("mission_id"),
            "lat":          sample.get("lat"),
            "lon":          sample.get("lon"),
            "alt_m":        sample.get("alt_m"),
            "battery_pct":  sample.get("battery_pct"),
            "speed_mps":    sample.get("speed_mps"),
            "flight_mode":  sample.get("flight_mode"),
            "ts":           time.time(),
        })

        # Tartarus sensor stream — spatial/temporal data for cross-domain
        # pattern synthesis (e.g. Tartarus phase 5 omnisense can correlate
        # flight altitude patterns with AEGIS threat scores over time).
        sample_count = getattr(self, "_telem_count", 0) + 1
        self._telem_count = sample_count
        if sample_count % 10 == 0:
            self._tart.push("streams", {
                "type":        "drone_position",
                "mission_id":  sample.get("mission_id"),
                "lat":         sample.get("lat"),
                "lon":         sample.get("lon"),
                "alt_m":       sample.get("alt_m"),
                "battery_pct": sample.get("battery_pct"),
                "ts":          time.time(),
            }, source=self.SOURCE)

    # ── Threshold alerts ──────────────────────────────────────────────────────

    def publish_alert(self, mission_id: str, alert: Dict[str, Any]) -> None:
        """
        Called by TelemetryStore.ingest() for each triggered alert.
        Publishes to hive bus AND pushes into Tartarus 'inputs' so
        the learning engine can build a model of which flight
        conditions precede battery/link/GPS failure events.
        """
        self._pub.publish(self.SOURCE, "drone_threshold_alert", {
            "mission_id": mission_id,
            "severity":   alert.get("severity"),
            "code":       alert.get("code"),
            "detail":     alert.get("detail"),
            "ts":         time.time(),
        })

        self._tart.push("inputs", {
            "type":       "drone_alert",
            "mission_id": mission_id,
            "severity":   alert.get("severity"),
            "code":       alert.get("code"),
        }, source=self.SOURCE)

    # ── Geofence breach ───────────────────────────────────────────────────────

    def publish_geofence_breach(self, mission_id: str, lat: float, lon: float,
                                 alt_m: float, reason: str,
                                 sovereignty_ring: int = 6) -> None:
        """
        Called by GeofenceMonitor._escalate_breach(). Publishes to hive
        bus as a security-tier event (same bus source as AEGIS threats,
        so existing security dashboards surface it without modification)
        AND pushes a pattern entry into Tartarus 'patterns' so the
        learning engine can model typical breach geometries.
        """
        payload = {
            "mission_id":       mission_id,
            "lat":              lat,
            "lon":              lon,
            "alt_m":            alt_m,
            "reason":           reason,
            "sovereignty_ring": sovereignty_ring,
            "ts":               time.time(),
        }
        # Publish as a drone event on the hive bus
        self._pub.publish(self.SOURCE, "drone_geofence_breach", payload)

        # Also publish as an aegis-tier event so it appears in the
        # threat dashboard — geofence breach is a safety boundary
        # violation that analysts monitoring security should see.
        self._pub.publish("aegis", "drone_geofence_breach", {
            **payload,
            "note": "Drone ISR geofence boundary violation — automatic RTL issued",
        })

        self._tart.push("patterns", {
            "type":             "drone_geofence_breach",
            "mission_id":       mission_id,
            "lat":              lat,
            "lon":              lon,
            "alt_m":            alt_m,
            "sovereignty_ring": sovereignty_ring,
        }, source=self.SOURCE)

    # ── Mission complete ──────────────────────────────────────────────────────

    def publish_mission_complete(self, mission_id: str, pattern_type: str,
                                  waypoint_count: int, duration_s: float,
                                  distance_m: float) -> None:
        """
        Called when a fly_mission() sequence reaches its final RTL.
        Pushes a mission summary into Tartarus 'datasets' field so
        the learning engine can build a model of mission durations,
        distances, and coverage patterns over time — useful for
        estimating future mission planning parameters automatically.
        """
        payload = {
            "mission_id":    mission_id,
            "pattern_type":  pattern_type,
            "waypoint_count": waypoint_count,
            "duration_s":    duration_s,
            "distance_m":    distance_m,
            "ts":            time.time(),
        }
        self._pub.publish(self.SOURCE, "drone_mission_complete", payload)

        self._tart.push("datasets", {
            "type":          "drone_mission_summary",
            **payload,
        }, source=self.SOURCE)

        # Feed into Tartarus 'insights' as a natural-language observation
        # for the LLM-augmented analysis phases.
        self._tart.push("insights", {
            "type":    "drone_observation",
            "content": (
                f"ISR mission {mission_id} ({pattern_type}) completed: "
                f"{waypoint_count} waypoints, {distance_m:.0f}m, {duration_s:.0f}s. "
                f"Mission geometry and timing available for pattern analysis."
            ),
            "source":  self.SOURCE,
            "ts":      time.time(),
        }, source=self.SOURCE)

    # ── Change detection ──────────────────────────────────────────────────────

    def publish_change_detection(self, mission_id: str, result: Dict[str, Any]) -> None:
        """
        Called by zeus_drone_blueprint.api_change_detect() after a
        successful ChangeDetector.compare(). Publishes the change
        magnitude and region count to the hive bus so it's visible
        in the collective log, and pushes into Tartarus 'patterns'
        for cross-domain synthesis — e.g. Tartarus phase 5 omnisense
        can correlate change-detection events with AEGIS threat scores
        from the same time window to identify operationally significant
        co-occurrences without explicit rules.
        """
        self._pub.publish(self.SOURCE, "drone_change_detected", {
            "mission_id":           mission_id,
            "change_magnitude_pct": result.get("change_magnitude_pct"),
            "changed_region_count": result.get("changed_region_count"),
            "note":                 result.get("note"),
            "ts":                   time.time(),
        })

        self._tart.push("patterns", {
            "type":                 "drone_change_detection",
            "mission_id":          mission_id,
            "change_magnitude_pct": result.get("change_magnitude_pct"),
            "changed_region_count": result.get("changed_region_count"),
        }, source=self.SOURCE)

    # ── Coverage quality ──────────────────────────────────────────────────────

    def publish_coverage_score(self, mission_id: str, result: Dict[str, Any]) -> None:
        """
        Called by zeus_drone_blueprint.api_coverage_score(). Pushes
        coverage quality into Tartarus 'learning_steps' field so the
        11-step learning engine treats coverage gaps as training signal
        for future mission planning optimisation.
        """
        self._pub.publish(self.SOURCE, "drone_coverage_scored", {
            "mission_id":    mission_id,
            "coverage_pct":  result.get("coverage_pct"),
            "quality_flag":  result.get("quality_flag"),
            "gap_cell_count": result.get("gap_cell_count"),
            "ts":            time.time(),
        })

        self._tart.push("learning_steps", {
            "type":          "drone_coverage_qa",
            "mission_id":    mission_id,
            "coverage_pct":  result.get("coverage_pct"),
            "quality_flag":  result.get("quality_flag"),
            "gap_cells":     result.get("gap_cell_count"),
            "lesson":        (
                "Coverage gap detected — consider reducing swath_width_m or "
                "increasing flight altitude for wider footprint"
                if result.get("gap_cell_count", 0) > 5 else
                "Coverage within acceptable parameters"
            ),
        }, source=self.SOURCE)


# ── Singleton ─────────────────────────────────────────────────────────────────

_wire_singleton: Optional[DroneHiveWire] = None
_wire_lock = threading.Lock()


def get_wire() -> DroneHiveWire:
    global _wire_singleton
    if _wire_singleton is not None:
        return _wire_singleton
    with _wire_lock:
        if _wire_singleton is None:
            _wire_singleton = DroneHiveWire()
            log.info("[drone_hive_wire] DroneHiveWire initialised — "
                     "drone observations will flow into Hive + Tartarus")
    return _wire_singleton
