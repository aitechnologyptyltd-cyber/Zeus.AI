# The Zeus Project 2026 — Francois Nel
# zeus_clickup_bridge.py — ClickUp REST API Bridge v1.0
# =============================================================
#
# Follows the same pattern as zeus_grok_bridge.py / zeus_deepseek_bridge.py /
# zeus_perplexity_bridge.py: circuit breaker, Flask blueprint, register(app).
#
# This is an ADDITIVE module — new agent, new file, new routes. Nothing in
# the existing 13-agent swarm, app.py's prior layers, or any other bridge
# is modified or removed to add this.
#
# ClickUp's REST API (v2, base https://api.clickup.com/api/v2) is a plain
# REST API, not OpenAI-compatible, so this uses stdlib urllib.request —
# same choice already made for zeus_llm_router.py's openrouter/ollama calls
# — rather than adding a new third-party HTTP dependency for one module.
#
# Auth: personal token, plain string in the Authorization header —
# ClickUp does NOT use a "Bearer " prefix (unlike almost every other API
# this codebase talks to). Confirmed against ClickUp's own docs.
#
# API key: CLICKUP_API_TOKEN in .env (optional — see engine_availability()
# equivalent below; every route degrades to a clean 503 if unset, same
# as XAI_API_KEY / DEEPSEEK_API_KEY / PERPLEXITY_API_KEY do in their
# bridges, never a crash).
#
# Rate limits (per ClickUp docs): 100 req/min on Free/Unlimited/Business,
# 1000/min Business Plus, 10000/min Enterprise. On 429, this bridge respects
# the Retry-After header before its single built-in retry.
#
# Swarm: owned by the new "Hecate" agent (crossroads/threshold goddess —
# gateway to an external system) in zeus_swarm_orchestrator.py.
# =============================================================

from __future__ import annotations

import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.clickup")

clickup_bp = Blueprint("clickup_bridge", __name__)

CLICKUP_API_TOKEN = os.environ.get("CLICKUP_API_TOKEN", "")
CLICKUP_API_BASE  = os.environ.get("CLICKUP_API_BASE", "https://api.clickup.com/api/v2")
CLICKUP_TEAM_ID   = os.environ.get("CLICKUP_TEAM_ID", "")  # optional, auto-discovered if blank
DEFAULT_TIMEOUT   = 30


# ─── CIRCUIT BREAKER (same shape as the other three bridges) ────────────────

class ClickUpCircuitBreaker:
    def __init__(self, failure_threshold: int = 4, cooldown_s: float = 60.0):
        self._threshold  = failure_threshold
        self._cooldown   = cooldown_s
        self._failures   = 0
        self._tripped_at: Optional[float] = None
        self._lock       = threading.Lock()

    def allow(self) -> bool:
        with self._lock:
            if self._tripped_at is None:
                return True
            if time.time() - self._tripped_at >= self._cooldown:
                self._failures   = 0
                self._tripped_at = None
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            self._failures   = 0
            self._tripped_at = None

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._tripped_at = time.time()
                log.warning("[clickup] Circuit breaker OPEN (%d failures)", self._failures)

    def state(self) -> str:
        with self._lock:
            if self._tripped_at is None:
                return "CLOSED"
            if time.time() - self._tripped_at >= self._cooldown:
                return "HALF_OPEN"
            return "OPEN"


@dataclass
class ClickUpStats:
    total_calls: int = 0
    successes: int = 0
    failures: int = 0
    rate_limited: int = 0
    last_error: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_calls": self.total_calls,
            "successes": self.successes,
            "failures": self.failures,
            "rate_limited": self.rate_limited,
            "last_error": self.last_error,
        }


# ─── CLIENT ──────────────────────────────────────────────────────────────────

class ClickUpClient:
    """
    Thin REST client over ClickUp API v2. Six core operations, matching the
    standard "hero tools" set for agent/task orchestration: list tasks,
    create task, get task, update task, add comment, list teams/spaces/lists
    for navigation. Every method returns a plain dict; on failure returns
    {"error": "..."} rather than raising, so a caller (Flask route or another
    Zeus module) never has to wrap every call in try/except — consistent
    with the graceful-degradation pattern already used elsewhere in Zeus
    (see zeus_hive_bridge.py, zeus_llm_router.py's offline engine).
    """

    def __init__(self):
        self._cb = ClickUpCircuitBreaker()
        self._stats = ClickUpStats()
        self._lock = threading.Lock()
        self._team_id_cache: Optional[str] = CLICKUP_TEAM_ID or None

    # ---- low-level request ------------------------------------------------

    def _request(self, method: str, path: str, body: Optional[dict] = None,
                  params: Optional[dict] = None, retries: int = 1) -> Dict[str, Any]:
        if not CLICKUP_API_TOKEN:
            return {"error": "CLICKUP_API_TOKEN not configured", "configured": False}

        if not self._cb.allow():
            return {"error": f"ClickUp circuit breaker OPEN (cooldown in progress)"}

        url = f"{CLICKUP_API_BASE}{path}"
        if params:
            query = "&".join(f"{k}={urllib.request.quote(str(v))}" for k, v in params.items() if v is not None)
            if query:
                url = f"{url}?{query}"

        data = json.dumps(body).encode() if body is not None else None
        headers = {
            # NOT "Bearer <token>" — ClickUp wants the raw token string.
            "Authorization": CLICKUP_API_TOKEN,
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        with self._lock:
            self._stats.total_calls += 1

        for attempt in range(retries + 1):
            try:
                with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
                    raw = resp.read()
                    result = json.loads(raw) if raw else {}
                    self._cb.record_success()
                    with self._lock:
                        self._stats.successes += 1
                    return result
            except urllib.error.HTTPError as e:
                body_text = ""
                try:
                    body_text = e.read().decode(errors="ignore")
                except Exception:
                    pass
                if e.code == 429:
                    with self._lock:
                        self._stats.rate_limited += 1
                    retry_after = float(e.headers.get("Retry-After", "2")) if e.headers else 2.0
                    log.warning(f"[clickup] 429 rate limited — waiting {retry_after}s")
                    if attempt < retries:
                        time.sleep(retry_after)
                        continue
                self._cb.record_failure()
                with self._lock:
                    self._stats.failures += 1
                    self._stats.last_error = f"HTTP {e.code}: {body_text[:200]}"
                return {"error": f"ClickUp API HTTP {e.code}", "detail": body_text[:300]}
            except Exception as e:
                self._cb.record_failure()
                with self._lock:
                    self._stats.failures += 1
                    self._stats.last_error = str(e)[:200]
                if attempt < retries:
                    time.sleep(1)
                    continue
                return {"error": f"ClickUp request failed: {e}"}

        return {"error": "ClickUp request exhausted retries"}

    # ---- navigation ---------------------------------------------------------

    def get_teams(self) -> Dict[str, Any]:
        """GET /team — list workspaces (called 'teams' in ClickUp's API)."""
        return self._request("GET", "/team")

    def resolve_team_id(self) -> Optional[str]:
        """Returns the cached/configured team_id, or auto-discovers the
        first available one via get_teams()."""
        if self._team_id_cache:
            return self._team_id_cache
        result = self.get_teams()
        teams = result.get("teams", [])
        if teams:
            self._team_id_cache = teams[0].get("id")
            return self._team_id_cache
        return None

    def get_spaces(self, team_id: Optional[str] = None) -> Dict[str, Any]:
        tid = team_id or self.resolve_team_id()
        if not tid:
            return {"error": "no team_id available (set CLICKUP_TEAM_ID or ensure get_teams() succeeds)"}
        return self._request("GET", f"/team/{tid}/space")

    def get_lists(self, folder_id: Optional[str] = None, space_id: Optional[str] = None) -> Dict[str, Any]:
        if folder_id:
            return self._request("GET", f"/folder/{folder_id}/list")
        if space_id:
            return self._request("GET", f"/space/{space_id}/list", params={"archived": "false"})
        return {"error": "provide folder_id or space_id"}

    # ---- tasks (the core "hero tools") --------------------------------------

    def list_tasks(self, list_id: str, include_closed: bool = False) -> Dict[str, Any]:
        """GET /list/{list_id}/task — the primary discovery mechanism."""
        return self._request("GET", f"/list/{list_id}/task",
                              params={"include_closed": str(include_closed).lower()})

    def get_task(self, task_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/task/{task_id}")

    def create_task(self, list_id: str, name: str, description: str = "",
                     priority: Optional[int] = None, assignees: Optional[List[int]] = None,
                     due_date_ms: Optional[int] = None,
                     custom_fields: Optional[List[dict]] = None) -> Dict[str, Any]:
        """POST /list/{list_id}/task — priority: 1=urgent 2=high 3=normal 4=low."""
        body: Dict[str, Any] = {"name": name, "description": description}
        if priority is not None:
            body["priority"] = priority
        if assignees:
            body["assignees"] = assignees
        if due_date_ms is not None:
            body["due_date"] = due_date_ms
        if custom_fields:
            body["custom_fields"] = custom_fields
        return self._request("POST", f"/list/{list_id}/task", body=body)

    def update_task(self, task_id: str, **fields) -> Dict[str, Any]:
        """PUT /task/{task_id} — pass any of name/description/status/priority/
        assignees(add/rem)/due_date as kwargs."""
        return self._request("PUT", f"/task/{task_id}", body=fields)

    def add_comment(self, task_id: str, comment_text: str,
                     notify_all: bool = False) -> Dict[str, Any]:
        return self._request("POST", f"/task/{task_id}/comment", body={
            "comment_text": comment_text,
            "notify_all": notify_all,
        })

    # ---- status ---------------------------------------------------------

    def is_configured(self) -> bool:
        return bool(CLICKUP_API_TOKEN)

    def stats(self) -> Dict[str, Any]:
        return {
            "configured": self.is_configured(),
            "circuit": self._cb.state(),
            "team_id_cached": self._team_id_cache,
            **self._stats.to_dict(),
        }


# ─── SINGLETON ────────────────────────────────────────────────────────────────

_client_lock = threading.Lock()
_client_instance: Optional[ClickUpClient] = None


def get_client() -> ClickUpClient:
    global _client_instance
    with _client_lock:
        if _client_instance is None:
            _client_instance = ClickUpClient()
        return _client_instance


# ─── FLASK ROUTES — /api/clickup/* ─────────────────────────────────────────
# Every route degrades to a clean JSON error (never a 500 crash) if
# CLICKUP_API_TOKEN isn't set — same contract as zeus_grok_bridge.py's
# routes when XAI_API_KEY is missing.

@clickup_bp.route("/api/clickup/health", methods=["GET"])
def http_health():
    client = get_client()
    return jsonify(client.stats())


@clickup_bp.route("/api/clickup/teams", methods=["GET"])
def http_teams():
    client = get_client()
    if not client.is_configured():
        return jsonify({"error": "CLICKUP_API_TOKEN not configured"}), 503
    return jsonify(client.get_teams())


@clickup_bp.route("/api/clickup/spaces", methods=["GET"])
def http_spaces():
    client = get_client()
    if not client.is_configured():
        return jsonify({"error": "CLICKUP_API_TOKEN not configured"}), 503
    team_id = request.args.get("team_id")
    return jsonify(client.get_spaces(team_id))


@clickup_bp.route("/api/clickup/lists/<list_id>/tasks", methods=["GET"])
def http_list_tasks(list_id):
    client = get_client()
    if not client.is_configured():
        return jsonify({"error": "CLICKUP_API_TOKEN not configured"}), 503
    include_closed = request.args.get("include_closed", "false").lower() == "true"
    return jsonify(client.list_tasks(list_id, include_closed))


@clickup_bp.route("/api/clickup/lists/<list_id>/tasks", methods=["POST"])
def http_create_task(list_id):
    client = get_client()
    if not client.is_configured():
        return jsonify({"error": "CLICKUP_API_TOKEN not configured"}), 503
    body = request.get_json(force=True, silent=True) or {}
    name = body.get("name")
    if not name:
        return jsonify({"error": "'name' is required"}), 400
    result = client.create_task(
        list_id, name=name,
        description=body.get("description", ""),
        priority=body.get("priority"),
        assignees=body.get("assignees"),
        due_date_ms=body.get("due_date_ms"),
        custom_fields=body.get("custom_fields"),
    )
    status_code = 201 if "error" not in result else 502
    return jsonify(result), status_code


@clickup_bp.route("/api/clickup/tasks/<task_id>", methods=["GET"])
def http_get_task(task_id):
    client = get_client()
    if not client.is_configured():
        return jsonify({"error": "CLICKUP_API_TOKEN not configured"}), 503
    return jsonify(client.get_task(task_id))


@clickup_bp.route("/api/clickup/tasks/<task_id>", methods=["PUT"])
def http_update_task(task_id):
    client = get_client()
    if not client.is_configured():
        return jsonify({"error": "CLICKUP_API_TOKEN not configured"}), 503
    body = request.get_json(force=True, silent=True) or {}
    result = client.update_task(task_id, **body)
    status_code = 200 if "error" not in result else 502
    return jsonify(result), status_code


@clickup_bp.route("/api/clickup/tasks/<task_id>/comment", methods=["POST"])
def http_add_comment(task_id):
    client = get_client()
    if not client.is_configured():
        return jsonify({"error": "CLICKUP_API_TOKEN not configured"}), 503
    body = request.get_json(force=True, silent=True) or {}
    text = body.get("comment_text")
    if not text:
        return jsonify({"error": "'comment_text' is required"}), 400
    result = client.add_comment(task_id, text, notify_all=body.get("notify_all", False))
    status_code = 200 if "error" not in result else 502
    return jsonify(result), status_code


# ─── REGISTRATION — fits app.py's _register_fn(module_name) convention ─────

def register(app) -> None:
    app.register_blueprint(clickup_bp)
    log.info(f"[clickup] registered — configured={bool(CLICKUP_API_TOKEN)}, "
             f"base={CLICKUP_API_BASE}")
