# The Zeus Project 2026 — Francois Nel
# zeus_search.py — Unified Search Engine + Autonomous Harvesting System
# DuckDuckGo · SerpAPI fallback · AI synthesis · Semantic ranking
# Logic Engine integration · Result caching · Knowledge save-back
# ── EXPANSION ──────────────────────────────────────────────────────────────
# Unified Harvesting System integrated (non-destructive expansion):
#   WebHarvester · GoogleSearchEngine · AdaptiveLearningEngine
#   HarvestCodeGenerator · HarvestDatabase · HarvestCodeAnalyzer
#   activate_harvesting() added to UnifiedSearchEngine
#   search() gains use_harvest parameter → queries harvested-code DB

import os
import re
import ast
import sys
import time
import json
import math
import uuid
import queue
import random
import logging
import hashlib
import sqlite3
import requests
import threading
import statistics
import subprocess
import tempfile
from collections import Counter, deque, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.search")

search_bp = Blueprint("search", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================================
# RESULT CACHE
# ============================================================================

@dataclass
class CacheEntry:
    query:      str
    results:    List[Dict]
    source:     str
    created_at: float = field(default_factory=time.time)
    hit_count:  int   = 0
    ttl_s:      float = 300.0

    def is_fresh(self) -> bool:
        return (time.time() - self.created_at) < self.ttl_s


class SearchCache:
    """LRU cache for search results. Thread-safe."""

    def __init__(self, max_size: int = 200):
        self._lock   = threading.RLock()
        self._store: Dict[str, CacheEntry] = {}
        self._max    = max_size
        self._hits   = 0
        self._misses = 0

    def _key(self, query: str) -> str:
        return hashlib.md5(query.lower().strip().encode()).hexdigest()

    def get(self, query: str) -> Optional[List[Dict]]:
        k = self._key(query)
        with self._lock:
            entry = self._store.get(k)
            if entry and entry.is_fresh():
                entry.hit_count += 1
                self._hits += 1
                return entry.results
            elif entry:
                del self._store[k]
            self._misses += 1
            return None

    def set(self, query: str, results: List[Dict],
            source: str = "", ttl_s: float = 300.0) -> None:
        k = self._key(query)
        with self._lock:
            if len(self._store) >= self._max:
                oldest = min(self._store.items(), key=lambda x: x[1].created_at)
                del self._store[oldest[0]]
            self._store[k] = CacheEntry(query=query, results=results,
                                          source=source, ttl_s=ttl_s)

    def stats(self) -> Dict:
        with self._lock:
            fresh = sum(1 for e in self._store.values() if e.is_fresh())
            return {
                "size":     len(self._store),
                "fresh":    fresh,
                "hits":     self._hits,
                "misses":   self._misses,
                "hit_rate": round(self._hits / max(self._hits + self._misses, 1), 4),
            }

    def clear(self) -> int:
        with self._lock:
            n = len(self._store)
            self._store.clear()
            return n


# ============================================================================
# RESULT RANKER
# ============================================================================

class ResultRanker:
    """TF-IDF cosine similarity re-ranker."""

    STOP_WORDS = {
        "the","and","for","with","that","this","from","into","have","what",
        "how","why","can","are","was","but","not","been","they","will",
        "which","when","who","would","could","should","may","might","must",
    }

    def _tokenize(self, text: str) -> List[str]:
        tokens = re.findall(r'\b[a-z][a-z0-9_]{2,}\b', text.lower())
        return [t for t in tokens if t not in self.STOP_WORDS]

    def _tf(self, tokens: List[str]) -> Dict[str, float]:
        if not tokens:
            return {}
        freq  = Counter(tokens)
        total = len(tokens)
        return {t: c / total for t, c in freq.items()}

    def _cosine(self, vec_a: Dict[str, float], vec_b: Dict[str, float]) -> float:
        common = set(vec_a) & set(vec_b)
        if not common:
            return 0.0
        dot = sum(vec_a[t] * vec_b[t] for t in common)
        na  = math.sqrt(sum(v*v for v in vec_a.values()))
        nb  = math.sqrt(sum(v*v for v in vec_b.values()))
        return dot / (na * nb) if na and nb else 0.0

    def rank(self, query: str, results: List[Dict],
              boost_recent: bool = False) -> List[Dict]:
        if not results:
            return results
        q_tokens = self._tokenize(query)
        q_tf     = self._tf(q_tokens)
        ranked   = []
        for i, r in enumerate(results):
            text  = f"{r.get('title','')} {r.get('snippet','')}"
            r_tf  = self._tf(self._tokenize(text))
            score = self._cosine(q_tf, r_tf)
            title_lower = r.get("title", "").lower()
            for qw in q_tokens[:5]:
                if qw in title_lower:
                    score += 0.05
            score -= i * 0.01
            r["relevance_score"] = round(score, 4)
            ranked.append(r)
        ranked.sort(key=lambda x: -x["relevance_score"])
        return ranked


# ============================================================================
# SEARCH ENGINES (original)
# ============================================================================

class DDGEngine:
    """DuckDuckGo search — no quota, no API key needed. PRIMARY web engine."""

    _last_fail: float = 0.0
    _COOLDOWN:  float = 30.0

    @classmethod
    def search(cls, query: str, max_results: int = 8) -> List[Dict]:
        if time.time() - cls._last_fail < cls._COOLDOWN:
            log.debug("[Search:DDG] In cooldown — skipping")
            return []
        try:
            from ddgs import DDGS
            results = []
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=max_results):
                    results.append({
                        "title":   r.get("title", ""),
                        "url":     r.get("href", ""),
                        "snippet": r.get("body", "")[:500],
                        "source":  "ddg",
                    })
            log.info(f"[Search:DDG] '{query[:50]}' → {len(results)} results")
            return results
        except Exception as e:
            cls._last_fail = time.time()
            log.warning(f"[Search:DDG] Failed: {e}")
            return []


# ── FALLBACK 1 — Grok (xAI) web search ──────────────────────────────────────

class GrokSearchEngine:
    """
    Grok (xAI) web search fallback.
    Uses zeus_grok_bridge if available, else calls xAI REST directly.
    Activates when DDG fails or returns zero results.
    """

    _last_fail: float = 0.0
    _COOLDOWN:  float = 120.0   # longer cooldown — quota is limited

    @classmethod
    def search(cls, query: str, max_results: int = 8) -> List[Dict]:
        if time.time() - cls._last_fail < cls._COOLDOWN:
            log.debug("[Search:Grok] In cooldown")
            return []
        api_key = os.environ.get("XAI_API_KEY", "")
        if not api_key:
            log.debug("[Search:Grok] XAI_API_KEY not set — skipping")
            return []
        try:
            # Try grok bridge first
            try:
                from zeus_grok_bridge import ask_grok
                answer = ask_grok(
                    f"Web search results for: {query}\n"
                    f"Return a JSON array of {max_results} results, each with keys: "
                    f"title, url, snippet. Return ONLY the JSON array.",
                    max_tokens=1024,
                )
                data = json.loads(
                    re.sub(r"```(?:json)?", "", answer).strip().rstrip("```")
                )
                if isinstance(data, list):
                    results = []
                    for r in data[:max_results]:
                        if isinstance(r, dict):
                            results.append({
                                "title":   r.get("title", ""),
                                "url":     r.get("url", ""),
                                "snippet": r.get("snippet", "")[:500],
                                "source":  "grok",
                            })
                    if results:
                        log.info(f"[Search:Grok] '{query[:50]}' → {len(results)} results")
                        return results
            except Exception as bridge_err:
                log.debug(f"[Search:Grok] Bridge error: {bridge_err}")

            # Direct xAI REST call
            resp = requests.post(
                "https://api.x.ai/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}",
                         "Content-Type": "application/json"},
                json={
                    "model": "grok-3",
                    "messages": [{
                        "role": "user",
                        "content": (
                            f"Search the web for: {query}\n"
                            f"Return a JSON array of up to {max_results} results. "
                            f"Each result must have: title (string), url (string), "
                            f"snippet (string). Return ONLY the JSON array, no markdown."
                        )
                    }],
                    "max_tokens": 1024,
                    "temperature": 0.1,
                },
                timeout=20,
            )
            if resp.status_code == 200:
                raw = resp.json()["choices"][0]["message"]["content"].strip()
                raw = re.sub(r"```(?:json)?", "", raw).strip().rstrip("```")
                data = json.loads(raw)
                if isinstance(data, list):
                    results = [{
                        "title":   r.get("title", ""),
                        "url":     r.get("url", ""),
                        "snippet": r.get("snippet", "")[:500],
                        "source":  "grok",
                    } for r in data[:max_results] if isinstance(r, dict)]
                    log.info(f"[Search:Grok] REST '{query[:50]}' → {len(results)} results")
                    return results
            elif resp.status_code in (429, 402):
                log.warning(f"[Search:Grok] Rate/quota limited ({resp.status_code}) → triggering cooldown")
                cls._last_fail = time.time()
            else:
                log.warning(f"[Search:Grok] HTTP {resp.status_code}")
        except Exception as e:
            cls._last_fail = time.time()
            log.warning(f"[Search:Grok] Failed: {e}")
        return []


# ── FALLBACK 2 — Claude (Anthropic) web knowledge ────────────────────────────

class ClaudeSearchEngine:
    """
    Claude (Anthropic) knowledge search fallback.
    Uses claude-sonnet's broad training for known-topic queries.
    Activates when DDG and Grok both fail.
    """

    _last_fail: float = 0.0
    _COOLDOWN:  float = 120.0

    @classmethod
    def search(cls, query: str, max_results: int = 6) -> List[Dict]:
        if time.time() - cls._last_fail < cls._COOLDOWN:
            log.debug("[Search:Claude] In cooldown")
            return []
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            log.debug("[Search:Claude] ANTHROPIC_API_KEY not set — skipping")
            return []
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            msg = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=1024,
                messages=[{
                    "role": "user",
                    "content": (
                        f"Provide factual search results for: {query}\n"
                        f"Return a JSON array of up to {max_results} results. "
                        f"Each result must have: title (string), url (string — use a "
                        f"plausible real URL if known, else empty string), snippet "
                        f"(string — concise factual summary). "
                        f"Return ONLY the JSON array, no markdown, no explanation."
                    ),
                }],
            )
            raw = msg.content[0].text.strip()
            raw = re.sub(r"```(?:json)?", "", raw).strip().rstrip("```")
            data = json.loads(raw)
            if isinstance(data, list):
                results = [{
                    "title":   r.get("title", ""),
                    "url":     r.get("url", ""),
                    "snippet": r.get("snippet", "")[:500],
                    "source":  "claude",
                } for r in data[:max_results] if isinstance(r, dict)]
                log.info(f"[Search:Claude] '{query[:50]}' → {len(results)} results")
                return results
        except Exception as e:
            if "rate" in str(e).lower() or "quota" in str(e).lower() or "overloaded" in str(e).lower():
                cls._last_fail = time.time()
                log.warning(f"[Search:Claude] Rate-limited → cooldown: {e}")
            else:
                log.warning(f"[Search:Claude] Failed: {e}")
        return []


# ── FALLBACK 3 — Firecrawl ───────────────────────────────────────────────────

class FirecrawlEngine:
    """
    Firecrawl search API fallback.
    Requires FIRECRAWL_API_KEY environment variable.
    Activates when DDG, Grok, and Claude all fail.
    """

    _last_fail: float = 0.0
    _COOLDOWN:  float = 60.0
    _BASE_URL   = "https://api.firecrawl.dev/v1/search"

    @classmethod
    def search(cls, query: str, max_results: int = 8) -> List[Dict]:
        if time.time() - cls._last_fail < cls._COOLDOWN:
            log.debug("[Search:Firecrawl] In cooldown")
            return []
        api_key = os.environ.get("FIRECRAWL_API_KEY", "")
        if not api_key:
            log.debug("[Search:Firecrawl] FIRECRAWL_API_KEY not set — skipping")
            return []
        try:
            resp = requests.post(
                cls._BASE_URL,
                headers={"Authorization": f"Bearer {api_key}",
                         "Content-Type": "application/json"},
                json={"query": query, "limit": max_results},
                timeout=20,
            )
            if resp.status_code == 200:
                data    = resp.json()
                results = []
                for r in data.get("data", [])[:max_results]:
                    results.append({
                        "title":   r.get("title", ""),
                        "url":     r.get("url", ""),
                        "snippet": (r.get("description") or r.get("markdown", ""))[:500],
                        "source":  "firecrawl",
                    })
                log.info(f"[Search:Firecrawl] '{query[:50]}' → {len(results)} results")
                return results
            elif resp.status_code in (429, 402):
                cls._last_fail = time.time()
                log.warning(f"[Search:Firecrawl] Rate-limited ({resp.status_code}) → cooldown")
            else:
                log.warning(f"[Search:Firecrawl] HTTP {resp.status_code}")
        except Exception as e:
            cls._last_fail = time.time()
            log.warning(f"[Search:Firecrawl] Failed: {e}")
        return []


class KnowledgeEngine:
    """Search the local Zeus knowledge base."""

    def search(self, query: str, max_results: int = 10) -> List[Dict]:
        from db_init import get_db
        keywords = re.findall(r'\b[a-zA-Z][a-zA-Z0-9]{2,}\b', query)[:8]
        stop     = {"the","and","for","with","that","this","search","find","about"}
        keywords = [w for w in keywords if w.lower() not in stop]
        if not keywords:
            return []
        results = []
        seen    = set()
        try:
            conn = get_db()
            for kw in keywords[:5]:
                rows = conn.execute(
                    """SELECT topic, depth, content, confidence, source_url, created_at
                       FROM knowledge
                       WHERE topic LIKE ? OR content LIKE ?
                       ORDER BY confidence DESC, id DESC LIMIT 5""",
                    (f"%{kw}%", f"%{kw}%")
                ).fetchall()
                for row in rows:
                    key = (row["topic"], row["depth"])
                    if key in seen:
                        continue
                    seen.add(key)
                    results.append({
                        "title":      f"[K] {row['topic']} ({row['depth']})",
                        "url":        row["source_url"] or "",
                        "snippet":    (row["content"] or "")[:400],
                        "source":     "knowledge_base",
                        "confidence": float(row["confidence"] or 0.8),
                        "depth":      row["depth"],
                    })
            conn.close()
        except Exception as e:
            log.warning(f"[Search:KB] Error: {e}")
        log.info(f"[Search:KB] '{query[:50]}' → {len(results)} results")
        return results[:max_results]


class GenomeEngine:
    """Search genome segments for DNA relevant to a query."""

    def search(self, query: str, max_results: int = 6) -> List[Dict]:
        from db_init import get_db
        keywords = re.findall(r'\b[a-zA-Z][a-zA-Z0-9]{2,}\b', query)[:6]
        results  = []
        seen     = set()
        try:
            conn = get_db()
            for kw in keywords[:4]:
                rows = conn.execute(
                    """SELECT name, description, module_type, capabilities, priority
                       FROM genome
                       WHERE name LIKE ? OR description LIKE ? OR capabilities LIKE ?
                       ORDER BY priority DESC LIMIT 4""",
                    (f"%{kw}%", f"%{kw}%", f"%{kw}%")
                ).fetchall()
                for row in rows:
                    if row["name"] in seen:
                        continue
                    seen.add(row["name"])
                    results.append({
                        "title":    f"[G] {row['name']} ({row['module_type']})",
                        "url":      "",
                        "snippet":  f"{row['description'][:200]} | capabilities: {row['capabilities'][:150]}",
                        "source":   "genome",
                        "priority": int(row["priority"] or 0),
                    })
            conn.close()
        except Exception as e:
            log.warning(f"[Search:Genome] Error: {e}")
        return results[:max_results]


class LogicSemanticEngine:
    """Delegate semantic search to the logic engine's TF-IDF index."""

    def search(self, query: str, max_results: int = 10) -> List[Dict]:
        try:
            from logic_engine import get_engine
            engine  = get_engine()
            raw     = engine._semantic_idx.search(query, top_k=max_results)
            results = []
            for score, rowid, topic, snippet in raw:
                results.append({
                    "title":           f"[S] {topic}",
                    "url":             "",
                    "snippet":         snippet,
                    "source":          "logic_semantic",
                    "relevance_score": round(score, 4),
                })
            return results
        except Exception as e:
            log.debug(f"[Search:Logic] Semantic search skipped: {e}")
            return []


class AISearchEngine:
    """Synthesize a search response using the LLM router."""

    def search(self, query: str, context_results: List[Dict] = None) -> List[Dict]:
        try:
            from zeus_llm_router import call_llm
            context = ""
            if context_results:
                snippets = "\n".join(
                    f"- {r.get('title','')}: {r.get('snippet','')[:150]}"
                    for r in context_results[:5]
                )
                context = f"\n\nAvailable context:\n{snippets}"
            prompt = (
                f"You are Zeus knowledge synthesizer.\n"
                f"Query: {query}{context}\n\n"
                f"Provide a concise, technically precise answer. "
                f"Focus on facts, mechanisms, and actionable insights. "
                f"Return a single coherent paragraph (200-300 words)."
            )
            text = call_llm(prompt, max_tokens=512)
            return [{
                "title":   f"AI Synthesis: {query[:60]}",
                "url":     "",
                "snippet": text,
                "source":  "ai_synthesis",
            }]
        except Exception as e:
            log.warning(f"[Search:AI] Synthesis failed: {e}")
            return []


# ============================================================================
# HARVESTING SYSTEM — non-destructive expansion
# ============================================================================

HARVEST_TARGET_URLS = [
    "https://openai.com", "https://anthropic.com", "https://deepmind.google",
    "https://ai.meta.com", "https://cohere.com", "https://mistral.ai",
    "https://huggingface.co", "https://stability.ai", "https://ai21.com",
    "https://github.com/trending/python", "https://stackoverflow.com/questions/tagged/python",
    "https://github.com/trending/ai", "https://paperswithcode.com",
    "https://arxiv.org/list/cs.AI/recent", "https://pytorch.org/blog/",
    "https://research.google/", "https://github.com/google-deepmind",
    "https://github.com/microsoft/ai", "https://blogs.nvidia.com/blog/category/deep-learning/",
    "https://www.tensorflow.org/community",
]

HARVEST_DB_PATH = os.path.join(ZEUS_DIR, "harvest_data.db")


class HarvestDatabase:
    """Dedicated SQLite DB for harvested code. Feeds Zeus KB and genome."""

    def __init__(self, db_path: str = HARVEST_DB_PATH):
        self.db_path = db_path
        self._lock   = threading.RLock()
        self._init()
        log.info(f"[HarvestDB] Ready: {db_path}")

    def _conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        return c

    def _init(self) -> None:
        with self._lock:
            c = self._conn()
            c.executescript("""
                CREATE TABLE IF NOT EXISTS harvested_code (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT, company TEXT, code TEXT, language TEXT,
                    quality_score REAL, harvest_method TEXT DEFAULT 'web',
                    harvested_at TEXT DEFAULT (datetime('now')));
                CREATE TABLE IF NOT EXISTS harvest_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT UNIQUE, priority INTEGER DEFAULT 1,
                    status TEXT DEFAULT 'pending', attempts INTEGER DEFAULT 0);
                CREATE TABLE IF NOT EXISTS harvest_patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pattern_hash TEXT UNIQUE, pattern_type TEXT,
                    code_snippet TEXT, effectiveness_score REAL DEFAULT 0.5,
                    usage_count INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT (datetime('now')));
                CREATE TABLE IF NOT EXISTS harvest_learning (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    context_hash TEXT, action TEXT, reward REAL,
                    state TEXT, metadata TEXT,
                    timestamp TEXT DEFAULT (datetime('now')));
                CREATE TABLE IF NOT EXISTS harvest_modifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    component TEXT, description TEXT,
                    success INTEGER, generation INTEGER,
                    timestamp TEXT DEFAULT (datetime('now')));
            """)
            c.commit()
            c.close()

    def add_urls(self, urls: List[str]) -> int:
        added = 0
        with self._lock:
            c = self._conn()
            for url in urls:
                try:
                    c.execute("INSERT OR IGNORE INTO harvest_queue (url, priority) VALUES (?,10)", (url,))
                    if c.total_changes > 0:
                        added += 1
                except Exception:
                    pass
            c.commit(); c.close()
        return added

    def get_next_url(self) -> Optional[str]:
        with self._lock:
            c   = self._conn()
            row = c.execute(
                "SELECT url FROM harvest_queue WHERE status='pending' AND attempts<3 ORDER BY priority DESC LIMIT 1"
            ).fetchone()
            c.close()
        return row["url"] if row else None

    def update_harvest(self, url: str, status: str) -> None:
        with self._lock:
            c = self._conn()
            c.execute("UPDATE harvest_queue SET status=?, attempts=attempts+1 WHERE url=?", (status, url))
            c.commit(); c.close()

    def save_code(self, url: str, company: str, code: str,
                   language: str, quality: float, method: str = "web") -> None:
        with self._lock:
            c = self._conn()
            c.execute(
                "INSERT INTO harvested_code (source_url,company,code,language,quality_score,harvest_method) VALUES (?,?,?,?,?,?)",
                (url, company, code, language, quality, method)
            )
            c.commit(); c.close()

    def save_pattern(self, pattern_hash: str, pattern_type: str,
                      code_snippet: str, effectiveness: float = 0.5) -> None:
        with self._lock:
            c = self._conn()
            c.execute(
                "INSERT OR REPLACE INTO harvest_patterns (pattern_hash,pattern_type,code_snippet,effectiveness_score) VALUES (?,?,?,?)",
                (pattern_hash, pattern_type, code_snippet, effectiveness)
            )
            c.commit(); c.close()

    def save_learning_experience(self, context_hash: str, action: str,
                                   reward: float, state: str, metadata: Dict = None) -> None:
        with self._lock:
            c = self._conn()
            c.execute(
                "INSERT INTO harvest_learning (context_hash,action,reward,state,metadata) VALUES (?,?,?,?,?)",
                (context_hash, action, reward, state, json.dumps(metadata) if metadata else None)
            )
            c.commit(); c.close()

    def save_modification(self, component: str, description: str,
                           success: bool, generation: int) -> None:
        with self._lock:
            c = self._conn()
            c.execute(
                "INSERT INTO harvest_modifications (component,description,success,generation) VALUES (?,?,?,?)",
                (component, description, int(success), generation)
            )
            c.commit(); c.close()

    def search_code(self, query: str, limit: int = 10) -> List[Dict]:
        with self._lock:
            c    = self._conn()
            rows = c.execute(
                "SELECT * FROM harvested_code WHERE code LIKE ? OR company LIKE ? ORDER BY quality_score DESC LIMIT ?",
                (f"%{query}%", f"%{query}%", limit)
            ).fetchall()
            c.close()
        return [dict(r) for r in rows]

    def get_patterns(self, pattern_type: str = None, limit: int = 10) -> List[Dict]:
        with self._lock:
            c = self._conn()
            if pattern_type:
                rows = c.execute(
                    "SELECT * FROM harvest_patterns WHERE pattern_type=? ORDER BY effectiveness_score DESC LIMIT ?",
                    (pattern_type, limit)
                ).fetchall()
            else:
                rows = c.execute(
                    "SELECT * FROM harvest_patterns ORDER BY effectiveness_score DESC LIMIT ?",
                    (limit,)
                ).fetchall()
            c.close()
        return [dict(r) for r in rows]

    def statistics(self) -> Dict:
        stats = {}
        pairs = [
            ("code_blocks",         "SELECT COUNT(*) FROM harvested_code"),
            ("urls_harvested",      "SELECT COUNT(*) FROM harvest_queue WHERE status='completed'"),
            ("patterns",            "SELECT COUNT(*) FROM harvest_patterns"),
            ("learning_experiences","SELECT COUNT(*) FROM harvest_learning"),
            ("modifications",       "SELECT COUNT(*) FROM harvest_modifications WHERE success=1"),
        ]
        with self._lock:
            c = self._conn()
            for key, sql in pairs:
                try:
                    stats[key] = c.execute(sql).fetchone()[0]
                except Exception:
                    stats[key] = 0
            c.close()
        return stats


# ── GoogleSearchEngine ──────────────────────────────────────────────────────

class GoogleSearchEngine:
    """Google Custom Search API integration for the harvesting system."""

    def __init__(self, api_key: str = "", search_engine_id: str = ""):
        self.api_key          = api_key or os.environ.get("GOOGLE_API_KEY", "")
        self.search_engine_id = search_engine_id or os.environ.get("GOOGLE_SEARCH_ENGINE_ID", "")
        self.base_url         = "https://www.googleapis.com/customsearch/v1"
        self._session         = requests.Session()
        self._session.headers.update({"User-Agent": "Zeus/4.0 AIBot"})

    def search(self, query: str, num_results: int = 5) -> Dict:
        if not self.api_key or not self.search_engine_id:
            log.debug("[GoogleSearch] Not configured — skipping")
            return {"success": False, "error": "GOOGLE_API_KEY not configured"}
        params = {
            "key": self.api_key,
            "cx":  self.search_engine_id,
            "q":   query + " code example github",
            "num": min(num_results, 10),
        }
        try:
            resp = self._session.get(self.base_url, params=params, timeout=10)
            if resp.status_code == 200:
                data    = resp.json()
                results = [
                    {
                        "title":        item.get("title", ""),
                        "link":         item.get("link", ""),
                        "snippet":      item.get("snippet", ""),
                        "display_link": item.get("displayLink", ""),
                    }
                    for item in data.get("items", [])
                ]
                log.info(f"[GoogleSearch] '{query[:50]}' → {len(results)} results")
                return {"success": True, "results": results}
            return {"success": False, "error": f"HTTP {resp.status_code}"}
        except Exception as e:
            return {"success": False, "error": str(e)}


# ── WebHarvester ─────────────────────────────────────────────────────────────

class WebHarvester:
    """Autonomous web harvester — extracts code blocks, feeds Zeus KB."""

    CODE_PATTERNS = [
        (r'```python\s*\n(.*?)```',     "python",     0.90),
        (r'```javascript\s*\n(.*?)```', "javascript",  0.90),
        (r'```java\s*\n(.*?)```',       "java",        0.85),
        (r'```kotlin\s*\n(.*?)```',     "kotlin",      0.85),
        (r'```rust\s*\n(.*?)```',       "rust",        0.85),
        (r'```go\s*\n(.*?)```',         "go",          0.80),
        (r'```cpp\s*\n(.*?)```',        "cpp",         0.80),
        (r'```\s*\n(.*?)```',           "unknown",     0.50),
    ]

    def __init__(self, harvest_db: HarvestDatabase):
        self.db           = harvest_db
        self._session     = requests.Session()
        self._session.headers.update({"User-Agent": "Mozilla/5.0 (compatible; ZeusAIBot/4.0)"})
        self._total_blocks = 0
        self._total_urls   = 0
        self._failed_urls  = 0

    def harvest_url(self, url: str) -> Dict:
        """Harvest one URL and feed high-quality code into Zeus KB."""
        log.info(f"[Harvester] Harvesting: {url}")
        self.db.update_harvest(url, "in_progress")
        try:
            resp = self._session.get(url, timeout=15, allow_redirects=True)
            if resp.status_code != 200:
                self.db.update_harvest(url, "failed")
                self._failed_urls += 1
                return {"success": False, "error": f"HTTP {resp.status_code}"}

            blocks  = self._extract_code(resp.text)
            company = self._company_from_url(url)
            saved   = 0
            for block in blocks:
                if len(block["code"]) < 30:
                    continue
                try:
                    self.db.save_code(url, company, block["code"],
                                       block["lang"], block["quality"])
                    saved += 1
                    self._total_blocks += 1
                    if block["quality"] >= 0.80:
                        self._feed_to_zeus_kb(url, company, block)
                except Exception:
                    pass

            self.db.update_harvest(url, "completed")
            self._total_urls += 1
            log.info(f"[Harvester] ✓ {url} → {saved} blocks")
            return {"success": True, "blocks": saved, "url": url, "company": company}

        except Exception as e:
            self.db.update_harvest(url, "failed")
            self._failed_urls += 1
            log.warning(f"[Harvester] ✗ {url}: {e}")
            return {"success": False, "error": str(e)}

    def harvest_batch(self, max_urls: int = 5) -> Dict:
        """Harvest the next N pending URLs from the queue."""
        harvested = 0; failed = 0; count = 0
        while count < max_urls:
            url = self.db.get_next_url()
            if not url:
                break
            result = self.harvest_url(url)
            if result["success"]:
                harvested += 1
            else:
                failed += 1
            count += 1
            time.sleep(1.0)
        return {
            "total":        count,
            "successful":   harvested,
            "failed":       failed,
            "total_blocks": self._total_blocks,
        }

    def _extract_code(self, html: str) -> List[Dict]:
        blocks = []
        for pattern, lang, quality in self.CODE_PATTERNS:
            for match in re.findall(pattern, html, re.DOTALL | re.IGNORECASE):
                code = match.strip()
                if len(code) >= 30:
                    blocks.append({"code": code, "lang": lang, "quality": quality})
        return blocks

    def _company_from_url(self, url: str) -> str:
        try:
            domain = url.replace("https://","").replace("http://","").split("/")[0]
            return domain.replace("www.","").split(".")[0].title()
        except Exception:
            return "Unknown"

    def _feed_to_zeus_kb(self, url: str, company: str, block: Dict) -> None:
        try:
            from db_init import get_db
            topic   = f"Harvested {block['lang'].title()} code from {company}"
            content = f"Source: {url}\n\n```{block['lang']}\n{block['code'][:2000]}\n```"
            conn    = get_db()
            conn.execute(
                """INSERT OR IGNORE INTO knowledge
                   (topic, depth, content, source_url, confidence, domain)
                   VALUES (?, 'Simple', ?, ?, ?, 'harvested_code')""",
                (topic[:200], content[:8080], url, block["quality"])
            )
            conn.commit(); conn.close()
        except Exception as e:
            log.debug(f"[Harvester] KB feed failed: {e}")

    def stats(self) -> Dict:
        return {
            "total_urls_processed": self._total_urls,
            "total_blocks_saved":   self._total_blocks,
            "failed_urls":          self._failed_urls,
        }


# ── HarvestCodeAnalyzer ──────────────────────────────────────────────────────

class HarvestCodeAnalyzer:
    """Multi-metric code analysis for harvested code."""

    def analyze(self, code: str) -> Dict:
        try:
            tree = ast.parse(code)
            return {
                "success": True,
                "metrics": {
                    "lines":                 len(code.splitlines()),
                    "characters":            len(code),
                    "cyclomatic_complexity": self._complexity(tree),
                    "functions":             self._count(tree, ast.FunctionDef),
                    "classes":               self._count(tree, ast.ClassDef),
                    "imports":               self._count(tree, (ast.Import, ast.ImportFrom)),
                    "issues":                self._find_issues(tree),
                },
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _complexity(self, tree: ast.AST) -> int:
        n = 1
        for node in ast.walk(tree):
            if isinstance(node, (ast.If, ast.While, ast.For, ast.Try, ast.ExceptHandler, ast.With)):
                n += 1
        return n

    def _count(self, tree: ast.AST, node_type) -> int:
        return sum(1 for n in ast.walk(tree) if isinstance(n, node_type))

    def _find_issues(self, tree: ast.AST) -> List[str]:
        issues = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler) and node.type is None:
                issues.append("Bare except clause")
        return issues

    def generate_report(self, code: str) -> str:
        result = self.analyze(code)
        if not result["success"]:
            return f"Analysis failed: {result.get('error')}"
        m = result["metrics"]
        return (
            f"Code Analysis: lines={m['lines']}, "
            f"complexity={m['cyclomatic_complexity']}, "
            f"functions={m['functions']}, "
            f"classes={m['classes']}, "
            f"imports={m['imports']}"
            + (f", issues={m['issues']}" if m["issues"] else "")
        )


# ── AdaptiveLearningEngine ───────────────────────────────────────────────────

class AdaptiveLearningEngine:
    """Reinforcement-learning engine integrated with the harvesting system."""

    def __init__(self, harvest_db: HarvestDatabase,
                  google_search: GoogleSearchEngine):
        self.db               = harvest_db
        self.google_search    = google_search
        self.learning_rate    = 0.10
        self.exploration_rate = 0.30
        self._history: List[Dict] = []

    def learn_from_experience(self, context: Dict, action: str, reward: float) -> None:
        ctx_hash = hashlib.md5(json.dumps(context, sort_keys=True).encode()).hexdigest()
        self.db.save_learning_experience(ctx_hash, action, reward, json.dumps(context),
                                          {"learning_rate": self.learning_rate})
        if reward > 0:
            self.exploration_rate = max(0.10, self.exploration_rate * 0.95)
        else:
            self.exploration_rate = min(0.80, self.exploration_rate * 1.05)
        self._history.append({"action": action, "reward": reward,
                               "timestamp": datetime.now(timezone.utc).isoformat()})

    def search_and_learn(self, query: str) -> Dict:
        log.info(f"[AdaptiveLearning] Search & learn: {query}")
        result = self.google_search.search(query)
        if not result.get("success"):
            return {"success": False, "error": result.get("error")}
        patterns_found = 0
        for item in result.get("results", []):
            pattern_hash = hashlib.md5(item["link"].encode()).hexdigest()
            self.db.save_pattern(pattern_hash, "internet_discovered",
                                  item["snippet"], 0.70)
            patterns_found += 1
            self._feed_to_zeus_kb(query, item)
        self.learn_from_experience({"query": query}, "internet_search",
                                    patterns_found * 0.10)
        return {"success": True, "patterns_found": patterns_found, "query": query}

    def _feed_to_zeus_kb(self, query: str, item: Dict) -> None:
        try:
            from db_init import get_db
            topic   = f"Web pattern: {query[:100]}"
            content = f"Source: {item.get('link','')}\n{item.get('snippet','')}"
            conn    = get_db()
            conn.execute(
                """INSERT OR IGNORE INTO knowledge
                   (topic, depth, content, source_url, confidence, domain)
                   VALUES (?, 'Simple', ?, ?, 0.65, 'adaptive_learning')""",
                (topic[:200], content[:3000], item.get("link",""))
            )
            conn.commit(); conn.close()
        except Exception as e:
            log.debug(f"[AdaptiveLearning] KB feed failed: {e}")

    def get_stats(self) -> Dict:
        return {
            "learning_rate":     self.learning_rate,
            "exploration_rate":  self.exploration_rate,
            "total_experiences": len(self._history),
            "avg_reward":        statistics.mean([h["reward"] for h in self._history])
                                 if self._history else 0.0,
        }


# ── HarvestCodeGenerator ─────────────────────────────────────────────────────

class HarvestCodeGenerator:
    """Generate improvements from harvested patterns; feed into Zeus genome."""

    def __init__(self, harvest_db: HarvestDatabase,
                  learning_engine: Optional[AdaptiveLearningEngine] = None):
        self.db              = harvest_db
        self.learning_engine = learning_engine
        self.generation      = 1

    def generate_improvement(self, analysis: Dict, context: Dict) -> Dict:
        func_name = context.get("function_name", "improved_function")
        patterns  = self.db.search_code(func_name, limit=3)
        if patterns and self.learning_engine:
            code       = self._synthesize(patterns, context)
            source     = "learned_patterns"
            confidence = 0.80
        else:
            code       = self._template(context)
            source     = "template"
            confidence = 0.50
        return {"code": code, "source": source, "confidence": confidence,
                "generation": self.generation,
                "timestamp": datetime.now(timezone.utc).isoformat()}

    def _synthesize(self, patterns: List[Dict], context: Dict) -> str:
        func_name = context.get("function_name", "improved_function")
        return (
            f"def {func_name}(*args, **kwargs):\n"
            f'    """Synthesized from {len(patterns)} harvested patterns.\n'
            f"    # The Zeus Project 2026 — Francois Nel\n"
            f'    """\n'
            f"    result = None\n"
            f"    return result\n"
        )

    def _template(self, context: Dict) -> str:
        func_name = context.get("function_name", "improved_function")
        return (
            f"def {func_name}(*args, **kwargs):\n"
            f'    """Generated by Zeus HarvestCodeGenerator — The Zeus Project 2026"""\n'
            f"    pass\n"
        )

    def evolve_capability(self, name: str, description: str) -> Dict:
        safe_name = re.sub(r'[^a-z0-9_]', '_', name.lower().replace(' ', '_'))
        code = (
            f"def {safe_name}(*args, **kwargs):\n"
            f'    """{description}\n'
            f"    Generation {self.generation}\n"
            f"    # The Zeus Project 2026 — Francois Nel\n"
            f'    """\n'
            f"    return {{'success': True, 'generation': {self.generation}}}\n"
        )
        self.db.save_modification(name, description, True, self.generation)
        self.generation += 1
        try:
            from genome_manager import get_genome_engine
            get_genome_engine().add(
                name=f"evolved_cap:{safe_name}",
                description=description,
                module_type="evolved_capability",
                source_code=code,
                version=f"gen{self.generation}",
                priority=60,
                capabilities=name,
            )
        except Exception as e:
            log.debug(f"[HarvestGen] Genome registration skipped: {e}")
        return {"success": True, "code": code, "generation": self.generation}


# ── HarvestEngine ─────────────────────────────────────────────────────────────

class HarvestEngine:
    """Master orchestrator for autonomous harvesting."""

    _TOPICS = [
        "python optimization techniques",
        "machine learning code patterns",
        "algorithm implementations python",
        "AI architecture patterns",
        "neural network implementations",
        "reinforcement learning code",
        "data processing pipelines python",
        "code improvements best practices",
    ]

    def __init__(self, google_api_key: str = "", google_cx: str = ""):
        self._lock     = threading.RLock()
        self.db        = HarvestDatabase()
        self.google    = GoogleSearchEngine(google_api_key, google_cx)
        self.harvester = WebHarvester(self.db)
        self.learner   = AdaptiveLearningEngine(self.db, self.google)
        self.generator = HarvestCodeGenerator(self.db, self.learner)
        self.analyzer  = HarvestCodeAnalyzer()
        self._running  = False
        self._thread:  Optional[threading.Thread] = None
        self._iteration = 0
        self._initialized = False

    def initialize(self, extra_urls: List[str] = None) -> Dict:
        all_urls = HARVEST_TARGET_URLS + (extra_urls or [])
        added    = self.db.add_urls(all_urls)
        self._initialized = True
        log.info(f"[HarvestEngine] Initialized — {added} new URLs queued")
        return {"initialized": True, "urls_added": added}

    def run_cycle(self, topics: List[str] = None,
                   max_urls_per_cycle: int = 3) -> Dict:
        if not self._initialized:
            self.initialize()
        topics  = topics or self._TOPICS
        topic   = topics[self._iteration % len(topics)]
        summary = {
            "iteration":  self._iteration + 1,
            "topic":      topic,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
        }
        search_result = self.learner.search_and_learn(topic)
        summary["search"] = {
            "success":  search_result.get("success"),
            "patterns": search_result.get("patterns_found", 0),
        }
        harvest_result = self.harvester.harvest_batch(max_urls=max_urls_per_cycle)
        summary["harvest"] = harvest_result
        for p in self.db.get_patterns(limit=5):
            self._feed_pattern_to_genome(p)
        self._iteration += 1
        summary["stats"] = self.stats()
        log.info(f"[HarvestEngine] Cycle {self._iteration} complete")
        return summary

    def start_autonomous(self, interval_s: float = 30.0,
                          max_iterations: int = 0) -> None:
        with self._lock:
            if self._running:
                return
            self._running = True

        def _loop():
            n = 0
            while self._running:
                if max_iterations and n >= max_iterations:
                    break
                try:
                    self.run_cycle()
                except Exception as e:
                    log.warning(f"[HarvestEngine] Cycle error: {e}")
                n += 1
                time.sleep(interval_s)
            with self._lock:
                self._running = False

        self._thread = threading.Thread(target=_loop, name="harvest_engine", daemon=True)
        self._thread.start()
        log.info(f"[HarvestEngine] Autonomous loop started (interval={interval_s}s)")

    def stop_autonomous(self) -> None:
        with self._lock:
            self._running = False
        log.info("[HarvestEngine] Stop signal sent")

    def search_harvested(self, query: str, max_results: int = 10) -> List[Dict]:
        raw     = self.db.search_code(query, limit=max_results)
        results = []
        for r in raw:
            results.append({
                "title":   f"[H] {r.get('company','?')} — {r.get('language','?')} code",
                "url":     r.get("source_url",""),
                "snippet": (r.get("code",""))[:400],
                "source":  "harvested_code",
                "quality": float(r.get("quality_score",0.5)),
            })
        return results

    def stats(self) -> Dict:
        return {
            "harvest_db":   self.db.statistics(),
            "harvester":    self.harvester.stats(),
            "learning":     self.learner.get_stats(),
            "iterations":   self._iteration,
            "running":      self._running,
            "initialized":  self._initialized,
        }

    def _feed_pattern_to_genome(self, pattern: Dict) -> None:
        try:
            from genome_manager import get_genome_engine
            snippet = (pattern.get("code_snippet") or "")[:3000]
            if len(snippet) < 50:
                return
            get_genome_engine().add(
                name=f"harvest_pattern:{(pattern.get('pattern_hash') or '')[:12]}",
                description=f"Harvested {pattern.get('pattern_type','unknown')} pattern",
                module_type="harvested_pattern",
                source_code=snippet,
                version="v1.0",
                priority=50,
                capabilities=f"harvested,{pattern.get('pattern_type','')}",
            )
        except Exception:
            pass


# ============================================================================
# UNIFIED SEARCH ENGINE (SINGLETON) — ORIGINAL CODE FULLY PRESERVED
# New: use_harvest parameter + activate_harvesting() method
# ============================================================================

class UnifiedSearchEngine:
    """
    Orchestrates all search sources:
    1. Local knowledge base (fastest, no network)
    2. Logic engine semantic index (TF-IDF)
    3. Genome DNA search
    4. Web search chain: DDG (primary) → Grok → Claude → Firecrawl
    5. AI synthesis (when use_ai=True or still no results)
    6. Harvested code database (when use_harvest=True)

    Results are merged, ranked, deduplicated, and optionally saved back
    to the knowledge base for future searches.
    """

    def __init__(self):
        self._lock          = threading.RLock()
        self._cache         = SearchCache(max_size=300)
        self._ranker        = ResultRanker()
        self._ddg           = DDGEngine()
        self._grok          = GrokSearchEngine()
        self._claude_search = ClaudeSearchEngine()
        self._firecrawl     = FirecrawlEngine()
        self._kb            = KnowledgeEngine()
        self._genome        = GenomeEngine()
        self._logic_sem     = LogicSemanticEngine()
        self._ai            = AISearchEngine()
        self._total_queries = 0
        self._source_hits: Dict[str, int] = defaultdict(int)
        self._recent:       deque         = deque(maxlen=100)
        self._fail_cooldowns: Dict[str, float] = {}
        # Harvesting engine — lazy-init via activate_harvesting()
        self._harvest_engine: Optional[HarvestEngine] = None

    def search(
        self,
        query:        str,
        max_results:  int  = 8,
        use_web:      bool = True,
        use_ai:       bool = False,
        save_to_kb:   bool = False,
        topic_hint:   str  = "",
        use_harvest:  bool = False,
    ) -> Dict:
        """
        Full multi-source search.
        Web fallback order: DDG → Grok → Claude → Firecrawl.
        Returns { results, sources, total, query, cached, timestamp }
        """
        query = query.strip()
        if not query:
            return {"error": "query required", "results": []}

        cache_key = query + (":h" if use_harvest else "")
        cached    = self._cache.get(cache_key)
        if cached:
            log.debug(f"[Search] Cache hit: '{query[:50]}'")
            return {
                "results":   cached,
                "sources":   list({r["source"] for r in cached}),
                "total":     len(cached),
                "query":     query,
                "cached":    True,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        with self._lock:
            self._total_queries += 1

        results      = []
        sources_used = []

        # 1. Knowledge base
        kb_results = self._kb.search(query, max_results=max_results)
        if kb_results:
            results.extend(kb_results)
            sources_used.append("knowledge_base")
            self._source_hits["knowledge_base"] += len(kb_results)

        # 2. Logic semantic index
        sem_results = self._logic_sem.search(query, max_results=max_results // 2)
        if sem_results:
            results.extend(sem_results)
            sources_used.append("logic_semantic")
            self._source_hits["logic_semantic"] += len(sem_results)

        # 3. Genome
        genome_results = self._genome.search(query, max_results=4)
        if genome_results:
            results.extend(genome_results)
            sources_used.append("genome")
            self._source_hits["genome"] += len(genome_results)

        # 4. Harvested code database (only when requested)
        if use_harvest and self._harvest_engine:
            harvest_results = self._harvest_engine.search_harvested(
                query, max_results=max_results
            )
            if harvest_results:
                results.extend(harvest_results)
                sources_used.append("harvested_code")
                self._source_hits["harvested_code"] += len(harvest_results)

        # 5. Web search chain — DDG → Grok → Claude → Firecrawl
        if use_web:
            web_results = self._web_search_with_fallback(query, max_results)
            for r in web_results:
                src = r.get("source", "web")
                results.append(r)
                if src not in sources_used:
                    sources_used.append(src)
                self._source_hits[src] += 1

        # 6. AI synthesis — if explicitly requested OR still no results at all
        if use_ai or not results:
            ai_results = self._ai.search(query, context_results=results[:5])
            if ai_results:
                results.extend(ai_results)
                sources_used.append("ai_synthesis")
                self._source_hits["ai_synthesis"] += len(ai_results)

        results = self._dedup(results)
        results = self._ranker.rank(query, results)
        results = results[:max_results]

        self._cache.set(cache_key, results, source=",".join(sources_used))

        if save_to_kb and results:
            self._save_to_kb(query, results[:3], topic_hint)

        self._recent.append({
            "query":   query,
            "results": len(results),
            "sources": sources_used,
            "ts":      time.time(),
        })

        log.info(
            f"[Search] '{query[:60]}' → {len(results)} results from {sources_used}"
        )

        return {
            "results":   results,
            "sources":   list(set(sources_used)),
            "total":     len(results),
            "query":     query,
            "cached":    False,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _web_search_with_fallback(self, query: str, max_results: int) -> List[Dict]:
        """
        Try web engines in order: DDG → Grok → Claude → Firecrawl.
        Returns results from the first engine that succeeds.
        Falls through to the next engine on empty result or failure.
        """
        # 1. DDG — primary (free, no key)
        results = self._ddg.search(query, max_results=max_results)
        if results:
            log.debug(f"[Search:web] DDG succeeded ({len(results)} results)")
            return results

        log.info("[Search:web] DDG returned 0 results → trying Grok")

        # 2. Grok (xAI) — first paid fallback
        results = self._grok.search(query, max_results=max_results)
        if results:
            log.debug(f"[Search:web] Grok succeeded ({len(results)} results)")
            return results

        log.info("[Search:web] Grok returned 0 results → trying Claude")

        # 3. Claude — second paid fallback
        results = self._claude_search.search(query, max_results=max_results)
        if results:
            log.debug(f"[Search:web] Claude succeeded ({len(results)} results)")
            return results

        log.info("[Search:web] Claude returned 0 results → trying Firecrawl")

        # 4. Firecrawl — final fallback
        results = self._firecrawl.search(query, max_results=max_results)
        if results:
            log.debug(f"[Search:web] Firecrawl succeeded ({len(results)} results)")
            return results

        log.warning(f"[Search:web] All web engines exhausted for '{query[:50]}'")
        return []

    def quick_search(self, query: str, max_results: int = 5) -> List[Dict]:
        """Fast search: KB + logic semantic only. No web, no AI."""
        return self.search(query, max_results=max_results,
                            use_web=False, use_ai=False)["results"]

    def deep_search(self, query: str, max_results: int = 10) -> Dict:
        """Full search with web + AI synthesis."""
        return self.search(query, max_results=max_results,
                            use_web=True, use_ai=True, save_to_kb=True)

    def logic_engine_search(self, query: str, top_k: int = 10) -> List[Dict]:
        """Delegate directly to logic engine TF-IDF semantic index."""
        return self._logic_sem.search(query, max_results=top_k)

    def stats(self) -> Dict:
        base = {
            "total_queries":  self._total_queries,
            "source_hits":    dict(self._source_hits),
            "cache":          self._cache.stats(),
            "recent_queries": list(self._recent)[-10:],
        }
        if self._harvest_engine:
            base["harvest_engine"] = self._harvest_engine.stats()
        return base

    # ── NEW: Harvesting activation ─────────────────────────────────────────

    def activate_harvesting(
        self,
        google_api_key:      str       = "",
        google_cx:           str       = "",
        extra_urls:          List[str] = None,
        autonomous:          bool      = False,
        autonomous_interval: float     = 30.0,
        max_iterations:      int       = 0,
    ) -> Dict:
        """
        Initialize and activate the autonomous harvesting system.
        Lazy-initialises HarvestEngine if not already created.

        Args:
            google_api_key:      Google Custom Search API key (optional)
            google_cx:           Google Custom Search Engine ID (optional)
            extra_urls:          Additional URLs to queue
            autonomous:          Start background continuous harvesting loop
            autonomous_interval: Seconds between background harvest cycles
            max_iterations:      0 = run forever; >0 = stop after N cycles

        Returns:
            Status dict with initialization details.
        """
        with self._lock:
            if self._harvest_engine is None:
                self._harvest_engine = HarvestEngine(
                    google_api_key=google_api_key or os.environ.get("GOOGLE_API_KEY", ""),
                    google_cx=google_cx or os.environ.get("GOOGLE_SEARCH_ENGINE_ID", ""),
                )

        init_result = self._harvest_engine.initialize(extra_urls=extra_urls)

        if autonomous:
            self._harvest_engine.start_autonomous(
                interval_s=autonomous_interval,
                max_iterations=max_iterations,
            )

        log.info(
            f"[Search] Harvesting activated — "
            f"autonomous={autonomous}, interval={autonomous_interval}s"
        )
        return {
            "status":     "activated",
            "autonomous": autonomous,
            "interval_s": autonomous_interval,
            **init_result,
        }

    def run_harvest_cycle(self, max_urls: int = 3) -> Dict:
        """Run a single harvest cycle manually."""
        if self._harvest_engine is None:
            return {"error": "Harvesting not activated. Call activate_harvesting() first."}
        return self._harvest_engine.run_cycle(max_urls_per_cycle=max_urls)

    def stop_harvesting(self) -> Dict:
        """Stop the autonomous harvesting background loop."""
        if self._harvest_engine:
            self._harvest_engine.stop_autonomous()
            return {"status": "stopped"}
        return {"status": "not_running"}

    def harvest_stats(self) -> Dict:
        """Return stats from the harvesting subsystem."""
        if not self._harvest_engine:
            return {"status": "not_initialized"}
        return self._harvest_engine.stats()

    # ── Internal helpers (unchanged) ──────────────────────────────────────

    def _dedup(self, results: List[Dict]) -> List[Dict]:
        seen_fps: set = set()
        unique: List[Dict] = []
        for r in results:
            fp = hashlib.md5(r.get("snippet","")[:100].encode()).hexdigest()
            if fp not in seen_fps:
                seen_fps.add(fp)
                unique.append(r)
        return unique

    def _save_to_kb(self, query: str, results: List[Dict], topic_hint: str = "") -> None:
        topic = topic_hint.strip() or query[:200]
        content_parts = []
        for r in results[:3]:
            if r.get("snippet"):
                content_parts.append(f"Source: {r.get('title','')}\n{r['snippet']}")
        content = "\n\n".join(content_parts)[:2000]
        if not content.strip():
            return
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """INSERT OR IGNORE INTO knowledge
                   (topic, depth, content, source_url, confidence, domain)
                   VALUES (?, 'Simple', ?, ?, 0.65, 'search')""",
                (topic[:200], content, results[0].get("url","") if results else "")
            )
            conn.commit(); conn.close()
            log.debug(f"[Search] Saved search result: {topic[:50]}")
        except Exception as e:
            log.debug(f"[Search] KB save failed: {e}")


# ============================================================================
# SINGLETON
# ============================================================================

_search_lock:     threading.RLock          = threading.RLock()
_search_instance: Optional[UnifiedSearchEngine] = None


def get_engine() -> UnifiedSearchEngine:
    global _search_instance
    with _search_lock:
        if _search_instance is None:
            _search_instance = UnifiedSearchEngine()
        return _search_instance


# ============================================================================
# MODULE-LEVEL CONVENIENCE FUNCTIONS
# ============================================================================

def search_web(query: str, max_results: int = 5) -> List[Dict]:
    """Importable by any Zeus module. Returns list of result dicts."""
    return get_engine().search(query, max_results=max_results, use_web=True)["results"]


def search_knowledge(query: str, max_results: int = 6) -> List[Dict]:
    """Search only local knowledge base. No network."""
    return get_engine().quick_search(query, max_results=max_results)


def search_all(query: str, max_results: int = 8, save: bool = False) -> Dict:
    """Full multi-source search. Returns full result dict."""
    return get_engine().search(query, max_results=max_results,
                                use_web=True, use_ai=False, save_to_kb=save)


def search_harvested(query: str, max_results: int = 8) -> Dict:
    """Search the harvested code database. Returns full result dict."""
    return get_engine().search(query, max_results=max_results,
                                use_web=False, use_harvest=True)


def activate_harvesting(autonomous: bool = False, **kwargs) -> Dict:
    """Activate the autonomous harvesting system on the singleton engine."""
    return get_engine().activate_harvesting(autonomous=autonomous, **kwargs)


# ============================================================================
# FLASK ROUTES — ALL ORIGINAL ROUTES PRESERVED EXACTLY
# ============================================================================

@search_bp.route("/api/search", methods=["POST", "GET"])
def search_route():
    """
    POST { "query": str, "max_results": int, "use_web": bool,
           "use_ai": bool, "save_to_kb": bool, "topic_hint": str,
           "use_harvest": bool }
    GET  ?q=str&max=int&web=0|1&ai=0|1&save=0|1&harvest=0|1
    """
    if request.method == "POST":
        data        = request.get_json(force=True, silent=True) or {}
        query       = data.get("query", "").strip()
        max_r       = int(data.get("max_results", 8))
        use_web     = bool(data.get("use_web", True))
        use_ai      = bool(data.get("use_ai", False))
        save_to_kb  = bool(data.get("save_to_kb", False))
        topic_hint  = data.get("topic_hint", "")
        use_harvest = bool(data.get("use_harvest", False))
    else:
        query       = request.args.get("q",       "").strip()
        max_r       = int(request.args.get("max", 8))
        use_web     = request.args.get("web",     "1") == "1"
        use_ai      = request.args.get("ai",      "0") == "1"
        save_to_kb  = request.args.get("save",    "0") == "1"
        topic_hint  = request.args.get("topic",   "")
        use_harvest = request.args.get("harvest", "0") == "1"

    if not query:
        return jsonify({"error": "query required (POST: query, GET: q)"}), 400

    try:
        result = get_engine().search(
            query=query, max_results=min(max_r, 20),
            use_web=use_web, use_ai=use_ai,
            save_to_kb=save_to_kb, topic_hint=topic_hint,
            use_harvest=use_harvest,
        )
        return jsonify(result)
    except Exception as exc:
        log.error(f"[Search] Route error: {exc}")
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/deep", methods=["POST"])
def search_deep():
    """Full deep search: web + AI synthesis. POST { "query": str }"""
    data  = request.get_json(force=True, silent=True) or {}
    query = data.get("query", "").strip()
    if not query:
        return jsonify({"error": "query required"}), 400
    try:
        return jsonify(get_engine().deep_search(query, max_results=10))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/knowledge", methods=["POST"])
def search_knowledge_route():
    """Search local knowledge base only. POST { "query": str }"""
    data  = request.get_json(force=True, silent=True) or {}
    query = data.get("query", "").strip()
    top_k = int(data.get("top_k", 8))
    if not query:
        return jsonify({"error": "query required"}), 400
    try:
        results = KnowledgeEngine().search(query, max_results=top_k)
        return jsonify({"results": results, "query": query, "total": len(results)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/semantic", methods=["POST"])
def search_semantic():
    """Logic engine semantic search (TF-IDF). POST { "query": str, "top_k": int }"""
    data  = request.get_json(force=True, silent=True) or {}
    query = data.get("query", "").strip()
    top_k = int(data.get("top_k", 10))
    if not query:
        return jsonify({"error": "query required"}), 400
    try:
        results = get_engine().logic_engine_search(query, top_k=top_k)
        return jsonify({"results": results, "query": query, "total": len(results)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/health", methods=["GET"])
def search_health():
    engine = get_engine()
    # Check which web fallbacks are configured
    web_engines = {
        "ddg":       "always_available",
        "grok":      "configured" if os.environ.get("XAI_API_KEY") else "missing_key",
        "claude":    "configured" if os.environ.get("ANTHROPIC_API_KEY") else "missing_key",
        "firecrawl": "configured" if os.environ.get("FIRECRAWL_API_KEY") else "missing_key",
    }
    return jsonify({
        "status":          "ok",
        "module":          "zeus_search",
        "version":         "2.2",
        "sources":         ["knowledge_base", "logic_semantic", "genome",
                            "ddg", "grok", "claude", "firecrawl",
                            "ai_synthesis", "harvested_code"],
        "web_fallback_chain": ["ddg", "grok", "claude", "firecrawl"],
        "web_engines":     web_engines,
        "cache_stats":     engine._cache.stats(),
        "harvest_active":  engine._harvest_engine is not None,
        "harvest_running": engine._harvest_engine._running
                           if engine._harvest_engine else False,
    })


@search_bp.route("/api/search/stats", methods=["GET"])
def search_stats():
    try:
        return jsonify(get_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/cache/clear", methods=["POST"])
def search_cache_clear():
    n = get_engine()._cache.clear()
    return jsonify({"status": "ok", "cleared": n})


# ── NEW HARVESTING ROUTES ─────────────────────────────────────────────────────

@search_bp.route("/api/search/harvest/activate", methods=["POST"])
def harvest_activate():
    """
    Activate the autonomous harvesting system.
    POST {
      "autonomous":          bool,    (default: false)
      "autonomous_interval": float,   (seconds, default: 30)
      "max_iterations":      int,     (0=forever)
      "extra_urls":          [str],
      "google_api_key":      str,
      "google_cx":           str
    }
    """
    data = request.get_json(force=True, silent=True) or {}
    try:
        result = get_engine().activate_harvesting(
            google_api_key=data.get("google_api_key",""),
            google_cx=data.get("google_cx",""),
            extra_urls=data.get("extra_urls",[]),
            autonomous=bool(data.get("autonomous",False)),
            autonomous_interval=float(data.get("autonomous_interval",30.0)),
            max_iterations=int(data.get("max_iterations",0)),
        )
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/harvest/cycle", methods=["POST"])
def harvest_cycle():
    """Run one harvest cycle manually. POST { "max_urls": int }"""
    data     = request.get_json(force=True, silent=True) or {}
    max_urls = int(data.get("max_urls", 3))
    try:
        return jsonify(get_engine().run_harvest_cycle(max_urls=max_urls))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/harvest/stop", methods=["POST"])
def harvest_stop():
    """Stop the autonomous harvesting background loop."""
    return jsonify(get_engine().stop_harvesting())


@search_bp.route("/api/search/harvest/stats", methods=["GET"])
def harvest_stats():
    """Return harvesting subsystem statistics."""
    return jsonify(get_engine().harvest_stats())


@search_bp.route("/api/search/harvest/query", methods=["POST"])
def harvest_query():
    """Search the harvested code database. POST { "query": str }"""
    data  = request.get_json(force=True, silent=True) or {}
    query = data.get("query","").strip()
    max_r = int(data.get("max_results", 10))
    if not query:
        return jsonify({"error": "query required"}), 400
    try:
        result = get_engine().search(query=query, max_results=max_r,
                                      use_web=False, use_harvest=True)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/harvest/analyze", methods=["POST"])
def harvest_analyze():
    """Analyze code with the harvest analyzer. POST { "code": str }"""
    data = request.get_json(force=True, silent=True) or {}
    code = data.get("code","").strip()
    if not code:
        return jsonify({"error": "code required"}), 400
    try:
        return jsonify(HarvestCodeAnalyzer().analyze(code))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/harvest/evolve", methods=["POST"])
def harvest_evolve():
    """Evolve a new capability. POST { "name": str, "description": str }"""
    data = request.get_json(force=True, silent=True) or {}
    name = data.get("name","").strip()
    desc = data.get("description","").strip()
    if not name or not desc:
        return jsonify({"error": "name and description required"}), 400
    try:
        engine = get_engine()
        if not engine._harvest_engine:
            engine.activate_harvesting()
        result = engine._harvest_engine.generator.evolve_capability(name, desc)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@search_bp.route("/api/search/harvest/learn", methods=["POST"])
def harvest_learn():
    """
    Trigger search-and-learn on a topic.
    POST { "topic": str }
    """
    data  = request.get_json(force=True, silent=True) or {}
    topic = data.get("topic","").strip()
    if not topic:
        return jsonify({"error": "topic required"}), 400
    try:
        engine = get_engine()
        if not engine._harvest_engine:
            engine.activate_harvesting()
        result = engine._harvest_engine.learner.search_and_learn(topic)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(search_bp)
    log.info("[search] ✓ Registered at /api/search (+ autonomous harvesting)")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_search",
            blueprint_var="search_bp",
            url_prefix="/api/search",
            version="2.1",
            description=(
                "Multi-source unified search: DDG + knowledge base + genome + "
                "logic semantic + AI synthesis + autonomous harvesting engine "
                "(150+ AI sources, Google Custom Search, adaptive learning, "
                "code generator, pattern evolution)"
            ),
            capabilities=[
                {"id": "search.main",          "endpoint": "/api/search",                  "method": "POST", "tags": ["search","web"]},
                {"id": "search.deep",          "endpoint": "/api/search/deep",              "method": "POST", "tags": ["search","ai"]},
                {"id": "search.knowledge",     "endpoint": "/api/search/knowledge",         "method": "POST", "tags": ["search","kb"]},
                {"id": "search.semantic",      "endpoint": "/api/search/semantic",          "method": "POST", "tags": ["search","semantic"]},
                {"id": "search.health",        "endpoint": "/api/search/health",            "method": "GET",  "tags": ["health"]},
                {"id": "search.stats",         "endpoint": "/api/search/stats",             "method": "GET",  "tags": ["stats"]},
                {"id": "harvest.activate",     "endpoint": "/api/search/harvest/activate",  "method": "POST", "tags": ["harvest","autonomous"]},
                {"id": "harvest.cycle",        "endpoint": "/api/search/harvest/cycle",     "method": "POST", "tags": ["harvest"]},
                {"id": "harvest.stop",         "endpoint": "/api/search/harvest/stop",      "method": "POST", "tags": ["harvest"]},
                {"id": "harvest.stats",        "endpoint": "/api/search/harvest/stats",     "method": "GET",  "tags": ["harvest","stats"]},
                {"id": "harvest.query",        "endpoint": "/api/search/harvest/query",     "method": "POST", "tags": ["harvest","search"]},
                {"id": "harvest.analyze",      "endpoint": "/api/search/harvest/analyze",   "method": "POST", "tags": ["harvest","analysis"]},
                {"id": "harvest.evolve",       "endpoint": "/api/search/harvest/evolve",    "method": "POST", "tags": ["harvest","evolution"]},
                {"id": "harvest.learn",        "endpoint": "/api/search/harvest/learn",     "method": "POST", "tags": ["harvest","learning"]},
            ],
            depends_on=["zeus_llm_router","logic_engine","genome_manager"],
            boot_order=20,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5012, debug=True, use_reloader=False)
