# The Zeus Project 2026 — Francois Nel
# zeus_prediction_engine.py — Universal Prediction Engine v1.0
#
# Run once to self-install: python3 zeus_prediction_engine.py
# That single command will:
#   1. Inject blueprint into app.py
#   2. Create all DB tables
#   3. Wire into zeus_nightly_scheduler.py
#   4. Wire into zeus_recursive_learner.py
#   5. Run first full system scan + generate predictions
#   6. Print a ranked report to stdout

import os, re, ast, json, uuid, time, math, logging, hashlib, threading, shutil, sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify

log = logging.getLogger("zeus.prediction")
prediction_bp = Blueprint("prediction", __name__)

ZEUS_DIR  = os.path.dirname(os.path.abspath(__file__))
PRED_DIR  = os.path.join(ZEUS_DIR, "prediction_output")
os.makedirs(PRED_DIR, exist_ok=True)

# ── Every Zeus file/folder the scanner will inspect ──────────────────────────
ZEUS_SOURCE_FILES = [
    "app.py", "db_init.py",
    "zeus_chat.py", "zeus_llm_router.py", "zeus_mutator.py",
    "zeus_recursive_learner.py", "zeus_self_evolution.py",
    "zeus_synthesis.py", "zeus_synthesis_v3.py",
    "zeus_forge.py", "zeus_apk_export.py", "zeus_apk_builder_core.py",
    "zeus_apk_engine.py", "zeus_blueprints.py", "zeus_executor.py",
    "zeus_genome.py", "genome_manager.py", "zeus_identity.py",
    "zeus_knowledge.py", "zeus_search.py", "zeus_upload.py",
    "zeus_sandbox.py", "zeus_replication_engine.py",
    "zeus_nightly_scheduler.py", "zeus_scheduler.py",
    "zeus_repair.py", "zeus_grok_bridge.py", "zeus_memory.py",
    "zeus_orchestrator.py", "zeus_prediction_engine.py",
    "zeus_learning_dashboard.py", "zeus_learner.py",
    "apply_patches.py", "full_system_check.py",
]

ZEUS_SCAN_DIRS = [
    "genome", "evolved_modules", "synthesis_output", "blueprints",
    "generated_code", "forge_output", "apk_analysis", "uploads",
    "data", "models", "children", "exports", "reports",
    "strategies", "templates", "backups", "sandbox_workspace",
    "splice_archive", "logs",
]


# ═══════════════════════════════════════════════════════════════════════════ #
#  DATA MODELS                                                                #
# ═══════════════════════════════════════════════════════════════════════════ #

@dataclass
class ComponentHealth:
    name: str
    path: str
    exists: bool = False
    loc: int = 0
    functions: int = 0
    classes: int = 0
    routes: List[str] = field(default_factory=list)
    imports: List[str] = field(default_factory=list)
    complexity: float = 0.0
    has_syntax_error: bool = False
    syntax_error: str = ""
    has_tests: bool = False
    last_modified: float = 0.0
    maturity: str = "missing"   # missing/embryonic/developing/stable/mature
    issues: List[str] = field(default_factory=list)

@dataclass
class DirStats:
    name: str
    exists: bool = False
    file_count: int = 0
    total_bytes: int = 0
    extensions: Dict[str, int] = field(default_factory=dict)

@dataclass
class SystemSnapshot:
    ts: str = ""
    # DB counts
    genome_count: int = 0
    knowledge_count: int = 0
    queue_pending: int = 0
    queue_processing: int = 0
    queue_done: int = 0
    evolved_modules: int = 0
    synthesis_jobs: int = 0
    learner_cycles: int = 0
    llm_call_count: int = 0
    # DB samples
    top_genome: List[Dict] = field(default_factory=list)
    top_knowledge: List[Dict] = field(default_factory=list)
    queue_sample: List[Dict] = field(default_factory=list)
    recent_synthesis: List[Dict] = field(default_factory=list)
    recent_learner: List[Dict] = field(default_factory=list)
    recent_mutations: List[Dict] = field(default_factory=list)
    # Source analysis
    components: List[ComponentHealth] = field(default_factory=list)
    dir_stats: List[DirStats] = field(default_factory=list)
    active_blueprints: List[str] = field(default_factory=list)
    total_loc: int = 0
    # Derived
    capability_gaps: List[str] = field(default_factory=list)
    bottlenecks: List[str] = field(default_factory=list)
    metrics: Dict = field(default_factory=dict)

@dataclass
class ImpactScore:
    intelligence: float = 0.0
    speed: float = 0.0
    autonomy: float = 0.0
    synthesis: float = 0.0
    knowledge: float = 0.0
    resilience: float = 0.0
    compound: float = 1.0
    total: float = 0.0

    def compute(self) -> "ImpactScore":
        raw = (self.intelligence * 2.5 + self.speed * 1.2 + self.autonomy * 2.0 +
               self.synthesis * 1.8 + self.knowledge * 1.5 + self.resilience * 1.0)
        self.total = round(raw * self.compound, 3)
        return self

@dataclass
class Effect:
    description: str
    probability: float = 0.8
    horizon: str = "days"    # hours/days/weeks/months
    positive: bool = True

@dataclass
class Prediction:
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    title: str = ""
    category: str = ""
    rank: int = 999
    summary: str = ""
    rationale: str = ""
    steps: List[str] = field(default_factory=list)
    code_patch: str = ""
    target_files: List[str] = field(default_factory=list)
    impact: ImpactScore = field(default_factory=ImpactScore)
    second_order: List[Effect] = field(default_factory=list)
    third_order: List[str] = field(default_factory=list)
    effort_hours: float = 4.0
    risk: str = "low"
    created_at: str = ""
    status: str = "pending"

    def to_dict(self) -> Dict:
        return {
            "id": self.id, "title": self.title, "category": self.category,
            "rank": self.rank, "summary": self.summary, "rationale": self.rationale,
            "steps": self.steps, "code_patch": self.code_patch,
            "target_files": self.target_files,
            "impact": {"total": self.impact.total, "intelligence": self.impact.intelligence,
                       "speed": self.impact.speed, "autonomy": self.impact.autonomy,
                       "synthesis": self.impact.synthesis, "knowledge": self.impact.knowledge,
                       "resilience": self.impact.resilience, "compound": self.impact.compound},
            "second_order": [{"desc": e.description, "prob": e.probability,
                               "horizon": e.horizon, "positive": e.positive}
                             for e in self.second_order],
            "third_order": self.third_order,
            "effort_hours": self.effort_hours, "risk": self.risk,
            "created_at": self.created_at, "status": self.status,
        }


# ═══════════════════════════════════════════════════════════════════════════ #
#  SYSTEM STATE SCANNER                                                       #
# ═══════════════════════════════════════════════════════════════════════════ #

class SystemStateScanner:
    """
    Reads EVERY dimension of the running Zeus system.
    Covers: all source files, all DB tables, all output directories.
    """

    def scan(self) -> SystemSnapshot:
        snap = SystemSnapshot(ts=datetime.now(timezone.utc).isoformat())
        self._scan_db(snap)
        self._scan_sources(snap)
        self._scan_dirs(snap)
        self._scan_blueprints(snap)
        self._derive_gaps(snap)
        self._derive_bottlenecks(snap)
        snap.metrics = {
            "genome": snap.genome_count, "knowledge": snap.knowledge_count,
            "queue_pending": snap.queue_pending, "queue_done": snap.queue_done,
            "evolved_modules": snap.evolved_modules, "synthesis_jobs": snap.synthesis_jobs,
            "learner_cycles": snap.learner_cycles, "total_loc": snap.total_loc,
            "active_blueprints": len(snap.active_blueprints),
            "component_count": len(snap.components),
            "gaps": len(snap.capability_gaps), "bottlenecks": len(snap.bottlenecks),
        }
        return snap

    def _db(self):
        from db_init import get_db
        return get_db()

    def _q(self, conn, sql: str, default=0):
        try:   return conn.execute(sql).fetchone()[0] or default
        except: return default

    def _rows(self, conn, sql: str) -> List[Dict]:
        try:   return [dict(r) for r in conn.execute(sql).fetchall()]
        except: return []

    def _scan_db(self, snap: SystemSnapshot):
        try:
            conn = self._db()
            snap.genome_count    = self._q(conn, "SELECT COUNT(*) FROM genome")
            snap.knowledge_count = self._q(conn, "SELECT COUNT(*) FROM knowledge")
            snap.queue_pending   = self._q(conn, "SELECT COUNT(*) FROM learning_queue WHERE status='pending'")
            snap.queue_processing= self._q(conn, "SELECT COUNT(*) FROM learning_queue WHERE status='processing'")
            snap.queue_done      = self._q(conn, "SELECT COUNT(*) FROM learning_queue WHERE status='done'")
            snap.synthesis_jobs  = self._q(conn, "SELECT COUNT(*) FROM synthesis_jobs")
            snap.learner_cycles  = self._q(conn, "SELECT COUNT(*) FROM learner_cycles")

            for tbl in ("evolved_modules", "llm_calls", "mutations"):
                try:
                    v = self._q(conn, f"SELECT COUNT(*) FROM {tbl}")
                    if tbl == "evolved_modules": snap.evolved_modules = v
                    if tbl == "llm_calls":       snap.llm_call_count  = v
                except: pass

            snap.top_genome = self._rows(conn,
                "SELECT name,description,priority,module_type FROM genome "
                "ORDER BY priority DESC LIMIT 25")
            snap.top_knowledge = self._rows(conn,
                "SELECT topic,depth,confidence FROM knowledge "
                "ORDER BY confidence DESC, rowid DESC LIMIT 25")
            snap.queue_sample = self._rows(conn,
                "SELECT topic,depth,priority FROM learning_queue "
                "WHERE status='pending' ORDER BY priority DESC LIMIT 40")
            snap.recent_synthesis = self._rows(conn,
                "SELECT topic,target_lang,status,architecture FROM synthesis_jobs "
                "ORDER BY created_at DESC LIMIT 20")
            snap.recent_learner = self._rows(conn,
                "SELECT * FROM learner_cycles ORDER BY started_at DESC LIMIT 10")

            # Genome type distribution
            genome_types = self._rows(conn,
                "SELECT module_type, COUNT(*) as n FROM genome GROUP BY module_type")
            snap.metrics["genome_types"] = {r["module_type"]: r["n"] for r in genome_types}

            # Knowledge depth distribution
            kd = self._rows(conn,
                "SELECT depth, COUNT(*) as n FROM knowledge GROUP BY depth")
            snap.metrics["knowledge_depths"] = {r["depth"]: r["n"] for r in kd}

            conn.close()
        except Exception as e:
            log.warning(f"[Scanner] DB error: {e}")

    def _scan_sources(self, snap: SystemSnapshot):
        for fname in ZEUS_SOURCE_FILES:
            path = os.path.join(ZEUS_DIR, fname)
            ch   = ComponentHealth(name=fname, path=path, exists=os.path.isfile(path))
            if ch.exists:
                self._analyse_source(ch)
            snap.components.append(ch)
        snap.total_loc = sum(c.loc for c in snap.components)

    def _analyse_source(self, ch: ComponentHealth):
        try:
            src = Path(ch.path).read_text(encoding="utf-8", errors="replace")
            lines = src.splitlines()
            ch.loc = len(lines)
            ch.last_modified = os.path.getmtime(ch.path)
            ch.has_tests = bool(re.search(r'def test_', src))
            ch.routes = re.findall(r'@\w+_bp\.route\(["\']([^"\']+)["\']', src)[:20]

            try:
                tree = ast.parse(src)
                ch.functions = sum(1 for n in ast.walk(tree)
                                   if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
                ch.classes   = sum(1 for n in ast.walk(tree) if isinstance(n, ast.ClassDef))
                ch.imports   = list(dict.fromkeys(
                    getattr(n, "module", None) or (n.names[0].name if n.names else "")
                    for n in ast.walk(tree)
                    if isinstance(n, (ast.Import, ast.ImportFrom))
                ))[:20]
                branches = sum(1 for n in ast.walk(tree)
                               if isinstance(n, (ast.If, ast.While, ast.For,
                                                 ast.ExceptHandler, ast.comprehension)))
                ch.complexity = round(branches / max(ch.functions, 1), 2)
            except SyntaxError as e:
                ch.has_syntax_error = True
                ch.syntax_error     = str(e)
                ch.issues.append(f"SyntaxError: {e}")

            if ch.loc > 2000:  ch.maturity = "mature"
            elif ch.loc > 600: ch.maturity = "stable"
            elif ch.loc > 150: ch.maturity = "developing"
            else:              ch.maturity = "embryonic"

            if ch.complexity > 10:  ch.issues.append(f"High complexity {ch.complexity}")
            if ch.loc > 1500:       ch.issues.append(f"Monolithic ({ch.loc} LOC)")
            if not ch.has_tests:    ch.issues.append("No test coverage")

        except Exception as e:
            ch.issues.append(f"Read error: {e}")

    def _scan_dirs(self, snap: SystemSnapshot):
        for dname in ZEUS_SCAN_DIRS:
            dpath = os.path.join(ZEUS_DIR, dname)
            ds    = DirStats(name=dname, exists=os.path.isdir(dpath))
            if ds.exists:
                for root, _, files in os.walk(dpath):
                    for f in files:
                        fp = os.path.join(root, f)
                        try:
                            ds.file_count += 1
                            ds.total_bytes += os.path.getsize(fp)
                            ext = Path(f).suffix.lower()
                            ds.extensions[ext] = ds.extensions.get(ext, 0) + 1
                        except: pass
            snap.dir_stats.append(ds)

    def _scan_blueprints(self, snap: SystemSnapshot):
        app_path = os.path.join(ZEUS_DIR, "app.py")
        if os.path.isfile(app_path):
            src = Path(app_path).read_text(encoding="utf-8", errors="replace")
            snap.active_blueprints = re.findall(r'register_blueprint\((\w+)', src)

    def _derive_gaps(self, snap: SystemSnapshot):
        gaps = []
        existing = {c.name for c in snap.components if c.exists}
        bp_set   = set(snap.active_blueprints)

        critical_modules = {
            "zeus_orchestrator.py":     "Central event bus — modules are tightly coupled without it",
            "zeus_memory.py":           "Episodic memory — Zeus forgets context between restarts",
            "zeus_scheduler.py":        "Nightly scheduler — evolution must be triggered manually",
            "zeus_nightly_scheduler.py":"Nightly scheduler (alt name)",
        }
        for mod, reason in critical_modules.items():
            if mod not in existing:
                gaps.append(f"MISSING MODULE: {mod} — {reason}")

        critical_bps = {
            "prediction_bp": "Prediction engine routes not registered",
            "synthesis_bp":  "Synthesis engine routes not registered",
            "chat_bp":        "Chat routes not registered",
        }
        for bp, reason in critical_bps.items():
            if bp not in bp_set:
                gaps.append(f"UNREGISTERED BLUEPRINT: {bp} — {reason}")

        if snap.genome_count < 100:
            gaps.append(f"SPARSE GENOME: only {snap.genome_count} entries — needs mass seeding")
        if snap.knowledge_count < 1000:
            gaps.append(f"THIN KNOWLEDGE: {snap.knowledge_count} articles — synthesis quality degraded")
        if snap.queue_pending == 0 and snap.queue_done < 100:
            gaps.append("IDLE LEARNER: learning queue empty, no active knowledge acquisition")
        if snap.queue_pending > 10000:
            gaps.append(f"QUEUE FLOOD: {snap.queue_pending} pending — learner cannot keep up")

        syntax_broken = [c.name for c in snap.components if c.has_syntax_error]
        if syntax_broken:
            gaps.append(f"SYNTAX ERRORS in: {', '.join(syntax_broken)} — these modules cannot load")

        untested = [c.name for c in snap.components if c.exists and not c.has_tests]
        if len(untested) > 8:
            gaps.append(f"ZERO TEST COVERAGE: {len(untested)} modules — blind evolution")

        snap.capability_gaps = gaps

    def _derive_bottlenecks(self, snap: SystemSnapshot):
        bns = []
        high_cx = [c.name for c in snap.components if c.complexity > 8 and c.exists]
        if high_cx:
            bns.append(f"HIGH COMPLEXITY HOTSPOTS: {', '.join(high_cx)} — refactor targets")

        monoliths = [f"{c.name} ({c.loc} LOC)" for c in snap.components
                     if c.loc > 1500 and c.exists]
        if monoliths:
            bns.append(f"MONOLITHIC FILES: {', '.join(monoliths)}")

        if snap.queue_pending > snap.queue_done * 2 and snap.queue_pending > 500:
            bns.append(f"LEARNER FALLING BEHIND: {snap.queue_pending} pending vs "
                       f"{snap.queue_done} done — increase batch size or parallelise")

        if snap.recent_synthesis:
            failed = sum(1 for j in snap.recent_synthesis if j.get("status") == "error")
            rate   = failed / len(snap.recent_synthesis)
            if rate > 0.15:
                bns.append(f"SYNTHESIS FAILURE RATE {rate:.0%} — generator has structural bugs")

        genome_types = snap.metrics.get("genome_types", {})
        if genome_types:
            synth_n = genome_types.get("synthesis", 0)
            total_n = sum(genome_types.values())
            if total_n > 0 and synth_n / total_n > 0.6:
                bns.append("GENOME DOMINATED BY SYNTHESIS: other module types starved")

        snap.bottlenecks = bns


# ═══════════════════════════════════════════════════════════════════════════ #
#  IMPACT RANKER                                                              #
# ═══════════════════════════════════════════════════════════════════════════ #

class ImpactRanker:
    _BASE: Dict[str, Dict] = {
        "intelligence": {"intelligence": 3.0, "autonomy": 1.5, "compound": 1.45},
        "autonomy":     {"autonomy": 3.0, "intelligence": 1.2, "compound": 1.5},
        "architecture": {"speed": 2.0, "resilience": 2.0, "compound": 1.3},
        "synthesis":    {"synthesis": 3.0, "knowledge": 1.0, "compound": 1.2},
        "data":         {"knowledge": 3.0, "intelligence": 1.5, "compound": 1.15},
        "performance":  {"speed": 3.0, "resilience": 1.5, "compound": 1.2},
        "integration":  {"resilience": 2.0, "speed": 1.0, "compound": 1.1},
        "repair":       {"resilience": 3.0, "speed": 1.0, "compound": 1.4},
    }

    def score(self, pred: Prediction, snap: SystemSnapshot) -> ImpactScore:
        w = self._BASE.get(pred.category, {"intelligence": 1.0, "compound": 1.0})
        sc = ImpactScore(
            intelligence = w.get("intelligence", 1.0) * (1.0 + 0.08 * len(snap.capability_gaps)),
            speed        = w.get("speed",        1.0),
            autonomy     = w.get("autonomy",     1.0) * (1.0 + 0.1 * max(0, 6 - len(snap.active_blueprints))),
            synthesis    = w.get("synthesis",    1.0),
            knowledge    = w.get("knowledge",    1.0) * (1.5 if snap.knowledge_count < 2000 else 1.0),
            resilience   = w.get("resilience",   1.0),
            compound     = w.get("compound",     1.0),
        )
        # Effort discount
        sc.compound *= 1.0 / (1.0 + math.log1p(pred.effort_hours / 8.0))
        # Risk discount
        sc.compound *= {"low": 1.0, "medium": 0.82, "high": 0.60}.get(pred.risk, 1.0)
        return sc.compute()


# ═══════════════════════════════════════════════════════════════════════════ #
#  EFFECT SIMULATOR                                                           #
# ═══════════════════════════════════════════════════════════════════════════ #

class EffectSimulator:
    _CHAINS: Dict[str, List[Tuple]] = {
        "intelligence": [
            ("LLM routing accuracy improves → fewer wasted API calls", 0.90, "days",  True),
            ("Knowledge quality rises → future learning is higher value", 0.85, "weeks", True),
            ("Genome mutation becomes more targeted → faster evolution", 0.80, "weeks", True),
            ("Over-confident predictions cause incorrect auto-patches", 0.30, "days", False),
        ],
        "autonomy": [
            ("Nightly cycles run deeper with zero manual intervention", 0.90, "hours", True),
            ("Self-scheduling tightens the evolution loop significantly", 0.85, "days",  True),
            ("Autonomous decisions may drift from intended goals without guardrails", 0.40, "weeks", False),
        ],
        "architecture": [
            ("Reduced boot time → nightly scheduler fits more iterations", 0.85, "hours", True),
            ("Cleaner module boundaries → cascading import failures disappear", 0.80, "days",  True),
            ("Refactor exposes hidden race conditions during transition", 0.35, "days", False),
        ],
        "synthesis": [
            ("Generated blueprints become self-testable → invalid output drops", 0.88, "days",  True),
            ("Higher quality seeds feed back into mutator → better genome", 0.90, "weeks", True),
            ("Synthesis volume increase stresses learning queue further", 0.45, "weeks", False),
        ],
        "data": [
            ("Richer knowledge base improves every LLM prompt context", 0.92, "days",  True),
            ("Cross-domain knowledge density enables novel synthesis", 0.75, "weeks", True),
            ("Storage growth outpaces pruning → DB bloat", 0.50, "months", False),
        ],
        "performance": [
            ("Freed compute allows parallel synthesis + learning", 0.85, "hours", True),
            ("Faster responses enable more aggressive nightly windows", 0.80, "days",  True),
        ],
        "repair": [
            ("Syntax errors eliminated → all modules load cleanly", 0.95, "hours", True),
            ("Repaired modules expose deeper logic bugs previously hidden", 0.40, "days", False),
        ],
        "integration": [
            ("Tighter wiring eliminates stale data across module boundaries", 0.88, "hours", True),
            ("Event propagation may amplify failures under load", 0.35, "days", False),
        ],
    }
    _THIRD: Dict[str, List[str]] = {
        "intelligence": [
            "Zeus proposes its own architectural changes without external prompting",
            "Prediction accuracy surpasses human intuition for Zeus-specific decisions",
        ],
        "autonomy": [
            "Multi-day fully autonomous evolution cycles with zero human intervention",
            "Self-modification candidates are auto-validated, applied, and rolled back on failure",
        ],
        "synthesis": [
            "Generated code is automatically deployed to the running Android instance",
            "Cross-language transpilation becomes 100% deterministic across all 17 targets",
        ],
        "architecture": [
            "Module graph becomes self-documenting; new modules auto-scaffolded on demand",
        ],
        "data": [
            "Knowledge base evolves into a semantic vector store enabling domain-crossing synthesis",
            "Genome develops specialised sub-populations per domain",
        ],
        "repair": [
            "System is self-healing: syntax errors are detected and patched without restart",
        ],
    }

    def simulate(self, pred: Prediction, snap: SystemSnapshot) -> Tuple[List[Effect], List[str]]:
        chain = self._CHAINS.get(pred.category, [])
        effects = []
        for desc, prob, horizon, positive in chain:
            # Modulate: stressed system amplifies negative effects
            adj = prob
            if not positive and snap.queue_pending > 5000: adj = min(1.0, prob * 1.25)
            if positive and len(snap.capability_gaps) > 5: adj = min(1.0, prob * 1.10)
            effects.append(Effect(desc, round(adj, 2), horizon, positive))
        third = self._THIRD.get(pred.category, [])[:2]
        return effects, third


# ═══════════════════════════════════════════════════════════════════════════ #
#  PREDICTION ENGINE — the brain                                              #
# ═══════════════════════════════════════════════════════════════════════════ #

class PredictionEngine:
    def __init__(self):
        self.ranker    = ImpactRanker()
        self.simulator = EffectSimulator()

    def generate(self, snap: SystemSnapshot) -> List[Prediction]:
        raw: List[Prediction] = []
        raw += self._repair_predictions(snap)
        raw += self._architecture_predictions(snap)
        raw += self._intelligence_predictions(snap)
        raw += self._autonomy_predictions(snap)
        raw += self._synthesis_predictions(snap)
        raw += self._data_predictions(snap)
        raw += self._performance_predictions(snap)
        raw += self._integration_predictions(snap)

        now = datetime.now(timezone.utc).isoformat()
        for p in raw:
            p.created_at  = now
            p.impact      = self.ranker.score(p, snap)
            p.second_order, p.third_order = self.simulator.simulate(p, snap)

        raw.sort(key=lambda p: p.impact.total, reverse=True)
        for i, p in enumerate(raw, 1):
            p.rank = i
        return raw

    # ── Repair ───────────────────────────────────────────────────────────────

    def _repair_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []
        broken = [c for c in snap.components if c.has_syntax_error]
        for c in broken:
            preds.append(Prediction(
                title=f"CRITICAL: Fix SyntaxError in {c.name}",
                category="repair",
                summary=f"{c.name} has a SyntaxError and cannot be imported by Flask.",
                rationale=f"A SyntaxError prevents the module from loading at all. "
                           f"Error: {c.syntax_error}",
                steps=[
                    f"1. Open {c.name}",
                    f"2. Go to the line reported: {c.syntax_error}",
                    "3. Fix the syntax issue (common: unclosed string, bad indent, missing colon)",
                    "4. Validate with: python3 -m py_compile " + c.name,
                    "5. Restart Zeus",
                ],
                code_patch=f"# Run: python3 -m py_compile {c.name}",
                target_files=[c.name],
                effort_hours=0.5,
                risk="low",
            ))

        missing_critical = [g for g in snap.capability_gaps if "SYNTAX" in g or "MISSING MODULE" in g]
        for gap in missing_critical:
            mod_match = re.search(r'MISSING MODULE: (\S+)', gap)
            if mod_match:
                mod = mod_match.group(1)
                preds.append(Prediction(
                    title=f"Scaffold missing module: {mod}",
                    category="repair",
                    summary=f"{mod} is referenced in the system but does not exist on disk.",
                    rationale=gap,
                    steps=[
                        f"1. Create {mod} with minimal Flask blueprint stub",
                        f"2. Add blueprint registration to app.py",
                        f"3. Implement core functionality",
                    ],
                    code_patch=f"# Minimal scaffold for {mod}:\n"
                                f"from flask import Blueprint\n"
                                f"{mod.replace('.py','').replace('zeus_','')}_bp = Blueprint('{mod.replace('.py','')}', __name__)\n",
                    target_files=[mod, "app.py"],
                    effort_hours=3.0,
                    risk="low",
                ))
        return preds

    # ── Architecture ─────────────────────────────────────────────────────────

    def _architecture_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []

        # Split monoliths
        for c in snap.components:
            if c.loc > 1500 and c.exists:
                preds.append(Prediction(
                    title=f"Split monolith: {c.name} ({c.loc} LOC → 3 focused modules)",
                    category="architecture",
                    summary=f"{c.name} is {c.loc} lines across {c.functions} functions. "
                             f"Split into routes/logic/db layers.",
                    rationale=f"Files over 1500 LOC accumulate hidden coupling and slow "
                               f"hot-reload. {c.name} has complexity={c.complexity}. "
                               f"Splitting allows each layer to evolve independently.",
                    steps=[
                        f"1. Extract all Flask routes → {c.name.replace('.py','_routes.py')}",
                        f"2. Extract DB helpers → {c.name.replace('.py','_db.py')}",
                        f"3. Keep core logic in {c.name} under 500 LOC",
                        f"4. Update imports across all ZEUS_SOURCE_FILES",
                        f"5. Register any new blueprints in app.py",
                    ],
                    code_patch=(
                        f"# {c.name.replace('.py','_routes.py')} — extracted routes\n"
                        f"from flask import Blueprint, request, jsonify\n"
                        f"{c.name.replace('.py','').replace('zeus_','')}_routes_bp = Blueprint('{c.name.replace('.py','')}_routes', __name__)\n\n"
                        f"# Move @*_bp.route decorators here"
                    ),
                    target_files=[c.name, "app.py"],
                    effort_hours=8.0,
                    risk="medium",
                ))

        # Central event bus
        if "zeus_orchestrator.py" not in {c.name for c in snap.components if c.exists}:
            preds.append(Prediction(
                title="Build zeus_orchestrator.py — Central Event Bus",
                category="architecture",
                summary="Replace direct module calls with a pub/sub event bus so every "
                         "Zeus subsystem is decoupled and independently evolvable.",
                rationale=(
                    f"Zeus has {len(snap.active_blueprints)} active blueprints calling each other "
                    f"directly. Adding an event bus means: learner emits 'knowledge_updated', "
                    f"mutator listens and triggers, prediction engine listens and re-scores. "
                    f"Failure in one module no longer cascades."
                ),
                steps=[
                    "1. Create zeus_orchestrator.py with EventBus (publish/subscribe)",
                    "2. Define events: knowledge_updated, genome_mutated, synthesis_done, "
                    "   evolution_tick, learner_cycle_complete, prediction_generated",
                    "3. Replace direct calls in zeus_recursive_learner.py with event emits",
                    "4. Subscribe prediction engine to knowledge_updated + genome_mutated",
                    "5. Register orchestrator_bp in app.py",
                    "6. Expose /api/orchestrator/events GET and /api/orchestrator/emit POST",
                ],
                code_patch="""
class EventBus:
    _subscribers: Dict[str, List] = {}

    @classmethod
    def subscribe(cls, event: str, callback):
        cls._subscribers.setdefault(event, []).append(callback)

    @classmethod
    def emit(cls, event: str, payload: Dict = None):
        for cb in cls._subscribers.get(event, []):
            threading.Thread(target=cb, args=(payload or {},), daemon=True).start()

# Usage in zeus_recursive_learner.py:
# EventBus.emit("knowledge_updated", {"topic": topic, "count": new_count})

# Usage in zeus_prediction_engine.py:
# EventBus.subscribe("knowledge_updated", lambda p: schedule_prediction_run())
""".strip(),
                target_files=["zeus_orchestrator.py", "app.py", "zeus_recursive_learner.py"],
                effort_hours=10.0,
                risk="medium",
            ))

        return preds

    # ── Intelligence ─────────────────────────────────────────────────────────

    def _intelligence_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []

        # Adaptive LLM routing
        preds.append(Prediction(
            title="Adaptive LLM Router: Learn Which Model Wins Per Task Class",
            category="intelligence",
            summary=f"Track success/latency per model per task type. With {snap.llm_call_count} "
                     f"historical calls, route future requests to the statistically best performer.",
            rationale=(
                f"Zeus routes to Claude/OpenRouter statically. With {snap.knowledge_count} "
                f"knowledge articles and {snap.genome_count} genome entries across multiple "
                f"domains, different tasks benefit from different models. Routing correctly "
                f"reduces cost by ~30% and latency by ~40%."
            ),
            steps=[
                "1. Add table: llm_outcomes (call_id, model, task_class, latency_ms, success, tokens, ts)",
                "2. In zeus_llm_router.py call_llm(): wrap with outcome logger",
                "3. Add _best_model(task_class) → queries last 50 outcomes, returns highest success rate",
                "4. Prepend _best_model() lookup before every LLM call",
                "5. Decay scores older than 7 days (exponential moving average)",
                "6. Expose /api/llm/performance endpoint for monitoring",
            ],
            code_patch="""
# In zeus_llm_router.py — add after imports:
def _best_model(task_class: str, default: str = "claude") -> str:
    try:
        conn = _db()
        rows = conn.execute(
            \"\"\"SELECT model, AVG(CAST(success AS FLOAT)) as rate, AVG(latency_ms) as lat
               FROM llm_outcomes WHERE task_class=? AND ts > datetime('now','-7 days')
               GROUP BY model ORDER BY rate DESC, lat ASC LIMIT 1\"\"\",
            (task_class,)).fetchall()
        conn.close()
        return rows[0]["model"] if rows else default
    except Exception:
        return default

def _log_outcome(call_id, model, task_class, latency_ms, success, tokens):
    try:
        conn = _db()
        conn.execute(
            \"INSERT OR IGNORE INTO llm_outcomes VALUES(?,?,?,?,?,?,datetime('now'))\",
            (call_id, model, task_class, latency_ms, int(success), tokens))
        conn.commit(); conn.close()
    except Exception: pass
""".strip(),
            target_files=["zeus_llm_router.py", "db_init.py"],
            effort_hours=5.0,
            risk="low",
        ))

        # TF-IDF knowledge search
        if snap.knowledge_count > 500:
            preds.append(Prediction(
                title=f"Replace LIKE Search with TF-IDF — {snap.knowledge_count} Articles",
                category="intelligence",
                summary="Build a pure-Python TF-IDF index over the knowledge base so synthesis "
                         "and LLM context retrieval finds semantically relevant articles, not just "
                         "substring matches.",
                rationale=(
                    f"With {snap.knowledge_count} knowledge entries, substring LIKE queries miss "
                    f"articles using different vocabulary. TF-IDF (zero new dependencies) gives "
                    f"ranked relevance. Quality of every LLM prompt context improves immediately."
                ),
                steps=[
                    "1. Create zeus_knowledge_index.py with TFIDFIndex class",
                    "2. On startup: load all knowledge.content, build inverted index in memory",
                    "3. Expose search(query, top_k=10) returning (topic, content, score) tuples",
                    "4. Replace all 'WHERE topic LIKE ?' calls with TFIDFIndex.search()",
                    "5. Rebuild index after each learner cycle via EventBus subscription",
                    "6. Add /api/knowledge/search?q=... endpoint",
                ],
                code_patch="""
import math, re
from collections import defaultdict

class TFIDFIndex:
    def __init__(self):
        self.docs: List[Tuple[str,str]] = []   # (topic, content)
        self.tf:   List[Dict[str,float]] = []
        self.idf:  Dict[str,float] = {}

    def build(self, conn):
        rows = conn.execute("SELECT topic, content FROM knowledge").fetchall()
        self.docs = [(r["topic"], str(r["content"])[:2000]) for r in rows]
        N = len(self.docs)
        df: Dict[str,int] = defaultdict(int)
        self.tf = []
        for _, content in self.docs:
            tokens = self._tokenize(content)
            freq: Dict[str,int] = defaultdict(int)
            for t in tokens: freq[t] += 1
            total = max(len(tokens), 1)
            self.tf.append({t: c/total for t, c in freq.items()})
            for t in freq: df[t] += 1
        self.idf = {t: math.log((N+1)/(df[t]+1))+1 for t in df}

    def search(self, query: str, top_k: int = 10) -> List[Tuple[float,str,str]]:
        q_tokens = self._tokenize(query)
        scores = []
        for i, (topic, content) in enumerate(self.docs):
            score = sum(self.tf[i].get(t,0) * self.idf.get(t,0) for t in q_tokens)
            if score > 0: scores.append((score, topic, content[:500]))
        scores.sort(reverse=True)
        return scores[:top_k]

    def _tokenize(self, text: str) -> List[str]:
        return [w.lower() for w in re.findall(r'[a-zA-Z]{3,}', text)]

_knowledge_index = TFIDFIndex()
""".strip(),
                target_files=["zeus_knowledge_index.py", "zeus_recursive_learner.py", "zeus_synthesis_v3.py"],
                effort_hours=6.0,
                risk="low",
            ))

        # Prediction feedback loop
        preds.append(Prediction(
            title="Prediction Accuracy Feedback Loop — Self-Calibrating Scoring",
            category="intelligence",
            summary="Record system metrics before/after each applied prediction. Use the delta "
                     "to recalibrate ImpactRanker weights over time.",
            rationale="The prediction engine scores blindly. If it consistently overestimates "
                       "synthesis improvements, it should learn to discount that category. "
                       "This makes predictions increasingly accurate over weeks.",
            steps=[
                "1. Add table: prediction_outcomes (prediction_id, metrics_before JSON, "
                "   metrics_after JSON, delta JSON, measured_at)",
                "2. When a prediction is marked 'applied': snapshot current DB metrics",
                "3. Schedule re-snapshot 24h later via nightly scheduler",
                "4. Compute delta, store in prediction_outcomes",
                "5. In ImpactRanker.score(): query average delta per category, apply as calibration factor",
            ],
            code_patch="""
def _record_outcome(pred_id: str, before: Dict, after: Dict):
    delta = {k: after.get(k,0) - before.get(k,0) for k in before}
    conn = _db()
    conn.execute(
        \"INSERT INTO prediction_outcomes VALUES(?,?,?,?,datetime('now'))\",
        (pred_id, json.dumps(before), json.dumps(after), json.dumps(delta)))
    conn.commit(); conn.close()
""".strip(),
            target_files=["zeus_prediction_engine.py", "db_init.py"],
            effort_hours=4.0,
            risk="low",
        ))

        return preds

    # ── Autonomy ─────────────────────────────────────────────────────────────

    def _autonomy_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []

        # Nightly scheduler wiring
        scheduler_exists = any(
            c.name in ("zeus_nightly_scheduler.py", "zeus_scheduler.py")
            and c.exists for c in snap.components
        )
        preds.append(Prediction(
            title=("Wire prediction engine into nightly scheduler"
                   if scheduler_exists else "Build zeus_nightly_scheduler.py — Evolution Clock"),
            category="autonomy",
            summary=("Run a full system scan + prediction generation every night at 03:00, "
                     "auto-queue top-5 predictions into the genome for application.")
                    if scheduler_exists else
                    ("Create the nightly scheduler that drives evolution automatically "
                     "while Zeus is idle. Run at 03:00: scan → predict → mutate → learn."),
            rationale=(
                f"Zeus has {snap.learner_cycles} learner cycles but "
                f"{'no scheduler detected' if not scheduler_exists else 'the scheduler is not prediction-aware'}. "
                f"A prediction-aware nightly job compounds evolution every 24 hours "
                f"without human intervention."
            ),
            steps=[
                "1. In zeus_nightly_scheduler.py: add step 'prediction_run'",
                "2. Call POST /api/prediction/run at 03:00 after learner completes",
                "3. Take top-5 predictions by impact.total",
                "4. For each: call _fire_mutator() with prediction as seed",
                "5. Mark predictions status='queued' in DB",
                "6. Log summary to logs/nightly_prediction_{date}.json",
            ],
            code_patch="""
# Add to zeus_nightly_scheduler.py nightly_cycle():
def _run_predictions():
    import requests
    try:
        r = requests.post("http://localhost:8080/api/prediction/run",
                          json={"auto_queue": True, "top_k": 5}, timeout=120)
        log.info(f"[Scheduler] Predictions: {r.json().get('generated',0)} generated")
    except Exception as e:
        log.warning(f"[Scheduler] Prediction run failed: {e}")

# Add to nightly_cycle() after learner step:
_run_predictions()
""".strip(),
            target_files=["zeus_nightly_scheduler.py", "zeus_prediction_engine.py"],
            effort_hours=3.0,
            risk="low",
        ))

        # Recursive self-improvement hook
        preds.append(Prediction(
            title="Full Deep Self-Improvement: Scan → Analyse → Patch → Validate → Apply",
            category="autonomy",
            summary=(
                f"Implement the complete self-improvement pipeline that processes the "
                f"{snap.genome_count} genome entries, {snap.knowledge_count} knowledge "
                f"articles, and {snap.queue_pending} pending queue topics into concrete "
                f"code patches applied without human intervention."
            ),
            rationale=(
                "The current /api/synthesis/self_improve endpoint only seeds the mutator. "
                "The full pipeline should: (1) scan the whole system, (2) generate predictions, "
                "(3) for each high-impact prediction generate an actual code patch, "
                "(4) validate the patch with ast.parse, (5) write it to disk with backup, "
                "(6) record the outcome for feedback learning."
            ),
            steps=[
                "1. Implement _generate_patch(prediction, snap) → actual Python code string",
                "2. Validate patch: ast.parse() + import check",
                "3. Backup original file: shutil.copy(target, target+'.bak')",
                "4. Apply patch: write modified file",
                "5. Smoke test: subprocess.run(['python3','-m','py_compile', target])",
                "6. On failure: restore backup, mark prediction 'failed'",
                "7. On success: mark 'applied', emit EventBus knowledge_updated",
            ],
            code_patch="""
def _safe_apply_patch(target_file: str, patch_content: str, pred_id: str) -> bool:
    backup = target_file + f".bak_{pred_id}"
    try:
        shutil.copy(target_file, backup)
        # Validate patch is valid Python
        ast.parse(patch_content)
        # Append patch to target
        with open(target_file, "a", encoding="utf-8") as f:
            f.write("\\n\\n# === Auto-applied patch: " + pred_id + " ===\\n")
            f.write(patch_content)
        # Smoke test
        result = subprocess.run(
            ["python3", "-m", "py_compile", target_file],
            capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            shutil.copy(backup, target_file)
            return False
        os.remove(backup)
        return True
    except Exception:
        if os.path.exists(backup):
            shutil.copy(backup, target_file)
        return False
""".strip(),
            target_files=["zeus_prediction_engine.py", "zeus_self_evolution.py"],
            effort_hours=12.0,
            risk="high",
        ))

        return preds

    # ── Synthesis ─────────────────────────────────────────────────────────────

    def _synthesis_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []

        if snap.synthesis_jobs > 0:
            failed = sum(1 for j in snap.recent_synthesis if j.get("status") == "error")
            rate   = failed / max(len(snap.recent_synthesis), 1)
            if rate > 0.1:
                preds.append(Prediction(
                    title=f"Fix Synthesis Failure Rate ({rate:.0%} of recent jobs failing)",
                    category="synthesis",
                    summary=f"{failed} of the last {len(snap.recent_synthesis)} synthesis jobs "
                             f"failed. Validate generator output before writing to disk.",
                    rationale="Synthesis failures waste LLM tokens and fill the genome with "
                               "bad seeds. The ValidationLayer in v3 catches Python SyntaxErrors "
                               "but not logic errors. Add a smoke-test runner.",
                    steps=[
                        "1. After generation, run python3 -m py_compile on all .py output files",
                        "2. Check JS/TS output for balanced braces (already in ValidationLayer)",
                        "3. On failure: log detailed error, mark job 'validation_failed', do NOT save genome seed",
                        "4. Expose /api/synthesis/validate POST endpoint for manual testing",
                    ],
                    code_patch="""
# In ValidationLayer.validate() — add smoke test step:
def _smoke_test_python(self, filename: str, content: str, result: ValidationResult):
    import tempfile, subprocess
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name
    try:
        r = subprocess.run(["python3","-m","py_compile", tmp_path],
                           capture_output=True, timeout=10)
        if r.returncode != 0:
            result.valid = False
            result.errors.append(f"{filename}: compile failed: {r.stderr.decode()[:200]}")
    finally:
        os.unlink(tmp_path)
""".strip(),
                    target_files=["zeus_synthesis_v3.py"],
                    effort_hours=3.0,
                    risk="low",
                ))

        # Synthesis → Android auto-deploy
        preds.append(Prediction(
            title="Auto-Deploy Synthesis Output to Running Android APK",
            category="synthesis",
            summary="After a successful synthesis job targeting 'android', automatically "
                     "trigger APKBuilderCore to compile and push the APK to the device.",
            rationale=(
                "Currently synthesis generates Android Kotlin files but stops there. "
                "Wiring synthesis_done → APKBuilderCore → adb install completes the "
                "loop: Zeus writes code and runs it on itself."
            ),
            steps=[
                "1. In run_synthesis(): after status='done' for target='android', emit synthesis_done event",
                "2. APK builder subscribes to synthesis_done: copies output to forge_output/",
                "3. Triggers zeus_apk_builder_core.py build pipeline",
                "4. On build success: adb install -r <apk_path> if device connected",
                "5. Record deploy result in synthesis_blueprints table",
            ],
            code_patch="""
# In run_synthesis() after _job_set(job_id, status="done", ...):
if target == "android":
    threading.Thread(
        target=_trigger_apk_build,
        args=(out_dir, model.metadata.get("app_name","ZeusApp")),
        daemon=True
    ).start()

def _trigger_apk_build(source_dir: str, app_name: str):
    try:
        from zeus_apk_builder_core import APKBuilderCore
        builder = APKBuilderCore()
        result  = builder.build(source_dir=source_dir, app_name=app_name)
        log.info(f"[Synthesis] APK build: {result.get('status')}")
    except Exception as e:
        log.warning(f"[Synthesis] APK build failed: {e}")
""".strip(),
            target_files=["zeus_synthesis_v3.py", "zeus_apk_builder_core.py"],
            effort_hours=6.0,
            risk="medium",
        ))

        return preds

    # ── Data ─────────────────────────────────────────────────────────────────

    def _data_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []

        # Queue re-prioritisation
        if snap.queue_pending > 1000:
            preds.append(Prediction(
                title=f"Intelligent Queue Re-Prioritisation ({snap.queue_pending} pending topics)",
                category="data",
                summary="Re-score all pending queue items by domain relevance to current "
                         "genome gaps, pushing high-leverage topics to the front.",
                rationale=(
                    f"With {snap.queue_pending} pending topics, the learner processes them "
                    f"FIFO. Many low-value topics are processed before high-value ones. "
                    f"Re-scoring by alignment with genome gaps and current prediction priorities "
                    f"multiplies the value of every learner cycle."
                ),
                steps=[
                    "1. Extract top-20 genome capability names",
                    "2. For each pending queue item: score = TF-IDF similarity to genome names",
                    "3. UPDATE learning_queue SET priority=score*100 WHERE status='pending'",
                    "4. Run this re-prioritisation after every prediction cycle",
                    "5. Expose /api/queue/reprioritise POST endpoint",
                ],
                code_patch="""
def reprioritise_queue(conn, genome_topics: List[str]):
    \"\"\"Re-score pending queue items by genome relevance.\"\"\"
    genome_text = " ".join(genome_topics).lower()
    genome_words = set(re.findall(r'[a-z]{4,}', genome_text))
    rows = conn.execute(
        "SELECT id, topic FROM learning_queue WHERE status='pending'"
    ).fetchall()
    updates = []
    for row in rows:
        words = set(re.findall(r'[a-z]{4,}', row['topic'].lower()))
        overlap = len(words & genome_words)
        score   = min(100, 10 + overlap * 15)
        updates.append((score, row['id']))
    conn.executemany("UPDATE learning_queue SET priority=? WHERE id=?", updates)
    conn.commit()
    log.info(f"[Queue] Re-prioritised {len(updates)} items")
""".strip(),
                target_files=["zeus_recursive_learner.py", "zeus_prediction_engine.py"],
                effort_hours=3.0,
                risk="low",
            ))

        # Knowledge pruning
        if snap.knowledge_count > 50000:
            preds.append(Prediction(
                title=f"Knowledge Pruning — Remove Low-Confidence Articles "
                       f"({snap.knowledge_count} total)",
                category="data",
                summary="Delete knowledge entries with confidence < 0.4 and no recent access, "
                         "keeping the DB fast and the TF-IDF index accurate.",
                rationale=(
                    f"At {snap.knowledge_count} articles the knowledge table is large enough "
                    f"to slow queries meaningfully. Low-confidence entries add noise to LLM "
                    f"context and degrade synthesis quality. Pruning monthly keeps the DB sharp."
                ),
                steps=[
                    "1. Add column last_accessed to knowledge table",
                    "2. On every knowledge SELECT: UPDATE last_accessed=now",
                    "3. Monthly prune: DELETE WHERE confidence < 0.4 AND last_accessed < now-90days",
                    "4. Also deduplicate: keep highest-confidence entry per topic",
                    "5. Rebuild TF-IDF index after pruning",
                ],
                code_patch="""
def prune_knowledge(conn, min_confidence: float = 0.4, days_stale: int = 90):
    cutoff = datetime.now(timezone.utc) - timedelta(days=days_stale)
    cur = conn.execute(
        \"\"\"DELETE FROM knowledge
           WHERE confidence < ? AND (last_accessed IS NULL OR last_accessed < ?)
           \"\"\", (min_confidence, cutoff.isoformat()))
    conn.commit()
    return cur.rowcount
""".strip(),
                target_files=["zeus_knowledge.py", "db_init.py"],
                effort_hours=4.0,
                risk="low",
            ))

        return preds

    # ── Performance ───────────────────────────────────────────────────────────

    def _performance_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []

        preds.append(Prediction(
            title="Parallel Synthesis Jobs — Run up to 4 Simultaneously",
            category="performance",
            summary="Replace sequential synthesis with a thread-pool executor so up to 4 "
                     "jobs run in parallel, multiplying throughput 4×.",
            rationale=(
                f"zeus_synthesis_v3.py runs one job at a time. With "
                f"{snap.synthesis_jobs} jobs completed, the queue can clearly support "
                f"parallelism. SQLite WAL mode is already enabled, making concurrent reads safe."
            ),
            steps=[
                "1. Add synthesis_workers config: int(os.environ.get('SYNTHESIS_WORKERS','4'))",
                "2. Replace threading.Thread per-job with concurrent.futures.ThreadPoolExecutor",
                "3. Add semaphore: _synthesis_sem = threading.Semaphore(SYNTHESIS_WORKERS)",
                "4. Acquire semaphore in run_synthesis(), release in finally block",
                "5. Expose /api/synthesis/queue_depth to monitor backlog",
            ],
            code_patch="""
import concurrent.futures
SYNTHESIS_WORKERS = int(os.environ.get("SYNTHESIS_WORKERS", "4"))
_synthesis_pool   = concurrent.futures.ThreadPoolExecutor(max_workers=SYNTHESIS_WORKERS)
_synthesis_sem    = threading.Semaphore(SYNTHESIS_WORKERS)

# Replace threading.Thread(...).start() with:
def _submit_synthesis(job_id, topic, target, file_id, extra):
    _synthesis_sem.acquire()
    try:
        return run_synthesis(job_id, topic, target, file_id, extra)
    finally:
        _synthesis_sem.release()

# In synthesis_generate() async path:
future = _synthesis_pool.submit(_submit_synthesis, job_id, topic, target, file_id, extra)
""".strip(),
            target_files=["zeus_synthesis_v3.py"],
            effort_hours=4.0,
            risk="medium",
        ))

        preds.append(Prediction(
            title="DB Index Optimisation — Add Missing Indexes on Hot Columns",
            category="performance",
            summary="Add composite indexes on knowledge(confidence DESC, rowid), "
                     "learning_queue(status, priority DESC), genome(priority DESC). "
                     "Expected 10–50× speedup on most-used queries.",
            rationale=(
                f"Every learner cycle runs SELECT … ORDER BY priority DESC on "
                f"{snap.queue_pending} pending items without an index. "
                f"Every synthesis enrichment runs WHERE topic LIKE '%%…%%' without an index. "
                f"These are the hottest queries in the system."
            ),
            steps=[
                "1. In db_init.py _ensure_tables(): add CREATE INDEX IF NOT EXISTS statements",
                "2. CREATE INDEX idx_queue_priority ON learning_queue(status, priority DESC)",
                "3. CREATE INDEX idx_knowledge_conf ON knowledge(confidence DESC)",
                "4. CREATE INDEX idx_genome_priority ON genome(priority DESC)",
                "5. CREATE INDEX idx_knowledge_topic ON knowledge(topic)",
                "6. Run ANALYZE after creation",
            ],
            code_patch="""
# Add to db_init.py after CREATE TABLE statements:
conn.execute("CREATE INDEX IF NOT EXISTS idx_queue_priority ON learning_queue(status, priority DESC)")
conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_conf ON knowledge(confidence DESC)")
conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_topic ON knowledge(topic)")
conn.execute("CREATE INDEX IF NOT EXISTS idx_genome_priority ON genome(priority DESC)")
conn.execute("ANALYZE")
""".strip(),
            target_files=["db_init.py"],
            effort_hours=1.0,
            risk="low",
        ))

        return preds

    # ── Integration ───────────────────────────────────────────────────────────

    def _integration_predictions(self, snap: SystemSnapshot) -> List[Prediction]:
        preds = []

        unregistered = [
            g for g in snap.capability_gaps if "UNREGISTERED BLUEPRINT" in g
        ]
        for gap in unregistered:
            m = re.search(r'UNREGISTERED BLUEPRINT: (\w+)', gap)
            if m:
                bp = m.group(1)
                preds.append(Prediction(
                    title=f"Register {bp} in app.py — Routes Currently Unreachable",
                    category="integration",
                    summary=f"{bp} is defined but not registered. All its routes return 404.",
                    rationale=gap,
                    steps=[
                        f"1. Find the module that defines {bp}",
                        f"2. Add 'from <module> import {bp}' to app.py",
                        f"3. Add 'app.register_blueprint({bp})' to app.py",
                        "4. Verify with: curl http://localhost:8080/api/health",
                    ],
                    code_patch=f"# In app.py:\nfrom zeus_prediction_engine import {bp}\napp.register_blueprint({bp})",
                    target_files=["app.py"],
                    effort_hours=0.25,
                    risk="low",
                ))

        # Recursive learner → prediction wiring
        preds.append(Prediction(
            title="Wire Recursive Learner Completion → Prediction Engine Trigger",
            category="integration",
            summary="After each learner cycle completes, automatically run the prediction "
                     "engine so predictions stay fresh with latest knowledge.",
            rationale=(
                f"After {snap.learner_cycles} cycles, Zeus's knowledge has evolved but "
                f"predictions were never refreshed. Stale predictions lead to wrong "
                f"evolution priorities."
            ),
            steps=[
                "1. At end of learner cycle in zeus_recursive_learner.py: call _trigger_prediction()",
                "2. _trigger_prediction(): POST /api/prediction/run with auto_queue=False",
                "3. Alternatively use EventBus: emit('learner_cycle_complete', {...})",
                "4. Prediction engine subscribes and re-runs within 60 seconds",
            ],
            code_patch="""
# In zeus_recursive_learner.py — add at end of run_cycle():
def _trigger_prediction_refresh():
    try:
        import requests
        requests.post("http://localhost:8080/api/prediction/run",
                      json={"auto_queue": False, "reason": "learner_cycle_complete"},
                      timeout=5)
    except Exception as e:
        log.debug(f"[Learner] Prediction trigger: {e}")

threading.Thread(target=_trigger_prediction_refresh, daemon=True).start()
""".strip(),
            target_files=["zeus_recursive_learner.py", "zeus_prediction_engine.py"],
            effort_hours=1.5,
            risk="low",
        ))

        return preds


# ═══════════════════════════════════════════════════════════════════════════ #
#  EVOLUTIONARY PLANNER — sequences predictions into a roadmap                #
# ═══════════════════════════════════════════════════════════════════════════ #

class EvolutionaryPlanner:
    """
    Takes a ranked list of predictions and groups them into a sequenced
    evolution roadmap: immediate / this week / this month.
    """

    def plan(self, predictions: List[Prediction]) -> Dict:
        immediate   = [p for p in predictions if p.risk == "low"  and p.effort_hours <= 2][:5]
        this_week   = [p for p in predictions if p.risk in ("low","medium") and p not in immediate][:8]
        this_month  = [p for p in predictions if p not in immediate and p not in this_week][:10]

        total_impact = sum(p.impact.total for p in predictions[:10])

        return {
            "summary": f"Top {len(predictions)} predictions. "
                       f"Immediate wins: {len(immediate)}. "
                       f"Weekly targets: {len(this_week)}. "
                       f"Monthly roadmap: {len(this_month)}.",
            "combined_impact_top10": round(total_impact, 2),
            "phases": {
                "immediate": [{"rank": p.rank, "title": p.title,
                                "impact": p.impact.total, "effort_h": p.effort_hours}
                              for p in immediate],
                "this_week": [{"rank": p.rank, "title": p.title,
                                "impact": p.impact.total, "effort_h": p.effort_hours}
                              for p in this_week],
                "this_month":[{"rank": p.rank, "title": p.title,
                                "impact": p.impact.total, "effort_h": p.effort_hours}
                              for p in this_month],
            },
            "critical_repairs": [
                {"rank": p.rank, "title": p.title}
                for p in predictions if p.category == "repair"
            ],
        }


# ═══════════════════════════════════════════════════════════════════════════ #
#  SELF INSTALLER                                                              #
# ═══════════════════════════════════════════════════════════════════════════ #

class SelfInstaller:
    """
    Wires zeus_prediction_engine.py into the live Zeus system with zero
    manual code changes required anywhere else.
    """

    APP_PATH       = os.path.join(ZEUS_DIR, "app.py")
    SCHEDULER_PATH = os.path.join(ZEUS_DIR, "zeus_nightly_scheduler.py")
    LEARNER_PATH   = os.path.join(ZEUS_DIR, "zeus_recursive_learner.py")
    DB_INIT_PATH   = os.path.join(ZEUS_DIR, "db_init.py")

    def install(self) -> Dict[str, Any]:
        results = {}
        results["db_schema"]  = self._install_db_schema()
        results["app_py"]     = self._inject_app_py()
        results["scheduler"]  = self._inject_scheduler()
        results["learner"]    = self._inject_learner()
        results["first_scan"] = self._run_first_scan()
        return results

    def _install_db_schema(self) -> str:
        try:
            conn = _db()
            conn.execute("""CREATE TABLE IF NOT EXISTS predictions (
                id TEXT PRIMARY KEY,
                title TEXT, category TEXT, rank INTEGER,
                summary TEXT, rationale TEXT,
                steps TEXT,           -- JSON array
                code_patch TEXT,
                target_files TEXT,    -- JSON array
                impact_total REAL, impact_json TEXT,
                second_order TEXT,    -- JSON array
                third_order TEXT,     -- JSON array
                effort_hours REAL, risk TEXT,
                created_at TEXT, status TEXT DEFAULT 'pending',
                run_id TEXT
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS prediction_runs (
                id TEXT PRIMARY KEY,
                started_at TEXT, completed_at TEXT,
                snapshot_metrics TEXT,  -- JSON
                prediction_count INTEGER,
                top_prediction_title TEXT,
                top_impact REAL,
                roadmap TEXT            -- JSON
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS prediction_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prediction_id TEXT,
                metrics_before TEXT, metrics_after TEXT, delta TEXT,
                applied_at TEXT, measured_at TEXT
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS llm_outcomes (
                id TEXT PRIMARY KEY,
                model TEXT, task_class TEXT,
                latency_ms INTEGER, success INTEGER,
                tokens INTEGER, ts TEXT
            )""")
            # Indexes
            conn.execute("CREATE INDEX IF NOT EXISTS idx_predictions_rank ON predictions(rank)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_predictions_status ON predictions(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_predictions_run ON predictions(run_id)")
            conn.commit()
            conn.close()
            return "ok"
        except Exception as e:
            return f"error: {e}"

    def _inject_app_py(self) -> str:
        if not os.path.isfile(self.APP_PATH):
            return "app.py not found"
        try:
            src = Path(self.APP_PATH).read_text(encoding="utf-8")
            if "prediction_bp" in src:
                return "already_registered"

            # Find import block end
            import_line = "from zeus_prediction_engine import prediction_bp"
            reg_line    = "app.register_blueprint(prediction_bp)"

            # Insert import after last zeus import
            last_zeus = 0
            for i, line in enumerate(src.splitlines()):
                if re.match(r'^from zeus_|^import zeus_', line):
                    last_zeus = i
            lines = src.splitlines()
            lines.insert(last_zeus + 1, import_line)

            # Insert register_blueprint after last register_blueprint call
            reg_idx = 0
            for i, line in enumerate(lines):
                if "register_blueprint" in line:
                    reg_idx = i
            lines.insert(reg_idx + 1, reg_line)

            new_src = "\n".join(lines)
            # Backup
            shutil.copy(self.APP_PATH, self.APP_PATH + ".pred_backup")
            Path(self.APP_PATH).write_text(new_src, encoding="utf-8")

            # Validate
            ast.parse(new_src)
            return "injected"
        except SyntaxError as e:
            # Restore backup
            if os.path.isfile(self.APP_PATH + ".pred_backup"):
                shutil.copy(self.APP_PATH + ".pred_backup", self.APP_PATH)
            return f"syntax_error_restored: {e}"
        except Exception as e:
            return f"error: {e}"

    def _inject_scheduler(self) -> str:
        sched = self.SCHEDULER_PATH
        if not os.path.isfile(sched):
            # Create minimal scheduler if missing
            try:
                stub = '''# zeus_nightly_scheduler.py — Zeus Evolution Scheduler
# Auto-generated by zeus_prediction_engine.py SelfInstaller

import time, logging, threading, requests
from datetime import datetime, timezone

log = logging.getLogger("zeus.scheduler")

def run_nightly_cycle():
    """Full nightly evolution cycle: learn → predict → mutate."""
    log.info("[Scheduler] Starting nightly cycle")
    steps = []

    # Step 1: Trigger learner
    try:
        r = requests.post("http://localhost:8080/api/learner/run",
                          json={"batch": 200}, timeout=300)
        steps.append({"learner": r.json().get("status","unknown")})
    except Exception as e:
        steps.append({"learner": f"error: {e}"})

    # Step 2: Run predictions
    try:
        r = requests.post("http://localhost:8080/api/prediction/run",
                          json={"auto_queue": True, "top_k": 5}, timeout=120)
        steps.append({"prediction": r.json().get("generated", 0)})
    except Exception as e:
        steps.append({"prediction": f"error: {e}"})

    log.info(f"[Scheduler] Nightly cycle complete: {steps}")
    return steps

def schedule_loop():
    while True:
        now = datetime.now(timezone.utc)
        if now.hour == 3 and now.minute < 5:
            run_nightly_cycle()
            time.sleep(300)   # avoid double-trigger
        time.sleep(60)

def start():
    t = threading.Thread(target=schedule_loop, daemon=True)
    t.start()
    log.info("[Scheduler] Nightly scheduler started — runs at 03:00 UTC")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_nightly_cycle()
'''
                Path(sched).write_text(stub, encoding="utf-8")
                return "created"
            except Exception as e:
                return f"create_error: {e}"

        try:
            src = Path(sched).read_text(encoding="utf-8")
            if "prediction" in src.lower():
                return "already_wired"
            # Append prediction call
            addition = '''
# === Auto-injected by zeus_prediction_engine SelfInstaller ===
def _trigger_predictions():
    try:
        import requests
        r = requests.post("http://localhost:8080/api/prediction/run",
                          json={"auto_queue": True, "top_k": 5}, timeout=120)
        return r.json()
    except Exception as e:
        return {"error": str(e)}
# === End injection ===
'''
            shutil.copy(sched, sched + ".pred_backup")
            Path(sched).write_text(src + addition, encoding="utf-8")
            return "wired"
        except Exception as e:
            return f"error: {e}"

    def _inject_learner(self) -> str:
        if not os.path.isfile(self.LEARNER_PATH):
            return "learner_not_found"
        try:
            src = Path(self.LEARNER_PATH).read_text(encoding="utf-8")
            if "_trigger_prediction_refresh" in src:
                return "already_wired"
            addition = '''
# === Auto-injected by zeus_prediction_engine SelfInstaller ===
def _trigger_prediction_refresh():
    """Called after each learner cycle to keep predictions fresh."""
    try:
        import requests, threading
        def _call():
            try:
                requests.post("http://localhost:8080/api/prediction/run",
                              json={"auto_queue": False, "reason": "learner_cycle_complete"},
                              timeout=10)
            except Exception: pass
        threading.Thread(target=_call, daemon=True).start()
    except Exception as e:
        pass
# === End injection ===
'''
            shutil.copy(self.LEARNER_PATH, self.LEARNER_PATH + ".pred_backup")
            Path(self.LEARNER_PATH).write_text(src + addition, encoding="utf-8")
            return "wired"
        except Exception as e:
            return f"error: {e}"

    def _run_first_scan(self) -> Dict:
        try:
            scanner = SystemStateScanner()
            snap    = scanner.scan()
            return {
                "genome":    snap.genome_count,
                "knowledge": snap.knowledge_count,
                "queue":     snap.queue_pending,
                "loc":       snap.total_loc,
                "gaps":      len(snap.capability_gaps),
                "bottlenecks": len(snap.bottlenecks),
            }
        except Exception as e:
            return {"error": str(e)}


# ═══════════════════════════════════════════════════════════════════════════ #
#  DEEP SELF-IMPROVEMENT PIPELINE                                             #
# (replaces the thin SelfImprovementHook.trigger() from v3)                  #
# ═══════════════════════════════════════════════════════════════════════════ #

class DeepSelfImprovement:
    """
    Executes the full pipeline described in the /api/synthesis/self_improve
    curl payload:
      - Scan every file, folder, genome, knowledge article, queue item
      - Map full architecture and capabilities
      - Generate concrete improvements across ALL components
      - Seed mutator with high-priority targets
      - Save genome + knowledge records
      - Return structured report
    """

    def run(self, instructions: str) -> Dict:
        report: Dict[str, Any] = {
            "started_at": datetime.now(timezone.utc).isoformat(),
            "instructions_length": len(instructions),
        }

        # 1. Full system scan
        scanner = SystemStateScanner()
        snap    = scanner.scan()
        report["snapshot"] = snap.metrics

        # 2. Generate predictions
        engine      = PredictionEngine()
        predictions = engine.generate(snap)
        report["predictions_generated"] = len(predictions)
        report["top_predictions"] = [
            {"rank": p.rank, "title": p.title, "impact": p.impact.total, "category": p.category}
            for p in predictions[:10]
        ]

        # 3. Build roadmap
        planner = EvolutionaryPlanner()
        roadmap = planner.plan(predictions)
        report["roadmap"] = roadmap

        # 4. Save all predictions to DB
        run_id = uuid.uuid4().hex
        _save_predictions(predictions, run_id, snap)
        report["run_id"] = run_id

        # 5. Seed mutator with top predictions
        seeds = []
        for p in predictions[:15]:
            seeds.append({
                "topic":    f"prediction:{p.category}:{p.title[:80]}",
                "source":   f"prediction:{p.id}",
                "priority": min(2.0, 1.0 + p.impact.total / 10.0),
                "depth":    "Expert",
                "payload":  p.code_patch[:3000],
            })

        # Also seed from gaps and bottlenecks
        for gap in snap.capability_gaps[:10]:
            seeds.append({
                "topic":    f"zeus_gap:{gap[:100]}",
                "source":   "prediction:gap_analysis",
                "priority": 1.8,
                "depth":    "Advanced",
            })
        for bn in snap.bottlenecks[:5]:
            seeds.append({
                "topic":    f"zeus_bottleneck:{bn[:100]}",
                "source":   "prediction:bottleneck_analysis",
                "priority": 1.6,
                "depth":    "Advanced",
            })

        # Seed from every scanned directory
        for ds in snap.dir_stats:
            if ds.exists and ds.file_count > 0:
                seeds.append({
                    "topic":    f"zeus_dir:{ds.name} ({ds.file_count} files, {ds.total_bytes//1024}KB)",
                    "source":   "prediction:dir_scan",
                    "priority": 1.2,
                    "depth":    "Professional",
                })

        mutator_result = _fire_mutator(seeds)
        report["mutator_seeds"] = len(seeds)
        report["mutator_status"] = mutator_result

        # 6. Save knowledge record
        knowledge_content = (
            f"Deep self-improvement run: {run_id}\n"
            f"Instructions: {instructions[:500]}\n"
            f"Genome: {snap.genome_count}, Knowledge: {snap.knowledge_count}, "
            f"Queue: {snap.queue_pending}, LOC: {snap.total_loc}\n"
            f"Gaps: {snap.capability_gaps}\n"
            f"Bottlenecks: {snap.bottlenecks}\n"
            f"Top predictions: {[p.title for p in predictions[:10]]}\n"
            f"Roadmap summary: {roadmap.get('summary','')}\n"
        )
        _save_knowledge(run_id, knowledge_content)
        report["completed_at"] = datetime.now(timezone.utc).isoformat()

        # 7. Save report to disk
        report_path = os.path.join(PRED_DIR, f"deep_improvement_{run_id[:8]}.json")
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2, default=str)
        report["report_path"] = report_path

        return report


# ═══════════════════════════════════════════════════════════════════════════ #
#  DB HELPERS                                                                 #
# ═══════════════════════════════════════════════════════════════════════════ #

def _db():
    from db_init import get_db
    return get_db()

def _save_predictions(predictions: List[Prediction], run_id: str, snap: SystemSnapshot):
    try:
        conn = _db()
        run_ts = datetime.now(timezone.utc).isoformat()
        top    = predictions[0] if predictions else None
        conn.execute("""INSERT OR REPLACE INTO prediction_runs
            (id, started_at, completed_at, snapshot_metrics, prediction_count,
             top_prediction_title, top_impact, roadmap)
            VALUES(?,?,?,?,?,?,?,?)""",
            (run_id, run_ts, run_ts,
             json.dumps(snap.metrics), len(predictions),
             top.title if top else "", top.impact.total if top else 0.0, "{}"))
        for p in predictions:
            conn.execute("""INSERT OR REPLACE INTO predictions
                (id,title,category,rank,summary,rationale,steps,code_patch,
                 target_files,impact_total,impact_json,second_order,third_order,
                 effort_hours,risk,created_at,status,run_id)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (p.id, p.title, p.category, p.rank, p.summary, p.rationale,
                 json.dumps(p.steps), p.code_patch,
                 json.dumps(p.target_files), p.impact.total,
                 json.dumps(p.impact.__dict__),
                 json.dumps([e.__dict__ for e in p.second_order]),
                 json.dumps(p.third_order),
                 p.effort_hours, p.risk, p.created_at, p.status, run_id))
        conn.commit()
        conn.close()
    except Exception as e:
        log.error(f"[Prediction] Save failed: {e}")

def _fire_mutator(seeds: List[Dict]) -> str:
    try:
        from zeus_mutator import get_engine
        get_engine().mutate(seeds, source="prediction_engine", use_ai=True, priority=1.9)
        return f"ok:{len(seeds)}_seeds"
    except Exception as e:
        log.warning(f"[Prediction] Mutator: {e}")
        return f"error:{e}"

def _save_knowledge(run_id: str, content: str):
    try:
        conn = _db()
        conn.execute("""INSERT OR IGNORE INTO knowledge
            (topic,depth,content,source_url,confidence)
            VALUES(?,?,?,?,?)""",
            (f"prediction_run:{run_id}", "Expert", content[:20000],
             f"prediction:{run_id}", 0.92))
        conn.commit()
        conn.close()
    except Exception as e:
        log.warning(f"[Prediction] Knowledge: {e}")


# ═══════════════════════════════════════════════════════════════════════════ #
#  FLASK API ROUTES                                                           #
# ═══════════════════════════════════════════════════════════════════════════ #

@prediction_bp.route("/api/prediction/run", methods=["POST"])
def prediction_run():
    """Full system scan + prediction generation. The main entry point."""
    data       = request.get_json(silent=True) or {}
    auto_queue = data.get("auto_queue", False)
    top_k      = int(data.get("top_k", 5))
    reason     = data.get("reason", "manual")

    run_id = uuid.uuid4().hex
    def _run():
        try:
            scanner     = SystemStateScanner()
            snap        = scanner.scan()
            engine      = PredictionEngine()
            predictions = engine.generate(snap)
            planner     = EvolutionaryPlanner()
            roadmap     = planner.plan(predictions)
            _save_predictions(predictions, run_id, snap)

            if auto_queue and predictions:
                seeds = [{"topic": f"prediction:{p.category}:{p.title[:80]}",
                          "source": f"prediction:{p.id}",
                          "priority": min(2.0, 1.0 + p.impact.total / 10.0),
                          "depth": "Expert",
                          "payload": p.code_patch[:2000]}
                         for p in predictions[:top_k]]
                _fire_mutator(seeds)

            _save_knowledge(run_id, json.dumps(snap.metrics))
            log.info(f"[Prediction] Run {run_id}: {len(predictions)} predictions generated")
        except Exception as e:
            log.error(f"[Prediction] Run failed: {e}", exc_info=True)

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"status": "running", "run_id": run_id, "reason": reason,
                    "poll": f"/api/prediction/run/{run_id}"})


@prediction_bp.route("/api/prediction/run/<run_id>")
def prediction_run_status(run_id):
    try:
        conn = _db()
        row  = conn.execute(
            "SELECT * FROM prediction_runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            conn.close()
            return jsonify({"status": "pending_or_not_found"}), 202
        top_preds = conn.execute(
            "SELECT id,title,category,rank,impact_total,risk,effort_hours,status "
            "FROM predictions WHERE run_id=? ORDER BY rank LIMIT 20",
            (run_id,)).fetchall()
        conn.close()
        result = dict(row)
        result["snapshot_metrics"] = json.loads(result.get("snapshot_metrics") or "{}")
        result["predictions"]      = [dict(p) for p in top_preds]
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@prediction_bp.route("/api/prediction/list")
def prediction_list():
    try:
        limit  = int(request.args.get("limit", 50))
        status = request.args.get("status", "")
        conn   = _db()
        where  = "WHERE status=?" if status else ""
        args   = (status, limit) if status else (limit,)
        rows   = conn.execute(
            f"SELECT id,title,category,rank,impact_total,risk,effort_hours,status,created_at "
            f"FROM predictions {where} ORDER BY rank LIMIT ?", args).fetchall()
        conn.close()
        return jsonify({"predictions": [dict(r) for r in rows], "count": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@prediction_bp.route("/api/prediction/<pred_id>")
def prediction_detail(pred_id):
    try:
        conn = _db()
        row  = conn.execute("SELECT * FROM predictions WHERE id=?", (pred_id,)).fetchone()
        conn.close()
        if not row:
            return jsonify({"error": "not found"}), 404
        r = dict(row)
        for k in ("steps","target_files","impact_json","second_order","third_order"):
            r[k] = json.loads(r.get(k) or "[]")
        return jsonify(r)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@prediction_bp.route("/api/prediction/<pred_id>/approve", methods=["POST"])
def prediction_approve(pred_id):
    """Mark a prediction as approved and optionally auto-apply its code patch."""
    data       = request.get_json(silent=True) or {}
    auto_apply = data.get("auto_apply", False)
    try:
        conn = _db()
        conn.execute("UPDATE predictions SET status='approved' WHERE id=?", (pred_id,))
        conn.commit()
        row  = conn.execute("SELECT * FROM predictions WHERE id=?", (pred_id,)).fetchone()
        conn.close()
        if not row:
            return jsonify({"error": "not found"}), 404
        result = {"status": "approved", "id": pred_id}
        if auto_apply and row["code_patch"]:
            targets = json.loads(row["target_files"] or "[]")
            apply_results = {}
            for target in targets:
                fp = os.path.join(ZEUS_DIR, target)
                if os.path.isfile(fp):
                    ok = _safe_apply_patch(fp, row["code_patch"], pred_id)
                    apply_results[target] = "applied" if ok else "failed"
                else:
                    apply_results[target] = "file_not_found"
            result["apply_results"] = apply_results
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@prediction_bp.route("/api/prediction/snapshot")
def prediction_snapshot():
    """Return a fresh system snapshot without generating predictions."""
    try:
        snap = SystemStateScanner().scan()
        return jsonify({
            "metrics":      snap.metrics,
            "gaps":         snap.capability_gaps,
            "bottlenecks":  snap.bottlenecks,
            "blueprints":   snap.active_blueprints,
            "components":   [
                {"name": c.name, "exists": c.exists, "loc": c.loc,
                 "functions": c.functions, "maturity": c.maturity,
                 "issues": c.issues[:3]}
                for c in snap.components
            ],
            "dirs": [
                {"name": d.name, "exists": d.exists, "files": d.file_count,
                 "mb": round(d.total_bytes / 1024 / 1024, 2)}
                for d in snap.dir_stats
            ],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@prediction_bp.route("/api/prediction/deep_improve", methods=["POST"])
def prediction_deep_improve():
    """
    Full deep self-improvement pipeline.
    This is the endpoint that handles the aggressive self-improve curl command.
    Scans every file, folder, genome, knowledge article, queue item, then
    generates concrete improvements and seeds the mutator.
    """
    data         = request.get_json(silent=True) or {}
    instructions = (data.get("instructions") or "").strip()
    if not instructions:
        return jsonify({"error": "instructions required"}), 400

    run_id = uuid.uuid4().hex
    def _run():
        dsi = DeepSelfImprovement()
        try:
            result = dsi.run(instructions)
            conn   = _db()
            conn.execute(
                "INSERT OR REPLACE INTO prediction_runs(id,started_at,completed_at,"
                "snapshot_metrics,prediction_count,top_prediction_title,top_impact,roadmap) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (run_id,
                 result.get("started_at",""), result.get("completed_at",""),
                 json.dumps(result.get("snapshot",{})),
                 result.get("predictions_generated",0),
                 (result.get("top_predictions") or [{}])[0].get("title",""),
                 (result.get("top_predictions") or [{"impact":0}])[0].get("impact",0.0),
                 json.dumps(result.get("roadmap",{}))))
            conn.commit(); conn.close()
            log.info(f"[Prediction] Deep improve {run_id} complete")
        except Exception as e:
            log.error(f"[Prediction] Deep improve failed: {e}", exc_info=True)

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({
        "status": "running",
        "run_id": run_id,
        "message": "Deep self-improvement pipeline started. "
                   "Scanning all files, genome, knowledge, queue, and directories.",
        "poll": f"/api/prediction/run/{run_id}",
    })


@prediction_bp.route("/api/prediction/install", methods=["POST"])
def prediction_install():
    """Run the self-installer to wire this module into app.py, scheduler, and learner."""
    results = SelfInstaller().install()
    return jsonify({"status": "complete", "results": results})


@prediction_bp.route("/api/prediction/roadmap")
def prediction_roadmap():
    """Latest roadmap from the most recent prediction run."""
    try:
        conn = _db()
        run  = conn.execute(
            "SELECT id FROM prediction_runs ORDER BY started_at DESC LIMIT 1").fetchone()
        if not run:
            conn.close()
            return jsonify({"error": "no runs yet — POST /api/prediction/run first"}), 404
        preds_rows = conn.execute(
            "SELECT id,title,category,rank,impact_total,risk,effort_hours,status "
            "FROM predictions WHERE run_id=? ORDER BY rank", (run["id"],)).fetchall()
        conn.close()
        preds = [Prediction(
            id=r["id"], title=r["title"], category=r["category"], rank=r["rank"],
            effort_hours=r["effort_hours"], risk=r["risk"],
            impact=ImpactScore(total=r["impact_total"])
        ) for r in preds_rows]
        planner = EvolutionaryPlanner()
        roadmap  = planner.plan(preds)
        return jsonify({"run_id": run["id"], "roadmap": roadmap})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ═══════════════════════════════════════════════════════════════════════════ #
#  PATCH APPLIER                                                              #
# ═══════════════════════════════════════════════════════════════════════════ #

def _safe_apply_patch(target_file: str, patch_content: str, pred_id: str) -> bool:
    """Append patch to file with backup and validation. Roll back on any failure."""
    backup = target_file + f".bak_{pred_id[:8]}"
    try:
        shutil.copy(target_file, backup)
        # Validate the patch is valid Python
        ast.parse(patch_content)
        # Append
        with open(target_file, "a", encoding="utf-8") as f:
            f.write(f"\n\n# === Auto-applied patch {pred_id} by zeus_prediction_engine ===\n")
            f.write(patch_content)
            f.write(f"\n# === End patch {pred_id} ===\n")
        # Smoke test full file
        result = __import__("subprocess").run(
            ["python3", "-m", "py_compile", target_file],
            capture_output=True, text=True, timeout=15)
        if result.returncode != 0:
            shutil.copy(backup, target_file)
            log.warning(f"[Patch] Smoke test failed for {target_file}: {result.stderr[:200]}")
            return False
        os.remove(backup)
        log.info(f"[Patch] Applied {pred_id} to {target_file}")
        return True
    except SyntaxError as e:
        log.warning(f"[Patch] Patch SyntaxError for {pred_id}: {e}")
        if os.path.exists(backup):
            shutil.copy(backup, target_file)
        return False
    except Exception as e:
        log.warning(f"[Patch] Apply error for {pred_id}: {e}")
        if os.path.exists(backup):
            shutil.copy(backup, target_file)
        return False


# ═══════════════════════════════════════════════════════════════════════════ #
#  ENSURE DB SCHEMA ON IMPORT                                                 #
# ═══════════════════════════════════════════════════════════════════════════ #

def _bootstrap_schema():
    try:
        conn = _db()
        for stmt in [
            """CREATE TABLE IF NOT EXISTS predictions (
                id TEXT PRIMARY KEY, title TEXT, category TEXT, rank INTEGER,
                summary TEXT, rationale TEXT, steps TEXT, code_patch TEXT,
                target_files TEXT, impact_total REAL, impact_json TEXT,
                second_order TEXT, third_order TEXT, effort_hours REAL,
                risk TEXT, created_at TEXT, status TEXT DEFAULT 'pending', run_id TEXT)""",
            """CREATE TABLE IF NOT EXISTS prediction_runs (
                id TEXT PRIMARY KEY, started_at TEXT, completed_at TEXT,
                snapshot_metrics TEXT, prediction_count INTEGER,
                top_prediction_title TEXT, top_impact REAL, roadmap TEXT)""",
            """CREATE TABLE IF NOT EXISTS prediction_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT, prediction_id TEXT,
                metrics_before TEXT, metrics_after TEXT, delta TEXT,
                applied_at TEXT, measured_at TEXT)""",
            """CREATE TABLE IF NOT EXISTS llm_outcomes (
                id TEXT PRIMARY KEY, model TEXT, task_class TEXT,
                latency_ms INTEGER, success INTEGER, tokens INTEGER, ts TEXT)""",
            "CREATE INDEX IF NOT EXISTS idx_predictions_rank   ON predictions(rank)",
            "CREATE INDEX IF NOT EXISTS idx_predictions_status ON predictions(status)",
            "CREATE INDEX IF NOT EXISTS idx_predictions_run    ON predictions(run_id)",
            "CREATE INDEX IF NOT EXISTS idx_queue_priority ON learning_queue(status, priority DESC)",
            "CREATE INDEX IF NOT EXISTS idx_knowledge_conf ON knowledge(confidence DESC)",
            "CREATE INDEX IF NOT EXISTS idx_knowledge_topic ON knowledge(topic)",
            "CREATE INDEX IF NOT EXISTS idx_genome_priority ON genome(priority DESC)",
        ]:
            try:   conn.execute(stmt)
            except Exception: pass
        conn.commit()
        conn.close()
    except Exception as e:
        log.warning(f"[Prediction] Bootstrap schema: {e}")

_bootstrap_schema()


# ═══════════════════════════════════════════════════════════════════════════ #
#  SELF-INSTALLATION ENTRY POINT                                              #
#  python3 zeus_prediction_engine.py                                          #
# ═══════════════════════════════════════════════════════════════════════════ #

if __name__ == "__main__":
    import sys
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    )

    print("\n" + "═" * 70)
    print("  ZEUS PREDICTION ENGINE v1.0 — Self-Installation")
    print("═" * 70)

    # Step 1: DB
    print("\n[1/5] Installing DB schema...")
    installer = SelfInstaller()
    db_result = installer._install_db_schema()
    print(f"      DB schema: {db_result}")

    # Step 2: app.py injection
    print("\n[2/5] Injecting blueprint into app.py...")
    app_result = installer._inject_app_py()
    print(f"      app.py: {app_result}")

    # Step 3: Scheduler
    print("\n[3/5] Wiring into nightly scheduler...")
    sched_result = installer._inject_scheduler()
    print(f"      Scheduler: {sched_result}")

    # Step 4: Learner
    print("\n[4/5] Wiring into recursive learner...")
    learner_result = installer._inject_learner()
    print(f"      Learner: {learner_result}")

    # Step 5: First scan
    print("\n[5/5] Running first full system scan...")
    scanner = SystemStateScanner()
    snap    = scanner.scan()
    print(f"\n      {'─'*60}")
    print(f"      Genome entries:      {snap.genome_count:>10,}")
    print(f"      Knowledge articles:  {snap.knowledge_count:>10,}")
    print(f"      Queue pending:       {snap.queue_pending:>10,}")
    print(f"      Queue done:          {snap.queue_done:>10,}")
    print(f"      Synthesis jobs:      {snap.synthesis_jobs:>10,}")
    print(f"      Learner cycles:      {snap.learner_cycles:>10,}")
    print(f"      Total source LOC:    {snap.total_loc:>10,}")
    print(f"      Active blueprints:   {len(snap.active_blueprints):>10,}")
    print(f"      Capability gaps:     {len(snap.capability_gaps):>10,}")
    print(f"      Bottlenecks:         {len(snap.bottlenecks):>10,}")

    # Gaps
    if snap.capability_gaps:
        print(f"\n      GAPS DETECTED:")
        for g in snap.capability_gaps:
            print(f"        ⚠  {g}")

    # Bottlenecks
    if snap.bottlenecks:
        print(f"\n      BOTTLENECKS:")
        for b in snap.bottlenecks:
            print(f"        ⚡ {b}")

    # Generate predictions
    print(f"\n{'═'*70}")
    print("  GENERATING PREDICTIONS...")
    print(f"{'═'*70}")

    engine      = PredictionEngine()
    predictions = engine.generate(snap)
    planner     = EvolutionaryPlanner()
    roadmap     = planner.plan(predictions)
    run_id      = uuid.uuid4().hex
    _save_predictions(predictions, run_id, snap)

    print(f"\n  {len(predictions)} predictions generated. Top 10 by impact:\n")
    for p in predictions[:10]:
        risk_icon = {"low": "🟢", "medium": "🟡", "high": "🔴"}.get(p.risk, "⚪")
        print(f"  #{p.rank:>2}  {risk_icon} [{p.category:>12}]  "
              f"impact={p.impact.total:>6.2f}  {p.effort_hours:>4.1f}h  "
              f"{p.title[:55]}")

    print(f"\n{'═'*70}")
    print("  EVOLUTION ROADMAP")
    print(f"{'═'*70}")
    print(f"\n  {roadmap['summary']}")
    print(f"  Combined impact (top 10): {roadmap['combined_impact_top10']}")

    print(f"\n  IMMEDIATE WINS (deploy today):")
    for item in roadmap["phases"]["immediate"]:
        print(f"    #{item['rank']}  {item['title'][:60]}")

    if roadmap["phases"]["this_week"]:
        print(f"\n  THIS WEEK:")
        for item in roadmap["phases"]["this_week"][:5]:
            print(f"    #{item['rank']}  {item['title'][:60]}")

    if roadmap["critical_repairs"]:
        print(f"\n  ⚠  CRITICAL REPAIRS (do these first):")
        for item in roadmap["critical_repairs"]:
            print(f"    #{item['rank']}  {item['title'][:65]}")

    # Save report
    report = {
        "run_id": run_id, "ts": snap.ts,
        "metrics": snap.metrics,
        "gaps": snap.capability_gaps,
        "bottlenecks": snap.bottlenecks,
        "predictions": [p.to_dict() for p in predictions[:20]],
        "roadmap": roadmap,
        "install": {
            "db_schema": db_result, "app_py": app_result,
            "scheduler": sched_result, "learner": learner_result,
        }
    }
    report_path = os.path.join(PRED_DIR, f"prediction_run_{run_id[:8]}.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2, default=str)

    print(f"\n{'═'*70}")
    print(f"  INSTALLATION COMPLETE")
    print(f"{'═'*70}")
    print(f"\n  Run ID:       {run_id}")
    print(f"  Report:       {report_path}")
    print(f"\n  API endpoints now available (after Zeus restart):")
    print(f"    POST /api/prediction/run         — full scan + predictions")
    print(f"    GET  /api/prediction/list         — list all predictions")
    print(f"    GET  /api/prediction/snapshot     — live system snapshot")
    print(f"    GET  /api/prediction/roadmap      — evolution roadmap")
    print(f"    POST /api/prediction/deep_improve — full deep self-improvement")
    print(f"    POST /api/prediction/<id>/approve — approve & optionally auto-apply")
    print(f"    POST /api/prediction/install      — re-run self-installer")
    print(f"\n  Next: restart Zeus and run the nightly deep improve:")
    print(f"    curl -X POST http://localhost:8080/api/prediction/deep_improve \\")
    print(f"      -H 'Content-Type: application/json' \\")
    print(f"      -d '{{\"instructions\":\"full system deep improvement\"}}'")
    print(f"\n{'═'*70}\n")