# tests/conftest.py
# The Zeus Project 2026 — Francois Nel
# Pytest Configuration & Fixtures
# Provides fresh test environment for every test run

import os
import sys
import tempfile
import shutil
import pytest
from pathlib import Path

# BUGFIX: the previous version only added the project root to sys.path.
# The real app.py lives inside SPEARHEAD_CLEAN/ (not the project root),
# and app.py itself does `from db_init import init_db, get_db` — a bare
# sibling import that only resolves if SPEARHEAD_CLEAN itself is on
# sys.path, not just its parent. Confirmed against the actual shipped
# app.py: it has no create_app() factory, just a module-level
# `app = Flask(...)`. Both problems caused every test_health_routes.py
# test to fail with ModuleNotFoundError: No module named 'app'.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_APP_CANDIDATES = [
    _PROJECT_ROOT / "SPEARHEAD_CLEAN",
    _PROJECT_ROOT / "zeus_hive_final_genome_patched" / "zeus_arch",
]
for _candidate in _APP_CANDIDATES:
    if (_candidate / "app.py").exists():
        sys.path.insert(0, str(_candidate))
        break


@pytest.fixture(scope="session")
def app():
    """Load the real Zeus Flask app for testing.

    The real app.py (confirmed by inspection) exposes a module-level
    `app = Flask(...)` object — there is no create_app() factory. It also
    runs `init_db()` at import time, which is idempotent (creates tables
    if they don't already exist) and matches the schema already set up
    by SPEARHEAD_CLEAN/db_init.py during installation.
    """
    os.environ["ZEUS_TESTING"] = "1"
    os.environ["ZEUS_ENV"] = "test"

    try:
        import app as zeus_app_module
    except ModuleNotFoundError as e:
        pytest.skip(
            f"Could not import the Zeus app module (searched: "
            f"{[str(c) for c in _APP_CANDIDATES]}): {e}"
        )

    flask_app = getattr(zeus_app_module, "app", None)
    if flask_app is None:
        pytest.skip(
            "Zeus app module imported successfully but has no 'app' "
            "attribute — check that app.py still defines app = Flask(...)"
        )

    flask_app.config["TESTING"] = True
    yield flask_app


@pytest.fixture
def client(app):
    """Return a test client for the Flask app."""
    return app.test_client()


@pytest.fixture
def runner(app):
    """Return a CLI test runner."""
    return app.test_cli_runner()


@pytest.fixture
def db_temp():
    """Create a temporary database for testing."""
    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    temp_db_path = temp_db.name
    temp_db.close()
    
    yield temp_db_path
    
    # Cleanup
    if os.path.exists(temp_db_path):
        try:
            os.unlink(temp_db_path)
        except:
            pass


@pytest.fixture
def sample_genome_data():
    """Sample data for genome tests."""
    return {
        "name": "test_genome_001",
        "description": "Test genome for unit testing",
        "module_type": "core",
        "source_code": """
def analyze_data(data):
    '''Analyze input data and return results.'''
    if not data:
        return {"status": "empty"}
    return {"status": "ok", "count": len(data)}
""",
        "capabilities": "testing,analysis,data",
        "priority": 100,
        "author": "test_suite"
    }


@pytest.fixture
def sample_test_genome():
    """Sample genome with working Python code."""
    return {
        "name": "fitness_test_genome",
        "module_type": "utility",
        "source_code": """
def add(a, b):
    '''Add two numbers.'''
    return a + b

def multiply(a, b):
    '''Multiply two numbers.'''
    return a * b

def calculate(x, y, op='add'):
    '''Calculate using specified operation.'''
    if op == 'add':
        return add(x, y)
    elif op == 'multiply':
        return multiply(x, y)
    return None
""",
        "capabilities": "math,calculation",
        "priority": 95
    }


@pytest.fixture
def health_check_endpoints():
    """List of common health check endpoints to test."""
    return [
        "/health",
        "/api/health",
        "/api/v1/health",
        "/status",
        "/api/status",
    ]
