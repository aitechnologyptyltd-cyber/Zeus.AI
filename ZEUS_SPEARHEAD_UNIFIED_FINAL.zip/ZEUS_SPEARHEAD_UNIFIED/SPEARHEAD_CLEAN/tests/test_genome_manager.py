# tests/test_genome_manager.py
# The Zeus Project 2026 — Francois Nel
# Unit Tests for Genome Manager (DNA Registry)

import pytest
import json


class TestGenomeBasics:
    """Test basic genome manager operations."""
    
    def test_genome_data_structure(self, sample_genome_data):
        """Verify genome data has required fields."""
        required_fields = ["name", "module_type", "source_code"]
        
        for field in required_fields:
            assert field in sample_genome_data, \
                f"Sample genome missing required field: {field}"
    
    def test_genome_name_validation(self):
        """Test genome name validation."""
        # Valid names
        valid_names = [
            "genome_001",
            "test_module",
            "core_logic_v2",
            "analyzer_1",
        ]
        
        for name in valid_names:
            # Names should be alphanumeric with underscores
            assert all(c.isalnum() or c == "_" for c in name), \
                f"Invalid genome name: {name}"
    
    def test_genome_serialization(self, sample_genome_data):
        """Test genome can be serialized to JSON."""
        # Should be JSON serializable
        try:
            json_str = json.dumps(sample_genome_data)
            deserialized = json.loads(json_str)
            assert deserialized == sample_genome_data
        except Exception as e:
            pytest.fail(f"Genome not JSON serializable: {e}")


class TestGenomeCodeQuality:
    """Test code quality analysis for genomes."""
    
    def test_code_syntax_validation(self, sample_test_genome):
        """Verify genome code is syntactically valid Python."""
        import ast
        
        try:
            ast.parse(sample_test_genome["source_code"])
            # Should parse without error
            assert True
        except SyntaxError as e:
            pytest.fail(f"Genome contains invalid Python: {e}")
    
    def test_code_complexity_detection(self, sample_test_genome):
        """Test detection of code complexity metrics."""
        import ast
        
        tree = ast.parse(sample_test_genome["source_code"])
        
        # Count functions
        functions = [node for node in ast.walk(tree) 
                    if isinstance(node, ast.FunctionDef)]
        
        # Should have functions
        assert len(functions) > 0, "Sample genome should have functions"
        
        # Each function should be analyzable
        for func in functions:
            assert hasattr(func, 'name')
            assert hasattr(func, 'body')
    
    def test_code_metrics_calculation(self, sample_test_genome):
        """Test calculation of basic code metrics."""
        lines = sample_test_genome["source_code"].split('\n')
        loc = len([l for l in lines if l.strip() and not l.strip().startswith('#')])
        
        # Should have lines of code
        assert loc > 0, "Genome should have actual code lines"
    
    def test_docstring_detection(self, sample_test_genome):
        """Test detection of function docstrings."""
        import ast
        
        tree = ast.parse(sample_test_genome["source_code"])
        functions = [node for node in ast.walk(tree) 
                    if isinstance(node, ast.FunctionDef)]
        
        # At least one function should have a docstring
        documented = [f for f in functions if ast.get_docstring(f)]
        assert len(documented) > 0, "Sample should have documented functions"


class TestGenomeCapabilities:
    """Test genome capability tracking."""
    
    def test_capability_parsing(self, sample_genome_data):
        """Test parsing of capability strings."""
        capabilities = sample_genome_data.get("capabilities", "")
        
        if capabilities:
            # Should be comma-separated
            caps_list = [c.strip() for c in capabilities.split(',')]
            assert len(caps_list) > 0
            assert all(isinstance(c, str) for c in caps_list)
    
    def test_capability_matching(self, sample_genome_data):
        """Test searching genomes by capability."""
        capabilities = sample_genome_data.get("capabilities", "")
        
        # Should be able to search for capabilities
        if "testing" in capabilities:
            assert True  # Capability found
        
        # Should handle capability queries
        query = "testing"
        assert query in capabilities or "testing" not in capabilities


class TestGenomeFitness:
    """Test genome fitness scoring."""
    
    def test_fitness_score_range(self):
        """Verify fitness scores are in valid range."""
        # Fitness scores should be 0-1 or similar range
        test_scores = [0.0, 0.5, 0.75, 1.0]
        
        for score in test_scores:
            assert 0 <= score <= 1, f"Score {score} out of range"
    
    def test_fitness_components(self):
        """Test components of fitness calculation."""
        # Fitness should consider:
        # - Code quality
        # - Complexity
        # - Performance
        # - Documentation
        
        components = ["quality", "complexity", "performance", "documentation"]
        for component in components:
            # Each should contribute to fitness
            assert isinstance(component, str)
    
    def test_fitness_reproducibility(self, sample_test_genome):
        """Test that fitness score is reproducible."""
        # Same code should produce same fitness score
        import hashlib
        
        code1 = sample_test_genome["source_code"]
        code2 = sample_test_genome["source_code"]
        
        hash1 = hashlib.md5(code1.encode()).hexdigest()
        hash2 = hashlib.md5(code2.encode()).hexdigest()
        
        assert hash1 == hash2, "Code hash should be reproducible"


class TestGenomeSearch:
    """Test genome search and discovery."""
    
    def test_search_by_name(self, sample_genome_data):
        """Test searching genomes by name."""
        name = sample_genome_data["name"]
        
        # Should be able to construct query
        query = f"name:{name}"
        assert name in query
    
    def test_search_by_type(self, sample_genome_data):
        """Test searching by module type."""
        module_type = sample_genome_data["module_type"]
        
        # Should be able to search by type
        assert module_type in ["core", "utility", "extension", "analyzer"]
    
    def test_search_by_capability(self, sample_genome_data):
        """Test searching by capability."""
        capabilities = sample_genome_data.get("capabilities", "").split(',')
        
        if capabilities:
            # Should be able to search by capability
            query_cap = capabilities[0].strip()
            assert len(query_cap) > 0


class TestGenomePersistence:
    """Test genome storage and retrieval."""
    
    def test_genome_storage_schema(self):
        """Test that genome storage schema is valid."""
        schema_fields = [
            "id",
            "name",
            "description",
            "module_type",
            "source_code",
            "capabilities",
            "priority",
            "created_at",
            "fitness_score",
        ]
        
        # All fields should be valid
        for field in schema_fields:
            assert isinstance(field, str)
    
    def test_genome_update_tracking(self):
        """Test that genome updates are tracked."""
        # Should have fields for tracking updates
        tracking_fields = ["created_at", "updated_at", "version"]
        
        for field in tracking_fields:
            assert isinstance(field, str)
    
    def test_genome_deletion_safety(self):
        """Test that genome deletion is safe."""
        # Should implement soft deletes or backups
        # Before deleting a genome, it should be backed up
        
        safety_checks = [
            "backup_before_delete",
            "cascade_delete_check",
            "dependency_check",
        ]
        
        assert len(safety_checks) > 0


class TestGenomeEvolution:
    """Test genome evolution tracking."""
    
    def test_mutation_recording(self):
        """Test that mutations are recorded."""
        mutation_types = [
            "split_function",
            "extract_module",
            "refactor_logic",
            "optimize_performance",
        ]
        
        # All mutation types should be valid
        for mutation in mutation_types:
            assert isinstance(mutation, str)
    
    def test_evolution_history(self):
        """Test tracking of evolution history."""
        # System should track:
        # - Original code
        # - Mutations applied
        # - Fitness improvements
        # - Successful outcomes
        
        history_fields = [
            "original_code",
            "mutations",
            "fitness_history",
            "outcomes",
        ]
        
        assert len(history_fields) == 4
    
    def test_successful_pattern_registration(self):
        """Test registration of successful patterns."""
        # When a mutation is successful, it should be registered
        # as a new genome or pattern variant
        
        registration_info = {
            "pattern": "extracted_function",
            "fitness_improvement": 0.15,
            "reproducibility": True,
        }
        
        assert registration_info["reproducibility"]


# Test execution markers
@pytest.mark.parametrize("genome_type", ["core", "utility", "extension"])
def test_genome_type_validation(genome_type):
    """Test that genome types are valid."""
    valid_types = ["core", "utility", "extension", "analyzer"]
    assert genome_type in valid_types
