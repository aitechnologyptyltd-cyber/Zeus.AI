"""
zeus_drone_geofence_monitor.py
=================================
Zeus Drone ISR — Live Geofence Monitor
The Zeus Project 2026 — additive extension (v2.3)

The piece flagged as not-yet-built in v2.2's spec: something that
actually consumes live telemetry and triggers drone_geofence_breach
(Ring 6) when a mission's reported position falls outside its assigned
geofence — that action type existed in the sovereignty engine since
v2.2 but nothing called it until now.

Design:
  - A mission is "registered" with its Geofence when planning starts
    (the blueprint route does this — see zeus_drone_blueprint.py).
  - Every telemetry sample ingested through
    zeus_drone_telemetry.TelemetryStore.ingest() is also checked here
    against the mission's registered fence.
  - A breach triggers TWO things, in order:
      1. sovereign_execute("drone_geofence_breach", ...) — Ring 6,
         30s human-veto window + AI Council deliberation, written to
         the audit trail like every other Ring 6 action in SPEARHEAD.
      2. An IMMEDIATE safety RTL command issued through
         zeus_drone_command_bridge.CommandBridge — RTL is Ring 4
         (see v2.3's ring classification), so it executes without
         waiting on the Ring 6 deliberation. This ordering is
         deliberate: the safety recovery action must not be gated
         behind the same advisory window that's busy logging/
         escalating the breach itself, or the airframe would keep
         flying further outside the fence while the Council
         deliberates on a question that was never "should it return"
         but "this needs review."
  - Breach state per mission is tracked so a single breach only
    triggers one RTL command + one Ring 6 escalation, not one per
    telemetry sample, while still logging every sample that remains
    outside the fence for audit completeness.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

log = logging.getLogger("zeus.drone_geofence_monitor")


@dataclass
class _MonitoredMission:
    mission_id: str
    geofence: Any            # zeus_drone_coverage.Geofence
    breached: bool = False
    breach_count: int = 0
    last_check_utc: str = ""


class GeofenceMonitor:
    """
    Singleton-style registry + checker. Intended usage:

        monitor = get_monitor()
        monitor.register_mission(mission_id, geofence)
        # ... on every telemetry ingest:
        monitor.check(mission_id, lat, lon, alt_m)

    Wired into zeus_drone_blueprint.py's telemetry-ingest route so
    every sample that already flows through TelemetryStore.ingest()
    is also fence-checked, with no separate polling loop required.
    """

    def __init__(self, command_bridge: Optional[Any] = None):
        self._lock = threading.Lock()
        self._missions: Dict[str, _MonitoredMission] = {}
        self._command_bridge = command_bridge   # zeus_drone_command_bridge.CommandBridge, optional

    def set_command_bridge(self, bridge: Any) -> None:
        self._command_bridge = bridge

    def register_mission(self, mission_id: str, geofence: Any) -> None:
        with self._lock:
            self._missions[mission_id] = _MonitoredMission(mission_id=mission_id, geofence=geofence)
        log.info("[geofence_monitor] registered mission %s under fence %s",
                  mission_id, getattr(geofence, "fence_id", "?"))

    def unregister_mission(self, mission_id: str) -> None:
        with self._lock:
            self._missions.pop(mission_id, None)

    def registered_missions(self) -> List[str]:
        with self._lock:
            return list(self._missions.keys())

    def check(self, mission_id: str, lat: float, lon: float, alt_m: float) -> Dict[str, Any]:
        """
        Checks one position against the mission's registered fence.
        Returns a structured result; no-ops (with a clear reason) if
        the mission was never registered — telemetry for an
        unregistered/ad-hoc mission is not an error, just unmonitored.
        """
        with self._lock:
            mm = self._missions.get(mission_id)
        if mm is None:
            return {"monitored": False, "reason": "MISSION_NOT_REGISTERED_FOR_GEOFENCE_MONITORING"}

        ok, reason = mm.geofence.validate_point(lat, lon, alt_m)
        mm.last_check_utc = datetime.now(timezone.utc).isoformat()

        if ok:
            if mm.breached:
                # Recovered back inside the fence — clear the breach
                # flag so a future excursion triggers fresh escalation.
                log.info("[geofence_monitor] mission %s back inside fence %s",
                          mission_id, mm.geofence.fence_id)
                mm.breached = False
            return {"monitored": True, "inside_fence": True}

        mm.breach_count += 1
        already_escalated = mm.breached
        mm.breached = True

        result = {
            "monitored": True, "inside_fence": False, "reason": reason,
            "breach_count": mm.breach_count, "newly_escalated": not already_escalated,
        }

        if not already_escalated:
            result["escalation"] = self._escalate_breach(mission_id, lat, lon, alt_m, reason)
        else:
            log.debug("[geofence_monitor] mission %s still outside fence (sample logged, "
                      "no re-escalation — already breached)", mission_id)

        return result

    def _escalate_breach(self, mission_id: str, lat: float, lon: float, alt_m: float,
                          reason: str) -> Dict[str, Any]:
        from zeus_sovereignty_engine import sovereign_execute

        log.warning("[geofence_monitor] BREACH: mission %s at (%s, %s, %sm) — %s",
                    mission_id, lat, lon, alt_m, reason)

        gate_result = sovereign_execute(
            "drone_geofence_breach",
            f"Mission {mission_id} left its approved operating boundary: {reason}",
            {"mission_id": mission_id, "lat": lat, "lon": lon, "alt_m": alt_m, "reason": reason},
        )

        rtl_result = None
        if self._command_bridge is not None:
            try:
                rtl = self._command_bridge.return_to_launch(
                    mission_id, reason=f"AUTOMATIC SAFETY RTL — geofence breach: {reason}")
                rtl_result = rtl.to_dict()
            except Exception as e:
                log.error("[geofence_monitor] safety RTL command failed for %s: %s", mission_id, e)
                rtl_result = {"accepted": False, "detail": f"RTL command raised: {e}"}
        else:
            log.warning("[geofence_monitor] no command bridge attached — breach logged and "
                        "escalated to Ring 6, but no automatic RTL was issued for %s", mission_id)

        # ── Hive + Tartarus wiring (v2.4, additive) ──────────────────────────
        # Publish breach into hive bus (dual-source: drone_isr + aegis so it
        # appears on both the drone dashboard and the AEGIS threat stream)
        # and into Tartarus 'patterns' for cross-domain synthesis.
        try:
            from zeus_drone_hive_wire import get_wire
            get_wire().publish_geofence_breach(
                mission_id, lat, lon, alt_m, reason,
                sovereignty_ring=gate_result.get("ring", 6),
            )
        except Exception as _hive_err:
            log.debug("[geofence_monitor] hive wire: %s", _hive_err)
        # ─────────────────────────────────────────────────────────────────────

        return {"sovereignty_gate": gate_result, "safety_rtl": rtl_result}


_monitor_singleton: Optional[GeofenceMonitor] = None
_singleton_lock = threading.Lock()


def get_monitor() -> GeofenceMonitor:
    global _monitor_singleton
    if _monitor_singleton is not None:
        return _monitor_singleton
    with _singleton_lock:
        if _monitor_singleton is None:
            _monitor_singleton = GeofenceMonitor()
        return _monitor_singleton
