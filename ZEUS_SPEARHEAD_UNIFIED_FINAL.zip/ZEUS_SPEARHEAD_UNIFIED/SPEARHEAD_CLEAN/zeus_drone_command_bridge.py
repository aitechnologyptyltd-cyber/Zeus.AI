"""
zeus_drone_command_bridge.py
===============================
Zeus Drone ISR — Airframe Command Bridge
The Zeus Project 2026 — additive extension (v2.3)

This is the piece flagged as not-yet-built in v2.2's spec: a path from
a planned, geofence-validated FlightMission to actually commanding an
airframe. It is deliberately narrow.

COMMAND VOCABULARY — this is the complete list, by design:
  ARM, DISARM, TAKEOFF, GOTO_WAYPOINT, SET_GIMBAL, RETURN_TO_LAUNCH,
  LAND, HOLD, SET_FLIGHT_MODE

There is no WEAPON_*, no PAYLOAD_RELEASE, no FIRE_*, no ENGAGE_TARGET
command anywhere in this vocabulary, and none will be added to it —
this file defines the entire surface this extension can use to talk
to an airframe, and that surface only ever asks the airframe to fly
somewhere, point a camera, or stop/land/return.

TRANSPORT ABSTRACTION:
  AirframeTransport is an abstract interface. Two implementations ship:
    - SimulatorTransport: an in-memory flight model for testing this
      bridge end-to-end with no real hardware (used in this build's
      verification — see the integration spec).
    - MAVLinkTransportStub: defines the exact method surface a real
      pymavlink/MAVSDK integration would implement, but raises
      NotImplementedError on every call. Wiring in a real flight
      controller means implementing this one class against pymavlink —
      nothing else in this codebase needs to change to support it.

Every command issued through CommandBridge.send() is ring-gated via
zeus_sovereignty_engine.sovereign_execute() before it reaches the
transport, exactly like every other Zeus action.
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

log = logging.getLogger("zeus.drone_command")

# Ring classification for airframe commands. ARM/TAKEOFF/GOTO are
# Ring 5 (Full Auto, non-destructive, already-validated mission
# execution — same tier as drone_mission_execute in zeus_drone_coverage.py).
# RTL/LAND/HOLD are Ring 4 (Zeus process adaptation tier) — they are
# safety/de-escalation commands, deliberately classified BELOW the
# commands that send the airframe further out, so a safety action is
# never blocked behind a higher gate than the action it's recovering from.
DRONE_COMMAND_RING_TYPES = {
    "drone_command_arm":          5,
    "drone_command_takeoff":      5,
    "drone_command_goto":         5,
    "drone_command_set_gimbal":   5,
    "drone_command_disarm":       4,
    "drone_command_rtl":          4,
    "drone_command_land":         4,
    "drone_command_hold":         4,
    "drone_command_set_mode":     4,
}


class DroneCommand(Enum):
    ARM = "ARM"
    DISARM = "DISARM"
    TAKEOFF = "TAKEOFF"
    GOTO_WAYPOINT = "GOTO_WAYPOINT"
    SET_GIMBAL = "SET_GIMBAL"
    RETURN_TO_LAUNCH = "RETURN_TO_LAUNCH"
    LAND = "LAND"
    HOLD = "HOLD"
    SET_FLIGHT_MODE = "SET_FLIGHT_MODE"


_COMMAND_RING_ACTION = {
    DroneCommand.ARM: "drone_command_arm",
    DroneCommand.DISARM: "drone_command_disarm",
    DroneCommand.TAKEOFF: "drone_command_takeoff",
    DroneCommand.GOTO_WAYPOINT: "drone_command_goto",
    DroneCommand.SET_GIMBAL: "drone_command_set_gimbal",
    DroneCommand.RETURN_TO_LAUNCH: "drone_command_rtl",
    DroneCommand.LAND: "drone_command_land",
    DroneCommand.HOLD: "drone_command_hold",
    DroneCommand.SET_FLIGHT_MODE: "drone_command_set_mode",
}


@dataclass
class CommandResult:
    command_id: str
    command: str
    accepted: bool
    detail: str
    issued_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    sovereignty_gate: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d


# ── Transport abstraction ──────────────────────────────────────────────────────

class AirframeTransport(ABC):
    """Every real flight-controller integration implements this. The
    command vocabulary is closed — see module docstring."""

    @abstractmethod
    def arm(self, mission_id: str) -> bool: ...

    @abstractmethod
    def disarm(self, mission_id: str) -> bool: ...

    @abstractmethod
    def takeoff(self, mission_id: str, target_alt_m: float) -> bool: ...

    @abstractmethod
    def goto(self, mission_id: str, lat: float, lon: float, alt_m: float, speed_mps: float) -> bool: ...

    @abstractmethod
    def set_gimbal(self, mission_id: str, pitch_deg: float) -> bool: ...

    @abstractmethod
    def return_to_launch(self, mission_id: str) -> bool: ...

    @abstractmethod
    def land(self, mission_id: str) -> bool: ...

    @abstractmethod
    def hold(self, mission_id: str) -> bool: ...

    @abstractmethod
    def set_flight_mode(self, mission_id: str, mode: str) -> bool: ...

    @abstractmethod
    def is_connected(self, mission_id: str) -> bool: ...


class MAVLinkTransportStub(AirframeTransport):
    """
    Defines the exact surface a real pymavlink/MAVSDK bridge implements.
    Intentionally not implemented here — wiring a real flight controller
    means subclassing this (or AirframeTransport directly) against
    pymavlink and overriding every method below; nothing else in
    zeus_drone_command_bridge.py, zeus_drone_blueprint.py, or the
    sovereignty engine needs to change.
    """
    def _ni(self, name): raise NotImplementedError(
        f"MAVLinkTransportStub.{name}() — implement against pymavlink/MAVSDK to use a real airframe")

    def arm(self, mission_id): self._ni("arm")
    def disarm(self, mission_id): self._ni("disarm")
    def takeoff(self, mission_id, target_alt_m): self._ni("takeoff")
    def goto(self, mission_id, lat, lon, alt_m, speed_mps): self._ni("goto")
    def set_gimbal(self, mission_id, pitch_deg): self._ni("set_gimbal")
    def return_to_launch(self, mission_id): self._ni("return_to_launch")
    def land(self, mission_id): self._ni("land")
    def hold(self, mission_id): self._ni("hold")
    def set_flight_mode(self, mission_id, mode): self._ni("set_flight_mode")
    def is_connected(self, mission_id): self._ni("is_connected")


class SimulatorTransport(AirframeTransport):
    """
    In-memory flight model. Lets this bridge — and anything built on
    top of it (the geofence monitor, the dashboard) — be exercised
    end-to-end with no physical or simulated-MAVLink hardware. State
    is process-local and intentionally simple: armed/altitude/position/
    mode per mission_id.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._state: Dict[str, Dict[str, Any]] = {}

    def _get(self, mission_id: str) -> Dict[str, Any]:
        with self._lock:
            if mission_id not in self._state:
                self._state[mission_id] = {
                    "armed": False, "lat": 0.0, "lon": 0.0, "alt_m": 0.0,
                    "gimbal_pitch_deg": -90.0, "mode": "HOLD", "connected": True,
                }
            return self._state[mission_id]

    def arm(self, mission_id):
        self._get(mission_id)["armed"] = True
        return True

    def disarm(self, mission_id):
        self._get(mission_id)["armed"] = False
        return True

    def takeoff(self, mission_id, target_alt_m):
        s = self._get(mission_id)
        if not s["armed"]:
            return False
        s["alt_m"] = target_alt_m
        s["mode"] = "TAKEOFF"
        return True

    def goto(self, mission_id, lat, lon, alt_m, speed_mps):
        s = self._get(mission_id)
        if not s["armed"]:
            return False
        s["lat"], s["lon"], s["alt_m"] = lat, lon, alt_m
        s["mode"] = "AUTO"
        return True

    def set_gimbal(self, mission_id, pitch_deg):
        self._get(mission_id)["gimbal_pitch_deg"] = pitch_deg
        return True

    def return_to_launch(self, mission_id):
        s = self._get(mission_id)
        s["lat"], s["lon"] = 0.0, 0.0
        s["mode"] = "RTL"
        return True

    def land(self, mission_id):
        s = self._get(mission_id)
        s["alt_m"] = 0.0
        s["armed"] = False
        s["mode"] = "LANDED"
        return True

    def hold(self, mission_id):
        self._get(mission_id)["mode"] = "HOLD"
        return True

    def set_flight_mode(self, mission_id, mode):
        self._get(mission_id)["mode"] = mode
        return True

    def is_connected(self, mission_id):
        return self._get(mission_id)["connected"]

    def snapshot(self, mission_id: str) -> Dict[str, Any]:
        return dict(self._get(mission_id))


# ── Command bridge (ring-gated front door) ────────────────────────────────────

class CommandBridge:
    """
    The only path through which this extension issues commands to an
    airframe. Every call is ring-classified and audited via
    zeus_sovereignty_engine.sovereign_execute() BEFORE the transport is
    touched. A Ring 5 command whose sovereignty gate is denied/pending
    is never forwarded to the transport.
    """

    def __init__(self, transport: AirframeTransport):
        self.transport = transport

    def _gate_and_send(self, command: DroneCommand, mission_id: str,
                        description: str, payload: Dict[str, Any],
                        transport_call) -> CommandResult:
        from zeus_sovereignty_engine import sovereign_execute
        action_type = _COMMAND_RING_ACTION[command]
        gate_result = sovereign_execute(action_type, description, payload)

        ring = gate_result.get("ring")
        # zeus_sovereignty_engine.SovereigntyEngine.execute() returns
        # status="executed" for Ring 1-5 (immediate), status="advisory"
        # for Ring 6 (proceeds after a 30s veto window unless vetoed —
        # NOT immediate), and status="pending_permission" for Ring 7
        # (blocks indefinitely). Every drone command in this bridge is
        # classified Ring 4/5 by DRONE_COMMAND_RING_TYPES, so in normal
        # operation this will always be "executed" — the check below is
        # a hard backstop, not the primary gate: if a future action
        # type is misclassified into Ring 6/7, this bridge still
        # refuses to forward it to the transport.
        status = gate_result.get("status", "")
        executed_immediately = (status == "executed")
        if not executed_immediately:
            return CommandResult(
                command_id="cmd_" + uuid.uuid4().hex[:12], command=command.value,
                accepted=False,
                detail=f"Sovereignty gate did not authorize immediate execution "
                       f"(status={status!r}, ring={ring}) — command not sent to transport",
                sovereignty_gate=gate_result,
            )

        try:
            accepted = bool(transport_call())
            detail = "Command accepted by transport" if accepted else "Transport rejected command"
        except NotImplementedError as e:
            accepted, detail = False, str(e)
        except Exception as e:
            accepted, detail = False, f"Transport error: {e}"

        return CommandResult(
            command_id="cmd_" + uuid.uuid4().hex[:12], command=command.value,
            accepted=accepted, detail=detail, sovereignty_gate=gate_result,
        )

    def arm(self, mission_id: str) -> CommandResult:
        return self._gate_and_send(DroneCommand.ARM, mission_id, f"Arm {mission_id}",
                                    {"mission_id": mission_id}, lambda: self.transport.arm(mission_id))

    def disarm(self, mission_id: str) -> CommandResult:
        return self._gate_and_send(DroneCommand.DISARM, mission_id, f"Disarm {mission_id}",
                                    {"mission_id": mission_id}, lambda: self.transport.disarm(mission_id))

    def takeoff(self, mission_id: str, target_alt_m: float) -> CommandResult:
        return self._gate_and_send(
            DroneCommand.TAKEOFF, mission_id, f"Takeoff {mission_id} to {target_alt_m}m",
            {"mission_id": mission_id, "target_alt_m": target_alt_m},
            lambda: self.transport.takeoff(mission_id, target_alt_m))

    def goto(self, mission_id: str, lat: float, lon: float, alt_m: float, speed_mps: float = 5.0) -> CommandResult:
        return self._gate_and_send(
            DroneCommand.GOTO_WAYPOINT, mission_id, f"Goto waypoint for {mission_id}",
            {"mission_id": mission_id, "lat": lat, "lon": lon, "alt_m": alt_m, "speed_mps": speed_mps},
            lambda: self.transport.goto(mission_id, lat, lon, alt_m, speed_mps))

    def set_gimbal(self, mission_id: str, pitch_deg: float) -> CommandResult:
        return self._gate_and_send(
            DroneCommand.SET_GIMBAL, mission_id, f"Set gimbal for {mission_id}",
            {"mission_id": mission_id, "pitch_deg": pitch_deg},
            lambda: self.transport.set_gimbal(mission_id, pitch_deg))

    def return_to_launch(self, mission_id: str, reason: str = "") -> CommandResult:
        return self._gate_and_send(
            DroneCommand.RETURN_TO_LAUNCH, mission_id, f"RTL {mission_id}: {reason}",
            {"mission_id": mission_id, "reason": reason},
            lambda: self.transport.return_to_launch(mission_id))

    def land(self, mission_id: str, reason: str = "") -> CommandResult:
        return self._gate_and_send(
            DroneCommand.LAND, mission_id, f"Land {mission_id}: {reason}",
            {"mission_id": mission_id, "reason": reason},
            lambda: self.transport.land(mission_id))

    def hold(self, mission_id: str, reason: str = "") -> CommandResult:
        return self._gate_and_send(
            DroneCommand.HOLD, mission_id, f"Hold {mission_id}: {reason}",
            {"mission_id": mission_id, "reason": reason},
            lambda: self.transport.hold(mission_id))

    def set_flight_mode(self, mission_id: str, mode: str) -> CommandResult:
        return self._gate_and_send(
            DroneCommand.SET_FLIGHT_MODE, mission_id, f"Set mode {mode} for {mission_id}",
            {"mission_id": mission_id, "mode": mode},
            lambda: self.transport.set_flight_mode(mission_id, mode))

    def fly_mission(self, mission: Dict[str, Any]) -> List[CommandResult]:
        """
        Issues ARM, TAKEOFF, then GOTO_WAYPOINT (+ SET_GIMBAL where the
        waypoint specifies it) for every waypoint in a FlightMission
        dict (as produced by zeus_drone_coverage.CoveragePlanner).
        Stops and returns early if any command is not accepted, rather
        than continuing to send commands a denied/failed mission.
        """
        mission_id = mission["mission_id"]
        results = [self.arm(mission_id)]
        if not results[-1].accepted:
            return results

        waypoints = mission.get("waypoints", [])
        if waypoints:
            results.append(self.takeoff(mission_id, waypoints[0]["alt_m"]))
            if not results[-1].accepted:
                return results

        for wp in waypoints:
            r = self.goto(mission_id, wp["lat"], wp["lon"], wp["alt_m"], wp.get("speed_mps", 5.0))
            results.append(r)
            if not r.accepted:
                return results
            if "gimbal_pitch_deg" in wp:
                results.append(self.set_gimbal(mission_id, wp["gimbal_pitch_deg"]))

        results.append(self.return_to_launch(mission_id, reason="mission complete"))

        # ── Hive + Tartarus wiring (v2.4, additive) ──────────────────────────
        # Publish mission-complete summary into hive bus + Tartarus 'datasets'
        # so the learning engine can build a model of mission timing/geometry.
        try:
            from zeus_drone_hive_wire import get_wire
            total_dist = sum(
                __import__('zeus_drone_coverage').haversine_m(
                    waypoints[i]['lat'], waypoints[i]['lon'],
                    waypoints[i+1]['lat'], waypoints[i+1]['lon']
                ) for i in range(len(waypoints)-1)
            ) if len(waypoints) > 1 else 0.0
            get_wire().publish_mission_complete(
                mission_id=mission_id,
                pattern_type=mission.get("pattern_type", "unknown"),
                waypoint_count=len(waypoints),
                duration_s=mission.get("estimated_duration_s", 0.0),
                distance_m=total_dist,
            )
        except Exception as _hw:
            pass   # non-fatal — telemetry path must not be interrupted
        # ─────────────────────────────────────────────────────────────────────

        return results
