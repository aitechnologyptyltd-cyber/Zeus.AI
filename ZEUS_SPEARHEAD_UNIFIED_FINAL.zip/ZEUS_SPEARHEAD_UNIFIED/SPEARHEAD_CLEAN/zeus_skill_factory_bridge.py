# zeus_skill_factory_bridge.py
# The Zeus Project 2026 — Skill Factory Flask Bridge
# Exposes the Skill Extractor & Generator as SPEARHEAD API endpoints,
# following the same blueprint-registration convention as
# zeus_refactoring_engine.py and zeus_test_feedback_bridge.py.

import os
import logging
from pathlib import Path

log = logging.getLogger("zeus.skill_factory.bridge")


def create_skill_factory_blueprint(genome_manager=None, hive_bridge=None):
    from flask import Blueprint, jsonify, request
    from skill_factory_src.orchestrator import Orchestrator

    bp = Blueprint("skill_factory", __name__, url_prefix="/api/skills")

    upload_dir = Path("skill_factory_uploads")
    upload_dir.mkdir(exist_ok=True)

    @bp.route("/extract", methods=["POST"])
    def extract_skills():
        """
        Upload an archive (multipart/form-data, field 'archive') to extract
        and validate skills from it. Returns pass/fail per skill.
        """
        if "archive" not in request.files:
            return jsonify({"error": "No archive file provided (field 'archive')"}), 400

        archive_file = request.files["archive"]
        if not archive_file.filename:
            return jsonify({"error": "Empty filename"}), 400

        # Basic filename safety — don't trust the client-supplied name for pathing
        safe_name = os.path.basename(archive_file.filename)
        save_path = upload_dir / safe_name
        archive_file.save(save_path)

        output_dir = request.form.get("output_dir", "./generated_skills")

        orchestrator = Orchestrator(
            output_dir=output_dir,
            genome_manager=genome_manager,
            hive_bridge=hive_bridge,
        )

        try:
            results = orchestrator.run(str(save_path))
        except Exception as e:
            log.error(f"[skill_factory_bridge] Extraction run failed: {e}")
            return jsonify({"error": f"Extraction failed: {e}"}), 500
        finally:
            # Don't retain uploaded archives from untrusted sources longer
            # than the run itself.
            try:
                save_path.unlink(missing_ok=True)
            except Exception:
                pass

        return jsonify({
            "total": len(results),
            "passed": sum(1 for r in results if r.passed),
            "failed": sum(1 for r in results if not r.passed),
            "results": [
                {
                    "skill": r.skill_name,
                    "passed": r.passed,
                    "coverage": r.coverage,
                    "errors": r.errors,
                }
                for r in results
            ],
        })

    @bp.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok", "module": "skill_factory"})

    return bp


def register(app, genome_manager=None, hive_bridge=None):
    """Registration entrypoint matching zeus_auto_register.py conventions."""
    bp = create_skill_factory_blueprint(genome_manager=genome_manager, hive_bridge=hive_bridge)
    app.register_blueprint(bp)
    log.info("[skill_factory_bridge] Registered at /api/skills")
