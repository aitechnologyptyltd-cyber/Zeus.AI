"""
zeus_stress_engine.py
The Zeus Project 2026 — Francois Nel

AUTONOMOUS STRESS TESTING ENGINE v1.0
══════════════════════════════════════════════════════════════════════════════
Tests ALL FOUR SYSTEMS at every depth and layer:

  SYSTEM 1 — Zeus Architecture  (zeus_arch/  port 8080)
  SYSTEM 3 — Aegis Firewall      (zeus_firewall/)
  SYSTEM 4 — Hive Mind Bridge    (zeus_hive_bridge.py)

Coverage:
  ▸ CODE LAYER     — AST parse, import, cyclomatic complexity, dead code
  ▸ DB LAYER       — Schema integrity, WAL mode, concurrency, corruption recovery
  ▸ LOGIC LAYER    — Genome fitness, knowledge coherence, evolution gap detection
  ▸ WEIGHT LAYER   — Domain weight balance, drift detection, update propagation
  ▸ DECISION LAYER — LLM router fallback chain, prediction confidence calibration
  ▸ COMMS LAYER    — Hive bridge sync, cross-system HTTP, event stream fidelity
  ▸ SECURITY LAYER — Aegis pattern coverage, injection probe, threat scoring
  ▸ PERF LAYER     — Concurrency contention, memory pressure, response latency
  ▸ MINING LAYER   — Swarm node health, coin switch logic, profit switcher gaps
  ▸ SELF-HEAL LAYER— Evolution cycle completeness, fill/merge integrity

Results stored in stress_results table (zeus.db).
Scheduler hook: nightly at 03:30 via zeus_nightly_scheduler.py.
API: Blueprint stress_bp at /api/stress/*
Manual trigger: GET /api/stress/run  ?system=all|zeus|aegis|hive
                GET /api/stress/report
                GET /api/stress/gaps
                POST /api/stress/schedule
══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import print_function

import os
import re
import ast
import sys
import time
import json
import math
import uuid
import gzip
import random
import hashlib
import sqlite3
import logging
import inspect
import textwrap
import threading
import traceback
import importlib
import subprocess
import statistics
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.stress")

# ══════════════════════════════════════════════════════════════
# PATHS
# ══════════════════════════════════════════════════════════════

STRESS_DIR = os.path.dirname(os.path.abspath(__file__))
ZEUS_ARCH  = os.path.join(STRESS_DIR, "zeus_arch")
FW_DIR     = os.path.join(STRESS_DIR, "zeus_firewall")
ZEUS_DB    = os.path.join(ZEUS_ARCH,  "zeus.db")

ZEUS_URL   = "http://127.0.0.1:8080"

# ══════════════════════════════════════════════════════════════
# RESULT DATA STRUCTURES
# ══════════════════════════════════════════════════════════════

@dataclass
class StressResult:
    test_id:     str
    system:      str        # zeus | aegis | hive
    layer:       str        # code | db | logic | weight | decision | comms | security | perf | mining | heal
    test_name:   str
    status:      str        # PASS | FAIL | WARN | GAP | SKIP
    score:       float      # 0.0 – 1.0 (higher = healthier)
    message:     str
    detail:      str        = ""
    gap_desc:    str        = ""
    fix_hint:    str        = ""
    duration_ms: float      = 0.0
    ts:          str        = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class StressReport:
    run_id:         str      = field(default_factory=lambda: str(uuid.uuid4())[:8])
    started_at:     str      = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    finished_at:    str      = ""
    total_tests:    int      = 0
    passed:         int      = 0
    warned:         int      = 0
    failed:         int      = 0
    gaps:           int      = 0
    overall_score:  float    = 0.0
    system_scores:  Dict     = field(default_factory=dict)
    layer_scores:   Dict     = field(default_factory=dict)
    critical_gaps:  List     = field(default_factory=list)
    results:        List     = field(default_factory=list)

    def finalise(self):
        self.finished_at  = datetime.now(timezone.utc).isoformat()
        self.total_tests  = len(self.results)
        self.passed       = sum(1 for r in self.results if r.status == "PASS")
        self.warned       = sum(1 for r in self.results if r.status == "WARN")
        self.failed       = sum(1 for r in self.results if r.status == "FAIL")
        self.gaps         = sum(1 for r in self.results if r.status == "GAP")
        scores = [r.score for r in self.results if r.status != "SKIP"]
        self.overall_score = round(statistics.mean(scores), 3) if scores else 0.0
        # per-system
        for sys_name in ("zeus", "aegis", "hive"):
            s = [r.score for r in self.results if r.system == sys_name and r.status != "SKIP"]
            self.system_scores[sys_name] = round(statistics.mean(s), 3) if s else 0.0
        # per-layer
        layers = set(r.layer for r in self.results)
        for lyr in layers:
            s = [r.score for r in self.results if r.layer == lyr and r.status != "SKIP"]
            self.layer_scores[lyr] = round(statistics.mean(s), 3) if s else 0.0
        # critical gaps (score < 0.4)
        self.critical_gaps = [
            {"test": r.test_name, "system": r.system, "layer": r.layer,
             "gap": r.gap_desc, "fix": r.fix_hint}
            for r in self.results if r.status in ("FAIL", "GAP") and r.score < 0.4
        ]

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["results"] = [r.to_dict() for r in self.results]
        return d

# ══════════════════════════════════════════════════════════════
# DB PERSISTENCE
# ══════════════════════════════════════════════════════════════

def _ensure_stress_table(db_path: str):
    try:
        con = sqlite3.connect(db_path, timeout=10)
        con.execute("""
            CREATE TABLE IF NOT EXISTS stress_results (
                run_id       TEXT,
                test_id      TEXT PRIMARY KEY,
                system       TEXT,
                layer        TEXT,
                test_name    TEXT,
                status       TEXT,
                score        REAL,
                message      TEXT,
                detail       TEXT,
                gap_desc     TEXT,
                fix_hint     TEXT,
                duration_ms  REAL,
                ts           TEXT
            )""")
        con.execute("""
            CREATE TABLE IF NOT EXISTS stress_reports (
                run_id        TEXT PRIMARY KEY,
                started_at    TEXT,
                finished_at   TEXT,
                total_tests   INTEGER,
                passed        INTEGER,
                warned        INTEGER,
                failed        INTEGER,
                gaps          INTEGER,
                overall_score REAL,
                system_scores TEXT,
                layer_scores  TEXT,
                critical_gaps TEXT,
                raw_json      TEXT
            )""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_stress_sys ON stress_results(system)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_stress_layer ON stress_results(layer)")
        con.commit()
        con.close()
    except Exception as e:
        log.warning(f"stress table init: {e}")


def _persist_report(report: StressReport):
    try:
        _ensure_stress_table(ZEUS_DB)
        con = sqlite3.connect(ZEUS_DB, timeout=15)
        for r in report.results:
            con.execute("""
                INSERT OR REPLACE INTO stress_results
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (report.run_id, r.test_id, r.system, r.layer, r.test_name,
                  r.status, r.score, r.message, r.detail[:1000],
                  r.gap_desc[:500], r.fix_hint[:500], r.duration_ms, r.ts))
        con.execute("""
            INSERT OR REPLACE INTO stress_reports
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (report.run_id, report.started_at, report.finished_at,
              report.total_tests, report.passed, report.warned,
              report.failed, report.gaps, report.overall_score,
              json.dumps(report.system_scores),
              json.dumps(report.layer_scores),
              json.dumps(report.critical_gaps[:50]),
              json.dumps(report.to_dict())))
        con.commit()
        con.close()
    except Exception as e:
        log.error(f"persist_report: {e}")


# ══════════════════════════════════════════════════════════════
# TEST RUNNER HELPER
# ══════════════════════════════════════════════════════════════

def _run(system: str, layer: str, name: str, fn: Callable,
         run_id: str, results: List[StressResult]):
    t0 = time.time()
    try:
        r = fn()          # must return StressResult
        r.duration_ms = round((time.time() - t0) * 1000, 1)
        r.test_id = f"{run_id}_{name}"
    except Exception as exc:
        r = StressResult(
            test_id     = f"{run_id}_{name}",
            system      = system,
            layer       = layer,
            test_name   = name,
            status      = "FAIL",
            score       = 0.0,
            message     = f"Exception: {type(exc).__name__}: {exc}",
            detail      = traceback.format_exc(limit=5),
            gap_desc    = f"Test {name} threw unhandled exception",
            fix_hint    = "Fix the underlying module or its import dependencies",
            duration_ms = round((time.time() - t0) * 1000, 1),
        )
    results.append(r)

# ══════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════
#   LAYER 1 — CODE LAYER  (all 4 systems)
# ══════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════

def _code_test_file(fpath: str, system: str) -> StressResult:
    """AST parse + complexity + dead code + missing docstrings."""
    fname = os.path.basename(fpath)
    try:
        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
            src = f.read()
    except Exception as e:
        return StressResult("", system, "code", f"read_{fname}",
                            "FAIL", 0.0, f"Cannot read: {e}",
                            gap_desc=f"Unreadable source file: {fpath}")

    issues = []
    score_parts = []

    # 1. AST parse
    try:
        tree = ast.parse(src)
        score_parts.append(1.0)
    except SyntaxError as e:
        return StressResult("", system, "code", f"ast_{fname}",
                            "FAIL", 0.0,
                            f"SyntaxError line {e.lineno}: {e.msg}",
                            gap_desc=f"Syntax error in {fname}",
                            fix_hint="Fix syntax error before any other improvement")

    # 2. Cyclomatic complexity proxy (count branches)
    branches = sum(
        1 for node in ast.walk(tree)
        if isinstance(node, (ast.If, ast.For, ast.While, ast.ExceptHandler,
                              ast.With, ast.Assert, ast.Try))
    )
    funcs = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    avg_complex = (branches / max(len(funcs), 1))
    if avg_complex > 20:
        issues.append(f"High avg cyclomatic complexity: {avg_complex:.1f}")
        score_parts.append(0.3)
    elif avg_complex > 10:
        score_parts.append(0.7)
    else:
        score_parts.append(1.0)

    # 3. Missing docstrings on public functions
    missing_docs = [
        n.name for n in funcs
        if not n.name.startswith("_")
        and not (n.body and isinstance(n.body[0], ast.Expr)
                 and isinstance(n.body[0].value, (ast.Str, ast.Constant)))
    ]
    doc_ratio = 1.0 - (len(missing_docs) / max(len(funcs), 1))
    score_parts.append(max(0.0, doc_ratio))
    if missing_docs:
        issues.append(f"{len(missing_docs)} public funcs missing docstrings")

    # 4. TODO / FIXME / STUB / PLACEHOLDER in code
    stub_re = re.compile(r"\b(TODO|FIXME|STUB|PLACEHOLDER|NotImplemented|pass\s*#\s*TODO)\b", re.I)
    stubs = stub_re.findall(src)
    if stubs:
        stub_score = max(0.0, 1.0 - len(stubs) * 0.05)
        score_parts.append(stub_score)
        issues.append(f"{len(stubs)} stubs/TODOs found")
    else:
        score_parts.append(1.0)

    # 5. Exception swallowing (bare except: pass)
    bare_except = sum(
        1 for node in ast.walk(tree)
        if isinstance(node, ast.ExceptHandler)
        and node.type is None
        and len(node.body) == 1
        and isinstance(node.body[0], ast.Pass)
    )
    if bare_except:
        score_parts.append(max(0.0, 1.0 - bare_except * 0.15))
        issues.append(f"{bare_except} silent bare except:pass")
    else:
        score_parts.append(1.0)

    score = round(statistics.mean(score_parts), 3)
    status = "PASS" if score >= 0.75 else ("WARN" if score >= 0.45 else "GAP")
    msg = f"{fname}: score={score} branches={branches} funcs={len(funcs)}"
    detail = "; ".join(issues) if issues else "Clean"
    gap_desc = "; ".join(issues) if issues else ""
    fix_hint = (
        "Reduce function complexity, add docstrings, eliminate stubs/bare-excepts"
        if issues else ""
    )
    return StressResult("", system, "code", f"code_{fname}",
                        status, score, msg, detail, gap_desc, fix_hint)


def run_code_layer(system: str, directory: str, run_id: str, results: List):
    py_files = sorted(Path(directory).glob("*.py"))
    for fpath in py_files:
        r = _code_test_file(str(fpath), system)
        r.test_id = f"{run_id}_code_{fpath.name}"
        results.append(r)


# ══════════════════════════════════════════════════════════════
#   LAYER 2 — DB LAYER
# ══════════════════════════════════════════════════════════════

def _db_stress(db_path: str, system: str, expected_tables: List[str],
               run_id: str, results: List):

    def t(name, fn):
        _run(system, "db", name, fn, run_id, results)

    # 1. File existence
    def _exists():
        if not os.path.exists(db_path):
            return StressResult("", system, "db", f"db_exists_{system}",
                                "GAP", 0.0, f"DB not found: {db_path}",
                                gap_desc="Database file missing",
                                fix_hint="Run db_init() or start the service once")
        size = os.path.getsize(db_path)
        return StressResult("", system, "db", f"db_exists_{system}",
                            "PASS", 1.0, f"DB exists {size//1024}KB")
    t(f"db_exists_{system}", _exists)

    if not os.path.exists(db_path):
        return  # remaining db tests meaningless

    # 2. Open + WAL mode
    def _wal():
        con = sqlite3.connect(db_path, timeout=5)
        mode = con.execute("PRAGMA journal_mode").fetchone()[0]
        con.close()
        if mode != "wal":
            return StressResult("", system, "db", f"db_wal_{system}",
                                "WARN", 0.5, f"journal_mode={mode} (want wal)",
                                gap_desc="WAL mode not set — write contention risk",
                                fix_hint="PRAGMA journal_mode=WAL; at startup")
        return StressResult("", system, "db", f"db_wal_{system}",
                            "PASS", 1.0, "journal_mode=wal")
    t(f"db_wal_{system}", _wal)

    # 3. Integrity check
    def _integrity():
        con = sqlite3.connect(db_path, timeout=10)
        rows = con.execute("PRAGMA integrity_check(20)").fetchall()
        con.close()
        msgs = [r[0] for r in rows]
        if msgs == ["ok"]:
            return StressResult("", system, "db", f"db_integrity_{system}",
                                "PASS", 1.0, "integrity_check ok")
        return StressResult("", system, "db", f"db_integrity_{system}",
                            "FAIL", 0.0, f"Corruption: {msgs}",
                            gap_desc=f"DB corruption detected: {msgs}",
                            fix_hint="Restore from backup or run VACUUM + REINDEX")
    t(f"db_integrity_{system}", _integrity)

    # 4. Expected tables present
    def _tables():
        con = sqlite3.connect(db_path, timeout=5)
        existing = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        con.close()
        missing = [t for t in expected_tables if t not in existing]
        if missing:
            return StressResult("", system, "db", f"db_tables_{system}",
                                "GAP", max(0.0, 1.0 - len(missing) * 0.15),
                                f"Missing tables: {missing}",
                                gap_desc=f"Schema gap — missing: {missing}",
                                fix_hint="Re-run db_init() or add CREATE TABLE migrations")
        return StressResult("", system, "db", f"db_tables_{system}",
                            "PASS", 1.0, f"All {len(expected_tables)} tables present")
    t(f"db_tables_{system}", _tables)

    # 5. Write concurrency stress (10 threads, 20 inserts each)
    def _concurrent_write():
        errors = []
        def _worker(tid):
            try:
                con = sqlite3.connect(db_path, timeout=15)
                con.execute("PRAGMA journal_mode=WAL")
                for i in range(20):
                    con.execute("""
                        CREATE TABLE IF NOT EXISTS _stress_tmp
                        (id INTEGER PRIMARY KEY AUTOINCREMENT, val TEXT, ts TEXT)
                    """)
                    con.execute("INSERT INTO _stress_tmp(val,ts) VALUES (?,?)",
                                (f"t{tid}_{i}", datetime.now(timezone.utc).isoformat()))
                con.commit()
                con.close()
            except Exception as e:
                errors.append(str(e))
        threads = [threading.Thread(target=_worker, args=(i,)) for i in range(10)]
        for th in threads: th.start()
        for th in threads: th.join(timeout=10)
        # clean up
        try:
            con = sqlite3.connect(db_path, timeout=5)
            con.execute("DROP TABLE IF EXISTS _stress_tmp")
            con.commit()
            con.close()
        except Exception:
            pass
        if errors:
            return StressResult("", system, "db", f"db_concurrency_{system}",
                                "WARN", 0.4, f"{len(errors)} concurrent write errors",
                                gap_desc=f"Concurrency issues: {errors[:3]}",
                                fix_hint="Ensure WAL mode + retry logic on SQLITE_BUSY")
        return StressResult("", system, "db", f"db_concurrency_{system}",
                            "PASS", 1.0, "10-thread concurrent write: no errors")
    t(f"db_concurrency_{system}", _concurrent_write)

    # 6. Index coverage
    def _indexes():
        con = sqlite3.connect(db_path, timeout=5)
        indexes = {r[1]: r[2] for r in con.execute(
            "SELECT type,name,tbl_name FROM sqlite_master WHERE type='index'").fetchall()}
        con.close()
        count = len(indexes)
        if count == 0:
            return StressResult("", system, "db", f"db_indexes_{system}",
                                "WARN", 0.3, "No indexes found",
                                gap_desc="Missing DB indexes — query performance gap",
                                fix_hint="Add indexes on frequently-queried columns (ts, status, system)")
        return StressResult("", system, "db", f"db_indexes_{system}",
                            "PASS", 1.0, f"{count} indexes found")
    t(f"db_indexes_{system}", _indexes)


# ══════════════════════════════════════════════════════════════
#   LAYER 3 — LOGIC / GENOME LAYER  (zeus)
# ══════════════════════════════════════════════════════════════

def run_logic_layer(run_id: str, results: List):
    system = "zeus"

    def t(name, fn):
        _run(system, "logic", name, fn, run_id, results)

    # 1. Genome engine imports
    def _genome_import():
        if ZEUS_ARCH not in sys.path:
            sys.path.insert(0, ZEUS_ARCH)
        try:
            mod = importlib.import_module("genome_manager")
            eng = mod.get_genome_engine()
            stats = eng.stats()
            total = stats.get("total", 0)
            if total == 0:
                return StressResult("", system, "logic", "genome_empty",
                                    "GAP", 0.2, "Genome DB empty — no segments registered",
                                    gap_desc="Zero genome segments",
                                    fix_hint="Seed genome via POST /api/genome/add or run improvement loop")
            return StressResult("", system, "logic", "genome_import",
                                "PASS", 1.0, f"GenomeEngine ok — {total} segments")
        except ImportError as e:
            return StressResult("", system, "logic", "genome_import",
                                "FAIL", 0.0, f"Import failed: {e}",
                                gap_desc="genome_manager import broken",
                                fix_hint="Check zeus_arch/ is on sys.path + db_init ran")
    t("genome_import", _genome_import)

    # 2. Fitness distribution — are any segments stuck at 0?
    def _genome_fitness():
        if ZEUS_ARCH not in sys.path:
            sys.path.insert(0, ZEUS_ARCH)
        try:
            mod = importlib.import_module("genome_manager")
            eng = mod.get_genome_engine()
            all_segs = eng.list_all()
            if not all_segs:
                return StressResult("", system, "logic", "genome_fitness",
                                    "SKIP", 0.5, "No genome segments to evaluate")
            fitnesses = [s.get("priority", 0.0) for s in all_segs]
            zero_count = sum(1 for f in fitnesses if f <= 0.01)
            zero_ratio = zero_count / len(fitnesses)
            score = round(1.0 - zero_ratio, 3)
            if zero_ratio > 0.5:
                return StressResult("", system, "logic", "genome_fitness",
                                    "GAP", score,
                                    f"{zero_count}/{len(fitnesses)} segments at zero fitness",
                                    gap_desc="Majority of genome at zero fitness — evolution stalled",
                                    fix_hint="Trigger fitness recompute: POST /api/genome/fitness_all")
            if zero_ratio > 0.2:
                return StressResult("", system, "logic", "genome_fitness",
                                    "WARN", score,
                                    f"{zero_count} low-fitness segments",
                                    gap_desc="Some genome segments never activated",
                                    fix_hint="Run nightly fitness job or trigger manual recompute")
            return StressResult("", system, "logic", "genome_fitness",
                                "PASS", score,
                                f"Fitness ok — avg={round(statistics.mean(fitnesses),3)} zero={zero_count}")
        except Exception as e:
            return StressResult("", system, "logic", "genome_fitness",
                                "FAIL", 0.0, str(e),
                                gap_desc="Genome fitness check failed")
    t("genome_fitness", _genome_fitness)

    # 3. Knowledge depth balance
    def _knowledge_depth():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", system, "logic", "knowledge_depth",
                                "SKIP", 0.5, "zeus.db not found")
        try:
            con = sqlite3.connect(ZEUS_DB, timeout=5)
            rows = con.execute("""
                SELECT depth, COUNT(*) as cnt
                FROM knowledge GROUP BY depth
            """).fetchall()
            con.close()
            if not rows:
                return StressResult("", system, "logic", "knowledge_depth",
                                    "GAP", 0.1, "Knowledge table empty",
                                    gap_desc="No knowledge entries — learning never ran",
                                    fix_hint="Queue topics and trigger zeus_learner")
            depth_map = {r[0]: r[1] for r in rows}
            expected_depths = ["Simple", "Advanced", "Professional", "Complex", "Mastery"]
            missing = [d for d in expected_depths if d not in depth_map]
            if missing:
                score = 1.0 - len(missing) * 0.15
                return StressResult("", system, "logic", "knowledge_depth",
                                    "WARN", score,
                                    f"Missing depth levels: {missing}",
                                    gap_desc=f"Knowledge gaps at depths: {missing}",
                                    fix_hint="Run learner on diverse topics to fill all 5 depth levels")
            return StressResult("", system, "logic", "knowledge_depth",
                                "PASS", 1.0,
                                f"All 5 depths present: {depth_map}")
        except Exception as e:
            return StressResult("", system, "logic", "knowledge_depth",
                                "FAIL", 0.0, str(e))
    t("knowledge_depth", _knowledge_depth)

    # 4. Logic rules registered
    def _logic_rules():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", system, "logic", "logic_rules",
                                "SKIP", 0.5, "zeus.db not found")
        try:
            con = sqlite3.connect(ZEUS_DB, timeout=5)
            count = con.execute("SELECT COUNT(*) FROM logic_rules").fetchone()[0]
            con.close()
            if count == 0:
                return StressResult("", system, "logic", "logic_rules",
                                    "GAP", 0.1, "Zero logic rules registered",
                                    gap_desc="Logic engine has no rules — reasoning is blind",
                                    fix_hint="Seed logic rules via logic_engine.register(app) + default rule set")
            return StressResult("", system, "logic", "logic_rules",
                                "PASS", 1.0, f"{count} logic rules active")
        except Exception as e:
            return StressResult("", system, "logic", "logic_rules",
                                "FAIL", 0.0, str(e))
    t("logic_rules", _logic_rules)

    # 5. Evolution log — check last cycle freshness
    def _evolution_freshness():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", system, "logic", "evolution_freshness",
                                "SKIP", 0.5, "zeus.db not found")
        try:
            con = sqlite3.connect(ZEUS_DB, timeout=5)
            row = con.execute("""
                SELECT MAX(created_at) FROM evolution_log
            """).fetchone()
            con.close()
            if not row or not row[0]:
                return StressResult("", system, "logic", "evolution_freshness",
                                    "GAP", 0.1,
                                    "Evolution log empty — self-evolution never ran",
                                    gap_desc="Zero evolution cycles logged",
                                    fix_hint="Trigger POST /api/evolution/run or check nightly scheduler")
            last = row[0]
            # naive freshness: if string exists, score 0.8 (can't parse TZ easily without deps)
            return StressResult("", system, "logic", "evolution_freshness",
                                "PASS", 0.8, f"Last evolution at {last}")
        except sqlite3.OperationalError:
            return StressResult("", system, "logic", "evolution_freshness",
                                "GAP", 0.2, "evolution_log table missing",
                                gap_desc="evolution_log table not created",
                                fix_hint="Re-run db_init() to create all tables")
        except Exception as e:
            return StressResult("", system, "logic", "evolution_freshness",
                                "FAIL", 0.0, str(e))
    t("evolution_freshness", _evolution_freshness)


# ══════════════════════════════════════════════════════════════
#   LAYER 4 — WEIGHT LAYER
# ══════════════════════════════════════════════════════════════

def run_weight_layer(run_id: str, results: List):
    """
    Zeus weight engine is defined in zeus_hive_bridge.py and genome_manager.
    We test: domain coverage, balance, update path, drift.
    """
    system = "zeus"

    # Known domains from the architecture
    EXPECTED_DOMAINS = [
        "learning", "evolution", "genome", "mining", "security",
        "prediction", "logic", "communication"
    ]

    def t(name, fn):
        _run(system, "weight", name, fn, run_id, results)

    # 1. Weight engine reachable via genome stats
    def _weight_domains():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", system, "weight", "weight_domains",
                                "SKIP", 0.5, "zeus.db not found")
        try:
            con = sqlite3.connect(ZEUS_DB, timeout=5)
            rows = con.execute("""
                SELECT module_type, COUNT(*) FROM genome
                GROUP BY module_type
            """).fetchall()
            con.close()
            present = {r[0].lower() for r in rows if r[0]}
            missing = [d for d in EXPECTED_DOMAINS if d not in present]
            score = max(0.0, 1.0 - len(missing) * 0.1)
            if missing:
                return StressResult("", system, "weight", "weight_domains",
                                    "WARN", score,
                                    f"Missing weight domains in genome: {missing}",
                                    gap_desc=f"Genome weight domains absent: {missing}",
                                    fix_hint="Register genome segments for each domain via genome_manager.add()")
            return StressResult("", system, "weight", "weight_domains",
                                "PASS", score,
                                f"Domains in genome: {sorted(present)}")
        except Exception as e:
            return StressResult("", system, "weight", "weight_domains",
                                "FAIL", 0.0, str(e))
    t("weight_domains", _weight_domains)

    # 2. Priority/fitness range — detect if all weights clamped at extremes
    def _weight_distribution():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", system, "weight", "weight_distribution",
                                "SKIP", 0.5, "zeus.db not found")
        try:
            con = sqlite3.connect(ZEUS_DB, timeout=5)
            rows = con.execute("SELECT priority FROM genome WHERE priority IS NOT NULL").fetchall()
            con.close()
            if not rows:
                return StressResult("", system, "weight", "weight_distribution",
                                    "GAP", 0.1, "No priority values in genome",
                                    gap_desc="Weight values absent — all decisions are unweighted",
                                    fix_hint="Trigger fitness recompute to populate priority values")
            vals = [r[0] for r in rows]
            mn, mx, avg = min(vals), max(vals), statistics.mean(vals)
            spread = mx - mn
            # Good spread = diverse weights, bad = all same
            score = min(1.0, spread / 10.0) if spread < 10 else 1.0
            if spread < 0.1:
                return StressResult("", system, "weight", "weight_distribution",
                                    "GAP", 0.1,
                                    f"All weights identical ({avg:.3f}) — no differentiation",
                                    gap_desc="Weight collapse: all genome segments same priority",
                                    fix_hint="Run fitness_recompute with usage/success signals")
            return StressResult("", system, "weight", "weight_distribution",
                                "PASS", min(1.0, score),
                                f"Weight spread: min={mn:.2f} max={mx:.2f} avg={avg:.2f}")
        except Exception as e:
            return StressResult("", system, "weight", "weight_distribution",
                                "FAIL", 0.0, str(e))
    t("weight_distribution", _weight_distribution)

    # 3. Mutation history — verify weights are being updated
    def _weight_update_activity():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", system, "weight", "weight_update_activity",
                                "SKIP", 0.5, "zeus.db not found")
        try:
            con = sqlite3.connect(ZEUS_DB, timeout=5)
            # genome_mutations table if present
            tables = {r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            if "genome_mutations" not in tables:
                con.close()
                return StressResult("", system, "weight", "weight_update_activity",
                                    "GAP", 0.3,
                                    "genome_mutations table missing — weight history untracked",
                                    gap_desc="No mutation history table",
                                    fix_hint="Add genome_mutations table tracking weight deltas over time")
            count = con.execute("SELECT COUNT(*) FROM genome_mutations").fetchone()[0]
            con.close()
            if count == 0:
                return StressResult("", system, "weight", "weight_update_activity",
                                    "WARN", 0.4, "No mutations recorded — weights never updated",
                                    gap_desc="Weight update path never triggered",
                                    fix_hint="Run genome fitness cycle + ensure mutation recording is wired")
            return StressResult("", system, "weight", "weight_update_activity",
                                "PASS", 1.0, f"{count} weight mutation records found")
        except Exception as e:
            return StressResult("", system, "weight", "weight_update_activity",
                                "FAIL", 0.0, str(e))
    t("weight_update_activity", _weight_update_activity)


# ══════════════════════════════════════════════════════════════
#   LAYER 5 — DECISION LAYER  (LLM router, prediction)
# ══════════════════════════════════════════════════════════════

def run_decision_layer(run_id: str, results: List):
    system = "zeus"

    def t(name, fn):
        _run(system, "decision", name, fn, run_id, results)

    # 1. LLM router file presence + fallback chain
    def _llm_router_chain():
        router_path = os.path.join(ZEUS_ARCH, "zeus_llm_router.py")
        if not os.path.exists(router_path):
            return StressResult("", system, "decision", "llm_router_chain",
                                "GAP", 0.0, "zeus_llm_router.py missing",
                                gap_desc="LLM router absent — all LLM calls will fail",
                                fix_hint="Restore zeus_llm_router.py from backup or rebuild")
        try:
            with open(router_path, "r", errors="replace") as f:
                src = f.read()
            # Count fallback providers
            providers = re.findall(r"(groq|openrouter|claude|anthropic|grok|xai|openai)",
                                   src, re.I)
            unique = set(p.lower() for p in providers)
            if len(unique) < 2:
                return StressResult("", system, "decision", "llm_router_chain",
                                    "WARN", 0.4,
                                    f"Only {len(unique)} LLM provider(s) in router",
                                    gap_desc="Single LLM point of failure — no fallback chain",
                                    fix_hint="Add Groq + OpenRouter + Claude fallback chain")
            return StressResult("", system, "decision", "llm_router_chain",
                                "PASS", 1.0,
                                f"LLM router has {len(unique)} providers: {sorted(unique)}")
        except Exception as e:
            return StressResult("", system, "decision", "llm_router_chain",
                                "FAIL", 0.0, str(e))
    t("llm_router_chain", _llm_router_chain)

    # 2. Prediction engine — verify model exists + table populated
    def _prediction_quality():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", system, "decision", "prediction_quality",
                                "SKIP", 0.5, "zeus.db not found")
        try:
            con = sqlite3.connect(ZEUS_DB, timeout=5)
            tables = {r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            if "predictions" not in tables:
                con.close()
                return StressResult("", system, "decision", "prediction_quality",
                                    "GAP", 0.2,
                                    "predictions table missing",
                                    gap_desc="Prediction engine never stored results",
                                    fix_hint="Ensure prediction engine routes are registered + blueprint active")
            rows = con.execute("SELECT COUNT(*), AVG(confidence) FROM predictions").fetchone()
            con.close()
            count, avg_conf = rows[0], rows[1]
            if count == 0:
                return StressResult("", system, "decision", "prediction_quality",
                                    "WARN", 0.3, "No predictions stored",
                                    gap_desc="Prediction table empty — decision layer blind",
                                    fix_hint="Trigger prediction cycle via scheduler or POST /api/predict/run")
            conf_score = min(1.0, (avg_conf or 0.5))
            return StressResult("", system, "decision", "prediction_quality",
                                "PASS", conf_score,
                                f"{count} predictions, avg confidence={round(avg_conf or 0, 3)}")
        except Exception as e:
            return StressResult("", system, "decision", "prediction_quality",
                                "FAIL", 0.0, str(e))
    t("prediction_quality", _prediction_quality)

    # 3. Decision loop — improvement loop state
    def _improvement_loop_active():
        loop_path = os.path.join(ZEUS_ARCH, "zeus_improvement_loop.py")
        if not os.path.exists(loop_path):
            return StressResult("", system, "decision", "improvement_loop_active",
                                "GAP", 0.0, "zeus_improvement_loop.py missing",
                                gap_desc="Improvement loop file absent",
                                fix_hint="Restore from backup — this is the decision spine")
        try:
            with open(loop_path, "r", errors="replace") as f:
                src = f.read()
            # Check it actually starts a background thread
            has_thread = "threading.Thread" in src or "Thread(" in src
            has_loop = "while True" in src or "_loop" in src
            score = (0.5 if has_thread else 0.0) + (0.5 if has_loop else 0.0)
            if score < 1.0:
                return StressResult("", system, "decision", "improvement_loop_active",
                                    "WARN", score,
                                    "Improvement loop missing thread or loop construct",
                                    gap_desc="Improvement loop may not run autonomously",
                                    fix_hint="Ensure _start_loop() launches threading.Thread(daemon=True)")
            return StressResult("", system, "decision", "improvement_loop_active",
                                "PASS", 1.0, "Improvement loop has thread + loop construct")
        except Exception as e:
            return StressResult("", system, "decision", "improvement_loop_active",
                                "FAIL", 0.0, str(e))
    t("improvement_loop_active", _improvement_loop_active)


# ══════════════════════════════════════════════════════════════
#   LAYER 6 — COMMS LAYER  (hive bridge, cross-system HTTP)
# ══════════════════════════════════════════════════════════════

def run_comms_layer(run_id: str, results: List):
    system = "hive"

    def t(name, fn):
        _run(system, "comms", name, fn, run_id, results)

    # 1. Hive bridge file integrity
    def _hive_bridge_integrity():
        bp = os.path.join(STRESS_DIR, "zeus_hive_bridge.py")
        if not os.path.exists(bp):
            return StressResult("", system, "comms", "hive_bridge_integrity",
                                "GAP", 0.0, "zeus_hive_bridge.py missing",
                                gap_desc="Hive bridge absent — systems disconnected",
                                fix_hint="Restore zeus_hive_bridge.py — all inter-system comms depend on it")
        with open(bp, "r", errors="replace") as f:
            src = f.read()
        checks = {
            "HiveMemory":             "HiveMemory" in src,
            "HiveSyncLoop":           "HiveSyncLoop" in src,
            "HivePredictionEngine":   "HivePredictionEngine" in src,
            "HiveRepairDispatcher":   "HiveRepairDispatcher" in src,
            "GenomeHiveBroadcaster":  "GenomeHiveBroadcaster" in src,
        }
        missing = [k for k, v in checks.items() if not v]
        score = 1.0 - len(missing) * 0.2
        if missing:
            return StressResult("", system, "comms", "hive_bridge_integrity",
                                "GAP", max(0.0, score),
                                f"Missing hive classes: {missing}",
                                gap_desc=f"Hive bridge incomplete: {missing}",
                                fix_hint="Restore missing hive classes from last known good version")
        return StressResult("", system, "comms", "hive_bridge_integrity",
                            "PASS", 1.0, "All 5 hive classes present")
    t("hive_bridge_integrity", _hive_bridge_integrity)

    # 2. Hive DB tables
    def _hive_db():
        if not os.path.exists(HIVE_DB):
            return StressResult("", system, "comms", "hive_db",
                                "WARN", 0.3,
                                "hive_collective.db not found (created on first run)",
                                gap_desc="Hive DB not initialized — collective memory absent",
                                fix_hint="Start zeus+ump once to trigger HiveMemory._init_db()")
        con = sqlite3.connect(HIVE_DB, timeout=5)
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        con.close()
        expected = {"hive_events", "hive_mining_snapshots", "hive_threats",
                    "hive_predictions", "hive_files"}
        missing = expected - tables
        if missing:
            return StressResult("", system, "comms", "hive_db",
                                "WARN", max(0.2, 1.0 - len(missing)*0.15),
                                f"Missing hive tables: {missing}",
                                gap_desc=f"Hive collective DB incomplete: {missing}",
                                fix_hint="Restart zeus to trigger HiveMemory._init_db()")
        return StressResult("", system, "comms", "hive_db",
                            "PASS", 1.0, f"Hive DB ok: {sorted(tables)}")
    t("hive_db", _hive_db)

    # 3. Cross-system URL reachability (non-blocking probe)
    def _zeus_http_reachable():
        try:
            import urllib.request
            req = urllib.request.Request(f"{ZEUS_URL}/api/health",
                                         headers={"User-Agent": "ZeusStress/1.0"})
            urllib.request.urlopen(req, timeout=4)
            return StressResult("", system, "comms", "zeus_http_reachable",
                                "PASS", 1.0, f"Zeus at {ZEUS_URL} reachable")
        except Exception as e:
            return StressResult("", system, "comms", "zeus_http_reachable",
                                "WARN", 0.3,
                                f"Zeus HTTP unreachable: {e} (may be offline during test)",
                                gap_desc="Zeus HTTP not responding — hive bridge can't sync",
                                fix_hint="Start Zeus: cd zeus_arch && gunicorn wsgi_zeus:app")
    t("zeus_http_reachable", _zeus_http_reachable)


    # 4. Sync loop code path coverage
    def _sync_loop_coverage():
        bp = os.path.join(STRESS_DIR, "zeus_hive_bridge.py")
        if not os.path.exists(bp):
            return StressResult("", system, "comms", "sync_loop_coverage",
                                "SKIP", 0.5, "Bridge file missing")
        with open(bp, "r", errors="replace") as f:
            src = f.read()
        required_methods = [
            "_zeus_pull_ump", "_zeus_push_predictions",
            "_zeus_scan_and_repair",
            "_deliver_pending_files"
        ]
        missing = [m for m in required_methods if m not in src]
        score = 1.0 - len(missing) * 0.2
        if missing:
            return StressResult("", system, "comms", "sync_loop_coverage",
                                "GAP", max(0.0, score),
                                f"Sync loop missing methods: {missing}",
                                gap_desc=f"Hive sync gaps: {missing}",
                                fix_hint="Implement missing sync methods in HiveSyncLoop")
        return StressResult("", system, "comms", "sync_loop_coverage",
                            "PASS", 1.0, "All sync loop methods present")
    t("sync_loop_coverage", _sync_loop_coverage)


# ══════════════════════════════════════════════════════════════
#   LAYER 7 — SECURITY LAYER  (aegis)
# ══════════════════════════════════════════════════════════════

def run_security_layer(run_id: str, results: List):
    system = "aegis"

    def t(name, fn):
        _run(system, "security", name, fn, run_id, results)

    # 1. All 21 aegis layers defined
    def _aegis_layer_count():
        eng_path = os.path.join(FW_DIR, "zeus_aegis_engine.py")
        fw_path  = os.path.join(FW_DIR, "zeus_firewall_v1.py")
        for fpath in [eng_path, fw_path]:
            if os.path.exists(fpath):
                with open(fpath, "r", errors="replace") as f:
                    src = f.read()
                layers = re.findall(r"\(\s*(\d+)\s*,\s*['\"]", src)
                if layers:
                    max_layer = max(int(l) for l in layers)
                    if max_layer >= 21:
                        return StressResult("", system, "security", "aegis_layer_count",
                                            "PASS", 1.0, f"All {max_layer} Aegis layers defined")
                    return StressResult("", system, "security", "aegis_layer_count",
                                        "GAP", max_layer / 21.0,
                                        f"Only {max_layer}/21 Aegis layers defined",
                                        gap_desc=f"Missing Aegis layers {max_layer+1}–21",
                                        fix_hint="Add missing LAYER_DEFINITIONS tuples in zeus_aegis_engine.py")
        return StressResult("", system, "security", "aegis_layer_count",
                            "GAP", 0.0, "Aegis engine files missing",
                            gap_desc="zeus_aegis_engine.py not found",
                            fix_hint="Restore zeus_firewall/ directory from backup")
    t("aegis_layer_count", _aegis_layer_count)

    # 2. Injection probe — verify Aegis catches SQLi/XSS patterns
    def _injection_probe():
        fw_path = os.path.join(FW_DIR, "zeus_firewall_v1.py")
        if not os.path.exists(fw_path):
            return StressResult("", system, "security", "injection_probe",
                                "GAP", 0.0, "Firewall file missing",
                                gap_desc="No firewall to test injection coverage against")
        with open(fw_path, "r", errors="replace") as f:
            src = f.read()
        INJECTION_PATTERNS = [
            r"UNION\s+SELECT",    # SQLi
            r"<script",           # XSS
            r"\.\./\.\.",         # Path traversal
            r"exec\s*\(",         # Code exec
            r"eval\s*\(",         # Eval injection
            r"cmd\.exe",          # CMD injection
            r"\/etc\/passwd",     # LFI
        ]
        covered = [p for p in INJECTION_PATTERNS
                   if re.search(p.replace("\\\\", "\\"), src, re.I)]
        coverage = len(covered) / len(INJECTION_PATTERNS)
        if coverage < 0.6:
            missing_pats = [p for p in INJECTION_PATTERNS if p not in covered]
            return StressResult("", system, "security", "injection_probe",
                                "GAP", coverage,
                                f"Injection coverage: {len(covered)}/{len(INJECTION_PATTERNS)}",
                                gap_desc=f"Missing injection patterns: {missing_pats}",
                                fix_hint="Add regex patterns for missing injection types in INJECTION_PATTERNS")
        if coverage < 1.0:
            return StressResult("", system, "security", "injection_probe",
                                "WARN", coverage,
                                f"Partial injection coverage: {len(covered)}/{len(INJECTION_PATTERNS)}")
        return StressResult("", system, "security", "injection_probe",
                            "PASS", 1.0, "All injection pattern classes covered")
    t("injection_probe", _injection_probe)

    # 3. Threat DB (aegis.db) health
    def _aegis_db():
        aegis_db = os.path.join(ZEUS_ARCH, "zeus_aegis.db")
        if not os.path.exists(aegis_db):
            # try firewall dir
            aegis_db = os.path.join(FW_DIR, "zeus_aegis.db")
        if not os.path.exists(aegis_db):
            return StressResult("", system, "security", "aegis_db",
                                "WARN", 0.3,
                                "zeus_aegis.db not found (created on first threat)",
                                gap_desc="Aegis threat DB absent — no threat memory",
                                fix_hint="Start Aegis engine to initialize threat DB")
        con = sqlite3.connect(aegis_db, timeout=5)
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        con.close()
        return StressResult("", system, "security", "aegis_db",
                            "PASS", 1.0, f"Aegis DB present, tables: {sorted(tables)}")
    t("aegis_db", _aegis_db)

    # 4. Rate limiter presence in firewall
    def _rate_limiter():
        fw_path = os.path.join(FW_DIR, "zeus_firewall_v1.py")
        eng_path = os.path.join(FW_DIR, "zeus_aegis_engine.py")
        for fpath in [fw_path, eng_path]:
            if os.path.exists(fpath):
                with open(fpath, "r", errors="replace") as f:
                    src = f.read()
                has_rate = "rate_limit" in src.lower() or "ratelimit" in src.lower()
                has_ddos = "ddos" in src.lower() or "burst" in src.lower()
                score = (0.5 if has_rate else 0.0) + (0.5 if has_ddos else 0.0)
                if score < 1.0:
                    missing = []
                    if not has_rate: missing.append("rate_limiting")
                    if not has_ddos: missing.append("DDoS_burst_detection")
                    return StressResult("", system, "security", "rate_limiter",
                                        "WARN", score,
                                        f"Rate limiting gaps: {missing}",
                                        gap_desc=f"Security gaps: {missing}",
                                        fix_hint="Add rate limiter + DDoS burst detection to firewall")
                return StressResult("", system, "security", "rate_limiter",
                                    "PASS", 1.0, "Rate limiter + DDoS detection present")
        return StressResult("", system, "security", "rate_limiter",
                            "GAP", 0.0, "Firewall files missing",
                            gap_desc="No firewall files found")
    t("rate_limiter", _rate_limiter)


# ══════════════════════════════════════════════════════════════
#   LAYER 8 — PERFORMANCE LAYER
# ══════════════════════════════════════════════════════════════

def run_perf_layer(run_id: str, results: List):

    def t(system, name, fn):
        _run(system, "perf", name, fn, run_id, results)

    # 1. Zeus DB read latency under load (100 concurrent reads)
    def _zeus_db_read_latency():
        if not os.path.exists(ZEUS_DB):
            return StressResult("", "zeus", "perf", "zeus_db_read_latency",
                                "SKIP", 0.5, "zeus.db not found")
        latencies = []
        errors = []
        lock = threading.Lock()
        def _reader():
            t0 = time.time()
            try:
                con = sqlite3.connect(ZEUS_DB, timeout=10)
                con.execute("SELECT COUNT(*) FROM knowledge").fetchone()
                con.close()
                with lock:
                    latencies.append((time.time() - t0) * 1000)
            except Exception as e:
                with lock:
                    errors.append(str(e))
        threads = [threading.Thread(target=_reader) for _ in range(50)]
        for th in threads: th.start()
        for th in threads: th.join(timeout=15)
        if errors:
            return StressResult("", "zeus", "perf", "zeus_db_read_latency",
                                "WARN", 0.4,
                                f"{len(errors)} read errors under load",
                                gap_desc=f"DB read failures: {errors[:3]}",
                                fix_hint="Ensure WAL mode and increase sqlite timeout")
        if not latencies:
            return StressResult("", "zeus", "perf", "zeus_db_read_latency",
                                "FAIL", 0.0, "No latency data collected")
        p50 = statistics.median(latencies)
        p95 = sorted(latencies)[int(len(latencies) * 0.95)]
        score = 1.0 if p95 < 200 else (0.6 if p95 < 500 else 0.3)
        return StressResult("", "zeus", "perf", "zeus_db_read_latency",
                            "PASS" if score > 0.5 else "WARN",
                            score,
                            f"50-reader DB stress: p50={p50:.1f}ms p95={p95:.1f}ms",
                            gap_desc="" if score > 0.5 else f"p95={p95:.1f}ms too slow",
                            fix_hint="" if score > 0.5 else "Add indexes, enable WAL, consider read replicas")
    t("zeus", "zeus_db_read_latency", _zeus_db_read_latency)

    # 2. Import time for core modules (armv7l budget: < 3s each)
    def _module_import_time():
        if ZEUS_ARCH not in sys.path:
            sys.path.insert(0, ZEUS_ARCH)
        modules = ["genome_manager", "logic_engine", "zeus_mutator"]
        slow = []
        for mod in modules:
            t0 = time.time()
            try:
                importlib.import_module(mod)
                ms = (time.time() - t0) * 1000
                if ms > 3000:
                    slow.append(f"{mod}={ms:.0f}ms")
            except Exception:
                pass  # import failures handled in code layer
        if slow:
            return StressResult("", "zeus", "perf", "module_import_time",
                                "WARN", 0.5,
                                f"Slow imports on armv7l: {slow}",
                                gap_desc=f"Module startup too slow: {slow}",
                                fix_hint="Defer heavy imports inside functions with lazy loading")
        return StressResult("", "zeus", "perf", "module_import_time",
                            "PASS", 1.0, "All core module imports within armv7l budget")
    t("zeus", "module_import_time", _module_import_time)


# ══════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════
# NOTE: LAYER 9 (MINING/UMP) REMOVED
# The mining-layer stress checks that previously lived here tested
# UMP-specific infrastructure (swarm engine, wallet DB, coin registry).
# UMP has been fully removed from this codebase; this function referenced
# an undefined UMP_DB constant and contained several truncated
# os.path.join(...) calls left over from that removal, which caused a
# SyntaxError on import and prevented this entire blueprint from loading.
# Removed rather than reconstructed, consistent with UMP being erased.
# ══════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════
#   LAYER 10 — SELF-HEAL LAYER
# ══════════════════════════════════════════════════════════════

def run_heal_layer(run_id: str, results: List):
    system = "zeus"

    def t(name, fn):
        _run(system, "heal", name, fn, run_id, results)

    # 1. Nightly scheduler jobs coverage
    def _scheduler_coverage():
        sched_path = os.path.join(ZEUS_ARCH, "zeus_nightly_scheduler.py")
        if not os.path.exists(sched_path):
            return StressResult("", system, "heal", "scheduler_coverage",
                                "GAP", 0.0, "zeus_nightly_scheduler.py missing",
                                gap_desc="Nightly scheduler absent — no autonomous healing",
                                fix_hint="Restore zeus_nightly_scheduler.py")
        with open(sched_path, "r", errors="replace") as f:
            src = f.read()
        required_jobs = [
            "nightly_evolution", "nightly_mutation", "nightly_fitness",
            "nightly_db_cleanup", "hive_repair_scan", "hive_mining_learn"
        ]
        missing = [j for j in required_jobs if j not in src]
        score = 1.0 - len(missing) * (1.0 / len(required_jobs))
        if missing:
            return StressResult("", system, "heal", "scheduler_coverage",
                                "WARN", max(0.0, score),
                                f"Scheduler missing jobs: {missing}",
                                gap_desc=f"Healing schedule gaps: {missing}",
                                fix_hint=f"Add ScheduledJob entries for: {missing}")
        return StressResult("", system, "heal", "scheduler_coverage",
                            "PASS", 1.0, "All nightly healing jobs scheduled")
    t("scheduler_coverage", _scheduler_coverage)

    # 2. Gap fill pipeline — verify evolution fills and merges
    def _gap_fill_pipeline():
        evo_path = os.path.join(ZEUS_ARCH, "zeus_self_evolution.py")
        if not os.path.exists(evo_path):
            return StressResult("", system, "heal", "gap_fill_pipeline",
                                "GAP", 0.0, "zeus_self_evolution.py missing",
                                gap_desc="Self-evolution engine absent")
        with open(evo_path, "r", errors="replace") as f:
            src = f.read()
        checks = {
            "gap_detection":     "detect" in src.lower() and "gap" in src.lower(),
            "fill_logic":        "fill" in src.lower(),
            "merge_logic":       "merge" in src.lower(),
            "protected_files":   "PROTECTED_FILES" in src,
            "backup_before_patch": "backup" in src.lower() or "patch_backup" in src.lower(),
        }
        missing = [k for k, v in checks.items() if not v]
        score = 1.0 - len(missing) * 0.2
        if missing:
            return StressResult("", system, "heal", "gap_fill_pipeline",
                                "WARN", max(0.0, score),
                                f"Evolution pipeline missing: {missing}",
                                gap_desc=f"Self-heal gaps: {missing}",
                                fix_hint=f"Implement {missing} in zeus_self_evolution.py")
        return StressResult("", system, "heal", "gap_fill_pipeline",
                            "PASS", 1.0, "Gap fill pipeline: detect+fill+merge+protect+backup")
    t("gap_fill_pipeline", _gap_fill_pipeline)

    # 3. Repair dispatcher — cross-system healing
    def _repair_dispatcher():
        bp_path = os.path.join(STRESS_DIR, "zeus_hive_bridge.py")
        if not os.path.exists(bp_path):
            return StressResult("", system, "heal", "repair_dispatcher",
                                "GAP", 0.0, "Hive bridge missing — repair dispatcher offline")
        with open(bp_path, "r", errors="replace") as f:
            src = f.read()
        checks = {
            "dispatch_aegis_rule":    "dispatch_aegis_rule" in src,
            "request_zeus_evolution": "request_zeus_evolution" in src,
        }
        missing = [k for k, v in checks.items() if not v]
        score = 1.0 - len(missing) * 0.33
        if missing:
            return StressResult("", system, "heal", "repair_dispatcher",
                                "GAP", max(0.0, score),
                                f"Repair dispatcher gaps: {missing}",
                                gap_desc=f"Cross-system repair missing: {missing}",
                                fix_hint="Implement HiveRepairDispatcher methods: " + str(missing))
        return StressResult("", system, "heal", "repair_dispatcher",
                            "PASS", 1.0, "Cross-system repair dispatcher complete")
    t("repair_dispatcher", _repair_dispatcher)

    # 4. Protected files respected by evolution
    def _protected_files_check():
        evo_path = os.path.join(ZEUS_ARCH, "zeus_self_evolution.py")
        if not os.path.exists(evo_path):
            return StressResult("", system, "heal", "protected_files_check",
                                "SKIP", 0.5, "evolution file not found")
        with open(evo_path, "r", errors="replace") as f:
            src = f.read()
        critical = ["app.py", "db_init.py", "zeus_self_evolution.py", "logic_engine.py"]
        protected_in_code = [f for f in critical if f'"{f}"' in src or f"'{f}'" in src]
        if len(protected_in_code) < len(critical):
            missing = [f for f in critical if f not in protected_in_code]
            return StressResult("", system, "heal", "protected_files_check",
                                "WARN", len(protected_in_code) / len(critical),
                                f"Some critical files not in PROTECTED_FILES: {missing}",
                                gap_desc=f"Evolution could overwrite critical files: {missing}",
                                fix_hint="Add to PROTECTED_FILES set in zeus_self_evolution.py")
        return StressResult("", system, "heal", "protected_files_check",
                            "PASS", 1.0, "All critical files in PROTECTED_FILES")
    t("protected_files_check", _protected_files_check)


# ══════════════════════════════════════════════════════════════
# MASTER RUNNER
# ══════════════════════════════════════════════════════════════

def run_stress_suite(systems: str = "all") -> StressReport:
    """
    Run the full autonomous stress test suite.
    systems: "all" | "zeus" | "aegis" | "hive"
    """
    report  = StressReport()
    results = report.results
    run_id  = report.run_id
    do_all  = systems == "all"

    log.info(f"[STRESS] Starting run {run_id} — systems={systems}")

    # ── ZEUS ─────────────────────────────────────────────────
    if do_all or systems == "zeus":
        run_code_layer("zeus", ZEUS_ARCH, run_id, results)
        _db_stress(ZEUS_DB, "zeus",
                   ["genome", "knowledge", "queue", "blueprints", "executor_jobs",
                    "evolution_log", "synthesis_blueprints", "logic_rules",
                    "module_registry", "chat_history"],
                   run_id, results)
        run_logic_layer(run_id, results)
        run_weight_layer(run_id, results)
        run_decision_layer(run_id, results)
        run_perf_layer(run_id, results)
        run_heal_layer(run_id, results)

    # NOTE: UMP mining-system stress block removed — UMP has been fully
    # erased from this codebase (run_mining_layer, which this called, was
    # removed above). "ump" is no longer a valid `systems` value.

    # ── AEGIS ────────────────────────────────────────────────
    if do_all or systems == "aegis":
        run_code_layer("aegis", FW_DIR, run_id, results)
        run_security_layer(run_id, results)

    # ── HIVE ─────────────────────────────────────────────────
    if do_all or systems == "hive":
        run_comms_layer(run_id, results)

    report.finalise()
    _persist_report(report)
    log.info(
        f"[STRESS] Run {run_id} complete — "
        f"{report.total_tests} tests | "
        f"score={report.overall_score} | "
        f"gaps={report.gaps} | "
        f"failed={report.failed}"
    )
    return report


# ══════════════════════════════════════════════════════════════
# AUTO-IMPROVE: feed gaps back into evolution queue
# ══════════════════════════════════════════════════════════════

def feed_gaps_to_evolution(report: StressReport) -> int:
    """
    Insert all detected gaps into zeus.db queue so the improvement
    loop and nightly scheduler can process them automatically.
    Returns count of gaps queued.
    """
    if not os.path.exists(ZEUS_DB):
        return 0
    count = 0
    try:
        con = sqlite3.connect(ZEUS_DB, timeout=10)
        for r in report.results:
            if r.status in ("FAIL", "GAP", "WARN") and r.gap_desc:
                topic = f"stress_gap::{r.system}::{r.layer}::{r.test_name}"
                con.execute("""
                    INSERT OR IGNORE INTO queue (topic, source, priority, created_at)
                    VALUES (?, ?, ?, ?)
                """, (topic, "stress_engine",
                      10 if r.score < 0.3 else 5,
                      datetime.now(timezone.utc).isoformat()))
                count += 1
        con.commit()
        con.close()
    except Exception as e:
        log.warning(f"feed_gaps: {e}")
    return count


def apply_quick_fixes(report: StressReport) -> List[str]:
    """
    Apply immediate structural fixes that don't require LLM:
      - WAL mode on all found DBs
      - Create missing stress_results table
      - Log critical gaps to zeus.log for operator review
    Returns list of actions taken.
    """
    actions = []

    # 1. WAL mode on all sqlite DBs found
    # NOTE: this list previously included a second, truncated
    # os.path.join(...) entry left over from editing — ZEUS_DB is the
    # only DB path constant actually defined in this file, so that's
    # what's safe to iterate here.
    for db_path in [ZEUS_DB]:
        if os.path.exists(db_path):
            try:
                con = sqlite3.connect(db_path, timeout=5)
                con.execute("PRAGMA journal_mode=WAL")
                con.execute("PRAGMA synchronous=NORMAL")
                con.commit()
                con.close()
                actions.append(f"WAL+NORMAL applied to {os.path.basename(db_path)}")
            except Exception as e:
                actions.append(f"WAL failed on {os.path.basename(db_path)}: {e}")

    # 2. Ensure stress table exists in zeus.db
    if os.path.exists(ZEUS_DB):
        _ensure_stress_table(ZEUS_DB)
        actions.append("stress_results/stress_reports tables ensured in zeus.db")

    # 3. Log critical gaps to file
    if report.critical_gaps:
        log_path = os.path.join(ZEUS_ARCH, "logs", "stress_critical.log")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        try:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"\n{'='*70}\n")
                f.write(f"STRESS RUN {report.run_id} — {report.started_at}\n")
                f.write(f"Overall score: {report.overall_score}\n")
                for gap in report.critical_gaps:
                    f.write(f"  [{gap['system']}/{gap['layer']}] {gap['test']}\n")
                    f.write(f"    GAP:  {gap['gap']}\n")
                    f.write(f"    FIX:  {gap['fix']}\n")
        except Exception as e:
            actions.append(f"Log write failed: {e}")
        actions.append(f"{len(report.critical_gaps)} critical gaps logged to stress_critical.log")

    return actions


# ══════════════════════════════════════════════════════════════
# FLASK BLUEPRINT
# ══════════════════════════════════════════════════════════════

stress_bp = Blueprint("stress", __name__)

_last_report: Optional[StressReport] = None
_running     = False
_run_lock    = threading.Lock()


@stress_bp.route("/api/stress/run", methods=["GET", "POST"])
def stress_run():
    global _last_report, _running
    systems = request.args.get("system", "all")
    if _running:
        return jsonify({"status": "running", "message": "Stress test already in progress"}), 429

    def _bg():
        global _last_report, _running
        _running = True
        try:
            rpt = run_stress_suite(systems)
            gaps_queued = feed_gaps_to_evolution(rpt)
            fixes = apply_quick_fixes(rpt)
            rpt.results  # keep reference
            _last_report = rpt
            log.info(f"[STRESS] BG run done — queued {gaps_queued} gaps, fixes: {fixes}")
        finally:
            _running = False

    t = threading.Thread(target=_bg, daemon=True)
    t.start()
    return jsonify({
        "status":  "started",
        "systems": systems,
        "message": "Stress test started in background. GET /api/stress/report for results."
    })


@stress_bp.route("/api/stress/report", methods=["GET"])
def stress_report():
    if _running:
        return jsonify({"status": "running", "message": "Test in progress — check back shortly"}), 202
    if _last_report is None:
        # Try loading from DB
        if os.path.exists(ZEUS_DB):
            try:
                con = sqlite3.connect(ZEUS_DB, timeout=5)
                row = con.execute("""
                    SELECT raw_json FROM stress_reports
                    ORDER BY started_at DESC LIMIT 1
                """).fetchone()
                con.close()
                if row:
                    return jsonify(json.loads(row[0]))
            except Exception:
                pass
        return jsonify({"status": "no_data", "message": "No stress report yet. POST /api/stress/run"}), 404
    return jsonify(_last_report.to_dict())


@stress_bp.route("/api/stress/gaps", methods=["GET"])
def stress_gaps():
    """Return only the failures and gaps from the last report, sorted by severity."""
    if _last_report is None:
        return jsonify({"gaps": [], "message": "No report yet"}), 404
    gaps = [
        r.to_dict() for r in _last_report.results
        if r.status in ("FAIL", "GAP", "WARN")
    ]
    gaps.sort(key=lambda x: x["score"])
    return jsonify({
        "run_id":         _last_report.run_id,
        "overall_score":  _last_report.overall_score,
        "critical_count": len(_last_report.critical_gaps),
        "gaps":           gaps,
    })


@stress_bp.route("/api/stress/scores", methods=["GET"])
def stress_scores():
    if _last_report is None:
        return jsonify({"message": "No report yet"}), 404
    return jsonify({
        "run_id":        _last_report.run_id,
        "overall_score": _last_report.overall_score,
        "system_scores": _last_report.system_scores,
        "layer_scores":  _last_report.layer_scores,
        "critical_gaps": _last_report.critical_gaps,
    })


@stress_bp.route("/api/stress/history", methods=["GET"])
def stress_history():
    """Return last N run summaries from DB."""
    limit = int(request.args.get("limit", 10))
    if not os.path.exists(ZEUS_DB):
        return jsonify({"runs": []})
    try:
        con = sqlite3.connect(ZEUS_DB, timeout=5)
        rows = con.execute("""
            SELECT run_id, started_at, finished_at, total_tests,
                   passed, warned, failed, gaps, overall_score
            FROM stress_reports
            ORDER BY started_at DESC LIMIT ?
        """, (limit,)).fetchall()
        con.close()
        cols = ["run_id", "started_at", "finished_at", "total_tests",
                "passed", "warned", "failed", "gaps", "overall_score"]
        return jsonify({"runs": [dict(zip(cols, r)) for r in rows]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@stress_bp.route("/api/stress/status", methods=["GET"])
def stress_status():
    return jsonify({
        "running":         _running,
        "has_last_report": _last_report is not None,
        "last_run_id":     _last_report.run_id if _last_report else None,
        "last_score":      _last_report.overall_score if _last_report else None,
        "last_critical":   len(_last_report.critical_gaps) if _last_report else 0,
    })


# ══════════════════════════════════════════════════════════════
# STANDALONE RUN (for testing)
# ══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Zeus Autonomous Stress Engine")
    parser.add_argument("--system", default="all",
                        choices=["all", "zeus", "aegis", "hive"],
                        help="Which system(s) to stress test")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="[%(asctime)s] %(levelname)s %(name)s — %(message)s")

    print(f"\n{'═'*65}")
    print(f"  ZEUS AUTONOMOUS STRESS ENGINE — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  System scope: {args.system}")
    print(f"{'═'*65}\n")

    report = run_stress_suite(args.system)
    fixes  = apply_quick_fixes(report)
    queued = feed_gaps_to_evolution(report)

    if args.json:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        print(f"Run ID: {report.run_id}")
        print(f"Total tests : {report.total_tests}")
        print(f"Passed      : {report.passed}")
        print(f"Warned      : {report.warned}")
        print(f"Failed      : {report.failed}")
        print(f"Gaps        : {report.gaps}")
        print(f"Overall     : {report.overall_score}")
        print(f"\nSystem Scores:")
        for sys, sc in sorted(report.system_scores.items()):
            bar = "█" * int(sc * 20) + "░" * (20 - int(sc * 20))
            print(f"  {sys:8} [{bar}] {sc:.3f}")
        print(f"\nLayer Scores:")
        for lyr, sc in sorted(report.layer_scores.items()):
            bar = "█" * int(sc * 20) + "░" * (20 - int(sc * 20))
            print(f"  {lyr:12} [{bar}] {sc:.3f}")
        if report.critical_gaps:
            print(f"\n{'─'*65}")
            print(f"  CRITICAL GAPS ({len(report.critical_gaps)}):")
            for g in report.critical_gaps:
                print(f"  [{g['system']}/{g['layer']}] {g['test']}")
                print(f"    {g['gap']}")
                print(f"    → {g['fix']}")
        print(f"\nQuick fixes applied: {fixes}")
        print(f"Gaps queued to evolution: {queued}")
        print(f"\n{'═'*65}")
