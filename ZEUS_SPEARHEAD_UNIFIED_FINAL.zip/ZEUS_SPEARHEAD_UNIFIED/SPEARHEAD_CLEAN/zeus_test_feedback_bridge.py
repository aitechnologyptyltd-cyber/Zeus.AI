# zeus_test_feedback_bridge.py
# The Zeus Project 2026 — Francois Nel
# TEST FEEDBACK BRIDGE
# Records test results and publishes them to the Hive Mind for autonomous response

import os
import json
import sqlite3
import subprocess
import logging
import time
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
import threading

log = logging.getLogger("zeus.test_feedback")


class TestFeedbackBridge:
    """
    Bridges test execution results with the Hive Mind.
    
    - Runs pytest suite
    - Records results in feedback database
    - Publishes events to Hive Mind
    - Triggers autonomous responses
    """
    
    def __init__(self, test_dir: str = "tests", hive_bridge=None):
        self.test_dir = test_dir
        self.hive_bridge = hive_bridge  # Will be injected by improvement loop
        self.db_path = "zeus_test_results.db"
        self._init_db()
        self._test_command = ["pytest", test_dir, "-v", "--tb=short", "--json-report"]
    
    def _init_db(self):
        """Initialize test results database."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        c.execute("""
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                test_file TEXT,
                test_name TEXT,
                status TEXT,
                duration_seconds REAL,
                error_message TEXT,
                stack_trace TEXT,
                module_affected TEXT,
                severity TEXT
            )
        """)
        
        c.execute("""
            CREATE TABLE IF NOT EXISTS test_summaries (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                total_tests INTEGER,
                passed INTEGER,
                failed INTEGER,
                skipped INTEGER,
                success_rate REAL,
                performance_degradation BOOLEAN,
                critical_failures INTEGER
            )
        """)
        
        c.execute("""
            CREATE TABLE IF NOT EXISTS failure_patterns (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                pattern TEXT,
                occurrence_count INTEGER,
                affected_modules TEXT,
                first_seen TEXT,
                last_seen TEXT
            )
        """)
        
        conn.commit()
        conn.close()
        log.info(f"[test_feedback] Database initialized: {self.db_path}")
    
    # ===== TEST EXECUTION =====
    
    def run_tests(self, target: Optional[str] = None, capture: bool = True) -> Dict[str, Any]:
        """
        Run the pytest suite and return results.
        
        Args:
            target: Specific test file/function to run
            capture: Capture output (vs print to console)
        
        Returns:
            Dictionary with test results
        """
        log.info("[test_feedback] Starting test run...")
        
        cmd = self._test_command.copy()
        if target:
            cmd.append(target)
        
        if capture:
            cmd.extend(["--tb=short", "-q"])
        
        start_time = time.time()
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=capture,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            elapsed = time.time() - start_time
            
            # Parse results
            output = result.stdout + result.stderr
            test_results = self._parse_pytest_output(output, elapsed)
            
            # Record results
            self._record_test_run(test_results)
            
            # Publish to hive mind
            if self.hive_bridge:
                self._publish_to_hive(test_results)
            
            log.info(f"[test_feedback] Tests completed in {elapsed:.2f}s: "
                    f"{test_results['summary']['passed']} passed, "
                    f"{test_results['summary']['failed']} failed")
            
            return test_results
        
        except subprocess.TimeoutExpired:
            log.error("[test_feedback] Test run timed out after 5 minutes")
            return {"error": "timeout", "message": "Test run exceeded 5 minute limit"}
        except FileNotFoundError:
            log.error("[test_feedback] pytest not found. Install with: pip install pytest")
            return {"error": "pytest_not_found", "message": "pytest is not installed"}
        except Exception as e:
            log.error(f"[test_feedback] Test execution failed: {e}")
            return {"error": "execution_failed", "message": str(e)}
    
    def _parse_pytest_output(self, output: str, elapsed_time: float) -> Dict:
        """Parse pytest output and extract metrics."""
        lines = output.split('\n')
        
        results = {
            "summary": {
                "total": 0,
                "passed": 0,
                "failed": 0,
                "skipped": 0,
                "error": 0,
            },
            "duration_seconds": elapsed_time,
            "success": False,
            "details": []
        }
        
        # Simple parsing (could be enhanced with JSON report plugin)
        for line in lines:
            if " passed" in line:
                try:
                    num = int(line.split()[0])
                    results["summary"]["passed"] = num
                except:
                    pass
            elif " failed" in line:
                try:
                    num = int(line.split()[0])
                    results["summary"]["failed"] = num
                except:
                    pass
            elif " skipped" in line:
                try:
                    num = int(line.split()[0])
                    results["summary"]["skipped"] = num
                except:
                    pass
            elif "ERROR" in line or "FAILED" in line:
                results["details"].append(line)
        
        total = results["summary"]["passed"] + results["summary"]["failed"]
        results["summary"]["total"] = total
        
        if total > 0:
            results["summary"]["success_rate"] = (
                results["summary"]["passed"] / total * 100
            )
        else:
            results["summary"]["success_rate"] = 100.0
        
        results["success"] = results["summary"]["failed"] == 0
        
        return results
    
    # ===== RESULT RECORDING =====
    
    def _record_test_run(self, test_results: Dict):
        """Record test results in database."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        timestamp = datetime.now(timezone.utc).isoformat()
        summary = test_results.get("summary", {})
        
        # Record summary
        c.execute("""
            INSERT INTO test_summaries
            (timestamp, total_tests, passed, failed, skipped, success_rate, critical_failures)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            timestamp,
            summary.get("total", 0),
            summary.get("passed", 0),
            summary.get("failed", 0),
            summary.get("skipped", 0),
            summary.get("success_rate", 0),
            1 if summary.get("failed", 0) > 3 else 0
        ))
        
        conn.commit()
        conn.close()
        
        log.info(f"[test_feedback] Test run recorded in database")
    
    def _publish_to_hive(self, test_results: Dict):
        """Publish test results to Hive Mind."""
        if not self.hive_bridge:
            return
        
        event = {
            "type": "test_results",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": {
                "passed": test_results["summary"].get("passed", 0),
                "failed": test_results["summary"].get("failed", 0),
                "success_rate": test_results["summary"].get("success_rate", 0),
                "duration": test_results.get("duration_seconds", 0),
            }
        }
        
        # Publish to hive
        try:
            self.hive_bridge.publish_event("test_stream", event)
            log.info(f"[test_feedback] Published test results to hive mind")
        except Exception as e:
            log.error(f"[test_feedback] Failed to publish to hive: {e}")
    
    # ===== FAILURE ANALYSIS =====
    
    def analyze_failures(self) -> Dict:
        """Analyze patterns in test failures."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        # Get recent failures
        c.execute("""
            SELECT test_name, status, COUNT(*) as count
            FROM test_results
            WHERE status = 'FAILED'
            GROUP BY test_name
            ORDER BY count DESC
            LIMIT 10
        """)
        
        frequent_failures = {}
        for row in c.fetchall():
            test_name, status, count = row
            frequent_failures[test_name] = count
        
        conn.close()
        
        analysis = {
            "frequent_failures": frequent_failures,
            "failure_count": len(frequent_failures),
            "action_required": len(frequent_failures) > 0,
        }
        
        return analysis
    
    # ===== AUTONOMOUS RESPONSES =====
    
    def trigger_autonomous_response(self, test_results: Dict):
        """
        Determine if autonomous response is needed based on test results.
        
        Triggers:
        - Multiple failures → Refactoring suggestion
        - Performance degradation → Optimization
        - New failures → Gap detection
        """
        summary = test_results.get("summary", {})
        failed_count = summary.get("failed", 0)
        success_rate = summary.get("success_rate", 100)
        
        actions = []
        
        # Trigger 1: Multiple failures
        if failed_count >= 3:
            actions.append({
                "type": "refactor_required",
                "severity": "HIGH",
                "reason": f"{failed_count} tests failing",
                "target": "high_failure_modules"
            })
        
        # Trigger 2: Low success rate
        if success_rate < 80:
            actions.append({
                "type": "system_health_check",
                "severity": "CRITICAL",
                "reason": f"Success rate dropped to {success_rate}%",
                "target": "all_modules"
            })
        
        # Trigger 3: Performance degradation
        if test_results.get("duration_seconds", 0) > 60:
            actions.append({
                "type": "performance_optimization",
                "severity": "MEDIUM",
                "reason": f"Test suite taking {test_results['duration_seconds']:.1f}s",
                "target": "slow_tests"
            })
        
        return actions
    
    # ===== REPORTING =====
    
    def get_health_report(self, hours: int = 24) -> Dict:
        """Get system health report based on test history."""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        # Get recent summary
        c.execute(f"""
            SELECT 
                COUNT(*) as runs,
                AVG(success_rate) as avg_success,
                MIN(success_rate) as min_success,
                MAX(success_rate) as max_success,
                SUM(critical_failures) as critical_count
            FROM test_summaries
            WHERE datetime(timestamp) > datetime('now', '-{hours} hours')
        """)
        
        stats = c.fetchone()
        conn.close()
        
        if stats:
            runs, avg_success, min_success, max_success, critical_count = stats
            report = {
                "period_hours": hours,
                "test_runs": runs or 0,
                "average_success_rate": avg_success or 0,
                "success_range": {
                    "min": min_success or 0,
                    "max": max_success or 0,
                },
                "critical_failures": critical_count or 0,
                "health_status": self._determine_health(avg_success or 0, critical_count or 0),
            }
        else:
            report = {
                "period_hours": hours,
                "test_runs": 0,
                "average_success_rate": 0,
                "health_status": "NO_DATA",
            }
        
        return report
    
    def _determine_health(self, success_rate: float, critical_count: int) -> str:
        """Determine overall health status."""
        if critical_count > 0:
            return "CRITICAL"
        if success_rate < 70:
            return "UNHEALTHY"
        if success_rate < 90:
            return "DEGRADED"
        return "HEALTHY"


# Flask integration
def create_test_feedback_blueprint(feedback_bridge: Optional[TestFeedbackBridge] = None):
    """Create Flask blueprint for test feedback endpoints."""
    from flask import Blueprint, jsonify, request
    
    if feedback_bridge is None:
        feedback_bridge = TestFeedbackBridge()
    
    bp = Blueprint("test_feedback", __name__, url_prefix="/api/testing")
    
    @bp.route("/run", methods=["POST"])
    def run_tests():
        """Trigger test suite run."""
        target = request.json.get("target") if request.json else None
        results = feedback_bridge.run_tests(target=target)
        return jsonify(results)
    
    @bp.route("/results/latest", methods=["GET"])
    def get_latest_results():
        """Get latest test results."""
        report = feedback_bridge.get_health_report()
        return jsonify(report)
    
    @bp.route("/analysis", methods=["GET"])
    def analyze_failures():
        """Analyze failure patterns."""
        analysis = feedback_bridge.analyze_failures()
        return jsonify(analysis)
    
    return bp


# Export
def get_test_feedback_bridge() -> TestFeedbackBridge:
    """Get or create test feedback bridge singleton."""
    if not hasattr(get_test_feedback_bridge, '_instance'):
        get_test_feedback_bridge._instance = TestFeedbackBridge()
    return get_test_feedback_bridge._instance


def register(app) -> None:
    """Fits app.py's _register_fn(module_name) convention."""
    app.register_blueprint(create_test_feedback_blueprint())
