# The Zeus Project 2026 — Francois Nel SA ID 8708275089084
# zeus_council_router.py — The AI Council Deliberation Engine v1.0
# ================================================================
#
# ARCHITECTURE ROLE:  LAYER 0 — LLM ROUTING (High-Stakes Branch)
#
# Dispatches Ring 6/7 queries in parallel to 5 AI platforms with a
# 60-second deliberation window. Implements adversarial cross-examination
# and weighted voting. Returns a ratified, synthesised consensus.
#
# ROUTING LOGIC:
#   Ring 1-5  → zeus_llm_router.py  (fast path, 15s)
#   Ring 6-7  → zeus_council_router.py (this module, 60s)
#
# DELIBERATION PHASES:
#   Phase 1 — Parallel Dispatch:  All agents query simultaneously
#   Phase 2 — Weighted Scoring:   Each response scored by 8-dim critic
#   Phase 3 — Conflict Resolution: Split decisions trigger rebuttal round
#   Phase 4 — Audit:              Outcome pushed to HiveMemory sovereignty_stream
#
# API ROUTES (registered via app.py _register):
#   GET  /api/council/status        — engine status + historical stats
#   POST /api/council/deliberate    — submit a prompt for council deliberation
#   GET  /api/council/history       — past deliberation outcomes
#
# APP.PY REGISTRATION:
#   _loaded += _register("zeus_council_router", "council_bp")
# ================================================================

from __future__ import annotations

import concurrent.futures
import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.council")

council_bp = Blueprint("council", __name__)

ZEUS_DIR             = os.path.dirname(os.path.abspath(__file__))
DB_PATH              = os.path.join(ZEUS_DIR, "zeus.db")
DELIBERATION_TIMEOUT = 60   # seconds — full council window
FAST_TIMEOUT         = 15   # seconds — used for low-ring fast path
REBUTTAL_TIMEOUT     = 20   # seconds — winner critiques runner-up


# ─── DB INIT ─────────────────────────────────────────────────────────────────

def _init_db() -> None:
    con = sqlite3.connect(DB_PATH)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS council_deliberations (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            deliberation_id TEXT    UNIQUE NOT NULL,
            prompt_preview  TEXT    NOT NULL,
            ring            INTEGER NOT NULL,
            mode            TEXT    NOT NULL,
            winning_agent   TEXT    NOT NULL,
            confidence      REAL    NOT NULL,
            elapsed_s       REAL    NOT NULL,
            synthesis       TEXT    NOT NULL,
            raw_votes_json  TEXT    NOT NULL,
            ts              REAL    NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_council_ts ON council_deliberations(ts);
    """)
    con.close()

_init_db()


# ─── DATA CLASSES ─────────────────────────────────────────────────────────────

@dataclass
class CouncilVote:
    agent:      str
    response:   str
    confidence: float
    duration:   float
    is_timeout: bool = False
    error:      str  = ""

    def to_dict(self) -> Dict:
        return {
            "agent":      self.agent,
            "preview":    self.response[:200],
            "confidence": round(self.confidence, 4),
            "duration_s": round(self.duration, 2),
            "is_timeout": self.is_timeout,
        }


@dataclass
class CouncilVerdict:
    deliberation_id: str
    status:          str
    mode:            str
    ring:            int
    winning_agent:   str
    confidence:      float
    synthesis:       str
    raw_votes:       List[CouncilVote]
    elapsed_s:       float
    ts:              float = field(default_factory=time.time)

    def to_dict(self) -> Dict:
        return {
            "deliberation_id": self.deliberation_id,
            "status":          self.status,
            "mode":            self.mode,
            "ring":            self.ring,
            "winning_agent":   self.winning_agent,
            "confidence":      round(self.confidence, 4),
            "synthesis":       self.synthesis,
            "elapsed_s":       round(self.elapsed_s, 2),
            "raw_votes":       {v.agent: v.to_dict() for v in self.raw_votes},
            "ts":              self.ts,
        }


# ─── COUNCIL ENGINE ───────────────────────────────────────────────────────────

class ZeusCouncilRouter:
    """
    The sovereign AI council.
    Dispatches queries to Claude, Grok, DeepSeek, Gemini, and Perplexity.
    Gives them 60 seconds. Scores responses. Resolves conflicts via
    adversarial rebuttal. Returns a ratified consensus.
    """

    # Historical domain-specific confidence weights (updated by critic feedback)
    _WEIGHTS: Dict[str, float] = {
        "claude":      0.92,   # highest for legal, nuance, long-context
        "grok":        0.85,   # real-time data, contrarian reasoning
        "deepseek":    0.88,   # math, code, structured logic
        "gemini":      0.80,   # factual search, knowledge graph
        "perplexity":  0.84,   # citation-based retrieval, fact-checking
    }

    _instance: Optional["ZeusCouncilRouter"] = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if getattr(self, "_initialised", False):
            return
        self._initialised = True
        self._stats = {
            "total_deliberations": 0,
            "unanimous":           0,
            "adversarial":         0,
            "timeouts":            0,
            "errors":              0,
        }
        log.info("[council] AI Council Router online — 60s deliberation window")

    # ── Main entry point ─────────────────────────────────────────────────────

    def deliberate(self, prompt: str, context: str = "", ring: int = 6) -> CouncilVerdict:
        """
        Convene the council. Returns a CouncilVerdict with the ratified answer.
        Ring 6/7: full 60s window.
        Ring 1-5: fast path (15s, single best model).
        """
        if ring <= 5:
            return self._fast_path(prompt, context, ring)

        deliberation_id = str(uuid.uuid4())
        log.warning("[council] CONVENED id=%s ring=%d — 60s deliberation started", deliberation_id, ring)
        start = time.time()

        # Phase 1: Parallel dispatch
        raw_votes = self._dispatch(prompt, context)

        # Phase 2: Score
        scored = self._score(raw_votes, prompt)

        # Phase 3: Resolve
        verdict = self._resolve(scored, prompt, context, deliberation_id, ring)

        elapsed = time.time() - start
        verdict.elapsed_s = elapsed

        # Phase 4: Audit
        self._persist(verdict, prompt)
        self._push_to_hive(verdict)

        self._stats["total_deliberations"] += 1
        if verdict.mode == "UNANIMOUS_HIGH_CONFIDENCE":
            self._stats["unanimous"] += 1
        elif verdict.mode == "ADVERSARIAL_REBUTTAL":
            self._stats["adversarial"] += 1

        log.info("[council] CONCLUDED id=%s winner=%s elapsed=%.1fs conf=%.3f",
                 deliberation_id, verdict.winning_agent, elapsed, verdict.confidence)
        return verdict

    # ── Fast path for Ring 1-5 ────────────────────────────────────────────────

    def _fast_path(self, prompt: str, context: str, ring: int) -> CouncilVerdict:
        did = str(uuid.uuid4())
        start = time.time()
        try:
            resp, _ = self._call_claude(prompt, context)
            vote = CouncilVote("claude", resp, self._WEIGHTS["claude"], time.time() - start)
        except Exception as e:
            try:
                resp, _ = self._call_grok(prompt, context)
                vote = CouncilVote("grok", resp, self._WEIGHTS["grok"], time.time() - start)
            except Exception as e2:
                vote = CouncilVote("fallback", f"[Fast path error: {e2}]", 0.0, time.time() - start, error=str(e2))

        return CouncilVerdict(
            deliberation_id=did,
            status="fast_path",
            mode="RING_1_5_FAST",
            ring=ring,
            winning_agent=vote.agent,
            confidence=vote.confidence,
            synthesis=vote.response,
            raw_votes=[vote],
            elapsed_s=time.time() - start,
        )

    # ── Phase 1: Parallel dispatch ────────────────────────────────────────────

    def _dispatch(self, prompt: str, context: str) -> List[CouncilVote]:
        results: List[CouncilVote] = []

        agent_calls = {
            "claude":     lambda: self._call_claude(prompt, context),
            "grok":       lambda: self._call_grok(prompt, context),
            "deepseek":   lambda: self._call_deepseek(prompt, context),
            "gemini":     lambda: self._call_gemini(prompt, context),
            "perplexity": lambda: self._call_perplexity(prompt, context),
        }

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            future_map = {executor.submit(fn): name for name, fn in agent_calls.items()}

            try:
                for future in concurrent.futures.as_completed(
                    future_map, timeout=DELIBERATION_TIMEOUT
                ):
                    agent = future_map[future]
                    t0 = time.time()
                    try:
                        resp, conf = future.result(timeout=2)
                        results.append(CouncilVote(agent, resp, conf, time.time() - t0))
                    except concurrent.futures.TimeoutError:
                        log.warning("[council] %s timed out", agent)
                        results.append(CouncilVote(agent, "[Timeout]", 0.25,
                                                   DELIBERATION_TIMEOUT, is_timeout=True))
                        self._stats["timeouts"] += 1
                    except Exception as e:
                        log.error("[council] %s error: %s", agent, e)
                        results.append(CouncilVote(agent, f"[Error: {str(e)[:80]}]",
                                                   0.0, 0.0, error=str(e)))
                        self._stats["errors"] += 1
            except concurrent.futures.TimeoutError:
                # Overall 60s window expired — collect whatever we have
                for future, agent in future_map.items():
                    if not future.done():
                        results.append(CouncilVote(agent, "[Global timeout]",
                                                   0.20, DELIBERATION_TIMEOUT, is_timeout=True))

        return results

    # ── Phase 2: Score ────────────────────────────────────────────────────────

    def _score(self, votes: List[CouncilVote], prompt: str) -> List[CouncilVote]:
        """Score each response using inline heuristics + historical weights."""
        for vote in votes:
            if vote.confidence in (0.0, 0.25, 0.20) and not vote.error:
                # Already timeout-penalised; skip
                continue
            if vote.error or vote.is_timeout:
                continue
            raw_score = self._heuristic_score(vote.response, prompt)
            weight = self._WEIGHTS.get(vote.agent.lower(), 0.80)
            vote.confidence = min(1.0, raw_score * weight)

        return sorted(votes, key=lambda v: v.confidence, reverse=True)

    def _heuristic_score(self, response: str, prompt: str) -> float:
        """
        8-dimension scoring without an external critic module.
        Returns 0.0–1.0.
        """
        if not response or response.startswith("["):
            return 0.05
        score = 0.0
        length = len(response)
        # 1. Length adequacy (20%)
        score += min(0.20, length / 2000 * 0.20)
        # 2. Not an error (10%)
        if not any(kw in response.lower() for kw in ["error", "sorry", "cannot", "unable"]):
            score += 0.10
        # 3. Code present if prompt asks for code (15%)
        if any(kw in prompt.lower() for kw in ["code", "function", "implement", "write"]):
            if "```" in response or "def " in response or "class " in response:
                score += 0.15
            else:
                score += 0.03
        else:
            score += 0.10
        # 4. Has structure (10%)
        if any(c in response for c in ["\n", ":", "-", "1.", "•"]):
            score += 0.10
        # 5. Mentions key prompt terms (20%)
        prompt_words = set(w.lower() for w in prompt.split() if len(w) > 4)
        if prompt_words:
            hits = sum(1 for w in prompt_words if w in response.lower())
            score += min(0.20, hits / len(prompt_words) * 0.20)
        # 6. Confidence indicators (10%)
        if any(kw in response.lower() for kw in ["because", "therefore", "specifically",
                                                   "in summary", "conclusion"]):
            score += 0.10
        # 7. No hallucination signals (10%)
        if not any(kw in response.lower() for kw in ["i think maybe", "i'm not sure",
                                                       "possibly", "might be"]):
            score += 0.10
        # 8. Citations or evidence (5%)
        if any(c in response for c in ["http", "ref", "source", "according"]):
            score += 0.05

        return min(1.0, score)

    # ── Phase 3: Conflict resolution ─────────────────────────────────────────

    def _resolve(self, scored: List[CouncilVote], prompt: str, context: str,
                 did: str, ring: int) -> CouncilVerdict:

        if not scored:
            return CouncilVerdict(
                deliberation_id=did, status="error", mode="NO_RESPONSES", ring=ring,
                winning_agent="none", confidence=0.0,
                synthesis="Council returned no responses. Check API keys.",
                raw_votes=[], elapsed_s=0.0,
            )

        top    = scored[0]
        second = scored[1] if len(scored) > 1 else None

        # Unanimous: top is clearly ahead
        if second is None or (top.confidence - second.confidence) > 0.15:
            return CouncilVerdict(
                deliberation_id=did, status="ratified",
                mode="UNANIMOUS_HIGH_CONFIDENCE", ring=ring,
                winning_agent=top.agent, confidence=top.confidence,
                synthesis=top.response, raw_votes=scored, elapsed_s=0.0,
            )

        # Split: trigger adversarial rebuttal
        log.info("[council] Split decision (%.3f vs %.3f) — adversarial rebuttal",
                 top.confidence, second.confidence)

        rebuttal_prompt = (
            f"You are {top.agent}. Your answer was:\n{top.response[:400]}\n\n"
            f"A rival AI ({second.agent}) argued:\n{second.response[:400]}\n\n"
            "Critically examine the rival's argument. Point out the specific logical flaw "
            "or factual error. Then provide your final, strongest, most precise answer. "
            "Be definitive — no hedging."
        )

        try:
            final_resp, _ = self._call_claude(rebuttal_prompt, context)
            final_score = self._heuristic_score(final_resp, prompt) * self._WEIGHTS["claude"]
            top = CouncilVote("claude_rebuttal", final_resp, min(1.0, final_score), 0.0)
        except Exception as e:
            log.error("[council] Rebuttal failed: %s — using majority winner", e)

        return CouncilVerdict(
            deliberation_id=did, status="ratified",
            mode="ADVERSARIAL_REBUTTAL", ring=ring,
            winning_agent=top.agent, confidence=top.confidence,
            synthesis=top.response, raw_votes=scored, elapsed_s=0.0,
        )

    # ── Agent callers ─────────────────────────────────────────────────────────

    def _call_claude(self, prompt: str, context: str) -> Tuple[str, float]:
        from zeus_llm_router import get_router
        router = get_router()
        system = f"Context:\n{context}\n\nYou are a member of the Zeus AI Council. Reason carefully." if context else "You are a member of the Zeus AI Council. Reason carefully."
        resp = router.call_claude(prompt, system=system, max_tokens=2000)
        return resp, 0.0

    def _call_grok(self, prompt: str, context: str) -> Tuple[str, float]:
        from zeus_grok_bridge import get_grok_engine
        engine = get_grok_engine()
        system = f"Context:\n{context}\n\nYou are a member of the Zeus AI Council." if context else "You are a member of the Zeus AI Council."
        resp = engine.call(prompt, system=system)
        return resp, 0.0

    def _call_deepseek(self, prompt: str, context: str) -> Tuple[str, float]:
        try:
            from zeus_deepseek_bridge import get_deepseek_engine
            engine = get_deepseek_engine()
            resp = engine.call(prompt, context)
            return resp, 0.0
        except ImportError:
            pass
        # Fallback: route through llm_router with OpenRouter/DeepSeek model
        try:
            from zeus_llm_router import get_router
            router = get_router()
            resp = router._openrouter(
                prompt,
                system="You are a member of the Zeus AI Council. Specialise in mathematical and code reasoning.",
                max_tokens=2000
            )
            return resp, 0.0
        except Exception as e:
            return f"[DeepSeek unavailable: {e}]", 0.40

    def _call_gemini(self, prompt: str, context: str) -> Tuple[str, float]:
        try:
            from zeus_gemini_bridge import get_gemini_engine
            engine = get_gemini_engine()
            resp = engine.call(prompt, context)
            return resp, 0.0
        except ImportError:
            return "[Gemini bridge not yet installed — see zeus_gemini_bridge.py]", 0.45

    def _call_perplexity(self, prompt: str, context: str) -> Tuple[str, float]:
        try:
            from zeus_perplexity_bridge import get_perplexity_engine
            engine = get_perplexity_engine()
            resp = engine.call(prompt, context)
            return resp, 0.0
        except ImportError:
            return "[Perplexity bridge not yet installed — see zeus_perplexity_bridge.py]", 0.45

    # ── Persistence and Hive ──────────────────────────────────────────────────

    def _persist(self, v: CouncilVerdict, prompt: str) -> None:
        try:
            con = sqlite3.connect(DB_PATH)
            con.execute(
                "INSERT OR IGNORE INTO council_deliberations "
                "(deliberation_id,prompt_preview,ring,mode,winning_agent,confidence,"
                " elapsed_s,synthesis,raw_votes_json,ts) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (v.deliberation_id, prompt[:200], v.ring, v.mode, v.winning_agent,
                 v.confidence, v.elapsed_s, v.synthesis[:5000],
                 json.dumps({vt.agent: vt.to_dict() for vt in v.raw_votes}),
                 v.ts)
            )
            con.commit()
            con.close()
        except Exception as e:
            log.error("[council] persist error: %s", e)

    def _push_to_hive(self, v: CouncilVerdict) -> None:
        try:
            from zeus_hive_bridge import get_hive
            hive = get_hive()
            hive.publish_sovereignty(
                "council_verdict",
                {
                    "deliberation_id": v.deliberation_id,
                    "mode":            v.mode,
                    "winner":          v.winning_agent,
                    "confidence":      v.confidence,
                    "elapsed_s":       v.elapsed_s,
                    "synthesis":       v.synthesis[:300],
                }
            )
        except Exception as e:
            log.debug("[council] hive push error (non-fatal): %s", e)

    def stats(self) -> Dict:
        return {
            "status":              "online",
            "deliberation_timeout": DELIBERATION_TIMEOUT,
            "agents":              list(self._WEIGHTS.keys()),
            "weights":             self._WEIGHTS,
            **self._stats,
        }


# ─── SINGLETON ───────────────────────────────────────────────────────────────

_COUNCIL: Optional[ZeusCouncilRouter] = None
_COUNCIL_LOCK = threading.Lock()


def get_council() -> ZeusCouncilRouter:
    global _COUNCIL
    if _COUNCIL is None:
        with _COUNCIL_LOCK:
            if _COUNCIL is None:
                _COUNCIL = ZeusCouncilRouter()
    return _COUNCIL


# ─── FLASK ROUTES ─────────────────────────────────────────────────────────────

@council_bp.route("/api/council/status", methods=["GET"])
def council_status():
    return jsonify(get_council().stats())


@council_bp.route("/api/council/deliberate", methods=["POST"])
def council_deliberate():
    data    = request.get_json(force=True, silent=True) or {}
    prompt  = data.get("prompt", "").strip()
    context = data.get("context", "")
    ring    = int(data.get("ring", 6))
    if not prompt:
        return jsonify({"error": "prompt required"}), 400
    verdict = get_council().deliberate(prompt, context, ring)
    return jsonify(verdict.to_dict())


@council_bp.route("/api/council/history", methods=["GET"])
def council_history():
    try:
        limit = min(int(request.args.get("limit", 20)), 100)
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT deliberation_id,prompt_preview,ring,mode,winning_agent,"
            "confidence,elapsed_s,ts FROM council_deliberations "
            "ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
        con.close()
        return jsonify([dict(r) for r in rows])
    except Exception as e:
        return jsonify({"error": str(e)}), 500
