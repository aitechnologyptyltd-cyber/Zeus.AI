"""
zeus_govint_blueprint.py
========================
Zeus GovInt — Flask Blueprint
Author: Francois Nel | The Zeus Project 2026

Registers all GovInt routes into Zeus v8 Flask app.
Routes prefix: /api/govint/...
Dashboard:     /govint/dashboard
"""
from __future__ import annotations
import json, logging, os, sys, threading, time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from flask import Blueprint, request, jsonify, render_template_string, g

log = logging.getLogger("zeus.govint")

govint_bp = Blueprint("govint", __name__, url_prefix="/govint")

# ── Lazy-loaded singletons ────────────────────────────────────────────────────

_auth_gate = None
_geo_intel = None
_aegis = None
_init_lock = threading.Lock()

def _get_systems():
    global _auth_gate, _geo_intel, _aegis
    if _auth_gate is not None:
        return _auth_gate, _geo_intel, _aegis
    with _init_lock:
        if _auth_gate is not None:
            return _auth_gate, _geo_intel, _aegis
        try:
            # Import from govint package directory
            govint_dir = Path(__file__).parent
            sys.path.insert(0, str(govint_dir))
            sys.path.insert(0, str(govint_dir / "aegis_field"))

            from zeus_geo_auth import AuthorizationGate
            from zeus_geo_intel import ZeusGeoIntel
            from aegis_field.aegis_master import AegisFieldEngine

            ca_cert = os.environ.get("GOVINT_CA_CERT_PATH", "")
            _auth_gate = AuthorizationGate(
                db_path=str(govint_dir / "govint_warrants.db"),
                trusted_ca_cert_path=ca_cert if os.path.exists(ca_cert) else None
            )
            _geo_intel = ZeusGeoIntel(_auth_gate)
            _aegis = AegisFieldEngine(
                protected_root=str(govint_dir),
                allowed_ports=[int(os.environ.get("PORT", 8080)), 8889],
                scan_interval=120,
            )
            _aegis.initialise()
            _aegis.start_auto_scan(full=False)
            log.info("GovInt systems initialized successfully.")
        except Exception as e:
            log.error("GovInt system init failed: %s", e)
            _auth_gate = None
        return _auth_gate, _geo_intel, _aegis

# ── Dashboard ─────────────────────────────────────────────────────────────────

DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Zeus GovInt — Law Enforcement Command Center</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Courier New',monospace; background:linear-gradient(135deg,#0a0e27 0%,#1a1f3a 100%); color:#00ffcc; padding:16px; min-height:100vh; }
.header { background:rgba(0,0,0,0.7); border-bottom:2px solid #00ffcc; padding:20px; margin-bottom:20px; border-radius:8px; }
.header h1 { font-size:1.6em; text-shadow:0 0 10px #00ffcc; }
.header .sub { color:#888; font-size:0.8em; margin-top:6px; }
.live { display:inline-block; width:10px; height:10px; background:#ff3366; border-radius:50%; animation:pulse 1s infinite; margin-right:8px; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:20px; }
.card { background:rgba(0,0,0,0.6); border:1px solid #00ffcc; border-radius:8px; padding:16px; text-align:center; }
.card .val { font-size:2.2em; font-weight:bold; color:#ff3366; }
.card .lbl { font-size:0.75em; color:#aaa; margin-top:8px; }
.panel { background:rgba(0,0,0,0.6); border:1px solid #00ffcc; border-radius:8px; padding:16px; margin-bottom:16px; }
.panel h3 { color:#00ffcc; margin-bottom:12px; font-size:0.95em; }
.alert { background:rgba(255,51,102,0.1); border-left:3px solid #ff3366; padding:12px; margin-bottom:8px; border-radius:4px; font-size:0.8em; }
.alert .ip { color:#ffcc00; font-weight:bold; }
.alert .loc { color:#aaa; margin-top:4px; }
.badge { display:inline-block; padding:2px 8px; border-radius:3px; font-size:0.7em; font-weight:bold; }
.badge-crit { background:#ff3366; color:#fff; }
.badge-warn { background:#ffcc00; color:#000; }
.badge-ok { background:#00cc66; color:#000; }
.badge-info { background:#0066ff; color:#fff; }
input { background:#0a0e27; border:1px solid #00ffcc; color:#00ffcc; padding:8px; border-radius:4px; font-family:monospace; font-size:0.85em; }
input::placeholder { color:#555; }
button { background:#ff3366; color:#fff; border:none; padding:8px 16px; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.85em; }
button:hover { background:#ff6699; }
button.secondary { background:#0066ff; }
button.secondary:hover { background:#3399ff; }
.form-row { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:12px; }
.form-row input { flex:1; min-width:160px; }
.warrant-item { background:rgba(0,102,255,0.1); border-left:3px solid #0066ff; padding:10px; margin-bottom:8px; border-radius:4px; font-size:0.8em; }
.warrant-item .wid { color:#00ffcc; }
.auth-level { display:inline-block; padding:2px 6px; border-radius:3px; font-size:0.7em; font-weight:bold; background:#0066ff; color:#fff; }
.aegis-status { font-size:0.8em; color:#00ffcc; background:rgba(0,255,204,0.05); border:1px solid #00ffcc33; border-radius:4px; padding:8px; margin-bottom:16px; }
table { width:100%; border-collapse:collapse; font-size:0.75em; }
th { background:rgba(0,255,204,0.1); color:#00ffcc; padding:8px; text-align:left; border-bottom:1px solid #00ffcc33; }
td { padding:8px; border-bottom:1px solid #00ffcc11; color:#ccc; }
tr:hover td { background:rgba(0,255,204,0.05); }
.tabs { display:flex; gap:4px; margin-bottom:16px; }
.tab { padding:8px 16px; background:rgba(0,0,0,0.4); border:1px solid #00ffcc33; border-radius:4px; cursor:pointer; font-size:0.8em; }
.tab.active { background:rgba(0,255,204,0.2); border-color:#00ffcc; }
.tab-content { display:none; }
.tab-content.active { display:block; }
.map-placeholder { background:#050810; border:1px dashed #00ffcc33; border-radius:4px; height:200px; display:flex; align-items:center; justify-content:center; color:#555; font-size:0.8em; text-align:center; }
.footer { text-align:center; color:#555; font-size:0.65em; margin-top:20px; }
</style>
</head>
<body>
<div class="header">
  <h1>⚡ ZEUS GOVINT | LAW ENFORCEMENT COMMAND CENTER</h1>
  <div class="sub"><span class="live"></span>REAL-TIME THREAT INTELLIGENCE | SOUTH AFRICA | SECURED</div>
</div>

<div class="aegis-status" id="aegisStatus">⚙ AEGIS-FIELD: Loading...</div>

<div class="grid">
  <div class="card"><div class="val" id="statThreats">0</div><div class="lbl">Active Threats</div></div>
  <div class="card"><div class="val" id="statWarrants">0</div><div class="lbl">Active Warrants</div></div>
  <div class="card"><div class="val" id="statQueries">0</div><div class="lbl">Geo Queries (24h)</div></div>
  <div class="card"><div class="val" id="statAudit">0</div><div class="lbl">Audit Events</div></div>
</div>

<div class="tabs">
  <div class="tab active" onclick="switchTab('alerts')">🚨 Alerts</div>
  <div class="tab" onclick="switchTab('warrants')">📜 Warrants</div>
  <div class="tab" onclick="switchTab('locate')">📍 Locate</div>
  <div class="tab" onclick="switchTab('audit')">📋 Audit Log</div>
</div>

<div id="tab-alerts" class="tab-content active">
  <div class="panel">
    <h3>🚨 REAL-TIME THREAT ALERTS</h3>
    <div id="alertsList"><div class="alert">Awaiting threat data from Zeus Firewall...</div></div>
  </div>
</div>

<div id="tab-warrants" class="tab-content">
  <div class="panel">
    <h3>📜 WARRANT SUBMISSION</h3>
    <p style="font-size:0.75em;color:#aaa;margin-bottom:12px;">Submit RICA-compliant authorization documents to unlock geolocation tiers.</p>
    <div class="form-row">
      <input type="text" id="wDocType" placeholder="doc_type (e.g. high_court_warrant)" value="rica_court_order">
      <input type="text" id="wAuthority" placeholder="Issuing authority" value="South African Police Service">
    </div>
    <div class="form-row">
      <input type="text" id="wCaseNo" placeholder="Case number" value="CASE-2026-001">
      <input type="text" id="wTarget" placeholder="Target IP or MSISDN" value="">
    </div>
    <div class="form-row">
      <input type="text" id="wIssuedUtc" placeholder="issued_utc (ISO)" value="">
      <input type="text" id="wExpiresUtc" placeholder="expires_utc (ISO)" value="">
    </div>
    <div class="form-row">
      <input type="text" id="wAuthorizedBy" placeholder="Authorized by (Judge/Director)" value="">
      <input type="text" id="wSignature" placeholder="Signature (base64, or leave blank for test)" value="">
    </div>
    <div class="form-row">
      <input type="file" id="wDocFile" accept=".pdf,.json,.txt">
      <button onclick="submitWarrant()">SUBMIT DOCUMENT</button>
    </div>
    <div id="warrantResult" style="margin-top:8px;font-size:0.8em;"></div>
  </div>
  <div class="panel">
    <h3>✅ ACTIVE WARRANTS</h3>
    <div id="warrantsList"><em style="color:#555">No active warrants</em></div>
  </div>
</div>

<div id="tab-locate" class="tab-content">
  <div class="panel">
    <h3>📍 IP GEOLOCATION</h3>
    <div class="form-row">
      <input type="text" id="locateIp" placeholder="Target IP address" value="">
      <input type="text" id="locateOperator" placeholder="Operator badge/ID" value="">
      <button onclick="locateTarget()">LOCATE</button>
    </div>
    <div id="locateResult" style="margin-top:12px;"></div>
    <div class="map-placeholder" id="mapView">
      Location will appear here after query
    </div>
  </div>
</div>

<div id="tab-audit" class="tab-content">
  <div class="panel">
    <h3>📋 IMMUTABLE AUDIT LOG</h3>
    <table>
      <thead><tr><th>Time</th><th>Action</th><th>Target</th><th>Operator</th><th>Result</th></tr></thead>
      <tbody id="auditTable"><tr><td colspan="5" style="color:#555">Loading...</td></tr></tbody>
    </table>
  </div>
</div>

<div class="footer">
  ZEUS GOVINT v1.0 | AEGIS-FIELD v1.0.0 | The Zeus Project 2026 — Francois Nel<br>
  All geolocation queries are immutably logged with chain-of-custody hashes. RICA compliant.
</div>

<script>
function switchTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('tab-'+name).classList.add('active');
}

async function api(path, opts={}) {
  try {
    const r = await fetch('/govint/api/'+path, {headers:{'Content-Type':'application/json'},...opts});
    return await r.json();
  } catch(e) { return {error: e.message}; }
}

async function refreshStats() {
  const d = await api('stats');
  document.getElementById('statThreats').textContent = d.active_threats || 0;
  document.getElementById('statWarrants').textContent = d.active_warrants || 0;
  document.getElementById('statQueries').textContent = d.queries_24h || 0;
  document.getElementById('statAudit').textContent = d.audit_events || 0;
}

async function refreshAegis() {
  const d = await api('aegis/status');
  document.getElementById('aegisStatus').textContent = '⚙ AEGIS-FIELD: ' + (d.status || 'Unavailable');
}

async function refreshAlerts() {
  const d = await api('alerts');
  const el = document.getElementById('alertsList');
  if (!d.alerts || !d.alerts.length) { el.innerHTML='<div class="alert">No alerts yet.</div>'; return; }
  el.innerHTML = d.alerts.map(a => `
    <div class="alert">
      <div>
        <span class="badge ${a.risk_score>80?'badge-crit':'badge-warn'}">${a.risk_score>80?'CRITICAL':'WARNING'}</span>
        <span class="ip"> ${a.target_ip}</span>
        <span style="float:right;color:#555;font-size:0.75em">${new Date(a.timestamp_utc).toLocaleTimeString()}</span>
      </div>
      <div class="loc">📍 ${a.city}, ${a.region}, ${a.country} (${a.method})</div>
      <div style="color:#666;font-size:0.75em;margin-top:4px">Auth: <span class="auth-level">${a.auth_level}</span></div>
    </div>`).join('');
}

async function refreshWarrants() {
  const d = await api('warrants');
  const el = document.getElementById('warrantsList');
  if (!d.warrants || !d.warrants.length) { el.innerHTML='<em style="color:#555">No active warrants</em>'; return; }
  el.innerHTML = d.warrants.map(w => `
    <div class="warrant-item">
      <div><span class="wid">${w.doc_id.slice(0,8)}...</span>
        <span class="badge badge-ok" style="margin-left:8px">${w.doc_type.replace(/_/g,' ').toUpperCase()}</span>
        <span class="auth-level" style="margin-left:8px">${w.auth_level}</span>
      </div>
      <div style="margin-top:6px;color:#aaa">🏛 ${w.issuing_authority}</div>
      <div style="color:#666;font-size:0.75em">Case: ${w.case_number} | Target: ${w.target_identifier} | Expires: ${w.expires_utc}</div>
    </div>`).join('');
}

async function refreshAudit() {
  const d = await api('audit');
  const tbody = document.getElementById('auditTable');
  if (!d.entries || !d.entries.length) { tbody.innerHTML='<tr><td colspan="5" style="color:#555">No audit entries</td></tr>'; return; }
  tbody.innerHTML = d.entries.map(e => `
    <tr>
      <td>${new Date(e.timestamp_utc).toLocaleTimeString()}</td>
      <td><span class="badge ${e.result==='OK'||e.result==='APPROVED'||e.result==='LOGGED'?'badge-ok':e.result==='REJECTED'?'badge-crit':'badge-warn'}">${e.action}</span></td>
      <td>${e.target_identifier||'-'}</td>
      <td>${e.operator||'-'}</td>
      <td style="color:${e.result==='OK'||e.result==='APPROVED'||e.result==='LOGGED'?'#00cc66':'#ff3366'}">${e.result}</td>
    </tr>`).join('');
}

async function submitWarrant() {
  const el = document.getElementById('warrantResult');
  el.textContent = 'Submitting...';
  const fileEl = document.getElementById('wDocFile');
  let docContent = '';
  if (fileEl.files.length > 0) {
    docContent = await fileEl.files[0].text();
  } else {
    docContent = JSON.stringify({
      doc_type: document.getElementById('wDocType').value,
      issuing_authority: document.getElementById('wAuthority').value,
      case_number: document.getElementById('wCaseNo').value,
      target_identifier: document.getElementById('wTarget').value,
      issued_utc: document.getElementById('wIssuedUtc').value || new Date().toISOString(),
      expires_utc: document.getElementById('wExpiresUtc').value || new Date(Date.now()+86400000*30).toISOString(),
      authorized_by: document.getElementById('wAuthorizedBy').value,
    });
  }

  const payload = {
    document_content: docContent,
    metadata: {
      doc_type: document.getElementById('wDocType').value,
      issuing_authority: document.getElementById('wAuthority').value,
      case_number: document.getElementById('wCaseNo').value,
      target_identifier: document.getElementById('wTarget').value,
      issued_utc: document.getElementById('wIssuedUtc').value || new Date().toISOString(),
      expires_utc: document.getElementById('wExpiresUtc').value || new Date(Date.now()+86400000*30).toISOString(),
      authorized_by: document.getElementById('wAuthorizedBy').value,
      signature_b64: document.getElementById('wSignature').value || null,
    },
    operator: document.getElementById('locateOperator').value || 'dashboard'
  };

  const d = await api('warrant/submit', {method:'POST', body:JSON.stringify(payload)});
  el.style.color = d.success ? '#00cc66' : '#ff3366';
  el.textContent = (d.success ? '✓ ' : '✗ ') + (d.message || JSON.stringify(d));
  if (d.success) { refreshWarrants(); refreshStats(); }
}

async function locateTarget() {
  const ip = document.getElementById('locateIp').value.trim();
  const op = document.getElementById('locateOperator').value.trim() || 'dashboard';
  if (!ip) { alert('Enter a target IP address'); return; }
  const resEl = document.getElementById('locateResult');
  const mapEl = document.getElementById('mapView');
  resEl.innerHTML = '<div style="color:#aaa">Locating...</div>';

  const d = await api('locate', {method:'POST', body:JSON.stringify({target_ip:ip,operator:op})});
  if (d.error) { resEl.innerHTML=`<div style="color:#ff3366">Error: ${d.error}</div>`; return; }

  const geo = d.ip_geolocation || {};
  const precise = d.precise_location || {};
  resEl.innerHTML = `
    <div style="background:rgba(0,255,204,0.05);border:1px solid #00ffcc33;border-radius:4px;padding:12px;font-size:0.8em">
      <div><strong style="color:#00ffcc">Auth Level:</strong> <span class="auth-level">${d.auth_level}</span></div>
      <div style="margin-top:8px"><strong style="color:#00ffcc">IP Geolocation:</strong>
        ${geo.city}, ${geo.region}, ${geo.country} (±${geo.accuracy_km}km)
      </div>
      <div><strong style="color:#00ffcc">Coordinates:</strong> ${(precise.lat||geo.lat||0).toFixed(4)}, ${(precise.lon||geo.lon||0).toFixed(4)}</div>
      <div><strong style="color:#00ffcc">Method:</strong> ${precise.method||geo.method||'IP_GEOLOCATION'}</div>
      <div><strong style="color:#00ffcc">ISP:</strong> ${geo.isp||'Unknown'}</div>
      ${d.legal_status?.warrant_active ? `<div style="color:#00cc66;margin-top:6px">✓ Warrant active: ${d.legal_status.case_number}</div>` : '<div style="color:#ffcc00;margin-top:6px">⚠ No active warrant — IP geolocation only</div>'}
      ${d.action_recommendations.map(r=>`<div style="margin-top:4px;color:#aaa">→ ${r.action}: ${r.detail}</div>`).join('')}
    </div>`;

  const lat = precise.lat || geo.lat || 0;
  const lon = precise.lon || geo.lon || 0;
  if (lat && lon) {
    mapEl.innerHTML = `<iframe
      width="100%" height="100%" frameborder="0" style="border-radius:4px"
      src="https://maps.google.com/maps?q=${lat},${lon}&z=12&output=embed">
    </iframe>`;
  }
  refreshStats();
}

async function init() {
  await refreshStats();
  await refreshAegis();
  await refreshAlerts();
  await refreshWarrants();
  await refreshAudit();
  setInterval(async()=>{
    await refreshStats();
    await refreshAlerts();
    await refreshAudit();
  }, 5000);
  setInterval(refreshAegis, 30000);
  setInterval(refreshWarrants, 10000);
}
init();
</script>
</body>
</html>
"""

# ── API Routes ────────────────────────────────────────────────────────────────

@govint_bp.route("/dashboard")
def dashboard():
    return render_template_string(DASHBOARD_HTML)

@govint_bp.route("/api/stats")
def api_stats():
    auth_gate, geo_intel, aegis = _get_systems()
    if not auth_gate:
        return jsonify({"error": "GovInt systems not initialized"}), 503
    import sqlite3
    db_path = auth_gate.db_path
    with sqlite3.connect(db_path) as conn:
        warrants = conn.execute("SELECT COUNT(*) FROM authorization_documents WHERE signature_verified=1 AND rica_compliant=1").fetchone()[0]
        queries = conn.execute("SELECT COUNT(*) FROM geolocation_queries WHERE epoch > ?", (time.time()-86400,)).fetchone()[0]
        audit = conn.execute("SELECT COUNT(*) FROM authorization_audit").fetchone()[0]
        alerts = conn.execute("SELECT COUNT(*) FROM geolocation_queries WHERE epoch > ?", (time.time()-3600,)).fetchone()[0]
    return jsonify({"active_warrants": warrants, "queries_24h": queries,
                    "audit_events": audit, "active_threats": alerts})

@govint_bp.route("/api/aegis/status")
def api_aegis_status():
    _, _, aegis = _get_systems()
    if not aegis:
        return jsonify({"status": "AEGIS-FIELD not initialized", "ok": False})
    try:
        status = aegis.status()
        return jsonify({"status": status, "ok": True})
    except Exception as e:
        return jsonify({"status": f"Error: {e}", "ok": False})

@govint_bp.route("/api/alerts")
def api_alerts():
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"alerts": []})
    import sqlite3
    with sqlite3.connect(auth_gate.db_path) as conn:
        cursor = conn.execute("""
            SELECT gq.timestamp_utc, gq.target_identifier, gq.query_type,
                   gq.result_lat, gq.result_lon, gq.accuracy_meters, gq.method,
                   NULL AS auth_level
            FROM geolocation_queries gq
            LEFT JOIN authorization_documents ad ON gq.doc_id = ad.doc_id
            ORDER BY gq.epoch DESC LIMIT 50
        """)
        # NOTE: authorization_documents genuinely has no auth_level column
        # (confirmed against its actual CREATE TABLE in zeus_geo_auth.py —
        # doc_id/doc_type/issuing_authority/case_number/target_identifier/
        # issued_utc/expires_utc/authorized_by/document_hash/signature_b64/
        # signature_verified/rica_compliant/uploaded_utc/upload_ip/
        # upload_user). This was crashing every call to /govint/api/alerts
        # with "no such column: ad.auth_level". Swapped in NULL so the
        # response shape (an auth_level key per row) is preserved without
        # guessing at unconfirmed business intent — closest real candidate
        # is doc_type, but that's your call, not mine to silently assume.
        cols = [d[0] for d in cursor.description]
        rows = [dict(zip(cols, row)) for row in cursor.fetchall()]

    # Enrich with cached IP geo data
    from zeus_geo_intel import IPGeolocator
    geolocator = IPGeolocator()
    alerts = []
    for row in rows:
        ip = row.get("target_identifier", "")
        geo = geolocator.resolve(ip) if ip and not row.get("result_lat") else {}
        alerts.append({
            "timestamp_utc": row["timestamp_utc"],
            "target_ip": ip,
            "city": geo.get("city", "Unknown"),
            "region": geo.get("region", "Unknown"),
            "country": geo.get("country", "Unknown"),
            "method": row.get("method") or geo.get("method","IP_GEO"),
            "auth_level": row.get("auth_level","IP_GEOLOCATION"),
            "risk_score": 75,  # Integrate with Zeus Firewall risk score
        })
    return jsonify({"alerts": alerts})

@govint_bp.route("/api/locate", methods=["POST"])
def api_locate():
    auth_gate, geo_intel, aegis = _get_systems()
    if not geo_intel:
        return jsonify({"error": "GovInt systems not initialized"}), 503
    data = request.get_json() or {}
    target_ip = data.get("target_ip", "")
    operator  = data.get("operator", "api")
    threat_ctx = data.get("threat_context")
    if not target_ip:
        return jsonify({"error": "target_ip required"}), 400
    result = geo_intel.locate(target_ip, operator, threat_ctx)
    return jsonify(result)

@govint_bp.route("/api/warrant/submit", methods=["POST"])
def api_warrant_submit():
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"success": False, "message": "Auth gate not initialized"}), 503
    data = request.get_json() or {}
    doc_content = data.get("document_content", "{}")
    metadata    = data.get("metadata", {})
    operator    = data.get("operator", "api")
    doc_bytes   = doc_content.encode() if isinstance(doc_content, str) else doc_content
    success, message, doc = auth_gate.submit_document(doc_bytes, metadata, operator)
    resp = {"success": success, "message": message}
    if doc:
        resp["doc_id"] = doc.doc_id
        resp["doc_type"] = doc.doc_type.value
        resp["signature_verified"] = doc.signature_verified
        resp["rica_compliant"] = doc.rica_compliant
        resp["auth_level_unlocked"] = auth_gate._get_auth_level(doc).name if success else "IP_GEOLOCATION"
    return jsonify(resp)

@govint_bp.route("/api/warrants")
def api_warrants():
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"warrants": []})
    warrants = auth_gate.get_active_warrants()
    # Add auth_level to each warrant
    for w in warrants:
        from zeus_geo_auth import AuthorizationGate, DocumentType, AuthLevel
        try:
            from zeus_geo_auth import AuthorizationGate as AG
            tmp = AG.__new__(AG)
            tmp._active_documents = {}
            from zeus_geo_auth import AuthDocument, LegalStatus
        except Exception:
            pass
        w["auth_level"] = "CARRIER_CSLI" if w.get("doc_type") == "high_court_warrant" else \
                          "SUBSCRIBER_QUERY" if w.get("doc_type") == "rica_court_order" else \
                          "PRIORITY_CSLI" if w.get("doc_type") == "national_security_directive" else \
                          "IP_GEOLOCATION"
    return jsonify({"warrants": warrants})

@govint_bp.route("/api/audit")
def api_audit():
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"entries": []})
    entries = auth_gate.get_audit_log(limit=100)
    return jsonify({"entries": entries})

@govint_bp.route("/api/warrant/revoke/<doc_id>", methods=["DELETE"])
def api_revoke(doc_id: str):
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"success": False}), 503
    operator = request.args.get("operator", "api")
    success = auth_gate.revoke_document(doc_id, operator)
    return jsonify({"success": success, "doc_id": doc_id})

@govint_bp.route("/api/forensics/export", methods=["POST"])
def api_export_forensics():
    _, _, aegis = _get_systems()
    if not aegis:
        return jsonify({"error": "AEGIS not initialized"}), 503
    import tempfile
    output_path = os.path.join(tempfile.gettempdir(), f"aegis_incident_{int(time.time())}.json")
    aegis.forensics.export_bundle(output_path)
    report = aegis.forensics.human_readable_report()
    return jsonify({"exported_to": output_path,
                    "incident_count": aegis.forensics.incident_count,
                    "report_preview": report[:2000]})

# ── Visual / On-Device Geo-Intel routes (v2.1, additive) ──────────────────────
# Extends GovInt with ATLAS.AI-derived on-device coordinate extraction
# (zeus_geo_vision.py) and cluster/pattern analytics (zeus_geo_cluster.py).
# Every mutating or surveillance-grade call is ring-classified through
# zeus_sovereignty_engine.sovereign_execute() before it runs, exactly
# like every other Zeus action — these routes add NO bypass of the
# Ring/Council/audit model already governing the rest of GovInt.

@govint_bp.route("/api/vision/extract", methods=["POST"])
def api_vision_extract():
    """
    Single-shot visual geolocation read from an ADB-reachable device.
    Ring 3 (read-only) — executes immediately, logged, no Council needed.
    """
    auth_gate, geo_intel, _ = _get_systems()
    if not geo_intel:
        return jsonify({"error": "GovInt systems not initialized"}), 503
    data = request.get_json() or {}
    device_serial = data.get("device_serial", "")
    target_identifier = data.get("target_identifier", device_serial)
    operator = data.get("operator", "api")
    tap_x = data.get("tap_x")
    tap_y = data.get("tap_y")
    tag_filters = data.get("tag_filters")
    if not device_serial:
        return jsonify({"error": "device_serial required"}), 400

    from zeus_sovereignty_engine import sovereign_execute
    gate_result = sovereign_execute(
        "geo_visual_extract",
        f"Visual geo extraction from device {device_serial}",
        {"device_serial": device_serial, "target_identifier": target_identifier},
    )
    result = geo_intel.locate_device(device_serial, target_identifier, operator,
                                      tap_x=tap_x, tap_y=tap_y, tag_filters=tag_filters)
    result["sovereignty_gate"] = gate_result
    return jsonify(result)

@govint_bp.route("/api/vision/target_lock", methods=["POST"])
def api_vision_target_lock():
    """
    Sustained/repeated visual tracking request for one device.
    Ring 6 (advisory) — 30s human veto window + AI Council deliberation
    before this is approved; this route only SUBMITS the request, it
    does not itself execute repeated extraction.
    """
    _, _, _ = _get_systems()
    data = request.get_json() or {}
    device_serial = data.get("device_serial", "")
    justification = data.get("justification", "")
    if not device_serial:
        return jsonify({"error": "device_serial required"}), 400

    from zeus_sovereignty_engine import sovereign_execute
    gate_result = sovereign_execute(
        "geo_visual_target_lock",
        f"Sustained visual tracking request for device {device_serial}: {justification}",
        {"device_serial": device_serial, "justification": justification},
    )
    return jsonify({"device_serial": device_serial, "sovereignty_gate": gate_result})

@govint_bp.route("/api/vision/calibrate", methods=["POST"])
def api_vision_calibrate():
    """
    Stores viewport calibration (two known lat/lon reference points
    mapped to two pixel positions) used by VisualGeoExtractor's
    tap-position interpolation fallback. Ring 3 — local config write.
    """
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"error": "GovInt systems not initialized"}), 503
    data = request.get_json() or {}
    required = ("device_serial", "lat_tl", "lon_tl", "lat_br", "lon_br")
    if not all(k in data for k in required):
        return jsonify({"error": f"required fields: {required}"}), 400

    from zeus_sovereignty_engine import sovereign_execute
    gate_result = sovereign_execute(
        "geo_visual_calibrate",
        f"Viewport calibration for device {data['device_serial']}",
        data,
    )
    import sqlite3
    with sqlite3.connect(auth_gate.db_path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS vision_calibration (
                device_serial TEXT PRIMARY KEY,
                lat_tl REAL, lon_tl REAL, lat_br REAL, lon_br REAL,
                px_x1 REAL, px_y1 REAL, px_x2 REAL, px_y2 REAL,
                updated_utc TEXT
            )
        """)
        conn.execute("""
            INSERT OR REPLACE INTO vision_calibration
            (device_serial, lat_tl, lon_tl, lat_br, lon_br, px_x1, px_y1, px_x2, px_y2, updated_utc)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (data["device_serial"], data["lat_tl"], data["lon_tl"], data["lat_br"], data["lon_br"],
              data.get("px_x1", 0), data.get("px_y1", 0), data.get("px_x2", 1080), data.get("px_y2", 1920),
              datetime.now(timezone.utc).isoformat()))
    return jsonify({"success": True, "device_serial": data["device_serial"], "sovereignty_gate": gate_result})

@govint_bp.route("/api/cluster/<target_identifier>")
def api_cluster(target_identifier: str):
    """
    Clusters all logged geolocation_queries for a target into places
    of interest. Ring 3 — read-only aggregation over already-logged,
    already-authorized data; no new location data is derived.
    """
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"error": "GovInt systems not initialized"}), 503
    from zeus_sovereignty_engine import sovereign_execute
    gate_result = sovereign_execute(
        "geo_cluster_analyze", f"Cluster analysis for {target_identifier}",
        {"target_identifier": target_identifier},
    )
    from zeus_geo_cluster import GeoClusterEngine
    engine = GeoClusterEngine(auth_gate.db_path)
    result = engine.cluster(target_identifier)
    result["sovereignty_gate"] = gate_result
    return jsonify(result)

@govint_bp.route("/api/pattern/<target_identifier>")
def api_pattern(target_identifier: str):
    """
    Pattern-of-life summary (ranked places of interest, single- vs
    multi-location triage signal) built on top of cluster analysis.
    Ring 3 — same justification as /api/cluster above.
    """
    auth_gate, _, _ = _get_systems()
    if not auth_gate:
        return jsonify({"error": "GovInt systems not initialized"}), 503
    from zeus_sovereignty_engine import sovereign_execute
    gate_result = sovereign_execute(
        "geo_pattern_report", f"Pattern-of-life report for {target_identifier}",
        {"target_identifier": target_identifier},
    )
    from zeus_geo_cluster import GeoClusterEngine
    engine = GeoClusterEngine(auth_gate.db_path)
    result = engine.pattern_report(target_identifier)
    result["sovereignty_gate"] = gate_result
    return jsonify(result)

# ── Zeus v8 registration ──────────────────────────────────────────────────────

def register(app):
    """Register blueprint into Zeus v8 Flask app."""
    app.register_blueprint(govint_bp)
    log.info("[ok] zeus_govint_blueprint registered at /govint")
    return True
