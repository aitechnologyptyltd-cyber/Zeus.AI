# The Zeus Project 2026 — Francois Nel SA ID 8708275089084
# zeus_deepseek_bridge.py — DeepSeek API Bridge v1.0
# ====================================================
#
# Follows the exact same pattern as zeus_grok_bridge.py:
#   - Per-model circuit breaker
#   - Call stats dataclass
#   - DeepSeekEngine class
#   - Singleton accessor
#
# DeepSeek uses an OpenAI-compatible API endpoint.
# API key: DEEPSEEK_API_KEY in .env
# Default model: deepseek-chat (V3 — best for code/math)
# Alt model: deepseek-reasoner (R1 — best for deep logic)
#
# Council role: Mathematical reasoning, structured logic, code analysis.
#
# APP.PY: No separate route registration needed.
#         Imported directly by zeus_council_router.py.
# ====================================================

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

log = logging.getLogger("zeus.deepseek")

DEEPSEEK_API_KEY   = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL  = "https://api.deepseek.com"
DEFAULT_MODEL      = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
REASONER_MODEL     = "deepseek-reasoner"
DEFAULT_MAX_TOKENS = 2000
DEFAULT_TIMEOUT    = 55  # stay under 60s council window


# ─── CIRCUIT BREAKER ─────────────────────────────────────────────────────────

class DeepSeekCircuitBreaker:
    """Per-model circuit breaker — trips after 4 consecutive failures."""

    def __init__(self, failure_threshold: int = 4, cooldown_s: float = 90.0):
        self._threshold  = failure_threshold
        self._cooldown   = cooldown_s
        self._failures   = 0
        self._tripped_at: Optional[float] = None
        self._lock       = threading.Lock()

    def allow(self) -> bool:
        with self._lock:
            if self._tripped_at is None:
                return True
            if time.time() - self._tripped_at >= self._cooldown:
                self._failures   = 0
                self._tripped_at = None
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            self._failures   = 0
            self._tripped_at = None

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._tripped_at = time.time()
                log.warning("[deepseek] Circuit breaker OPEN (%d failures)", self._failures)

    def state(self) -> str:
        with self._lock:
            if self._tripped_at is None:
                return "CLOSED"
            if time.time() - self._tripped_at >= self._cooldown:
                return "HALF_OPEN"
            return "OPEN"


# ─── STATS ───────────────────────────────────────────────────────────────────

@dataclass
class DeepSeekStats:
    model:         str
    total_calls:   int  = 0
    success_calls: int  = 0
    error_calls:   int  = 0
    total_tokens:  int  = 0
    total_ms:      float = 0.0
    last_error:    str   = ""

    def record(self, tokens: int, ms: float, success: bool, error: str = "") -> None:
        self.total_calls  += 1
        self.total_ms     += ms
        self.total_tokens += tokens
        if success:
            self.success_calls += 1
        else:
            self.error_calls += 1
            self.last_error   = error[:200]

    def success_rate(self) -> float:
        return self.success_calls / max(self.total_calls, 1)

    def avg_ms(self) -> float:
        return self.total_ms / max(self.total_calls, 1)

    def to_dict(self) -> Dict:
        return {
            "model":        self.model,
            "total_calls":  self.total_calls,
            "success_rate": round(self.success_rate(), 3),
            "avg_ms":       round(self.avg_ms(), 1),
            "total_tokens": self.total_tokens,
            "last_error":   self.last_error,
        }


# ─── ENGINE ──────────────────────────────────────────────────────────────────

class DeepSeekEngine:
    """
    DeepSeek API engine.
    Uses openai-compatible SDK (openai package already in requirements.txt).
    """

    def __init__(self):
        self._cb_chat     = DeepSeekCircuitBreaker()
        self._cb_reasoner = DeepSeekCircuitBreaker()
        self._stats_chat  = DeepSeekStats(model=DEFAULT_MODEL)
        self._stats_reason = DeepSeekStats(model=REASONER_MODEL)
        self._client      = None
        self._client_lock = threading.Lock()

    def _get_client(self):
        """Lazy-init OpenAI-compatible client pointing at DeepSeek."""
        if self._client is not None:
            return self._client
        with self._client_lock:
            if self._client is not None:
                return self._client
            try:
                from openai import OpenAI
                api_key = DEEPSEEK_API_KEY
                if not api_key:
                    raise RuntimeError("DEEPSEEK_API_KEY not set in environment")
                self._client = OpenAI(
                    api_key=api_key,
                    base_url=DEEPSEEK_BASE_URL,
                )
                log.info("[deepseek] Client initialised (base_url=%s)", DEEPSEEK_BASE_URL)
            except ImportError:
                raise RuntimeError("openai package required: pip install openai --break-system-packages")
        return self._client

    def call(self, prompt: str, context: str = "",
             model: Optional[str] = None,
             max_tokens: int = DEFAULT_MAX_TOKENS,
             timeout: int = DEFAULT_TIMEOUT) -> str:
        """
        Single call to DeepSeek.
        model=None → DEFAULT_MODEL (deepseek-chat / V3)
        model="reasoner" → deepseek-reasoner (R1, best for deep logic)
        """
        target_model = REASONER_MODEL if model == "reasoner" else (model or DEFAULT_MODEL)
        cb    = self._cb_reasoner if "reasoner" in target_model else self._cb_chat
        stats = self._stats_reason if "reasoner" in target_model else self._stats_chat

        if not cb.allow():
            raise RuntimeError(f"[deepseek] Circuit breaker OPEN for model {target_model}")

        system = (
            f"Context:\n{context}\n\nYou are a member of the Zeus AI Council. "
            "Specialise in mathematical precision, structured logic, and code quality."
        ) if context else (
            "You are a member of the Zeus AI Council. "
            "Specialise in mathematical precision, structured logic, and code quality."
        )

        messages = [
            {"role": "system", "content": system},
            {"role": "user",   "content": prompt},
        ]

        t0 = time.time()
        try:
            client   = self._get_client()
            response = client.chat.completions.create(
                model=target_model,
                messages=messages,
                max_tokens=max_tokens,
                timeout=timeout,
            )
            elapsed  = (time.time() - t0) * 1000
            text     = response.choices[0].message.content or ""
            tokens   = getattr(response.usage, "total_tokens", 0)
            stats.record(tokens, elapsed, True)
            cb.record_success()
            log.info("[deepseek] %s success %.0fms %d tokens", target_model, elapsed, tokens)
            return text
        except Exception as e:
            elapsed = (time.time() - t0) * 1000
            stats.record(0, elapsed, False, str(e))
            cb.record_failure()
            log.error("[deepseek] %s error: %s", target_model, e)
            raise

    def call_with_context(self, prompt: str, context: str,
                          use_reasoner: bool = False) -> str:
        """Convenience wrapper: chat vs reasoner toggle."""
        model = "reasoner" if use_reasoner else None
        return self.call(prompt, context=context, model=model)

    def is_available(self) -> bool:
        return bool(DEEPSEEK_API_KEY) and self._cb_chat.allow()

    def stats(self) -> Dict:
        return {
            "available":      self.is_available(),
            "api_key_set":    bool(DEEPSEEK_API_KEY),
            "circuit_chat":   self._cb_chat.state(),
            "circuit_reason": self._cb_reasoner.state(),
            "stats_chat":     self._stats_chat.to_dict(),
            "stats_reasoner": self._stats_reason.to_dict(),
        }


# ─── SINGLETON ───────────────────────────────────────────────────────────────

_INSTANCE: Optional[DeepSeekEngine] = None
_LOCK = threading.Lock()


def get_deepseek_engine() -> DeepSeekEngine:
    global _INSTANCE
    if _INSTANCE is None:
        with _LOCK:
            if _INSTANCE is None:
                _INSTANCE = DeepSeekEngine()
    return _INSTANCE


def call_deepseek(prompt: str, context: str = "",
                  use_reasoner: bool = False) -> str:
    """Module-level convenience function."""
    return get_deepseek_engine().call_with_context(prompt, context, use_reasoner)
