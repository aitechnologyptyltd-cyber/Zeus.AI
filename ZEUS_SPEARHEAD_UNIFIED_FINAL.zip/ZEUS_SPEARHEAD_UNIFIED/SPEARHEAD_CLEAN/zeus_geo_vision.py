"""
zeus_geo_vision.py
===================
Zeus GovInt — Visual / On-Device Geolocation Extraction
The Zeus Project 2026 — additive GovInt extension (v2.1)

Origin: ported and generalised from ATLAS.AI's on-device coordinate
extraction pipeline (atlas_vision.py / atlas_map.py), which proved out
OCR + ADB based real-coordinate scraping against a live Android UI.
Here it is generalised from "read Atlas Earth's map HUD" to "read
coordinate/location data exposed by ANY ADB-reachable device screen",
and wired into GovInt's authorization + ring-gating model instead of
running unmonitored.

This module adds a THIRD geolocation method alongside the existing
IPGeolocator (Tier 0, no warrant) and CarrierCSLIInterface (Tier 2-4,
warrant+MOU gated) already present in zeus_geo_intel.py:

  TIER: VISUAL_DEVICE — extracts location data directly from a device's
  on-screen state via ADB screencap + OpenCV/Tesseract OCR, ADB logcat
  scraping, or tap-position interpolation against a calibrated viewport.
  This requires physical/ADB access to the target device (not a remote
  network capability), so it is gated by Sovereignty Ring classification
  rather than by the warrant system — see GEO_VISION_RING_TYPES below
  and zeus_govint_blueprint.py's /api/locate/visual route.

Nothing in zeus_geo_intel.py, zeus_geo_auth.py, or any existing GovInt
route is modified or removed by this module. It is purely additive.

Optional dependencies (already declared for OCR elsewhere in the
codebase): opencv-python (cv2), pytesseract. Both degrade gracefully —
if unavailable, OCR-based extraction is skipped and the module falls
back to logcat scraping / tap interpolation / a clearly-flagged miss.
"""
from __future__ import annotations

import json
import logging
import math
import re
import subprocess
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("zeus.geo_vision")

try:
    import cv2
    import numpy as np
    CV2_OK = True
except ImportError:
    CV2_OK = False

try:
    import pytesseract
    TESS_OK = True
except ImportError:
    TESS_OK = False


# ── Sovereignty ring wiring (additive only) ──────────────────────────────────
# Imported by zeus_sovereignty_engine.py's ring-type sets, NOT by editing
# the engine's classification logic in place — see integration note at
# the bottom of this file and SOVEREIGNTY_INTEGRATION.md.
GEO_VISION_RING_TYPES = {
    "geo_visual_extract":      3,  # single-shot screencap + OCR read — read-only
    "geo_visual_calibrate":    3,  # viewport calibration write (local config only)
    "geo_visual_target_lock":  6,  # sustained/repeated tracking of one device — advisory + Council
}


# ── Device coordinate ROI / calibration model ────────────────────────────────

@dataclass
class VisionROI:
    """A screen region (y1,y2,x1,x2) believed to contain coordinate text."""
    name: str
    y1: int
    y2: int
    x1: int
    x2: int

    def as_tuple(self) -> Tuple[int, int, int, int]:
        return (self.y1, self.y2, self.x1, self.x2)


# Generic default ROIs — coordinate overlays/HUDs in most mapping or
# location-sharing apps cluster near the top or bottom bar, or inside
# an opened detail/info card. Operators calibrate per-app via
# /api/govint/api/vision/calibrate (see blueprint extension).
DEFAULT_ROIS = [
    VisionROI("info_card",  620,  680,  80,  720),
    VisionROI("bottom_bar", 1780, 1870, 200, 880),
    VisionROI("top_bar",    0,    120,  0,   1080),
]

_COORD_PATTERNS = [
    r"(-?\d{1,3}\.\d{3,8})\s*[,\s]+\s*(-?\d{1,3}\.\d{3,8})",
    r"[Ll]at[:\s]+(-?\d{1,3}\.\d{3,8})\s+[Ll]on[:\s]+(-?\d{1,3}\.\d{3,8})",
    r"\((-?\d{1,3}\.\d{3,8}),\s*(-?\d{1,3}\.\d{3,8})\)",
]


def _parse_lat_lon(text: str) -> Tuple[Optional[float], Optional[float]]:
    for pat in _COORD_PATTERNS:
        m = re.search(pat, text)
        if m:
            try:
                lat = float(m.group(1))
                lon = float(m.group(2))
                if -90 <= lat <= 90 and -180 <= lon <= 180:
                    return lat, lon
            except ValueError:
                continue
    return None, None


def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Real geographic distance in kilometres. Shared with zeus_geo_cluster.py."""
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2
         + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2))
         * math.sin(dlon / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


# ── ADB transport (thin, dependency-free) ────────────────────────────────────

class ADBTransport:
    """
    Minimal ADB wrapper for screen capture and logcat access against a
    GovInt-authorized target device. Deliberately separate from any
    ATLAS-specific ADB module — this one is generic and carries no
    game-automation logic (no tap/swipe/click — read-only by design).
    """

    def __init__(self, device_serial: str):
        self.device_serial = device_serial

    def _adb(self, args: List[str], timeout: int = 10) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["adb", "-s", self.device_serial] + args,
            capture_output=True, timeout=timeout,
        )

    def is_connected(self) -> bool:
        try:
            r = subprocess.run(["adb", "devices"], capture_output=True, text=True, timeout=5)
            return self.device_serial in r.stdout and "device" in r.stdout
        except Exception:
            return False

    def screencap(self):
        """Returns a BGR numpy array (cv2 image) or None."""
        if not CV2_OK:
            return None
        try:
            r = self._adb(["exec-out", "screencap", "-p"], timeout=15)
            if r.returncode != 0 or not r.stdout:
                return None
            arr = np.frombuffer(r.stdout, dtype=np.uint8)
            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            return img
        except Exception as e:
            log.debug("screencap failed for %s: %s", self.device_serial, e)
            return None

    def logcat_snapshot(self, tag_filters: Optional[List[str]] = None, timeout: float = 3.0) -> List[str]:
        """Returns recent logcat lines (already in buffer), filtered by tag if given."""
        try:
            self._adb(["logcat", "-c"], timeout=3)  # clear so we get a fresh window
            filters = (tag_filters or []) + ["*:S"]
            proc = subprocess.Popen(
                ["adb", "-s", self.device_serial, "logcat", "-d", "-v", "brief"] + filters,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            )
            start = time.time()
            lines: List[str] = []
            while time.time() - start < timeout:
                line = proc.stdout.readline()
                if not line:
                    break
                lines.append(line.decode("utf-8", errors="ignore"))
            proc.terminate()
            return lines
        except Exception:
            return []


# ── Visual geolocator ─────────────────────────────────────────────────────────

class VisualGeoExtractor:
    """
    Extracts real-world coordinates from an ADB-reachable device's
    current on-screen state. Three methods tried in order, generalised
    from ATLAS.AI's get_real_coordinates() cascade:

      1. OCR — screencap + OpenCV preprocessing + Tesseract over
         configured ROIs (or per-app calibrated ROIs).
      2. Logcat scrape — filters the device's log buffer for any
         line matching a lat/lon pattern (works for apps that log
         location broadcasts, e.g. mapping/tracking apps).
      3. Tap-position interpolation — if the device viewport has been
         calibrated (two known lat/lon reference points mapped to two
         pixel positions), estimate coordinates from a given tap/anchor
         pixel via linear interpolation.

    Every extraction attempt is intended to be wrapped by the caller
    (zeus_geo_intel.py / the GovInt blueprint) in a sovereign_execute()
    call so it is ring-classified, audited, and Council-escalated like
    every other Zeus action — this class itself does no authorization
    or ring logic, it only performs the read.
    """

    def __init__(self, device_serial: str, rois: Optional[List[VisionROI]] = None,
                 calibration: Optional[Dict[str, float]] = None):
        self.transport = ADBTransport(device_serial)
        self.rois = rois or DEFAULT_ROIS
        # calibration: {lat_tl, lon_tl, lat_br, lon_br, px_x1, px_y1, px_x2, px_y2}
        self.calibration = calibration or {}

    # -- Method 1: OCR --------------------------------------------------------
    def extract_via_ocr(self, img=None) -> Tuple[Optional[float], Optional[float], str]:
        if not (CV2_OK and TESS_OK):
            return None, None, "OCR_UNAVAILABLE_MISSING_DEPENDENCIES"

        if img is None:
            img = self.transport.screencap()
        if img is None:
            return None, None, "SCREENCAP_FAILED"

        h, w = img.shape[:2]
        for roi in self.rois:
            y1, y2, x1, x2 = roi.as_tuple()
            y1, y2 = max(0, y1), min(h, y2)
            x1, x2 = max(0, x1), min(w, x2)
            if y2 <= y1 or x2 <= x1:
                continue
            region = img[y1:y2, x1:x2]
            region = cv2.resize(region, None, fx=2.5, fy=2.5, interpolation=cv2.INTER_CUBIC)
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
            gray = cv2.bilateralFilter(gray, 9, 75, 75)
            _, thr = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            text = pytesseract.image_to_string(
                thr, config="--psm 6 -c tessedit_char_whitelist=0123456789.,-°'NSEWLatLon: "
            )
            lat, lon = _parse_lat_lon(text)
            if lat is not None:
                return lat, lon, f"OCR_ROI_{roi.name}"
        return None, None, "OCR_NO_MATCH"

    # -- Method 2: logcat -------------------------------------------------------
    def extract_via_logcat(self, tag_filters: Optional[List[str]] = None,
                            timeout: float = 2.0) -> Tuple[Optional[float], Optional[float], str]:
        lines = self.transport.logcat_snapshot(tag_filters, timeout)
        for line in lines:
            lat, lon = _parse_lat_lon(line)
            if lat is not None:
                return lat, lon, "LOGCAT_SCRAPE"
        return None, None, "LOGCAT_NO_MATCH"

    # -- Method 3: tap-position interpolation -----------------------------------
    def extract_via_interpolation(self, tap_x: float, tap_y: float) -> Tuple[Optional[float], Optional[float], str]:
        c = self.calibration
        required = ("lat_tl", "lon_tl", "lat_br", "lon_br")
        if not all(k in c for k in required):
            return None, None, "NOT_CALIBRATED"
        px_x1 = c.get("px_x1", 0)
        px_y1 = c.get("px_y1", 0)
        px_x2 = c.get("px_x2", 1080)
        px_y2 = c.get("px_y2", 1920)
        x_frac = (tap_x - px_x1) / max(px_x2 - px_x1, 1)
        y_frac = (tap_y - px_y1) / max(px_y2 - px_y1, 1)
        lat = c["lat_tl"] + (c["lat_br"] - c["lat_tl"]) * y_frac
        lon = c["lon_tl"] + (c["lon_br"] - c["lon_tl"]) * x_frac
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            return round(lat, 6), round(lon, 6), "VIEWPORT_INTERPOLATION"
        return None, None, "INTERPOLATION_OUT_OF_RANGE"

    # -- Master cascade -----------------------------------------------------------
    def extract(self, tap_x: Optional[float] = None, tap_y: Optional[float] = None,
                tag_filters: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Runs the full extraction cascade and returns a structured result
        ready to be embedded into a GovInt locate() response or logged
        as a geolocation_query entry.
        """
        if not self.transport.is_connected():
            return {
                "lat": None, "lon": None, "method": "DEVICE_NOT_CONNECTED",
                "device": self.transport.device_serial, "confidence": 0.0,
            }

        lat, lon, method = self.extract_via_ocr()
        if lat is not None:
            return {"lat": lat, "lon": lon, "method": method,
                    "device": self.transport.device_serial, "confidence": 0.9}

        lat, lon, method = self.extract_via_logcat(tag_filters)
        if lat is not None:
            return {"lat": lat, "lon": lon, "method": method,
                    "device": self.transport.device_serial, "confidence": 0.75}

        if tap_x is not None and tap_y is not None:
            lat, lon, method = self.extract_via_interpolation(tap_x, tap_y)
            if lat is not None:
                return {"lat": lat, "lon": lon, "method": method,
                        "device": self.transport.device_serial, "confidence": 0.5}

        return {"lat": None, "lon": None, "method": "ALL_METHODS_FAILED",
                "device": self.transport.device_serial, "confidence": 0.0}


# ── Integration note (read, do not auto-run) ──────────────────────────────────
# This module is consumed by:
#   - zeus_geo_intel.py   -> ZeusGeoIntel.locate_device() (new method, additive)
#   - zeus_govint_blueprint.py -> POST /govint/api/vision/extract,
#                                  POST /govint/api/vision/calibrate
# Both call zeus_sovereignty_engine.sovereign_execute() with action_type
# values from GEO_VISION_RING_TYPES above so every visual extraction is
# ring-classified, logged, and — for geo_visual_target_lock — routed
# through the AI Council exactly like every other Ring 6 action.
