#!/bin/bash
# The Zeus Project 2026 — stop_all.sh
echo "[*] Stopping Zeus Hive Mind..."
pkill -f "gunicorn_zeus.py"   2>/dev/null && echo "[✓] Zeus stopped"   || echo "[-] Zeus not running"
pkill -f "gunicorn_config.py" 2>/dev/null && echo "[✓] UMP stopped"    || echo "[-] UMP not running"
pkill -f "wsgi_zeus:app"      2>/dev/null || true
pkill -f "wsgi:app"           2>/dev/null || true
[ -f /tmp/zeus_arch.pid ] && kill $(cat /tmp/zeus_arch.pid) 2>/dev/null || true
[ -f /tmp/ump.pid ]       && kill $(cat /tmp/ump.pid)       2>/dev/null || true
rm -f /tmp/zeus_arch.pid /tmp/ump.pid
echo "[✓] Hive Mind stopped."
