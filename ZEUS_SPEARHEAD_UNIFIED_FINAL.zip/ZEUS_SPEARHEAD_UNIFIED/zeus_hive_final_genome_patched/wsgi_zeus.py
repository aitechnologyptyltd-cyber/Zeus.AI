"""
wsgi_zeus.py
The Zeus Project 2026 — Francois Nel

WSGI entry point for Zeus Architecture + Zeus Firewall + Aegis Engine + Hive Mind Bridge.
Runs on port 8080 via Gunicorn.

Boot order:
    1. Zeus Architecture (27 blueprints, all layers)
    2. Zeus Firewall v1  (22-layer middleware)
    3. Aegis Engine      (autonomous evolution + dashboard)
    4. Hive Mind Bridge  (3-way bidirectional collective intelligence)

Usage:
    gunicorn --config gunicorn_zeus.py wsgi_zeus:app
"""

import sys
import os
import threading

MERGED_DIR  = os.path.dirname(os.path.abspath(__file__))
ZEUS_ARCH   = os.path.join(MERGED_DIR, "zeus_arch")
ZEUS_FW_DIR = os.path.join(MERGED_DIR, "zeus_firewall")

sys.path.insert(0, ZEUS_ARCH)
sys.path.insert(0, ZEUS_FW_DIR)
sys.path.insert(0, MERGED_DIR)

# ── 1. Zeus Architecture Flask app ────────────────────────────────────────────
from app import app, log, _boot_improvement_loop

# ── 2. Zeus Firewall + Aegis as middleware ────────────────────────────────────
_orch = None
try:
    from zeus_firewall_v1 import ZeusFirewall
    from zeus_aegis_engine import attach_to_zeus_firewall, create_aegis_blueprint

    fw   = ZeusFirewall()
    _orch = attach_to_zeus_firewall(fw)
    _orch.start_autonomous(interval_seconds=60)

    before_req, after_req = fw.flask_middleware()
    app.before_request(before_req)
    app.after_request(after_req)

    try:
        aegis_bp = create_aegis_blueprint(_orch)
        app.register_blueprint(aegis_bp)
        log.info("[boot] ✓ Aegis-22 dashboard registered at /aegis")
    except Exception as e:
        log.warning("[boot] Aegis blueprint: %s", e)

    log.info("[boot] ✓ Zeus Firewall v1 (22 layers) active")
    log.info("[boot] ✓ Aegis self-hardening engine active")

except Exception as e:
    log.warning("[boot] Firewall/Aegis init failed (non-fatal): %s", e)

# ── 3. Hive Mind Bridge (replaces zeus_ump_bridge) ────────────────────────────
try:
    from zeus_hive_bridge import register_zeus_bridge, aegis_on_threat_detected
    register_zeus_bridge(app)

    # Wire Aegis's threat callbacks into the hive — makes Aegis hive-aware.
    # Monkey-patch AegisOrchestrator.inspect_and_respond to emit hive events.
    if _orch is not None:
        _original_inspect = _orch.inspect_and_respond

        def _hive_aware_inspect(payload, category="UNKNOWN"):
            result = _original_inspect(payload, category)
            try:
                import hashlib
                ph = hashlib.sha256(payload[:512]).hexdigest()[:16] if payload else ""
                aegis_on_threat_detected(
                    threat_id    = result.get("item_id", ""),
                    category     = category,
                    source_ip    = "",      # IP added by firewall middleware layer
                    severity     = 7,       # Aegis confirmed threats are always high severity
                    layer        = 0,
                    action       = "ISOLATED",
                    payload_hash = ph,
                )
            except Exception:
                pass
            return result

        _orch.inspect_and_respond = _hive_aware_inspect

        # Wire defense rating updates into hive
        _original_auto = _orch._autonomous_loop

        def _hive_aware_auto(interval):
            from zeus_hive_bridge import aegis_on_defense_rating_update
            import time
            while _orch._running:
                try:
                    _orch.synthesis.run()
                    result = _orch.evolution.evolve()
                    dr = _orch.db.defense_rating()
                    layers = {str(row.get("layer_id", 0)): row.get("triggers", 0)
                              for row in _orch.db.get_layer_stats()}
                    aegis_on_defense_rating_update(dr, layers)
                except Exception as exc:
                    log.warning("[aegis_auto] loop error: %s", exc)
                time.sleep(interval)

        import types
        _orch._autonomous_loop = types.MethodType(
            lambda self, interval: _hive_aware_auto(interval), _orch
        )

    log.info("[boot] ✓ Hive Mind Bridge registered — /api/hive/*")
    log.info("[boot] ✓ Aegis → Hive threat callbacks wired")

except Exception as e:
    log.warning("[boot] Hive Mind Bridge init failed (non-fatal): %s", e)

# ── 4. Zeus improvement loop ──────────────────────────────────────────────────
_boot_improvement_loop()

log.info("[wsgi_zeus] Zeus + Firewall + Aegis + Hive WSGI ready on port 8080")

__all__ = ["app"]
