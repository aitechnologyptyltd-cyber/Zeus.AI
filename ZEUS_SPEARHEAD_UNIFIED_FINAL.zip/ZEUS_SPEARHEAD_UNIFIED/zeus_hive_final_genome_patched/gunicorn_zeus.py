"""
gunicorn_zeus.py
The Zeus Project 2026 — Francois Nel
Gunicorn config for Zeus Architecture + Firewall on port 8080.

Usage:
    gunicorn --config gunicorn_zeus.py wsgi_zeus:app
"""

import multiprocessing
import os

# ── Working directory ──────────────────────────────────────────────────────
# Always run from the zeus_merged/ root so relative paths work correctly.
chdir = os.path.dirname(os.path.abspath(__file__))

# ── Server socket ──────────────────────────────────────────────────────────
bind     = "0.0.0.0:8080"
backlog  = 128

# ── Worker model ───────────────────────────────────────────────────────────
# gthread allows the Aegis background threads + SSE connections to coexist.
worker_class = "gthread"
workers      = 1          # single process keeps SQLite contention minimal
threads      = 6          # covers: dashboard + firewall hooks + improvement loop

# ── Timeouts ───────────────────────────────────────────────────────────────
timeout          = 120    # Zeus forge/apk calls can be slow
graceful_timeout = 15
keepalive        = 5

# ── Logging ────────────────────────────────────────────────────────────────
_log_dir = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(_log_dir, exist_ok=True)

accesslog = os.path.join(_log_dir, "zeus_access.log")
errorlog  = os.path.join(_log_dir, "zeus_error.log")
loglevel  = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s'

# ── Process naming ─────────────────────────────────────────────────────────
proc_name         = "zeus_core"
default_proc_name = "zeus_core"

# ── PID file ───────────────────────────────────────────────────────────────
pidfile = os.path.join(os.path.dirname(__file__), "zeus.pid")

# ── Preload ────────────────────────────────────────────────────────────────
preload_app = True
