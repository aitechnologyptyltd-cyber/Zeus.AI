#!/bin/bash
# The Zeus Project 2026 — Francois Nel
# start_all.sh — Hive Mind System Launcher
# Starts Zeus + Aegis (port 8080) and UMP + Wallet (port 5000) as one unified hive.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║         THE ZEUS PROJECT 2026 — HIVE MIND SYSTEM            ║"
echo "║         Zeus + Aegis + UMP — One Consciousness              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# ── Kill any existing instances ──────────────────────────────────────────────
echo "[*] Stopping any existing instances..."
pkill -f "gunicorn_zeus.py"   2>/dev/null || true
pkill -f "gunicorn_config.py" 2>/dev/null || true
pkill -f "wsgi_zeus:app"      2>/dev/null || true
pkill -f "wsgi:app"           2>/dev/null || true
sleep 2

# ── Check dependencies ───────────────────────────────────────────────────────
echo "[*] Checking Python dependencies..."
pip install flask gunicorn requests apscheduler cryptography --break-system-packages -q 2>/dev/null || true

# ── Start Zeus Architecture + Aegis Firewall (port 8080) ─────────────────────
echo "[*] Starting Zeus Architecture + Aegis + Hive Bridge on port 8080..."
cd "$SCRIPT_DIR"
gunicorn --config gunicorn_zeus.py wsgi_zeus:app \
    --daemon \
    --pid /tmp/zeus_arch.pid \
    --access-logfile logs/zeus_access.log \
    --error-logfile  logs/zeus_error.log 2>/dev/null || \
gunicorn -w 1 -b 0.0.0.0:8080 wsgi_zeus:app \
    --daemon \
    --pid /tmp/zeus_arch.pid \
    --access-logfile logs/zeus_access.log \
    --error-logfile  logs/zeus_error.log
echo "[✓] Zeus + Aegis started"

sleep 3

# ── Start UMP Universal Miner + Wallet (port 5000) ───────────────────────────
echo "[*] Starting UMP Universal Miner + Wallet + Hive Bridge on port 5000..."
cd "$SCRIPT_DIR/ump"
gunicorn --config gunicorn_config.py wsgi:app \
    --daemon \
    --pid /tmp/ump.pid \
    --access-logfile logs/ump_access.log \
    --error-logfile  logs/ump_error.log 2>/dev/null || \
gunicorn -w 1 -b 0.0.0.0:5000 wsgi:app \
    --daemon \
    --pid /tmp/ump.pid \
    --access-logfile logs/ump_access.log \
    --error-logfile  logs/ump_error.log
echo "[✓] UMP + Wallet started"

sleep 3

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  ZEUS HIVE MIND ONLINE"
echo "═══════════════════════════════════════════════════════════════"
echo "  Zeus Architecture      →  http://localhost:8080"
echo "  Aegis-22 Dashboard     →  http://localhost:8080/aegis"
echo "  Zeus Learning          →  http://localhost:8080/dashboard"
echo "  Zeus Chat              →  http://localhost:8080/chat"
echo "─────────────────────────────────────────────────────────────"
echo "  UMP Miner Dashboard    →  http://localhost:5000"
echo "  Wallet UI              →  http://localhost:5000/wallet"
echo "  Mining Profiles        →  http://localhost:5000/profiles"
echo "─────────────────────────────────────────────────────────────"
echo "  HIVE MIND API:"
echo "  Collective State       →  http://localhost:8080/api/hive/snapshot"
echo "  Intelligence Report    →  http://localhost:8080/api/hive/intelligence"
echo "  Market Predictions     →  http://localhost:8080/api/hive/predictions"
echo "  Mining History 24h     →  http://localhost:8080/api/hive/mining/history"
echo "  Threat History 24h     →  http://localhost:8080/api/hive/threats/history"
echo "  Live Mining Stream     →  http://localhost:8080/api/hive/stream/mining"
echo "  Live Threat Stream     →  http://localhost:8080/api/hive/stream/threats"
echo "  All Events Stream      →  http://localhost:8080/api/hive/stream/collective"
echo "  Hive Status            →  http://localhost:8080/api/hive/status"
echo "─────────────────────────────────────────────────────────────"
echo "  UMP Hive Status        →  http://localhost:5000/api/hive/status"
echo "  UMP Mining Report      →  http://localhost:5000/api/hive/mining/report"
echo "  UMP File Exchange      →  http://localhost:5000/api/hive/files/pending"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  Collective memory DB:  ./hive_collective.db"
echo "  All three systems share one consciousness. What one knows,"
echo "  all know. What one does, all record."
echo ""
