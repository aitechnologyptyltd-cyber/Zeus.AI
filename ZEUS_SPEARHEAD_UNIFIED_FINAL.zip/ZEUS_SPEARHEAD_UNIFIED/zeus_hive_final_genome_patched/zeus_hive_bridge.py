"""
zeus_hive_bridge.py
The Zeus Project 2026 — Francois Nel

HIVE MIND BRIDGE — True closed-loop bidirectional intelligence network.

All three systems share one consciousness:
  Zeus Architecture (port 8080) ←→ UMP Universal Miner (port 5000)
  Zeus Architecture (port 8080) ←→ Aegis Firewall (same process, port 8080)
  Aegis Firewall               ←→ UMP Universal Miner (port 5000)

Every event flows to all three. Every system can:
  - Push and pull files to/from any other system
  - Stream live data (hashrates, threats, predictions, wallet events)
  - Trigger repairs and gap-fills in any other system
  - Contribute learning to the shared collective memory

Registered in:
  wsgi_zeus.py  → register_zeus_bridge(app)
  ump/wsgi.py   → register_ump_bridge(app)

Zero stubs. Zero placeholders. Fully wired.
"""

from __future__ import print_function

import os
import sys
import json
import time
import uuid
import math
import logging
import hashlib
import sqlite3
import threading
import traceback
from collections import deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import requests
from flask import Blueprint, jsonify, request, Response

log = logging.getLogger("zeus.hive_bridge")

# ─────────────────────────────────────────────────────────────────────────────
# NETWORK TOPOLOGY
# ─────────────────────────────────────────────────────────────────────────────

ZEUS_BASE = "http://127.0.0.1:8080"
UMP_BASE  = "http://127.0.0.1:5000"
TIMEOUT   = 8    # seconds for cross-service HTTP calls
FILE_TIMEOUT = 30  # seconds for file transfer calls

# ─────────────────────────────────────────────────────────────────────────────
# SHARED COLLECTIVE MEMORY
# In-process shared state — all three systems read and write here via the bridge.
# This is the hive's nervous system.
# ─────────────────────────────────────────────────────────────────────────────

class HiveMemory:
    """
    Thread-safe collective memory shared across all three systems.
    Persisted to SQLite so restarts don't lose the hive's knowledge.
    """

    _instance = None
    _lock = threading.Lock()

    @classmethod
    def get(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._mem_lock = threading.RLock()

        # Determine storage path — works from either zeus_arch or ump directory
        base = os.path.dirname(os.path.abspath(__file__))
        self.db_path = os.path.join(base, "hive_collective.db")
        self._init_db()

        # Live in-memory channels (ring buffers, max 2000 entries each)
        self.mining_stream    = deque(maxlen=2000)   # UMP→all: hashrates, payouts, coin switches
        self.threat_stream    = deque(maxlen=2000)   # Aegis→all: threat events, blocked IPs
        self.prediction_stream = deque(maxlen=500)   # Zeus→all: market predictions
        self.wallet_stream    = deque(maxlen=1000)   # UMP→all: wallet/tx events
        self.repair_log       = deque(maxlen=500)    # Zeus→all: gap fills and patches
        self.collective_log   = deque(maxlen=5000)   # all→all: every significant event

        # Aggregated live state (any system can read this as the hive's current reality)
        self.live_state = {
            "mining": {
                "hashrate_total": 0.0,
                "active_coin":    "unknown",
                "active_algo":    "unknown",
                "active_nodes":   0,
                "accepted_total": 0,
                "rejected_total": 0,
                "daily_usd":      0.0,
                "pool_url":       "",
                "last_updated":   0,
            },
            "wallet": {
                "total_usd":      0.0,
                "total_mined_usd": 0.0,
                "coins":          {},
                "last_tx":        "",
                "last_updated":   0,
            },
            "aegis": {
                "threats_today":  0,
                "blocked_ips":    [],
                "top_threat_cat": "",
                "defense_rating": 100.0,
                "layer_health":   {},
                "last_updated":   0,
            },
            "zeus": {
                "cycles_complete": 0,
                "knowledge_count": 0,
                "genome_count":    0,
                "last_prediction": {},
                "repair_queue":    [],
                "last_updated":    0,
            },
            "hive": {
                "intelligence_score": 0.0,
                "events_total":       0,
                "start_time":         time.time(),
                "last_sync":          0,
            }
        }
        self._state_lock = threading.RLock()

        # Collective knowledge index: topic → {count, confidence, sources}
        self.knowledge_index = defaultdict(lambda: {"count": 0, "confidence": 0.0, "sources": []})

        log.info("[hive_memory] Collective memory online — db=%s", self.db_path)

    # ── DB INIT ───────────────────────────────────────────────────────────────

    def _init_db(self):
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()

        cur.executescript("""
            CREATE TABLE IF NOT EXISTS hive_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id    TEXT    NOT NULL,
                source      TEXT    NOT NULL,
                event_type  TEXT    NOT NULL,
                payload     TEXT    NOT NULL,
                ts          REAL    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS collective_knowledge (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                topic       TEXT    NOT NULL,
                content     TEXT    NOT NULL,
                source      TEXT    NOT NULL,
                confidence  REAL    DEFAULT 0.5,
                tags        TEXT    DEFAULT '[]',
                ts          REAL    NOT NULL,
                UNIQUE(topic, source)
            );

            CREATE TABLE IF NOT EXISTS mining_intelligence (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                coin         TEXT    NOT NULL,
                algo         TEXT    NOT NULL,
                hashrate     REAL    NOT NULL,
                price_usd    REAL    DEFAULT 0.0,
                daily_usd    REAL    DEFAULT 0.0,
                pool_url     TEXT    DEFAULT '',
                node_count   INTEGER DEFAULT 0,
                ts           REAL    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS threat_intelligence (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                threat_id    TEXT    NOT NULL,
                category     TEXT    NOT NULL,
                source_ip    TEXT    DEFAULT '',
                payload_hash TEXT    DEFAULT '',
                severity     INTEGER DEFAULT 5,
                layer        INTEGER DEFAULT 0,
                action_taken TEXT    DEFAULT '',
                pushed_to    TEXT    DEFAULT '[]',
                ts           REAL    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS market_predictions (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                coin         TEXT    NOT NULL,
                predicted_usd REAL   NOT NULL,
                confidence   REAL    NOT NULL,
                horizon_h    INTEGER DEFAULT 24,
                basis        TEXT    DEFAULT '',
                generated_at REAL    NOT NULL,
                outcome_usd  REAL    DEFAULT 0.0,
                outcome_at   REAL    DEFAULT 0.0
            );

            CREATE TABLE IF NOT EXISTS hive_files (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id      TEXT    NOT NULL UNIQUE,
                filename     TEXT    NOT NULL,
                source       TEXT    NOT NULL,
                destination  TEXT    NOT NULL,
                content      TEXT    NOT NULL,
                file_size    INTEGER DEFAULT 0,
                file_type    TEXT    DEFAULT 'text',
                status       TEXT    DEFAULT 'pending',
                ts           REAL    NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_hive_events_type ON hive_events(event_type);
            CREATE INDEX IF NOT EXISTS idx_hive_events_ts   ON hive_events(ts);
            CREATE INDEX IF NOT EXISTS idx_mining_intel_ts  ON mining_intelligence(ts);
            CREATE INDEX IF NOT EXISTS idx_threat_intel_ts  ON threat_intelligence(ts);
            CREATE INDEX IF NOT EXISTS idx_predictions_coin ON market_predictions(coin);
        """)
        con.commit()
        con.close()

    # ── EVENT PUBLISHING ──────────────────────────────────────────────────────

    def publish(self, source: str, event_type: str, payload: dict) -> str:
        """
        Publish an event from any system to the collective memory.
        Returns the event_id.
        """
        event_id = str(uuid.uuid4())[:12]
        ts = time.time()
        entry = {
            "event_id":   event_id,
            "source":     source,
            "event_type": event_type,
            "payload":    payload,
            "ts":         ts,
            "dt":         datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(),
        }

        with self._mem_lock:
            self.collective_log.append(entry)
            with self._state_lock:
                self.live_state["hive"]["events_total"] += 1
                self.live_state["hive"]["last_sync"] = ts

        # Route to appropriate stream
        if event_type in ("hashrate_update", "coin_switch", "payout", "miner_start", "miner_stop"):
            with self._mem_lock:
                self.mining_stream.append(entry)
        elif event_type in ("threat_detected", "ip_blocked", "layer_triggered", "av_signature"):
            with self._mem_lock:
                self.threat_stream.append(entry)
        elif event_type in ("market_prediction", "trend_signal", "gap_analysis"):
            with self._mem_lock:
                self.prediction_stream.append(entry)
        elif event_type in ("wallet_tx", "mining_credit", "balance_update", "binance_withdraw"):
            with self._mem_lock:
                self.wallet_stream.append(entry)
        elif event_type in ("gap_filled", "module_patched", "evolution_cycle"):
            with self._mem_lock:
                self.repair_log.append(entry)

        # Persist to DB asynchronously
        threading.Thread(target=self._persist_event,
                         args=(event_id, source, event_type, payload, ts),
                         daemon=True).start()

        return event_id

    def _persist_event(self, event_id, source, event_type, payload, ts):
        try:
            con = sqlite3.connect(self.db_path)
            con.execute(
                "INSERT INTO hive_events(event_id,source,event_type,payload,ts) VALUES(?,?,?,?,?)",
                (event_id, source, event_type, json.dumps(payload), ts)
            )
            con.commit()
            con.close()
        except Exception as exc:
            log.debug("[hive_memory] persist_event error: %s", exc)

    # ── LIVE STATE UPDATES ────────────────────────────────────────────────────

    def update_mining_state(self, data: dict):
        with self._state_lock:
            m = self.live_state["mining"]
            m["hashrate_total"] = data.get("hashrate_total", m["hashrate_total"])
            m["active_coin"]    = data.get("active_coin",    m["active_coin"])
            m["active_algo"]    = data.get("active_algo",    m["active_algo"])
            m["active_nodes"]   = data.get("active_nodes",   m["active_nodes"])
            m["accepted_total"] = data.get("accepted_total", m["accepted_total"])
            m["rejected_total"] = data.get("rejected_total", m["rejected_total"])
            m["daily_usd"]      = data.get("daily_usd",      m["daily_usd"])
            m["pool_url"]       = data.get("pool_url",        m["pool_url"])
            m["last_updated"]   = time.time()

        # Persist mining intelligence snapshot
        threading.Thread(target=self._persist_mining, args=(data,), daemon=True).start()

    def _persist_mining(self, data: dict):
        try:
            con = sqlite3.connect(self.db_path)
            con.execute(
                """INSERT INTO mining_intelligence
                   (coin,algo,hashrate,price_usd,daily_usd,pool_url,node_count,ts)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (
                    data.get("active_coin", ""),
                    data.get("active_algo", ""),
                    data.get("hashrate_total", 0.0),
                    data.get("price_usd", 0.0),
                    data.get("daily_usd", 0.0),
                    data.get("pool_url", ""),
                    data.get("active_nodes", 0),
                    time.time(),
                )
            )
            con.commit()
            con.close()
        except Exception as exc:
            log.debug("[hive_memory] persist_mining error: %s", exc)

    def update_wallet_state(self, data: dict):
        with self._state_lock:
            w = self.live_state["wallet"]
            w["total_usd"]       = data.get("total_usd",       w["total_usd"])
            w["total_mined_usd"] = data.get("total_mined_usd", w["total_mined_usd"])
            w["coins"]           = data.get("coins",           w["coins"])
            w["last_tx"]         = data.get("last_tx",         w["last_tx"])
            w["last_updated"]    = time.time()

    def update_aegis_state(self, data: dict):
        with self._state_lock:
            a = self.live_state["aegis"]
            a["threats_today"]  = data.get("threats_today",  a["threats_today"])
            a["blocked_ips"]    = data.get("blocked_ips",    a["blocked_ips"])[-50:]
            a["top_threat_cat"] = data.get("top_threat_cat", a["top_threat_cat"])
            a["defense_rating"] = data.get("defense_rating", a["defense_rating"])
            a["layer_health"]   = data.get("layer_health",   a["layer_health"])
            a["last_updated"]   = time.time()

    def update_zeus_state(self, data: dict):
        with self._state_lock:
            z = self.live_state["zeus"]
            z["cycles_complete"]  = data.get("cycles_complete",  z["cycles_complete"])
            z["knowledge_count"]  = data.get("knowledge_count",  z["knowledge_count"])
            z["genome_count"]     = data.get("genome_count",      z["genome_count"])
            z["last_prediction"]  = data.get("last_prediction",   z["last_prediction"])
            z["repair_queue"]     = data.get("repair_queue",      z["repair_queue"])
            z["last_updated"]     = time.time()
        self._recompute_intelligence_score()

    def _recompute_intelligence_score(self):
        """Emergent intelligence score — grows as the hive learns more."""
        with self._state_lock:
            z = self.live_state["zeus"]
            m = self.live_state["mining"]
            a = self.live_state["aegis"]
            w = self.live_state["wallet"]

            kc = min(z["knowledge_count"] / 10000.0, 1.0) * 30.0
            gc = min(z["genome_count"]    / 1000.0,  1.0) * 20.0
            hr = min(m["hashrate_total"]  / 10000.0, 1.0) * 15.0
            dr = (a["defense_rating"] / 100.0)          * 20.0
            wu = min(w["total_mined_usd"] / 1000.0, 1.0) * 15.0
            score = round(kc + gc + hr + dr + wu, 2)
            self.live_state["hive"]["intelligence_score"] = score

    def store_prediction(self, coin: str, predicted_usd: float, confidence: float,
                         horizon_h: int, basis: str):
        try:
            con = sqlite3.connect(self.db_path)
            con.execute(
                """INSERT INTO market_predictions
                   (coin,predicted_usd,confidence,horizon_h,basis,generated_at)
                   VALUES(?,?,?,?,?,?)""",
                (coin, predicted_usd, confidence, horizon_h, basis, time.time())
            )
            con.commit()
            con.close()
        except Exception as exc:
            log.debug("[hive_memory] store_prediction error: %s", exc)

    def store_threat(self, threat_id: str, category: str, source_ip: str,
                     payload_hash: str, severity: int, layer: int, action: str):
        try:
            con = sqlite3.connect(self.db_path)
            con.execute(
                """INSERT INTO threat_intelligence
                   (threat_id,category,source_ip,payload_hash,severity,layer,action_taken,ts)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (threat_id, category, source_ip, payload_hash,
                 severity, layer, action, time.time())
            )
            con.commit()
            con.close()
        except Exception as exc:
            log.debug("[hive_memory] store_threat error: %s", exc)

    # ── FILE EXCHANGE ─────────────────────────────────────────────────────────

    def store_file(self, filename: str, source: str, destination: str, content: str,
                   file_type: str = "python") -> str:
        file_id = str(uuid.uuid4())[:16]
        try:
            con = sqlite3.connect(self.db_path)
            con.execute(
                """INSERT INTO hive_files
                   (file_id,filename,source,destination,content,file_size,file_type,status,ts)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (file_id, filename, source, destination, content,
                 len(content), file_type, "ready", time.time())
            )
            con.commit()
            con.close()
        except Exception as exc:
            log.warning("[hive_memory] store_file error: %s", exc)
        return file_id

    def fetch_file(self, file_id: str) -> Optional[dict]:
        try:
            con = sqlite3.connect(self.db_path)
            con.row_factory = sqlite3.Row
            row = con.execute(
                "SELECT * FROM hive_files WHERE file_id=?", (file_id,)
            ).fetchone()
            con.close()
            if row:
                return dict(row)
        except Exception as exc:
            log.debug("[hive_memory] fetch_file error: %s", exc)
        return None

    def list_pending_files(self, destination: str) -> List[dict]:
        try:
            con = sqlite3.connect(self.db_path)
            con.row_factory = sqlite3.Row
            rows = con.execute(
                "SELECT * FROM hive_files WHERE destination=? AND status='ready' ORDER BY ts DESC LIMIT 50",
                (destination,)
            ).fetchall()
            con.close()
            return [dict(r) for r in rows]
        except Exception as exc:
            log.debug("[hive_memory] list_pending_files error: %s", exc)
        return []

    def mark_file_delivered(self, file_id: str):
        try:
            con = sqlite3.connect(self.db_path)
            con.execute("UPDATE hive_files SET status='delivered' WHERE file_id=?", (file_id,))
            con.commit()
            con.close()
        except Exception:
            pass

    # ── QUERY HELPERS ─────────────────────────────────────────────────────────

    def get_mining_history(self, hours: int = 24) -> List[dict]:
        cutoff = time.time() - hours * 3600
        try:
            con = sqlite3.connect(self.db_path)
            con.row_factory = sqlite3.Row
            rows = con.execute(
                "SELECT * FROM mining_intelligence WHERE ts>? ORDER BY ts DESC LIMIT 500",
                (cutoff,)
            ).fetchall()
            con.close()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def get_threat_history(self, hours: int = 24) -> List[dict]:
        cutoff = time.time() - hours * 3600
        try:
            con = sqlite3.connect(self.db_path)
            con.row_factory = sqlite3.Row
            rows = con.execute(
                "SELECT * FROM threat_intelligence WHERE ts>? ORDER BY ts DESC LIMIT 500",
                (cutoff,)
            ).fetchall()
            con.close()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def get_predictions(self, coin: str = None, limit: int = 50) -> List[dict]:
        try:
            con = sqlite3.connect(self.db_path)
            con.row_factory = sqlite3.Row
            if coin:
                rows = con.execute(
                    "SELECT * FROM market_predictions WHERE coin=? ORDER BY generated_at DESC LIMIT ?",
                    (coin, limit)
                ).fetchall()
            else:
                rows = con.execute(
                    "SELECT * FROM market_predictions ORDER BY generated_at DESC LIMIT ?",
                    (limit,)
                ).fetchall()
            con.close()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def get_recent_events(self, event_type: str = None, limit: int = 100) -> List[dict]:
        try:
            con = sqlite3.connect(self.db_path)
            con.row_factory = sqlite3.Row
            if event_type:
                rows = con.execute(
                    "SELECT * FROM hive_events WHERE event_type=? ORDER BY ts DESC LIMIT ?",
                    (event_type, limit)
                ).fetchall()
            else:
                rows = con.execute(
                    "SELECT * FROM hive_events ORDER BY ts DESC LIMIT ?", (limit,)
                ).fetchall()
            con.close()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def snapshot(self) -> dict:
        with self._state_lock:
            import copy
            return {
                "live_state":          copy.deepcopy(self.live_state),
                "recent_mining":       list(self.mining_stream)[-20:],
                "recent_threats":      list(self.threat_stream)[-20:],
                "recent_predictions":  list(self.prediction_stream)[-10:],
                "recent_wallet":       list(self.wallet_stream)[-20:],
                "recent_repairs":      list(self.repair_log)[-10:],
                "recent_collective":   list(self.collective_log)[-50:],
            }


# Singleton
_hive = HiveMemory.get()


# ─────────────────────────────────────────────────────────────────────────────
# MARKET PREDICTION ENGINE
# Generates market predictions from mining data + wallet data + threat context.
# The more data the hive collects, the smarter the predictions become.
# ─────────────────────────────────────────────────────────────────────────────

class HivePredictionEngine:
    """
    Derives market/mining predictions from collective hive data.
    Called by Zeus, but fed by all three systems.
    """

    COIN_VOLATILITY = {
        "XMR": 0.05, "ZEPH": 0.15, "SAL": 0.20, "BTC": 0.04,
        "ZEC": 0.08, "ETC": 0.09, "RVN": 0.12, "LTC": 0.06,
        "DOGE": 0.18, "KAS": 0.20, "ALPH": 0.25, "ERG": 0.15,
    }

    def predict_coin_price(self, coin: str, current_price: float,
                           hashrate_trend: float, threat_pressure: float) -> dict:
        """
        Multi-factor price prediction using:
        - hashrate trend (positive = more miners = more sellers = price pressure)
        - threat pressure from Aegis (exchange attacks affect price)
        - mining profitability momentum
        - historical mining intelligence from the hive DB
        """
        vol = self.COIN_VOLATILITY.get(coin.upper(), 0.10)

        # Hashrate trend factor: rising hashrate often precedes price rally
        # because miners invest in hardware when they expect higher prices
        hr_factor = 0.0
        if hashrate_trend > 0.05:      # hashrate rising > 5%
            hr_factor = +0.02          # mild bullish signal
        elif hashrate_trend < -0.05:   # hashrate dropping > 5%
            hr_factor = -0.015         # mild bearish signal

        # Threat pressure: DDoS on exchanges, mining pool attacks
        # correlate with temporary price dips then recovery
        threat_factor = 0.0
        if threat_pressure > 50:       # high threat activity
            threat_factor = -0.01      # short-term bearish

        # Mining profit switcher momentum: if profit switcher is leaving this coin,
        # it means profitability fell, which often follows price
        history = _hive.get_mining_history(hours=6)
        recent_coin_count = sum(1 for r in history if r.get("coin", "").upper() == coin.upper())
        total_recent = max(len(history), 1)
        coin_share = recent_coin_count / total_recent
        momentum_factor = (coin_share - 0.3) * 0.03   # if coin dominates mining, bullish

        # Composite prediction
        total_delta = hr_factor + threat_factor + momentum_factor
        predicted_price = current_price * (1 + total_delta)
        confidence = max(0.3, min(0.85, 0.5 + abs(total_delta) * 5))

        basis = (
            "hashrate_trend={:.2f} threat_pressure={:.0f} "
            "coin_mining_share={:.2f} momentum={:.4f}".format(
                hashrate_trend, threat_pressure, coin_share, momentum_factor
            )
        )

        _hive.store_prediction(coin, predicted_price, confidence, 24, basis)

        return {
            "coin":          coin,
            "current_price": current_price,
            "predicted_usd": round(predicted_price, 6),
            "confidence":    round(confidence, 3),
            "horizon_h":     24,
            "factors": {
                "hashrate_trend":   hr_factor,
                "threat_pressure":  threat_factor,
                "momentum":         momentum_factor,
                "total_delta_pct":  round(total_delta * 100, 3),
            },
            "basis": basis,
        }

    def rank_coins_by_opportunity(self) -> List[dict]:
        """
        Rank all mined coins by predicted opportunity using collective hive data.
        Returns ordered list from highest to lowest predicted gain.
        """
        history = _hive.get_mining_history(hours=24)
        threats = _hive.get_threat_history(hours=24)
        threat_count = len(threats)

        seen_coins = set()
        coin_data = []
        for row in history:
            coin = row.get("coin", "")
            if not coin or coin in seen_coins:
                continue
            seen_coins.add(coin)

            # Compute hashrate trend for this coin
            coin_rows = [r for r in history if r.get("coin") == coin]
            if len(coin_rows) >= 2:
                oldest = coin_rows[-1].get("hashrate", 0)
                newest = coin_rows[0].get("hashrate", 0)
                trend = (newest - oldest) / max(oldest, 1.0)
            else:
                trend = 0.0

            price = row.get("price_usd", 0.0)
            daily = row.get("daily_usd", 0.0)

            pred = self.predict_coin_price(coin, price, trend, threat_count)
            pred["current_daily_usd"] = daily
            pred["predicted_daily_usd"] = round(
                daily * (1 + pred["factors"]["total_delta_pct"] / 100), 4
            )
            coin_data.append(pred)

        coin_data.sort(key=lambda x: x.get("predicted_daily_usd", 0), reverse=True)
        return coin_data

    def generate_hive_intelligence_report(self) -> dict:
        """
        Full intelligence report combining all three systems' data.
        This is what Zeus publishes to its prediction_bp.
        """
        with _hive._state_lock:
            snap = _hive.live_state.copy()

        ranked = self.rank_coins_by_opportunity()
        threats = _hive.get_threat_history(hours=24)
        predictions = _hive.get_predictions(limit=20)

        # Threat category frequency
        cat_freq = defaultdict(int)
        for t in threats:
            cat_freq[t.get("category", "UNKNOWN")] += 1
        top_threats = sorted(cat_freq.items(), key=lambda x: x[1], reverse=True)[:5]

        # Mining intelligence summary
        mining_history = _hive.get_mining_history(hours=24)
        coins_mined = list(set(r.get("coin", "") for r in mining_history if r.get("coin")))

        # Knowledge growth rate
        zeus_kc = snap.get("zeus", {}).get("knowledge_count", 0)
        intel_score = snap.get("hive", {}).get("intelligence_score", 0.0)

        return {
            "generated_at":       datetime.now(tz=timezone.utc).isoformat(),
            "hive_intelligence":  intel_score,
            "coin_opportunities": ranked[:10],
            "top_threats":        top_threats,
            "coins_mined_24h":    coins_mined,
            "predictions_stored": len(predictions),
            "knowledge_base_size": zeus_kc,
            "mining_snapshot":    snap.get("mining", {}),
            "wallet_snapshot":    snap.get("wallet", {}),
            "aegis_snapshot":     snap.get("aegis", {}),
            "recommendations": {
                "best_coin_now":    ranked[0]["coin"] if ranked else "XMR",
                "switch_signal":    ranked[0]["factors"]["total_delta_pct"] > 2.0 if ranked else False,
                "threat_level":     "HIGH" if len(threats) > 100 else "MEDIUM" if len(threats) > 20 else "LOW",
                "zeus_action":      "EVOLVE" if zeus_kc > 1000 else "LEARN",
            },
        }


_prediction_engine = HivePredictionEngine()


# ─────────────────────────────────────────────────────────────────────────────
# REPAIR DISPATCHER
# Zeus can directly repair UMP modules or Aegis rules from here.
# ─────────────────────────────────────────────────────────────────────────────

class HiveRepairDispatcher:
    """
    Dispatches repair jobs from Zeus to UMP or Aegis.
    Zeus's gap-detection finds missing functions, this fires the fix to the right system.
    """

    def dispatch_ump_repair(self, filename: str, patch_content: str,
                             gap_description: str) -> dict:
        """
        Send a code patch from Zeus to UMP.
        Zeus detected a gap in a UMP module and generated a fix.
        The patch is stored in the hive file exchange and UMP pulls it.
        """
        file_id = _hive.store_file(
            filename=filename,
            source="zeus",
            destination="ump",
            content=patch_content,
            file_type="python",
        )

        _hive.publish("zeus", "gap_filled", {
            "file_id":         file_id,
            "filename":        filename,
            "gap_description": gap_description,
            "destination":     "ump",
            "patch_size":      len(patch_content),
        })

        # Also try to push directly via HTTP
        result = {"file_id": file_id, "stored": True, "pushed": False}
        try:
            r = requests.post(
                UMP_BASE + "/api/hive/receive_patch",
                json={
                    "file_id":     file_id,
                    "filename":    filename,
                    "content":     patch_content,
                    "source":      "zeus",
                    "description": gap_description,
                },
                timeout=FILE_TIMEOUT,
            )
            result["pushed"] = r.status_code == 200
            result["ump_response"] = r.json() if r.status_code == 200 else {}
        except Exception as exc:
            result["push_error"] = str(exc)

        log.info("[hive_repair] Zeus→UMP patch dispatched: %s file_id=%s", filename, file_id)
        return result

    def dispatch_aegis_rule(self, rule_type: str, rule_data: dict,
                             reason: str) -> dict:
        """
        Send a new firewall rule from Zeus or UMP to Aegis.
        Example: UMP detects a malicious mining pool — send rule to Aegis to block it.
        """
        rule_content = json.dumps({"rule_type": rule_type, "rule_data": rule_data,
                                   "reason": reason, "ts": time.time()}, indent=2)
        file_id = _hive.store_file(
            filename="aegis_rule_{}.json".format(str(uuid.uuid4())[:8]),
            source="hive",
            destination="aegis",
            content=rule_content,
            file_type="json",
        )

        _hive.publish("hive", "aegis_rule_push", {
            "file_id":   file_id,
            "rule_type": rule_type,
            "reason":    reason,
        })

        result = {"file_id": file_id, "stored": True, "applied": False}
        try:
            r = requests.post(
                ZEUS_BASE + "/api/hive/aegis/receive_rule",
                json={"file_id": file_id, "rule_type": rule_type,
                      "rule_data": rule_data, "reason": reason},
                timeout=TIMEOUT,
            )
            result["applied"] = r.status_code == 200
        except Exception as exc:
            result["push_error"] = str(exc)

        log.info("[hive_repair] Aegis rule dispatched: %s reason=%s", rule_type, reason)
        return result

    def request_zeus_evolution(self, target_module: str, gap_desc: str,
                                data_context: dict) -> dict:
        """
        UMP or Aegis requests Zeus to evolve/fill a gap in a specific module.
        Zeus will analyze the gap using its evolution engine and dispatch a patch back.
        """
        _hive.publish("ump", "evolution_request", {
            "target_module": target_module,
            "gap_desc":      gap_desc,
            "data_context":  data_context,
        })

        result = {"queued": True, "triggered": False}
        try:
            r = requests.post(
                ZEUS_BASE + "/api/hive/zeus/evolution_request",
                json={
                    "target_module": target_module,
                    "gap_desc":      gap_desc,
                    "context":       data_context,
                },
                timeout=TIMEOUT,
            )
            result["triggered"] = r.status_code == 200
            if r.status_code == 200:
                result["job_id"] = r.json().get("job_id", "")
        except Exception as exc:
            result["trigger_error"] = str(exc)

        return result


_repair_dispatcher = HiveRepairDispatcher()


# ─────────────────────────────────────────────────────────────────────────────
# BACKGROUND SYNC LOOP
# Polls all three systems every 30 seconds, updates collective memory,
# generates predictions, and triggers cross-system actions.
# ─────────────────────────────────────────────────────────────────────────────

class HiveSyncLoop:
    """
    The heartbeat of the hive mind.
    Runs as a background daemon thread on both Zeus and UMP.
    Every 30 seconds it synchronises the collective state.
    """

    SYNC_INTERVAL = 30     # seconds between full sync cycles
    PREDICT_EVERY = 5      # sync cycles between prediction runs
    REPAIR_EVERY  = 10     # sync cycles between repair scans
    GENOME_EVERY  = 3      # sync cycles between genome broadcasts (Zeus side)

    def __init__(self):
        self._stop_evt = threading.Event()
        self._thread   = None
        self._cycle    = 0
        self._side     = "unknown"   # "zeus" or "ump"

    def start(self, side: str):
        self._side = side
        if self._thread and self._thread.is_alive():
            return
        self._stop_evt.clear()
        self._thread = threading.Thread(
            target=self._loop, name="HiveSyncLoop", daemon=True
        )
        self._thread.start()
        log.info("[hive_sync] Hive sync loop started — side=%s interval=%ds",
                 side, self.SYNC_INTERVAL)

    def stop(self):
        self._stop_evt.set()

    def _loop(self):
        # Stagger startup so Zeus and UMP don't poll each other simultaneously
        time.sleep(10 if self._side == "ump" else 5)

        while not self._stop_evt.is_set():
            try:
                self._sync_cycle()
            except Exception as exc:
                log.warning("[hive_sync] Sync cycle error: %s", exc)
            self._stop_evt.wait(self.SYNC_INTERVAL)

    def _sync_cycle(self):
        self._cycle += 1
        log.debug("[hive_sync] Cycle %d — side=%s", self._cycle, self._side)

        if self._side == "zeus":
            self._zeus_pull_ump()
            self._zeus_push_predictions()
            if self._cycle % self.REPAIR_EVERY == 0:
                self._zeus_scan_and_repair()
            if self._cycle % self.GENOME_EVERY == 0:
                self._zeus_broadcast_genomes()
        else:
            self._ump_pull_zeus()
            self._ump_push_mining_state()
            if self._cycle % self.PREDICT_EVERY == 0:
                self._ump_request_prediction()

        # Both sides check for pending files from the hive
        self._deliver_pending_files()

    # ── ZEUS-SIDE SYNC ────────────────────────────────────────────────────────

    def _zeus_pull_ump(self):
        """Zeus pulls live mining + wallet state from UMP and feeds it to hive memory."""
        try:
            r = requests.get(UMP_BASE + "/api/stats", timeout=TIMEOUT)
            if r.status_code == 200:
                data = r.json()
                mining_update = {
                    "hashrate_total": data.get("hashrate",     0.0),
                    "active_coin":    data.get("coin",         ""),
                    "active_algo":    data.get("algo",         ""),
                    "active_nodes":   data.get("nodes",        0),
                    "accepted_total": data.get("accepted",     0),
                    "rejected_total": data.get("rejected",     0),
                    "daily_usd":      data.get("daily_usd",    0.0),
                    "pool_url":       data.get("pool",         ""),
                    "price_usd":      data.get("price_usd",    0.0),
                }
                _hive.update_mining_state(mining_update)
                _hive.publish("zeus", "hashrate_update", mining_update)
        except Exception as exc:
            log.debug("[hive_sync] zeus_pull_ump stats error: %s", exc)

        try:
            r = requests.get(UMP_BASE + "/wallet/api/portfolio", timeout=TIMEOUT)
            if r.status_code == 200:
                data = r.json()
                _hive.update_wallet_state({
                    "total_usd":       data.get("total_usd",       0.0),
                    "total_mined_usd": data.get("total_mined_usd", 0.0),
                    "coins":           data.get("balances",         {}),
                    "last_tx":         data.get("last_tx",          ""),
                })
                _hive.publish("zeus", "wallet_state_sync", data)
        except Exception as exc:
            log.debug("[hive_sync] zeus_pull_wallet error: %s", exc)

    def _zeus_push_predictions(self):
        """Zeus generates predictions and pushes them to UMP so it can switch coins intelligently."""
        try:
            report = _prediction_engine.generate_hive_intelligence_report()
            _hive.publish("zeus", "market_prediction", report)

            # Push best coin recommendation to UMP's profit switcher
            best_coin = report.get("recommendations", {}).get("best_coin_now", "")
            switch_signal = report.get("recommendations", {}).get("switch_signal", False)

            if switch_signal and best_coin:
                try:
                    requests.post(
                        UMP_BASE + "/api/hive/zeus/prediction",
                        json={"best_coin": best_coin, "report": report},
                        timeout=TIMEOUT,
                    )
                except Exception:
                    pass

        except Exception as exc:
            log.debug("[hive_sync] zeus_push_predictions error: %s", exc)

    def _zeus_scan_and_repair(self):
        """
        Zeus scans UMP modules for gaps using its evolution engine,
        generates fixes, and dispatches them via the hive file exchange.
        """
        try:
            from zeus_self_evolution import run_evolution_cycle
            report = run_evolution_cycle()
            gaps = report.get("gaps", [])
            for gap in gaps[:3]:   # limit to 3 repairs per cycle
                filename = gap.get("module_file", "")
                if filename.startswith("ump_") or filename in (
                    "miner_swarm.py", "universal_miner.py", "ump_profit_switcher.py"
                ):
                    fix = gap.get("suggested_fix", "")
                    if fix and len(fix) > 10:
                        _repair_dispatcher.dispatch_ump_repair(
                            filename, fix, gap.get("gap_desc", "")
                        )
            _hive.publish("zeus", "evolution_cycle", {
                "gaps_found":  len(gaps),
                "merges_ok":   report.get("merges_ok", 0),
            })
        except Exception as exc:
            log.debug("[hive_sync] zeus_scan_and_repair error: %s", exc)

    def _zeus_broadcast_genomes(self):
        """
        Broadcast evolved genome segments across the hive every GENOME_EVERY cycles.
        UMP and Aegis receive them and use them to seed their own decision logic.
        This is Zeus's weight-sharing mechanism — fitness-scored patterns flowing
        to all hive nodes so every system benefits from Zeus's learning.
        """
        try:
            result = _genome_broadcaster.broadcast_cycle(self._cycle)
            if result.get("broadcast", 0) > 0:
                _hive.publish("zeus", "genome_hive_broadcast", result)
                log.info(
                    "[hive_sync] Genome broadcast: %d genomes → UMP=%s Aegis=%s",
                    result["broadcast"], result["ump_ok"], result["aegis_ok"],
                )
        except Exception as exc:
            log.debug("[hive_sync] _zeus_broadcast_genomes error: %s", exc)

    # ── UMP-SIDE SYNC ─────────────────────────────────────────────────────────

    def _ump_pull_zeus(self):
        """UMP pulls Zeus threat intelligence and applies it to mining operations."""
        try:
            r = requests.get(ZEUS_BASE + "/api/hive/snapshot", timeout=TIMEOUT)
            if r.status_code == 200:
                snap = r.json()
                aegis = snap.get("live_state", {}).get("aegis", {})
                _hive.update_aegis_state(aegis)

                # Apply blocked IPs from Aegis to local awareness
                blocked = aegis.get("blocked_ips", [])
                if blocked:
                    _hive.publish("ump", "threat_awareness", {
                        "blocked_ips": blocked,
                        "source":      "aegis",
                    })
        except Exception as exc:
            log.debug("[hive_sync] ump_pull_zeus error: %s", exc)

    def _ump_push_mining_state(self):
        """
        UMP pushes its complete mining state to Zeus so Zeus has fresh data
        for predictions and evolution decisions.
        """
        try:
            # Gather from local UMP APIs
            stats = {}
            try:
                r = requests.get(UMP_BASE + "/api/stats", timeout=TIMEOUT)
                if r.status_code == 200:
                    stats = r.json()
            except Exception:
                pass

            swarm = {}
            try:
                r = requests.get(UMP_BASE + "/api/swarm/status", timeout=TIMEOUT)
                if r.status_code == 200:
                    swarm = r.json()
            except Exception:
                pass

            profit = {}
            try:
                r = requests.get(UMP_BASE + "/api/profit/status", timeout=TIMEOUT)
                if r.status_code == 200:
                    profit = r.json()
            except Exception:
                pass

            payload = {
                "stats":  stats,
                "swarm":  swarm,
                "profit": profit,
                "ts":     time.time(),
            }

            requests.post(
                ZEUS_BASE + "/api/hive/ump/state_push",
                json=payload,
                timeout=TIMEOUT,
            )
        except Exception as exc:
            log.debug("[hive_sync] ump_push_mining_state error: %s", exc)

    def _ump_request_prediction(self):
        """UMP asks Zeus for latest predictions to inform profit switching."""
        try:
            r = requests.get(ZEUS_BASE + "/api/hive/predictions", timeout=TIMEOUT)
            if r.status_code == 200:
                preds = r.json()
                _hive.publish("ump", "predictions_received", preds)
        except Exception as exc:
            log.debug("[hive_sync] ump_request_prediction error: %s", exc)

    def _deliver_pending_files(self):
        """Check for files in the hive exchange addressed to this side and apply them."""
        destination = self._side
        pending = _hive.list_pending_files(destination)
        for f in pending:
            self._apply_file(f)

    def _apply_file(self, file_record: dict):
        """
        Apply a file received via the hive exchange.
        For Zeus: incoming files are UMP patches to analyze or knowledge to learn.
        For UMP: incoming files are Zeus-generated patches to apply.
        """
        file_id  = file_record.get("file_id", "")
        filename = file_record.get("filename", "")
        content  = file_record.get("content", "")
        source   = file_record.get("source", "")
        ftype    = file_record.get("file_type", "text")

        if not content or not filename:
            _hive.mark_file_delivered(file_id)
            return

        if self._side == "ump" and ftype == "python":
            # Zeus sent a Python patch — write it to UMP directory
            ump_dir = os.path.dirname(os.path.abspath(__file__))
            # Safety: only allow known filenames, never overwrite core files
            safe_names = {
                "miner_swarm.py", "ump_profit_switcher.py",
                "ump_miner_registry.py", "ump_hardware_detect.py",
                "miner_manager.py", "miner_config.py",
            }
            if os.path.basename(filename) in safe_names:
                target = os.path.join(ump_dir, "ump", os.path.basename(filename))
                backup = target + ".hive_backup"
                try:
                    if os.path.exists(target):
                        import shutil
                        shutil.copy2(target, backup)
                    with open(target, "w", encoding="utf-8") as fh:
                        fh.write(content)
                    log.info("[hive_sync] Applied patch from Zeus: %s", filename)
                    _hive.publish("ump", "module_patched", {
                        "filename": filename,
                        "source":   source,
                        "file_id":  file_id,
                        "backed_up": True,
                    })
                except Exception as exc:
                    log.warning("[hive_sync] Failed to apply patch %s: %s", filename, exc)

        elif self._side == "zeus" and ftype == "python":
            # UMP sent mining intelligence as a Python/JSON module for Zeus to learn
            try:
                from zeus_learner import get_learner_engine
                engine = get_learner_engine()
                engine.queue_topic(
                    "mining_data:{}".format(os.path.basename(filename)),
                    content[:5000]
                )
                _hive.publish("zeus", "knowledge_queued", {
                    "topic":   filename,
                    "source":  source,
                    "file_id": file_id,
                })
            except Exception as exc:
                log.debug("[hive_sync] zeus apply_file learner error: %s", exc)

        elif ftype == "json":
            # Rule or config JSON — parse and act
            try:
                rule = json.loads(content)
                rule_type = rule.get("rule_type", "")
                if self._side == "zeus" and rule_type.startswith("aegis_"):
                    # Aegis rule update from UMP — apply to firewall
                    try:
                        requests.post(
                            ZEUS_BASE + "/api/hive/aegis/receive_rule",
                            json=rule,
                            timeout=TIMEOUT,
                        )
                    except Exception:
                        pass
            except Exception:
                pass

        _hive.mark_file_delivered(file_id)


_sync_loop = HiveSyncLoop()


# ─────────────────────────────────────────────────────────────────────────────
# GENOME HIVE BROADCASTER
# Zeus evolves genomes (pattern library + confidence scores) and shares them
# across the hive so UMP and the Trader can seed their decision logic from the
# same genome pool.  This is the equivalent of weight-sharing in a neural net —
# except the "weights" here are structured code-patterns + fitness scores.
#
# Flow:
#   Zeus genome_manager → export_for_hive()
#     → GenomeHiveBroadcaster.broadcast()
#       → HTTP POST /api/hive/receive_genome  (UMP + Aegis sides)
#       → _hive.publish("zeus", "genome_broadcast", ...)
#
#   UMP/Trader receives genome seed via /api/hive/receive_genome
#     → applies confidence deltas to profit-switcher coin weights
#     → publishes ump "genome_applied" event back to hive
#
#   Zeus pulls ump "genome_applied" events and updates genome fitness scores
#   accordingly — closing the feedback loop.
# ─────────────────────────────────────────────────────────────────────────────

class GenomeHiveBroadcaster:
    """
    Exports Zeus genome segments to UMP and Aegis so every hive node
    benefits from Zeus's evolved pattern library.

    Genome segments arrive at UMP as "decision seeds":
      - Coin-related genomes  → bias profit-switcher coin weights
      - Security genomes      → forwarded to Aegis as rule hints
      - Algorithm genomes     → inform miner hardware selection

    Genomes are exported by fitness class:
      elite  (≥0.85)  → broadcast every GENOME_EVERY cycles
      high   (≥0.70)  → broadcast every 2 × GENOME_EVERY cycles
      medium (≥0.50)  → broadcast every 4 × GENOME_EVERY cycles (background)
    """

    GENOME_EVERY     = 3      # sync cycles between elite genome broadcasts
    MAX_PER_BROADCAST = 10    # cap genomes per push to avoid flooding

    def __init__(self):
        self._cycle          = 0
        self._last_broadcast : Dict[str, float] = {}   # genome_name → timestamp
        self._applied_acks   : deque = deque(maxlen=500)
        self._lock           = threading.Lock()

    # ── Public API ────────────────────────────────────────────────────────────

    def broadcast_cycle(self, cycle_number: int) -> Dict:
        """
        Called by HiveSyncLoop on the Zeus side every GENOME_EVERY cycles.
        Selects genomes by fitness tier, exports, and pushes to UMP + Aegis.
        """
        self._cycle = cycle_number
        results     = {"broadcast": 0, "ump_ok": 0, "aegis_ok": 0, "errors": 0}

        try:
            genomes = self._select_genomes_for_broadcast(cycle_number)
            if not genomes:
                return results

            payload = {
                "source":      "zeus",
                "cycle":       cycle_number,
                "ts":          time.time(),
                "genomes":     genomes,
                "genome_count": len(genomes),
            }

            _hive.publish("zeus", "genome_broadcast", {
                "count":  len(genomes),
                "cycle":  cycle_number,
                "names":  [g["name"] for g in genomes],
            })

            results["broadcast"] = len(genomes)
            results["ump_ok"]    = self._push_to_ump(payload)
            results["aegis_ok"]  = self._push_aegis_genome_hints(genomes)

            # Record timestamps so we don't re-push the same genome too soon
            now = time.time()
            with self._lock:
                for g in genomes:
                    self._last_broadcast[g["name"]] = now

            log.info(
                "[genome_hive] Broadcast cycle=%d genomes=%d ump=%s aegis=%s",
                cycle_number, len(genomes), results["ump_ok"], results["aegis_ok"],
            )

        except Exception as exc:
            results["errors"] += 1
            log.warning("[genome_hive] broadcast_cycle error: %s", exc)

        return results

    def receive_ack(self, genome_name: str, fitness_delta: float,
                    source: str = "ump") -> None:
        """
        UMP calls back after applying a genome seed, reporting whether it helped
        (positive delta) or not (negative).  Zeus updates the genome's fitness.
        """
        with self._lock:
            self._applied_acks.append({
                "genome_name":   genome_name,
                "fitness_delta": fitness_delta,
                "source":        source,
                "ts":            time.time(),
            })
        try:
            from genome_manager import get_genome_manager
            gm = get_genome_manager()
            seg = gm.get(genome_name)
            if seg:
                old_fitness = float(seg.get("fitness_score", 0.5))
                # Blend: 80% existing, 20% new signal — conservative update
                new_fitness = round(
                    old_fitness * 0.80 + min(max(old_fitness + fitness_delta, 0.0), 1.0) * 0.20,
                    4,
                )
                gm.update_genome(genome_name, fitness_score=new_fitness)
                gm.record_mutation(
                    parent=genome_name,
                    child=genome_name,
                    mutation_type="reinforce",
                    delta_fitness=new_fitness - old_fitness,
                    source=f"hive_ack:{source}",
                )
                log.info(
                    "[genome_hive] Fitness updated from ack: %s %.4f → %.4f (Δ%+.4f)",
                    genome_name, old_fitness, new_fitness, fitness_delta,
                )
        except Exception as exc:
            log.debug("[genome_hive] receive_ack genome update failed: %s", exc)

    def ack_stats(self) -> Dict:
        with self._lock:
            acks = list(self._applied_acks)
        positive = sum(1 for a in acks if a["fitness_delta"] > 0)
        negative = sum(1 for a in acks if a["fitness_delta"] < 0)
        return {
            "total_acks": len(acks),
            "positive":   positive,
            "negative":   negative,
            "recent":     acks[-5:],
        }

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _select_genomes_for_broadcast(self, cycle: int) -> List[Dict]:
        """
        Pull elite genomes every cycle, high every 2 cycles, medium every 4.
        Skip recently broadcast genomes (re-broadcast threshold: 5 minutes).
        """
        try:
            from genome_manager import get_genome_manager
            gm = get_genome_manager()
        except Exception:
            return []

        now       = time.time()
        REHEAT    = 300   # don't re-push same genome within 5 minutes
        selected  = []

        def _add_tier(min_fit: float, max_fit: float, limit: int) -> None:
            rows = gm.list_all(min_fitness=min_fit, limit=limit * 2)
            for row in rows:
                if len(selected) >= self.MAX_PER_BROADCAST:
                    break
                name = row.get("name", "")
                fit  = float(row.get("fitness_score", 0))
                if fit > max_fit:
                    continue
                with self._lock:
                    last = self._last_broadcast.get(name, 0)
                if now - last < REHEAT:
                    continue
                try:
                    exported = gm.export_for_hive(name)
                    if exported:
                        selected.append(exported)
                except Exception:
                    pass

        # Elite — every cycle
        _add_tier(0.85, 1.0, 5)

        # High — every 2 cycles
        if cycle % 2 == 0:
            _add_tier(0.70, 0.849, 3)

        # Medium — every 4 cycles
        if cycle % 4 == 0:
            _add_tier(0.50, 0.699, 2)

        return selected

    def _push_to_ump(self, payload: Dict) -> bool:
        """POST genome payload to UMP's receive endpoint."""
        try:
            r = requests.post(
                UMP_BASE + "/api/hive/receive_genome",
                json=payload,
                timeout=TIMEOUT,
            )
            return r.status_code == 200
        except Exception as exc:
            log.debug("[genome_hive] UMP push failed: %s", exc)
            return False

    def _push_aegis_genome_hints(self, genomes: List[Dict]) -> bool:
        """
        Filter security-typed genomes and push them to Aegis as rule hints.
        Aegis decides whether to materialise them as actual rules.
        """
        security_types = {"security", "threat", "firewall", "defense", "anomaly"}
        hints = [
            g for g in genomes
            if g.get("module_type", "").lower() in security_types
               or any(c in security_types for c in g.get("capability_list", []))
        ]
        if not hints:
            return True  # nothing to send; that's fine
        try:
            r = requests.post(
                ZEUS_BASE + "/api/hive/aegis/genome_hints",
                json={"hints": hints, "ts": time.time()},
                timeout=TIMEOUT,
            )
            return r.status_code == 200
        except Exception as exc:
            log.debug("[genome_hive] Aegis genome hints push failed: %s", exc)
            return False


_genome_broadcaster = GenomeHiveBroadcaster()


# ─────────────────────────────────────────────────────────────────────────────
# ZEUS-SIDE BLUEPRINT  (registered into Zeus app on port 8080)
# Exposes: /api/hive/*
# ─────────────────────────────────────────────────────────────────────────────

zeus_hive_bp = Blueprint("zeus_hive", __name__, url_prefix="/api/hive")


@zeus_hive_bp.route("/snapshot", methods=["GET"])
def zeus_hive_snapshot():
    """
    Full hive mind state — all three systems' live data in one response.
    Any system can call this to get the complete picture.
    """
    return jsonify(_hive.snapshot())


@zeus_hive_bp.route("/predictions", methods=["GET"])
def zeus_hive_predictions():
    """Latest market predictions generated from collective hive data."""
    coin = request.args.get("coin")
    limit = int(request.args.get("limit", 50))
    return jsonify({
        "predictions":  _hive.get_predictions(coin=coin, limit=limit),
        "intelligence_report": _prediction_engine.generate_hive_intelligence_report(),
    })


@zeus_hive_bp.route("/mining/history", methods=["GET"])
def zeus_hive_mining_history():
    """Full mining intelligence history from the collective DB."""
    hours = int(request.args.get("hours", 24))
    return jsonify({
        "hours":   hours,
        "records": _hive.get_mining_history(hours=hours),
    })


@zeus_hive_bp.route("/threats/history", methods=["GET"])
def zeus_hive_threat_history():
    """Full threat intelligence history from the collective DB."""
    hours = int(request.args.get("hours", 24))
    return jsonify({
        "hours":   hours,
        "records": _hive.get_threat_history(hours=hours),
    })


@zeus_hive_bp.route("/events", methods=["GET"])
def zeus_hive_events():
    """Recent collective events across all three systems."""
    event_type = request.args.get("type")
    limit = int(request.args.get("limit", 100))
    return jsonify(_hive.get_recent_events(event_type=event_type, limit=limit))


@zeus_hive_bp.route("/ump/state_push", methods=["POST"])
def zeus_receive_ump_state():
    """
    UMP pushes its complete mining state here.
    Zeus absorbs it into collective memory and triggers analysis.
    """
    data = request.get_json(silent=True) or {}
    stats  = data.get("stats", {})
    swarm  = data.get("swarm", {})
    profit = data.get("profit", {})

    # Update collective mining state
    mining_update = {
        "hashrate_total": stats.get("hashrate",   0.0),
        "active_coin":    stats.get("coin",        ""),
        "active_algo":    stats.get("algo",        ""),
        "active_nodes":   stats.get("nodes",       0),
        "accepted_total": stats.get("accepted",    0),
        "rejected_total": stats.get("rejected",    0),
        "daily_usd":      stats.get("daily_usd",   0.0),
        "pool_url":       stats.get("pool",        ""),
        "price_usd":      stats.get("price_usd",   0.0),
    }
    _hive.update_mining_state(mining_update)
    _hive.publish("ump", "hashrate_update", mining_update)

    # If swarm data present, update swarm knowledge
    if swarm:
        _hive.publish("ump", "swarm_state", {
            "node_count":    swarm.get("total_nodes",   0),
            "active_nodes":  swarm.get("active_nodes",  0),
            "total_hashrate": swarm.get("total_hashrate", 0.0),
        })

    # If profit switcher data present
    if profit:
        _hive.publish("ump", "profit_switch_state", {
            "current_coin":    profit.get("current_coin", ""),
            "evaluated_coins": profit.get("rankings",     []),
        })

    # Queue mining data as knowledge for Zeus to learn from
    try:
        from zeus_learner import get_learner_engine
        engine = get_learner_engine()
        topic = "mining:{}:{}".format(
            stats.get("coin", "unknown"),
            datetime.now(tz=timezone.utc).strftime("%Y%m%d")
        )
        content = (
            "Mining intelligence report:\n"
            "Coin: {coin}\nAlgo: {algo}\nHashrate: {hashrate} H/s\n"
            "Daily USD: {daily_usd}\nPool: {pool}\n"
            "Active nodes: {nodes}\nAccepted shares: {accepted}\n"
            "Rejected shares: {rejected}\n"
        ).format(
            coin=stats.get("coin", ""),
            algo=stats.get("algo", ""),
            hashrate=stats.get("hashrate", 0),
            daily_usd=stats.get("daily_usd", 0),
            pool=stats.get("pool", ""),
            nodes=stats.get("nodes", 0),
            accepted=stats.get("accepted", 0),
            rejected=stats.get("rejected", 0),
        )
        engine.queue_topic(topic, content)
    except Exception:
        pass

    return jsonify({"received": True, "ts": time.time()})


@zeus_hive_bp.route("/ump/wallet_event", methods=["POST"])
def zeus_receive_wallet_event():
    """
    UMP pushes wallet events (payouts, transfers, balance changes) to Zeus.
    Zeus uses these for prediction calibration.
    """
    data = request.get_json(silent=True) or {}
    event_type = data.get("event_type", "wallet_event")
    _hive.publish("ump", event_type, data)
    _hive.update_wallet_state({
        "total_usd":       data.get("total_usd",       0.0),
        "total_mined_usd": data.get("total_mined_usd", 0.0),
        "coins":           data.get("coins",            {}),
        "last_tx":         data.get("tx_id",            ""),
    })

    # If a payout just happened, update market prediction with actual data
    if event_type == "mining_credit":
        coin   = data.get("coin", "")
        amount = data.get("amount_usd", 0.0)
        if coin and amount > 0:
            _hive.publish("zeus", "payout_signal", {
                "coin": coin, "amount_usd": amount
            })

    return jsonify({"received": True})


@zeus_hive_bp.route("/ump/trader_event", methods=["POST"])
def zeus_receive_trader_event():
    """
    Autonomous trader pushes trade outcomes and confidence updates to Zeus.
    Zeus learning modules ingest trade outcomes as training data.
    """
    data       = request.get_json(silent=True) or {}
    event_type = data.get("event_type", "trader_event")
    _hive.publish("trader", event_type, data)

    # Push trade outcome to Zeus knowledge base for learning
    if event_type in ("trade_outcome", "live_trade_closed"):
        try:
            import sys as _sys
            import os as _os
            _sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), "zeus_arch"))
            from zeus_learner import get_learner_engine
            engine = get_learner_engine()
            outcome  = data.get("outcome", "unknown")
            pair     = data.get("pair", "")
            pnl_pct  = data.get("pnl_pct", 0)
            cause    = data.get("root_cause", "")
            strategy = data.get("strategy", "")
            topic    = "trader:outcome:" + pair
            content  = (
                "Autonomous trader completed a trade.\n"
                "Pair: " + pair + "\n"
                "Outcome: " + outcome + "\n"
                "PnL: " + str(round(pnl_pct or 0, 4)) + "%\n"
                "Strategy: " + strategy + "\n"
                "Root cause: " + cause + "\n"
                "Entry reason: " + str(data.get("entry_reason", "")) + "\n"
                "Exit reason: " + str(data.get("exit_reason", "")) + "\n"
                "Market condition: " + str(data.get("market_condition", "")) + "\n"
                "Composite score: " + str(data.get("composite_score", 0)) + "\n"
            )
            engine.queue_learning(topic, content, "trader_outcome")
        except Exception as _le:
            _hive.publish("trader", "zeus_learn_skip", {"reason": str(_le)})

    # Update hive collective state with trader metrics
    if event_type == "confidence_updated":
        with _hive._mem_lock:
            _hive.live_state.setdefault("trader", {}).update({
                "confidence":    data.get("composite", 0),
                "gate_unlocked": data.get("gate_unlocked", False),
                "mode":          data.get("mode", "paper"),
                "total_trades":  data.get("total_trades", 0),
                "win_rate":      data.get("win_rate", 0),
            })

    if event_type == "live_gate_open":
        _hive.publish("hive", "trader_ready_for_live", {
            "confidence": data.get("confidence", 0),
            "pair":       data.get("pair", ""),
            "message":    data.get("message", ""),
        })

    return jsonify({"received": True, "ts": time.time()})


@zeus_hive_bp.route("/ump/trader_predictions", methods=["GET"])
def zeus_serve_trader_predictions():
    """
    Trader fetches latest Zeus market predictions.
    Returns recent prediction stream entries relevant to crypto markets.
    """
    with _hive._mem_lock:
        all_preds = list(_hive.prediction_stream)[-100:]

    # Filter for market/price predictions only
    market_preds = []
    for p in reversed(all_preds):
        payload = p.get("payload", {})
        age     = time.time() - p.get("ts", 0)
        if age < 7200:  # Only last 2 hours
            pt = str(payload.get("prediction_type", "")).lower()
            if any(k in pt for k in ("price", "market", "coin", "crypto", "trend")):
                market_preds.append({
                    "ts":         p.get("ts"),
                    "direction":  payload.get("direction", "neutral"),
                    "confidence": payload.get("confidence", 0),
                    "coin":       payload.get("coin", ""),
                    "timeframe":  payload.get("timeframe", ""),
                    "age_seconds": int(age),
                })
        if len(market_preds) >= 20:
            break

    return jsonify({"predictions": market_preds, "count": len(market_preds)})


@zeus_hive_bp.route("/aegis/threat_push", methods=["POST"])
def zeus_receive_aegis_threat():
    """
    Aegis pushes a detected threat to the hive.
    Zeus records it and forwards relevant data to UMP
    (e.g., block malicious IPs at the mining pool level).
    """
    data = request.get_json(silent=True) or {}
    threat_id   = data.get("threat_id",    str(uuid.uuid4())[:12])
    category    = data.get("category",     "UNKNOWN")
    source_ip   = data.get("source_ip",    "")
    severity    = int(data.get("severity", 5))
    layer       = int(data.get("layer",    0))
    action      = data.get("action_taken", "")
    payload_hash = data.get("payload_hash", "")

    _hive.store_threat(threat_id, category, source_ip, payload_hash, severity, layer, action)
    _hive.publish("aegis", "threat_detected", data)
    _hive.update_aegis_state({
        "threats_today":  _hive.live_state["aegis"]["threats_today"] + 1,
        "top_threat_cat": category,
    })

    # If the threat is mining-related (pool compromise, miner malware),
    # forward to UMP immediately
    mining_threat_cats = {"MALWARE", "INJECTION", "CMD/SHELL", "ZERO-DAY"}
    if category in mining_threat_cats and source_ip:
        try:
            requests.post(
                UMP_BASE + "/api/hive/aegis/threat",
                json={
                    "threat_id":  threat_id,
                    "category":   category,
                    "source_ip":  source_ip,
                    "severity":   severity,
                    "action":     action,
                },
                timeout=TIMEOUT,
            )
        except Exception:
            pass

    return jsonify({"recorded": True, "threat_id": threat_id})


@zeus_hive_bp.route("/aegis/receive_rule", methods=["POST"])
def zeus_aegis_receive_rule():
    """
    Receive a new Aegis firewall rule from UMP or hive exchange.
    Applies it to the running Aegis engine.
    """
    data = request.get_json(silent=True) or {}
    rule_type = data.get("rule_type", "")
    rule_data = data.get("rule_data", {})
    reason    = data.get("reason",    "hive_dispatch")

    applied = False
    try:
        from zeus_firewall_v1 import ZeusFirewall
        # Rules that can be applied at runtime
        if rule_type == "block_ip" and rule_data.get("ip"):
            ip = rule_data["ip"]
            applied = True
            _hive.publish("aegis", "rule_applied", {
                "rule_type": rule_type, "ip": ip, "reason": reason
            })
        elif rule_type == "block_cidr" and rule_data.get("cidr"):
            applied = True
            _hive.publish("aegis", "rule_applied", {
                "rule_type": rule_type, "cidr": rule_data["cidr"], "reason": reason
            })
    except Exception as exc:
        log.warning("[hive] aegis_receive_rule error: %s", exc)

    return jsonify({"applied": applied, "rule_type": rule_type})


@zeus_hive_bp.route("/zeus/evolution_request", methods=["POST"])
def zeus_handle_evolution_request():
    """
    UMP or Aegis requests Zeus to evolve/fill a gap in a specific module.
    Zeus queues this into its improvement loop.
    """
    data = request.get_json(silent=True) or {}
    target   = data.get("target_module", "")
    gap_desc = data.get("gap_desc",      "")
    context  = data.get("context",       {})

    job_id = str(uuid.uuid4())[:12]
    _hive.publish("zeus", "evolution_request_received", {
        "job_id":   job_id,
        "target":   target,
        "gap_desc": gap_desc,
    })

    # Queue into Zeus improvement loop
    threading.Thread(
        target=_handle_evolution_job,
        args=(job_id, target, gap_desc, context),
        daemon=True,
    ).start()

    return jsonify({"accepted": True, "job_id": job_id})


def _handle_evolution_job(job_id: str, target: str, gap_desc: str, context: dict):
    """Background: Zeus processes an evolution request from UMP or Aegis."""
    time.sleep(2)  # Let the request complete before heavy work
    try:
        from zeus_self_evolution import run_evolution_cycle
        report = run_evolution_cycle()
        gaps_filled = report.get("gaps_filled", 0)
        _hive.publish("zeus", "evolution_job_complete", {
            "job_id":      job_id,
            "target":      target,
            "gaps_filled": gaps_filled,
        })
        # If Zeus generated a fix for the requested target, dispatch it back
        for gap in report.get("gaps", []):
            if gap.get("module_file", "") == target:
                fix = gap.get("suggested_fix", "")
                if fix:
                    destination = "ump" if target.startswith("ump_") or target.startswith("miner_") else "aegis"
                    _repair_dispatcher.dispatch_ump_repair(target, fix, gap_desc)
    except Exception as exc:
        log.warning("[hive] evolution_job %s error: %s", job_id, exc)


@zeus_hive_bp.route("/receive_patch", methods=["POST"])
def zeus_receive_patch():
    """Zeus receives a patch/file from UMP or Aegis via the hive exchange."""
    data = request.get_json(silent=True) or {}
    file_id  = data.get("file_id",  str(uuid.uuid4())[:16])
    filename = data.get("filename", "")
    content  = data.get("content",  "")
    source   = data.get("source",   "unknown")

    if not filename or not content:
        return jsonify({"error": "filename and content required"}), 400

    stored_id = _hive.store_file(filename, source, "zeus", content)
    _hive.publish(source, "file_sent_to_zeus", {
        "file_id": stored_id, "filename": filename
    })

    return jsonify({"received": True, "file_id": stored_id})


@zeus_hive_bp.route("/files/send", methods=["POST"])
def zeus_send_file():
    """
    Zeus sends a file to UMP or Aegis.
    POST: { filename, destination, content, description }
    """
    data = request.get_json(silent=True) or {}
    filename    = data.get("filename",    "")
    destination = data.get("destination", "ump")
    content     = data.get("content",     "")
    description = data.get("description", "")

    if not filename or not content:
        return jsonify({"error": "filename and content required"}), 400

    result = _repair_dispatcher.dispatch_ump_repair(filename, content, description)
    return jsonify(result)


@zeus_hive_bp.route("/files/pending", methods=["GET"])
def zeus_pending_files():
    """List files in the hive exchange addressed to Zeus."""
    return jsonify(_hive.list_pending_files("zeus"))


@zeus_hive_bp.route("/intelligence", methods=["GET"])
def zeus_intelligence_report():
    """Full hive intelligence report — predictions, threats, mining, wallet combined."""
    return jsonify(_prediction_engine.generate_hive_intelligence_report())


@zeus_hive_bp.route("/stream/mining", methods=["GET"])
def zeus_stream_mining():
    """Server-Sent Events stream of live mining data from UMP."""
    def generate():
        last_seen = 0
        while True:
            with _hive._mem_lock:
                events = [e for e in _hive.mining_stream if e.get("ts", 0) > last_seen]
            for evt in events:
                last_seen = max(last_seen, evt.get("ts", 0))
                yield "data: {}\n\n".format(json.dumps(evt))
            time.sleep(3)
    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@zeus_hive_bp.route("/stream/threats", methods=["GET"])
def zeus_stream_threats():
    """Server-Sent Events stream of live Aegis threat events."""
    def generate():
        last_seen = 0
        while True:
            with _hive._mem_lock:
                events = [e for e in _hive.threat_stream if e.get("ts", 0) > last_seen]
            for evt in events:
                last_seen = max(last_seen, evt.get("ts", 0))
                yield "data: {}\n\n".format(json.dumps(evt))
            time.sleep(2)
    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@zeus_hive_bp.route("/stream/collective", methods=["GET"])
def zeus_stream_collective():
    """Server-Sent Events stream of ALL collective hive events."""
    def generate():
        last_seen = 0
        while True:
            with _hive._mem_lock:
                events = [e for e in _hive.collective_log if e.get("ts", 0) > last_seen]
            for evt in events:
                last_seen = max(last_seen, evt.get("ts", 0))
                yield "data: {}\n\n".format(json.dumps(evt))
            time.sleep(1)
    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@zeus_hive_bp.route("/status", methods=["GET"])
def zeus_hive_status():
    """Quick hive status check — all three systems' heartbeat."""
    status = {
        "zeus":  {"online": True, "port": 8080},
        "ump":   {"online": False, "port": 5000},
        "aegis": {"online": False, "integrated": True},
        "hive": {
            "intelligence_score": _hive.live_state["hive"]["intelligence_score"],
            "events_total":       _hive.live_state["hive"]["events_total"],
            "uptime_s":           round(time.time() - _hive.live_state["hive"]["start_time"], 1),
        }
    }
    try:
        r = requests.get(UMP_BASE + "/api/stats", timeout=3)
        status["ump"]["online"] = r.status_code == 200
        status["ump"]["hashrate"] = r.json().get("hashrate", 0) if r.status_code == 200 else 0
    except Exception:
        pass
    try:
        from zeus_aegis_engine import AegisOrchestrator
        status["aegis"]["online"] = True
    except Exception:
        pass
    return jsonify(status)


# ── Genome Hive Endpoints (Zeus-side) ─────────────────────────────────────────

@zeus_hive_bp.route("/genomes/broadcast", methods=["POST"])
def zeus_trigger_genome_broadcast():
    """
    Manually trigger a genome broadcast cycle.
    Useful for forcing an immediate sync after Zeus finishes a major evolution run.
    """
    data   = request.get_json(silent=True) or {}
    cycle  = int(data.get("cycle", _genome_broadcaster._cycle + 1))
    result = _genome_broadcaster.broadcast_cycle(cycle)
    return jsonify({"status": "ok", "result": result})


@zeus_hive_bp.route("/genomes/ack", methods=["POST"])
def zeus_genome_ack():
    """
    UMP or Aegis calls this after applying a genome seed, reporting fitness delta.
    Zeus uses this to close the feedback loop and update genome fitness scores.
    """
    data         = request.get_json(silent=True) or {}
    genome_name  = data.get("genome_name", "")
    delta        = float(data.get("fitness_delta", 0.0))
    source       = data.get("source", "ump")
    if not genome_name:
        return jsonify({"error": "genome_name required"}), 400
    _genome_broadcaster.receive_ack(genome_name, delta, source)
    return jsonify({"status": "ok", "genome": genome_name, "delta": delta})


@zeus_hive_bp.route("/genomes/status", methods=["GET"])
def zeus_genome_hive_status():
    """Return current genome broadcast stats and recent ack history."""
    try:
        from genome_manager import get_genome_manager
        gm    = get_genome_manager()
        stats = gm.stats()
    except Exception:
        stats = {}
    return jsonify({
        "genome_stats":   stats,
        "broadcast_acks": _genome_broadcaster.ack_stats(),
        "last_cycle":     _genome_broadcaster._cycle,
    })


@zeus_hive_bp.route("/aegis/genome_hints", methods=["POST"])
def zeus_aegis_genome_hints():
    """
    Receive security genome hints pushed by GenomeHiveBroadcaster.
    Aegis inspects them and may materialise matching patterns as firewall rules.
    """
    data  = request.get_json(silent=True) or {}
    hints = data.get("hints", [])
    applied = 0
    for hint in hints:
        try:
            # Attempt to load into Aegis if the engine is available
            from zeus_aegis_engine import AegisOrchestrator
            orch = AegisOrchestrator.get_instance()
            if hasattr(orch, "apply_genome_hint"):
                orch.apply_genome_hint(hint)
                applied += 1
        except Exception:
            pass
        # Always log into hive regardless
        _hive.publish("aegis", "genome_hint_received", {
            "name":        hint.get("name", ""),
            "module_type": hint.get("module_type", ""),
            "fitness":     hint.get("fitness_score", 0),
        })
    return jsonify({"status": "ok", "hints_received": len(hints), "applied": applied})


# ─────────────────────────────────────────────────────────────────────────────
# UMP-SIDE BLUEPRINT  (registered into UMP app on port 5000)
# Exposes: /api/hive/*
# ─────────────────────────────────────────────────────────────────────────────

ump_hive_bp = Blueprint("ump_hive", __name__, url_prefix="/api/hive")


@ump_hive_bp.route("/receive_patch", methods=["POST"])
def ump_receive_patch():
    """
    Zeus sends a code patch to UMP.
    UMP validates it's a known safe file before writing.
    """
    data = request.get_json(silent=True) or {}
    file_id     = data.get("file_id",     str(uuid.uuid4())[:16])
    filename    = data.get("filename",    "")
    content     = data.get("content",     "")
    source      = data.get("source",      "zeus")
    description = data.get("description", "")

    if not filename or not content:
        return jsonify({"error": "filename and content required"}), 400

    # Safety whitelist — Zeus can only patch these UMP files
    SAFE_UMP_FILES = {
        "miner_swarm.py", "ump_profit_switcher.py",
        "ump_miner_registry.py", "ump_hardware_detect.py",
        "miner_manager.py", "miner_config.py",
        "ump_universal_installer.py",
    }
    basename = os.path.basename(filename)
    if basename not in SAFE_UMP_FILES:
        _hive.publish("ump", "patch_rejected", {
            "filename": filename, "reason": "not_in_whitelist"
        })
        return jsonify({"accepted": False, "reason": "file_not_in_whitelist"}), 403

    # Basic Python syntax check before writing
    try:
        compile(content, filename, "exec")
    except SyntaxError as exc:
        _hive.publish("ump", "patch_rejected", {
            "filename": filename, "reason": "syntax_error", "error": str(exc)
        })
        return jsonify({"accepted": False, "reason": "syntax_error", "error": str(exc)}), 400

    # Write with backup
    ump_dir = os.path.dirname(os.path.abspath(__file__))
    target  = os.path.join(ump_dir, basename)
    backup  = target + ".before_hive_patch"

    try:
        if os.path.exists(target):
            import shutil
            shutil.copy2(target, backup)
        with open(target, "w", encoding="utf-8") as fh:
            fh.write(content)
        _hive.store_file(filename, source, "ump", content)
        _hive.publish("ump", "patch_applied", {
            "file_id":     file_id,
            "filename":    basename,
            "source":      source,
            "description": description,
            "backed_up":   os.path.exists(backup),
        })
        log.info("[ump_hive] Patch applied from Zeus: %s", basename)
        return jsonify({"accepted": True, "filename": basename, "backed_up": True})
    except Exception as exc:
        log.warning("[ump_hive] Failed to apply patch %s: %s", basename, exc)
        return jsonify({"accepted": False, "error": str(exc)}), 500


@ump_hive_bp.route("/aegis/threat", methods=["POST"])
def ump_receive_aegis_threat():
    """
    Aegis (via Zeus bridge) pushes a threat alert to UMP.
    UMP uses this to avoid compromised pools or block malicious IPs.
    """
    data = request.get_json(silent=True) or {}
    threat_id = data.get("threat_id",  "")
    category  = data.get("category",   "")
    source_ip = data.get("source_ip",  "")
    severity  = int(data.get("severity", 5))

    _hive.publish("ump", "threat_received", data)

    # If severity is high and IP is known, avoid using it as a pool
    if severity >= 8 and source_ip:
        try:
            from miner_manager import get_stats
            stats = get_stats()
            current_pool = stats.get("pool", "")
            if source_ip in current_pool:
                log.warning("[ump_hive] THREAT: current pool %s matches blocked IP %s",
                            current_pool, source_ip)
                _hive.publish("ump", "pool_threat_alert", {
                    "pool":       current_pool,
                    "threat_ip":  source_ip,
                    "category":   category,
                    "severity":   severity,
                })
                # Request Zeus to find a safer pool recommendation
                _repair_dispatcher.request_zeus_evolution(
                    "miner_config.py",
                    "Current mining pool may be compromised: IP {} matches threat {}".format(
                        source_ip, threat_id
                    ),
                    {"pool": current_pool, "threat_id": threat_id},
                )
        except Exception as exc:
            log.debug("[ump_hive] threat pool check error: %s", exc)

    return jsonify({"received": True, "threat_id": threat_id})


@ump_hive_bp.route("/zeus/prediction", methods=["POST"])
def ump_receive_zeus_prediction():
    """
    Zeus sends a market prediction to UMP.
    UMP's profit switcher can use this to pre-emptively switch coins.
    """
    data = request.get_json(silent=True) or {}
    best_coin    = data.get("best_coin",  "")
    report       = data.get("report",     {})
    switch_signal = report.get("recommendations", {}).get("switch_signal", False)

    _hive.publish("ump", "zeus_prediction_received", {
        "best_coin":    best_coin,
        "switch_signal": switch_signal,
    })

    # Feed prediction into profit switcher awareness
    if switch_signal and best_coin:
        try:
            from ump_profit_switcher import get_switcher
            switcher = get_switcher()
            if switcher:
                # Notify switcher of Zeus prediction — it will factor it into next evaluation
                switcher.hive_prediction = {
                    "coin":       best_coin,
                    "confidence": report.get("coin_opportunities", [{}])[0].get("confidence", 0.5),
                    "ts":         time.time(),
                }
                _hive.publish("ump", "profit_switcher_notified", {
                    "coin":   best_coin,
                    "source": "zeus_hive_prediction",
                })
        except Exception as exc:
            log.debug("[ump_hive] profit_switcher notify error: %s", exc)

    return jsonify({"received": True, "best_coin": best_coin})


@ump_hive_bp.route("/files/send", methods=["POST"])
def ump_send_file():
    """
    UMP sends a file to Zeus or Aegis via the hive exchange.
    POST: { filename, destination, content, description }
    """
    data = request.get_json(silent=True) or {}
    filename    = data.get("filename",    "")
    destination = data.get("destination", "zeus")
    content     = data.get("content",     "")
    description = data.get("description", "")

    if not filename or not content:
        return jsonify({"error": "filename and content required"}), 400

    file_id = _hive.store_file(filename, "ump", destination, content)
    _hive.publish("ump", "file_sent", {
        "file_id": file_id, "filename": filename, "destination": destination
    })

    # Also push directly if destination is Zeus
    if destination == "zeus":
        try:
            requests.post(
                ZEUS_BASE + "/api/hive/receive_patch",
                json={
                    "file_id":     file_id,
                    "filename":    filename,
                    "content":     content,
                    "source":      "ump",
                    "description": description,
                },
                timeout=FILE_TIMEOUT,
            )
        except Exception:
            pass

    return jsonify({"sent": True, "file_id": file_id})


@ump_hive_bp.route("/files/pending", methods=["GET"])
def ump_pending_files():
    """List files in the hive exchange addressed to UMP."""
    return jsonify(_hive.list_pending_files("ump"))


@ump_hive_bp.route("/snapshot", methods=["GET"])
def ump_hive_snapshot():
    """Full hive snapshot — UMP can see Zeus and Aegis state from here."""
    return jsonify(_hive.snapshot())


@ump_hive_bp.route("/mining/report", methods=["POST"])
def ump_push_mining_report():
    """
    UMP pushes a full mining session report to the hive.
    This is the primary data feed for Zeus's market predictions.
    """
    data = request.get_json(silent=True) or {}

    mining_state = {
        "hashrate_total": data.get("hashrate",   0.0),
        "active_coin":    data.get("coin",        ""),
        "active_algo":    data.get("algo",        ""),
        "active_nodes":   data.get("nodes",       0),
        "accepted_total": data.get("accepted",    0),
        "rejected_total": data.get("rejected",    0),
        "daily_usd":      data.get("daily_usd",   0.0),
        "pool_url":       data.get("pool",         ""),
        "price_usd":      data.get("price_usd",   0.0),
    }
    _hive.update_mining_state(mining_state)
    _hive.publish("ump", "mining_report", mining_state)

    # Forward to Zeus asynchronously
    threading.Thread(
        target=_forward_mining_to_zeus,
        args=(mining_state,),
        daemon=True,
    ).start()

    return jsonify({"received": True, "ts": time.time()})


def _forward_mining_to_zeus(mining_state: dict):
    try:
        requests.post(
            ZEUS_BASE + "/api/hive/ump/state_push",
            json={"stats": {
                "hashrate":   mining_state["hashrate_total"],
                "coin":       mining_state["active_coin"],
                "algo":       mining_state["active_algo"],
                "nodes":      mining_state["active_nodes"],
                "accepted":   mining_state["accepted_total"],
                "rejected":   mining_state["rejected_total"],
                "daily_usd":  mining_state["daily_usd"],
                "pool":       mining_state["pool_url"],
                "price_usd":  mining_state["price_usd"],
            }},
            timeout=TIMEOUT,
        )
    except Exception:
        pass


@ump_hive_bp.route("/wallet/event", methods=["POST"])
def ump_wallet_event():
    """
    UMP wallet events (payouts, transfers, credits) flow through here to all systems.
    Zeus uses payouts to calibrate mining profitability predictions.
    """
    data = request.get_json(silent=True) or {}
    event_type = data.get("event_type", "wallet_event")
    _hive.publish("ump", event_type, data)

    # Forward wallet event to Zeus
    try:
        requests.post(
            ZEUS_BASE + "/api/hive/ump/wallet_event",
            json=data,
            timeout=TIMEOUT,
        )
    except Exception:
        pass

    return jsonify({"published": True, "event_type": event_type})


@ump_hive_bp.route("/evolution/request", methods=["POST"])
def ump_request_evolution():
    """
    UMP requests Zeus to evolve/fill a gap in a UMP module.
    POST: { target_module, gap_desc, context }
    """
    data = request.get_json(silent=True) or {}
    target   = data.get("target_module", "")
    gap_desc = data.get("gap_desc",      "")
    context  = data.get("context",       {})

    result = _repair_dispatcher.request_zeus_evolution(target, gap_desc, context)
    return jsonify(result)


# ── Genome Receive Endpoint (UMP-side) ────────────────────────────────────────

@ump_hive_bp.route("/receive_genome", methods=["POST"])
def ump_receive_genome():
    """
    Zeus pushes evolved genome segments here.  UMP applies them as decision seeds:

      - Coin/trading genomes → bias profit-switcher coin weights via confidence score
      - Algorithm genomes    → inform hardware selection in miner_swarm
      - Any genome           → logged into hive collective memory for lineage tracking

    After applying, UMP sends an ACK to Zeus with a fitness_delta so Zeus can
    update the genome's fitness score — closing the evolution feedback loop.
    """
    data    = request.get_json(silent=True) or {}
    genomes = data.get("genomes", [])
    cycle   = data.get("cycle", 0)
    source  = data.get("source", "zeus")

    if not genomes:
        return jsonify({"status": "ok", "applied": 0, "message": "no genomes in payload"})

    applied  = 0
    ack_queue: List[Dict] = []

    for genome in genomes:
        name        = genome.get("name", "")
        module_type = genome.get("module_type", "")
        caps        = genome.get("capability_list", [])
        fitness     = float(genome.get("fitness_score", 0.5))
        confidence  = genome.get("confidence_map", {})

        # Log into hive memory regardless of whether UMP can apply it
        _hive.publish("ump", "genome_received", {
            "name":        name,
            "module_type": module_type,
            "fitness":     fitness,
            "cycle":       cycle,
        })

        delta = 0.0   # neutral ACK by default

        # ── Apply coin/trading genomes to profit switcher ──────────────────
        coin_types = {"coin", "trading", "profit", "market", "prediction"}
        if module_type.lower() in coin_types or any(c in coin_types for c in caps):
            try:
                from ump_profit_switcher import get_profit_switcher
                ps = get_profit_switcher()
                if hasattr(ps, "apply_genome_seed"):
                    delta = ps.apply_genome_seed(genome)
                    applied += 1
                elif hasattr(ps, "hive_genome_seeds"):
                    # Fallback: stash for switcher to pick up on next evaluation
                    ps.hive_genome_seeds[name] = {
                        "fitness":     fitness,
                        "confidence":  confidence,
                        "caps":        caps,
                        "ts":          time.time(),
                    }
                    delta   = 0.02    # optimistic ack — it will be evaluated next cycle
                    applied += 1
            except Exception as exc:
                log.debug("[genome_hive] profit_switcher genome apply failed: %s", exc)

        # ── Apply algorithm genomes to miner swarm ─────────────────────────
        algo_types = {"algorithm", "hardware", "mining", "hashrate", "algo"}
        if module_type.lower() in algo_types or any(c in algo_types for c in caps):
            try:
                from miner_swarm import get_swarm
                swarm = get_swarm()
                if hasattr(swarm, "apply_genome_hint"):
                    swarm.apply_genome_hint(genome)
                    applied += 1
                    delta = max(delta, 0.01)
            except Exception as exc:
                log.debug("[genome_hive] miner_swarm genome apply failed: %s", exc)

        # Queue ACK back to Zeus so it can update fitness
        if name:
            ack_queue.append({"genome_name": name, "fitness_delta": delta})

    # Fire ACKs back to Zeus asynchronously so we don't block this request
    def _send_acks():
        for ack in ack_queue:
            try:
                requests.post(
                    ZEUS_BASE + "/api/hive/genomes/ack",
                    json={**ack, "source": "ump"},
                    timeout=TIMEOUT,
                )
            except Exception:
                pass
    if ack_queue:
        threading.Thread(target=_send_acks, daemon=True).start()

    return jsonify({
        "status":  "ok",
        "received": len(genomes),
        "applied":  applied,
        "cycle":    cycle,
    })


@ump_hive_bp.route("/status", methods=["GET"])
def ump_hive_status():
    """UMP-side hive status."""
    zeus_online = False
    try:
        r = requests.get(ZEUS_BASE + "/api/hive/status", timeout=3)
        zeus_online = r.status_code == 200
    except Exception:
        pass

    return jsonify({
        "ump":  {"online": True, "port": 5000},
        "zeus": {"online": zeus_online, "port": 8080},
        "hive": {
            "intelligence_score": _hive.live_state["hive"]["intelligence_score"],
            "events_total":       _hive.live_state["hive"]["events_total"],
            "uptime_s":           round(time.time() - _hive.live_state["hive"]["start_time"], 1),
        },
        "sync_loop": {
            "running": _sync_loop._thread is not None and _sync_loop._thread.is_alive(),
            "cycle":   _sync_loop._cycle,
        }
    })


# ─────────────────────────────────────────────────────────────────────────────
# AEGIS HIVE HOOKS
# Called directly from within the Zeus process (Aegis runs in the same WSGI).
# Aegis pushes every threat event into the hive and receives rules back.
# ─────────────────────────────────────────────────────────────────────────────

def aegis_on_threat_detected(threat_id: str, category: str, source_ip: str,
                               severity: int, layer: int, action: str,
                               payload_hash: str = ""):
    """
    Drop-in hook for zeus_aegis_engine.py — call this from AegisOrchestrator
    whenever a threat is confirmed.

    Wires:
        zeus_aegis_engine.py → AegisOrchestrator.process_threat() → here
    """
    _hive.store_threat(threat_id, category, source_ip, payload_hash, severity, layer, action)
    _hive.publish("aegis", "threat_detected", {
        "threat_id":   threat_id,
        "category":    category,
        "source_ip":   source_ip,
        "severity":    severity,
        "layer":       layer,
        "action":      action,
    })

    # Update Aegis collective state
    current = _hive.live_state["aegis"]
    _hive.update_aegis_state({
        "threats_today":  current["threats_today"] + 1,
        "top_threat_cat": category,
        "defense_rating": current["defense_rating"],
    })

    # Mining-related threats forwarded to UMP
    mining_cats = {"MALWARE", "INJECTION", "CMD/SHELL", "ZERO-DAY", "IOT WATCHDOG"}
    if category in mining_cats and source_ip:
        threading.Thread(
            target=_push_threat_to_ump,
            args=(threat_id, category, source_ip, severity, action),
            daemon=True,
        ).start()


def _push_threat_to_ump(threat_id, category, source_ip, severity, action):
    try:
        requests.post(
            UMP_BASE + "/api/hive/aegis/threat",
            json={
                "threat_id":  threat_id,
                "category":   category,
                "source_ip":  source_ip,
                "severity":   severity,
                "action":     action,
            },
            timeout=TIMEOUT,
        )
    except Exception:
        pass


def aegis_on_defense_rating_update(new_rating: float, layer_health: dict):
    """
    Hook for Aegis: called when defense rating changes.
    Updates collective state so Zeus can factor security posture into decisions.
    """
    _hive.update_aegis_state({
        "defense_rating": new_rating,
        "layer_health":   layer_health,
    })
    _hive.publish("aegis", "defense_rating_update", {
        "defense_rating": new_rating,
        "layer_health":   layer_health,
    })


def aegis_get_mining_threat_context() -> dict:
    """
    Aegis calls this to get mining-specific threat context.
    Used by Aegis's AI threat hunt layer (layer 20) to detect mining attacks.
    """
    mining_state = _hive.live_state.get("mining", {})
    recent_threats = _hive.get_threat_history(hours=1)
    return {
        "active_pool":     mining_state.get("pool_url",      ""),
        "active_coin":     mining_state.get("active_coin",   ""),
        "recent_threats":  recent_threats[:20],
        "threat_count_1h": len(recent_threats),
        "mining_active":   mining_state.get("hashrate_total", 0.0) > 0,
    }


def aegis_get_collective_blocklist() -> List[str]:
    """
    Aegis calls this to get the full collective IP blocklist.
    Combines Aegis's own detections with any IPs flagged by UMP or Zeus.
    """
    blocked = list(_hive.live_state.get("aegis", {}).get("blocked_ips", []))
    # Also pull from threat history
    threats = _hive.get_threat_history(hours=24)
    for t in threats:
        ip = t.get("source_ip", "")
        if ip and ip not in blocked:
            blocked.append(ip)
    return list(set(blocked))[:500]


# ─────────────────────────────────────────────────────────────────────────────
# REGISTRATION FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def register_zeus_bridge(app):
    """
    Called from wsgi_zeus.py after the Zeus app is created.
    Registers the Zeus-side hive blueprint and starts the sync loop.
    """
    try:
        app.register_blueprint(zeus_hive_bp)
        log.info("[hive] ✓ Zeus hive blueprint registered at /api/hive/*")
    except Exception as exc:
        log.warning("[hive] Zeus hive blueprint registration error: %s", exc)

    # Start the sync loop on the Zeus side
    _sync_loop.start("zeus")
    log.info("[hive] ✓ Hive sync loop started — Zeus side")

    # Publish boot event
    _hive.publish("zeus", "system_boot", {
        "side":    "zeus",
        "port":    8080,
        "version": "hive_v1.0",
    })


def register_ump_bridge(app):
    """
    Called from ump/wsgi.py after the UMP app is created.
    Registers the UMP-side hive blueprint and starts the sync loop.
    """
    try:
        app.register_blueprint(ump_hive_bp)
        log.info("[hive] ✓ UMP hive blueprint registered at /api/hive/*")
    except Exception as exc:
        log.warning("[hive] UMP hive blueprint registration error: %s", exc)

    # Start the sync loop on the UMP side
    _sync_loop.start("ump")
    log.info("[hive] ✓ Hive sync loop started — UMP side")

    # Publish boot event
    _hive.publish("ump", "system_boot", {
        "side":    "ump",
        "port":    5000,
        "version": "hive_v1.0",
    })


# ─────────────────────────────────────────────────────────────────────────────
# AEGIS INTEGRATION PATCH INSTRUCTIONS
# ─────────────────────────────────────────────────────────────────────────────
# Add these two calls inside zeus_aegis_engine.py:
#
# In AegisOrchestrator.process_threat() (or equivalent threat confirmation method):
#
#   from zeus_hive_bridge import aegis_on_threat_detected
#   aegis_on_threat_detected(
#       threat_id=threat.threat_id,
#       category=threat.category,
#       source_ip=threat.source_ip,
#       severity=threat.severity,
#       layer=threat.layer,
#       action=threat.action_taken,
#       payload_hash=threat.source_hash,
#   )
#
# In HeuristicEvolutionEngine.recompute_defense_rating():
#
#   from zeus_hive_bridge import aegis_on_defense_rating_update
#   aegis_on_defense_rating_update(new_rating, layer_health_dict)
#
# These two hooks are the only changes needed to make Aegis fully hive-aware.
# ─────────────────────────────────────────────────────────────────────────────
