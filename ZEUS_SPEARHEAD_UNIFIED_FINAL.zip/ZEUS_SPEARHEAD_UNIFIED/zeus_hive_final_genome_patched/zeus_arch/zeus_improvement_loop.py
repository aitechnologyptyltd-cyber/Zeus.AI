# The Zeus Project 2026 — Francois Nel
# zeus_improvement_loop.py — Continuous Improvement Loop Orchestrator
# ============================================================
# This module is the SPINE of Zeus self-improvement.
# It wires every layer together into one closed feedback loop:
#
#   DB (knowledge + genome + queue)
#     ↓
#   zeus_learner         — 5-depth learning from queue topics
#     ↓
#   zeus_recursive_learner — bulk fast-path queue processing
#     ↓
#   zeus_code_learner    — AST + Halstead + call-graph mastery
#     ↓
#   zeus_mutator         — topic tree generation from mastered knowledge
#     ↓
#   zeus_self_evolution  — gap detection + safe code fills (PEL)
#     ↓
#   genome_manager       — fitness-scored DNA registry
#     ↓
#   logic_engine         — architectural reasoning + synthesis blueprints
#     ↓
#   zeus_synthesis       — FastAPI tool synthesis from intent
#     ↓
#   zeus_forge           — knowledge-aware code generation
#     ↓
#   zeus_apk_builder_core / zeus_apk_engine — real APK builds
#     ↓
#   DB (genome + knowledge + blueprints) ← loop back ∞
#
# This file only ORCHESTRATES. It never touches internal logic of other modules.
# ============================================================

import os
import time
import json
import logging
import threading
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.improvement_loop")

improvement_bp = Blueprint("improvement_loop", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))


# ============================================================================
# LOOP STATS
# ============================================================================

@dataclass
class LoopStats:
    start_time:        float = field(default_factory=time.time)
    cycles_complete:   int   = 0
    learner_triggers:  int   = 0
    mutator_triggers:  int   = 0
    evolution_triggers:int   = 0
    genome_updates:    int   = 0
    synthesis_triggers:int   = 0
    forge_triggers:    int   = 0
    apk_triggers:      int   = 0
    last_cycle_at:     str   = ""
    last_cycle_ms:     float = 0.0
    errors:            int   = 0

    def uptime_s(self) -> float:
        return round(time.time() - self.start_time, 1)

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["uptime_s"] = self.uptime_s()
        return d


# ============================================================================
# IMPROVEMENT LOOP ENGINE
# ============================================================================

class ImprovementLoopEngine:
    """
    Orchestrates the continuous self-improvement loop.
    Runs a background thread that periodically checks each subsystem
    and triggers the next stage when conditions are met.
    No internal logic is duplicated — this module only calls
    the public APIs of other Zeus modules.
    """

    CYCLE_INTERVAL_S = 120     # seconds between full loop cycles
    MIN_QUEUE_SEED   = 50      # seed mutator when queue drops below this

    def __init__(self):
        self._lock    = threading.RLock()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._stats   = LoopStats()
        self._event_log: deque = deque(maxlen=200)

    def start(self) -> Dict:
        with self._lock:
            if self._running:
                return {"status": "already_running"}
            self._running = True

        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="improvement_loop"
        )
        self._thread.start()
        log.info("[ImprovementLoop] Started")
        return {"status": "started"}

    def stop(self) -> Dict:
        with self._lock:
            if not self._running:
                return {"status": "not_running"}
            self._running = False
        log.info("[ImprovementLoop] Stop signal sent")
        return {"status": "stopping"}

    def is_running(self) -> bool:
        with self._lock:
            return self._running

    def stats(self) -> Dict:
        with self._lock:
            return self._stats.to_dict()

    def event_log(self, limit: int = 50) -> List[Dict]:
        with self._lock:
            return list(self._event_log)[-limit:]

    # ------------------------------------------------------------------ #
    # MAIN LOOP                                                            #
    # ------------------------------------------------------------------ #

    def _loop(self):
        log.info("[ImprovementLoop] Background thread active")
        while True:
            with self._lock:
                if not self._running:
                    break

            t0 = time.time()
            try:
                self._run_cycle()
                self._stats.cycles_complete += 1
                self._stats.last_cycle_ms  = round((time.time() - t0) * 1000, 1)
                self._stats.last_cycle_at  = datetime.now(timezone.utc).isoformat()
            except Exception as e:
                self._stats.errors += 1
                log.error(f"[ImprovementLoop] Cycle error: {e}", exc_info=True)

            # Sleep between cycles (interruptible)
            for _ in range(int(self.CYCLE_INTERVAL_S)):
                with self._lock:
                    if not self._running:
                        return
                time.sleep(1)

        log.info("[ImprovementLoop] Stopped")

    # ------------------------------------------------------------------ #
    # CYCLE STAGES                                                         #
    # ------------------------------------------------------------------ #

    def _run_cycle(self):
        """
        One full improvement cycle.
        Each stage is wrapped in try/except so a failing stage
        never blocks subsequent stages.
        """
        cycle_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        self._log_event(f"cycle_start:{cycle_id}")

        # STAGE 1 — Ensure learner is processing the queue
        self._stage_learner()

        # STAGE 2 — Ensure code learner is scanning Zeus modules
        self._stage_code_learner()

        # STAGE 3 — Feed genome-based topics into the mutator
        self._stage_mutator_from_genome()

        # STAGE 4 — Ensure the knowledge queue is seeded
        self._stage_seed_queue()

        # STAGE 5 — Notify logic engine of new knowledge → update facts
        self._stage_logic_refresh()

        # STAGE 6 — Recompute genome fitness scores
        self._stage_genome_fitness()

        # STAGE 7 — Trigger prediction engine to find improvement opportunities
        self._stage_prediction_scan()

        # STAGE 8 — Hive sync: update collective state and push Zeus metrics
        self._stage_hive_sync()

        self._log_event(f"cycle_end:{cycle_id}")

    def _stage_learner(self):
        try:
            from zeus_learner import get_learner_engine
            engine = get_learner_engine()
            stats  = engine.stats()
            # Restart scheduler if it died
            if not stats.get("scheduler", False):
                engine.start_scheduler()
                self._log_event("learner_scheduler_restarted")
                log.info("[ImprovementLoop] Learner scheduler restarted")
            self._stats.learner_triggers += 1
        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage learner: {e}")

    def _stage_code_learner(self):
        try:
            from zeus_code_learner import get_code_learner
            cl = get_code_learner()
            if not cl.is_running():
                cl.start()
                self._log_event("code_learner_restarted")
                log.info("[ImprovementLoop] Code learner restarted")
        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage code learner: {e}")

    def _stage_mutator_from_genome(self):
        """
        Pull high-fitness genome segments and seed the mutator
        so the learning queue keeps expanding from our DNA.
        """
        try:
            from db_init import get_db
            conn  = get_db()
            # Only pick recently updated genomes to avoid redundant mutation
            rows  = conn.execute(
                """
                SELECT name, capabilities FROM genome
                WHERE fitness_score > 0.4 OR priority > 60
                ORDER BY priority DESC, fitness_score DESC
                LIMIT 15
                """
            ).fetchall()
            count_kb = conn.execute(
                "SELECT COUNT(*) FROM knowledge"
            ).fetchone()[0]
            conn.close()

            if not rows:
                return

            from zeus_mutator import get_engine as get_mutator
            seeds = []
            for row in rows:
                seeds.append({"topic": row["name"], "priority": 1.2, "depth": "Simple"})
                for cap in (row["capabilities"] or "").split(",")[:3]:
                    cap = cap.strip()
                    if cap and len(cap) > 4:
                        seeds.append({"topic": cap, "priority": 1.0, "depth": "Simple"})

            if seeds:
                get_mutator().mutate(seeds, source="improvement_loop_genome", use_ai=False)
                self._stats.mutator_triggers += 1
                self._log_event(f"mutator_seeded:{len(seeds)}_topics")

        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage mutator: {e}")

    def _stage_seed_queue(self):
        """
        If the learning queue is running low, seed it with knowledge
        topics extracted from Mastery-depth articles so deeper topics
        get advanced to the next depth tier.
        """
        try:
            from db_init import get_db
            conn    = get_db()
            pending = conn.execute(
                "SELECT COUNT(*) FROM queue WHERE status='pending'"
            ).fetchone()[0]

            if pending < self.MIN_QUEUE_SEED:
                # Pull mastery articles → queue their topics at Advanced depth
                rows = conn.execute(
                    """
                    SELECT topic FROM knowledge
                    WHERE depth='Mastery' AND confidence > 0.7
                    ORDER BY quality_score DESC LIMIT 30
                    """
                ).fetchall()
                conn.close()

                if rows:
                    from zeus_learner import get_learner_engine
                    engine = get_learner_engine()
                    queued = 0
                    for row in rows:
                        ok = engine.queue_topic(
                            row["topic"], depth="Advanced",
                            priority=1.5, source="improvement_loop_mastery_seed"
                        )
                        if ok:
                            queued += 1
                    if queued:
                        self._log_event(f"queue_seeded:{queued}_advanced_topics")
                        log.info(f"[ImprovementLoop] Queue seeded with {queued} advanced topics")
            else:
                conn.close()

        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage seed queue: {e}")

    def _stage_logic_refresh(self):
        """
        Feed a sample of recent knowledge into the logic engine
        so it can reason about new facts and update architectural decisions.
        """
        try:
            from db_init import get_db
            conn = get_db()
            rows = conn.execute(
                """
                SELECT topic, domain, confidence FROM knowledge
                WHERE confidence > 0.75
                ORDER BY id DESC LIMIT 20
                """
            ).fetchall()
            conn.close()

            if not rows:
                return

            from logic_engine import get_engine as get_logic, LogicFact
            engine = get_logic()
            facts  = []
            for row in rows:
                facts.append(LogicFact(
                    predicate="zeus_knows",
                    args=(row["topic"][:80],),
                    confidence=float(row["confidence"]),
                    source="improvement_loop",
                ))
                if row["domain"]:
                    facts.append(LogicFact(
                        predicate="domain_knowledge_available",
                        args=(row["domain"],),
                        source="improvement_loop",
                    ))
            engine.reason(facts, max_depth=6, auto_learn=True)
            self._log_event(f"logic_refreshed:{len(facts)}_facts")

        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage logic refresh: {e}")

    def _stage_genome_fitness(self):
        """
        Trigger genome fitness recomputation so high-quality DNA
        rises to the top and drives better synthesis blueprints.
        """
        try:
            from genome_manager import get_genome_engine
            result = get_genome_engine().recompute_all_fitness()
            updated = result.get("updated", 0)
            if updated:
                self._stats.genome_updates += updated
                self._log_event(f"genome_fitness_updated:{updated}")
        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage genome fitness: {e}")

    def _stage_prediction_scan(self):
        """
        Every 10 cycles, trigger prediction engine to build a fresh
        improvement roadmap and feed the top improvements back to
        the evolution engine and mutator.
        """
        try:
            if self._stats.cycles_complete % 10 != 0:
                return  # Only run every 10 cycles

            from zeus_prediction_engine import SystemStateScanner
            snap = SystemStateScanner().scan()

            # Feed bottlenecks as mutation seeds so Zeus learns about gaps
            if snap.capability_gaps:
                from zeus_mutator import get_engine as get_mutator
                seeds = [
                    {"topic": f"Zeus architecture gap: {g}",
                     "priority": 2.0, "depth": "Professional"}
                    for g in snap.capability_gaps[:10]
                ]
                get_mutator().mutate(seeds, source="prediction_gap_seed", use_ai=False)
                self._log_event(f"prediction_gaps_seeded:{len(seeds)}")

        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage prediction: {e}")

    # ------------------------------------------------------------------ #
    # EVENT LOG                                                            #
    # ------------------------------------------------------------------ #

    def _stage_hive_sync(self):
        """
        Stage 8 — Hive sync.
        Publishes Zeus's current intelligence state to the collective memory so
        UMP and Aegis always have a fresh picture of Zeus's knowledge and genome.
        Every 5 cycles also pulls the latest mining intelligence from UMP and
        seeds it into the Zeus learner queue.
        """
        try:
            import sys as _sys
            import os as _os
            merged_dir = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
            if merged_dir not in _sys.path:
                _sys.path.insert(0, merged_dir)
            from zeus_hive_bridge import _hive

            # Push current Zeus state to collective memory
            zeus_update = {
                "cycles_complete": self._stats.cycles_complete,
            }
            try:
                from db_init import get_db
                conn = get_db()
                kc = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()
                gc = conn.execute("SELECT COUNT(*) FROM genome").fetchone()
                conn.close()
                zeus_update["knowledge_count"] = kc[0] if kc else 0
                zeus_update["genome_count"]    = gc[0] if gc else 0
            except Exception:
                pass

            _hive.update_zeus_state(zeus_update)
            _hive.publish("zeus", "improvement_cycle", {
                "cycle":     self._stats.cycles_complete,
                "knowledge": zeus_update.get("knowledge_count", 0),
                "genomes":   zeus_update.get("genome_count",    0),
            })

            # Every 5 cycles: pull mining intelligence and feed to learner
            if self._stats.cycles_complete % 5 == 0:
                mining_history = _hive.get_mining_history(hours=1)
                if mining_history:
                    try:
                        from zeus_learner import get_learner_engine
                        engine = get_learner_engine()
                        latest = mining_history[0]
                        coin   = latest.get("coin", "")
                        if coin:
                            topic   = "live_mining:{}".format(coin)
                            content = (
                                "Live mining data for {}:\n"
                                "Hashrate: {} H/s | Price: ${} | Daily: ${}\n"
                                "Pool: {} | Algorithm: {} | Nodes: {}\n"
                            ).format(
                                coin,
                                latest.get("hashrate",   0),
                                latest.get("price_usd",  0),
                                latest.get("daily_usd",  0),
                                latest.get("pool_url",   ""),
                                latest.get("algo",       ""),
                                latest.get("node_count", 1),
                            )
                            engine.queue_topic(topic, content)
                    except Exception:
                        pass

        except Exception as e:
            log.debug(f"[ImprovementLoop] Stage hive_sync: {e}")

    def _log_event(self, event: str):
        with self._lock:
            self._event_log.append({
                "ts":    datetime.now(timezone.utc).isoformat(),
                "event": event,
            })

    def run_single_cycle(self) -> Dict:
        """Run one improvement cycle synchronously (for API trigger)."""
        t0 = time.time()
        try:
            self._run_cycle()
            return {
                "status":   "ok",
                "duration_ms": round((time.time() - t0) * 1000, 1),
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}


# ============================================================================
# SINGLETON
# ============================================================================

_loop_lock:   threading.RLock              = threading.RLock()
_loop_instance: Optional[ImprovementLoopEngine] = None


def get_loop_engine() -> ImprovementLoopEngine:
    global _loop_instance
    with _loop_lock:
        if _loop_instance is None:
            _loop_instance = ImprovementLoopEngine()
        return _loop_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@improvement_bp.route("/api/improvement/health", methods=["GET"])
def improvement_health():
    engine = get_loop_engine()
    return jsonify({
        "status":   "ok",
        "module":   "zeus_improvement_loop",
        "version":  "1.0",
        "running":  engine.is_running(),
        "cycles":   engine._stats.cycles_complete,
    })


@improvement_bp.route("/api/improvement/stats", methods=["GET"])
def improvement_stats():
    try:
        return jsonify(get_loop_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@improvement_bp.route("/api/improvement/start", methods=["POST"])
def improvement_start():
    return jsonify(get_loop_engine().start())


@improvement_bp.route("/api/improvement/stop", methods=["POST"])
def improvement_stop():
    return jsonify(get_loop_engine().stop())


@improvement_bp.route("/api/improvement/trigger", methods=["POST"])
def improvement_trigger():
    """Trigger one full improvement cycle synchronously."""
    try:
        result = get_loop_engine().run_single_cycle()
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@improvement_bp.route("/api/improvement/events", methods=["GET"])
def improvement_events():
    limit = int(request.args.get("limit", 50))
    try:
        return jsonify({
            "events": get_loop_engine().event_log(limit),
            "total":  len(get_loop_engine()._event_log),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@improvement_bp.route("/api/improvement/loop_diagram", methods=["GET"])
def improvement_loop_diagram():
    """
    Returns a human-readable description of the improvement loop
    data flow so operators can understand what Zeus is doing.
    """
    return jsonify({
        "loop": "Continuous Self-Improvement Loop",
        "flow": [
            {"stage": 1, "name": "Knowledge Ingestion",
             "module": "zeus_upload + zeus_search",
             "action": "Files uploaded → DNA extracted → genome + knowledge populated",
             "endpoint": "POST /api/upload | POST /api/search"},
            {"stage": 2, "name": "5-Depth Learning",
             "module": "zeus_learner",
             "action": "Queue topics processed at Simple→Mastery depth tiers",
             "endpoint": "POST /api/learner/learn | GET /api/learner/stats"},
            {"stage": 3, "name": "Bulk Queue Processing",
             "module": "zeus_recursive_learner",
             "action": "High-throughput 32-worker queue drain, zero LLM",
             "endpoint": "POST /api/recursive_learner/fast"},
            {"stage": 4, "name": "Code Intelligence",
             "module": "zeus_code_learner",
             "action": "AST + Halstead + call-graph mastery on all Zeus .py files",
             "endpoint": "POST /api/code_learner/start | GET /api/code_learner/intelligence"},
            {"stage": 5, "name": "Knowledge Mutation",
             "module": "zeus_mutator",
             "action": "Mastery articles → 8 subtopics per article → re-queued",
             "endpoint": "POST /api/mutator/mutate | POST /api/mutator/genome/seed"},
            {"stage": 6, "name": "Self-Evolution (PEL)",
             "module": "zeus_self_evolution",
             "action": "AST audit → gap fill → sandbox validate → safe merge → genome register",
             "endpoint": "GET /api/evolution/status | POST /api/evolution/permanent/start"},
            {"stage": 7, "name": "Genome Fitness",
             "module": "genome_manager",
             "action": "Fitness scored DNA ordered by quality → synthesis candidates surfaced",
             "endpoint": "POST /api/genome/manager/fitness/all | GET /api/genome/manager/synthesis_candidates"},
            {"stage": 8, "name": "Logic Architecture",
             "module": "logic_engine",
             "action": "New facts → forward-chain inference → synthesis blueprints generated",
             "endpoint": "POST /api/logic/reason | POST /api/logic/plan"},
            {"stage": 9, "name": "Code Synthesis",
             "module": "zeus_synthesis + zeus_forge",
             "action": "Blueprint → DNA retrieve → architect → code → validate → package",
             "endpoint": "POST /api/synthesis/synthesize | POST /api/forge/generate"},
            {"stage": 10, "name": "APK Build",
             "module": "zeus_apk_builder_core + zeus_apk_engine",
             "action": "Validated code → real Android APKs → DNA re-extracted → loop",
             "endpoint": "POST /api/apk/core/build | POST /api/apk/analyse"},
            {"stage": 11, "name": "DB Feedback",
             "module": "db_init (zeus.db)",
             "action": "New genome segments + knowledge articles → loop restarts at stage 2",
             "endpoint": "Automatic — no API call required"},
        ],
        "continuous_loop": True,
        "auto_starts_at": "boot + 5s",
        "cycle_interval_s": ImprovementLoopEngine.CYCLE_INTERVAL_S,
        "pel_auto_start_delay_s": 3,
        "loop_status": "/api/improvement/stats",
    })


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(improvement_bp)
    log.info("[improvement_loop] ✓ Registered at /api/improvement")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_improvement_loop",
            blueprint_var="improvement_bp",
            url_prefix="/api/improvement",
            version="1.0",
            description=(
                "Continuous improvement loop orchestrator: "
                "knowledge → learner → code_learner → mutator → "
                "evolution → genome → synthesis → forge → APK → ∞"
            ),
            capabilities=[
                {"id": "improvement.health",      "endpoint": "/api/improvement/health",      "method": "GET",  "tags": ["health"]},
                {"id": "improvement.stats",       "endpoint": "/api/improvement/stats",       "method": "GET",  "tags": ["stats", "loop"]},
                {"id": "improvement.start",       "endpoint": "/api/improvement/start",       "method": "POST", "tags": ["loop"]},
                {"id": "improvement.stop",        "endpoint": "/api/improvement/stop",        "method": "POST", "tags": ["loop"]},
                {"id": "improvement.trigger",     "endpoint": "/api/improvement/trigger",     "method": "POST", "tags": ["loop"]},
                {"id": "improvement.events",      "endpoint": "/api/improvement/events",      "method": "GET",  "tags": ["loop", "history"]},
                {"id": "improvement.loop_diagram","endpoint": "/api/improvement/loop_diagram","method": "GET",  "tags": ["docs"]},
            ],
            depends_on=[
                "zeus_learner", "zeus_recursive_learner", "zeus_code_learner",
                "zeus_mutator", "genome_manager", "zeus_self_evolution",
                "logic_engine", "zeus_synthesis", "zeus_forge",
                "zeus_apk_builder_core", "zeus_apk_engine", "zeus_prediction_engine",
            ],
            boot_order=99,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    import logging as _logging
    _logging.basicConfig(level=_logging.DEBUG)
    _app = _Flask(__name__)
    _app.register_blueprint(improvement_bp)
    engine = get_loop_engine()
    engine.start()
    _app.run(host="0.0.0.0", port=5099, debug=True, use_reloader=False)
