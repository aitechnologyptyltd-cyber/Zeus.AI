# The Zeus Project 2026 — Francois Nel
# zeus_nightly_scheduler.py — Nightly Evolution Scheduler
# APScheduler · Multi-job pipeline · Evolution + Mutation + Fitness + Index rebuild
# Missed-job detection · Health watchdog · Manual trigger API · Full audit log

import os
import sys
import time
import json
import uuid
import logging
import threading
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.scheduler")

scheduler_bp = Blueprint("scheduler", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================================
# SCHEDULED JOB DEFINITIONS
# ============================================================================

@dataclass
class ScheduledJob:
    """A single scheduled job definition."""
    job_id:      str
    name:        str
    cron_hour:   int
    cron_minute: int
    fn_name:     str          # name of function to call
    enabled:     bool = True
    priority:    int  = 5     # higher = runs first within same window
    timeout_s:   int  = 600
    last_run_at: str  = ""
    last_status: str  = ""
    run_count:   int  = 0
    fail_count:  int  = 0
    description: str  = ""

    def to_dict(self) -> Dict:
        return asdict(self)


# Default nightly job schedule (all times are local server time)
DEFAULT_JOBS = [
    ScheduledJob("nightly_evolution",     "Self-Evolution Cycle",       0,  5,  "_job_evolution",    priority=10, timeout_s=600),
    ScheduledJob("nightly_mutation",      "Knowledge Mutation Pass",    0,  20, "_job_mutation",      priority=8,  timeout_s=300),
    ScheduledJob("nightly_fitness",       "Genome Fitness Recompute",   0,  35, "_job_fitness",       priority=6,  timeout_s=300),
    ScheduledJob("nightly_semantic_idx",  "Semantic Index Rebuild",     0,  45, "_job_semantic_idx",  priority=7,  timeout_s=120),
    ScheduledJob("nightly_db_cleanup",    "DB Cleanup & Vacuum",        1,  0,  "_job_db_cleanup",    priority=4,  timeout_s=180),
    ScheduledJob("nightly_queue_purge",   "Stale Queue Purge",          1,  10, "_job_queue_purge",   priority=5,  timeout_s=60),
    ScheduledJob("nightly_health_report", "Health Snapshot",            1,  20, "_job_health_report", priority=3,  timeout_s=60),
    ScheduledJob("hourly_queue_runner",   "Learner Queue Flush",        -1, -1, "_job_queue_runner",  priority=9,  timeout_s=120,
                 description="Runs every hour, not nightly"),
    ScheduledJob("hive_intelligence",     "Hive Intelligence Report",    2,  0,  "_job_hive_intelligence", priority=8, timeout_s=120,
                 description="Generate collective market predictions from mining+wallet+threat data"),
    ScheduledJob("hive_repair_scan",      "Hive Cross-System Repair",    2, 30,  "_job_hive_repair",       priority=7, timeout_s=300,
                 description="Zeus scans UMP and Aegis for gaps and dispatches fixes"),
    ScheduledJob("hive_mining_learn",     "Learn from Mining Data",      3,  0,  "_job_hive_mining_learn", priority=6, timeout_s=180,
                 description="Ingest last 24h of collective mining intelligence into Zeus knowledge base"),
    ScheduledJob("nightly_stress_test",  "Autonomous Stress Test",      3,  30, "_job_stress_test",       priority=9, timeout_s=600,
                 description="Run full autonomous stress test on all 4 systems — feeds gaps into evolution queue"),
]


# ============================================================================
# JOB IMPLEMENTATIONS
# ============================================================================

def _job_evolution() -> Dict:
    """Run a full self-evolution cycle."""
    try:
        from zeus_self_evolution import run_evolution_cycle
        report = run_evolution_cycle()
        return {
            "status":     report.get("status", "unknown"),
            "merges_ok":  report.get("merges_ok", 0),
            "gaps_filled": report.get("gaps_filled", 0),
            "duration_s": report.get("duration_s", 0),
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_mutation() -> Dict:
    """Run a knowledge mutation pass on all pending genome seeds."""
    try:
        from zeus_mutator import get_engine as get_mutator
        from db_init import get_db
        conn   = get_db()
        # Get top priority pending knowledge as mutation seeds
        rows   = conn.execute(
            """
            SELECT topic FROM knowledge
            ORDER BY confidence DESC, id DESC LIMIT 20
            """
        ).fetchall()
        conn.close()
        seeds  = [{"topic": r["topic"], "priority": 1.0, "depth": "Simple"} for r in rows]
        if not seeds:
            return {"status": "ok", "queued": 0, "reason": "no knowledge seeds"}
        mutator = get_mutator()
        result  = mutator.mutate(seeds, source="nightly_scheduler", use_ai=True)
        return {"status": "ok", "queued": result.get("total_queued", 0),
                "seeds": len(seeds), "fast_topics": result.get("fast_topics", 0)}
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_fitness() -> Dict:
    """Recompute fitness for all genome segments."""
    try:
        from genome_manager import get_genome_engine
        engine = get_genome_engine()
        result = engine.recompute_all_fitness()
        return {
            "status":    "ok",
            "processed": result.get("processed", 0),
            "errors":    result.get("errors", 0),
            "top_elite": result.get("top_elite", [])[:3],
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_semantic_idx() -> Dict:
    """Rebuild the logic engine semantic (TF-IDF) index."""
    try:
        from logic_engine import get_engine
        engine = get_engine()
        engine._semantic_idx.rebuild_from_db()
        return {"status": "ok", "message": "Semantic index rebuilt"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_db_cleanup() -> Dict:
    """Clean up stale records and vacuum the DB."""
    try:
        from db_init import get_db
        conn = get_db()
        # Remove chat history older than 7 days
        conn.execute(
            "DELETE FROM chat_history WHERE created_at < datetime('now', '-7 days')"
        )
        chat_deleted = conn.total_changes
        # Remove failed executor jobs older than 48 hours
        conn.execute(
            "DELETE FROM executor_jobs WHERE status IN ('failed','cancelled') "
            "AND submitted_at < datetime('now', '-2 days')"
        )
        jobs_deleted = conn.total_changes
        # Remove done executor jobs older than 24 hours
        conn.execute(
            "DELETE FROM executor_jobs WHERE status='done' "
            "AND completed_at < datetime('now', '-1 day')"
        )
        done_deleted = conn.total_changes
        conn.commit()
        # WAL checkpoint
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        conn.close()
        return {
            "status":       "ok",
            "chat_deleted": chat_deleted,
            "jobs_deleted": jobs_deleted + done_deleted,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_queue_purge() -> Dict:
    """Remove stale and exhausted queue items."""
    try:
        from db_init import get_db
        conn = get_db()
        # Remove failed items that have exhausted all attempts
        conn.execute(
            "DELETE FROM queue WHERE status='failed' AND attempts >= max_attempts "
            "AND updated_at < datetime('now', '-3 days')"
        )
        failed_deleted = conn.total_changes
        # Remove done items older than 1 day
        conn.execute(
            "DELETE FROM queue WHERE status='done' "
            "AND updated_at < datetime('now', '-1 day')"
        )
        done_deleted = conn.total_changes
        conn.commit()
        pending = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='pending'"
        ).fetchone()[0]
        conn.close()
        return {
            "status":         "ok",
            "failed_deleted": failed_deleted,
            "done_deleted":   done_deleted,
            "pending_remaining": pending,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_queue_runner() -> Dict:
    """Flush the highest-priority pending queue items through the learner."""
    try:
        from zeus_learner import get_learner_engine
        learner = get_learner_engine()
        result  = learner.run_batch(batch_size=20)
        return {"status": "ok", "processed": result.get("processed", 0),
                "learned": result.get("learned", 0)}
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_hive_intelligence() -> Dict:
    """
    Generate full hive intelligence report from collective mining + wallet + threat data.
    Stores predictions in collective DB and pushes best-coin recommendation to UMP.
    """
    try:
        import sys, os
        merged_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if merged_dir not in sys.path:
            sys.path.insert(0, merged_dir)
        from zeus_hive_bridge import _prediction_engine, _hive
        report = _prediction_engine.generate_hive_intelligence_report()
        ranked = report.get("coin_opportunities", [])
        _hive.publish("zeus", "nightly_intelligence_report", {
            "coins_ranked": len(ranked),
            "best_coin":    ranked[0]["coin"] if ranked else "",
            "intel_score":  report.get("hive_intelligence", 0.0),
        })
        return {
            "status":          "ok",
            "coins_analyzed":  len(ranked),
            "best_coin":       ranked[0]["coin"] if ranked else "",
            "intelligence":    report.get("hive_intelligence", 0.0),
            "threat_level":    report.get("recommendations", {}).get("threat_level", ""),
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_hive_repair() -> Dict:
    """
    Zeus scans all three systems for gaps and dispatches patches via hive exchange.
    Checks UMP modules for missing functions, Aegis for stale rule sets.
    """
    dispatched = []
    errors = []

    # Zeus self-evolution scan — gaps in UMP modules
    try:
        from zeus_self_evolution import run_evolution_cycle
        report = run_evolution_cycle()
        gaps = report.get("gaps", [])
        ump_targets = {
            "miner_swarm.py", "ump_profit_switcher.py",
            "ump_miner_registry.py", "ump_hardware_detect.py",
        }
        import sys, os
        merged_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if merged_dir not in sys.path:
            sys.path.insert(0, merged_dir)
        from zeus_hive_bridge import _repair_dispatcher
        for gap in gaps:
            fname = gap.get("module_file", "")
            fix   = gap.get("suggested_fix", "")
            if fname in ump_targets and fix and len(fix) > 20:
                result = _repair_dispatcher.dispatch_ump_repair(
                    fname, fix, gap.get("gap_desc", "")
                )
                dispatched.append({"file": fname, "file_id": result.get("file_id", "")})
    except Exception as e:
        errors.append("evolution_scan: {}".format(str(e)))

    # Check Aegis defense rating — if below 80, request evolution
    try:
        from zeus_hive_bridge import _hive
        dr = _hive.live_state.get("aegis", {}).get("defense_rating", 100.0)
        if dr < 80.0:
            _hive.publish("zeus", "aegis_low_defense_alert", {
                "defense_rating": dr,
                "action": "requesting_evolution_pass",
            })
    except Exception as e:
        errors.append("aegis_check: {}".format(str(e)))

    return {
        "status":     "ok" if not errors else "partial",
        "dispatched": len(dispatched),
        "patches":    dispatched,
        "errors":     errors,
    }


def _job_hive_mining_learn() -> Dict:
    """
    Ingest last 24 hours of collective mining intelligence into Zeus knowledge base.
    Makes Zeus learn from hashrate trends, coin switches, and profit patterns.
    """
    learned = 0
    errors  = []

    try:
        import sys, os
        merged_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if merged_dir not in sys.path:
            sys.path.insert(0, merged_dir)
        from zeus_hive_bridge import _hive
        history = _hive.get_mining_history(hours=24)

        if not history:
            return {"status": "ok", "learned": 0, "note": "no_mining_history"}

        # Group by coin and build learning articles
        from collections import defaultdict
        by_coin = defaultdict(list)
        for row in history:
            by_coin[row.get("coin", "unknown")].append(row)

        from zeus_learner import get_learner_engine
        engine = get_learner_engine()

        for coin, rows in by_coin.items():
            if not coin:
                continue
            hashrates = [r.get("hashrate", 0) for r in rows if r.get("hashrate", 0) > 0]
            daily_vals = [r.get("daily_usd", 0) for r in rows if r.get("daily_usd", 0) > 0]
            prices     = [r.get("price_usd", 0) for r in rows if r.get("price_usd", 0) > 0]

            avg_hr    = sum(hashrates)  / max(len(hashrates), 1)
            avg_daily = sum(daily_vals) / max(len(daily_vals), 1)
            avg_price = sum(prices)     / max(len(prices), 1)
            hr_trend  = ((hashrates[0] - hashrates[-1]) / max(hashrates[-1], 1.0)
                         if len(hashrates) >= 2 else 0.0)

            content = (
                "Mining intelligence for {coin} over last 24 hours:\n"
                "Average hashrate: {avg_hr:.2f} H/s\n"
                "Average daily earnings: ${avg_daily:.4f} USD\n"
                "Average price: ${avg_price:.6f} USD\n"
                "Hashrate trend: {trend:+.2f}% (positive = growing)\n"
                "Data points: {count}\n"
                "Pool: {pool}\n"
                "Algorithm: {algo}\n"
                "Analysis: {trend_label} hashrate trend suggests "
                "{market_note} for {coin}.\n"
            ).format(
                coin=coin,
                avg_hr=avg_hr,
                avg_daily=avg_daily,
                avg_price=avg_price,
                trend=hr_trend * 100,
                count=len(rows),
                pool=rows[0].get("pool_url", "unknown"),
                algo=rows[0].get("algo", "unknown"),
                trend_label="Rising" if hr_trend > 0.05 else "Falling" if hr_trend < -0.05 else "Stable",
                market_note=(
                    "increasing miner investment, often a bullish signal"
                    if hr_trend > 0.05 else
                    "miners leaving the network, often precedes price correction"
                    if hr_trend < -0.05 else
                    "stable network conditions"
                ),
            )

            try:
                engine.queue_topic(
                    "mining_intelligence:{}_24h".format(coin),
                    content
                )
                learned += 1
            except Exception as exc:
                errors.append("queue_{}: {}".format(coin, str(exc)))

        # Also learn from threat correlations
        threats = _hive.get_threat_history(hours=24)
        if threats:
            threat_content = (
                "Security threat intelligence over last 24 hours:\n"
                "Total threats detected: {total}\n"
                "Top categories: {cats}\n"
                "Mining-relevant threats: {mining}\n"
                "This data should inform risk scoring for mining operations.\n"
            ).format(
                total=len(threats),
                cats=", ".join(set(t.get("category", "") for t in threats[:20])),
                mining=sum(1 for t in threats
                           if t.get("category", "") in
                           {"MALWARE", "INJECTION", "CMD/SHELL", "ZERO-DAY"}),
            )
            try:
                engine.queue_topic("security_threat_intelligence_24h", threat_content)
                learned += 1
            except Exception as exc:
                errors.append("queue_threats: {}".format(str(exc)))

    except Exception as e:
        errors.append("hive_mining_learn: {}".format(str(e)))

    return {
        "status":  "ok" if not errors else "partial",
        "learned": learned,
        "errors":  errors,
    }



def _job_stress_test() -> Dict:
    """Run full autonomous stress test on all 4 systems. Feeds gaps into evolution queue."""
    try:
        import sys, os
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if root not in sys.path:
            sys.path.insert(0, root)
        from zeus_stress_engine import run_stress_suite, feed_gaps_to_evolution, apply_quick_fixes
        rpt     = run_stress_suite("all")
        queued  = feed_gaps_to_evolution(rpt)
        fixes   = apply_quick_fixes(rpt)
        return {
            "status":        "ok",
            "run_id":        rpt.run_id,
            "total_tests":   rpt.total_tests,
            "overall_score": rpt.overall_score,
            "gaps":          rpt.gaps,
            "failed":        rpt.failed,
            "gaps_queued":   queued,
            "quick_fixes":   fixes,
            "system_scores": rpt.system_scores,
            "layer_scores":  rpt.layer_scores,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _job_health_report() -> Dict:
    report = {}
    try:
        from db_init import db_health
        report["db"] = db_health()
    except Exception as e:
        report["db"] = {"error": str(e)}
    try:
        from genome_manager import get_genome_engine
        report["genome"] = get_genome_engine().stats()
    except Exception as e:
        report["genome"] = {"error": str(e)}
    try:
        from zeus_mutator import get_engine as get_mutator
        report["mutator"] = get_mutator().status()
    except Exception as e:
        report["mutator"] = {"error": str(e)}
    try:
        from zeus_llm_router import get_router
        report["llm"] = get_router().stats()
    except Exception as e:
        report["llm"] = {"error": str(e)}
    # Persist to evolution_log table
    try:
        from db_init import get_db
        conn = get_db()
        conn.execute(
            """
            INSERT OR IGNORE INTO evolution_log
                (cycle_id, trigger, status, report_json, started_at, completed_at)
            VALUES (?, 'health_report', 'done', ?, datetime('now'), datetime('now'))
            """,
            (uuid.uuid4().hex[:12], json.dumps(report, default=str)[:5000])
        )
        conn.commit()
        conn.close()
    except Exception:
        pass
    return {"status": "ok", "report": report}


# All job implementations in a registry
_JOB_RUNNERS: Dict[str, Callable[[], Dict]] = {
    "_job_evolution":     _job_evolution,
    "_job_mutation":      _job_mutation,
    "_job_fitness":       _job_fitness,
    "_job_semantic_idx":  _job_semantic_idx,
    "_job_db_cleanup":    _job_db_cleanup,
    "_job_queue_purge":   _job_queue_purge,
    "_job_queue_runner":  _job_queue_runner,
    "_job_health_report": _job_health_report,
    "_job_hive_intelligence": _job_hive_intelligence,
    "_job_hive_repair":       _job_hive_repair,
    "_job_hive_mining_learn": _job_hive_mining_learn,
    "_job_stress_test":       _job_stress_test,
}


# ============================================================================
# RUN RECORD
# ============================================================================

@dataclass
class RunRecord:
    run_id:     str
    job_id:     str
    job_name:   str
    trigger:    str       # scheduled | manual | missed
    started_at: str
    completed_at: str = ""
    status:     str   = "running"
    result:     Dict  = field(default_factory=dict)
    duration_s: float = 0.0
    error:      str   = ""

    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# SCHEDULER ENGINE (SINGLETON)
# ============================================================================

class SchedulerEngine:
    """
    Multi-job nightly scheduler built on APScheduler.
    Falls back to a pure-threading implementation if APScheduler is not installed.

    Features:
    - Nightly jobs at configurable cron times
    - Hourly queue flush
    - Missed-job detection and catch-up
    - Manual trigger per job or full nightly sweep
    - Full run history and audit log
    - Health watchdog that checks Zeus subsystems every 15 minutes
    """

    def __init__(self):
        self._lock            = threading.RLock()
        self._scheduler       = None
        self._running         = False
        self._jobs:           Dict[str, ScheduledJob] = {
            j.job_id: j for j in DEFAULT_JOBS
        }
        self._run_history:    deque = deque(maxlen=500)
        self._currently_running: Dict[str, str] = {}   # job_id → run_id
        self._watchdog_thread: Optional[threading.Thread] = None
        self._hourly_thread:   Optional[threading.Thread] = None

    # ---- Public API ------------------------------------------------------

    def start(self) -> bool:
        """Start the scheduler. Returns True on success."""
        with self._lock:
            if self._running:
                log.info("[Scheduler] Already running")
                return True

        success = self._start_apscheduler()
        if not success:
            success = self._start_threaded_fallback()

        if success:
            with self._lock:
                self._running = True
            self._start_watchdog()
            self._start_hourly_runner()
            log.info("[Scheduler] Started successfully")
        return success

    def stop(self) -> None:
        with self._lock:
            self._running = False
        if self._scheduler:
            try:
                self._scheduler.shutdown(wait=False)
            except Exception:
                pass
        log.info("[Scheduler] Stopped")

    def trigger_job(self, job_id: str, manual: bool = True) -> Dict:
        """Manually trigger a specific job by ID."""
        job = self._jobs.get(job_id)
        if not job:
            return {"error": f"Unknown job: {job_id}"}
        return self._run_job(job, trigger="manual" if manual else "scheduled")

    def trigger_nightly_sweep(self) -> Dict:
        """Trigger all nightly jobs in priority order."""
        jobs_sorted = sorted(
            [j for j in self._jobs.values() if j.enabled and j.cron_hour >= 0],
            key=lambda j: -j.priority
        )
        results = {}
        for job in jobs_sorted:
            results[job.job_id] = self._run_job(job, trigger="manual_sweep")
        return {
            "status": "ok",
            "jobs_run": len(results),
            "results": results,
        }

    def get_job(self, job_id: str) -> Optional[Dict]:
        job = self._jobs.get(job_id)
        return job.to_dict() if job else None

    def list_jobs(self) -> List[Dict]:
        with self._lock:
            return [j.to_dict() for j in sorted(self._jobs.values(), key=lambda j: -j.priority)]

    def get_history(self, job_id: str = "", limit: int = 50) -> List[Dict]:
        with self._lock:
            history = list(self._run_history)
        if job_id:
            history = [r for r in history if r.job_id == job_id]
        history = history[-limit:]
        return [r.to_dict() for r in reversed(history)]

    def enable_job(self, job_id: str, enabled: bool) -> Dict:
        job = self._jobs.get(job_id)
        if not job:
            return {"error": f"Unknown job: {job_id}"}
        job.enabled = enabled
        return {"status": "ok", "job_id": job_id, "enabled": enabled}

    def stats(self) -> Dict:
        with self._lock:
            total_runs   = sum(j.run_count  for j in self._jobs.values())
            total_fails  = sum(j.fail_count for j in self._jobs.values())
            return {
                "running":         self._running,
                "scheduler_type":  "apscheduler" if self._scheduler else "threaded",
                "total_jobs":      len(self._jobs),
                "enabled_jobs":    sum(1 for j in self._jobs.values() if j.enabled),
                "total_runs":      total_runs,
                "total_fails":     total_fails,
                "success_rate":    round((total_runs - total_fails) / max(total_runs, 1), 4),
                "history_entries": len(self._run_history),
                "currently_running": dict(self._currently_running),
            }

    # ---- Internal --------------------------------------------------------

    def _run_job(self, job: ScheduledJob, trigger: str = "scheduled") -> Dict:
        """Execute a job synchronously. Updates job state and appends to history."""
        run_id  = uuid.uuid4().hex[:12]
        started = datetime.now(timezone.utc).isoformat()
        runner  = _JOB_RUNNERS.get(job.fn_name)

        with self._lock:
            self._currently_running[job.job_id] = run_id

        log.info(f"[Scheduler] Starting '{job.name}' (trigger={trigger})")
        t0 = time.time()

        if not runner:
            result  = {"status": "error", "error": f"No runner: {job.fn_name}"}
            success = False
        else:
            try:
                result  = runner()
                success = result.get("status") not in ("error", "failed")
            except Exception as e:
                result  = {"status": "error", "error": str(e)}
                success = False

        duration = round(time.time() - t0, 2)
        completed = datetime.now(timezone.utc).isoformat()

        rec = RunRecord(
            run_id=run_id, job_id=job.job_id, job_name=job.name,
            trigger=trigger, started_at=started, completed_at=completed,
            status="done" if success else "failed",
            result=result, duration_s=duration,
            error=result.get("error", "") if not success else "",
        )

        with self._lock:
            self._run_history.append(rec)
            self._currently_running.pop(job.job_id, None)
            job.last_run_at = completed
            job.last_status = "done" if success else "failed"
            job.run_count  += 1
            if not success:
                job.fail_count += 1

        log.info(
            f"[Scheduler] '{job.name}' {'✓' if success else '✗'} "
            f"in {duration}s"
        )
        return {"status": rec.status, "run_id": run_id, "duration_s": duration, "result": result}

    def _nightly_callback(self) -> None:
        """Called at 00:05 by APScheduler or threaded scheduler."""
        log.info("[Scheduler] Nightly sweep starting...")
        now_hour   = datetime.now().hour
        now_minute = datetime.now().minute

        for job in sorted(self._jobs.values(), key=lambda j: -j.priority):
            if not job.enabled or job.cron_hour < 0:
                continue
            # Run jobs scheduled in the next 30-minute window
            job_minutes = job.cron_hour * 60 + job.cron_minute
            now_minutes = now_hour * 60 + now_minute
            if abs(job_minutes - now_minutes) <= 30:
                threading.Thread(
                    target=self._run_job, args=(job, "scheduled"),
                    daemon=True, name=f"sched_{job.job_id}"
                ).start()
                time.sleep(2)   # stagger starts

    def _start_apscheduler(self) -> bool:
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            self._scheduler = BackgroundScheduler()
            # Main nightly sweep at 00:05
            self._scheduler.add_job(
                self._nightly_callback, "cron",
                hour=0, minute=5,
                id="nightly_main",
                replace_existing=True,
                max_instances=1,
                misfire_grace_time=300,
            )
            # Hourly queue runner at :30 of each hour
            self._scheduler.add_job(
                lambda: self._run_job(self._jobs.get("hourly_queue_runner",
                    ScheduledJob("hourly_queue_runner","Queue Flush",-1,-1,"_job_queue_runner")),
                    "hourly"),
                "cron", minute=30, id="hourly_queue",
                replace_existing=True, max_instances=1,
            )
            self._scheduler.start()
            log.info("[Scheduler] APScheduler started — nightly 00:05, hourly :30")
            return True
        except ImportError:
            log.warning("[Scheduler] APScheduler not installed — using threaded fallback")
            return False
        except Exception as e:
            log.error(f"[Scheduler] APScheduler failed: {e}")
            return False

    def _start_threaded_fallback(self) -> bool:
        """Pure Python threaded scheduler — no external dependencies."""
        def _loop():
            log.info("[Scheduler] Threaded fallback loop started")
            while self._running:
                now = datetime.now()
                h, m = now.hour, now.minute
                # Nightly window: 00:00–00:30
                if h == 0 and 0 <= m < 30:
                    self._nightly_callback()
                    # Sleep until clear of the window
                    time.sleep(31 * 60)
                    continue
                # Hourly queue runner
                if m == 30:
                    hourly_job = self._jobs.get("hourly_queue_runner")
                    if hourly_job and hourly_job.enabled:
                        threading.Thread(
                            target=self._run_job, args=(hourly_job, "hourly"),
                            daemon=True
                        ).start()
                    time.sleep(60)
                    continue
                time.sleep(30)

        t = threading.Thread(target=_loop, name="scheduler_fallback", daemon=True)
        t.start()
        log.info("[Scheduler] Threaded fallback started")
        return True

    def _start_watchdog(self) -> None:
        """Health watchdog — checks Zeus subsystems every 15 minutes."""
        def _watchdog():
            while self._running:
                time.sleep(15 * 60)
                self._watchdog_check()

        self._watchdog_thread = threading.Thread(
            target=_watchdog, name="scheduler_watchdog", daemon=True
        )
        self._watchdog_thread.start()

    def _watchdog_check(self) -> None:
        """Check key Zeus subsystems and log health."""
        checks = {}
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute("SELECT 1")
            conn.close()
            checks["db"] = "ok"
        except Exception as e:
            checks["db"] = f"error: {e}"
            log.error(f"[Scheduler:Watchdog] DB check failed: {e}")

        try:
            from logic_engine import get_engine
            e = get_engine()
            checks["logic_engine"] = "ok" if e._ready else "not_ready"
        except Exception as e:
            checks["logic_engine"] = f"error: {e}"

        try:
            from zeus_mutator import get_engine as get_mutator
            status = get_mutator().status()
            checks["mutator"] = "ok" if "error" not in status else f"error: {status}"
        except Exception as e:
            checks["mutator"] = f"error: {e}"

        log.info(f"[Scheduler:Watchdog] {checks}")

    def _start_hourly_runner(self) -> None:
        """Start a dedicated hourly learner queue runner thread."""
        def _hourly_loop():
            while self._running:
                time.sleep(3600)
                hourly_job = self._jobs.get("hourly_queue_runner")
                if hourly_job and hourly_job.enabled:
                    self._run_job(hourly_job, trigger="hourly")

        self._hourly_thread = threading.Thread(
            target=_hourly_loop, name="scheduler_hourly", daemon=True
        )
        self._hourly_thread.start()


# ============================================================================
# SINGLETON
# ============================================================================

_sched_lock:     threading.RLock          = threading.RLock()
_sched_instance: Optional[SchedulerEngine] = None


def get_scheduler() -> SchedulerEngine:
    global _sched_instance
    with _sched_lock:
        if _sched_instance is None:
            _sched_instance = SchedulerEngine()
        return _sched_instance


def start_scheduler() -> None:
    """Start the scheduler. Called from register(app)."""
    get_scheduler().start()


# ============================================================================
# FLASK ROUTES
# ============================================================================

@scheduler_bp.route("/api/scheduler/health", methods=["GET"])
def scheduler_health():
    s = get_scheduler()
    return jsonify({
        "status":  "ok",
        "module":  "zeus_nightly_scheduler",
        "version": "2.0",
        "running": s._running,
        "jobs":    len(s._jobs),
    })


@scheduler_bp.route("/api/scheduler/stats", methods=["GET"])
def scheduler_stats():
    try:
        return jsonify(get_scheduler().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@scheduler_bp.route("/api/scheduler/jobs", methods=["GET"])
def scheduler_jobs():
    try:
        return jsonify({"jobs": get_scheduler().list_jobs()})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@scheduler_bp.route("/api/scheduler/trigger/<job_id>", methods=["POST"])
def scheduler_trigger(job_id: str):
    """Manually trigger a specific job."""
    try:
        result = get_scheduler().trigger_job(job_id, manual=True)
        code   = 200 if "error" not in result else 400
        return jsonify(result), code
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@scheduler_bp.route("/api/scheduler/trigger_all", methods=["POST"])
def scheduler_trigger_all():
    """Trigger the full nightly sweep manually."""
    try:
        def _bg():
            get_scheduler().trigger_nightly_sweep()
        threading.Thread(target=_bg, daemon=True).start()
        return jsonify({"status": "ok", "message": "Nightly sweep triggered in background"})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@scheduler_bp.route("/api/scheduler/history", methods=["GET"])
def scheduler_history():
    job_id = request.args.get("job_id", "")
    limit  = int(request.args.get("limit", 50))
    try:
        return jsonify({
            "history": get_scheduler().get_history(job_id=job_id, limit=limit),
            "total":   len(get_scheduler()._run_history),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@scheduler_bp.route("/api/scheduler/enable", methods=["POST"])
def scheduler_enable():
    """POST { "job_id": str, "enabled": bool }"""
    data    = request.get_json(force=True, silent=True) or {}
    job_id  = data.get("job_id", "")
    enabled = bool(data.get("enabled", True))
    if not job_id:
        return jsonify({"error": "job_id required"}), 400
    return jsonify(get_scheduler().enable_job(job_id, enabled))


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(scheduler_bp)
    log.info("[scheduler] ✓ Registered at /api/scheduler")
    start_scheduler()
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_nightly_scheduler",
            blueprint_var="scheduler_bp",
            url_prefix="/api/scheduler",
            version="2.0",
            description="Multi-job nightly scheduler: evolution, mutation, fitness, index rebuild, DB cleanup, health watchdog",
            capabilities=[
                {"id": "scheduler.health",      "endpoint": "/api/scheduler/health",      "method": "GET",  "tags": ["health"]},
                {"id": "scheduler.stats",        "endpoint": "/api/scheduler/stats",       "method": "GET",  "tags": ["stats"]},
                {"id": "scheduler.jobs",         "endpoint": "/api/scheduler/jobs",        "method": "GET",  "tags": ["scheduler"]},
                {"id": "scheduler.trigger",      "endpoint": "/api/scheduler/trigger",     "method": "POST", "tags": ["scheduler", "trigger"]},
                {"id": "scheduler.trigger_all",  "endpoint": "/api/scheduler/trigger_all", "method": "POST", "tags": ["scheduler", "trigger"]},
                {"id": "scheduler.history",      "endpoint": "/api/scheduler/history",     "method": "GET",  "tags": ["scheduler", "history"]},
            ],
            depends_on=["zeus_self_evolution", "zeus_mutator", "genome_manager", "logic_engine"],
            boot_order=90,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5016, debug=True, use_reloader=False)
