#!/bin/bash
# The Zeus Project 2026 — Francois Nel
# start_zeus.sh — Clean boot script for Zeus v4.0
# Usage: bash start_zeus.sh

ZEUS_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ZEUS_DIR"

# ------------------------------------------------------------------ #
# API KEYS — replace values with your actual keys                     #
# ------------------------------------------------------------------ #
export GROQ_API_KEY="your-groq-api-key-here"
export ANTHROPIC_API_KEY="your-anthropic-api-key-here"
export OPENROUTER_API_KEY="your-openrouter-api-key-here"
export XAI_API_KEY="your-xai-api-key-here"

# ------------------------------------------------------------------ #
# MODEL CONFIG                                                         #
# ------------------------------------------------------------------ #
export GROQ_MODEL="llama-3.3-70b-versatile"
export LLM_MODEL="claude-sonnet-4-6"
export GOOGLE_API_KEY=""
export GOOGLE_CSE_ID=""

# ------------------------------------------------------------------ #
# SETUP                                                                #
# ------------------------------------------------------------------ #
mkdir -p logs uploads evolved_modules backups reports genome exports \
         migration_packages replication_packages children splice_archive \
         splice_quarantine generated_code models blueprints data strategies

echo "============================================================"
echo "  ZEUS v4.0 — THE ZEUS PROJECT 2026"
echo "  Architect: Francois Nel · South Africa"
echo "  Dir: $ZEUS_DIR"
echo "============================================================"

# ------------------------------------------------------------------ #
# STOP EXISTING PROCESSES                                              #
# ------------------------------------------------------------------ #
echo "[*] Stopping existing Zeus processes..."
pkill -f "python3.*app.py"           2>/dev/null
pkill -f "zeus_nightly_scheduler"    2>/dev/null
pkill -f "zeus_recursive_learner"    2>/dev/null
pkill -f "zeus_auto_repair"          2>/dev/null
sleep 2

# ------------------------------------------------------------------ #
# INIT DATABASE                                                        #
# ------------------------------------------------------------------ #
echo "[*] Initialising database..."
python3 db_init.py

# ------------------------------------------------------------------ #
# START ZEUS                                                           #
# ------------------------------------------------------------------ #
echo "[*] Starting Zeus..."
nohup python3 app.py > logs/zeus.log 2>&1 &
ZEUS_PID=$!
echo "[ok] Zeus PID: $ZEUS_PID"

# Wait for Flask to come up
echo "[*] Waiting for Flask..."
for i in {1..15}; do
    sleep 1
    if curl -s http://localhost:5000/api/health > /dev/null 2>&1; then
        echo "[ok] Zeus is online"
        break
    fi
    if [ $i -eq 15 ]; then
        echo "[!!] Zeus did not come up in 15s — check logs/zeus.log"
        tail -20 logs/zeus.log
        exit 1
    fi
done

# Show health
echo ""
curl -s http://localhost:5000/api/health | python3 -m json.tool
echo ""

# ------------------------------------------------------------------ #
# START NIGHTLY EVOLUTION SCHEDULER                                    #
# ------------------------------------------------------------------ #
if [ -f "zeus_nightly_scheduler.py" ]; then
    pkill -f zeus_nightly_scheduler 2>/dev/null
    sleep 1
    nohup python3 zeus_nightly_scheduler.py > logs/scheduler.log 2>&1 &
    echo "[ok] Nightly scheduler started (PID: $!)"
else
    echo "[--] zeus_nightly_scheduler.py not found — skipping"
fi

# ------------------------------------------------------------------ #
# START LEARNER SCHEDULER                                              #
# ------------------------------------------------------------------ #
sleep 3
if curl -s -X POST http://localhost:5000/api/learner/scheduler/start > /dev/null 2>&1; then
    echo "[ok] Learner scheduler started"
fi

# ------------------------------------------------------------------ #
# START RECURSIVE SELF-LEARNER                                         #
# ------------------------------------------------------------------ #
if [ -f "zeus_recursive_learner.py" ]; then
    pkill -f zeus_recursive_learner 2>/dev/null
    sleep 1
    nohup python3 zeus_recursive_learner.py >> logs/recursive_learner.log 2>&1 &
    echo "[ok] Recursive learner started (PID: $!)"
else
    echo "[--] zeus_recursive_learner.py not found — skipping"
fi

# ------------------------------------------------------------------ #
# START AUTO-REPAIR WATCHDOG                                           #
# ------------------------------------------------------------------ #
if [ -f "zeus_auto_repair.py" ]; then
    nohup python3 zeus_auto_repair.py --watch > /dev/null 2>&1 &
    echo "[ok] Auto-repair watchdog started (PID: $!)"
fi

echo ""
echo "============================================================"
echo "  Zeus is running at http://localhost:5000"
echo "  Dashboard:  http://localhost:5000/"
echo "  Learning:   http://localhost:5000/learning"
echo "  Health:     http://localhost:5000/api/health"
echo "  Logs:       tail -f logs/zeus.log"
echo "============================================================"
