# The Zeus Project 2026 — Francois Nel
# app.py — Zeus v4.0 Core Flask Application
# ============================================================
# Clean 6-layer architecture:
#   LAYER 0  CORE         — identity · logic · llm routing · blueprints
#   LAYER 1  DATA         — upload · search · learners · code_learner · prediction
#   LAYER 2  EVOLUTION    — mutator · genome · self_evolution · synthesis
#   LAYER 3  EXECUTION    — executor · sandbox · forge
#   LAYER 4  SPECIALIZED  — apk pipeline · replication
#   LAYER 5  PRESENTATION — dashboard · chat · scheduler · improvement loop
# ============================================================
# Blueprints registered explicitly. No dynamic scanning. No auto-repair.
# logic_engine is registered via its register(app) function because
# its Blueprint routes use relative paths + url_prefix="/api/logic".
# All other modules use absolute route paths and register via _register().

import os
import sys
import logging
from datetime import datetime, timezone
from flask import Flask, jsonify, request
from db_init import init_db, get_db

# ------------------------------------------------------------------ #
# ENVIRONMENT                                                          #
# ------------------------------------------------------------------ #
ZEUS_DIR          = os.path.dirname(os.path.abspath(__file__))
PORT              = int(os.environ.get("PORT", 8080))
GROQ_API_KEY      = os.environ.get("GROQ_API_KEY", "")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
OPENROUTER_API_KEY= os.environ.get("OPENROUTER_API_KEY", "")
XAI_API_KEY       = os.environ.get("XAI_API_KEY", "")
GROQ_MODEL        = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
LLM_MODEL         = os.environ.get("LLM_MODEL",  "claude-sonnet-4-6")

os.makedirs(os.path.join(ZEUS_DIR, "logs"),    exist_ok=True)
os.makedirs(os.path.join(ZEUS_DIR, "uploads"), exist_ok=True)

# ------------------------------------------------------------------ #
# LOGGING                                                              #
# ------------------------------------------------------------------ #
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(name)s — %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            os.path.join(ZEUS_DIR, "logs", "zeus.log"), encoding="utf-8"
        ),
    ],
)
log = logging.getLogger("zeus.core")

# ------------------------------------------------------------------ #
# DATABASE                                                             #
# ------------------------------------------------------------------ #
init_db()

# ------------------------------------------------------------------ #
# FLASK APP                                                            #
# ------------------------------------------------------------------ #
app = Flask(
    __name__,
    static_folder="static",
    template_folder="templates",
)
app.config["SECRET_KEY"]         = os.environ.get("SECRET_KEY", "zeus2026")
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024  # 100 MB

# ------------------------------------------------------------------ #
# BLUEPRINT LOADERS                                                    #
# ------------------------------------------------------------------ #

def _register(module_name: str, bp_name: str) -> bool:
    """
    Register a blueprint by attribute name.
    Use this for modules whose route decorators already include full
    /api/... paths (i.e. no url_prefix needed on register).
    Warns on failure, never crashes.
    """
    try:
        mod = __import__(module_name, fromlist=[bp_name])
        app.register_blueprint(getattr(mod, bp_name))
        log.info(f"[ok] {module_name}:{bp_name}")
        return True
    except ImportError as e:
        log.warning(f"[--] {module_name} not installed: {e}")
        return False
    except Exception as e:
        log.error(f"[!!] {module_name}:{bp_name} failed: {e}")
        return False


def _register_fn(module_name: str) -> bool:
    """
    Register a module using its register(app) function.
    Use this for modules that set url_prefix inside register()
    (e.g. logic_engine which mounts at url_prefix='/api/logic').
    Warns on failure, never crashes.
    """
    try:
        mod = __import__(module_name)
        mod.register(app)
        log.info(f"[ok] {module_name}:register()")
        return True
    except ImportError as e:
        log.warning(f"[--] {module_name} not installed: {e}")
        return False
    except Exception as e:
        log.error(f"[!!] {module_name}:register() failed: {e}")
        return False


_loaded = 0

# ================================================================== #
# LAYER 0 — CORE                                                       #
# Identity · Logic Engine · LLM Routing · Intelligent Router          #
# Grok Bridge · Blueprint Engine                                       #
# ================================================================== #

# zeus_identity — module capability registry and system fingerprint
_loaded += _register("zeus_identity",           "identity_bp")

# logic_engine — uses url_prefix="/api/logic" inside register()
# Routes mount at /api/logic/health, /api/logic/plan, /api/logic/reason …
_loaded += _register_fn("logic_engine")

# LLM routing stack — circuit breaker, multi-engine fallback
# NOTE: zeus_llm_router exclusively owns /api/llm/status — do not duplicate.
_loaded += _register("zeus_llm_router",          "llm_bp")
_loaded += _register("zeus_intelligent_router",  "intelligent_router_bp")
_loaded += _register("zeus_grok_bridge",         "bridge_bp")

# Blueprint engine — logic synthesis + forge pipeline
_loaded += _register("zeus_blueprints",          "blueprints_bp")

# ================================================================== #
# LAYER 1 — DATA & LEARNING                                            #
# Upload · Search · Learner · Recursive Learner                        #
# Code Learner · Logic Engine · Prediction Engine                      #
# ================================================================== #

# Universal file upload → DNA splicing into genome + knowledge + mutator
_loaded += _register("zeus_upload",              "upload_bp")

# Unified search: DuckDuckGo + knowledge base + harvest engine
_loaded += _register("zeus_search",              "search_bp")

# 5-depth learning engine: Simple → Advanced → Professional → Complex → Mastery
_loaded += _register("zeus_learner",             "learner_bp")

# Bulk recursive learner — 32-worker fast path, zero LLM
_loaded += _register("zeus_recursive_learner",   "recursive_bp")

# *** CODE INTELLIGENCE LAYER ***
# zeus_code_learner: real AST + Halstead + call-graph + taint analysis
# Feeds zeus_self_evolution with mastery-weighted improvement targets
# CRITICAL for the continuous improvement loop — must be registered
_loaded += _register("zeus_code_learner",        "code_learner_bp")

# Prediction engine — scans entire system, generates improvement roadmap
_loaded += _register("zeus_prediction_engine",   "prediction_bp")

# ================================================================== #
# LAYER 2 — EVOLUTION & SYNTHESIS                                      #
# Mutator · Genome Manager · Self-Evolution · Synthesis                #
# ================================================================== #

# Knowledge mutation engine — topic → 8 subtopics → infinite queue growth
_loaded += _register("zeus_mutator",             "mutator_bp")

# Genome manager — DNA CRUD, fitness scoring, lineage, mutation history
# File is genome_manager.py; routes already include /api/genome/manager/*
_loaded += _register("genome_manager",           "genome_bp")

# Self-evolution v3.0 — AST audit → mastery-aware gap fill → safe merge
# Includes the Permanent Evolution Loop (PEL) that auto-starts 3s after boot
_loaded += _register("zeus_self_evolution",      "evolution_bp")

# Synthesis engine — FastAPI proxied through Flask Blueprint
# Runs on internal port SYNTHESIS_PORT (default 8846)
_loaded += _register("zeus_synthesis",           "synthesis_bp")

# ================================================================== #
# LAYER 3 — EXECUTION                                                  #
# Executor · Sandbox · Forge                                           #
# ================================================================== #

# Persistent task queue — priority scheduling, 8 workers, full audit trail
_loaded += _register("zeus_executor",            "executor_bp")

# Sandbox — AST validation, process isolation, output capture
_loaded += _register("zeus_sandbox",             "sandbox_bp")

# Forge — knowledge-aware code generation: Plan→Blueprint→DNA→Code→Validate
_loaded += _register("zeus_forge",               "forge_bp")

# ================================================================== #
# LAYER 4 — SPECIALIZED                                                #
# APK Builder Core · APK Engine · APK Export · Replication            #
# ================================================================== #

# Offline APK builder — pulls DNA from genome, generates real APKs
_loaded += _register("zeus_apk_builder_core",    "apk_core_bp")

# APK decompile + DNA extraction — Smali patterns → genome + knowledge
_loaded += _register("zeus_apk_engine",          "apk_engine_bp")

# APK export — package forge output for Android deployment
_loaded += _register("zeus_apk_export",          "apk_export_bp")

# Replication engine — creates offline-capable Zeus offspring instances
_loaded += _register("zeus_replication_engine",  "replication_bp")

# ================================================================== #
# LAYER 5 — PRESENTATION & SCHEDULING                                  #
# Dashboard · Chat · Nightly Scheduler · Improvement Loop             #
# ================================================================== #

# Live dark-UI dashboard — tabs, logs, blueprints, forge, downloads
_loaded += _register("zeus_learning_dashboard",  "learning_bp")

# Zeus intelligence chat engine — Groq→Claude→OpenRouter with genome context
_loaded += _register("zeus_chat",                "chat_bp")

# Nightly evolution scheduler — APScheduler multi-job pipeline
_loaded += _register("zeus_nightly_scheduler",   "scheduler_bp")

# *** CONTINUOUS IMPROVEMENT LOOP ORCHESTRATOR ***
# Wires all layers into a self-reinforcing improvement cycle:
# knowledge → code_learner → genome → evolution → synthesis → apk → ∞
_loaded += _register("zeus_improvement_loop",    "improvement_bp")

# LAYER 6+  STRESS TESTING
_loaded += _register("zeus_stress_engine",        "stress_bp")

log.info(f"[boot] {_loaded} blueprints loaded across 6 layers")

# ------------------------------------------------------------------ #
# CORE ROUTES                                                          #
# ------------------------------------------------------------------ #

@app.route("/")
def index():
    return jsonify({
        "name":      "Zeus v4.0",
        "project":   "The Zeus Project 2026",
        "architect": "Francois Nel",
        "location":  "South Africa",
        "device":    "Hisense Y82 Pro",
        "status":    "online",
        "started":   datetime.now(timezone.utc).isoformat(),
        "modules":   _loaded,
        "architecture": {
            "layer_0_core":        ["zeus_identity", "logic_engine", "zeus_llm_router",
                                    "zeus_intelligent_router", "zeus_grok_bridge", "zeus_blueprints"],
            "layer_1_data":        ["zeus_upload", "zeus_search", "zeus_learner",
                                    "zeus_recursive_learner", "zeus_code_learner", "zeus_prediction_engine"],
            "layer_2_evolution":   ["zeus_mutator", "genome_manager",
                                    "zeus_self_evolution", "zeus_synthesis"],
            "layer_3_execution":   ["zeus_executor", "zeus_sandbox", "zeus_forge"],
            "layer_4_specialized": ["zeus_apk_builder_core", "zeus_apk_engine",
                                    "zeus_apk_export", "zeus_replication_engine"],
            "layer_5_presentation":["zeus_learning_dashboard", "zeus_chat",
                                    "zeus_nightly_scheduler", "zeus_improvement_loop"],
        },
        "improvement_loop": "/api/improvement/loop_diagram",
    })


@app.route("/api/health")
def health():
    try:
        conn            = get_db()
        genome_count    = conn.execute("SELECT COUNT(*) FROM genome").fetchone()[0]
        knowledge_count = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
        queue_pending   = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='pending'"
        ).fetchone()[0]
        conn.close()
        db_ok = True
    except Exception as e:
        genome_count = knowledge_count = queue_pending = 0
        db_ok = False
        log.error(f"Health DB error: {e}")

    return jsonify({
        "status":          "ok",
        "version":         "v4.0",
        "modules_loaded":  _loaded,
        "genome_segments": genome_count,
        "knowledge":       knowledge_count,
        "queue_pending":   queue_pending,
        "db":              "ok" if db_ok else "error",
        "engines": {
            "groq":       "configured" if GROQ_API_KEY       else "missing",
            "claude":     "configured" if ANTHROPIC_API_KEY  else "missing",
            "openrouter": "configured" if OPENROUTER_API_KEY else "missing",
            "xai":        "configured" if XAI_API_KEY        else "missing",
        },
        "architect": "Francois Nel",
        "project":   "The Zeus Project 2026",
    })


# /api/llm/status is fully owned by zeus_llm_router (llm_bp).
# Use GET /api/llm/status for full circuit-breaker + availability detail.


# ------------------------------------------------------------------ #
# GENOME — core direct routes                                          #
# (Full manager API at /api/genome/manager/* via genome_bp)           #
# ------------------------------------------------------------------ #

@app.route("/api/genome")
def genome_list_core():
    """Core genome list. Full API at /api/genome/manager/list"""
    try:
        conn = get_db()
        rows = conn.execute(
            "SELECT * FROM genome ORDER BY priority DESC"
        ).fetchall()
        conn.close()
        return jsonify({"genomes": [dict(r) for r in rows], "count": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/genome/add", methods=["POST"])
def genome_add_core():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    try:
        conn = get_db()
        conn.execute("""
            INSERT OR IGNORE INTO genome
                (name, description, module_type, source_code, version, priority, capabilities)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            name,
            data.get("description", ""),
            data.get("type", data.get("module_type", "cognitive")),
            data.get("source_code", ""),
            data.get("version", "v1.0"),
            int(data.get("priority", 50)),
            data.get("capabilities", ""),
        ))
        conn.commit()
        conn.close()
        return jsonify({"status": "ok", "name": name})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ------------------------------------------------------------------ #
# KNOWLEDGE — core direct routes                                       #
# ------------------------------------------------------------------ #

@app.route("/api/knowledge")
def knowledge_list():
    try:
        conn  = get_db()
        limit = int(request.args.get("limit", 50))
        topic = request.args.get("topic", "")
        if topic:
            rows = conn.execute(
                "SELECT * FROM knowledge WHERE topic LIKE ? ORDER BY id DESC LIMIT ?",
                (f"%{topic}%", limit)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM knowledge ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        conn.close()
        return jsonify({"articles": [dict(r) for r in rows], "count": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/knowledge/count")
def knowledge_count():
    try:
        conn  = get_db()
        count = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
        conn.close()
        return jsonify({"count": count})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ------------------------------------------------------------------ #
# LEARNER — core status (dashboard-compatible)                         #
# Full learner stats at /api/learner/stats via learner_bp             #
# ------------------------------------------------------------------ #

@app.route("/api/learner/status")
def learner_status():
    """
    Dashboard-compatible learner status.
    Returns both flat keys AND a nested 'queue' dict so both the
    dashboard JS and other modules get what they expect.
    """
    try:
        conn    = get_db()
        pending = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='pending'"
        ).fetchone()[0]
        done    = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='done'"
        ).fetchone()[0]
        failed  = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='failed'"
        ).fetchone()[0]
        running = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='running'"
        ).fetchone()[0]
        conn.close()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    # Try to read scheduler state from the learner engine
    scheduler_running = False
    try:
        from zeus_learner import get_learner_engine
        scheduler_running = get_learner_engine().stats().get("scheduler", False)
    except Exception:
        pass

    return jsonify({
        # Flat keys (backward compat)
        "pending":           pending,
        "done":              done,
        "failed":            failed,
        "total":             pending + done + failed + running,
        "scheduler_running": scheduler_running,
        # Nested queue dict (dashboard JS reads d.queue.pending etc.)
        "queue": {
            "pending": pending,
            "done":    done,
            "failed":  failed,
            "running": running,
        },
    })


# ------------------------------------------------------------------ #
# RECURSIVE LEARNER — health proxy                                     #
# (zeus_recursive_learner has no /health route of its own)            #
# ------------------------------------------------------------------ #

@app.route("/api/recursive_learner/health", methods=["GET"])
def recursive_learner_health():
    """Health proxy for zeus_recursive_learner (which has no /health route)."""
    try:
        from zeus_recursive_learner import count_queue, WORKERS, BATCH_SIZE
        counts = count_queue()
        return jsonify({
            "status":     "ok",
            "module":     "zeus_recursive_learner",
            "version":    "2.0",
            "workers":    WORKERS,
            "batch_size": BATCH_SIZE,
            "queue":      counts,
        })
    except Exception as e:
        return jsonify({"status": "ok", "module": "zeus_recursive_learner", "error": str(e)})


# ------------------------------------------------------------------ #
# LOGIC ENGINE — health proxy                                          #
# logic_engine routes are at /api/logic/* via url_prefix              #
# This alias confirms the mount point                                  #
# ------------------------------------------------------------------ #

@app.route("/api/logic_status", methods=["GET"])
def logic_engine_status():
    """Quick logic engine status check (full API at /api/logic/health)."""
    try:
        from logic_engine import get_engine
        engine = get_engine()
        return jsonify({
            "status":  "ok",
            "module":  "logic_engine",
            "mounted": "/api/logic",
            "routes":  ["/api/logic/health", "/api/logic/stats", "/api/logic/plan",
                        "/api/logic/reason", "/api/logic/convert", "/api/logic/learn",
                        "/api/logic/meta", "/api/logic/self_modify", "/api/logic/taxonomy",
                        "/api/logic/arch_knowledge"],
        })
    except Exception as e:
        return jsonify({"status": "degraded", "module": "logic_engine", "error": str(e)})


# ------------------------------------------------------------------ #
# ERROR HANDLERS                                                       #
# ------------------------------------------------------------------ #

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "route not found", "status": 404}), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "internal server error", "status": 500}), 500


# ------------------------------------------------------------------ #
# CONTINUOUS IMPROVEMENT LOOP BOOT                                     #
# Starts 5 seconds after Flask is ready so all blueprints are loaded  #
# ------------------------------------------------------------------ #

def _boot_improvement_loop():
    """
    Boot the continuous improvement loop.
    Called 5 seconds after Zeus starts.

    Flow:
      DB (knowledge + genome)
        → zeus_learner scheduler        ← already auto-starts
        → zeus_recursive_learner bulk   ← started via /api/recursive_learner/fast
        → zeus_code_learner scanner     ← analyzes Zeus .py modules
        → zeus_mutator seeds            ← generates topic trees from mastery articles
        → zeus_self_evolution PEL       ← auto-starts 3s after registration
        → genome_manager fitness        ← fitness-scored DNA ready for synthesis
        → zeus_synthesis / zeus_forge   ← generates code from DNA blueprints
        → zeus_apk_builder + apk_engine ← real APKs built, DNA re-extracted
        → DB (genome + knowledge)       ← loop back, system gets smarter
    """
    import time, threading

    def _boot():
        time.sleep(5)
        log.info("[boot] ═══ Activating Continuous Improvement Loop ═══")

        # 1. Ensure learner scheduler is running (it auto-starts via singleton)
        try:
            from zeus_learner import get_learner_engine
            get_learner_engine().start_scheduler()
            log.info("[boot] ✓ Learner scheduler active")
        except Exception as e:
            log.warning(f"[boot] Learner scheduler: {e}")

        # 2. Start improvement loop orchestrator
        try:
            from zeus_improvement_loop import get_loop_engine
            get_loop_engine().start()
            log.info("[boot] ✓ Improvement loop orchestrator started")
        except Exception as e:
            log.warning(f"[boot] Improvement loop: {e}")

        # 3. Seed mutator from genome so knowledge expands from first boot
        try:
            from db_init import get_db
            conn  = get_db()
            rows  = conn.execute(
                "SELECT name FROM genome ORDER BY priority DESC LIMIT 25"
            ).fetchall()
            conn.close()
            if rows:
                from zeus_mutator import get_engine as get_mutator
                seeds = [{"topic": r["name"], "priority": 1.0, "depth": "Simple"}
                         for r in rows]
                get_mutator().mutate(seeds, source="boot_genome_seed", use_ai=False)
                log.info(f"[boot] ✓ Genome seeds injected: {len(seeds)} topics")
        except Exception as e:
            log.warning(f"[boot] Genome seed: {e}")

        # 4. Verify prediction engine schema
        try:
            from zeus_prediction_engine import _bootstrap_schema
            _bootstrap_schema()
            log.info("[boot] ✓ Prediction engine schema verified")
        except Exception as e:
            log.warning(f"[boot] Prediction bootstrap: {e}")

        # 5. Start code learner background scan
        try:
            from zeus_code_learner import get_code_learner
            learner = get_code_learner()
            if not learner.is_running():
                learner.start()
                log.info("[boot] ✓ Code intelligence scan started")
        except Exception as e:
            log.warning(f"[boot] Code learner: {e}")

        log.info("[boot] ═══ Continuous Improvement Loop ACTIVE ═══")
        log.info("[boot]   Knowledge → Learner → CodeLearner → Mutator")
        log.info("[boot]   → Evolution → Genome → Synthesis → Forge → APK → ∞")

    threading.Thread(target=_boot, daemon=True, name="zeus_boot_loop").start()


# ------------------------------------------------------------------ #
# BOOT                                                                 #
# ------------------------------------------------------------------ #

if __name__ == "__main__":
    log.info("=" * 60)
    log.info("  ZEUS v4.0 — THE ZEUS PROJECT 2026")
    log.info(f"  Architect: Francois Nel · South Africa · Hisense Y82 Pro")
    log.info(f"  Started:   {datetime.now(timezone.utc).isoformat()}")
    log.info(f"  Modules:   {_loaded} across 6 layers")
    log.info("=" * 60)
    _boot_improvement_loop()
    app.run(
        host="0.0.0.0",
        port=PORT,
        debug=False,
        use_reloader=False,
        threaded=True,
    )
