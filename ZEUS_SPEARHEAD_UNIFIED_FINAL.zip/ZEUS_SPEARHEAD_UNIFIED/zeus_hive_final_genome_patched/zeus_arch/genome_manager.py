# The Zeus Project 2026 — Francois Nel
# genome_manager.py — Zeus Genome CRUD + DNA Search + Fitness Tracking
# Full lineage tracking · Mutation history · Logic engine integration
# Fitness scoring · Capability extraction · Genome merge/splice API

import os
import re
import json
import time
import uuid
import math
import logging
import hashlib
import threading
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.genome")

genome_bp = Blueprint("genome_manager", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))


# ============================================================================
# GENOME DATA STRUCTURES
# ============================================================================

@dataclass
class GenomeSegment:
    """
    A single genome segment — the fundamental unit of Zeus DNA.
    Each segment represents a learned capability, pattern, or knowledge crystal.
    """
    genome_id:       str
    name:            str
    description:     str
    module_type:     str
    source_code:     str
    version:         str
    priority:        int
    capabilities:    str               # comma-separated capability tags
    lineage:         str               # parent genome_id chain
    fitness_score:   float
    mutation_count:  int
    created_at:      str
    updated_at:      str

    def capability_list(self) -> List[str]:
        return [c.strip() for c in self.capabilities.split(",") if c.strip()]

    def fitness_class(self) -> str:
        if self.fitness_score >= 0.85:   return "elite"
        elif self.fitness_score >= 0.70: return "high"
        elif self.fitness_score >= 0.50: return "medium"
        elif self.fitness_score >= 0.30: return "low"
        else:                            return "weak"

    def fingerprint(self) -> str:
        """SHA256 fingerprint of name + version + source_code[:500]."""
        src = f"{self.name}:{self.version}:{self.source_code[:500]}"
        return hashlib.sha256(src.encode()).hexdigest()[:16]

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["capability_list"] = self.capability_list()
        d["fitness_class"]   = self.fitness_class()
        d["fingerprint"]     = self.fingerprint()
        return d


@dataclass
class MutationRecord:
    """Records a single mutation event applied to a genome segment."""
    mutation_id:  str
    parent_name:  str
    child_name:   str
    mutation_type: str    # expand | splice | merge | prune | reinforce
    delta_fitness: float  # positive = improvement
    applied_at:   str
    source:       str     # mutator | forge | evolution | user
    notes:        str     = ""


@dataclass
class FitnessMetrics:
    """Multi-dimensional fitness evaluation for a genome segment."""
    genome_name:     str
    code_quality:    float = 0.0    # AST complexity, comment density
    capability_depth: float = 0.0   # number and specificity of capabilities
    usage_frequency: float = 0.0    # how often this segment is accessed
    mutation_success: float = 0.0   # ratio of successful mutations
    knowledge_density: float = 0.0  # knowledge entries linked to this genome
    recency:         float = 0.0    # age penalty (older = slightly lower)
    overall:         float = 0.0

    @classmethod
    def compute(cls, segment: GenomeSegment, usage_count: int = 0,
                 knowledge_count: int = 0) -> "FitnessMetrics":
        fm = cls(genome_name=segment.name)

        # Code quality: source code length + comment ratio
        code   = segment.source_code or ""
        lines  = code.splitlines()
        n_lines = max(len(lines), 1)
        comments = sum(1 for l in lines if re.match(r'\s*(#|//)', l))
        comment_density = comments / n_lines
        code_score  = min(1.0, len(code) / 3000) * 0.5 + min(comment_density / 0.15, 1.0) * 0.5
        fm.code_quality = round(code_score, 4)

        # Capability depth
        caps = segment.capability_list()
        cap_score = min(len(caps) / 10.0, 1.0)
        fm.capability_depth = round(cap_score, 4)

        # Usage frequency
        fm.usage_frequency = round(min(usage_count / 100.0, 1.0), 4)

        # Mutation success (lower mutation count with high priority = good)
        mut_score = 1.0 - min(segment.mutation_count / 50.0, 1.0) * 0.3
        fm.mutation_success = round(mut_score, 4)

        # Knowledge density
        fm.knowledge_density = round(min(knowledge_count / 20.0, 1.0), 4)

        # Recency (decay over 30 days)
        try:
            ts = datetime.fromisoformat(segment.created_at.replace("Z", "+00:00"))
            age_days = (datetime.now(timezone.utc) - ts).days
        except Exception:
            age_days = 0
        fm.recency = round(max(0.0, 1.0 - age_days / 90.0), 4)

        # Overall weighted average
        fm.overall = round(
            fm.code_quality     * 0.20 +
            fm.capability_depth * 0.25 +
            fm.usage_frequency  * 0.15 +
            fm.mutation_success * 0.15 +
            fm.knowledge_density* 0.15 +
            fm.recency          * 0.10,
            4
        )
        return fm


# ============================================================================
# GENOME ENGINE (SINGLETON)
# ============================================================================

class GenomeEngine:
    """
    Full genome management engine.
    Provides: CRUD, search, fitness scoring, mutation recording,
    lineage tracking, capability extraction, and logic engine integration.
    """

    def __init__(self):
        self._lock            = threading.RLock()
        self._usage_counts:   Dict[str, int] = defaultdict(int)
        self._mutation_log:   List[MutationRecord] = []
        self._fitness_cache:  Dict[str, FitnessMetrics] = {}
        self._fitness_ts:     Dict[str, float] = {}
        self._CACHE_TTL       = 120.0   # seconds

    # ---- DB Helpers -----------------------------------------------------

    def _db(self):
        from db_init import get_db
        return get_db()

    def _retry(self, fn, retries: int = 3) -> Any:
        from db_init import retry_db
        return retry_db(fn, retries=retries)

    # ---- CRUD -----------------------------------------------------------

    def add(self, name: str, description: str = "", module_type: str = "cognitive",
            source_code: str = "", version: str = "v1.0", priority: int = 50,
            capabilities: str = "", lineage: str = "") -> Dict:
        """Insert a new genome segment. Returns status dict."""
        name = name.strip()[:200]
        if not name:
            return {"error": "name required"}
        try:
            conn = self._db()
            conn.execute(
                """
                INSERT OR IGNORE INTO genome
                    (name, description, module_type, source_code, version,
                     priority, capabilities, lineage, fitness_score, mutation_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0.0, 0)
                """,
                (name, description[:2000], module_type, source_code,
                 version, priority, capabilities, lineage)
            )
            inserted = conn.total_changes > 0
            conn.commit()
            conn.close()
            log.info(f"[Genome] {'Added' if inserted else 'Ignored (exists)'}: {name}")

            if inserted:
                # Trigger logic engine to learn from new genome
                self._notify_logic_engine(name, description, capabilities)

            return {
                "status":   "inserted" if inserted else "exists",
                "name":     name,
                "inserted": inserted,
            }
        except Exception as e:
            return {"error": str(e)}

    def update_genome(self, name: str, **kwargs) -> Dict:
        """Update fields of an existing genome segment."""
        allowed = {
            "description", "module_type", "source_code", "version",
            "priority", "capabilities", "lineage", "fitness_score",
        }
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return {"error": "no valid fields to update"}
        updates["updated_at"] = datetime.now(timezone.utc).isoformat()
        set_clause = ", ".join(f"{k}=?" for k in updates)
        values     = list(updates.values()) + [name]
        try:
            conn = self._db()
            conn.execute(
                f"UPDATE genome SET {set_clause} WHERE name=?", values
            )
            conn.commit()
            conn.close()
            # Invalidate fitness cache
            with self._lock:
                self._fitness_cache.pop(name, None)
            return {"status": "ok", "name": name, "fields": list(updates.keys())}
        except Exception as e:
            return {"error": str(e)}

    def delete(self, name: str) -> Dict:
        """Delete a genome segment (irreversible)."""
        try:
            conn = self._db()
            conn.execute("DELETE FROM genome WHERE name=?", (name,))
            deleted = conn.total_changes
            conn.commit()
            conn.close()
            return {"status": "ok", "name": name, "deleted": deleted > 0}
        except Exception as e:
            return {"error": str(e)}

    def get(self, name: str) -> Optional[Dict]:
        """Retrieve a single genome segment by name."""
        try:
            conn = self._db()
            row  = conn.execute(
                "SELECT * FROM genome WHERE name=?", (name,)
            ).fetchone()
            conn.close()
            if row:
                self._usage_counts[name] += 1
                return dict(row)
            return None
        except Exception as e:
            log.warning(f"[Genome] get({name}): {e}")
            return None

    def list_all(self, module_type: str = "", min_priority: int = 0,
                  min_fitness: float = 0.0, search: str = "",
                  limit: int = 200, offset: int = 0) -> List[Dict]:
        """List genome segments with optional filters."""
        try:
            conn   = self._db()
            params = []
            where  = []
            if module_type:
                where.append("module_type=?"); params.append(module_type)
            if min_priority > 0:
                where.append("priority>=?"); params.append(min_priority)
            if min_fitness > 0.0:
                where.append("fitness_score>=?"); params.append(min_fitness)
            if search:
                where.append("(name LIKE ? OR description LIKE ? OR capabilities LIKE ?)")
                params += [f"%{search}%", f"%{search}%", f"%{search}%"]
            sql = "SELECT * FROM genome"
            if where:
                sql += " WHERE " + " AND ".join(where)
            sql += " ORDER BY priority DESC, fitness_score DESC LIMIT ? OFFSET ?"
            params += [limit, offset]
            rows = conn.execute(sql, params).fetchall()
            conn.close()
            return [dict(r) for r in rows]
        except Exception as e:
            log.warning(f"[Genome] list_all error: {e}")
            return []

    def search_dna(self, query: str, max_results: int = 10) -> List[Dict]:
        """Full-text search across genome fields. Returns ranked results."""
        keywords = re.findall(r'\b[a-zA-Z][a-zA-Z0-9]{2,}\b', query)[:10]
        if not keywords:
            return []
        results = []
        seen    = set()
        try:
            conn = self._db()
            for kw in keywords:
                rows = conn.execute(
                    """
                    SELECT name, description, module_type, capabilities,
                           priority, fitness_score, version
                    FROM genome
                    WHERE name LIKE ? OR description LIKE ?
                       OR capabilities LIKE ? OR source_code LIKE ?
                    ORDER BY priority DESC, fitness_score DESC
                    LIMIT 6
                    """,
                    (f"%{kw}%",) * 4
                ).fetchall()
                for row in rows:
                    if row["name"] not in seen:
                        seen.add(row["name"])
                        d = dict(row)
                        # Simple relevance: count keyword matches in description
                        text = f"{row['name']} {row['description']} {row['capabilities']}"
                        kw_hits = sum(1 for k in keywords if k.lower() in text.lower())
                        d["relevance"] = kw_hits
                        results.append(d)
                        self._usage_counts[row["name"]] += 1
            conn.close()
        except Exception as e:
            log.warning(f"[Genome] search_dna error: {e}")
        results.sort(key=lambda x: (-x.get("relevance", 0), -x.get("fitness_score", 0)))
        return results[:max_results]

    # ---- Fitness --------------------------------------------------------

    def compute_fitness(self, name: str, force: bool = False) -> Optional[FitnessMetrics]:
        """Compute and cache fitness metrics for a genome segment."""
        with self._lock:
            cached  = self._fitness_cache.get(name)
            ts      = self._fitness_ts.get(name, 0)
            if cached and not force and (time.time() - ts < self._CACHE_TTL):
                return cached
        try:
            conn = self._db()
            row  = conn.execute("SELECT * FROM genome WHERE name=?", (name,)).fetchone()
            if not row:
                conn.close()
                return None
            k_count = conn.execute(
                "SELECT COUNT(*) FROM knowledge WHERE topic LIKE ?",
                (f"%{name.replace('_',' ')}%",)
            ).fetchone()[0]
            conn.close()

            seg = GenomeSegment(
                genome_id=str(row["id"]),
                name=row["name"],
                description=row["description"] or "",
                module_type=row["module_type"] or "",
                source_code=row["source_code"] or "",
                version=row["version"] or "v1.0",
                priority=int(row["priority"] or 0),
                capabilities=row["capabilities"] or "",
                lineage=row["lineage"] or "",
                fitness_score=float(row["fitness_score"] or 0.0),
                mutation_count=int(row["mutation_count"] or 0),
                created_at=row["created_at"] or "",
                updated_at=row["updated_at"] or "",
            )
            fm = FitnessMetrics.compute(
                seg,
                usage_count=self._usage_counts.get(name, 0),
                knowledge_count=k_count,
            )
            # Persist fitness back to DB
            conn2 = self._db()
            conn2.execute(
                "UPDATE genome SET fitness_score=?, updated_at=datetime('now') WHERE name=?",
                (fm.overall, name)
            )
            conn2.commit()
            conn2.close()

            with self._lock:
                self._fitness_cache[name] = fm
                self._fitness_ts[name]    = time.time()
            return fm
        except Exception as e:
            log.warning(f"[Genome] compute_fitness({name}): {e}")
            return None

    def recompute_all_fitness(self) -> Dict:
        """Recompute fitness for all genome segments. Can be slow for large genomes."""
        try:
            conn  = self._db()
            names = [r[0] for r in conn.execute("SELECT name FROM genome").fetchall()]
            conn.close()
        except Exception as e:
            return {"error": str(e)}
        results = {"processed": 0, "errors": 0, "top_elite": []}
        for name in names:
            fm = self.compute_fitness(name, force=True)
            if fm:
                results["processed"] += 1
                if fm.overall >= 0.85:
                    results["top_elite"].append({"name": name, "fitness": fm.overall})
            else:
                results["errors"] += 1
        results["top_elite"].sort(key=lambda x: -x["fitness"])
        results["top_elite"] = results["top_elite"][:10]
        return results

    # ---- Mutation Tracking ---------------------------------------------

    def record_mutation(self, parent: str, child: str,
                         mutation_type: str, delta_fitness: float,
                         source: str = "mutator", notes: str = "") -> MutationRecord:
        """Record a mutation event in memory and increment mutation_count on parent."""
        rec = MutationRecord(
            mutation_id=uuid.uuid4().hex[:12],
            parent_name=parent,
            child_name=child,
            mutation_type=mutation_type,
            delta_fitness=round(delta_fitness, 4),
            applied_at=datetime.now(timezone.utc).isoformat(),
            source=source,
            notes=notes[:200],
        )
        with self._lock:
            self._mutation_log.append(rec)
        # Increment mutation count on parent
        try:
            conn = self._db()
            conn.execute(
                "UPDATE genome SET mutation_count=mutation_count+1 WHERE name=?",
                (parent,)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning(f"[Genome] mutation_count update failed: {e}")
        log.info(
            f"[Genome] Mutation recorded: {parent} → {child} "
            f"({mutation_type}, Δfitness={delta_fitness:+.3f})"
        )
        return rec

    def get_mutation_history(self, name: str = "",
                              limit: int = 50) -> List[Dict]:
        with self._lock:
            history = list(self._mutation_log)
        if name:
            history = [r for r in history if r.parent_name == name or r.child_name == name]
        history = history[-limit:]
        return [asdict(r) for r in reversed(history)]

    # ---- Lineage --------------------------------------------------------

    def get_lineage_chain(self, name: str) -> List[str]:
        """
        Trace the full lineage chain for a genome segment.
        Returns list from oldest ancestor to current.
        """
        try:
            conn = self._db()
            row  = conn.execute("SELECT lineage FROM genome WHERE name=?", (name,)).fetchone()
            conn.close()
            if not row or not row["lineage"]:
                return [name]
            lineage = [l.strip() for l in row["lineage"].split("→") if l.strip()]
            lineage.append(name)
            return lineage
        except Exception as e:
            log.warning(f"[Genome] get_lineage_chain({name}): {e}")
            return [name]

    def merge_genomes(self, source_name: str, target_name: str,
                       strategy: str = "union") -> Dict:
        """
        Merge two genome segments.
        strategy: union (combine capabilities) | best (keep best fitness)
        """
        src = self.get(source_name)
        tgt = self.get(target_name)
        if not src or not tgt:
            return {"error": "One or both genomes not found"}

        if strategy == "union":
            # Union of capabilities
            src_caps  = set(src.get("capabilities", "").split(","))
            tgt_caps  = set(tgt.get("capabilities", "").split(","))
            merged    = ", ".join(sorted(src_caps | tgt_caps))
            new_desc  = f"Merged from {source_name} + {target_name}. {tgt.get('description','')}"
            new_code  = (
                f"# Merged genome: {source_name} + {target_name}\n"
                f"# === Source: {source_name} ===\n"
                f"{src.get('source_code','')[:1000]}\n\n"
                f"# === Target: {target_name} ===\n"
                f"{tgt.get('source_code','')[:1000]}"
            )
            lineage   = f"{source_name}→{target_name}"
            result    = self.add(
                name=f"merged_{source_name}_{target_name[:20]}_{uuid.uuid4().hex[:6]}",
                description=new_desc,
                module_type=tgt.get("module_type", "cognitive"),
                source_code=new_code[:5000],
                capabilities=merged,
                lineage=lineage,
                priority=max(int(src.get("priority", 50)), int(tgt.get("priority", 50))),
            )
            self.record_mutation(
                parent=source_name, child=result.get("name", ""),
                mutation_type="merge", delta_fitness=0.0,
                source="merge_api",
            )
            return {"status": "ok", "merged_name": result.get("name"), "strategy": strategy}

        elif strategy == "best":
            # Keep the one with higher fitness
            if float(src.get("fitness_score", 0)) >= float(tgt.get("fitness_score", 0)):
                winner = src; loser = tgt
            else:
                winner = tgt; loser = src
            return {"status": "ok", "winner": winner["name"], "loser": loser["name"],
                    "strategy": strategy}

        return {"error": f"Unknown strategy: {strategy}"}

    # ---- Logic Engine Integration ----------------------------------------

    def _notify_logic_engine(self, name: str, description: str,
                               capabilities: str) -> None:
        """
        Notify the logic engine when a new genome segment is added.
        The logic engine can then learn from it and generate synthesis blueprints.
        """
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            caps   = [c.strip() for c in capabilities.split(",") if c.strip()]
            facts  = [
                LogicFact(predicate="genome_exists",     args=(name,),             source="genome_manager"),
                LogicFact(predicate="genome_module_type",args=(name, "cognitive"), source="genome_manager"),
            ]
            for cap in caps[:5]:
                facts.append(
                    LogicFact(predicate="has_capability", args=(name, cap), source="genome_manager")
                )
            # Trigger reasoning over the new facts
            result = engine.reason(facts, domain_filter="genome", max_depth=5, auto_learn=True)
            log.debug(
                f"[Genome] Logic engine notified for '{name}': "
                f"{len(result.conclusions)} conclusions"
            )
        except Exception as e:
            log.debug(f"[Genome] Logic engine notification skipped: {e}")

    def get_synthesis_candidates(self, min_fitness: float = 0.5) -> List[Dict]:
        """
        Returns genome segments that are good candidates for synthesis.
        Uses logic engine reasoning to select the best ones.
        """
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            rows   = self.list_all(min_fitness=min_fitness, limit=50)
            facts  = []
            for row in rows:
                if float(row.get("fitness_score", 0)) >= min_fitness:
                    facts.append(
                        LogicFact(predicate="stable_genome", args=(row["name"],),
                                  confidence=float(row.get("fitness_score", 0.5)),
                                  source="genome_manager")
                    )
                    facts.append(
                        LogicFact(predicate="knowledge_coverage", args=(row["name"], "HIGH"),
                                  source="genome_manager")
                    )
            if not facts:
                return rows[:10]
            result   = engine.reason(facts, domain_filter="synthesis", max_depth=8)
            ready    = {c.args[0] for c in result.conclusions if c.predicate == "synthesis_ready"}
            enhanced = [r for r in rows if r["name"] in ready]
            enhanced.sort(key=lambda x: -float(x.get("fitness_score", 0)))
            return enhanced or rows[:10]
        except Exception as e:
            log.debug(f"[Genome] synthesis_candidates fallback: {e}")
            return self.list_all(min_fitness=min_fitness, limit=10)

    def stats(self) -> Dict:
        """Return comprehensive genome stats."""
        try:
            conn = self._db()
            total  = conn.execute("SELECT COUNT(*) FROM genome").fetchone()[0]
            by_type= conn.execute(
                "SELECT module_type, COUNT(*) FROM genome GROUP BY module_type"
            ).fetchall()
            avg_fit = conn.execute(
                "SELECT AVG(fitness_score) FROM genome"
            ).fetchone()[0] or 0.0
            top5   = conn.execute(
                "SELECT name, fitness_score FROM genome ORDER BY fitness_score DESC LIMIT 5"
            ).fetchall()
            conn.close()
            return {
                "total_segments":   total,
                "by_type":          {r[0]: r[1] for r in by_type},
                "avg_fitness":      round(avg_fit, 4),
                "top5_fitness":     [{"name": r[0], "fitness": round(r[1], 4)} for r in top5],
                "mutations_tracked": len(self._mutation_log),
                "usage_tracked":    len(self._usage_counts),
                "fitness_cached":   len(self._fitness_cache),
            }
        except Exception as e:
            return {"error": str(e)}

    # ── Hive Export / Import ──────────────────────────────────────────────────

    def export_for_hive(self, name: str) -> Optional[Dict]:
        """
        Export a genome segment in hive-wire format.
        Includes a confidence_map that UMP uses to bias decision weights.

        The confidence_map maps capability tags to a normalised confidence score
        derived from fitness_score × priority / 100.  This is the "weight" that
        the hive shares — not neural-net floats, but capability-confidence pairs
        that seed decision logic in peer systems.

        Returns None if the genome is not found or has no source code.
        """
        seg = self.get(name)
        if not seg:
            return None
        fitness = float(seg.get("fitness_score", 0.0))
        if fitness < 0.40:
            return None   # don't broadcast weak genomes

        caps     = seg.get("capability_list", []) or []
        priority = int(seg.get("priority", 50))

        # Build capability→confidence map
        confidence_map: Dict[str, float] = {}
        for cap in caps:
            raw_conf = round(fitness * (priority / 100.0), 4)
            confidence_map[cap] = min(raw_conf, 1.0)

        fm = FitnessMetrics.compute(
            GenomeSegment(
                genome_id      = str(seg.get("id", "")),
                name           = name,
                description    = seg.get("description", ""),
                module_type    = seg.get("module_type", ""),
                source_code    = seg.get("source_code", ""),
                version        = str(seg.get("version", "1.0")),
                priority       = priority,
                capabilities   = seg.get("capabilities", ""),
                lineage        = seg.get("lineage", ""),
                fitness_score  = fitness,
                mutation_count = int(seg.get("mutation_count", 0)),
                created_at     = str(seg.get("created_at", "")),
                updated_at     = str(seg.get("updated_at", "")),
            )
        )

        return {
            "name":             name,
            "description":      seg.get("description", ""),
            "module_type":      seg.get("module_type", ""),
            "version":          str(seg.get("version", "1.0")),
            "fitness_score":    fitness,
            "fitness_class":    fm.fitness_class() if hasattr(fm, "fitness_class") else "medium",
            "priority":         priority,
            "capability_list":  caps,
            "confidence_map":   confidence_map,
            "lineage":          seg.get("lineage", ""),
            "mutation_count":   int(seg.get("mutation_count", 0)),
            # Include a short source excerpt so peer systems can learn patterns
            "source_excerpt":   (seg.get("source_code", "") or "")[:800],
            "exported_at":      datetime.now(timezone.utc).isoformat(),
        }

    def import_from_hive(self, hive_genome: Dict, source: str = "hive") -> Dict:
        """
        Import a genome segment received from a peer hive node (e.g. another Zeus instance).
        If a genome with the same name already exists, merges capabilities and takes the
        better fitness score.  If it's new, inserts it directly.

        The source_excerpt is stored as source_code so Zeus can learn from peer patterns.
        Returns a status dict with 'action': 'inserted' | 'merged' | 'skipped'.
        """
        name        = hive_genome.get("name", "")
        description = hive_genome.get("description", "")
        module_type = hive_genome.get("module_type", "cognitive")
        caps        = ", ".join(hive_genome.get("capability_list", []))
        fitness     = float(hive_genome.get("fitness_score", 0.0))
        priority    = int(hive_genome.get("priority", 50))
        lineage     = hive_genome.get("lineage", "")
        source_code = hive_genome.get("source_excerpt", "")

        if not name:
            return {"action": "skipped", "reason": "no name"}
        if fitness < 0.40:
            return {"action": "skipped", "reason": "fitness too low", "fitness": fitness}

        existing = self.get(name)
        if existing:
            # Merge: union capabilities, keep highest fitness
            old_caps = set(existing.get("capabilities", "").split(","))
            new_caps = set(caps.split(","))
            merged   = ", ".join(sorted(old_caps | new_caps - {""}))
            old_fit  = float(existing.get("fitness_score", 0.0))
            best_fit = max(old_fit, fitness)
            self.update_genome(name, capabilities=merged, fitness_score=best_fit)
            self.record_mutation(
                parent=name, child=name,
                mutation_type="reinforce",
                delta_fitness=best_fit - old_fit,
                source=f"hive_import:{source}",
            )
            return {"action": "merged", "name": name, "fitness": best_fit}
        else:
            result = self.add(
                name=name,
                description=f"[hive:{source}] {description}",
                module_type=module_type,
                source_code=source_code,
                capabilities=caps,
                lineage=lineage or f"hive:{source}",
                priority=priority,
            )
            self.update_genome(name, fitness_score=fitness)
            return {"action": "inserted", "name": name, "fitness": fitness}


# ============================================================================
# SINGLETON
# ============================================================================

_genome_lock:    threading.RLock      = threading.RLock()
_genome_instance: Optional[GenomeEngine] = None


def get_genome_engine() -> GenomeEngine:
    global _genome_instance
    with _genome_lock:
        if _genome_instance is None:
            _genome_instance = GenomeEngine()
        return _genome_instance


# Alias used by zeus_hive_bridge — keeps import uniform across the codebase
def get_genome_manager() -> GenomeEngine:
    return get_genome_engine()


# ============================================================================
# FLASK ROUTES
# ============================================================================

@genome_bp.route("/api/genome/manager/health", methods=["GET"])
def genome_health():
    return jsonify({
        "status":  "ok",
        "module":  "genome_manager",
        "version": "2.0",
        "segments": get_genome_engine().stats().get("total_segments", 0),
    })


@genome_bp.route("/api/genome/manager/stats", methods=["GET"])
def genome_stats():
    try:
        return jsonify(get_genome_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/list", methods=["GET"])
def genome_list():
    module_type  = request.args.get("type", "")
    min_priority = int(request.args.get("min_priority", 0))
    min_fitness  = float(request.args.get("min_fitness", 0.0))
    search       = request.args.get("q", "")
    limit        = int(request.args.get("limit", 200))
    offset       = int(request.args.get("offset", 0))
    try:
        rows = get_genome_engine().list_all(
            module_type=module_type, min_priority=min_priority,
            min_fitness=min_fitness, search=search,
            limit=limit, offset=offset,
        )
        return jsonify({"genomes": rows, "count": len(rows)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/get/<name>", methods=["GET"])
def genome_get(name: str):
    row = get_genome_engine().get(name)
    if not row:
        return jsonify({"error": f"Genome '{name}' not found"}), 404
    return jsonify(row)


@genome_bp.route("/api/genome/manager/add", methods=["POST"])
def genome_add():
    """
    POST {
      "name": str, "description": str, "module_type": str,
      "source_code": str, "version": str, "priority": int,
      "capabilities": str, "lineage": str
    }
    """
    data = request.get_json(force=True, silent=True) or {}
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    try:
        result = get_genome_engine().add(
            name=name,
            description=data.get("description", ""),
            module_type=data.get("module_type", data.get("type", "cognitive")),
            source_code=data.get("source_code", ""),
            version=data.get("version", "v1.0"),
            priority=int(data.get("priority", 50)),
            capabilities=data.get("capabilities", ""),
            lineage=data.get("lineage", ""),
        )
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/update/<name>", methods=["PUT", "POST"])
def genome_update(name: str):
    data = request.get_json(force=True, silent=True) or {}
    try:
        result = get_genome_engine().update_genome(name, **data)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/delete/<name>", methods=["DELETE", "POST"])
def genome_delete(name: str):
    try:
        result = get_genome_engine().delete(name)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/search", methods=["POST", "GET"])
def genome_search():
    """Search DNA across genome. POST { "query": str } or GET ?q=str"""
    if request.method == "POST":
        data  = request.get_json(force=True, silent=True) or {}
        query = data.get("query", data.get("q", "")).strip()
        max_r = int(data.get("max_results", 10))
    else:
        query = request.args.get("q", "").strip()
        max_r = int(request.args.get("max", 10))
    if not query:
        return jsonify({"error": "query required"}), 400
    try:
        results = get_genome_engine().search_dna(query, max_results=max_r)
        return jsonify({"results": results, "count": len(results), "query": query})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/fitness/<name>", methods=["GET"])
def genome_fitness(name: str):
    """Compute/return fitness metrics for a genome segment."""
    force = request.args.get("force", "false").lower() == "true"
    try:
        fm = get_genome_engine().compute_fitness(name, force=force)
        if not fm:
            return jsonify({"error": f"Genome '{name}' not found"}), 404
        return jsonify(asdict(fm))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

from dataclasses import asdict

@genome_bp.route("/api/genome/manager/fitness/all", methods=["POST"])
def genome_fitness_all():
    """Recompute fitness for all genome segments."""
    try:
        return jsonify(get_genome_engine().recompute_all_fitness())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/mutations", methods=["GET"])
def genome_mutations():
    name  = request.args.get("name", "")
    limit = int(request.args.get("limit", 50))
    try:
        return jsonify({
            "mutations": get_genome_engine().get_mutation_history(name=name, limit=limit),
            "total":     len(get_genome_engine()._mutation_log),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/lineage/<name>", methods=["GET"])
def genome_lineage(name: str):
    try:
        chain = get_genome_engine().get_lineage_chain(name)
        return jsonify({"name": name, "lineage": chain, "depth": len(chain)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/merge", methods=["POST"])
def genome_merge():
    """
    POST { "source": str, "target": str, "strategy": "union"|"best" }
    """
    data   = request.get_json(force=True, silent=True) or {}
    source = data.get("source", "").strip()
    target = data.get("target", "").strip()
    strat  = data.get("strategy", "union")
    if not source or not target:
        return jsonify({"error": "source and target required"}), 400
    try:
        return jsonify(get_genome_engine().merge_genomes(source, target, strat))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@genome_bp.route("/api/genome/manager/synthesis_candidates", methods=["GET"])
def genome_synthesis_candidates():
    """Return genome segments ready for synthesis (logic engine evaluated)."""
    min_fitness = float(request.args.get("min_fitness", 0.5))
    try:
        candidates = get_genome_engine().get_synthesis_candidates(min_fitness)
        return jsonify({"candidates": candidates, "count": len(candidates)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(genome_bp)
    log.info("[genome_manager] ✓ Registered at /api/genome/manager")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="genome_manager",
            blueprint_var="genome_bp",
            url_prefix="/api/genome/manager",
            version="2.0",
            description="Full genome CRUD, fitness scoring, lineage tracking, mutation recording, logic engine integration",
            capabilities=[
                {"id": "genome.list",       "endpoint": "/api/genome/manager/list",     "method": "GET",  "tags": ["genome"]},
                {"id": "genome.add",        "endpoint": "/api/genome/manager/add",      "method": "POST", "tags": ["genome"]},
                {"id": "genome.search",     "endpoint": "/api/genome/manager/search",   "method": "POST", "tags": ["genome", "search"]},
                {"id": "genome.fitness",    "endpoint": "/api/genome/manager/fitness",  "method": "GET",  "tags": ["genome", "fitness"]},
                {"id": "genome.merge",      "endpoint": "/api/genome/manager/merge",    "method": "POST", "tags": ["genome", "mutation"]},
                {"id": "genome.candidates", "endpoint": "/api/genome/manager/synthesis_candidates","method":"GET","tags":["genome","synthesis"]},
                {"id": "genome.health",     "endpoint": "/api/genome/manager/health",   "method": "GET",  "tags": ["health"]},
            ],
            depends_on=["logic_engine", "db_init"],
            boot_order=15,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5013, debug=True, use_reloader=False)
