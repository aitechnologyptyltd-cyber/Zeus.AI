# main.py
# Zeus Skill Factory — CLI Entry Point

import logging
import click
from src.orchestrator import Orchestrator

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")


@click.command()
@click.argument("archive_path", type=click.Path(exists=True))
@click.option("--output", "-o", default="./generated_skills", help="Output directory for skills.")
def main(archive_path, output):
    """Zeus Skill Extractor & Generator — zero stubs, verified execution only."""
    orchestrator = Orchestrator(output_dir=output)
    results = orchestrator.run(archive_path)

    passed = sum(1 for r in results if r.passed)
    total = len(results)
    click.echo(f"\n{passed}/{total} skills passed validation. Output: {output}")

    if passed < total:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
