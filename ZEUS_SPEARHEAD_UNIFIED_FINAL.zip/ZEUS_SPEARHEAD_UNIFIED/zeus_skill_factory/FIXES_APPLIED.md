# Zeus Skill Factory — Fixes Applied & Verified

The original blueprint (Ultimate Skill Extractor & Generator) did not run as
written. Every issue below was found by reading the code, fixed, and then
**actually executed** in this environment to confirm the fix works — not just
asserted. Where a real dependency (pytest, network access to PyPI) wasn't
available in this sandbox, a minimal local shim was used to execute the real
logic; this is noted explicitly per item.

---

## 🐛 Crash Bugs (would fail on first real use)

### 1. `RawSkill` had no `params` field; `conflict_arbiter` crashed
**Original:** `raw._fields.get('params', {})` — `RawSkill` is a Pydantic
model, not a namedtuple, and never defined `params` at all. First call to
`ConflictArbiter.merge()` raised `AttributeError`.

**Fix:** Added `params: Dict[str, str]` to `RawSkill` (`models.py`), and
`ast_surgeon.py` now populates it from the function's argument list.
`conflict_arbiter.py` reads `raw.params` directly.

**Verified:** Ran `ConflictArbiter().merge()` with real `SkillCandidate` +
`RawSkill` instances — merges successfully, no crash. See test output for
`test_conflict_arbiter_merges_without_crash`.

---

### 2. `generator.py` called `self._generate_test()`, which didn't exist
**Original:** `emit()` calls `self._generate_test(skill)` in the AST-verbatim
path. That method was never defined anywhere in `ZeroFluffGenerator`.
Guaranteed `AttributeError` on every skill with real source code — i.e. the
main intended use case.

**Fix:** Implemented `_generate_test()` — generates a real pytest smoke test
that imports the skill, asserts it's callable, and calls it with
type-appropriate dummy arguments derived from the skill's parameter types.

**Verified:** Generated a skill + test, then actually imported and executed
both the skill module and the generated test functions end-to-end (not
just checked the text). `add(1, 1)` returned `2`; the generated
`test_add_executes()` function ran without error.

---

### 3. JS parser polluted `List[str]` fields with `None`/`''`
**Original:** `imports=['const fs = require("fs")' if ... else None]` and
`dependencies=['axios' if ... else '']` — puts `None`/empty-string into
fields typed `List[str]`, which fails Pydantic validation on construction.

**Fix:** JS parser (`ast_surgeon.py`) now only appends real values into the
lists. Additionally, `RawSkill` has a `field_validator` (`models.py`) that
strips falsy entries from `imports`/`dependencies` as a defensive boundary,
so this class of bug can't silently reappear even if a future parser makes
the same mistake.

**Verified:** Constructed `RawSkill(imports=[None, "import os", ""], ...)`
directly — confirmed the validator strips it down to `["import os"]`.

---

## 🔓 Security Issues

### 4. Zip-slip / path traversal in `unpack_archive()`
**Original:** No validation that extracted entries stay inside the target
directory. A malicious archive with `../../../etc/whatever` entry names
could write files outside the extraction directory — a well-known,
serious vulnerability class for any "unpack an uploaded archive" feature.

**Fix:** `unpack_archive()` now validates every zip/tar member's resolved
path is contained within the extraction directory before extracting, and
also rejects symlink/hardlink entries pointing outside it. Raises
`UnsafeArchiveError` and aborts (no partial extraction) if violated.

**Verified:** Built an actual malicious zip with entry name
`../../../tmp/evil_payload.txt` and an actual malicious tar with the same
pattern. Both were rejected with `UnsafeArchiveError`. Confirmed the
payload file was **not** written to `/tmp/` after the attempt. A normal,
legitimate archive still extracts correctly (also verified).

---

### 5. Untrusted dependency auto-installation
**Original:** `resolve_pypi_version()` + `validation_rig.py` would
`pip install -r requirements.txt` for whatever package names the
heuristics *guessed* at from an untrusted uploaded archive, inside an
autonomous validation loop.

**Fix:** Version resolution now checks a local, hardcoded table of
known-safe pinned versions first (`KNOWN_SAFE_VERSIONS` in `utils.py`) —
no network call for common packages. `validation_rig.py` no longer
auto-installs anything; dependencies are recorded in the skill's
`manifest.json`/`requirements.txt` for a deliberate, separate install step
rather than being pulled in automatically during validation.

---

### 6. Duplicated a sandbox that already exists in SPEARHEAD
**Original:** Stood up its own Docker/venv sandbox per skill, parallel to
and inconsistent with `zeus_sandbox.py`, which already exists in the
SPEARHEAD codebase, is already covered by `tests/test_sandbox.py`, and
already blocks dangerous imports (`subprocess`, etc.) via `strict=True`.

**Fix:** `validation_rig.py` now uses `zeus_sandbox.get_sandbox()` as the
primary execution path when available (auto-detected, matching the
optional-injection pattern used by `zeus_test_feedback_bridge.py`), and
only falls back to a minimal isolated-subprocess check when running the
factory standalone outside a full SPEARHEAD deployment.

**Note:** `zeus_sandbox.py` itself isn't present in this isolated
verification environment, so the fallback path (`_validate_with_subprocess`)
is what was actually exercised end-to-end here. The `zeus_sandbox`
integration path is written against the exact interface your existing
`tests/test_sandbox.py` already exercises (`get_sandbox().run_python(code,
strict=True)` returning `.success`/`.stdout`/`.error`), so it will engage
automatically once deployed inside SPEARHEAD where `zeus_sandbox` is
importable.

---

## ⚠️ Design / Fragility Fixes

### 7. Heuristic engine only scanned prose docs — usually finds nothing
**Original:** Only scanned `.md/.txt/.rst/.pdf` for function-signature-like
text patterns. Most real code archives don't describe every function in
prose docs this way, so `candidates` was frequently empty, which then hit
the single-case `_generate_from_intent` fallback and crashed for anything
that wasn't image resizing.

**Fix:** Added `scan_code_docstrings()` — mines `.py` files directly for
function docstrings and signatures via AST, independent of README quality.
Also deduplicates candidates found by multiple heuristic sources (a
function documented in both the README and its own docstring no longer
produces two duplicate skill folders).

**Verified:** Ran the full orchestrator against a real zip archive with a
`README.md` and a `mathutils.py` containing `multiply`/`divide` — both
functions were correctly extracted, deduplicated (2 skills, not 3), and
emitted as real, unmodified, verbatim code (`multiply.py` contains exactly
the original function body, confirmed by direct inspection).

---

### 8. `resolve_pypi_version()` — synchronous network call per dependency
**Original:** Shells out to `pip index versions` (an experimental pip
subcommand) once per dependency per skill, synchronously. If wired into
Zeus's 120-second autonomous improvement cycle, this could stall it.

**Fix:** Checks the local `KNOWN_SAFE_VERSIONS` table first (instant, no
network). The network fallback is now `@lru_cache`d, so it only ever runs
once per unique package name per process, and has a 5-second timeout.

---

### 9. `pylint --fail-under=7.0` with `check=True` — over-aggressive gate
**Original:** pylint's exit codes are bit-flags that fire on ordinary
convention warnings, not just genuine failures. Combined with
`subprocess.run(..., check=True)`, this would reject most real code and
contradict the "80% coverage, mandatory validation" promise being
practically achievable.

**Fix:** Static analysis is now advisory only — findings are attached to
`TestResult.errors` as `lint_advisory:` entries but never block validation.
The actual pass/fail gate is real execution + pytest, which is what
genuinely proves a skill works.

---

### 10. `astor.to_source()` used instead of stdlib `ast.unparse()`
**Original:** Pulled in `astor` as an extra dependency for AST unparsing,
inconsistent with `zeus_refactoring_engine.py`, which already uses the
stdlib `ast.unparse()` (Python 3.9+) elsewhere in SPEARHEAD.

**Fix:** Dropped `astor` entirely. `ast_surgeon.py` uses `ast.unparse()`,
matching the convention already established in your codebase.

**Verified:** Extracted a real function via AST, ran `ast.parse()` on the
extracted body to confirm it round-trips as valid, syntactically correct
Python with no `astor` import anywhere in the package.

---

### 11. `_generate_from_intent()` only handled one case, then crashed the run
**Original:** Raised a bare `ValueError` for anything besides image resize,
which propagated up and killed the entire orchestrator run for that
archive — not just that one skill.

**Fix:** Raises a specific `SkillGenerationError`. The orchestrator catches
this specific exception, records it as a failed result for that skill only,
and continues processing the rest of the archive. Also expanded the intent
map to cover URL fetching and CSV parsing as additional real, runnable
mappings (not stubs).

**Verified:** Ran the full orchestrator against an archive containing one
mappable skill and one deliberately unmappable one — the unmappable skill
was recorded as a failure with a clear message, and the run completed and
processed the remaining skill successfully rather than crashing.

---

## 🔌 New: Integration into SPEARHEAD (not present in the original at all)

The original blueprint was a fully standalone tool with no connection to
your existing system. Added:

- **`genome_manager` registration** — skills that pass validation are
  registered as new DNA via `genome_manager.add()`, following the exact
  pattern used by the immune system's refactoring engine.
- **`hive_bridge` event publishing** — extraction/validation events are
  published to a `skill_factory_stream`, using the same optional-injection
  pattern (`_try_load_hive_bridge()`) as `zeus_test_feedback_bridge.py`.
- **`zeus_skill_factory_bridge.py`** — a Flask blueprint exposing
  `POST /api/skills/extract` (upload an archive, get back validated
  skills) and `GET /api/skills/health`, following the same
  `register(app)` convention as `zeus_auto_register.py`.

All three integration points are **optional and auto-detected** — the
factory runs standalone via `main.py` with zero SPEARHEAD dependencies,
and automatically wires in when those modules are importable.

---

## Summary of What Was Actually Executed (not just claimed)

| Component | Executed? | How |
|---|---|---|
| `models.py` field validation | ✅ Yes | Local pydantic-compatible shim, real model construction |
| `conflict_arbiter.py` merge logic | ✅ Yes | Same shim, real `SkillCandidate`/`RawSkill` merge |
| `generator.py` code + test generation | ✅ Yes | Generated files written to disk, then imported and run |
| `generator.py` error handling | ✅ Yes | Triggered both success and failure paths for real |
| `ast_surgeon.py` extraction | ✅ Yes | Real `.py` file parsed, `ast.parse()`-verified output |
| `utils.py` zip-slip protection | ✅ Yes | Real malicious zip/tar built and rejected; payload confirmed absent from filesystem |
| Full orchestrator pipeline | ✅ Yes | Real archive → extraction → generation → manifest, end-to-end |
| `validation_rig.py` + `zeus_sandbox` path | ⚠️ Partial | `zeus_sandbox.py` isn't present in this isolated environment; the fallback subprocess path was executed, the `zeus_sandbox` path is written to the exact interface your existing tests already verify, and will engage automatically on deployment |
| `zeus_skill_factory_bridge.py` (Flask) | ⚠️ Not executed | No live SPEARHEAD Flask app in this environment to register against; code follows the same pattern as your existing, working blueprints |
