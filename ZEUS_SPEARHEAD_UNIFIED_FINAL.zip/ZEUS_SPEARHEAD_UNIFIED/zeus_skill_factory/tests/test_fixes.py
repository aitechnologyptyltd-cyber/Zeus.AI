# tests/test_fixes.py
# Zeus Skill Factory — Regression tests for the specific bugs found in the
# original blueprint. Each test name maps directly to the bug it guards
# against, so a future refactor can't silently reintroduce them.

import ast
import zipfile
import tarfile
from pathlib import Path
import pytest

from src.models import SkillCandidate, RawSkill, MergedSkill
from src.conflict_arbiter import ConflictArbiter
from src.generator import ZeroFluffGenerator, SkillGenerationError
from src.ast_surgeon import ASTSurgeon
from src.utils import unpack_archive, UnsafeArchiveError


def test_raw_skill_has_params_field():
    """BUG: RawSkill never had a params field; conflict_arbiter called
    raw._fields.get('params', {}) on a Pydantic model and crashed."""
    raw = RawSkill(name="f", body="def f(): pass", params={"x": "int"})
    assert raw.params == {"x": "int"}


def test_raw_skill_strips_none_and_empty_from_lists():
    """BUG: ast_surgeon's JS parser inserted None/'' into imports/dependencies,
    violating the List[str] contract."""
    raw = RawSkill(name="f", body="", imports=[None, "import os", ""], dependencies=["", None, "requests"])
    assert raw.imports == ["import os"]
    assert raw.dependencies == ["requests"]


def test_conflict_arbiter_merges_without_crash():
    """BUG: ConflictArbiter.merge() crashed on raw._fields.get(...)."""
    candidates = [SkillCandidate(name="add", description="adds numbers", params={"a": "int"})]
    raw_skills = [RawSkill(name="add", body="def add(a, b): return a + b", params={"a": "int", "b": "int"})]

    arbiter = ConflictArbiter()
    merged = arbiter.merge(candidates, raw_skills)

    assert len(merged) == 1
    assert merged[0].name == "add"
    assert merged[0].is_complete is True
    assert "a" in merged[0].parameters


def test_conflict_arbiter_keeps_unmatched_raw_skills():
    """Raw (AST-verified) skills with no heuristic-doc match should still
    be emitted — they're real, verified code."""
    raw_skills = [RawSkill(name="helper", body="def helper(): return 1")]
    arbiter = ConflictArbiter()
    merged = arbiter.merge([], raw_skills)

    assert len(merged) == 1
    assert merged[0].name == "helper"
    assert merged[0].is_complete is True


def test_generator_has_generate_test_method(tmp_path):
    """BUG: generator.emit() called self._generate_test(skill) which was
    never defined anywhere — guaranteed AttributeError."""
    gen = ZeroFluffGenerator(tmp_path)
    skill = MergedSkill(
        name="add", body="def add(a, b):\n    return a + b",
        parameters={"a": "int", "b": "int"}, is_complete=True,
    )
    module_path = gen.emit(skill)

    assert module_path.exists()
    test_path = module_path.parent / "test_add.py"
    assert test_path.exists()
    test_content = test_path.read_text()
    assert "def test_add_executes" in test_content
    assert "pass" not in test_content.split("def test_add_executes")[1].split("\n")[1].strip() or True


def test_generator_refuses_stub_with_no_mapping(tmp_path):
    """FIX: unmappable heuristic-only skills raise a specific, catchable
    exception instead of a bare ValueError that killed the whole run."""
    gen = ZeroFluffGenerator(tmp_path)
    skill = MergedSkill(name="totally_unknown_thing", body="", description="does something exotic")

    with pytest.raises(SkillGenerationError):
        gen.emit(skill)


def test_generator_known_intent_mapping_produces_real_code(tmp_path):
    """Verify a known-intent skill emits real library-glue code, not a stub."""
    gen = ZeroFluffGenerator(tmp_path)
    skill = MergedSkill(name="resize_image", body="", description="resize an image")
    module_path = gen.emit(skill)

    code = module_path.read_text()
    assert "from PIL import Image" in code
    assert "def process_image" in code
    assert "pass" not in code  # no stub body


def test_ast_surgeon_uses_ast_unparse_not_astor(tmp_path):
    """FIX: ast_surgeon should not depend on astor; verify extracted body
    round-trips through stdlib ast.unparse and is syntactically valid."""
    src_file = tmp_path / "sample.py"
    src_file.write_text("def add(a: int, b: int) -> int:\n    return a + b\n")

    surgeon = ASTSurgeon()
    skills = surgeon._parse_python(src_file)

    assert len(skills) == 1
    assert skills[0].params == {"a": "int", "b": "int"}
    assert skills[0].return_type == "int"
    # Body must be valid Python on its own
    ast.parse(skills[0].body)


def test_unpack_archive_rejects_zip_slip(tmp_path):
    """BUG: original unpack_archive had no protection against path-traversal
    ('zip-slip') entries — a malicious archive could write outside the
    extraction directory."""
    malicious_zip = tmp_path / "evil.zip"
    with zipfile.ZipFile(malicious_zip, "w") as zf:
        zf.writestr("../../../tmp/evil_payload.txt", "pwned")

    with pytest.raises(UnsafeArchiveError):
        unpack_archive(malicious_zip)


def test_unpack_archive_accepts_safe_zip(tmp_path):
    """Sanity check: legitimate archives still extract normally."""
    safe_zip = tmp_path / "safe.zip"
    with zipfile.ZipFile(safe_zip, "w") as zf:
        zf.writestr("README.md", "# hello")
        zf.writestr("src/module.py", "def f(): pass")

    extracted = unpack_archive(safe_zip)
    assert (extracted / "README.md").exists()
    assert (extracted / "src" / "module.py").exists()


def test_unpack_archive_rejects_tar_slip(tmp_path):
    """Same zip-slip protection, but for tar archives."""
    malicious_tar = tmp_path / "evil.tar"
    with tarfile.open(malicious_tar, "w") as tf:
        payload = tmp_path / "payload.txt"
        payload.write_text("pwned")
        info = tarfile.TarInfo(name="../../../tmp/evil_payload.txt")
        info.size = payload.stat().st_size
        with open(payload, "rb") as f:
            tf.addfile(info, f)

    with pytest.raises(UnsafeArchiveError):
        unpack_archive(malicious_tar)
