#!/bin/bash
# Zeus Autonomous Immune System - Quick Start Script
# Usage: bash QUICKSTART.sh /path/to/spearhead

if [ -z "$1" ]; then
    echo "Usage: bash QUICKSTART.sh /path/to/spearhead"
    echo "Example: bash QUICKSTART.sh /home/zeus/spearhead"
    exit 1
fi

SPEARHEAD_PATH="$1"
IMMUNE_SYSTEM_PATH=$(cd "$(dirname "$0")" && pwd)

echo "=========================================="
echo "Zeus Autonomous Immune System - Installer"
echo "=========================================="
echo ""
echo "SPEARHEAD Path: $SPEARHEAD_PATH"
echo "Immune System Path: $IMMUNE_SYSTEM_PATH"
echo ""

# Check if SPEARHEAD exists
if [ ! -d "$SPEARHEAD_PATH" ]; then
    echo "❌ ERROR: SPEARHEAD directory not found: $SPEARHEAD_PATH"
    exit 1
fi

echo "✓ SPEARHEAD directory found"
echo ""

# Step 1: Install dependencies
echo "Step 1: Installing dependencies..."
pip install pytest pytest-flask pytest-cov pytest-timeout --break-system-packages -q

if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi
echo ""

# Step 2: Copy test files
echo "Step 2: Copying test suite..."
if [ ! -d "$SPEARHEAD_PATH/tests" ]; then
    mkdir -p "$SPEARHEAD_PATH/tests"
fi

cp -r "$IMMUNE_SYSTEM_PATH/tests/" "$SPEARHEAD_PATH/tests/" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✓ Test files copied"
else
    echo "❌ Failed to copy test files"
    exit 1
fi
echo ""

# Step 3: Copy core components
echo "Step 3: Copying core components..."
cp "$IMMUNE_SYSTEM_PATH/zeus_test_feedback_bridge.py" "$SPEARHEAD_PATH/" 2>/dev/null
cp "$IMMUNE_SYSTEM_PATH/zeus_refactoring_engine.py" "$SPEARHEAD_PATH/" 2>/dev/null
cp "$IMMUNE_SYSTEM_PATH/zeus_feedback_loop.py" "$SPEARHEAD_PATH/" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✓ Core components copied"
else
    echo "❌ Failed to copy components"
    exit 1
fi
echo ""

# Step 4: Run tests to verify
echo "Step 4: Running tests to verify installation..."
cd "$SPEARHEAD_PATH"
pytest tests/ -v --tb=short -q 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✓ All tests passed!"
else
    echo "⚠ Some tests may have failed (this is ok if app not fully configured)"
fi
echo ""

# Step 5: Create integration checklist
echo "Step 5: Creating integration checklist..."
cat > "$SPEARHEAD_PATH/IMMUNE_SYSTEM_INTEGRATION_CHECKLIST.md" << 'EOF'
# Immune System Integration Checklist

## Pre-Integration
- [ ] Read INTEGRATION_GUIDE.md (in immune system folder)
- [ ] Understand the feedback loop architecture
- [ ] Back up current SPEARHEAD system

## Integration Steps

### 1. zeus_improvement_loop.py
- [ ] Add Stage 9 to the 8-stage improvement cycle
- [ ] Import: `from zeus_test_feedback_bridge import get_test_feedback_bridge`
- [ ] Add method: `run_test_suite(self)` (see INTEGRATION_GUIDE.md)
- [ ] Update stages list to include Stage 9

### 2. zeus_self_evolution.py  
- [ ] Import: `from zeus_test_feedback_bridge import get_test_feedback_bridge`
- [ ] Add method: `_prioritize_gaps_by_test_failures(self)` (see INTEGRATION_GUIDE.md)
- [ ] Call this method in gap prioritization logic

### 3. hive_bridge.py
- [ ] Add test_stream to HiveMemory if not present
- [ ] Add test event handling to publish_event method
- [ ] Add test data to intelligence_score calculation

### 4. genome_manager.py
- [ ] Add method: `register_refactoring_as_genome(self, refactor_result)` (see INTEGRATION_GUIDE.md)
- [ ] Call this method when refactoring succeeds

## Post-Integration
- [ ] Restart Zeus system
- [ ] Check logs for "Stage 9" entries
- [ ] Verify test databases created
- [ ] Monitor system health report
- [ ] Celebrate autonomous improvements! 🎉

## Verification
- [ ] `pytest tests/ -v` runs successfully
- [ ] Test feedback bridge initializes without errors
- [ ] Stage 9 executes during improvement cycle
- [ ] Test events published to hive mind
- [ ] Refactoring engine creates backups
- [ ] No existing SPEARHEAD files modified

## Support
See INTEGRATION_GUIDE.md for detailed information on each step.
EOF

echo "✓ Integration checklist created"
echo ""

# Final summary
echo "=========================================="
echo "✅ Installation Complete!"
echo "=========================================="
echo ""
echo "Next Steps:"
echo "1. Read: INTEGRATION_GUIDE.md"
echo "2. Follow integration checklist: IMMUNE_SYSTEM_INTEGRATION_CHECKLIST.md"
echo "3. Run: pytest tests/ -v"
echo "4. Integrate with SPEARHEAD (see checklist)"
echo "5. Restart Zeus system"
echo ""
echo "Newly created files in $SPEARHEAD_PATH:"
echo "  ├─ tests/                                 (test suite)"
echo "  ├─ zeus_test_feedback_bridge.py           (test feedback)"
echo "  ├─ zeus_refactoring_engine.py             (refactoring)"
echo "  ├─ zeus_feedback_loop.py                  (health monitoring)"
echo "  └─ IMMUNE_SYSTEM_INTEGRATION_CHECKLIST.md (checklist)"
echo ""
echo "Databases created during operation:"
echo "  ├─ zeus_test_results.db       (test execution history)"
echo "  ├─ refactoring_history.db     (refactoring operations)"
echo "  └─ zeus_feedback.db           (system health metrics)"
echo ""
echo "Ready to activate your autonomous immune system!"
echo ""
