# ZEUS SWARM — Agent Architecture Design
**The Zeus Project 2026 — Francois Nel / AI Technology PTY LTD**
Companion design to `SPEARHEAD_CLEAN` / `zeus_hive_final_genome_patched`

---

## 1. Why a swarm layer at all

Zeus today is a **single Flask process** with 60+ blueprints registered flat in
`app.py` via `_register()` / `_register_fn()`. That works, but it has three
costs that grow as the module count grows:

1. **No ownership boundary.** Any module can technically import any other
   module. `zeus_drone_vision.py` could reach into `zeus_sovereignty_engine.py`
   if someone wrote the import — nothing stops it.
2. **No blast radius containment.** If `zeus_apk_builder_core.py` hangs or
   leaks memory on the armv7l box, it can starve `zeus_llm_router.py` in the
   same process/thread pool.
3. **No per-domain health signal.** `full_system_check.py` reports module-level
   pass/fail, but there's no notion of "is Geo-Intel as a *domain* healthy" —
   just 6 separate green/red dots.

The swarm layer doesn't replace `app.py`'s blueprint registration — it sits
**on top of it** as a routing + ownership + health-aggregation layer. It is
additive, same pattern as `zeus_immune_system` and `zeus_skill_factory`:
optional-injection, degrades gracefully if a piece is missing.

---

## 2. The 13 agents

Each agent is **not a new process** — it's a logical ownership group over
existing modules, enforced by a routing table + import-boundary convention.
Naming continues your existing Greek-mythology scheme (Forge, Nexus, Sentinel,
Mirror, Herald, Chronicle, Mesh, Validator already in use).

| Agent | Layer (per app.py) | Owns | Role |
|---|---|---|---|
| **Hermes** | 0 (Core) | app, zeus_blueprints, zeus_council_router, zeus_intelligent_router, zeus_llm_router, zeus_executor, zeus_identity | Dispatcher. Every task enters through Hermes; it decides which agent owns it. |
| **Prometheus** | 1–2 (Data/Evolution) | zeus_code_learner, zeus_learner, zeus_recursive_learner, zeus_self_evolution, zeus_mutator, zeus_improvement_loop, genome_manager, logic_engine, zeus_forge, zeus_synthesis | Self-evolution: everything that mutates, scores, and grows the genome. |
| **Aegis** | cross-cutting | aegis_field/*, zeus_firewall/*, zeus_sovereignty_engine, zeus_sovereignty_crosswire, zeus_sandbox | Security gate. Ring-1 authorization sits here — Prometheus's genome writes route through Aegis, not around it. |
| **Argus** | 1 (specialized) | zeus_geo_intel, zeus_geo_auth, zeus_geo_cluster, zeus_geo_signing_tool, zeus_geo_vision, zeus_govint_blueprint | GovInt / geo-intelligence domain. |
| **Icarus** | 4 (Specialized) | all zeus_drone_* modules | Drone telemetry, vision, command, geofencing. |
| **Tartarus** | 1 (Data) | all zeus_tartarus_* modules, zeus_prediction_engine | Sensing + prediction subsystem (already named in your base — kept as-is). |
| **Iris** | 0 (Core) | zeus_deepseek_bridge, zeus_grok_bridge, zeus_perplexity_bridge | External LLM bridges — messenger to outside models, separate from the internal `zeus_llm_router` circuit breaker Hermes owns. |
| **Hephaestus** | 4 (Specialized) | zeus_apk_builder_core, zeus_apk_engine, zeus_apk_export | Builds/exports physical artifacts (APKs). |
| **Mnemosyne** | 4–5 | zeus_hive_bridge, zeus_replication_engine, zeus_stress_engine, zeus_nightly_scheduler, zeus_auto_register | Persistence, replication, hive memory, scheduled cycles. |
| **Atlas** | 1 (Data) | zeus_upload, zeus_search, zeus_sys_aware, db_init, full_system_check | Infra load-bearing: DB, uploads, search, system awareness. |
| **Hestia** | 5 (Presentation) | zeus_chat, zeus_learning_dashboard | User-facing hearth — chat + dashboard. |
| **Asclepius** | (immune system) | tests/*, zeus_immune_system/* | Self-healing QA — the immune system, given a name instead of a folder. |
| **Daedalus** | (skill factory) | zeus_skill_factory/src/* | Builds new skills/tools on demand. |

---

## 3. What's shared vs what's isolated

**Shared core substrate** (every agent calls into the same instance — never
duplicated per agent):

- `db_init.get_db()` — one SQLite connection pool, WAL mode
- `zeus_identity` — one fingerprint/capability registry
- `zeus_llm_router` — one circuit breaker; agents call it, they don't each
  implement their own Groq/Claude/OpenRouter fallback
- `zeus_hive_bridge` — one hive memory

**Agent-isolated** (exclusive, not duplicated elsewhere):

- Each agent's own module list from the table above
- Each agent gets its own row in a new `swarm_agents` table (health, last
  dispatch, module manifest) — additive schema, doesn't touch your existing
  `DB_SCHEMA_VERSION = 7` tables

This answers last message's open question directly: **no agent gets "all of
Zeus."** Hermes routes; the domain agent executes; Aegis gates anything that
writes to the genome or touches sovereignty-tier actions, regardless of which
agent originated the request.

---

## 4. Request flow

```
   caller (chat / API / nightly scheduler)
            │
            ▼
        ┌───────┐
        │ Hermes│  ← looks up module/capability in ROUTING_TABLE
        └───┬───┘
            │  dispatch(agent, task)
            ▼
   ┌────────────────────┐
   │  target agent       │  e.g. Prometheus
   │  (owns the module)  │
   └─────────┬───────────┘
             │  if action touches genome/sovereignty
             ▼
        ┌────────┐
        │  Aegis  │  ← Ring-1 gate (existing sovereign_execute pattern)
        └────┬───┘
             │ approved
             ▼
      module executes, result logged to swarm_dispatch_log
```

## 5. Failure mode

If an agent's modules fail to import (missing dependency on the armv7l box,
same class of problem you hit with scipy/pandas), the agent is marked
`degraded` in `swarm_agents`, Hermes stops routing to it, and callers get a
clear `503 agent_degraded` instead of a silent Flask 500. This mirrors the
graceful-degradation pattern already in `zeus_hive_bridge.py`.

---

## 6. Verification pass — corrections made against the real tree

The first draft of this design assumed dotted subpackage imports
(`zeus_firewall.zeus_aegis_engine`, `zeus_immune_system.zeus_feedback_loop`,
`zeus_skill_factory.src.orchestrator`) without checking them against your
actual code. Re-verified directly by extracting the zip and testing real
imports with `sys.path` set the way `wsgi_zeus.py` sets it. Three corrections
and several real bugs found:

**Corrections to the swarm module map:**
- `zeus_firewall/*.py` are imported **flat** in your existing code
  (`wsgi_zeus.py`, `zeus_hive_bridge.py`: `from zeus_firewall_v1 import
  ZeusFirewall`) because `wsgi_zeus.py` puts the `zeus_firewall/` directory
  itself on `sys.path`. `aegis_field.*` dotted was correct as originally
  written — it has `__init__.py` and is already imported that way in
  `zeus_govint_blueprint.py`.
- `zeus_immune_system/` and `zeus_skill_factory/` currently live as
  **siblings of `SPEARHEAD_CLEAN/`**, not inside it — confirmed by direct
  import test failing until a copy step happens. `zeus_swarm_deps_sync.sh`
  (new, below) performs that copy.
- Importing `app` to health-check Hermes was **fully booting the live Flask
  stack** — DB init, all 42 blueprints, background threads — as a side
  effect, since `app.py` runs its registration sequence at module level, not
  inside `if __name__ == "__main__"`. Removed from live import-health;
  tracked by file existence instead.

**Real bugs found in the delivered files (unrelated to the swarm layer,
surfaced by the health scan) — all four fixed and re-verified:**

- **`zeus_hive_bridge.py` (Mnemosyne)** — this was not a typo. The
  `SPEARHEAD_CLEAN` copy was missing its entire `HiveMemory`,
  `HivePredictionEngine`, and `HiveRepairDispatcher` class bodies, plus the
  first half of `HiveSyncLoop` — confirmed by `HiveSyncLoop()` being
  instantiated at line 171 with **zero class definitions anywhere in the
  1218-line file**. A complete, syntactically valid 2612-line copy existed
  as a sibling at `zeus_hive_final_genome_patched/zeus_hive_bridge.py`
  (matches the architecture already documented in prior sessions: HiveMemory
  7-table SQLite, HivePredictionEngine, HiveRepairDispatcher, HiveSyncLoop,
  plus GenomeHiveBroadcaster). Restored from that copy rather than
  hand-patched — the damage was too large to reconstruct safely by guessing.
  Verified: imports cleanly, `register_zeus_bridge(app)` registers 25 real
  Flask routes against a live app. **The broken original is kept as
  `zeus_hive_bridge.py.BROKEN_BACKUP_FOR_REVIEW` — please diff it against
  the restored version before deploying**, since I can't rule out that some
  intentional recent edit to the broken copy (rather than corruption) is
  what caused the divergence.
- **`zeus_refactoring_engine.py`** line 336 — `result["reason": f"..."]` (a
  stray colon mimicking dict-literal syntax inside a subscript) fixed to
  `result["reason"] = f"..."`. Parses clean.
- **`zeus_test_feedback_bridge.py`** line 412 — `def analyze_failures():`
  was indented one level deeper than its own `@bp.route(...)` decorator.
  Dedented to match. Parses clean.
- **`zeus_immune_system/QUICKSTART.sh`** — the three `cp` lines referencing
  a non-existent `components/` subfolder corrected to the actual flat file
  paths.

Re-ran the full swarm health scan after all four fixes: Mnemosyne and
Asclepius both flip from `degraded` to `healthy`. Two items remain, neither
a code bug:
- **Prometheus stays 9/10** — `zeus_synthesis` needs `uvicorn`, which isn't
  installed in this environment. Wasn't part of the original four findings;
  flagging separately since the health scan surfaced it too.
- **Daedalus stays 1/7** — `src/*` still needs `pydantic`
  (`pip install pydantic --break-system-packages`), noted in
  `zeus_swarm_deps_sync.sh`'s output; couldn't install it in this sandbox
  (no network egress here) to confirm the fix closes the loop.

## 7. Files delivered

- `zeus_swarm_orchestrator.py` — the actual module: registry, routing table,
  Flask blueprint (`/api/swarm/*`), health check, dispatch logging. Follows
  your `_register_fn(module_name)` convention exactly — drop it in
  `SPEARHEAD_CLEAN/`, add one line to `app.py`.
