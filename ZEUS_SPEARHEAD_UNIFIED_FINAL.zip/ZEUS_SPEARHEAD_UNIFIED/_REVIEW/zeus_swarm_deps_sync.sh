#!/usr/bin/env bash
# The Zeus Project 2026 — Francois Nel
# zeus_swarm_deps_sync.sh — Copies zeus_immune_system/ and zeus_skill_factory/
# into SPEARHEAD_CLEAN/ so Asclepius and Daedalus resolve at their real,
# final import paths instead of the sys.path fallback in
# zeus_swarm_orchestrator.py's _bootstrap_paths().
#
# This REPLACES zeus_immune_system/QUICKSTART.sh's Step 3, which references
# a "$IMMUNE_SYSTEM_PATH/components/" folder that does not exist in the
# delivered zip (the three files sit flat at zeus_immune_system/*.py). That
# script would fail at Step 3 as shipped — this one copies from the actual
# location.
#
# Usage: bash zeus_swarm_deps_sync.sh /path/to/ZEUS_SPEARHEAD_UNIFIED

set -euo pipefail

if [ -z "${1:-}" ]; then
    echo "Usage: bash zeus_swarm_deps_sync.sh /path/to/ZEUS_SPEARHEAD_UNIFIED"
    exit 1
fi

UNIFIED_ROOT="$(cd "$1" && pwd)"
SPEARHEAD="$UNIFIED_ROOT/SPEARHEAD_CLEAN"
IMMUNE="$UNIFIED_ROOT/zeus_immune_system"
SKILLS="$UNIFIED_ROOT/zeus_skill_factory"
TESTS="$UNIFIED_ROOT/tests"

if [ ! -d "$SPEARHEAD" ]; then
    echo "ERROR: SPEARHEAD_CLEAN not found at $SPEARHEAD"
    exit 1
fi

echo "== Zeus Swarm Dependency Sync =="
echo "Unified root : $UNIFIED_ROOT"
echo "Target       : $SPEARHEAD"
echo ""

# ---------------------------------------------------------------------- #
# Asclepius — immune system: 3 core files copied FLAT (matches
# INTEGRATION_GUIDE.md's intent; the actual files live at
# zeus_immune_system/*.py, not zeus_immune_system/components/*.py)
# ---------------------------------------------------------------------- #
if [ -d "$IMMUNE" ]; then
    echo "[Asclepius] Copying immune system core files..."
    for f in zeus_feedback_loop.py zeus_refactoring_engine.py zeus_test_feedback_bridge.py; do
        if [ -f "$IMMUNE/$f" ]; then
            cp "$IMMUNE/$f" "$SPEARHEAD/$f"
            echo "  copied $f"
        else
            echo "  MISSING (not found in zip): $f"
        fi
    done
else
    echo "[Asclepius] zeus_immune_system/ not found — skipping"
fi

if [ -d "$TESTS" ]; then
    echo "[Asclepius] Copying test suite..."
    mkdir -p "$SPEARHEAD/tests"
    cp -r "$TESTS/"* "$SPEARHEAD/tests/"
    echo "  tests/ copied"
else
    echo "[Asclepius] tests/ not found at unified root — skipping"
fi
echo ""

# ---------------------------------------------------------------------- #
# Daedalus — skill factory: src/ + bridge file copied flat.
# NOTE: 'src' is a generic top-level module name. This script copies it
# as-is to match zeus_skill_factory_bridge.py's existing
# `from src.orchestrator import Orchestrator` — no rename performed here.
# If you want the safer name, rename BOTH the copied folder AND that one
# import line together (see the note printed below).
# ---------------------------------------------------------------------- #
if [ -d "$SKILLS" ]; then
    echo "[Daedalus] Copying skill factory..."
    if [ -d "$SKILLS/src" ]; then
        cp -r "$SKILLS/src" "$SPEARHEAD/src"
        echo "  src/ copied"
    fi
    if [ -f "$SKILLS/zeus_skill_factory_bridge.py" ]; then
        cp "$SKILLS/zeus_skill_factory_bridge.py" "$SPEARHEAD/zeus_skill_factory_bridge.py"
        echo "  zeus_skill_factory_bridge.py copied"
    fi
    echo "  NOTE: 'src' is a generic name — collision risk against future"
    echo "        modules in a 60+ file flat directory. Consider renaming"
    echo "        to skill_factory_src/ and updating the one import line"
    echo "        in zeus_skill_factory_bridge.py to match, as a follow-up."
else
    echo "[Daedalus] zeus_skill_factory/ not found — skipping"
fi
echo ""

echo "== Dependency install =="
echo "src/orchestrator.py etc. require 'pydantic' (confirmed missing in"
echo "this environment during testing). Install with:"
echo "  pip install pydantic --break-system-packages"
echo ""

echo "== Done. Re-run the swarm health scan to confirm 'healthy' status =="
echo "  curl -s http://localhost:8080/api/swarm/health/rescan -X POST | python3 -m json.tool"
