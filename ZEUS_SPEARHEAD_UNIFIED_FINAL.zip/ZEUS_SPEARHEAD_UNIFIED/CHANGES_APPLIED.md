# CHANGES_APPLIED.md — Zeus Swarm Integration Pass
**The Zeus Project 2026 — Francois Nel**

This zip is `ZEUS_SPEARHEAD_UNIFIED_MERGE.zip` with the Zeus Swarm layer
wired in and the four bugs the swarm's health scan surfaced fixed at the
source. Verified end-to-end by actually booting `app.py` — see the boot log
at the bottom of this file.

---

## What's new in SPEARHEAD_CLEAN/

| File | Status |
|---|---|
| `zeus_swarm_orchestrator.py` | **NEW** — 13-agent registry, routing, per-agent health, dispatch log. Registered as Layer 11 in `app.py`. |
| `zeus_hive_bridge.py` | **RESTORED** — see "The zeus_hive_bridge.py bug" below |
| `zeus_refactoring_engine.py` | **FIXED + copied in** from `zeus_immune_system/`, plus a `register(app)` wrapper added |
| `zeus_test_feedback_bridge.py` | **FIXED + copied in**, plus a `register(app)` wrapper added |
| `zeus_feedback_loop.py` | copied in as-is (background loop, no blueprint, nothing to register) |
| `zeus_skill_factory_bridge.py` | copied in, one import line updated (see rename below) |
| `skill_factory_src/` | copied in from `zeus_skill_factory/src/`, **renamed** from bare `src` |
| `tests/` | copied in from the unified-root `tests/` folder |
| `app.py` | Layer 11 added: registers the four items above via the existing `_register_fn()` convention |

## The `zeus_hive_bridge.py` bug

Not a typo. The `SPEARHEAD_CLEAN` copy was missing its entire `HiveMemory`,
`HivePredictionEngine`, and `HiveRepairDispatcher` class bodies, plus the
first half of `HiveSyncLoop` — proven by `HiveSyncLoop()` being instantiated
with **zero class definitions anywhere in the file**. Restored from the
complete, valid sibling copy at `zeus_hive_final_genome_patched/`, which
matches the architecture from your earlier sessions (HiveMemory 7-table
SQLite, HivePredictionEngine, HiveRepairDispatcher, HiveSyncLoop,
GenomeHiveBroadcaster). Verified: imports cleanly, `register_zeus_bridge(app)`
registers 25 routes against a live Flask app.

**The broken original is kept at
`_REVIEW/zeus_hive_bridge.py.BROKEN_BACKUP_FOR_REVIEW` — diff it against the
restored version before you trust this blind**, since I can't rule out an
in-progress edit of yours being the cause rather than corruption.

## The `src` → `skill_factory_src` rename

`zeus_skill_factory_bridge.py` originally did
`from src.orchestrator import Orchestrator` — a bare `src` package is a
collision risk once merged into a 60+ module flat directory. Renamed the
copied-in folder to `skill_factory_src/` and updated the one import line to
match. The original `zeus_skill_factory/src/` (used by that folder's
standalone `main.py`) was left untouched — only the copy going into
`SPEARHEAD_CLEAN` was renamed.

## Two small syntax bugs fixed at the source

- `zeus_refactoring_engine.py` line 336: `result["reason": f"..."]` →
  `result["reason"] = f"..."`.
- `zeus_test_feedback_bridge.py` line 412: a `def` mis-indented one level
  relative to its own `@bp.route(...)` decorator — dedented to match.
- `zeus_immune_system/QUICKSTART.sh`: the three `cp` lines referencing a
  non-existent `components/` subfolder corrected to the actual flat paths
  (kept for reference/history — not needed for this zip since the copy is
  already done, but your original `QUICKSTART.sh` was broken as shipped).

## Still needs two `pip install`s on your machine

Neither is a code bug — both are genuinely missing dependencies, confirmed
by attempting them in this sandbox (no network egress here to finish the
install and re-verify):

```bash
pip install uvicorn pydantic --break-system-packages
```

- `uvicorn` — needed by `zeus_synthesis` (Prometheus agent)
- `pydantic` — needed by `skill_factory_src/*` (Daedalus agent)

Everything else gracefully degrades around these two — `_register_fn()`
catches the `ImportError`, logs a warning, and the rest of the app boots
normally. Confirmed by actually running `app.py` end-to-end (see below).

## End-to-end boot verification (real run, this sandbox)

```
45 blueprints loaded across 11 layers (SOVEREIGNTY ENGINE ACTIVE)
389 URL rules registered
11/13 swarm agents fully healthy
  degraded: prometheus (9/10 — missing uvicorn)
  degraded: daedalus   (1/7 — missing pydantic)
```

Once you run the two `pip install`s above, re-run:
```bash
curl -s http://localhost:8080/api/swarm/health/rescan -X POST | python3 -m json.tool
```
and both should flip to `healthy`.

---

## Pass 3: Universal cross-platform installer + guaranteed offline LLM mode

### `zeus_universal_install.py` (new, in `SPEARHEAD_CLEAN/`)

A single Python installer (not bash) so it runs identically on Linux
(x86_64/aarch64/armv7l), macOS (Intel/Apple Silicon), Windows, and
Termux/UserLAnd — Python is the one thing every one of those already needs
anyway, since Zeus itself is a Python app.

```bash
python3 zeus_universal_install.py                       # full install
python3 zeus_universal_install.py --skip-optional        # core packages only
python3 zeus_universal_install.py --no-system-packages    # pip-only, no sudo
```

What it does, in order:
1. **Detects OS + architecture** (Linux/macOS/Windows, x86_64/aarch64/armv7l,
   plus Termux and WSL specifically) and picks the right install strategy —
   32-bit ARM gets the same source-build + piwheels fallback chain your
   original `zeus_install_armv7l.sh` proved out; 64-bit platforms get the
   fast prebuilt-wheel path first.
2. **Creates every directory Zeus's own code expects** — pulled directly out
   of `SPEARHEAD_CLEAN`'s source (grepped every
   `os.path.join(ZEUS_DIR, "...")` reference), not guessed: `logs/`,
   `uploads/`, `exports/`, `evolved_modules/`, `forge_output/`,
   `prediction_output/`, `replication_packages/`, `sandbox_workspace/`,
   `sovereignty_archive/`, `sovereignty_workspace/`, `tartarus_uploads/`,
   `apk_analysis/`, `asm_builds/`, `patch_backups/`, `_router_backups/`,
   plus verifies `static/`/`templates/` for Flask.
3. **Creates `.env`** with every key referenced anywhere in the codebase,
   all left blank — merges in any new keys without touching ones you've
   already set if `.env` already exists.
4. **Best-effort OS package manager step** — detects apt-get/dnf/pacman/brew/
   pkg (Termux) and installs dev headers; cleanly skipped on Windows, where
   prebuilt wheels cover virtually everything anyway.
5. **Installs Python packages with a layered fallback per package**: plain
   wheel -> `--break-system-packages` -> source build -> source build
   without bsp -> (32-bit ARM only) piwheels extra index -> a genuine
   drop-in replacement where one exists (`pandas-ta` -> `ta`, same
   indicators, no `numba` dependency to break on newer Python).
6. **Verifies Zeus actually runs with zero cloud API keys** — strips every
   key from the environment in a subprocess and confirms `zeus_llm_router`
   still returns a real response instead of raising.
7. **Runs the swarm health scan** and prints per-agent status.

Verified end-to-end in this sandbox. No network egress here, so the actual
`pip install` calls fail in this environment specifically — confirmed
that's a sandbox limitation and not a script bug by running the identical
`pip install` command directly and getting the same PyPI-unreachable error.
Everything else ran clean: platform detection, directory creation, `.env`
generation, idempotency on a second run, the offline-mode verification, and
the swarm health check.

### Guaranteed offline mode — `zeus_llm_router.py`

Before this pass, `zeus_llm_router.py` (the file every other Zeus module is
supposed to route LLM calls through — per its own header comment) had no
local fallback: if none of `GROQ_API_KEY` / `ANTHROPIC_API_KEY` /
`OPENROUTER_API_KEY` were set, `.call()` raised
`RuntimeError("All LLM engines exhausted")`.

Added a fourth engine, `offline`, that needs no API key and is now always
appended as the guaranteed last rung in every engine chain:
1. Tries a local Ollama server at `OLLAMA_HOST` (default
   `http://localhost:11434`) — real local inference, free, no account, if
   the user has Ollama (https://ollama.com) installed and a model pulled.
2. If Ollama isn't reachable, returns a clearly-labeled offline template
   response (never mistaken for real model output) instead of raising.

Confirmed live in this sandbox with every cloud key stripped from the
environment and no Ollama running: `router.call()` returns the labeled
offline response instead of throwing.

**Scope note:** this fix is in the central router only. The three
standalone provider bridges — `zeus_deepseek_bridge.py`,
`zeus_grok_bridge.py`, `zeus_perplexity_bridge.py` — are separate,
explicitly-opt-in tools (each already returns a clean HTTP 503 from their
own Flask routes when their specific key is missing, rather than crashing),
not part of the "every module routes through here" core path. Didn't touch
those three; flagging so the offline guarantee is understood as scoped to
the central router, not every LLM-adjacent file in the repo.

---

## Pass 4: ClickUp gateway — new "Hecate" agent (additive, nothing removed)

Context: a ClickUp Announcement showed 6 ClickUp-native "Super Agents"
(Orchestrator, Memory Keeper, Researcher, Architect, Builder, Analyst)
configured inside ClickUp's own workspace. Those live entirely inside
ClickUp's proprietary platform behind an authenticated URL
(`app.clickup.com/.../ai/agents/...`) and a share-link dossier
(`run.clickup.ai/...`) blocked by that site's `robots.txt` — there's no way
to read their actual configured prompts/tool-bindings/logic from outside
ClickUp's UI, so nothing about their specific internal behavior was
reverse-engineered or guessed at here. What *was* buildable, and is what
this pass adds: a real bridge so Zeus's own swarm can talk to the same
ClickUp task backend those agents operate through.

### `zeus_clickup_bridge.py` (new file)

Follows the exact same shape as `zeus_grok_bridge.py` /
`zeus_deepseek_bridge.py` / `zeus_perplexity_bridge.py`: circuit breaker,
Flask blueprint, `register(app)`. Uses stdlib `urllib.request` (no new pip
dependency) since ClickUp's API is plain REST, not OpenAI-compatible —
matching the same choice already made for the `openrouter`/`ollama` calls
in `zeus_llm_router.py`.

Six core operations (the standard set for task-system orchestration):
`get_teams`, `get_spaces`, `list_tasks`, `create_task`, `get_task`,
`update_task`, `add_comment` — plus `resolve_team_id()` for auto-discovery.
Eight Flask routes under `/api/clickup/*`. Every route degrades to a clean
503 if `CLICKUP_API_TOKEN` is unset — same contract the other bridges use,
never a crash.

**One easy-to-get-wrong detail confirmed against ClickUp's docs and tested
directly:** the `Authorization` header takes the raw token string, with
**no** `Bearer ` prefix — unlike Groq/Claude/OpenRouter/DeepSeek/
Perplexity/xAI, which all use the standard `Bearer <token>` form. Getting
this wrong is the single most common ClickUp API integration mistake per
their own community docs; the bridge and its test both check for it
explicitly.

### How this was tested without real network access

This sandbox's egress is allowlisted, and `api.clickup.com` isn't on it —
confirmed directly (`curl` to the real endpoint returned a proxy-level
`x-deny-reason: host_not_allowed`, not a ClickUp response). So a live
round-trip against the real API couldn't be verified from here. What
*could* be verified, and was: every method (`get_teams`, `create_task`,
`update_task`, `add_comment`, etc.) exercised end-to-end against a local
mock server on loopback (`mock_clickup_server.py`, included for your own
future testing — not part of the deployed app) that mirrors ClickUp's
documented request/response shapes. Confirmed: correct URL construction,
correct raw-token auth header (explicitly checked for a wrongly-added
`Bearer` prefix and would fail the test if present), correct JSON body
shape for task creation, and the Flask routes registering and responding
correctly through `register(app)`.

**This proves the code is correct against ClickUp's documented API
contract — it does not prove ClickUp's real server will accept these exact
requests.** If you want that closed the loop, either enable
`api.clickup.com` in this environment's network egress settings for a
follow-up session, or test the deployed `.py` file yourself with a real
token in `.env`.

### Wiring — every change additive, nothing removed or replaced

- New agent in `zeus_swarm_orchestrator.py`: **Hecate** (crossroads/threshold
  goddess — gateway to an external system), owning `zeus_clickup_bridge.py`
  only. 13 agents → 14. No existing agent's module list was touched.
- New Layer 12 in `app.py`, added strictly after Layer 11 — registers
  `zeus_clickup_bridge` via the same `_register_fn()` convention as
  everything else. Layers 0-11 untouched.
- New env keys in `zeus_universal_install.py`'s `.env` template:
  `CLICKUP_API_TOKEN`, `CLICKUP_API_BASE`, `CLICKUP_TEAM_ID` — all blank by
  default, added before the existing "Zeus core" section without touching
  any key already there.

Confirmed via a full real boot after all of the above: **46 blueprints (up
from 45), 397 routes (up from 389), 12/14 swarm agents healthy** — the same
2 pre-existing `pip install` gaps from Pass 3 (`uvicorn`, `pydantic`),
nothing newly broken.

### On the token you shared

You pasted a real personal ClickUp API token into the conversation to test
with. It was **not** written into any file or the delivered zip — testing
used a placeholder value against the local mock server instead, since the
real API wasn't reachable from here anyway. That token is now sitting in
this chat's history; regenerating it from ClickUp's **Settings → Apps → API
Token** page is a reasonable precaution if you're not comfortable with that.

---

## Pass 5: audit every file for self-registration in app.py

Request: check every file with a Blueprint (like `zeus_grok_bridge.py`) for
a working `register(app)` and confirm it's actually wired into `app.py`,
fixing any that aren't.

### Method

`app.py` turns out to have **three** separate registration helpers, not
one: `_register(module, bp_name)` (older, direct attribute access),
`_register_fn(module)` (newer, calls `mod.register(app)`), and
`_register_tartarus(module)` (a third, separately-named one — functionally
identical to `_register_fn`, used only for the 9 Tartarus files). Diffed
every file defining `= Blueprint(` (49 files) against every module name
passed to any of the three helpers.

**First pass missed the third helper** — a plain grep for `_register_fn("`
and `_register("` doesn't match `_register_tartarus("`, since that string
doesn't contain the literal substring `_register(` immediately followed by
an open-paren. That produced a false positive: it looked like all 9
`zeus_tartarus_*` files were never registered, when they actually already
were, correctly, via `_register_tartarus()`. Caught this **before** it
caused damage by testing the fix: adding a second registration for those 9
produced `"name already registered"` errors on boot — caught harmlessly by
the same try/except every helper here already uses, but redundant. Reverted
immediately, then re-ran the diff correctly accounting for all three helper
names.

### The one genuine gap: `zeus_hive_bridge.py`

Had a real Blueprint (two, actually — `zeus_hive_bp` and `ump_hive_bp`) and
a working registration function, but that function is named
`register_zeus_bridge(app)`, not `register(app)`, and was only ever called
from `wsgi_zeus.py` — never from `app.py` itself. Fixed two ways:
- Added a thin `register(app)` alias inside `zeus_hive_bridge.py` that
  calls `register_zeus_bridge(app)`, so it fits the same
  `_register_fn(module_name)` convention as every other bridge.
- Added `_register_fn("zeus_hive_bridge")` to `app.py` as Layer 13.

**Safe even when running under gunicorn via `wsgi_zeus.py`, which still
separately calls `register_zeus_bridge(app)` on the same `app` object:**
checked both potential double-registration hazards directly rather than
assuming —
- the blueprint registration inside `register_zeus_bridge()` is already
  wrapped in try/except and only logs a warning on a duplicate name
- `HiveSyncLoop.start()` is already idempotent (`if self._thread and
  self._thread.is_alive(): return`) — confirmed by reading it, not assumed

So calling it from both places produces one extra harmless log line and one
extra duplicate `"system_boot"` hive event, never a crash or a second
background thread.

### Result — verified by a real full boot, not assumed

Every one of the 49 files defining a Flask Blueprint now registers
somewhere in `app.py` under one of the three helper names — confirmed by
re-running the diff after the fix and getting an empty result. Full clean
boot capturing every registration log line: the **only** two failures
anywhere in the entire app are the same pre-existing pip gaps from Pass 3/4
(`zeus_synthesis` needs `uvicorn`, `zeus_skill_factory_bridge` needs
`pydantic`) — nothing else silently fails, including all 31 older-style
`_register(module, bp_name)` calls, which were also checked for a
mismatched blueprint variable name and found correct.

**47 blueprints, 421 routes** (up from 46/397 — the Hive Mind Bridge's 24
`/api/hive/*` routes were the only ones actually missing from a running
app; the 9 Tartarus files' 41 `/api/tartarus/*` routes were there all
along).

---

## Pass 6: full-session consistency audit + real runtime testing (not just import/registration)

Request: review every zip/fix across this entire conversation, merge any
duplicate files without losing anything, and produce one definitive zip —
explicitly because "completely fixed" had turned out to be wrong more than
once, and a repeated pattern of that isn't acceptable.

### Step 1 — cross-checked every file duplicated anywhere in the tree

Found 55 duplicate filenames across the whole zip. Broke down where each
one actually comes from before touching anything:

- **~45 of them**: `zeus_hive_final_genome_patched/` (and its `zeus_arch/`,
  `zeus_firewall/` subfolders) vs `SPEARHEAD_CLEAN/` — this is the **old,
  pre-GovInt-merge build kept alongside the new canonical one**, from
  before this conversation started. `SPEARHEAD_CLEAN` is authoritative;
  that folder is historical reference only. Left untouched — merging it
  in would resurrect superseded code, not fix anything.
- **9 of them**: `zeus_skill_factory/src/*.py` vs the two copies inside
  `SPEARHEAD_CLEAN` (`src/` and `skill_factory_src/`) — see the real bug
  below.
- **3 of them**: `zeus_immune_system/*.py` / unified-root `tests/*.py` vs
  their `SPEARHEAD_CLEAN` copies — diffed byte-for-byte: **identical**, no
  drift, nothing to reconcile.
- **1 of them**: `zeus_hive_bridge.py` — diffed byte-for-byte against the
  `zeus_hive_final_genome_patched/` copy it was restored from; the only
  difference is the `register(app)` alias added afterward. Expected,
  intentional, not a bug (that legacy folder is frozen/historical, per
  above).

**The one real duplicate-file bug**: a stray `SPEARHEAD_CLEAN/src/`
directory — leftover from an early test run of `zeus_swarm_deps_sync.sh`,
in the same session, before the `src` → `skill_factory_src` rename was
made to avoid the collision risk flagged back then. Confirmed nothing
referenced bare `src` anymore (grepped the whole tree), then deleted it.
Rebooted clean before and after: 47 blueprints, 421 routes, no change —
confirming it really was dead.

### Step 2 — actually invoked routes, not just checked they register

Every prior pass checked that modules import and blueprints register
without error. None of them actually **called** the routes. This pass did,
and it found two different classes of problem that only show up at
request time:

**A genuinely dangerous discovery**: this codebase has a live, autonomous
self-mutation engine, and hitting `/api/stress/run` — which accepts `GET`,
not just `POST` — triggered it *for real* during testing. It rewrote
dozens of source files on disk in place (confirmed via file mtimes and new
`evolved_modules/` snapshots) and, in the process, **introduced a genuine
new bug**: a duplicated `zeus_tartarus_core_health` function definition
that broke Flask registration. This is not something "fixed" here — the
contaminated working tree was discarded entirely and rebuilt fresh from
the last known-good zip (confirmed clean by re-extracting and checking
before continuing). **Flagging this as a real design concern for you to
decide on**, not silently changed: a state-mutating, potentially
destructive operation being reachable via a plain `GET` request violates
normal HTTP semantics (GET should be safe/idempotent) and means simply
*browsing* the app can trigger source-rewriting side effects. Worth
considering whether `/api/stress/run` should drop `GET` entirely.

**Three real, ordinary runtime bugs**, found by then re-testing with
`/api/stress/*` and other action-like routes excluded, and fixed:

1. **`zeus_tartarus_monitor.py`** — 3 of 5 entries in `STREAM_DEFS` used
   `"label"` where `StreamState.__init__` reads `stream_def["name"]"` —
   simple key-naming inconsistency (the other 2 entries already correctly
   used `"name"`). Broke `/api/tartarus/monitor/streams`,
   `/api/tartarus/monitor/summary`, and `/api/tartarus/monitor/stream/events`
   with a `KeyError`. Fixed: standardized all 5 to `"name"`.
2. **`zeus_upload.py`** — `uploaded_files` was referenced in `INSERT`/
   `UPDATE`/`SELECT` throughout the file but **never created anywhere** —
   not in this file, not in `db_init.py`. Every call to `/api/upload/list`
   (and any other route touching that table) failed with
   `no such table: uploaded_files`. Fixed: added a
   `CREATE TABLE IF NOT EXISTS` inside `_db()`, columns matched exactly to
   what the existing `INSERT`/`UPDATE` statements already write, guarded by
   the same idempotent-flag pattern already used in
   `zeus_swarm_orchestrator.py`.
3. **`zeus_govint_blueprint.py`** — `/api/alerts` selected `ad.auth_level`,
   a column that **doesn't exist** in `authorization_documents` (confirmed
   against its real `CREATE TABLE` in `zeus_geo_auth.py`: doc_id, doc_type,
   issuing_authority, case_number, target_identifier, issued_utc,
   expires_utc, authorized_by, document_hash, signature_b64,
   signature_verified, rica_compliant, uploaded_utc, upload_ip,
   upload_user — no `auth_level`, no obvious rename candidate either).
   **Did not guess at the intended business meaning.** Swapped in
   `NULL AS auth_level` so the response shape is preserved and the crash
   is gone, with a comment flagging that `doc_type` is the closest real
   candidate if you want this field to mean something — your call, not
   assumed here.

Two routes (`/api/hive/stream/mining`, `/api/hive/stream/threats`) showed
as "timeouts" under a 3-second test cutoff — these are Server-Sent-Events
streaming endpoints that hold the connection open by design, not bugs.

### Result

Full clean boot: **47 blueprints, 421 routes, zero registration errors**.
Full safe-route sweep (159 routes, deliberately excluding anything
plausibly action-triggering): **145×200, 3×400, 1×404, 10×503, zero 500s,
zero exceptions**. The 503s are the correctly-configured-off cloud
LLM/ClickUp bridges; the 400s/404 are this test script guessing at a
couple of parameterized paths, not app bugs. Zero mutation-engine
contamination in the final tree, confirmed by an empty `evolved_modules/`
both before and after this pass's testing.

---

## Pass 7: verified every route excluded from Pass 6's sweep

Pass 6 excluded ~93 routes from live testing based on their names alone
(anything containing "stress", "mutat", "evolution", "run", etc.) after
one of them turned out to genuinely trigger the self-mutation engine. That
was the right precaution at the time but too broad — most of those 93 were
excluded on a name match, not a confirmed risk.

This pass went back through all 93 individually:
- Read the actual handler source for every route that sounded genuinely
  dangerous (`/api/executor/run/shell`, `/api/executor/run/python`,
  `/api/sandbox/run/shell`, `/api/sovereignty/execute`,
  `/drone/api/mission/execute`) **before** calling any of them — confirmed
  each one validates required fields and fails closed on empty/missing
  input (e.g. `_run_shell` returns `"No command provided"` and never
  reaches `subprocess.run` if the `command` field is absent).
- Tested all 93 in a disposable copy of the tree — never the deliverable
  — specifically because routes like `/api/evolution/trigger` genuinely
  run a real cycle unconditionally by design (no field validation blocks
  it), so testing them for real was expected to cause real side effects
  in that disposable copy.

**Result: 40×200 + 3×404 (GET, all 3 confirmed intentional —
"no report yet" style responses) and 19×200 + 15×400 + 1×404 (POST, all
correct — proper validation or intentional "not found" semantics). Zero
500s, zero exceptions, zero timeouts across all 93.**

No code changes this pass — this was pure verification, and everything
already worked. Confirmed the golden `SPEARHEAD_CLEAN` copy in this zip was
never touched by this testing (checked `evolved_modules/` stayed empty and
re-ran a clean boot: still 47 blueprints / 421 routes, zero errors).

### What's still genuinely untested, for the record

- Every parameterized route (`/task/<id>` etc.) — no real IDs were available
  to call these meaningfully
- Real API keys for any cloud LLM or ClickUp — all testing ran in
  offline/disabled mode
- The actual armv7l/Android/UserLAnd target hardware — everything above ran
  on x86_64 Linux
- Whether route *outputs* are business-logic-correct, as opposed to
  not-crashing — this pass verifies the latter, not the former
