"""
zeus_geo_auth.py
================
Zeus GovInt — Cryptographic Authorization Gate
Author: Francois Nel | The Zeus Project 2026

Validates RICA warrants and institutional authorization documents
using RSA/ECDSA digital signatures before any carrier-level
geolocation capability is unlocked.

Architecture:
  ┌─────────────────────────────────────────┐
  │  AuthorizationGate (this module)        │
  │  ─────────────────────────────────────  │
  │  Document Upload → Signature Verify     │
  │  RICA Compliance Check                  │
  │  Institutional Cert Verify              │
  │  Audit Log Entry (immutable)            │
  │  ──────────────────────────────────     │
  │  LOCKED until all 3 checks pass         │
  └─────────────────────────────────────────┘
"""
from __future__ import annotations
import base64, hashlib, hmac as _hmac, json, logging, os
import sqlite3, threading, time, uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("zeus.geo_auth")

# ── Enums & Constants ─────────────────────────────────────────────────────────

class AuthLevel(Enum):
    NONE             = 0
    IP_GEOLOCATION   = 1   # Public API — no warrant needed
    SUBSCRIBER_QUERY = 2   # Requires court order (RICA s205)
    CARRIER_CSLI     = 3   # Requires high court warrant (RICA s27)
    PRIORITY_CSLI    = 4   # National security — requires NSL equivalent

class DocumentType(Enum):
    RICA_COURT_ORDER      = "rica_court_order"
    HIGH_COURT_WARRANT    = "high_court_warrant"
    NATIONAL_SECURITY     = "national_security_directive"
    INSTITUTIONAL_CERT    = "institutional_certificate"

ISSUING_AUTHORITIES_ZA = [
    "South African Police Service",
    "Directorate for Priority Crime Investigation",
    "State Security Agency",
    "National Prosecuting Authority",
    "Gauteng High Court",
    "Western Cape High Court",
    "KwaZulu-Natal High Court",
    "Eastern Cape High Court",
    "Free State High Court",
    "Department of Defence",
    "South African National Defence Force",
]

# ── Authorization Document ────────────────────────────────────────────────────

@dataclass
class AuthDocument:
    doc_id: str
    doc_type: DocumentType
    issuing_authority: str
    case_number: str
    target_identifier: str          # IP, MSISDN, or IMSI
    issued_utc: str
    expires_utc: str
    authorized_by: str              # Judge / Director name
    document_hash: str              # SHA-256 of raw document bytes
    signature_b64: Optional[str] = None  # RSA/ECDSA signature from issuing authority
    signature_verified: bool = False
    rica_compliant: bool = False
    uploaded_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def is_expired(self) -> bool:
        try:
            exp = datetime.fromisoformat(self.expires_utc.replace("Z","+00:00"))
            return datetime.now(timezone.utc) > exp
        except Exception:
            return True

    def to_dict(self) -> Dict:
        return {k: (v.value if isinstance(v, Enum) else v) for k, v in asdict(self).items()}

# ── AuthorizationGate ─────────────────────────────────────────────────────────

class AuthorizationGate:
    """
    Cryptographic gate that must be passed before any carrier
    geolocation capability activates. Uses SQLite for immutable
    audit trail.
    """

    def __init__(self, db_path: str = "govint_warrants.db",
                 trusted_ca_cert_path: Optional[str] = None):
        self.db_path = db_path
        self._trusted_ca_cert_path = trusted_ca_cert_path
        self._lock = threading.Lock()
        self._active_documents: Dict[str, AuthDocument] = {}
        self._init_database()
        log.info("AuthorizationGate initialized. DB: %s", db_path)

    def _init_database(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS authorization_documents (
                    doc_id TEXT PRIMARY KEY,
                    doc_type TEXT NOT NULL,
                    issuing_authority TEXT NOT NULL,
                    case_number TEXT NOT NULL,
                    target_identifier TEXT NOT NULL,
                    issued_utc TEXT NOT NULL,
                    expires_utc TEXT NOT NULL,
                    authorized_by TEXT NOT NULL,
                    document_hash TEXT NOT NULL,
                    signature_b64 TEXT,
                    signature_verified INTEGER DEFAULT 0,
                    rica_compliant INTEGER DEFAULT 0,
                    uploaded_utc TEXT NOT NULL,
                    upload_ip TEXT,
                    upload_user TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS authorization_audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp_utc TEXT NOT NULL,
                    epoch REAL NOT NULL,
                    doc_id TEXT,
                    action TEXT NOT NULL,
                    target_identifier TEXT,
                    auth_level TEXT,
                    operator TEXT,
                    result TEXT,
                    detail TEXT,
                    audit_hash TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS geolocation_queries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    query_id TEXT NOT NULL,
                    timestamp_utc TEXT NOT NULL,
                    epoch REAL NOT NULL,
                    doc_id TEXT NOT NULL,
                    target_identifier TEXT NOT NULL,
                    query_type TEXT NOT NULL,
                    result_lat REAL,
                    result_lon REAL,
                    accuracy_meters REAL,
                    method TEXT,
                    operator TEXT,
                    chain_hash TEXT NOT NULL
                )
            """)

    def _audit(self, action: str, doc_id: Optional[str] = None,
               target: Optional[str] = None, auth_level: Optional[str] = None,
               operator: str = "system", result: str = "OK", detail: str = "") -> None:
        ts = datetime.now(timezone.utc).isoformat()
        epoch = time.time()
        raw = f"{ts}|{action}|{doc_id}|{target}|{result}|{detail}|{epoch}"
        audit_hash = hashlib.sha3_256(raw.encode()).hexdigest()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO authorization_audit
                (timestamp_utc,epoch,doc_id,action,target_identifier,auth_level,operator,result,detail,audit_hash)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, (ts, epoch, doc_id, action, target, auth_level, operator, result, detail, audit_hash))
        log.info("AUDIT [%s] %s → %s | %s", action, target or "-", result, detail[:80])

    def submit_document(self, doc_bytes: bytes, metadata: Dict,
                        operator: str = "unknown") -> Tuple[bool, str, Optional[AuthDocument]]:
        """
        Submit an authorization document for validation.
        Returns (success, message, AuthDocument | None)
        """
        doc_hash = hashlib.sha256(doc_bytes).hexdigest()
        doc_type_str = metadata.get("doc_type", "")
        try:
            doc_type = DocumentType(doc_type_str)
        except ValueError:
            self._audit("SUBMIT_REJECTED", detail=f"Unknown doc_type: {doc_type_str}", operator=operator)
            return False, f"Unknown document type: {doc_type_str}", None

        issuing_authority = metadata.get("issuing_authority", "")
        if issuing_authority not in ISSUING_AUTHORITIES_ZA:
            self._audit("SUBMIT_REJECTED", detail=f"Unknown authority: {issuing_authority}", operator=operator)
            return False, f"Issuing authority not recognized: {issuing_authority}", None

        doc = AuthDocument(
            doc_id=str(uuid.uuid4()),
            doc_type=doc_type,
            issuing_authority=issuing_authority,
            case_number=metadata.get("case_number", ""),
            target_identifier=metadata.get("target_identifier", ""),
            issued_utc=metadata.get("issued_utc", ""),
            expires_utc=metadata.get("expires_utc", ""),
            authorized_by=metadata.get("authorized_by", ""),
            document_hash=doc_hash,
            signature_b64=metadata.get("signature_b64"),
        )

        # Step 1: Verify document signature
        sig_ok, sig_msg = self._verify_signature(doc_bytes, doc.signature_b64)
        doc.signature_verified = sig_ok

        # Step 2: RICA compliance check
        rica_ok, rica_msg = self._check_rica_compliance(doc)
        doc.rica_compliant = rica_ok

        # Step 3: Persist to DB
        self._persist_document(doc, operator)

        if sig_ok and rica_ok:
            with self._lock:
                self._active_documents[doc.target_identifier] = doc
            self._audit("DOCUMENT_APPROVED", doc_id=doc.doc_id,
                       target=doc.target_identifier,
                       auth_level=self._get_auth_level(doc).name,
                       operator=operator, result="APPROVED",
                       detail=f"{doc_type.value} | {issuing_authority}")
            log.info("Document APPROVED: %s for %s", doc.doc_id, doc.target_identifier)
            return True, "Document validated and approved.", doc
        else:
            reasons = []
            if not sig_ok: reasons.append(f"Signature: {sig_msg}")
            if not rica_ok: reasons.append(f"RICA: {rica_msg}")
            self._audit("DOCUMENT_REJECTED", doc_id=doc.doc_id,
                       target=doc.target_identifier, operator=operator,
                       result="REJECTED", detail=" | ".join(reasons))
            return False, " | ".join(reasons), doc

    def _verify_signature(self, doc_bytes: bytes, signature_b64: Optional[str]) -> Tuple[bool, str]:
        """
        Verify RSA/ECDSA signature on document.
        In production: uses CA cert from trusted_ca_cert_path.
        Falls back to HMAC-SHA256 verification for demo/test certs.
        """
        if not signature_b64:
            return False, "No signature provided"
        try:
            sig_bytes = base64.b64decode(signature_b64)
        except Exception:
            return False, "Invalid base64 signature encoding"

        # RSA/ECDSA path (requires cryptography library)
        if self._trusted_ca_cert_path and os.path.exists(self._trusted_ca_cert_path):
            try:
                from cryptography.hazmat.primitives import hashes, serialization
                from cryptography.hazmat.primitives.asymmetric import ec, rsa, padding
                from cryptography import x509

                with open(self._trusted_ca_cert_path, "rb") as f:
                    cert = x509.load_pem_x509_certificate(f.read())
                public_key = cert.public_key()

                if isinstance(public_key, ec.EllipticCurvePublicKey):
                    from cryptography.hazmat.primitives.asymmetric.ec import ECDSA
                    public_key.verify(sig_bytes, doc_bytes, ECDSA(hashes.SHA256()))
                    return True, "ECDSA signature verified against trusted CA"
                elif isinstance(public_key, rsa.RSAPublicKey):
                    public_key.verify(sig_bytes, doc_bytes,
                                     padding.PKCS1v15(), hashes.SHA256())
                    return True, "RSA signature verified against trusted CA"
                else:
                    return False, "Unsupported key type in CA certificate"
            except Exception as e:
                return False, f"Signature verification failed: {str(e)[:100]}"

        # HMAC fallback for test/demo environments
        # In production this path should be disabled
        doc_hash = hashlib.sha256(doc_bytes).digest()
        test_secret = os.environ.get("GOVINT_TEST_SIGNING_SECRET", "")
        if test_secret:
            expected = _hmac.new(test_secret.encode(), doc_hash, hashlib.sha256).digest()
            try:
                provided = base64.b64decode(signature_b64)
                if _hmac.compare_digest(expected, provided):
                    return True, "HMAC-SHA256 test signature verified (DEMO MODE)"
                return False, "HMAC signature mismatch"
            except Exception as e:
                return False, f"HMAC verification error: {e}"

        return False, "No trusted CA certificate configured and no test secret set"

    def _check_rica_compliance(self, doc: AuthDocument) -> Tuple[bool, str]:
        """
        Validates RICA (Regulation of Interception of Communications Act 70 of 2002)
        compliance requirements.
        """
        if not doc.case_number or len(doc.case_number) < 3:
            return False, "Missing or invalid case number"
        if not doc.authorized_by or len(doc.authorized_by) < 3:
            return False, "Missing authorized_by field"
        if not doc.target_identifier:
            return False, "Missing target identifier"
        if doc.is_expired():
            return False, f"Document expired: {doc.expires_utc}"

        # RICA section requirements by document type
        if doc.doc_type == DocumentType.HIGH_COURT_WARRANT:
            if "court" not in doc.issuing_authority.lower():
                return False, "HIGH_COURT_WARRANT requires court issuing authority"
            return True, "RICA s27 High Court Warrant — compliant"

        if doc.doc_type == DocumentType.RICA_COURT_ORDER:
            return True, "RICA s205 Court Order — compliant"

        if doc.doc_type == DocumentType.NATIONAL_SECURITY:
            if doc.issuing_authority not in ["State Security Agency","Department of Defence",
                                              "South African National Defence Force"]:
                return False, "National security directive requires SSA or DOD authority"
            return True, "National Security Directive — compliant"

        if doc.doc_type == DocumentType.INSTITUTIONAL_CERT:
            return True, "Institutional Certificate — compliant"

        return False, f"Unhandled document type: {doc.doc_type}"

    def _persist_document(self, doc: AuthDocument, operator: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO authorization_documents
                (doc_id,doc_type,issuing_authority,case_number,target_identifier,
                 issued_utc,expires_utc,authorized_by,document_hash,signature_b64,
                 signature_verified,rica_compliant,uploaded_utc,upload_user)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (doc.doc_id, doc.doc_type.value, doc.issuing_authority, doc.case_number,
                  doc.target_identifier, doc.issued_utc, doc.expires_utc, doc.authorized_by,
                  doc.document_hash, doc.signature_b64, int(doc.signature_verified),
                  int(doc.rica_compliant), doc.uploaded_utc, operator))

    def get_auth_level(self, target_identifier: str) -> AuthLevel:
        """Returns the current authorization level for a target.
        Checks in-memory cache first, then falls back to the persisted
        database so authorization survives process restarts."""
        with self._lock:
            doc = self._active_documents.get(target_identifier)
        if doc:
            if doc.is_expired() or not doc.signature_verified or not doc.rica_compliant:
                return AuthLevel.IP_GEOLOCATION
            return self._get_auth_level(doc)

        # Not in memory — check persisted DB (handles restarts / new process)
        row = self._load_active_document_from_db(target_identifier)
        if not row:
            return AuthLevel.IP_GEOLOCATION
        doc = self._row_to_auth_document(row)
        if doc.is_expired() or not doc.signature_verified or not doc.rica_compliant:
            return AuthLevel.IP_GEOLOCATION
        with self._lock:
            self._active_documents[target_identifier] = doc
        return self._get_auth_level(doc)

    def _load_active_document_from_db(self, target_identifier: str) -> Optional[Tuple]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT doc_id, doc_type, issuing_authority, case_number,
                       target_identifier, issued_utc, expires_utc, authorized_by,
                       document_hash, signature_b64, signature_verified, rica_compliant,
                       uploaded_utc
                FROM authorization_documents
                WHERE target_identifier = ? AND signature_verified=1 AND rica_compliant=1
                ORDER BY uploaded_utc DESC LIMIT 1
            """, (target_identifier,))
            return cursor.fetchone()

    @staticmethod
    def _row_to_auth_document(row: Tuple) -> AuthDocument:
        return AuthDocument(
            doc_id=row[0], doc_type=DocumentType(row[1]), issuing_authority=row[2],
            case_number=row[3], target_identifier=row[4], issued_utc=row[5],
            expires_utc=row[6], authorized_by=row[7], document_hash=row[8],
            signature_b64=row[9], signature_verified=bool(row[10]),
            rica_compliant=bool(row[11]), uploaded_utc=row[12],
        )

    def _get_auth_level(self, doc: AuthDocument) -> AuthLevel:
        mapping = {
            DocumentType.INSTITUTIONAL_CERT:   AuthLevel.IP_GEOLOCATION,
            DocumentType.RICA_COURT_ORDER:     AuthLevel.SUBSCRIBER_QUERY,
            DocumentType.HIGH_COURT_WARRANT:   AuthLevel.CARRIER_CSLI,
            DocumentType.NATIONAL_SECURITY:    AuthLevel.PRIORITY_CSLI,
        }
        return mapping.get(doc.doc_type, AuthLevel.IP_GEOLOCATION)

    def log_geolocation_query(self, doc_id: str, target: str, query_type: str,
                               lat: float, lon: float, accuracy: float,
                               method: str, operator: str = "system") -> str:
        """Immutably logs every geolocation query for chain-of-custody."""
        query_id = str(uuid.uuid4())
        ts = datetime.now(timezone.utc).isoformat()
        epoch = time.time()
        raw = f"{query_id}|{ts}|{doc_id}|{target}|{lat}|{lon}|{accuracy}|{method}"
        chain_hash = hashlib.sha3_256(raw.encode()).hexdigest()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO geolocation_queries
                (query_id,timestamp_utc,epoch,doc_id,target_identifier,query_type,
                 result_lat,result_lon,accuracy_meters,method,operator,chain_hash)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """, (query_id, ts, epoch, doc_id, target, query_type,
                  lat, lon, accuracy, method, operator, chain_hash))
        self._audit("GEO_QUERY", doc_id=doc_id, target=target,
                   result="LOGGED", detail=f"method={method} lat={lat:.4f} lon={lon:.4f}")
        return query_id

    def get_active_warrants(self) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT doc_id, doc_type, issuing_authority, case_number,
                       target_identifier, expires_utc, authorized_by,
                       signature_verified, rica_compliant
                FROM authorization_documents
                WHERE signature_verified=1 AND rica_compliant=1
                ORDER BY uploaded_utc DESC
            """)
            cols = [d[0] for d in cursor.description]
            return [dict(zip(cols, row)) for row in cursor.fetchall()]

    def get_audit_log(self, limit: int = 100) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT timestamp_utc, action, doc_id, target_identifier,
                       auth_level, operator, result, detail
                FROM authorization_audit
                ORDER BY epoch DESC LIMIT ?
            """, (limit,))
            cols = [d[0] for d in cursor.description]
            return [dict(zip(cols, row)) for row in cursor.fetchall()]

    def revoke_document(self, doc_id: str, operator: str = "system") -> bool:
        with self._lock:
            for target, doc in list(self._active_documents.items()):
                if doc.doc_id == doc_id:
                    del self._active_documents[target]
                    self._audit("DOCUMENT_REVOKED", doc_id=doc_id,
                               target=target, operator=operator, result="REVOKED")
                    log.info("Document revoked: %s by %s", doc_id, operator)
                    return True
        return False
