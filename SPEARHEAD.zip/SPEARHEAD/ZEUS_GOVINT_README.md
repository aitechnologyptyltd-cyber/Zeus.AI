# Zeus GovInt v1.0

**AEGIS-FIELD tamper detection + cryptographically-gated geolocation intelligence
for Zeus v8.**

Author: Francois Nel | The Zeus Project 2026

---

## What this is

This module combines two systems:

1. **AEGIS-FIELD v1.0.0** — a fully implemented, standalone tamper-evident /
   anti-reverse-engineering engine. Hardware-rooted trust anchor (TPM/HSM/
   Android Keystore/software fallback), AES-256-GCM encrypted vault, 17
   live security checks, DoD 5220.22-M secure wipe, deception/honeypot
   modes, and HMAC-signed forensic evidence bundles mapped to MITRE ATT&CK.

2. **Zeus GeoIntel** — a tiered geolocation intelligence module. IP-level
   geolocation (via public APIs) is always available with no authorization
   required. Carrier-level subscriber data and Cell Site Location
   Information (CSLI) are locked behind a cryptographic **Authorization
   Gate** that validates digitally signed RICA/court documents before
   unlocking each tier.

## What this is NOT

This module does **not** include, and will never include:

- SS7/DIAMETER signaling interception
- Real-time carrier triangulation infrastructure
- Drone targeting or terminal guidance integration
- Any bulk/dragnet collection capability

The `CarrierCSLIInterface` class defines the integration *contract* (what a
request/response looks like) but the actual carrier endpoints
(`CARRIER_VODACOM_ENDPOINT` etc.) are environment variables that must be
populated by your organisation's signed Memorandum of Understanding with
each network operator's lawful intercept department. Until that MOU exists
and the endpoint is configured, those calls return
`CARRIER_ENDPOINT_NOT_CONFIGURED` with the appropriate action item. This is
intentional and documented in `ZEUS_GOVINT_TECHNICAL_REFERENCE.pdf`.

## Authorization tiers

| Tier | Document Required | Unlocks |
|---|---|---|
| 0 — IP_GEOLOCATION | None | Public IP geolocation API (city-level, ~25km) |
| 1 — SUBSCRIBER_QUERY | RICA s205 Court Order | Subscriber database query (name/address, pending carrier MOU) |
| 2 — CARRIER_CSLI | High Court Warrant (RICA s27) | Cell tower CSLI (pending carrier MOU) |
| 3 — PRIORITY_CSLI | National Security Directive (SSA/DOD) | Priority carrier response (pending carrier MOU) |

Every document must carry a valid digital signature (ECDSA P-256 by
default) verified against your organisation's CA certificate, plus pass
RICA compliance checks (case number, authorizing officer, expiry, issuing
authority whitelist) before any tier above 0 activates. Unsigned, expired,
or tampered documents are rejected and logged.

## Quick start

```bash
pip install -r requirements.txt --break-system-packages

# Generate your organisation's signing keypair (do this ONCE, store the
# private key securely — e.g. with your legal/compliance officer, NOT on
# the application server)
python3 zeus_geo_signing_tool.py generate-ca --out /secure/location/ca_keys

# On the application server, only the PUBLIC cert is needed:
export GOVINT_CA_CERT_PATH=/secure/location/ca_keys/ca_public_cert.pem
```

### Integrating into Zeus v8's `app.py`

Add one line alongside the other `_register_fn` / `_register` calls:

```python
_register_fn("zeus_govint_blueprint")
```

The dashboard will be available at `/govint/dashboard` and the API at
`/govint/api/...`.

### Signing a real authorization document

```bash
python3 zeus_geo_signing_tool.py build-sample \
    --doc-type high_court_warrant \
    --target 196.12.34.56 \
    --case CASE-2026-001 \
    --authority "Gauteng High Court" \
    --authorized-by "Judge M. Naidoo" \
    --out warrant.json

python3 zeus_geo_signing_tool.py sign \
    --doc warrant.json \
    --key /secure/location/ca_keys/ca_private_key.pem \
    --out warrant_signature.json
```

Submit both through the dashboard's Warrants tab, or via
`POST /govint/api/warrant/submit`.

## Testing without real carrier access

Set `GOVINT_TEST_SIGNING_SECRET` to enable an HMAC-SHA256 demo signing path
instead of ECDSA. This is clearly logged as `DEMO MODE` in the audit trail
and should be disabled (unset) in any real deployment.

## File map

```
zeus_govint/
├── aegis_field/                  AEGIS-FIELD package (5 modules)
│   ├── aegis_trust.py             Hardware trust anchor + AES-256-GCM vault
│   ├── aegis_detect.py            17 live security checks across 5 engines
│   ├── aegis_response.py          Lock / wipe / deception / honeypot
│   ├── aegis_forensic.py          MITRE ATT&CK mapped evidence bundles
│   └── aegis_master.py            Orchestrator (AegisFieldEngine)
├── zeus_geo_auth.py               Cryptographic Authorization Gate
├── zeus_geo_intel.py               Tiered geolocation (IP always-on, carrier gated)
├── zeus_geo_signing_tool.py        CLI: generate CA keys, sign documents
├── zeus_govint_blueprint.py        Flask blueprint + LE dashboard
├── requirements.txt
└── ZEUS_GOVINT_TECHNICAL_REFERENCE.pdf
```
