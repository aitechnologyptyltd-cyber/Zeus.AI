# The Zeus Project 2026 — Francois Nel
# db_init.py — SQLite Foundation Layer
# WAL mode · full schema · retry wrapper · health check · migration support
# All Zeus modules depend on this — it must be rock solid.

import os
import time
import sqlite3
import logging
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Callable, List, Optional, Tuple

log = logging.getLogger("zeus.db")

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(ZEUS_DIR, "zeus.db")

# ============================================================================
# THREAD-SAFE CONNECTION POOL
# ============================================================================

_pool_lock     = threading.RLock()
_connections: List[sqlite3.Connection] = []
_POOL_SIZE     = 8
_DB_TIMEOUT    = 30   # seconds
_RETRY_COUNT   = 5
_RETRY_SLEEP   = 0.25 # seconds between retries

DB_SCHEMA_VERSION = 7   # increment when schema changes


# ============================================================================
# CONNECTION FACTORY
# ============================================================================

def get_db() -> sqlite3.Connection:
    """
    Open a WAL-mode SQLite connection.
    WAL allows concurrent readers + one writer — no reader/writer deadlock.
    Pragmas tuned for ARM / low-memory devices (armv7l, Hisense Y82 Pro).
    """
    conn = sqlite3.connect(DB_PATH, timeout=_DB_TIMEOUT, check_same_thread=False)
    conn.row_factory    = sqlite3.Row
    conn.isolation_level = None         # autocommit by default; callers use explicit transactions
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")       # fsync only on checkpoint
        conn.execute("PRAGMA cache_size=-8000")         # 8 MB page cache
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA mmap_size=134217728")      # 128 MB memory-mapped I/O
        conn.execute("PRAGMA wal_autocheckpoint=1000")  # checkpoint every 1000 pages
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=20000")       # 20 s wait on busy lock
    except sqlite3.OperationalError as e:
        log.warning(f"[DB] Pragma set failed (non-fatal): {e}")
    return conn


@contextmanager
def db_transaction():
    """
    Context manager for explicit transactions with retry on lock.

    Usage:
        with db_transaction() as conn:
            conn.execute("INSERT INTO ...")
    """
    conn = get_db()
    try:
        conn.execute("BEGIN")
        yield conn
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            pass
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass


def retry_db(fn: Callable[[sqlite3.Connection], Any],
             retries: int = _RETRY_COUNT,
             sleep_s: float = _RETRY_SLEEP) -> Any:
    """
    Execute fn(conn) with automatic retry on SQLite OperationalError (e.g. database locked).
    Opens a fresh connection per attempt.

    Example:
        result = retry_db(lambda c: c.execute("SELECT COUNT(*) FROM genome").fetchone()[0])
    """
    last_err: Optional[Exception] = None
    for attempt in range(retries):
        conn = get_db()
        try:
            result = fn(conn)
            conn.close()
            return result
        except sqlite3.OperationalError as e:
            conn.close()
            last_err = e
            if attempt < retries - 1:
                wait = sleep_s * (2 ** attempt)   # exponential back-off
                log.debug(f"[DB] Retry {attempt + 1}/{retries}: {e} — waiting {wait:.2f}s")
                time.sleep(wait)
        except Exception as e:
            conn.close()
            raise
    raise last_err or RuntimeError("retry_db: all retries exhausted")


# ============================================================================
# FULL SCHEMA
# ============================================================================

_DDL_STATEMENTS = [

    # ---- GENOME — core DNA store ----------------------------------------
    """
    CREATE TABLE IF NOT EXISTS genome (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        name          TEXT NOT NULL UNIQUE,
        description   TEXT DEFAULT '',
        module_type   TEXT DEFAULT 'cognitive',
        source_code   TEXT DEFAULT '',
        version       TEXT DEFAULT 'v1.0',
        priority      INTEGER DEFAULT 50,
        capabilities  TEXT DEFAULT '',
        lineage       TEXT DEFAULT '',
        fitness_score REAL  DEFAULT 0.0,
        mutation_count INTEGER DEFAULT 0,
        created_at    TEXT DEFAULT (datetime('now')),
        updated_at    TEXT DEFAULT (datetime('now'))
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_genome_priority ON genome(priority DESC)",
    "CREATE INDEX IF NOT EXISTS idx_genome_type     ON genome(module_type)",
    "CREATE INDEX IF NOT EXISTS idx_genome_fitness  ON genome(fitness_score DESC)",

    # ---- KNOWLEDGE — articles / facts saved by learner -------------------
    """
    CREATE TABLE IF NOT EXISTS knowledge (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        topic         TEXT NOT NULL,
        depth         TEXT NOT NULL DEFAULT 'Simple',
        content       TEXT NOT NULL,
        source_url    TEXT DEFAULT '',
        confidence    REAL DEFAULT 0.8,
        quality_score REAL DEFAULT 0.0,
        domain        TEXT DEFAULT '',
        tags          TEXT DEFAULT '',
        embedding_key TEXT DEFAULT '',
        created_at    TEXT DEFAULT (datetime('now')),
        updated_at    TEXT DEFAULT (datetime('now'))
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_knowledge_topic      ON knowledge(topic)",
    "CREATE INDEX IF NOT EXISTS idx_knowledge_depth      ON knowledge(depth)",
    "CREATE INDEX IF NOT EXISTS idx_knowledge_confidence ON knowledge(confidence DESC)",
    "CREATE INDEX IF NOT EXISTS idx_knowledge_domain     ON knowledge(domain)",
    """
    CREATE UNIQUE INDEX IF NOT EXISTS idx_knowledge_topic_depth
        ON knowledge(topic, depth)
    """,

    # ---- QUEUE — learning queue for recursive learner --------------------
    """
    CREATE TABLE IF NOT EXISTS queue (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        topic      TEXT NOT NULL,
        depth      TEXT NOT NULL DEFAULT 'Simple',
        priority   REAL DEFAULT 1.0,
        status     TEXT DEFAULT 'pending',
        attempts   INTEGER DEFAULT 0,
        max_attempts INTEGER DEFAULT 3,
        source     TEXT DEFAULT '',
        error_msg  TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_queue_status   ON queue(status)",
    "CREATE INDEX IF NOT EXISTS idx_queue_priority ON queue(priority DESC, id ASC)",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_queue_topic_depth ON queue(topic, depth)",

    # ---- BLUEPRINTS — forge output plans ---------------------------------
    """
    CREATE TABLE IF NOT EXISTS blueprints (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        blueprint_id    TEXT NOT NULL UNIQUE DEFAULT '',
        goal            TEXT NOT NULL,
        output_type     TEXT DEFAULT 'python_module',
        status          TEXT DEFAULT 'pending',
        plan_json       TEXT DEFAULT '{}',
        architecture    TEXT DEFAULT '',
        dna_context     TEXT DEFAULT '{}',
        forge_log       TEXT DEFAULT '',
        result_path     TEXT DEFAULT '',
        result_size     INTEGER DEFAULT 0,
        quality_score   REAL DEFAULT 0.0,
        stages_complete INTEGER DEFAULT 0,
        stages_total    INTEGER DEFAULT 5,
        error_msg       TEXT DEFAULT '',
        created_at      TEXT DEFAULT (datetime('now')),
        completed_at    TEXT DEFAULT ''
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_blueprints_status    ON blueprints(status)",
    "CREATE INDEX IF NOT EXISTS idx_blueprints_type      ON blueprints(output_type)",
    "CREATE INDEX IF NOT EXISTS idx_blueprints_quality   ON blueprints(quality_score DESC)",

    # ---- EXECUTOR JOBS — persistent task queue ---------------------------
    """
    CREATE TABLE IF NOT EXISTS executor_jobs (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id      TEXT NOT NULL UNIQUE,
        task_type   TEXT NOT NULL,
        payload     TEXT DEFAULT '{}',
        status      TEXT DEFAULT 'pending',
        result      TEXT DEFAULT '',
        error       TEXT DEFAULT '',
        priority    INTEGER DEFAULT 5,
        attempts    INTEGER DEFAULT 0,
        max_attempts INTEGER DEFAULT 3,
        worker_id   TEXT DEFAULT '',
        submitted_at TEXT DEFAULT (datetime('now')),
        started_at  TEXT DEFAULT '',
        completed_at TEXT DEFAULT ''
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_jobs_status   ON executor_jobs(status)",
    "CREATE INDEX IF NOT EXISTS idx_jobs_priority ON executor_jobs(priority DESC, id ASC)",
    "CREATE INDEX IF NOT EXISTS idx_jobs_type     ON executor_jobs(task_type)",

    # ---- CHAT HISTORY — conversation log ---------------------------------
    """
    CREATE TABLE IF NOT EXISTS chat_history (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id  TEXT DEFAULT 'default',
        role        TEXT NOT NULL,
        content     TEXT NOT NULL,
        engine      TEXT DEFAULT '',
        confidence  REAL DEFAULT 0.0,
        tokens_used INTEGER DEFAULT 0,
        reasoning_used INTEGER DEFAULT 0,
        logic_facts TEXT DEFAULT '[]',
        created_at  TEXT DEFAULT (datetime('now'))
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_chat_session    ON chat_history(session_id, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_chat_engine     ON chat_history(engine)",

    # ---- EVOLUTION LOG — nightly self-evolution records ------------------
    """
    CREATE TABLE IF NOT EXISTS evolution_log (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        cycle_id        TEXT NOT NULL UNIQUE,
        trigger         TEXT DEFAULT 'nightly',
        modules_audited INTEGER DEFAULT 0,
        gaps_found      INTEGER DEFAULT 0,
        gaps_filled     INTEGER DEFAULT 0,
        merges_ok       INTEGER DEFAULT 0,
        merges_failed   INTEGER DEFAULT 0,
        sandbox_passes  INTEGER DEFAULT 0,
        sandbox_fails   INTEGER DEFAULT 0,
        new_rules       INTEGER DEFAULT 0,
        duration_s      REAL DEFAULT 0.0,
        report_json     TEXT DEFAULT '{}',
        status          TEXT DEFAULT 'running',
        started_at      TEXT DEFAULT (datetime('now')),
        completed_at    TEXT DEFAULT ''
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_evolution_trigger ON evolution_log(trigger)",
    "CREATE INDEX IF NOT EXISTS idx_evolution_status  ON evolution_log(status)",

    # ---- SYNTHESIS OUTPUT — logic engine blueprint store -----------------
    """
    CREATE TABLE IF NOT EXISTS synthesis_blueprints (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        blueprint_id    TEXT NOT NULL UNIQUE,
        goal            TEXT NOT NULL,
        module_name     TEXT DEFAULT '',
        module_type     TEXT DEFAULT '',
        architecture    TEXT DEFAULT '',
        blueprint_json  TEXT DEFAULT '{}',
        critique_score  REAL DEFAULT 0.0,
        confidence      REAL DEFAULT 0.0,
        iterations      INTEGER DEFAULT 0,
        quality_gate_pass INTEGER DEFAULT 0,
        created_at      TEXT DEFAULT (datetime('now'))
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_synth_module ON synthesis_blueprints(module_name)",
    "CREATE INDEX IF NOT EXISTS idx_synth_quality ON synthesis_blueprints(critique_score DESC)",

    # ---- LOGIC RULES — dynamic rules persisted across restarts -----------
    """
    CREATE TABLE IF NOT EXISTS logic_rules (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        rule_id         TEXT NOT NULL UNIQUE,
        domain          TEXT DEFAULT 'dynamic',
        antecedents     TEXT DEFAULT '[]',
        consequent      TEXT DEFAULT '[]',
        weight          REAL DEFAULT 1.0,
        fire_count      INTEGER DEFAULT 0,
        generation_src  TEXT DEFAULT '',
        validated       INTEGER DEFAULT 0,
        created_at      TEXT DEFAULT (datetime('now'))
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_rules_domain ON logic_rules(domain)",
    "CREATE INDEX IF NOT EXISTS idx_rules_weight ON logic_rules(weight DESC)",

    # ---- MODULE REGISTRY — auto-discovered modules -----------------------
    """
    CREATE TABLE IF NOT EXISTS module_registry (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        module_name  TEXT NOT NULL UNIQUE,
        blueprint_var TEXT DEFAULT '',
        url_prefix   TEXT DEFAULT '',
        status       TEXT DEFAULT 'unknown',
        version      TEXT DEFAULT '',
        health_url   TEXT DEFAULT '',
        last_health  TEXT DEFAULT '',
        boot_order   INTEGER DEFAULT 100,
        registered_at TEXT DEFAULT (datetime('now'))
    )
    """,

    # ---- APK ANALYSIS — decompile results --------------------------------
    """
    CREATE TABLE IF NOT EXISTS apk_analysis (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id          TEXT NOT NULL UNIQUE,
        apk_path        TEXT NOT NULL,
        package_name    TEXT DEFAULT '',
        version_name    TEXT DEFAULT '',
        version_code    TEXT DEFAULT '',
        capabilities    TEXT DEFAULT '{}',
        permissions     TEXT DEFAULT '[]',
        activities      TEXT DEFAULT '[]',
        services        TEXT DEFAULT '[]',
        receivers       TEXT DEFAULT '[]',
        native_libs     TEXT DEFAULT '[]',
        strings_count   INTEGER DEFAULT 0,
        smali_classes   INTEGER DEFAULT 0,
        risk_score      REAL DEFAULT 0.0,
        genome_injected INTEGER DEFAULT 0,
        status          TEXT DEFAULT 'pending',
        created_at      TEXT DEFAULT (datetime('now'))
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_apk_package ON apk_analysis(package_name)",
    "CREATE INDEX IF NOT EXISTS idx_apk_status  ON apk_analysis(status)",

    # ---- SCHEMA VERSION — migration tracking -----------------------------
    """
    CREATE TABLE IF NOT EXISTS schema_version (
        id         INTEGER PRIMARY KEY,
        version    INTEGER NOT NULL,
        applied_at TEXT DEFAULT (datetime('now'))
    )
    """,
]


# ============================================================================
# INIT FUNCTION
# ============================================================================

def init_db() -> None:
    """
    Apply all DDL statements idempotently.
    Safe to call on every boot — all statements use IF NOT EXISTS.
    Records schema version for future migrations.
    """
    t0 = time.time()
    conn = get_db()
    try:
        conn.execute("BEGIN")
        errors = []
        for stmt in _DDL_STATEMENTS:
            stmt = stmt.strip()
            if not stmt:
                continue
            try:
                conn.execute(stmt)
            except sqlite3.OperationalError as e:
                errors.append(f"{str(e)[:80]} | sql={stmt[:60]}")

        # Record schema version
        existing = conn.execute("SELECT version FROM schema_version WHERE id=1").fetchone()
        if existing is None:
            conn.execute(
                "INSERT INTO schema_version(id, version) VALUES(1, ?)",
                (DB_SCHEMA_VERSION,)
            )
        elif existing[0] < DB_SCHEMA_VERSION:
            conn.execute(
                "UPDATE schema_version SET version=?, applied_at=datetime('now') WHERE id=1",
                (DB_SCHEMA_VERSION,)
            )

        conn.execute("COMMIT")
        elapsed = round((time.time() - t0) * 1000, 1)

        if errors:
            log.warning(f"[DB] Init completed with {len(errors)} non-fatal error(s) in {elapsed}ms")
            for err in errors[:5]:
                log.debug(f"[DB]   {err}")
        else:
            log.info(f"[DB] Schema v{DB_SCHEMA_VERSION} ready in {elapsed}ms — {DB_PATH}")

    except Exception as e:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            pass
        log.error(f"[DB] init_db failed: {e}")
        raise
    finally:
        conn.close()


# ============================================================================
# HEALTH CHECK
# ============================================================================

def db_health() -> dict:
    """
    Return a health snapshot of the Zeus database.
    Called by /api/health and logic engine boot.
    """
    try:
        conn = get_db()
        tables = [
            "genome", "knowledge", "queue", "blueprints",
            "executor_jobs", "chat_history", "evolution_log",
            "synthesis_blueprints", "logic_rules", "module_registry",
            "apk_analysis",
        ]
        counts = {}
        for t in tables:
            try:
                counts[t] = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            except Exception:
                counts[t] = -1

        wal_mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        page_count = conn.execute("PRAGMA page_count").fetchone()[0]
        page_size  = conn.execute("PRAGMA page_size").fetchone()[0]
        wal_pages  = conn.execute("PRAGMA wal_checkpoint").fetchone()
        schema_ver = conn.execute("SELECT version FROM schema_version WHERE id=1").fetchone()
        conn.close()

        return {
            "status":         "ok",
            "db_path":        DB_PATH,
            "schema_version": schema_ver[0] if schema_ver else 0,
            "journal_mode":   wal_mode,
            "db_size_kb":     round(page_count * page_size / 1024, 1),
            "table_counts":   counts,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


# ============================================================================
# MIGRATION HELPERS
# ============================================================================

def add_column_if_missing(table: str, column: str, column_def: str) -> bool:
    """
    Safely add a column to a table if it doesn't already exist.
    Returns True if column was added, False if already present.
    """
    try:
        conn = get_db()
        existing = [
            row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()
        ]
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_def}")
            conn.close()
            log.info(f"[DB] Migration: added {table}.{column}")
            return True
        conn.close()
        return False
    except Exception as e:
        log.warning(f"[DB] add_column_if_missing({table}.{column}): {e}")
        return False


def run_migrations() -> List[str]:
    """
    Apply any pending schema migrations.
    Returns list of migrations applied.
    """
    applied = []

    # v2: add quality_score to knowledge
    if add_column_if_missing("knowledge", "quality_score", "REAL DEFAULT 0.0"):
        applied.append("knowledge.quality_score")

    # v3: add fitness_score, mutation_count to genome
    if add_column_if_missing("genome", "fitness_score",   "REAL DEFAULT 0.0"):
        applied.append("genome.fitness_score")
    if add_column_if_missing("genome", "mutation_count",  "INTEGER DEFAULT 0"):
        applied.append("genome.mutation_count")
    if add_column_if_missing("genome", "lineage",         "TEXT DEFAULT ''"):
        applied.append("genome.lineage")

    # v4: executor_jobs priority
    if add_column_if_missing("executor_jobs", "priority", "INTEGER DEFAULT 5"):
        applied.append("executor_jobs.priority")
    if add_column_if_missing("executor_jobs", "max_attempts", "INTEGER DEFAULT 3"):
        applied.append("executor_jobs.max_attempts")

    # v5: chat logic_facts, reasoning_used
    if add_column_if_missing("chat_history", "reasoning_used", "INTEGER DEFAULT 0"):
        applied.append("chat_history.reasoning_used")
    if add_column_if_missing("chat_history", "logic_facts",    "TEXT DEFAULT '[]'"):
        applied.append("chat_history.logic_facts")

    # v6: blueprints quality_score, stages
    if add_column_if_missing("blueprints", "quality_score",   "REAL DEFAULT 0.0"):
        applied.append("blueprints.quality_score")
    if add_column_if_missing("blueprints", "stages_complete", "INTEGER DEFAULT 0"):
        applied.append("blueprints.stages_complete")
    if add_column_if_missing("blueprints", "stages_total",    "INTEGER DEFAULT 5"):
        applied.append("blueprints.stages_total")

    # v7: knowledge domain, tags, embedding_key
    if add_column_if_missing("knowledge", "domain",        "TEXT DEFAULT ''"):
        applied.append("knowledge.domain")
    if add_column_if_missing("knowledge", "tags",          "TEXT DEFAULT ''"):
        applied.append("knowledge.tags")
    if add_column_if_missing("knowledge", "embedding_key", "TEXT DEFAULT ''"):
        applied.append("knowledge.embedding_key")

    if applied:
        log.info(f"[DB] Migrations applied: {applied}")
    return applied


# ============================================================================
# BULK HELPERS
# ============================================================================

def bulk_insert_queue(topics: List[Tuple[str, str, float, str]]) -> int:
    """
    Fast bulk insert into queue. Ignores duplicates (UNIQUE index on topic+depth).
    topics: list of (topic, depth, priority, source)
    Returns number of rows actually inserted.
    """
    if not topics:
        return 0
    try:
        conn = get_db()
        before = conn.execute("SELECT COUNT(*) FROM queue").fetchone()[0]
        conn.executemany(
            """
            INSERT OR IGNORE INTO queue (topic, depth, priority, source, status, attempts)
            VALUES (?, ?, ?, ?, 'pending', 0)
            """,
            [(t[:500], d, p, s) for t, d, p, s in topics]
        )
        conn.commit()
        after = conn.execute("SELECT COUNT(*) FROM queue").fetchone()[0]
        conn.close()
        return after - before
    except Exception as e:
        log.warning(f"[DB] bulk_insert_queue error: {e}")
        return 0


def claim_queue_batch(batch_size: int = 100,
                      worker_id: str = "") -> List[sqlite3.Row]:
    """
    Atomically claim a batch of pending queue items.
    Marks them 'running' so other workers skip them.
    Returns list of rows.
    """
    try:
        conn = get_db()
        conn.execute("BEGIN IMMEDIATE")
        rows = conn.execute(
            """
            SELECT id, topic, depth, priority, source, attempts
            FROM queue
            WHERE status = 'pending' AND attempts < max_attempts
            ORDER BY priority DESC, id ASC
            LIMIT ?
            """,
            (batch_size,)
        ).fetchall()
        if rows:
            ids = [r["id"] for r in rows]
            placeholders = ",".join("?" for _ in ids)
            conn.execute(
                f"""
                UPDATE queue
                SET status='running', attempts=attempts+1,
                    updated_at=datetime('now')
                WHERE id IN ({placeholders})
                """,
                ids
            )
        conn.execute("COMMIT")
        conn.close()
        return rows
    except Exception as e:
        log.warning(f"[DB] claim_queue_batch error: {e}")
        return []


def complete_queue_item(item_id: int, success: bool, error: str = "") -> None:
    """Mark a queue item done or failed."""
    status = "done" if success else "failed"
    try:
        conn = get_db()
        conn.execute(
            "UPDATE queue SET status=?, error_msg=?, updated_at=datetime('now') WHERE id=?",
            (status, error[:500], item_id)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.warning(f"[DB] complete_queue_item({item_id}): {e}")


# ============================================================================
# BOOT ENTRY POINT
# ============================================================================

def boot() -> None:
    """Full DB boot: init schema + run migrations."""
    init_db()
    run_migrations()


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.DEBUG,
                        format="[%(asctime)s] %(levelname)s %(name)s — %(message)s")
    boot()
    health = db_health()
    print("\n=== Zeus DB Health ===")
    for k, v in health.items():
        print(f"  {k}: {v}")
    print("=== Schema OK ===\n")
