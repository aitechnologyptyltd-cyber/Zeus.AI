# The Zeus Project 2026 — Francois Nel
# zeus_apk_engine.py — APK Decompile + DNA Extraction Engine
# Extracts: Smali patterns, AndroidManifest, strings/assets, native libs
# Output feeds genome splicer + knowledge base + mutator engine

import os
import re
import json
import shutil
import logging
import subprocess
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timezone

log = logging.getLogger("zeus.apk_engine")

ZEUS_DIR     = os.path.dirname(os.path.abspath(__file__))
APK_WORK_DIR = os.path.join(ZEUS_DIR, "apk_analysis")
os.makedirs(APK_WORK_DIR, exist_ok=True)

# ------------------------------------------------------------------ #
# SMALI PATTERNS — what we recognise as capability signals            #
# ------------------------------------------------------------------ #
SMALI_PATTERNS = {
    "network_http":       [r"okhttp3", r"retrofit2", r"HttpURLConnection", r"OkHttpClient"],
    "network_websocket":  [r"WebSocket", r"websocket", r"ws://", r"wss://"],
    "crypto":             [r"javax/crypto", r"AES", r"RSA", r"MessageDigest", r"SecretKey"],
    "reflection":         [r"java/lang/reflect", r"getDeclaredMethod", r"invoke\("],
    "root_detection":     [r"su\b", r"Superuser", r"RootBeer", r"isRooted"],
    "anti_debug":         [r"isDebuggerConnected", r"TracerPid", r"JDWP"],
    "dynamic_code":       [r"DexClassLoader", r"PathClassLoader", r"loadDex"],
    "native_bridge":      [r"System\.loadLibrary", r"loadLibrary", r"\.so\b"],
    "sqlite_usage":       [r"SQLiteDatabase", r"SQLiteOpenHelper", r"rawQuery"],
    "shared_prefs":       [r"SharedPreferences", r"getSharedPreferences"],
    "camera":             [r"android/hardware/Camera", r"CameraManager", r"CameraDevice"],
    "location":           [r"LocationManager", r"FusedLocationProvider", r"getLastLocation"],
    "sms":                [r"SmsManager", r"sendTextMessage", r"SMS_RECEIVED"],
    "contacts":           [r"ContactsContract", r"ContactsProvider"],
    "clipboard":          [r"ClipboardManager", r"setPrimaryClip"],
    "accessibility":      [r"AccessibilityService", r"AccessibilityEvent"],
    "overlay":            [r"TYPE_APPLICATION_OVERLAY", r"SYSTEM_ALERT_WINDOW"],
    "biometric":          [r"BiometricPrompt", r"FingerprintManager"],
    "payment":            [r"com/google/android/gms/wallet", r"PaymentRequest", r"Stripe"],
    "firebase":           [r"com/google/firebase", r"FirebaseApp", r"FirebaseAuth"],
    "ads":                [r"com/google/android/gms/ads", r"AdMob", r"MoPub"],
    "obfuscation":        [r"^[a-z]\.", r"^[A-Z]\.", r"proguard"],
    "intent_intercept":   [r"BroadcastReceiver", r"registerReceiver", r"sendBroadcast"],
    "file_access":        [r"FileOutputStream", r"FileInputStream", r"Environment\.getExternal"],
    "process_exec":       [r"Runtime\.exec", r"ProcessBuilder", r"getRuntime\(\)\.exec"],
}

MANIFEST_DANGEROUS_PERMS = {
    "android.permission.READ_SMS",
    "android.permission.SEND_SMS",
    "android.permission.RECEIVE_SMS",
    "android.permission.READ_CONTACTS",
    "android.permission.WRITE_CONTACTS",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.CAMERA",
    "android.permission.RECORD_AUDIO",
    "android.permission.READ_CALL_LOG",
    "android.permission.WRITE_CALL_LOG",
    "android.permission.PROCESS_OUTGOING_CALLS",
    "android.permission.BIND_ACCESSIBILITY_SERVICE",
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.WRITE_SETTINGS",
    "android.permission.INSTALL_PACKAGES",
    "android.permission.DELETE_PACKAGES",
    "android.permission.REQUEST_INSTALL_PACKAGES",
    "android.permission.READ_EXTERNAL_STORAGE",
    "android.permission.WRITE_EXTERNAL_STORAGE",
    "android.permission.INTERNET",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.USE_BIOMETRIC",
    "android.permission.USE_FINGERPRINT",
    "android.permission.NFC",
    "android.permission.BLUETOOTH",
    "android.permission.CHANGE_NETWORK_STATE",
    "android.permission.KILL_BACKGROUND_PROCESSES",
}


# ================================================================== #
# MAIN ENGINE CLASS                                                    #
# ================================================================== #

class APKEngine:
    """
    Full APK decompile and DNA extraction.
    The Zeus Project 2026 — Francois Nel
    """

    def __init__(self, apk_path: str, file_id: str):
        self.apk_path  = apk_path
        self.file_id   = file_id
        self.apk_name  = Path(apk_path).stem
        self.work_dir  = os.path.join(APK_WORK_DIR, file_id)
        self.result: Dict = {
            "file_id":       file_id,
            "apk_name":      self.apk_name,
            "smali":         {},
            "manifest":      {},
            "strings":       [],
            "native_libs":   [],
            "capabilities":  [],
            "genome_entries": [],
            "knowledge_articles": [],
            "mutator_seeds": [],
            "error":         None,
        }

    # -------------------------------------------------------------- #
    # PUBLIC ENTRY POINT                                               #
    # -------------------------------------------------------------- #

    def extract(self) -> Dict:
        log.info(f"[APK Engine] Starting extraction: {self.apk_name}")
        try:
            decompiled = self._decompile_apktool()
            if not decompiled:
                decompiled = self._fallback_unzip()

            if decompiled:
                self._extract_smali()
                self._extract_manifest()
                self._extract_strings()
                self._extract_native_libs()

            self._build_genome_entries()
            self._build_knowledge_articles()
            self._build_mutator_seeds()

            log.info(
                f"[APK Engine] {self.apk_name} done — "
                f"{len(self.result['genome_entries'])} genome entries, "
                f"{len(self.result['knowledge_articles'])} knowledge articles, "
                f"{len(self.result['mutator_seeds'])} mutator seeds"
            )
        except Exception as e:
            log.error(f"[APK Engine] Extraction error: {e}")
            self.result["error"] = str(e)
        finally:
            self._cleanup()

        return self.result

    # -------------------------------------------------------------- #
    # DECOMPILE                                                        #
    # -------------------------------------------------------------- #

    def _decompile_apktool(self) -> bool:
        """Try apktool first — full Smali decompile."""
        try:
            r = subprocess.run(
                ["apktool", "d", "-f", "-o", self.work_dir, self.apk_path],
                capture_output=True, text=True, timeout=120
            )
            if r.returncode == 0 and os.path.isdir(self.work_dir):
                log.info(f"[APK Engine] apktool decompile OK")
                return True
            log.warning(f"[APK Engine] apktool failed: {r.stderr[:200]}")
            return False
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            log.warning(f"[APK Engine] apktool not available: {e}")
            return False

    def _fallback_unzip(self) -> bool:
        """Fallback: unzip APK as a zip — no Smali but gets manifest + libs."""
        try:
            os.makedirs(self.work_dir, exist_ok=True)
            with zipfile.ZipFile(self.apk_path, "r") as z:
                z.extractall(self.work_dir)
            log.info(f"[APK Engine] Fallback unzip OK")
            return True
        except Exception as e:
            log.error(f"[APK Engine] Fallback unzip failed: {e}")
            return False

    # -------------------------------------------------------------- #
    # SMALI EXTRACTION                                                 #
    # -------------------------------------------------------------- #

    def _extract_smali(self):
        smali_root = os.path.join(self.work_dir, "smali")
        if not os.path.isdir(smali_root):
            log.info("[APK Engine] No smali/ directory found")
            return

        detected:   Dict[str, int]  = {}
        classes:    List[str]       = []
        endpoints:  List[str]       = []
        total_files = 0

        url_re = re.compile(
            r'(https?://[a-zA-Z0-9./\-_?=&%+#@:]{8,})', re.IGNORECASE
        )

        for root, _, files in os.walk(smali_root):
            for fname in files:
                if not fname.endswith(".smali"):
                    continue
                total_files += 1
                fpath = os.path.join(root, fname)

                # Class name
                rel = os.path.relpath(fpath, smali_root).replace(os.sep, "/")
                classes.append(rel.replace(".smali", ""))

                try:
                    content = Path(fpath).read_text(errors="replace")
                except Exception:
                    continue

                # Pattern matching
                for cap, patterns in SMALI_PATTERNS.items():
                    for pat in patterns:
                        if re.search(pat, content):
                            detected[cap] = detected.get(cap, 0) + 1
                            break

                # URL extraction
                for url in url_re.findall(content):
                    if url not in endpoints:
                        endpoints.append(url)

        self.result["smali"] = {
            "total_files":    total_files,
            "class_count":    len(classes),
            "capabilities":   detected,
            "endpoints":      endpoints[:100],  # cap at 100
            "sample_classes": classes[:50],
        }

        log.info(
            f"[APK Engine] Smali: {total_files} files, "
            f"{len(detected)} capability patterns, "
            f"{len(endpoints)} endpoints"
        )

    # -------------------------------------------------------------- #
    # MANIFEST EXTRACTION                                              #
    # -------------------------------------------------------------- #

    def _extract_manifest(self):
        manifest_path = os.path.join(self.work_dir, "AndroidManifest.xml")
        if not os.path.exists(manifest_path):
            log.info("[APK Engine] AndroidManifest.xml not found")
            return

        try:
            tree = ET.parse(manifest_path)
            root = tree.getroot()

            ns = {"android": "http://schemas.android.com/apk/res/android"}

            # Package info
            package    = root.get("package", "")
            version    = root.get(
                "{http://schemas.android.com/apk/res/android}versionName", ""
            )
            min_sdk    = ""
            target_sdk = ""

            uses_sdk = root.find("uses-sdk")
            if uses_sdk is not None:
                min_sdk    = uses_sdk.get(
                    "{http://schemas.android.com/apk/res/android}minSdkVersion", ""
                )
                target_sdk = uses_sdk.get(
                    "{http://schemas.android.com/apk/res/android}targetSdkVersion", ""
                )

            # Permissions
            all_perms       = []
            dangerous_perms = []
            for perm in root.findall("uses-permission"):
                name = perm.get(
                    "{http://schemas.android.com/apk/res/android}name", ""
                )
                if name:
                    all_perms.append(name)
                    if name in MANIFEST_DANGEROUS_PERMS:
                        dangerous_perms.append(name)

            # Components
            app_elem    = root.find("application")
            activities  = []
            services    = []
            receivers   = []
            providers   = []

            if app_elem is not None:
                for child in app_elem:
                    name_attr = child.get(
                        "{http://schemas.android.com/apk/res/android}name", ""
                    )
                    if child.tag == "activity":
                        activities.append(name_attr)
                    elif child.tag == "service":
                        services.append(name_attr)
                    elif child.tag == "receiver":
                        receivers.append(name_attr)
                    elif child.tag == "provider":
                        providers.append(name_attr)

            self.result["manifest"] = {
                "package":         package,
                "version":         version,
                "min_sdk":         min_sdk,
                "target_sdk":      target_sdk,
                "permissions":     all_perms,
                "dangerous_perms": dangerous_perms,
                "activities":      activities,
                "services":        services,
                "receivers":       receivers,
                "providers":       providers,
                "component_count": len(activities) + len(services) +
                                   len(receivers) + len(providers),
            }

            log.info(
                f"[APK Engine] Manifest: {package} — "
                f"{len(all_perms)} perms ({len(dangerous_perms)} dangerous), "
                f"{len(activities)} activities, {len(services)} services"
            )

        except ET.ParseError as e:
            log.warning(f"[APK Engine] Manifest parse error: {e}")
            self.result["manifest"] = {"parse_error": str(e)}

    # -------------------------------------------------------------- #
    # STRINGS / ASSETS EXTRACTION                                      #
    # -------------------------------------------------------------- #

    def _extract_strings(self):
        strings_collected = []

        # strings.xml
        strings_xml = os.path.join(
            self.work_dir, "res", "values", "strings.xml"
        )
        if os.path.exists(strings_xml):
            try:
                tree = ET.parse(strings_xml)
                for elem in tree.getroot().findall("string"):
                    val = elem.text or ""
                    if val.strip():
                        strings_collected.append({
                            "name":   elem.get("name", ""),
                            "value":  val.strip()[:200],
                            "source": "strings.xml",
                        })
            except Exception as e:
                log.warning(f"[APK Engine] strings.xml parse error: {e}")

        # Walk assets/ for text files
        assets_dir = os.path.join(self.work_dir, "assets")
        if os.path.isdir(assets_dir):
            for root, _, files in os.walk(assets_dir):
                for fname in files:
                    if fname.endswith((".json", ".txt", ".xml", ".html", ".js")):
                        fpath = os.path.join(root, fname)
                        try:
                            content = Path(fpath).read_text(errors="replace")[:2000]
                            strings_collected.append({
                                "name":   fname,
                                "value":  content,
                                "source": f"assets/{fname}",
                            })
                        except Exception:
                            pass

        self.result["strings"] = strings_collected[:200]
        log.info(f"[APK Engine] Strings/assets: {len(strings_collected)} entries")

    # -------------------------------------------------------------- #
    # NATIVE LIBS EXTRACTION                                           #
    # -------------------------------------------------------------- #

    def _extract_native_libs(self):
        libs = []
        lib_dir = os.path.join(self.work_dir, "lib")
        if not os.path.isdir(lib_dir):
            # also check libs/ (unzipped name)
            lib_dir = os.path.join(self.work_dir, "libs")

        if os.path.isdir(lib_dir):
            for arch_dir in os.listdir(lib_dir):
                arch_path = os.path.join(lib_dir, arch_dir)
                if os.path.isdir(arch_path):
                    for lib_file in os.listdir(arch_path):
                        if lib_file.endswith(".so"):
                            lib_entry = {
                                "name": lib_file,
                                "arch": arch_dir,
                                "path": os.path.join(arch_dir, lib_file),
                            }
                            # Try to read symbols with nm/strings if available
                            full_path = os.path.join(arch_path, lib_file)
                            symbols = self._extract_lib_symbols(full_path)
                            if symbols:
                                lib_entry["symbols"] = symbols[:50]
                            libs.append(lib_entry)

        self.result["native_libs"] = libs
        log.info(f"[APK Engine] Native libs: {len(libs)} .so files")

    def _extract_lib_symbols(self, lib_path: str) -> List[str]:
        """Extract symbol names from .so using 'strings' command."""
        try:
            r = subprocess.run(
                ["strings", "-n", "6", lib_path],
                capture_output=True, text=True, timeout=10
            )
            if r.returncode == 0:
                raw = r.stdout.splitlines()
                # Filter to likely function/symbol names
                symbols = [
                    s for s in raw
                    if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]{4,}$', s)
                    and not s.startswith("GLIBC")
                ]
                return symbols[:100]
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return []

    # -------------------------------------------------------------- #
    # BUILD GENOME ENTRIES                                             #
    # -------------------------------------------------------------- #

    def _build_genome_entries(self):
        entries = []
        pkg = self.result["manifest"].get("package", self.apk_name)

        # 1. APK identity genome
        entries.append({
            "name":        f"APK:{self.apk_name}",
            "description": (
                f"Android APK — {pkg} "
                f"v{self.result['manifest'].get('version', '?')} — "
                f"{self.result['manifest'].get('component_count', 0)} components — "
                f"minSDK {self.result['manifest'].get('min_sdk', '?')}"
            ),
            "module_type": "apk_dna",
            "priority":    70,
            "version":     self.result["manifest"].get("version", "v1.0"),
            "capabilities": json.dumps(list(
                self.result["smali"].get("capabilities", {}).keys()
            )),
        })

        # 2. Permissions genome
        dangerous = self.result["manifest"].get("dangerous_perms", [])
        if dangerous:
            entries.append({
                "name":        f"APK:{self.apk_name}:permissions",
                "description": (
                    f"Dangerous permissions declared by {pkg}: "
                    + ", ".join(dangerous[:10])
                ),
                "module_type": "apk_permissions",
                "priority":    65,
                "capabilities": json.dumps(dangerous),
            })

        # 3. One genome entry per major capability cluster
        for cap, count in self.result["smali"].get("capabilities", {}).items():
            entries.append({
                "name":        f"APK:{self.apk_name}:{cap}",
                "description": (
                    f"Smali capability '{cap}' detected {count}× in {pkg}"
                ),
                "module_type": "apk_capability",
                "priority":    60,
                "capabilities": json.dumps([cap]),
            })

        # 4. Native library genome entries
        for lib in self.result["native_libs"]:
            entries.append({
                "name":        f"APK:{self.apk_name}:lib:{lib['name']}",
                "description": (
                    f"Native library {lib['name']} ({lib['arch']}) from {pkg}"
                    + (f" — symbols: {', '.join(lib.get('symbols', [])[:5])}"
                       if lib.get("symbols") else "")
                ),
                "module_type": "apk_native_lib",
                "priority":    55,
                "capabilities": json.dumps(lib.get("symbols", [])[:20]),
            })

        self.result["genome_entries"] = entries
        log.info(f"[APK Engine] Built {len(entries)} genome entries")

    # -------------------------------------------------------------- #
    # BUILD KNOWLEDGE ARTICLES                                         #
    # -------------------------------------------------------------- #

    def _build_knowledge_articles(self):
        articles = []
        pkg = self.result["manifest"].get("package", self.apk_name)
        caps = list(self.result["smali"].get("capabilities", {}).keys())

        # Summary article
        articles.append({
            "topic":      f"APK Analysis: {self.apk_name}",
            "depth":      "Simple",
            "content": (
                f"{self.apk_name} ({pkg}) is an Android application with "
                f"{self.result['smali'].get('class_count', '?')} classes, "
                f"{len(self.result['manifest'].get('permissions', []))} declared permissions "
                f"({len(self.result['manifest'].get('dangerous_perms', []))} dangerous), "
                f"{len(self.result['native_libs'])} native libraries. "
                f"Key capabilities detected: {', '.join(caps[:8]) if caps else 'none'}. "
                f"Components: {self.result['manifest'].get('component_count', 0)} total."
            ),
            "confidence": 0.95,
        })

        # Permissions article
        dangerous = self.result["manifest"].get("dangerous_perms", [])
        if dangerous:
            articles.append({
                "topic":      f"Android Permissions: {pkg}",
                "depth":      "Advanced",
                "content": (
                    f"Permission profile of {pkg}: "
                    f"{len(dangerous)} dangerous permissions including: "
                    + "; ".join(dangerous[:15])
                    + ". These permissions grant access to: "
                    + self._permissions_to_english(dangerous)
                ),
                "confidence": 0.9,
            })

        # Capability articles — one per detected capability
        for cap, count in self.result["smali"].get("capabilities", {}).items():
            articles.append({
                "topic":      f"Android Capability: {cap}",
                "depth":      "Advanced",
                "content": (
                    f"The capability '{cap}' was detected {count} times in "
                    f"{self.apk_name}. This indicates the application "
                    f"{self._capability_to_english(cap)}."
                ),
                "confidence": 0.85,
            })

        # Endpoints article
        endpoints = self.result["smali"].get("endpoints", [])
        if endpoints:
            articles.append({
                "topic":      f"Network Endpoints: {self.apk_name}",
                "depth":      "Advanced",
                "content": (
                    f"Network endpoints discovered in {self.apk_name}: "
                    + "; ".join(endpoints[:20])
                ),
                "confidence": 0.8,
            })

        # Native libs article
        if self.result["native_libs"]:
            lib_names = [l["name"] for l in self.result["native_libs"]]
            articles.append({
                "topic":      f"Native Libraries: {self.apk_name}",
                "depth":      "Advanced",
                "content": (
                    f"Native (.so) libraries in {self.apk_name}: "
                    + ", ".join(lib_names)
                    + ". Architectures: "
                    + ", ".join(set(l["arch"] for l in self.result["native_libs"]))
                ),
                "confidence": 0.85,
            })

        self.result["knowledge_articles"] = articles
        log.info(f"[APK Engine] Built {len(articles)} knowledge articles")

    # -------------------------------------------------------------- #
    # BUILD MUTATOR SEEDS                                              #
    # -------------------------------------------------------------- #

    def _build_mutator_seeds(self):
        """
        Fast pattern-match seeds for the mutator engine.
        AI-deep seeds are generated by zeus_mutator.py after this.
        """
        seeds = []
        pkg  = self.result["manifest"].get("package", self.apk_name)
        caps = self.result["smali"].get("capabilities", {})

        # Seed from each capability
        cap_to_topics = {
            "network_http":      ["Android HTTP networking internals",
                                  "OkHttp3 architecture and interceptors",
                                  "Retrofit2 annotation-driven REST clients"],
            "network_websocket": ["WebSocket protocol implementation on Android",
                                  "Real-time messaging architecture patterns"],
            "crypto":            ["Android cryptography with javax.crypto",
                                  "AES encryption implementation patterns",
                                  "RSA key exchange in mobile applications"],
            "root_detection":    ["Android root detection techniques",
                                  "Anti-tamper mechanisms in APKs",
                                  "Bypassing root detection with Magisk"],
            "anti_debug":        ["Anti-debugging techniques in Android APKs",
                                  "JNI debugger detection methods",
                                  "TracerPid monitoring in native code"],
            "dynamic_code":      ["DexClassLoader dynamic code loading",
                                  "Android plugin frameworks and hot patching",
                                  "Malware dynamic loading techniques"],
            "native_bridge":     ["JNI and NDK native bridge architecture",
                                  "Android .so library reverse engineering",
                                  "System.loadLibrary internals"],
            "sqlite_usage":      ["Android SQLite patterns and best practices",
                                  "Room database architecture in Android"],
            "camera":            ["Android Camera2 API architecture",
                                  "Computer vision on Android devices"],
            "location":          ["Android location services and FusedLocationProvider",
                                  "GPS and network triangulation on mobile"],
            "sms":               ["Android SMS architecture and SmsManager",
                                  "SMS-based authentication security"],
            "accessibility":     ["Android AccessibilityService capabilities",
                                  "Automation via accessibility APIs"],
            "overlay":           ["Android system overlay SYSTEM_ALERT_WINDOW",
                                  "Clickjacking via overlay attacks on Android"],
            "payment":           ["Android Google Pay wallet integration",
                                  "Mobile payment security patterns"],
            "firebase":          ["Firebase architecture and real-time database",
                                  "Firebase Authentication implementation"],
            "obfuscation":       ["ProGuard and R8 Android obfuscation",
                                  "Deobfuscation techniques for Android apps",
                                  "Code obfuscation detection methods"],
            "process_exec":      ["Runtime.exec in Android security context",
                                  "Process injection techniques on Android"],
            "biometric":         ["Android BiometricPrompt API",
                                  "Biometric authentication security analysis"],
        }

        for cap in caps:
            for topic in cap_to_topics.get(cap, [f"Android {cap} implementation patterns"]):
                seeds.append({
                    "topic":    topic,
                    "source":   f"APK:{self.apk_name}:{cap}",
                    "priority": 1.5,  # boosted
                    "depth":    "Simple",
                })

        # Seed from dangerous permissions
        for perm in self.result["manifest"].get("dangerous_perms", []):
            short = perm.replace("android.permission.", "")
            seeds.append({
                "topic":    f"Android permission {short} — security implications",
                "source":   f"APK:{self.apk_name}:manifest",
                "priority": 1.3,
                "depth":    "Simple",
            })

        # Seed from native libs
        for lib in self.result["native_libs"]:
            seeds.append({
                "topic":    f"Reverse engineering native library {lib['name']}",
                "source":   f"APK:{self.apk_name}:native",
                "priority": 1.2,
                "depth":    "Simple",
            })

        # Seed the APK package name itself for general research
        seeds.append({
            "topic":    f"Android application {pkg} analysis and architecture",
            "source":   f"APK:{self.apk_name}",
            "priority": 1.4,
            "depth":    "Simple",
        })

        self.result["mutator_seeds"] = seeds
        log.info(f"[APK Engine] Built {len(seeds)} mutator seeds")

    # -------------------------------------------------------------- #
    # HELPERS                                                          #
    # -------------------------------------------------------------- #

    def _permissions_to_english(self, perms: List[str]) -> str:
        mapping = {
            "READ_SMS":                   "read SMS messages",
            "SEND_SMS":                   "send SMS messages",
            "READ_CONTACTS":              "read device contacts",
            "ACCESS_FINE_LOCATION":       "track precise GPS location",
            "CAMERA":                     "access device camera",
            "RECORD_AUDIO":               "record microphone audio",
            "BIND_ACCESSIBILITY_SERVICE": "use accessibility overlay",
            "SYSTEM_ALERT_WINDOW":        "draw over other apps",
            "INSTALL_PACKAGES":           "install other APKs",
            "READ_CALL_LOG":              "read call history",
        }
        results = []
        for perm in perms[:8]:
            short = perm.replace("android.permission.", "")
            results.append(mapping.get(short, short.lower().replace("_", " ")))
        return "; ".join(results)

    def _capability_to_english(self, cap: str) -> str:
        mapping = {
            "network_http":      "makes HTTP network requests",
            "crypto":            "performs cryptographic operations",
            "root_detection":    "detects whether the device is rooted",
            "anti_debug":        "detects and resists debugging",
            "dynamic_code":      "loads and executes code at runtime",
            "native_bridge":     "uses native C/C++ code via JNI",
            "sqlite_usage":      "reads and writes a local SQLite database",
            "accessibility":     "uses Android Accessibility Services",
            "overlay":           "draws system-level overlays on screen",
            "process_exec":      "executes system-level shell commands",
            "obfuscation":       "uses code obfuscation to resist analysis",
        }
        return mapping.get(cap, f"implements {cap.replace('_', ' ')} functionality")

    def _cleanup(self):
        """Remove the temporary decompile directory."""
        try:
            if os.path.isdir(self.work_dir):
                shutil.rmtree(self.work_dir)
        except Exception as e:
            log.warning(f"[APK Engine] Cleanup error: {e}")


# ================================================================== #
# CONVENIENCE FUNCTION                                                 #
# ================================================================== #

def extract_apk(apk_path: str, file_id: str) -> Dict:
    """
    Extract DNA from an APK file.
    Returns full result dict with genome_entries, knowledge_articles,
    mutator_seeds.
    The Zeus Project 2026 — Francois Nel
    """
    engine = APKEngine(apk_path, file_id)
    return engine.extract()


# ============================================================================
# FLASK BLUEPRINT + SINGLETON ENGINE
# ============================================================================

from flask import Blueprint, jsonify, request, send_file
import threading
from collections import deque

apk_engine_bp = Blueprint("apk_engine", __name__)

_apk_engine_lock = threading.RLock()
_apk_engine_jobs: dict = {}
_apk_engine_recent: deque = deque(maxlen=50)
_apk_total_analyses = 0


def get_engine():
    """Return a callable to analyse an APK path."""
    return _EngineProxy()


class _EngineProxy:
    """Proxy that wraps APKEngine for singleton-style use."""

    def analyse(self, apk_path: str, file_id: str = "") -> dict:
        """Full APK analysis. Returns complete result dict."""
        fid = file_id or __import__("uuid").uuid4().hex[:12]
        return APKEngine(apk_path, fid).extract()


def _run_apk_job(job_id: str, apk_path: str) -> None:
    """Background APK analysis job."""
    global _apk_total_analyses
    t0 = __import__("time").time()
    try:
        result = APKEngine(apk_path, job_id).extract()
        # Feed genome
        try:
            from genome_manager import get_genome_engine
            geng = get_genome_engine()
            for entry in result.get("genome_entries", [])[:20]:
                geng.add(
                    name=entry.get("name", f"apk:{job_id}"),
                    description=entry.get("description", "")[:500],
                    module_type=entry.get("module_type", "apk_dna"),
                    source_code="",
                    version=entry.get("version", "v1.0"),
                    priority=int(entry.get("priority", 60)),
                    capabilities=entry.get("capabilities", ""),
                )
        except Exception as e:
            log.debug(f"[APKEngine] Genome feed skipped: {e}")

        # Feed knowledge
        try:
            from db_init import get_db
            conn = get_db()
            for art in result.get("knowledge_articles", [])[:10]:
                conn.execute(
                    """INSERT OR IGNORE INTO knowledge
                       (topic, depth, content, confidence, domain)
                       VALUES (?, ?, ?, ?, 'android')""",
                    (art.get("topic","")[:200],
                     art.get("depth","Simple"),
                     art.get("content","")[:8000],
                     float(art.get("confidence", 0.85)))
                )
            conn.commit(); conn.close()
        except Exception as e:
            log.debug(f"[APKEngine] Knowledge feed skipped: {e}")

        # Feed mutator seeds
        try:
            from zeus_mutator import get_engine as get_mutator
            seeds = result.get("mutator_seeds", [])
            if seeds:
                get_mutator().mutate(seeds[:15], source=f"apk_engine:{job_id}", use_ai=False)
        except Exception as e:
            log.debug(f"[APKEngine] Mutator feed skipped: {e}")

        # Logic engine notification
        try:
            from logic_engine import get_engine as get_logic, LogicFact
            pkg   = result.get("manifest", {}).get("package", "unknown")
            caps  = list(result.get("smali", {}).get("capabilities", {}).keys())
            facts = [LogicFact(predicate="file_category", args=(job_id, "android"), source="apk_engine")]
            for cap in caps[:5]:
                facts.append(LogicFact(predicate="has_capability", args=(pkg, cap), source="apk_engine"))
            get_logic().reason(facts, max_depth=6, auto_learn=True)
        except Exception as e:
            log.debug(f"[APKEngine] Logic notify skipped: {e}")

        result["status"] = "ok"
        result["job_id"] = job_id
        result["duration_ms"] = round((__import__("time").time() - t0) * 1000, 1)

    except Exception as e:
        result = {"status": "error", "error": str(e), "job_id": job_id}
        log.error(f"[APKEngine] Job {job_id} failed: {e}")

    with _apk_engine_lock:
        _apk_engine_jobs[job_id] = result
        _apk_total_analyses += 1
        _apk_engine_recent.append({
            "job_id":    job_id,
            "package":   result.get("manifest", {}).get("package", "?"),
            "status":    result.get("status", "?"),
            "caps":      len(result.get("smali", {}).get("capabilities", {})),
            "ms":        result.get("duration_ms", 0),
        })


# ============================================================================
# FLASK ROUTES
# ============================================================================

@apk_engine_bp.route("/api/apk/health", methods=["GET"])
def apk_engine_health():
    return jsonify({
        "status":  "ok",
        "module":  "zeus_apk_engine",
        "version": "2.0",
        "total_analyses": _apk_total_analyses,
        "active_jobs":    len(_apk_engine_jobs),
        "work_dir":       APK_WORK_DIR,
    })


@apk_engine_bp.route("/api/apk/stats", methods=["GET"])
def apk_engine_stats():
    with _apk_engine_lock:
        done   = sum(1 for j in _apk_engine_jobs.values() if j.get("status") == "ok")
        failed = sum(1 for j in _apk_engine_jobs.values() if j.get("status") == "error")
    return jsonify({
        "total_analyses": _apk_total_analyses,
        "done":           done,
        "failed":         failed,
        "recent":         list(_apk_engine_recent)[-5:],
        "smali_patterns": len(SMALI_PATTERNS),
        "dangerous_perms_tracked": len(MANIFEST_DANGEROUS_PERMS),
    })


@apk_engine_bp.route("/api/apk/analyse", methods=["POST"])
def apk_analyse():
    """
    Analyse an APK file and feed DNA into Zeus.
    POST { "apk_path": str, "sync": bool }
    """
    data     = request.get_json(force=True, silent=True) or {}
    apk_path = data.get("apk_path", "").strip()
    sync     = bool(data.get("sync", False))

    if not apk_path:
        return jsonify({"error": "apk_path required"}), 400
    if not os.path.isfile(apk_path):
        return jsonify({"error": f"File not found: {apk_path}"}), 404

    job_id = __import__("uuid").uuid4().hex[:12]

    if sync:
        _run_apk_job(job_id, apk_path)
        with _apk_engine_lock:
            return jsonify(_apk_engine_jobs.get(job_id, {"error": "no result"}))
    else:
        with _apk_engine_lock:
            _apk_engine_jobs[job_id] = {"status": "running", "job_id": job_id}
        t = __import__("threading").Thread(
            target=_run_apk_job, args=(job_id, apk_path),
            name=f"apk_{job_id[:8]}", daemon=True
        )
        t.start()
        return jsonify({"status": "running", "job_id": job_id,
                        "poll_url": f"/api/apk/job/{job_id}"})


@apk_engine_bp.route("/api/apk/job/<job_id>", methods=["GET"])
def apk_job_status(job_id: str):
    with _apk_engine_lock:
        job = _apk_engine_jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job)


@apk_engine_bp.route("/api/apk/jobs", methods=["GET"])
def apk_jobs():
    limit  = int(request.args.get("limit", 20))
    status = request.args.get("status", "")
    with _apk_engine_lock:
        jobs = list(_apk_engine_jobs.values())
    if status:
        jobs = [j for j in jobs if j.get("status") == status]
    # Return summary (without full smali data)
    summary = [
        {
            "job_id":   j.get("job_id",""),
            "package":  j.get("manifest",{}).get("package","") if isinstance(j.get("manifest"),dict) else "",
            "status":   j.get("status",""),
            "risk":     j.get("risk_score", 0),
            "caps":     len(j.get("smali",{}).get("capabilities",{})) if isinstance(j.get("smali"),dict) else 0,
        }
        for j in jobs[-limit:]
    ]
    return jsonify({"jobs": summary, "count": len(jobs)})


@apk_engine_bp.route("/api/apk/patterns", methods=["GET"])
def apk_patterns():
    """Return the SMALI detection patterns and dangerous permissions list."""
    return jsonify({
        "smali_patterns":      list(SMALI_PATTERNS.keys()),
        "dangerous_permissions": sorted(MANIFEST_DANGEROUS_PERMS),
        "pattern_count":       len(SMALI_PATTERNS),
        "dangerous_perm_count": len(MANIFEST_DANGEROUS_PERMS),
    })


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(apk_engine_bp)
    log.info("[apk_engine] ✓ Registered at /api/apk")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_apk_engine",
            blueprint_var="apk_engine_bp",
            url_prefix="/api/apk",
            version="2.0",
            description="APK decompile + DNA extraction: Smali patterns, manifest, strings, native libs, genome+knowledge+mutator feed",
            capabilities=[
                {"id": "apk.analyse",  "endpoint": "/api/apk/analyse",  "method": "POST", "tags": ["apk","android","dna"]},
                {"id": "apk.job",      "endpoint": "/api/apk/job",      "method": "GET",  "tags": ["apk"]},
                {"id": "apk.jobs",     "endpoint": "/api/apk/jobs",     "method": "GET",  "tags": ["apk"]},
                {"id": "apk.patterns", "endpoint": "/api/apk/patterns", "method": "GET",  "tags": ["apk"]},
                {"id": "apk.health",   "endpoint": "/api/apk/health",   "method": "GET",  "tags": ["health"]},
                {"id": "apk.stats",    "endpoint": "/api/apk/stats",    "method": "GET",  "tags": ["stats"]},
            ],
            depends_on=["genome_manager", "zeus_mutator", "logic_engine"],
            boot_order=60,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    import logging as _logging
    _logging.basicConfig(level=_logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5027, debug=True, use_reloader=False)
