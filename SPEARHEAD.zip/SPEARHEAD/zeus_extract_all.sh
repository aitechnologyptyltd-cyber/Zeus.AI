#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
# The Zeus Project 2026 — Francois Nel
# zeus_extract_all.sh — In-place permission fixer & system scanner
# ══════════════════════════════════════════════════════════════════════════════
#
# Run this from inside the ZEUS folder (where you already see the system dirs).
# It does NOT extract a ZIP — the files are already here.
#
# USAGE:
#   bash zeus_extract_all.sh
#
# WHAT IT DOES:
#   1. Confirms all 6 system folders are present
#   2. chmod +x every .py .sh .bash file in all system folders
#   3. chmod +x itself and zeus_install_all.sh
#   4. Prints a full file manifest with sizes
# ══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Colours ───────────────────────────────────────────────────────────────────
GRN='\033[0;32m'; CYN='\033[0;36m'; YEL='\033[1;33m'
RED='\033[0;31m'; BLD='\033[1m'; RST='\033[0m'

echo ""
echo -e "${BLD}${CYN}  ╔══════════════════════════════════════════════════════════╗${RST}"
echo -e "${BLD}${CYN}  ║   THE ZEUS PROJECT 2026 — FRANCOIS NEL                  ║${RST}"
echo -e "${BLD}${CYN}  ║   zeus_extract_all.sh — Permission Fixer                ║${RST}"
echo -e "${BLD}${CYN}  ╚══════════════════════════════════════════════════════════╝${RST}"
echo ""
echo -e "  ${CYN}Working directory:${RST} $SCRIPT_DIR"
echo ""

# ── Step 1: Check system folders ──────────────────────────────────────────────
echo -e "  ${BLD}[1/3] Checking system folders...${RST}"

EXPECTED_DIRS="01_hive_root 02_zeus_arch 03_ump 04_zeus_firewall 05_tartarus 06_hive_bridge"
MISSING=0

for d in $EXPECTED_DIRS; do
    if [ -d "$SCRIPT_DIR/$d" ]; then
        FILE_COUNT=$(find "$SCRIPT_DIR/$d" -type f | wc -l)
        echo -e "       ${GRN}✓${RST}  $d  (${FILE_COUNT} files)"
    else
        echo -e "       ${RED}✗${RST}  $d  MISSING"
        MISSING=$((MISSING + 1))
    fi
done

if [ $MISSING -gt 0 ]; then
    echo ""
    echo -e "  ${YEL}⚠  $MISSING folder(s) missing — continuing anyway${RST}"
fi

echo ""

# ── Step 2: chmod +x everything ───────────────────────────────────────────────
echo -e "  ${BLD}[2/3] Applying chmod +x...${RST}"
echo ""

TOTAL=0

for d in $EXPECTED_DIRS; do
    DIR_PATH="$SCRIPT_DIR/$d"
    [ -d "$DIR_PATH" ] || continue

    COUNT=0
    while IFS= read -r -d '' f; do
        chmod +x "$f"
        COUNT=$((COUNT + 1))
        TOTAL=$((TOTAL + 1))
    done < <(find "$DIR_PATH" -type f \( \
        -name "*.py" -o -name "*.sh" -o -name "*.bash" \) -print0)

    echo -e "       ${GRN}✓${RST}  $d  — ${COUNT} files made executable"
done

# chmod the two root scripts themselves
chmod +x "$SCRIPT_DIR/zeus_extract_all.sh"
chmod +x "$SCRIPT_DIR/zeus_install_all.sh" 2>/dev/null && \
    echo -e "       ${GRN}✓${RST}  zeus_install_all.sh — executable" || true

echo ""
echo -e "       ${BLD}Total: ${TOTAL} files made executable${RST}"
echo ""

# ── Step 3: Full manifest ──────────────────────────────────────────────────────
echo -e "  ${BLD}[3/3] Full file manifest:${RST}"
echo ""
printf "  %-55s %12s\n" "FILE" "SIZE"
printf "  %-55s %12s\n" "$(printf '─%.0s' {1..55})" "$(printf '─%.0s' {1..12})"

GRAND_TOTAL=0

for d in $EXPECTED_DIRS; do
    DIR_PATH="$SCRIPT_DIR/$d"
    [ -d "$DIR_PATH" ] || continue

    echo -e "\n  ${CYN}${d}/${RST}"

    while IFS= read -r f; do
        rel="${f#$SCRIPT_DIR/}"
        # portable size: try stat -c (Linux) then stat -f (BSD/macOS)
        sz=$(stat -c%s "$f" 2>/dev/null || stat -f%z "$f" 2>/dev/null || echo 0)
        GRAND_TOTAL=$((GRAND_TOTAL + sz))
        printf "    %-53s %10s B\n" "$rel" "$(printf '%d' "$sz" | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')"
    done < <(find "$DIR_PATH" -type f | sort)
done

echo ""
printf "  %-55s %12s\n" "$(printf '─%.0s' {1..55})" "$(printf '─%.0s' {1..12})"
GRAND_TOTAL_FMT=$(printf '%d' "$GRAND_TOTAL" | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')
printf "  %-55s %10s B\n" "TOTAL" "$GRAND_TOTAL_FMT"

echo ""
echo -e "  ${GRN}${BLD}✓  All done. Run next:${RST}"
echo -e "     ${CYN}sudo bash zeus_install_all.sh${RST}"
echo ""
