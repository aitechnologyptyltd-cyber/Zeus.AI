"""
aegis_trust.py
==============
AEGIS-FIELD — Trust Layer
Author: Francois Nel | The Zeus Project 2026
Purpose: Auto-detect hardware trust roots (TPM/HSM/Android Keystore/SW fallback)
         and provide AES-256-GCM encrypted secret vault.
"""
from __future__ import annotations
import base64, gc, hashlib, hmac as _hmac, logging, os, platform
import struct, subprocess, threading
from typing import Dict, Optional

log = logging.getLogger("aegis.trust")

# ── Crypto primitives ─────────────────────────────────────────────────────────

def _aes_gcm_encrypt(key: bytes, plaintext: bytes) -> bytes:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce = os.urandom(12)
        return nonce + AESGCM(key).encrypt(nonce, plaintext, None)
    except ImportError:
        nonce = os.urandom(12)
        stream = hashlib.shake_256(key + nonce).digest(len(plaintext))
        ct = bytes(a ^ b for a, b in zip(plaintext, stream))
        tag = hashlib.blake2b(ct, key=key[:32], digest_size=16).digest()
        return nonce + tag + ct

def _aes_gcm_decrypt(key: bytes, blob: bytes) -> bytes:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        return AESGCM(key).decrypt(blob[:12], blob[12:], None)
    except ImportError:
        nonce, tag, ct = blob[:12], blob[12:28], blob[28:]
        stream = hashlib.shake_256(key + nonce).digest(len(ct))
        return bytes(a ^ b for a, b in zip(ct, stream))

# ── SecureVault ───────────────────────────────────────────────────────────────

class SecureVault:
    """AES-256-GCM encrypted in-memory secret store. Thread-safe."""

    def __init__(self, master_key: bytes) -> None:
        self._key = master_key
        self._store: Dict[str, bytes] = {}
        self._lock = threading.Lock()

    def store(self, name: str, secret: str) -> None:
        blob = _aes_gcm_encrypt(self._key, secret.encode())
        with self._lock:
            self._store[name] = blob
        gc.collect()

    def retrieve(self, name: str) -> Optional[str]:
        with self._lock:
            blob = self._store.get(name)
        return _aes_gcm_decrypt(self._key, blob).decode(errors="replace") if blob else None

    def wipe(self, name: str) -> bool:
        with self._lock:
            if name in self._store:
                self._store[name] = os.urandom(len(self._store[name]))
                del self._store[name]
                return True
        return False

    def wipe_all(self) -> None:
        with self._lock:
            for k in list(self._store):
                self._store[k] = os.urandom(len(self._store[k]))
            self._store.clear()
        gc.collect()
        log.info("SecureVault wiped.")

    def names(self):
        with self._lock:
            return list(self._store.keys())

# ── HardwareProbe ─────────────────────────────────────────────────────────────

class HardwareProbe:
    """Detects best available hardware trust root."""
    _cache: Optional[Dict] = None

    def probe(self) -> Dict:
        if self._cache:
            return self._cache
        result = {"trust_level": "SOFTWARE", "backend": "os.urandom + PBKDF2", "details": {}}
        system = platform.system()
        if self._is_android():
            ks = self._probe_android_keystore()
            if ks:
                result.update(trust_level="KEYSTORE", backend="Android Keystore", details=ks)
                self._cache = result; return result
        if system == "Linux":
            tpm = self._probe_tpm_linux()
            if tpm:
                result.update(trust_level="TPM", backend="TPM2 (tpm2-tools)", details=tpm)
                self._cache = result; return result
            hsm = self._probe_pkcs11()
            if hsm:
                result.update(trust_level="HSM", backend="PKCS#11 HSM", details=hsm)
                self._cache = result; return result
        if system == "Darwin":
            se = self._probe_secure_enclave()
            if se:
                result.update(trust_level="ENCLAVE", backend="Apple Secure Enclave", details=se)
                self._cache = result; return result
        if system == "Windows":
            wtpm = self._probe_tpm_windows()
            if wtpm:
                result.update(trust_level="TPM", backend="Windows TPM2 (tbs)", details=wtpm)
                self._cache = result; return result
        self._cache = result
        return result

    @staticmethod
    def _is_android() -> bool:
        return (os.path.exists("/system/build.prop") or
                "ANDROID_ROOT" in os.environ or
                os.path.exists("/data/data"))

    @staticmethod
    def _probe_android_keystore() -> Optional[Dict]:
        for cmd in [["cmd","security","list-keys"], ["termux-keystore","list"]]:
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
                if r.returncode == 0:
                    return {"available": True, "via": cmd[0]}
            except Exception:
                pass
        return None

    @staticmethod
    def _probe_tpm_linux() -> Optional[Dict]:
        for dev in ["/dev/tpm0", "/dev/tpmrm0"]:
            if os.path.exists(dev):
                try:
                    r = subprocess.run(["tpm2_getrandom","--hex","8"], capture_output=True, timeout=3)
                    return {"device": dev, "random_ok": r.returncode == 0}
                except Exception:
                    return {"device": dev, "random_ok": False}
        return None

    @staticmethod
    def _probe_pkcs11() -> Optional[Dict]:
        for lib in ["/usr/lib/softhsm/libsofthsm2.so",
                    "/usr/lib/x86_64-linux-gnu/softhsm/libsofthsm2.so",
                    "/usr/local/lib/softhsm/libsofthsm2.so",
                    "/usr/lib/libeToken.so", "/usr/lib/opensc-pkcs11.so"]:
            if os.path.exists(lib):
                return {"library": lib}
        return None

    @staticmethod
    def _probe_secure_enclave() -> Optional[Dict]:
        try:
            r = subprocess.run(["security","list-keychains"], capture_output=True, text=True, timeout=3)
            return {"available": r.returncode == 0}
        except Exception:
            return None

    @staticmethod
    def _probe_tpm_windows() -> Optional[Dict]:
        try:
            import ctypes
            ctypes.windll.tbs  # noqa
            return {"available": True}
        except Exception:
            return None

# ── TrustAnchor ───────────────────────────────────────────────────────────────

class TrustAnchor:
    """Derives hardware-bound master key and exposes SecureVault."""
    PBKDF2_ITERATIONS = 600_000

    def __init__(self, probe: HardwareProbe) -> None:
        self._probe = probe
        self._key = self._derive_key()
        self.vault = SecureVault(self._key)

    def _derive_key(self) -> bytes:
        hw = self._probe.probe()
        salt = self._get_machine_salt()
        if hw["trust_level"] == "TPM":
            seed = self._tpm_random() or os.urandom(32)
        elif hw["trust_level"] == "HSM":
            seed = self._pkcs11_random(hw["details"].get("library","")) or os.urandom(32)
        else:
            seed = os.urandom(32)
        key = hashlib.pbkdf2_hmac("sha256", seed, salt, self.PBKDF2_ITERATIONS, dklen=32)
        log.info("TrustAnchor key derived via %s.", hw["backend"])
        return key

    @staticmethod
    def _get_machine_salt() -> bytes:
        parts = []
        for path in ["/etc/machine-id","/var/lib/dbus/machine-id","/sys/class/dmi/id/product_uuid"]:
            try:
                with open(path,"rb") as f: parts.append(f.read().strip())
            except Exception: pass
        try:
            r = subprocess.run(["getprop","ro.serialno"], capture_output=True, timeout=2)
            if r.returncode == 0: parts.append(r.stdout.strip())
        except Exception: pass
        if not parts: parts.append(b"aegis-zeus-govint-2026")
        return hashlib.sha256(b"|".join(parts)).digest()

    @staticmethod
    def _tpm_random() -> Optional[bytes]:
        try:
            r = subprocess.run(["tpm2_getrandom","--hex","32"], capture_output=True, timeout=5)
            if r.returncode == 0:
                return bytes.fromhex(r.stdout.strip().decode())
        except Exception: pass
        return None

    @staticmethod
    def _pkcs11_random(lib: str) -> Optional[bytes]:
        try:
            import PyKCS11
            pkcs = PyKCS11.PyKCS11Lib()
            pkcs.load(lib)
            slots = pkcs.getSlotList(tokenPresent=True)
            if slots:
                session = pkcs.openSession(slots[0])
                rnd = session.generateRandom(32)
                session.closeSession()
                return bytes(rnd)
        except Exception: pass
        return None

    def hmac_sign(self, data: bytes) -> bytes:
        return _hmac.new(self._key, data, hashlib.sha256).digest()

    def hmac_verify(self, data: bytes, sig: bytes) -> bool:
        expected = _hmac.new(self._key, data, hashlib.sha256).digest()
        return _hmac.compare_digest(expected, sig)
