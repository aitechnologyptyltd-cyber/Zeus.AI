"""
aegis_field.py
==============
AEGIS-FIELD — Master Orchestrator
Author: Francois Nel | The Zeus Project 2026
Version: 1.0.0
"""
from __future__ import annotations
import logging, os, sys, threading, time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

try:
    # Package-relative import (when used as part of zeus_govint package)
    from .aegis_trust import HardwareProbe, TrustAnchor
    from .aegis_detect import (AntiDebugEngine, EnvironmentEngine,
                               IntegrityEngine, ProcessWatchdog, NetworkGuard)
    from .aegis_response import ExecutionLock, SecureWipe, DeceptionEngine
    from .aegis_forensic import ForensicCollector
except ImportError:
    # Flat standalone deployment (5 .py files copied into one directory)
    from aegis_trust import HardwareProbe, TrustAnchor
    from aegis_detect import (AntiDebugEngine, EnvironmentEngine,
                               IntegrityEngine, ProcessWatchdog, NetworkGuard)
    from aegis_response import ExecutionLock, SecureWipe, DeceptionEngine
    from aegis_forensic import ForensicCollector

log = logging.getLogger("aegis.field")
log.setLevel(logging.DEBUG)
if not log.handlers:
    _h = logging.StreamHandler(sys.stderr)
    _h.setFormatter(logging.Formatter("[%(asctime)s][AEGIS][%(levelname)s] %(message)s"))
    log.addHandler(_h)

@dataclass
class ThreatResult:
    ok: bool
    check: str
    detail: str = ""
    severity: str = "INFO"
    def __bool__(self): return self.ok

@dataclass
class ThreatReport:
    timestamp: float = field(default_factory=time.time)
    results: List[ThreatResult] = field(default_factory=list)

    @property
    def passed(self) -> bool: return all(r.ok for r in self.results)

    @property
    def critical(self) -> List[ThreatResult]:
        return [r for r in self.results if not r.ok and r.severity in ("CRITICAL","FATAL")]

    @property
    def fatal(self) -> List[ThreatResult]:
        return [r for r in self.results if not r.ok and r.severity == "FATAL"]

    def summary(self) -> str:
        ok = sum(1 for r in self.results if r.ok)
        lines = [f"AEGIS-FIELD ThreatReport {ok}/{len(self.results)} checks passed"]
        for r in self.results:
            lines.append(f"  {'✓' if r.ok else '✗'} [{r.severity:8s}] {r.check}: {r.detail}")
        return "\n".join(lines)

class AegisFieldEngine:
    VERSION = "1.0.0"

    def __init__(self,
                 protected_root: str,
                 allowed_ports: Optional[List[int]] = None,
                 scan_interval: int = 60,
                 watchdog_interval: int = 10,
                 threat_callback: Optional[Callable[[ThreatReport], None]] = None,
                 decoy_identity: Optional[Dict] = None):
        self.root = Path(protected_root).resolve()
        self.scan_interval = scan_interval
        self.watchdog_interval = watchdog_interval
        self._threat_cb = threat_callback or self._default_threat_handler
        self._scan_lock = threading.Lock()
        self._initialised = False

        self.hw_probe  = HardwareProbe()
        self.trust     = TrustAnchor(self.hw_probe)
        self.vault     = self.trust.vault

        self.integrity  = IntegrityEngine(str(self.root), self.trust)
        self.anti_debug = AntiDebugEngine()
        self.environment= EnvironmentEngine()
        self.watchdog   = ProcessWatchdog(
            alert_callback=lambda m: log.warning("WATCHDOG: %s", m))
        self.network    = NetworkGuard(allowed_ports or [])

        self.lock      = ExecutionLock()
        self.wipe      = SecureWipe(self.vault)
        self.deception = DeceptionEngine(decoy_identity)
        self.forensics = ForensicCollector(str(self.root), self.trust)

    def initialise(self) -> None:
        log.info("AEGIS-FIELD v%s initialising …", self.VERSION)
        hw = self.hw_probe.probe()
        log.info("Hardware trust: %s | backend: %s", hw["trust_level"], hw["backend"])
        n = self.integrity.build()
        log.info("Integrity baseline: %d files.", n)
        self.watchdog.start(self.watchdog_interval)
        self.forensics.start()
        self.deception.arm()
        self._initialised = True
        log.info("AEGIS-FIELD ready. Root: %s", self.root)

    def shutdown(self) -> None:
        self.watchdog.stop()
        self.forensics.stop()
        self.vault.wipe_all()
        self.lock.release()
        log.info("AEGIS-FIELD shut down.")

    def full_scan(self) -> ThreatReport:
        with self._scan_lock:
            report = ThreatReport()
            for r in self.anti_debug.run_all():
                report.results.append(ThreatResult(r.ok, r.check, r.detail, r.severity))
            for r in self.environment.run_all():
                report.results.append(ThreatResult(r.ok, r.check, r.detail, r.severity))
            ir = self.integrity.verify()
            report.results.append(ThreatResult(ir.ok, ir.check, ir.detail, ir.severity))
            nr = self.network.check()
            report.results.append(ThreatResult(nr.ok, nr.check, nr.detail, nr.severity))
            wr = self.watchdog.check_now()
            report.results.append(ThreatResult(wr.ok, wr.check, wr.detail, wr.severity))
            if report.critical or report.fatal:
                self._respond(report)
            return report

    def quick_scan(self) -> ThreatReport:
        with self._scan_lock:
            report = ThreatReport()
            for check in [self.anti_debug.check_tracerpid,
                          self.anti_debug.check_sys_gettrace,
                          self.environment.check_env_vars,
                          self.integrity.verify]:
                r = check()
                report.results.append(ThreatResult(r.ok, r.check, r.detail, r.severity))
            if report.critical or report.fatal:
                self._respond(report)
            return report

    def start_auto_scan(self, full: bool = False) -> threading.Thread:
        def _loop():
            while True:
                time.sleep(self.scan_interval)
                self.full_scan() if full else self.quick_scan()
        t = threading.Thread(target=_loop, daemon=True, name="aegis-autoscan")
        t.start()
        log.info("Auto-scan started (interval=%ds).", self.scan_interval)
        return t

    def _respond(self, report: ThreatReport) -> None:
        self.forensics.capture_snapshot(report)
        if report.fatal:
            log.critical("FATAL THREAT — full response.")
            self.deception.activate_honeypot()
            self.deception.deploy_decoys()
            self.wipe.emergency_wipe()
            self.lock.hard_lock("FATAL threat detected")
        elif report.critical:
            log.critical("CRITICAL THREAT — locking + deception.")
            self.deception.deploy_decoys()
            self.lock.soft_lock("CRITICAL threat detected")
            self._threat_cb(report)

    @staticmethod
    def _default_threat_handler(report: ThreatReport) -> None:
        log.critical("THREAT DETECTED:\n%s", report.summary())

    def status(self) -> str:
        report = self.quick_scan()
        state = "CLEAN" if report.passed else "THREAT"
        fails = len(report.critical)
        hw = self.hw_probe.probe()
        return (f"AEGIS-FIELD [{state}] | trust={hw['trust_level']} "
                f"| backend={hw['backend']} | critical_failures={fails}")
