"""
aegis_forensic.py
=================
AEGIS-FIELD — Forensic Evidence Collector
Author: Francois Nel | The Zeus Project 2026
Purpose: HMAC-signed forensic snapshots, MITRE ATT&CK TTP mapping,
         chain-of-custody bundles for law enforcement / incident response.
"""
from __future__ import annotations
import hashlib, json, logging, os, platform, socket, subprocess
import threading, time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger("aegis.forensic")

TTP_MAP = {
    "tracerpid":       ("T1055",     "Process Injection / Debugger Attach"),
    "ptrace":          ("T1055",     "Process Injection / ptrace attach"),
    "sys_gettrace":    ("T1622",     "Debugger Evasion — Python tracer detected"),
    "debugger_procs":  ("T1622",     "Debugger Evasion — known debugger process"),
    "timing":          ("T1497",     "Virtualization/Sandbox Evasion — timing"),
    "vm_dmi":          ("T1497.001", "Virtualization Evasion — VM DMI markers"),
    "env_vars":        ("T1497.003", "User Activity Checks — sandbox env vars"),
    "hostname":        ("T1497",     "Sandbox detection via hostname"),
    "watchdog":        ("T1057",     "Process Discovery — analysis tools running"),
    "integrity":       ("T1565.001", "Stored Data Manipulation — file tampering"),
    "network_guard":   ("T1571",     "Non-Standard Port usage"),
}

# ── EvidenceRecord ────────────────────────────────────────────────────────────

class EvidenceRecord:
    def __init__(self, incident_id: str, trust_anchor) -> None:
        self.incident_id = incident_id
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.epoch = time.time()
        self._trust = trust_anchor
        self.data: Dict = {}
        self.signature: Optional[bytes] = None

    def seal(self) -> None:
        payload = json.dumps(self.data, sort_keys=True, default=str).encode()
        self.signature = self._trust.hmac_sign(payload)
        log.info("Evidence sealed: %s", self.incident_id)

    def verify(self) -> bool:
        if not self.signature: return False
        payload = json.dumps(self.data, sort_keys=True, default=str).encode()
        return self._trust.hmac_verify(payload, self.signature)

    def to_dict(self) -> Dict:
        return {
            "incident_id": self.incident_id,
            "timestamp": self.timestamp,
            "epoch": self.epoch,
            "data": self.data,
            "signature": self.signature.hex() if self.signature else None,
            "verified": self.verify(),
        }

# ── ForensicCollector ─────────────────────────────────────────────────────────

class ForensicCollector:
    def __init__(self, protected_root: str, trust_anchor) -> None:
        self.root = Path(protected_root).resolve()
        self._trust = trust_anchor
        self._records: List[EvidenceRecord] = []
        self._lock = threading.Lock()
        self._running = False
        self._incident_seq = 0

    def start(self) -> None:
        self._running = True
        log.info("ForensicCollector active.")

    def stop(self) -> None:
        self._running = False

    def capture_snapshot(self, threat_report) -> EvidenceRecord:
        self._incident_seq += 1
        incident_id = f"INC-{int(time.time())}-{self._incident_seq:04d}"
        log.critical("Capturing forensic snapshot: %s", incident_id)
        rec = EvidenceRecord(incident_id, self._trust)
        rec.data = {
            "incident_id": incident_id,
            "threat_report": self._serialise_report(threat_report),
            "system_state": self._capture_system_state(),
            "network_state": self._capture_network_state(),
            "process_state": self._capture_process_state(),
            "environment": self._capture_environment(),
            "attacker_fingerprint": self._build_attacker_fingerprint(threat_report),
            "chain_of_custody": self._chain_of_custody(incident_id),
        }
        rec.seal()
        with self._lock: self._records.append(rec)
        return rec

    @staticmethod
    def _serialise_report(report) -> Dict:
        return {
            "passed": report.passed,
            "results": [{"ok": r.ok, "check": r.check, "detail": r.detail, "severity": r.severity}
                        for r in report.results],
        }

    @staticmethod
    def _capture_system_state() -> Dict:
        state: Dict[str, Any] = {
            "platform": platform.platform(),
            "node": platform.node(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python": platform.python_version(),
            "pid": os.getpid(),
            "ppid": os.getppid(),
            "uid": getattr(os,"getuid",lambda:-1)(),
            "gid": getattr(os,"getgid",lambda:-1)(),
            "cwd": os.getcwd(),
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        }
        try:
            with open("/proc/uptime") as f:
                state["uptime_seconds"] = float(f.read().split()[0])
        except Exception: pass
        try: state["load_avg"] = list(os.getloadavg())
        except Exception: pass
        return state

    @staticmethod
    def _capture_network_state() -> Dict:
        net: Dict[str, Any] = {}
        try:
            net["hostname"] = socket.gethostname()
            net["fqdn"] = socket.getfqdn()
            net["local_ips"] = socket.gethostbyname_ex(socket.gethostname())[2]
        except Exception: pass
        listening = []
        for tcp_file in ("/proc/net/tcp", "/proc/net/tcp6"):
            try:
                with open(tcp_file) as f:
                    for line in f.readlines()[1:]:
                        parts = line.split()
                        if len(parts) < 4 or parts[3] != "0A": continue
                        listening.append(int(parts[1].rsplit(":",1)[1], 16))
            except Exception: pass
        net["listening_ports"] = sorted(set(listening))
        try:
            with open("/proc/net/tcp") as f:
                net["established_connections"] = sum(
                    1 for line in f.readlines()[1:]
                    if len(line.split()) > 3 and line.split()[3] == "01"
                )
        except Exception: pass
        try:
            r = subprocess.run(["traceroute","-m","5","-q","1","-w","1","8.8.8.8"],
                               capture_output=True, text=True, timeout=10)
            net["routing_hops"] = r.stdout.strip().splitlines()[:6]
        except Exception: net["routing_hops"] = []
        return net

    @staticmethod
    def _capture_process_state() -> Dict:
        procs = []
        try:
            for entry in Path("/proc").iterdir():
                if not entry.name.isdigit(): continue
                try:
                    pid = int(entry.name)
                    comm = (entry/"comm").read_text().strip()
                    try:
                        cmdline = (entry/"cmdline").read_bytes().replace(b"\x00",b" ").decode(errors="replace").strip()
                    except Exception: cmdline = ""
                    procs.append({"pid": pid, "name": comm, "cmdline": cmdline[:200]})
                except Exception: pass
        except Exception: pass
        return {"count": len(procs), "processes": procs[:100]}

    @staticmethod
    def _capture_environment() -> Dict:
        safe_env = {}
        secret_patterns = ("key","secret","token","password","passwd","pwd","auth")
        for k, v in os.environ.items():
            safe_env[k] = "[REDACTED]" if any(p in k.lower() for p in secret_patterns) else v[:200]
        return safe_env

    @staticmethod
    def _build_attacker_fingerprint(report) -> Dict:
        fp: Dict[str, Any] = {"triggered_checks": [], "inferred_ttps": [], "threat_level": "LOW"}
        fatal_count = critical_count = 0
        for r in report.results:
            if not r.ok:
                fp["triggered_checks"].append({"check": r.check, "severity": r.severity, "detail": r.detail})
                if r.check in TTP_MAP:
                    tid, desc = TTP_MAP[r.check]
                    fp["inferred_ttps"].append({"mitre_id": tid, "description": desc, "check": r.check})
                if r.severity == "FATAL": fatal_count += 1
                elif r.severity == "CRITICAL": critical_count += 1
        if fatal_count > 0: fp["threat_level"] = "FATAL"
        elif critical_count > 0: fp["threat_level"] = "CRITICAL"
        elif fp["triggered_checks"]: fp["threat_level"] = "WARN"
        return fp

    @staticmethod
    def _chain_of_custody(incident_id: str) -> Dict:
        return {
            "incident_id": incident_id,
            "collected_by": "AEGIS-FIELD v1.0.0 / Zeus GovInt v1.0",
            "collector_pid": os.getpid(),
            "collection_utc": datetime.now(timezone.utc).isoformat(),
            "platform": platform.platform(),
            "attribution": "The Zeus Project 2026 — Francois Nel",
            "note": (
                "Evidence captured automatically by AEGIS-FIELD. "
                "HMAC signature is hardware-bound. Suitable for incident response handoff."
            ),
        }

    def export_bundle(self, output_path: str) -> str:
        with self._lock:
            bundle = {
                "bundle_id": f"AEGIS-BUNDLE-{int(time.time())}",
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "incident_count": len(self._records),
                "incidents": [r.to_dict() for r in self._records],
            }
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(bundle, indent=2, default=str))
        log.info("Evidence bundle exported: %s (%d incidents)", output_path, len(self._records))
        return output_path

    def human_readable_report(self) -> str:
        with self._lock: records = list(self._records)
        lines = [
            "■"*66, "■  AEGIS-FIELD — INCIDENT REPORT", "■"*66,
            f" Generated : {datetime.now(timezone.utc).isoformat()}",
            f" Total incidents: {len(records)}", "",
        ]
        for rec in records:
            fp = rec.data.get("attacker_fingerprint", {})
            sys_ = rec.data.get("system_state", {})
            net = rec.data.get("network_state", {})
            coc = rec.data.get("chain_of_custody", {})
            lines += [
                f" ■■ Incident : {rec.incident_id}",
                f" ■ Timestamp : {rec.timestamp}",
                f" ■ Threat    : {fp.get('threat_level','UNKNOWN')}",
                f" ■ Platform  : {sys_.get('platform','unknown')}",
                f" ■ Hostname  : {net.get('hostname','unknown')}",
                f" ■ Sig OK    : {rec.verify()}",
                " ■ Triggered Checks:",
            ]
            for chk in fp.get("triggered_checks", []):
                lines.append(f"   [{chk['severity']:8s}] {chk['check']}: {chk['detail'][:80]}")
            lines.append(" ■ MITRE ATT&CK TTPs:")
            for ttp in fp.get("inferred_ttps", []):
                lines.append(f"   {ttp['mitre_id']:12s} — {ttp['description']}")
            lines += [f" ■ Chain-of-custody: {coc.get('collected_by','AEGIS-FIELD')}", ""]
        lines.append("■"*66)
        return "\n".join(lines)

    @property
    def incident_count(self) -> int:
        with self._lock: return len(self._records)
