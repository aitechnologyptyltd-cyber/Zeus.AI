"""
aegis_response.py
=================
AEGIS-FIELD — Response Layer
Author: Francois Nel | The Zeus Project 2026
Purpose: ExecutionLock, SecureWipe (DoD 5220.22-M), DeceptionEngine, HoneypotLogger
"""
from __future__ import annotations
import gc, json, logging, os, platform, random, signal, string
import sys, threading, time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("aegis.response")

# ── ExecutionLock ─────────────────────────────────────────────────────────────

class ExecutionLock:
    def __init__(self) -> None:
        self._locked = threading.Event()
        self._hard = False
        self._reason = ""
        self._lock_time: Optional[float] = None

    @property
    def is_locked(self) -> bool: return self._locked.is_set()

    def soft_lock(self, reason: str = "Threat detected") -> None:
        self._reason = reason
        self._lock_time = time.time()
        self._locked.set()
        log.critical("SOFT LOCK: %s", reason)

    def hard_lock(self, reason: str = "Fatal threat") -> None:
        self._reason = reason
        self._hard = True
        self._locked.set()
        log.critical("HARD LOCK: %s — halting.", reason)
        time.sleep(0.5)
        os.kill(os.getpid(), signal.SIGTERM)

    def release(self) -> None:
        self._locked.clear()
        self._hard = False
        self._reason = ""
        log.info("ExecutionLock released.")

    def assert_unlocked(self) -> None:
        if self._locked.is_set():
            raise RuntimeError(f"AEGIS ExecutionLock active: {self._reason}")

    def status(self) -> Dict:
        return {"locked": self._locked.is_set(), "hard": self._hard,
                "reason": self._reason, "lock_time": self._lock_time}

# ── SecureWipe ────────────────────────────────────────────────────────────────

class SecureWipe:
    """Emergency destruction following DoD 5220.22-M 3-pass overwrite."""
    DOD_PASSES = 3

    def __init__(self, vault) -> None:
        self._vault = vault
        self._file_targets: List[str] = []
        self._callbacks: List[Callable] = []

    def register_file(self, path: str) -> None: self._file_targets.append(path)
    def register_callback(self, fn: Callable) -> None: self._callbacks.append(fn)

    def emergency_wipe(self) -> None:
        log.critical("EMERGENCY WIPE initiated.")
        try: self._vault.wipe_all(); log.info("[✓] Vault wiped.")
        except Exception as e: log.error("[✗] Vault wipe failed: %s", e)
        for path in self._file_targets: self._wipe_file(path)
        for fn in self._callbacks:
            try: fn(); log.info("[✓] Callback %s.", getattr(fn,"__name__","?"))
            except Exception as e: log.error("[✗] Callback failed: %s", e)
        gc.collect()
        log.critical("EMERGENCY WIPE complete.")

    def _wipe_file(self, path: str) -> None:
        p = Path(path)
        if not p.exists(): return
        try:
            size = p.stat().st_size
            with open(p,"r+b") as f:
                for pat in [b"\x00", b"\xFF", None]:
                    f.seek(0)
                    f.write(os.urandom(size) if pat is None else pat * size)
                    f.flush(); os.fsync(f.fileno())
            p.unlink()
            log.info("[✓] File wiped: %s", path)
        except Exception as e:
            log.error("[✗] File wipe failed %s: %s", path, e)

# ── HoneypotLogger ────────────────────────────────────────────────────────────

class HoneypotLogger:
    def __init__(self) -> None:
        self.entries: List[Dict] = []
        self._lock = threading.Lock()
        self._running = False
        self._start_ts: Optional[float] = None

    def start(self) -> None:
        self._running = True
        self._start_ts = time.time()
        log.info("HoneypotLogger started.")

    def stop(self) -> None: self._running = False

    def log_query(self, query_type: str, data: Any = None) -> None:
        if not self._running: return
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "epoch": time.time(),
            "query": query_type,
            "data": data,
            "pid": os.getpid(),
            "session_age": round(time.time() - (self._start_ts or time.time()), 2),
        }
        with self._lock: self.entries.append(entry)
        log.warning("HONEYPOT query: %s", query_type)

    def log_command(self, command: str, response: str = "") -> None:
        self.log_query("command", {"cmd": command, "response": response})

    def report(self) -> str:
        with self._lock:
            lines = ["■"*60, " AEGIS-FIELD HONEYPOT SESSION REPORT",
                     f" Session start : {datetime.fromtimestamp(self._start_ts or 0, timezone.utc).isoformat()}",
                     f" Total queries : {len(self.entries)}", "■"*60]
            for i, e in enumerate(self.entries, 1):
                lines.append(f" [{i:04d}] {e['ts']} +{e['session_age']:>8.2f}s {e['query']}")
                if e.get("data"): lines.append(f"       data={json.dumps(e['data'])[:120]}")
            lines.append("■"*60)
            return "\n".join(lines)

    def export_json(self) -> str:
        with self._lock:
            return json.dumps({"session_start": self._start_ts,
                               "entry_count": len(self.entries),
                               "entries": self.entries}, indent=2)

# ── DeceptionEngine ───────────────────────────────────────────────────────────

class DeceptionEngine:
    """PASSIVE → DECOY → HONEYPOT deception modes."""
    DEFAULT_IDENTITY = {
        "hostname": "prod-web-01",
        "os": "Ubuntu 22.04.3 LTS",
        "kernel": "5.15.0-91-generic",
        "processes": ["systemd","sshd","nginx","postgres","redis-server","cron","rsyslogd"],
        "users": ["root","ubuntu","deploy","postgres"],
        "files": ["/etc/passwd","/etc/hosts","/var/log/syslog","/var/log/auth.log"],
        "open_ports": [22, 80, 443, 5432],
        "fake_creds": {
            "db_password": "P@ssw0rd_2024!",
            "api_key": "sk-" + "".join(random.choices(string.hexdigits, k=48)),
            "ssh_key_hint": "id_rsa (RSA 4096)",
        },
    }

    def __init__(self, identity: Optional[Dict] = None) -> None:
        self._identity = identity or self.DEFAULT_IDENTITY
        self._mode = "PASSIVE"
        self._honeypot = HoneypotLogger()
        self._armed = False

    def arm(self) -> None:
        self._armed = True
        log.info("DeceptionEngine armed (PASSIVE).")

    def deploy_decoys(self) -> None:
        self._mode = "DECOY"
        log.critical("DeceptionEngine: DECOY mode activated.")

    def activate_honeypot(self) -> None:
        self._mode = "HONEYPOT"
        self._honeypot.start()
        log.critical("DeceptionEngine: HONEYPOT mode — logging attacker session.")

    def get_process_list(self) -> List[str]:
        if self._mode in ("DECOY","HONEYPOT"):
            self._honeypot.log_query("process_list")
            return self._identity["processes"]
        return self._real_process_list()

    def get_file_listing(self, path: str = "/") -> List[str]:
        if self._mode in ("DECOY","HONEYPOT"):
            self._honeypot.log_query(f"file_listing:{path}")
            return self._identity["files"]
        return []

    def get_credentials(self, name: str = "db_password") -> str:
        if self._mode in ("DECOY","HONEYPOT"):
            self._honeypot.log_query(f"credentials:{name}")
            return self._identity["fake_creds"].get(name, "hunter2")
        return ""

    def get_hostname(self) -> str:
        if self._mode in ("DECOY","HONEYPOT"):
            self._honeypot.log_query("hostname")
            return self._identity["hostname"]
        return platform.node()

    def get_open_ports(self) -> List[int]:
        if self._mode in ("DECOY","HONEYPOT"):
            self._honeypot.log_query("open_ports")
            return self._identity["open_ports"]
        return []

    def get_system_info(self) -> Dict:
        if self._mode in ("DECOY","HONEYPOT"):
            self._honeypot.log_query("system_info")
            return {"hostname": self._identity["hostname"],
                    "os": self._identity["os"],
                    "kernel": self._identity["kernel"],
                    "users": self._identity["users"],
                    "uptime": f"{random.randint(30,180)} days"}
        return {}

    @property
    def mode(self) -> str: return self._mode

    @property
    def honeypot_log(self) -> List[Dict]: return self._honeypot.entries

    def honeypot_report(self) -> str: return self._honeypot.report()

    @staticmethod
    def _real_process_list() -> List[str]:
        procs = []
        try:
            if platform.system() in ("Linux","Android"):
                for e in Path("/proc").iterdir():
                    if e.name.isdigit():
                        try: procs.append((e/"comm").read_text().strip())
                        except Exception: pass
        except Exception: pass
        return procs
