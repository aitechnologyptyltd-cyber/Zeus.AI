"""
aegis_detect.py
===============
AEGIS-FIELD — Detection Layer
Author: Francois Nel | The Zeus Project 2026
Purpose: Anti-debug, environment fingerprinting, integrity verification,
         process watchdog, network exposure detection.
"""
from __future__ import annotations
import ctypes, hashlib, logging, os, platform, re, socket
import subprocess, sys, threading, time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

log = logging.getLogger("aegis.detect")

def _is_linux() -> bool: return platform.system() == "Linux"
def _is_windows() -> bool: return platform.system() == "Windows"
def _is_android() -> bool:
    return os.path.exists("/system/build.prop") or "ANDROID_ROOT" in os.environ

def _safe_read(path: str) -> str:
    try:
        with open(path, "r", errors="replace") as f: return f.read()
    except Exception: return ""

@dataclass
class StealthResult:
    ok: bool
    check: str
    detail: str = ""
    severity: str = "INFO"
    def __bool__(self): return self.ok

# ── AntiDebugEngine ───────────────────────────────────────────────────────────

class AntiDebugEngine:
    DEBUGGER_NAMES = {
        "gdb","lldb","pdb","pydevd","debugpy","strace","ltrace","ptrace",
        "ida64","ida","x64dbg","x32dbg","ollydbg","radare2","r2","windbg",
        "cdb","ntsd","frida","frida-server","objection","jdwp",
    }

    def check_tracerpid(self) -> StealthResult:
        if not _is_linux(): return StealthResult(True,"tracerpid","N/A.")
        m = re.search(r"TracerPid:\s*(\d+)", _safe_read("/proc/self/status"))
        if m and int(m.group(1)) != 0:
            return StealthResult(False,"tracerpid",f"Tracer PID={m.group(1)} attached.","FATAL")
        return StealthResult(True,"tracerpid","No tracer attached.")

    def check_ptrace_self(self) -> StealthResult:
        if not _is_linux(): return StealthResult(True,"ptrace","N/A.")
        try:
            res = ctypes.CDLL("libc.so.6", use_errno=True).ptrace(0, 0, 0, 0)
            if res == -1:
                return StealthResult(False,"ptrace","ptrace failed — traced.","FATAL")
            ctypes.CDLL("libc.so.6").ptrace(17, 0, 0, 0)
        except Exception as e:
            return StealthResult(True,"ptrace",f"skipped: {e}")
        return StealthResult(True,"ptrace","Not traced.")

    def check_sys_gettrace(self) -> StealthResult:
        tracer = sys.gettrace()
        if tracer is not None:
            return StealthResult(False,"sys_gettrace",f"Tracer: {getattr(tracer,'__name__',repr(tracer))}","CRITICAL")
        return StealthResult(True,"sys_gettrace","No Python tracer.")

    def check_debugger_processes(self) -> StealthResult:
        found: List[str] = []
        try:
            if _is_linux() or _is_android():
                for e in Path("/proc").iterdir():
                    if not e.name.isdigit(): continue
                    comm = _safe_read(str(e/"comm")).strip().lower()
                    if comm in self.DEBUGGER_NAMES: found.append(comm)
            elif _is_windows():
                r = subprocess.run(["tasklist","/fo","csv","/nh"], capture_output=True, text=True, timeout=5)
                for line in r.stdout.splitlines():
                    name = line.split(",")[0].strip('"').lower().replace(".exe","")
                    if name in self.DEBUGGER_NAMES: found.append(name)
        except Exception as e:
            return StealthResult(True,"debugger_procs",f"Scan skipped: {e}")
        if found:
            return StealthResult(False,"debugger_procs",f"Debugger processes: {found}","CRITICAL")
        return StealthResult(True,"debugger_procs","No debugger processes.")

    def check_timing(self) -> StealthResult:
        start = time.perf_counter()
        acc = 0
        for i in range(500_000): acc ^= i
        elapsed = time.perf_counter() - start
        if elapsed > 2.0:
            return StealthResult(False,"timing",f"Loop {elapsed:.3f}s > 2.0s — debugger slowdown.","WARN")
        return StealthResult(True,"timing",f"Loop {elapsed:.4f}s — normal.")

    def check_android_jdwp(self) -> StealthResult:
        if not _is_android(): return StealthResult(True,"android_jdwp","N/A.")
        try:
            r = subprocess.run(["getprop","ro.debuggable"], capture_output=True, text=True, timeout=2)
            if r.stdout.strip() == "1":
                return StealthResult(False,"android_jdwp","ro.debuggable=1 — debug build.","WARN")
        except Exception: pass
        return StealthResult(True,"android_jdwp","ro.debuggable=0.")

    def run_all(self) -> List[StealthResult]:
        return [self.check_tracerpid(), self.check_ptrace_self(),
                self.check_sys_gettrace(), self.check_debugger_processes(),
                self.check_timing(), self.check_android_jdwp()]

# ── EnvironmentEngine ─────────────────────────────────────────────────────────

class EnvironmentEngine:
    VM_PATHS = ["/sys/class/dmi/id/product_name","/sys/class/dmi/id/sys_vendor",
                "/sys/class/dmi/id/board_vendor"]
    VM_KEYWORDS = {"virtualbox","vmware","qemu","kvm","xen","hyper-v","parallels","bochs","bhyve","innotek","vbox"}
    SANDBOX_ENVVARS = {"CUCKOO","SANDBOX","ANALYSIS","MALWARE","VMWARE_TOOLS","VBOX_INSTALL_PATH",
                       "VBOX_USER_HOME","ANY_RUN","TRIAGE"}
    SANDBOX_HOSTNAMES = {"cuckoo","sandbox","malware","virus","analyze","honey","anyrun","triage","cape"}
    SUSPICIOUS_USERS = {"sandbox","malware","virus","analysis","tester","sample","test"}

    def check_vm_dmi(self) -> StealthResult:
        if not _is_linux(): return StealthResult(True,"vm_dmi","N/A.")
        hits = []
        for path in self.VM_PATHS:
            content = _safe_read(path).lower()
            for kw in self.VM_KEYWORDS:
                if kw in content: hits.append(f"{Path(path).name}={kw}")
        if hits: return StealthResult(False,"vm_dmi",f"VM indicators: {hits}","CRITICAL")
        return StealthResult(True,"vm_dmi","No VM DMI markers.")

    def check_cpu_count(self) -> StealthResult:
        count = os.cpu_count() or 1
        if count < 2: return StealthResult(False,"cpu_count",f"Only {count} CPU — sandbox.","WARN")
        return StealthResult(True,"cpu_count",f"{count} CPUs.")

    def check_env_vars(self) -> StealthResult:
        found = [k for k in self.SANDBOX_ENVVARS if k in os.environ]
        if found: return StealthResult(False,"env_vars",f"Sandbox env vars: {found}","FATAL")
        return StealthResult(True,"env_vars","No sandbox env vars.")

    def check_hostname(self) -> StealthResult:
        try: hostname = socket.gethostname().lower()
        except Exception: return StealthResult(True,"hostname","Could not resolve.")
        for kw in self.SANDBOX_HOSTNAMES:
            if kw in hostname: return StealthResult(False,"hostname",f"Suspicious hostname: {hostname!r}","WARN")
        return StealthResult(True,"hostname",f"Hostname {hostname!r} OK.")

    def check_username(self) -> StealthResult:
        try:
            import getpass
            user = getpass.getuser().lower()
        except Exception: return StealthResult(True,"username","Could not determine.")
        if user in self.SUSPICIOUS_USERS:
            return StealthResult(False,"username",f"Suspicious user: {user!r}","WARN")
        return StealthResult(True,"username",f"User {user!r} OK.")

    def check_uptime(self) -> StealthResult:
        if not (_is_linux() or _is_android()): return StealthResult(True,"uptime","N/A.")
        content = _safe_read("/proc/uptime")
        if not content: return StealthResult(True,"uptime","Could not read.")
        try:
            secs = float(content.split()[0])
            if secs < 120: return StealthResult(False,"uptime",f"Uptime {secs:.0f}s — fresh sandbox?","WARN")
            return StealthResult(True,"uptime",f"Uptime {secs:.0f}s — OK.")
        except Exception: return StealthResult(True,"uptime","Parse error.")

    def check_disk_space(self) -> StealthResult:
        try:
            st = os.statvfs("/") if hasattr(os,"statvfs") else None
            if not st: return StealthResult(True,"disk_space","N/A.")
            total_gb = (st.f_blocks * st.f_frsize) / (1024**3)
            if total_gb < 10: return StealthResult(False,"disk_space",f"Only {total_gb:.1f}GB — sandbox.","WARN")
            return StealthResult(True,"disk_space",f"{total_gb:.1f}GB — OK.")
        except Exception as e: return StealthResult(True,"disk_space",f"Skipped: {e}")

    def check_proc_count(self) -> StealthResult:
        if not (_is_linux() or _is_android()): return StealthResult(True,"proc_count","N/A.")
        try:
            count = len([e for e in Path("/proc").iterdir() if e.name.isdigit()])
            if count < 20: return StealthResult(False,"proc_count",f"Only {count} procs — sandbox.","WARN")
            return StealthResult(True,"proc_count",f"{count} processes — OK.")
        except Exception as e: return StealthResult(True,"proc_count",f"Skipped: {e}")

    def run_all(self) -> List[StealthResult]:
        return [self.check_vm_dmi(), self.check_cpu_count(), self.check_env_vars(),
                self.check_hostname(), self.check_username(), self.check_uptime(),
                self.check_disk_space(), self.check_proc_count()]

# ── IntegrityEngine ───────────────────────────────────────────────────────────

class IntegrityEngine:
    def __init__(self, root_dir: str, trust_anchor) -> None:
        self.root = Path(root_dir).resolve()
        self._trust = trust_anchor
        self._manifest: Dict[str, str] = {}
        self._sig: bytes = b""
        self._lock = threading.Lock()

    def _file_digest(self, path: Path) -> str:
        h = hashlib.sha256()
        with open(path,"rb") as f:
            for chunk in iter(lambda: f.read(65536), b""): h.update(chunk)
        return h.hexdigest()

    def build(self) -> int:
        with self._lock:
            self._manifest.clear()
            for py in self.root.rglob("*.py"):
                rel = str(py.relative_to(self.root))
                self._manifest[rel] = self._file_digest(py)
            payload = "|".join(f"{k}:{v}" for k,v in sorted(self._manifest.items())).encode()
            self._sig = self._trust.hmac_sign(payload)
        log.info("Integrity baseline: %d files.", len(self._manifest))
        return len(self._manifest)

    def verify(self) -> StealthResult:
        with self._lock:
            if not self._manifest:
                return StealthResult(False,"integrity","Baseline not built.","CRITICAL")
            tampered, missing = [], []
            for rel, expected in self._manifest.items():
                full = self.root / rel
                if not full.exists(): missing.append(rel); continue
                if self._file_digest(full) != expected: tampered.append(rel)
            payload = "|".join(f"{k}:{v}" for k,v in sorted(self._manifest.items())).encode()
            if not self._trust.hmac_verify(payload, self._sig):
                return StealthResult(False,"integrity","Manifest HMAC mismatch — in-memory tampering.","FATAL")
            if tampered or missing:
                return StealthResult(False,"integrity",f"tampered={tampered[:5]} missing={missing[:5]}","FATAL")
        return StealthResult(True,"integrity",f"{len(self._manifest)} files verified clean.")

# ── ProcessWatchdog ───────────────────────────────────────────────────────────

class ProcessWatchdog:
    SCAN_TOOLS = {"lsof","strace","ltrace","auditd","tcpdump","wireshark","tshark",
                  "netstat","ss","nmap","masscan","bpftrace","perf","systemtap",
                  "valgrind","dtruss","dtrace","procmon","procexp","processhacker"}

    def __init__(self, alert_callback: Optional[Callable[[str],None]] = None):
        self._cb = alert_callback or (lambda m: log.warning("WATCHDOG: %s", m))
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._interval = 10

    def _scan_once(self) -> List[str]:
        found = []
        try:
            if _is_linux() or _is_android():
                for e in Path("/proc").iterdir():
                    if not e.name.isdigit(): continue
                    comm = _safe_read(str(e/"comm")).strip().lower()
                    if comm in self.SCAN_TOOLS: found.append(comm)
            elif _is_windows():
                r = subprocess.run(["tasklist","/fo","csv","/nh"], capture_output=True, text=True, timeout=5)
                for line in r.stdout.splitlines():
                    name = line.split(",")[0].strip('"').lower().replace(".exe","")
                    if name in self.SCAN_TOOLS: found.append(name)
        except Exception: pass
        return found

    def _loop(self):
        while self._running:
            hits = self._scan_once()
            if hits: self._cb(f"Analysis tools detected: {hits}")
            time.sleep(self._interval)

    def start(self, interval: int = 10):
        self._interval = interval
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="aegis-watchdog")
        self._thread.start()
        log.info("ProcessWatchdog started (%ds).", interval)

    def stop(self):
        self._running = False
        if self._thread: self._thread.join(timeout=5)

    def check_now(self) -> StealthResult:
        hits = self._scan_once()
        if hits: return StealthResult(False,"watchdog",f"Analysis tools: {hits}","CRITICAL")
        return StealthResult(True,"watchdog","No analysis tools.")

# ── NetworkGuard ──────────────────────────────────────────────────────────────

class NetworkGuard:
    def __init__(self, allowed_ports: List[int]):
        self.allowed = set(allowed_ports)

    def _listening_ports(self) -> List[Tuple[str,int]]:
        results = []
        if not (_is_linux() or _is_android()): return results
        for path in ("/proc/net/tcp","/proc/net/tcp6"):
            content = _safe_read(path)
            for line in content.splitlines()[1:]:
                parts = line.split()
                if len(parts) < 4 or parts[3] != "0A": continue
                port = int(parts[1].rsplit(":",1)[1], 16)
                results.append((parts[1], port))
        return results

    def check(self) -> StealthResult:
        ports = self._listening_ports()
        if not ports: return StealthResult(True,"network_guard","No unexpected sockets.")
        exposed = [p for _,p in ports if p not in self.allowed]
        if exposed: return StealthResult(False,"network_guard",f"Unexpected ports: {exposed}","WARN")
        return StealthResult(True,"network_guard",f"All ports {[p for _,p in ports]} whitelisted.")
