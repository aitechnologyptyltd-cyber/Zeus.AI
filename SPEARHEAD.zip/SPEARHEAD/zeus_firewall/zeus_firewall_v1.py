#!/usr/bin/env python3
"""
zeus_firewall_v1.py
The Zeus Project 2026 — Francois Nel

21-Step Autonomous Firewall with:
  ▸ Secure static-analysis sandbox (threat reverse engineering — no code execution)
  ▸ Self-extending SQLite threat database (auto-sharding at configurable limits)
  ▸ Autonomous behavioral anomaly detection
  ▸ Cross-platform: Android Userland, Termux, Linux, Ubuntu, Windows CMD
  ▸ Framework adapters: Flask, WSGI, standalone proxy, raw-socket mode

Architecture: Hybrid pipeline — hard-block gates + cumulative risk scoring
Zero stubs. Zero placeholders. Fully deterministic.
"""

import os
import sys
import re
import json
import math
import time
import hmac
import hashlib
import sqlite3
import logging
import platform
import threading
import subprocess
import multiprocessing
import ipaddress
import base64
import zlib
import struct
import random
import string
import socket
import urllib.parse
import traceback
from datetime import datetime, timedelta
from collections import defaultdict, deque
from typing import Dict, List, Optional, Tuple, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from contextlib import contextmanager

# ══════════════════════════════════════════════════════════════
# LOGGING
# ══════════════════════════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [ZEUS-FW] %(levelname)s — %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
log = logging.getLogger('zeus_firewall')


# ══════════════════════════════════════════════════════════════
# PLATFORM DETECTION
# ══════════════════════════════════════════════════════════════

class PlatformProfile:
    """Detect runtime environment and adapt capabilities accordingly."""

    def __init__(self):
        self.system   = platform.system().lower()       # linux | windows | darwin
        self.machine  = platform.machine().lower()      # armv7l | x86_64 | aarch64
        self.python   = sys.version_info
        self.is_android   = self._detect_android()
        self.is_termux    = self._detect_termux()
        self.is_userland  = self._detect_userland()
        self.is_windows   = self.system == 'windows'
        self.is_linux     = self.system == 'linux'
        self.is_macos     = self.system == 'darwin'
        self.is_arm       = any(x in self.machine for x in ('arm', 'aarch'))
        self.has_resource = self._probe_module('resource')
        self.has_seccomp  = self._probe_seccomp()
        self.has_proc     = os.path.isdir('/proc')
        self.max_workers  = 2 if self.is_arm else min(4, os.cpu_count() or 2)
        self.path_sep     = '\\' if self.is_windows else '/'
        log.info(f"Platform: {self.system}/{self.machine} | Android={self.is_android} "
                 f"Termux={self.is_termux} ARM={self.is_arm}")

    def _read_safe(self, path: str) -> str:
        try:
            with open(path, 'r', errors='ignore') as f:
                return f.read()
        except Exception:
            return ''

    def _detect_android(self) -> bool:
        return (os.path.exists('/system/build.prop') or
                'ANDROID_ROOT' in os.environ or
                'ANDROID_DATA' in os.environ)

    def _detect_termux(self) -> bool:
        prefix = os.environ.get('PREFIX', '')
        return 'com.termux' in prefix or os.path.exists('/data/data/com.termux')

    def _detect_userland(self) -> bool:
        ver = self._read_safe('/proc/version').lower()
        return 'userland' in ver

    def _probe_module(self, name: str) -> bool:
        try:
            __import__(name)
            return True
        except ImportError:
            return False

    def _probe_seccomp(self) -> bool:
        return (not self.is_arm and
                not self.is_windows and
                os.path.exists('/proc/sys/kernel/seccomp'))

    def summary(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if not k.startswith('_')}


PLATFORM = PlatformProfile()


# ══════════════════════════════════════════════════════════════
# CONSTANTS & CONFIG
# ══════════════════════════════════════════════════════════════

DB_PATH           = 'zeus_threats.db'
SHARD_LIMIT       = 100_000       # rows per shard before auto-extension
SANDBOX_TIMEOUT   = 8             # seconds (reduced for ARM)
MAX_PAYLOAD_BYTES = 1_048_576     # 1 MB hard ceiling
REPLAY_WINDOW     = 300           # 5 min replay-detection window
RATE_WINDOW       = 60            # sliding window seconds
RATE_MAX          = 120           # max requests/IP/window before block
ENTROPY_HIGH      = 5.2           # Shannon entropy — hard block threshold
ENTROPY_WARN      = 4.2           # Shannon entropy — flag + score threshold
BLOCK_SCORE       = 70            # cumulative risk score → BLOCK verdict
SANDBOX_SCORE     = 40            # cumulative risk score → SANDBOX verdict
SESSION_SECRET    = os.urandom(32)
KNOWN_GOOD_IPS    = {'127.0.0.1', '::1', 'localhost'}

ATTRIB = "The Zeus Project 2026 — Francois Nel"


# ══════════════════════════════════════════════════════════════
# ENUMS & DATA CLASSES
# ══════════════════════════════════════════════════════════════

class Verdict(Enum):
    ALLOW     = 'allow'
    BLOCK     = 'block'
    SANDBOX   = 'sandbox'      # allow but deep-inspect asynchronously
    CHALLENGE = 'challenge'    # CAPTCHA / proof-of-work
    LOG_ONLY  = 'log_only'


class ThreatCategory(Enum):
    SQLI         = 'sqli'
    XSS          = 'xss'
    SSTI         = 'ssti'
    PATH_TRAV    = 'path_traversal'
    CMD_INJ      = 'cmd_injection'
    REPLAY       = 'replay_attack'
    RATE_ABUSE   = 'rate_abuse'
    HIGH_ENTROPY = 'high_entropy'
    HEADER_ANOM  = 'header_anomaly'
    PRIV_ESC     = 'privilege_escalation'
    BEHAVIORAL   = 'behavioral_anomaly'
    PROTO_VIOL   = 'protocol_violation'
    ENCODING     = 'encoding_attack'
    TAINT        = 'taint_propagation'
    FINGERPRINT  = 'fingerprint_evasion'
    UNKNOWN      = 'unknown'
    VOIP_SPAM    = 'voip_spam'
    SPAM_CALLER  = 'spam_caller'
    TOLL_FRAUD   = 'toll_fraud'


@dataclass
class ThreatSignature:
    category:    ThreatCategory
    pattern:     str
    severity:    int            # 1–10
    description: str
    auto_learned: bool = False
    first_seen:   str  = field(default_factory=lambda: datetime.utcnow().isoformat())
    hit_count:    int  = 0

    def to_dict(self) -> dict:
        return {
            'category':     self.category.value,
            'pattern':      self.pattern,
            'severity':     self.severity,
            'description':  self.description,
            'auto_learned': self.auto_learned,
            'first_seen':   self.first_seen,
            'hit_count':    self.hit_count,
        }


@dataclass
class FirewallContext:
    ip:           str
    method:       str
    path:         str
    headers:      Dict[str, str]
    body:         bytes
    query_string: str
    framework:    str            = 'unknown'
    timestamp:    float          = field(default_factory=time.time)
    risk_score:   int            = 0
    step_log:     List[str]      = field(default_factory=list)
    verdict:      Verdict        = Verdict.ALLOW
    threat_tags:  List[str]      = field(default_factory=list)
    session_token: Optional[str] = None
    request_id:   str            = field(
        default_factory=lambda: ''.join(random.choices(string.hexdigits, k=16)).upper()
    )
    normalized_body: str = ''
    sandbox_report:  dict = field(default_factory=dict)

    def flag(self, score: int, tag: str, step: int = 0):
        self.risk_score += score
        self.threat_tags.append(tag)
        if score >= 20:
            log.warning(f"[{self.request_id}] Step {step:02d} | +{score} | {tag}")

    def step(self, n: int, name: str, result: str):
        entry = f"[{n:02d}] {name}: {result}"
        self.step_log.append(entry)

    def finalize(self):
        # Preserve hard-block set by individual pipeline steps
        if self.verdict == Verdict.BLOCK:
            return
        if self.risk_score >= BLOCK_SCORE:
            self.verdict = Verdict.BLOCK
        elif self.risk_score >= SANDBOX_SCORE:
            self.verdict = Verdict.SANDBOX

    def to_dict(self) -> dict:
        return {
            'request_id':   self.request_id,
            'ip':           self.ip,
            'method':       self.method,
            'path':         self.path,
            'framework':    self.framework,
            'timestamp':    self.timestamp,
            'risk_score':   self.risk_score,
            'verdict':      self.verdict.value,
            'threat_tags':  self.threat_tags,
            'step_log':     self.step_log,
            'sandbox':      self.sandbox_report,
        }


# ══════════════════════════════════════════════════════════════
# THREAT DATABASE — SELF-EXTENDING (AUTO-SHARDING)
# ══════════════════════════════════════════════════════════════

class ThreatDatabase:
    """
    SQLite-backed threat store with automatic shard extension.
    When active shard reaches SHARD_LIMIT rows a new shard table is created
    transparently. All shards are queryable via UNION views.
    """

    SCHEMA_MANIFEST = """
        CREATE TABLE IF NOT EXISTS shard_manifest (
            shard_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name TEXT    NOT NULL UNIQUE,
            created_at TEXT    NOT NULL,
            row_count  INTEGER NOT NULL DEFAULT 0,
            is_active  INTEGER NOT NULL DEFAULT 1
        )
    """

    SCHEMA_SHARD = """
        CREATE TABLE IF NOT EXISTS {table} (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            request_id  TEXT,
            ip          TEXT,
            method      TEXT,
            path        TEXT,
            framework   TEXT,
            timestamp   REAL,
            risk_score  INTEGER,
            verdict     TEXT,
            threat_tags TEXT,
            step_log    TEXT,
            sandbox_json TEXT,
            created_at  TEXT DEFAULT (datetime('now'))
        )
    """

    SCHEMA_SIGNATURES = """
        CREATE TABLE IF NOT EXISTS threat_signatures (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            category     TEXT NOT NULL,
            pattern      TEXT NOT NULL UNIQUE,
            severity     INTEGER NOT NULL,
            description  TEXT,
            auto_learned INTEGER DEFAULT 0,
            first_seen   TEXT,
            hit_count    INTEGER DEFAULT 0,
            attrib       TEXT DEFAULT '{attrib}'
        )
    """.format(attrib=ATTRIB)

    SCHEMA_IP_HISTORY = """
        CREATE TABLE IF NOT EXISTS ip_history (
            ip          TEXT PRIMARY KEY,
            total_reqs  INTEGER DEFAULT 0,
            blocked     INTEGER DEFAULT 0,
            last_seen   TEXT,
            risk_sum    INTEGER DEFAULT 0,
            tags        TEXT DEFAULT '[]'
        )
    """

    def __init__(self, db_path: str = DB_PATH, shard_limit: int = SHARD_LIMIT):
        self.db_path     = db_path
        self.shard_limit = shard_limit
        self._lock       = threading.Lock()
        self._init_db()
        self._active_shard = self._resolve_active_shard()
        log.info(f"ThreatDB ready | path={db_path} | active_shard={self._active_shard}")

    # Cached connection for :memory: databases (each new connection = empty DB)
    _mem_conn: Optional[sqlite3.Connection] = None

    @contextmanager
    def _conn(self):
        if self.db_path == ':memory:':
            # Reuse single connection so tables persist across calls
            if self._mem_conn is None:
                self._mem_conn = sqlite3.connect(':memory:', check_same_thread=False)
                self._mem_conn.execute('PRAGMA journal_mode=WAL')
                self._mem_conn.row_factory = sqlite3.Row
            yield self._mem_conn
            self._mem_conn.commit()
            return
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        with self._conn() as c:
            c.execute(self.SCHEMA_MANIFEST)
            c.execute(self.SCHEMA_SIGNATURES)
            c.execute(self.SCHEMA_IP_HISTORY)
            # Ensure at least one shard exists
            row = c.execute("SELECT table_name FROM shard_manifest WHERE is_active=1 ORDER BY shard_id DESC LIMIT 1").fetchone()
            if not row:
                first = 'threats_shard_001'
                c.execute(self.SCHEMA_SHARD.format(table=first))
                c.execute(
                    "INSERT INTO shard_manifest(table_name, created_at) VALUES(?,?)",
                    (first, datetime.utcnow().isoformat())
                )
        self._seed_builtin_signatures()

    def _resolve_active_shard(self) -> str:
        with self._conn() as c:
            row = c.execute(
                "SELECT table_name FROM shard_manifest WHERE is_active=1 ORDER BY shard_id DESC LIMIT 1"
            ).fetchone()
            return row['table_name'] if row else 'threats_shard_001'

    def _maybe_extend_shard(self, conn):
        """Create a new shard if active shard has reached SHARD_LIMIT."""
        count = conn.execute(
            f"SELECT COUNT(*) as n FROM {self._active_shard}"
        ).fetchone()['n']
        if count >= self.shard_limit:
            # Get next shard number
            max_id = conn.execute("SELECT MAX(shard_id) as m FROM shard_manifest").fetchone()['m'] or 0
            new_table = f"threats_shard_{(max_id + 1):03d}"
            conn.execute(self.SCHEMA_SHARD.format(table=new_table))
            conn.execute("UPDATE shard_manifest SET is_active=0 WHERE is_active=1")
            conn.execute(
                "INSERT INTO shard_manifest(table_name, created_at) VALUES(?,?)",
                (new_table, datetime.utcnow().isoformat())
            )
            self._active_shard = new_table
            log.info(f"ThreatDB: shard limit reached → new shard '{new_table}'")

    def store_threat(self, ctx: FirewallContext):
        with self._lock:
            with self._conn() as c:
                self._maybe_extend_shard(c)
                c.execute(
                    f"""INSERT INTO {self._active_shard}
                        (request_id, ip, method, path, framework, timestamp,
                         risk_score, verdict, threat_tags, step_log, sandbox_json)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    (ctx.request_id, ctx.ip, ctx.method, ctx.path,
                     ctx.framework, ctx.timestamp, ctx.risk_score,
                     ctx.verdict.value,
                     json.dumps(ctx.threat_tags),
                     json.dumps(ctx.step_log),
                     json.dumps(ctx.sandbox_report))
                )
                # Update IP history
                c.execute("""
                    INSERT INTO ip_history(ip, total_reqs, blocked, last_seen, risk_sum, tags)
                    VALUES(?,1,?,?,?,?)
                    ON CONFLICT(ip) DO UPDATE SET
                        total_reqs = total_reqs + 1,
                        blocked    = blocked + excluded.blocked,
                        last_seen  = excluded.last_seen,
                        risk_sum   = risk_sum + excluded.risk_sum
                """, (
                    ctx.ip,
                    1 if ctx.verdict == Verdict.BLOCK else 0,
                    datetime.utcnow().isoformat(),
                    ctx.risk_score,
                    json.dumps(ctx.threat_tags[:5])
                ))

    def store_signature(self, sig: ThreatSignature):
        with self._lock:
            with self._conn() as c:
                try:
                    c.execute("""
                        INSERT INTO threat_signatures
                            (category, pattern, severity, description, auto_learned, first_seen)
                        VALUES(?,?,?,?,?,?)
                    """, (sig.category.value, sig.pattern, sig.severity,
                          sig.description, int(sig.auto_learned), sig.first_seen))
                    log.info(f"New signature stored: [{sig.category.value}] {sig.description}")
                except sqlite3.IntegrityError:
                    c.execute(
                        "UPDATE threat_signatures SET hit_count=hit_count+1 WHERE pattern=?",
                        (sig.pattern,)
                    )

    def get_signatures(self, category: Optional[str] = None) -> List[dict]:
        with self._conn() as c:
            if category:
                rows = c.execute(
                    "SELECT * FROM threat_signatures WHERE category=? ORDER BY severity DESC",
                    (category,)
                ).fetchall()
            else:
                rows = c.execute(
                    "SELECT * FROM threat_signatures ORDER BY severity DESC"
                ).fetchall()
            return [dict(r) for r in rows]

    def get_ip_profile(self, ip: str) -> dict:
        with self._conn() as c:
            row = c.execute("SELECT * FROM ip_history WHERE ip=?", (ip,)).fetchone()
            return dict(row) if row else {}

    def get_stats(self) -> dict:
        with self._conn() as c:
            shards  = c.execute("SELECT COUNT(*) as n FROM shard_manifest").fetchone()['n']
            sigs    = c.execute("SELECT COUNT(*) as n FROM threat_signatures").fetchone()['n']
            ips     = c.execute("SELECT COUNT(*) as n FROM ip_history").fetchone()['n']
            blocked = c.execute("SELECT SUM(blocked) as n FROM ip_history").fetchone()['n'] or 0
            # Count rows across all shards
            manifest = c.execute("SELECT table_name FROM shard_manifest").fetchall()
            total_threats = 0
            for m in manifest:
                try:
                    n = c.execute(f"SELECT COUNT(*) as n FROM {m['table_name']}").fetchone()['n']
                    total_threats += n
                except Exception:
                    pass
            return {
                'shards':        shards,
                'total_threats': total_threats,
                'signatures':    sigs,
                'tracked_ips':   ips,
                'total_blocked': blocked,
                'active_shard':  self._active_shard,
                'shard_limit':   self.shard_limit,
            }

    def _seed_builtin_signatures(self):
        """Pre-load known threat patterns into DB if not already present."""
        builtins = [
            ThreatSignature(ThreatCategory.SQLI,      r"(?i)(union\s+select|drop\s+table|insert\s+into|delete\s+from|1=1|or\s+1=1|--|;--)",  9, "Classic SQLi patterns"),
            ThreatSignature(ThreatCategory.XSS,       r"(?i)(<script[\s>]|javascript:|onerror\s*=|onload\s*=|eval\s*\(|alert\s*\()",         8, "Reflected/Stored XSS"),
            ThreatSignature(ThreatCategory.SSTI,       r"(\{\{.*\}\}|\{%.*%\}|\$\{.*\}|#\{.*\})",                                             8, "Template injection"),
            ThreatSignature(ThreatCategory.PATH_TRAV,  r"(\.\./|\.\.\\|%2e%2e%2f|%252e%252e|/etc/passwd|/etc/shadow|/proc/self)",             9, "Path traversal"),
            ThreatSignature(ThreatCategory.CMD_INJ,    r"(?i)(;\s*(ls|cat|id|whoami|wget|curl|nc|bash|sh|cmd|powershell)|&&|\|\||`[^`]+`)",    9, "Command injection"),
            ThreatSignature(ThreatCategory.PRIV_ESC,   r"(?i)(sudo|su\s+-|chmod\s+[0-7]{3,4}|/etc/sudoers|setuid|setgid)",                   7, "Privilege escalation"),
            ThreatSignature(ThreatCategory.ENCODING,   r"(%00|%0d%0a|\\x[0-9a-f]{2}|\\u[0-9a-f]{4}|&#x?[0-9a-f]+;)",                        6, "Encoding evasion"),
            ThreatSignature(ThreatCategory.PROTO_VIOL, r"(?i)(http/0\.9|connect\s+\S+\s+http)",                                               5, "Protocol violation"),
            # ── Telephony / VoIP / Spam-Caller signatures ──
            ThreatSignature(ThreatCategory.VOIP_SPAM,  r"(?i)(sip\s+invite|sip/2\.0\s+100|via:\s*sip|contact:\s*sip:|from:\s*sip:|to:\s*sip:)",  8, "SIP invite flood / VoIP spam"),
            ThreatSignature(ThreatCategory.VOIP_SPAM,  r"(?i)(register\s+sip:|options\s+sip:|sip:\d+@|sip:anonymous@)",                           7, "SIP REGISTER/OPTIONS probe"),
            ThreatSignature(ThreatCategory.SPAM_CALLER,r"(?i)(x-dialed-party|x-original-called|p-asserted-identity|p-preferred-identity)",         6, "Caller-ID spoofing headers"),
            ThreatSignature(ThreatCategory.SPAM_CALLER,r"(?i)(robocall|autodial|ivr\s+blast|dialer.*script|predictive.*dial)",                     8, "Robocall/auto-dialer signature"),
            ThreatSignature(ThreatCategory.TOLL_FRAUD, r"(?i)(premium.*rate|sip.*900|spit|vishing|wangiri|one.*ring.*scam)",                        9, "Toll fraud / vishing / wangiri"),
            ThreatSignature(ThreatCategory.TOLL_FRAUD, r"(?i)(pabx.*hack|pbx.*bruteforce|voip.*scan|sip.*enum|friendly.*scanner)",                 9, "PBX/PABX hack / SIP enumeration"),
        ]
        for sig in builtins:
            self.store_signature(sig)


# ══════════════════════════════════════════════════════════════
# SECURE SANDBOX — STATIC THREAT ANALYSIS (NO CODE EXECUTION)
# ══════════════════════════════════════════════════════════════

class SecureSandbox:
    """
    Isolated static analysis sandbox.
    Analyzes threat payloads via entropy, string extraction, byte-pattern
    matching, and known shellcode signature matching — ZERO code execution.
    Runs in a subprocess with a hard timeout so it cannot block the pipeline.
    """

    SHELLCODE_MARKERS = [
        b'\x90\x90\x90\x90',           # NOP sled
        b'\xcc\xcc\xcc\xcc',           # INT3 sled (debugger trap)
        b'\x6a\x02\x58\xcd\x80',       # Linux x86 syscall stub
        b'\x31\xc0\x50\x68',           # common x86 shellcode prefix
        b'MZ',                          # PE executable header
        b'\x7fELF',                     # ELF header
        b'#!/',                         # Shebang
        b'powershell',
        b'cmd.exe',
        b'/bin/sh',
        b'/bin/bash',
        b'base64 -d',
        b'eval(',
    ]

    SUSPICIOUS_STRINGS = re.compile(
        rb'(?i)(wget|curl|nc\s+-|netcat|python\s+-c|perl\s+-e|ruby\s+-e'
        rb'|exec\(|system\(|passthru|shell_exec'
        rb'|/etc/passwd|/etc/shadow|/proc/self'
        rb'|SELECT\s+\*|UNION\s+SELECT'
        rb'|<script|javascript:|onerror=)',
        re.DOTALL
    )

    def __init__(self, timeout: int = SANDBOX_TIMEOUT):
        self.timeout = timeout if not PLATFORM.is_arm else min(timeout, 6)

    def analyze(self, payload: bytes, meta: dict) -> dict:
        """
        Launch static analysis in a subprocess. Returns analysis dict.
        Falls back to in-process analysis if subprocess unavailable.
        """
        try:
            ctx_b64 = base64.b64encode(json.dumps(meta).encode()).decode()
            pay_b64 = base64.b64encode(payload).decode()

            proc = multiprocessing.Process(
                target=self._sandbox_entry,
                args=(pay_b64, ctx_b64),
                daemon=True
            )
            # Use a manager queue for result passing
            manager = multiprocessing.Manager()
            result_q = manager.Queue()

            # Re-run with result queue
            proc2 = multiprocessing.Process(
                target=self._sandbox_entry_q,
                args=(pay_b64, ctx_b64, result_q),
                daemon=True
            )
            proc2.start()
            proc2.join(timeout=self.timeout)
            if proc2.is_alive():
                proc2.terminate()
                proc2.join(1)
                return self._static_analysis(payload)

            if not result_q.empty():
                return result_q.get_nowait()
            return self._static_analysis(payload)

        except Exception:
            # If subprocess fails (e.g. Android restrictions), run inline
            return self._static_analysis(payload)

    def _sandbox_entry_q(self, pay_b64: str, ctx_b64: str, q):
        try:
            payload = base64.b64decode(pay_b64)
            result  = self._static_analysis(payload)
            q.put(result)
        except Exception as e:
            q.put({'error': str(e)})

    def _sandbox_entry(self, pay_b64: str, ctx_b64: str):
        """
        Subprocess entry point for ARM-compatible sandbox analysis.
        Decodes the base64 payload, runs static analysis, and writes
        the result to a temp file keyed by process PID so the parent
        can optionally retrieve it.  Falls back gracefully on any error.
        """
        import os, json, tempfile, base64 as _b64
        try:
            payload = _b64.b64decode(pay_b64)
            result  = self._static_analysis(payload)
            # Write result to a temp file so parent can read if needed
            tmp_path = os.path.join(
                tempfile.gettempdir(),
                "zeus_sandbox_{pid}.json".format(pid=os.getpid())
            )
            with open(tmp_path, "w") as fh:
                json.dump(result, fh)
        except Exception:
            pass  # subprocess failure is non-fatal; parent falls back to inline analysis

    def _static_analysis(self, payload: bytes) -> dict:
        """Full static analysis — entropy, strings, signatures, byte histogram."""
        analysis = {
            'size_bytes':      len(payload),
            'entropy':         self._shannon_entropy(payload),
            'byte_histogram':  self._byte_histogram(payload),
            'suspicious_strings': self._extract_suspicious_strings(payload),
            'shellcode_markers':  self._check_shellcode_markers(payload),
            'printable_ratio': self._printable_ratio(payload),
            'null_byte_count': payload.count(b'\x00'),
            'longest_token':   self._longest_token(payload),
            'derived_signature': None,
            'risk_indicators': [],
            'attrib':          ATTRIB,
        }

        # Derive risk indicators from analysis
        if analysis['entropy'] > ENTROPY_HIGH:
            analysis['risk_indicators'].append('very_high_entropy')
        if analysis['shellcode_markers']:
            analysis['risk_indicators'].append('shellcode_pattern')
        if analysis['suspicious_strings']:
            analysis['risk_indicators'].append('suspicious_strings')
        if analysis['printable_ratio'] < 0.3 and len(payload) > 64:
            analysis['risk_indicators'].append('mostly_binary')
        if analysis['null_byte_count'] > 10:
            analysis['risk_indicators'].append('null_byte_injection')

        # Attempt to derive a learnable signature
        analysis['derived_signature'] = self._derive_signature(payload, analysis)
        return analysis

    def _shannon_entropy(self, data: bytes) -> float:
        if not data:
            return 0.0
        freq = defaultdict(int)
        for b in data:
            freq[b] += 1
        total = len(data)
        return -sum((c / total) * math.log2(c / total) for c in freq.values())

    def _byte_histogram(self, data: bytes) -> dict:
        hist = defaultdict(int)
        for b in data:
            hist[b] += 1
        # Return top-10 most frequent
        top = sorted(hist.items(), key=lambda x: x[1], reverse=True)[:10]
        return {hex(k): v for k, v in top}

    def _check_shellcode_markers(self, data: bytes) -> List[str]:
        found = []
        for marker in self.SHELLCODE_MARKERS:
            if marker.lower() in data.lower():
                found.append(marker.decode('latin-1', errors='replace').strip())
        return found

    def _extract_suspicious_strings(self, data: bytes) -> List[str]:
        matches = self.SUSPICIOUS_STRINGS.findall(data)
        return list({m.decode('utf-8', errors='ignore') for m in matches})

    def _printable_ratio(self, data: bytes) -> float:
        if not data:
            return 1.0
        printable = sum(32 <= b < 127 for b in data)
        return printable / len(data)

    def _longest_token(self, data: bytes) -> int:
        try:
            text = data.decode('utf-8', errors='ignore')
            tokens = re.split(r'\s+', text)
            return max((len(t) for t in tokens), default=0)
        except Exception:
            return 0

    def _derive_signature(self, payload: bytes, analysis: dict) -> Optional[dict]:
        """
        Attempt to derive a learnable regex signature from the payload.
        Returns a dict that ThreatDatabase.store_signature() can consume.
        """
        try:
            text = payload.decode('utf-8', errors='ignore')

            # Try to extract the most suspicious N-gram as a pattern seed
            # Extract all runs of non-whitespace printable chars > 8 chars
            tokens = [t for t in re.findall(r'[^\s]{8,}', text) if t]
            if not tokens:
                return None

            # Pick the token with highest entropy
            best = max(tokens, key=lambda t: self._shannon_entropy(t.encode()))

            # Escape and form a pattern
            pattern = re.escape(best[:40])
            category = ThreatCategory.UNKNOWN.value

            # Classify by indicators
            indicators = analysis.get('risk_indicators', [])
            strings    = analysis.get('suspicious_strings', [])
            if 'shellcode_pattern' in indicators:
                category = ThreatCategory.CMD_INJ.value
            elif any(s in text.lower() for s in ('select', 'union', 'insert', 'drop')):
                category = ThreatCategory.SQLI.value
            elif any(s in text.lower() for s in ('<script', 'onerror', 'javascript:')):
                category = ThreatCategory.XSS.value
            elif any(s in text for s in ('{{', '}}', '{%', '%}')):
                category = ThreatCategory.SSTI.value
            elif '../' in text or '..\\' in text:
                category = ThreatCategory.PATH_TRAV.value

            severity = min(10, 3 + len(indicators) * 2)
            return {
                'category':    category,
                'pattern':     pattern,
                'severity':    severity,
                'description': f"Auto-learned from sandbox analysis | entropy={analysis['entropy']:.2f}",
                'auto_learned': True,
            }
        except Exception:
            return None


# ══════════════════════════════════════════════════════════════
# BEHAVIORAL BASELINE & AUTONOMOUS DETECTOR
# ══════════════════════════════════════════════════════════════

class AutonomousDetector:
    """
    Tracks per-IP behavioral baselines and detects statistical deviations.
    No ML model — uses rolling window statistics deterministically.
    """

    def __init__(self, window: int = 200):
        self.window     = window
        self._lock      = threading.Lock()
        # ip → deque of (timestamp, risk_score, path_hash)
        self._history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=window))
        # ip → set of seen paths
        self._paths:   Dict[str, set]   = defaultdict(set)
        # ip → method frequency
        self._methods: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))

    def record(self, ctx: FirewallContext):
        with self._lock:
            ip = ctx.ip
            self._history[ip].append((ctx.timestamp, ctx.risk_score, hash(ctx.path)))
            self._paths[ip].add(ctx.path)
            self._methods[ip][ctx.method] += 1

    def score(self, ctx: FirewallContext) -> Tuple[int, List[str]]:
        """Return (risk_delta, reason_list) based on behavioral profile."""
        with self._lock:
            ip      = ctx.ip
            hist    = list(self._history[ip])
            tags    = []
            delta   = 0

            if len(hist) < 5:
                return 0, []

            recent_scores = [h[1] for h in hist[-20:]]
            avg_score     = sum(recent_scores) / len(recent_scores)

            # Rapid escalation in risk score
            if avg_score > 30:
                delta += 15
                tags.append('behavioral:high_avg_risk')

            # Path scanning (many unique paths from same IP)
            unique_paths = len(self._paths[ip])
            if unique_paths > 50:
                delta += 10
                tags.append(f'behavioral:path_scanning({unique_paths})')

            # High request velocity
            now      = ctx.timestamp
            recent   = [h for h in hist if now - h[0] < 30]  # last 30 seconds
            if len(recent) > 40:
                delta += 20
                tags.append(f'behavioral:high_velocity({len(recent)}/30s)')

            # Method anomaly: mostly non-GET with high risk
            methods = self._methods[ip]
            total_m = sum(methods.values()) or 1
            if methods.get('POST', 0) / total_m > 0.8 and avg_score > 15:
                delta += 10
                tags.append('behavioral:post_flood')

            return delta, tags


# ══════════════════════════════════════════════════════════════
# RATE LIMITER (thread-safe sliding window)
# ══════════════════════════════════════════════════════════════

class RateLimiter:
    def __init__(self, window: int = RATE_WINDOW, max_req: int = RATE_MAX):
        self.window  = window
        self.max_req = max_req
        self._lock   = threading.Lock()
        self._hits:  Dict[str, deque] = defaultdict(deque)

    def check(self, ip: str) -> Tuple[bool, int]:
        """Returns (is_limited, current_count)."""
        now = time.time()
        with self._lock:
            dq = self._hits[ip]
            while dq and now - dq[0] > self.window:
                dq.popleft()
            dq.append(now)
            count = len(dq)
        return count > self.max_req, count


# ══════════════════════════════════════════════════════════════
# REPLAY DETECTOR (nonce / request-hash store)
# ══════════════════════════════════════════════════════════════

class ReplayDetector:
    def __init__(self, window: int = REPLAY_WINDOW):
        self.window = window
        self._lock  = threading.Lock()
        self._seen: Dict[str, float] = {}
        self._clean_every = 1000
        self._counter     = 0

    def check(self, ctx: FirewallContext) -> bool:
        """Returns True if this request looks like a replay."""
        key = self._fingerprint(ctx)
        now = time.time()
        with self._lock:
            self._counter += 1
            if self._counter % self._clean_every == 0:
                cutoff = now - self.window
                self._seen = {k: v for k, v in self._seen.items() if v > cutoff}
            if key in self._seen:
                age = now - self._seen[key]
                if age < self.window:
                    return True
            self._seen[key] = now
            return False

    def _fingerprint(self, ctx: FirewallContext) -> str:
        raw = f"{ctx.ip}|{ctx.method}|{ctx.path}|{ctx.query_string}|{ctx.body[:256]!r}"
        return hashlib.sha256(raw.encode()).hexdigest()


# ══════════════════════════════════════════════════════════════
# SESSION VALIDATOR
# ══════════════════════════════════════════════════════════════

class SessionValidator:
    def __init__(self, secret: bytes = SESSION_SECRET):
        self.secret = secret

    def create_token(self, ip: str) -> str:
        ts      = str(int(time.time()))
        payload = f"{ip}:{ts}"
        sig     = hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()[:16]
        return base64.urlsafe_b64encode(f"{payload}:{sig}".encode()).decode()

    def validate_token(self, token: str, ip: str) -> Tuple[bool, str]:
        try:
            decoded = base64.urlsafe_b64decode(token.encode()).decode()
            parts   = decoded.split(':')
            if len(parts) != 3:
                return False, 'malformed'
            tok_ip, ts, sig = parts
            if tok_ip != ip:
                return False, 'ip_mismatch'
            age = time.time() - int(ts)
            if age > 3600:
                return False, 'expired'
            expected = hmac.new(self.secret, f"{tok_ip}:{ts}".encode(), hashlib.sha256).hexdigest()[:16]
            if not hmac.compare_digest(sig, expected):
                return False, 'invalid_sig'
            return True, 'ok'
        except Exception as e:
            return False, f'error:{e}'


# ══════════════════════════════════════════════════════════════
# IP REPUTATION
# ══════════════════════════════════════════════════════════════

class IPReputation:
    def __init__(self, db: 'ThreatDatabase'):
        self.db          = db
        self._cache:     Dict[str, Tuple[int, float]] = {}  # ip → (score, ts)
        self._cache_ttl  = 300  # seconds
        self._lock       = threading.Lock()

    def score(self, ip: str) -> int:
        """Returns 0–100 reputation score (higher = more suspicious)."""
        now = time.time()
        with self._lock:
            if ip in self._cache:
                score, ts = self._cache[ip]
                if now - ts < self._cache_ttl:
                    return score

        if ip in KNOWN_GOOD_IPS:
            return 0

        profile = self.db.get_ip_profile(ip)
        if not profile:
            return 0

        blocked   = profile.get('blocked', 0)
        total     = profile.get('total_reqs', 1)
        risk_sum  = profile.get('risk_sum', 0)
        block_rate = blocked / max(total, 1)
        avg_risk   = risk_sum / max(total, 1)
        score      = min(100, int(block_rate * 60 + avg_risk * 0.5))

        with self._lock:
            self._cache[ip] = (score, now)
        return score


# ══════════════════════════════════════════════════════════════
# ENCODING NORMALIZER
# ══════════════════════════════════════════════════════════════

class EncodingNormalizer:
    """Decode multiple layers of URL / HTML / Base64 encoding to reveal true payload."""

    _HTML_ENTITIES = re.compile(r'&#x?([0-9a-fA-F]+);?')
    _UNICODE_ESC   = re.compile(r'\\u([0-9a-fA-F]{4})')
    _HEX_ESC       = re.compile(r'\\x([0-9a-fA-F]{2})')

    def normalize(self, text: str, max_depth: int = 5) -> str:
        prev = None
        for _ in range(max_depth):
            text = self._decode_url(text)
            text = self._decode_html(text)
            text = self._decode_unicode(text)
            text = self._decode_hex(text)
            text = self._try_base64(text)
            if text == prev:
                break
            prev = text
        return text

    def _decode_url(self, s: str) -> str:
        try:
            return urllib.parse.unquote(urllib.parse.unquote(s))
        except Exception:
            return s

    def _decode_html(self, s: str) -> str:
        def repl(m):
            try:
                code = int(m.group(1), 16 if 'x' in m.group(0) else 10)
                return chr(code)
            except Exception:
                return m.group(0)
        return self._HTML_ENTITIES.sub(repl, s)

    def _decode_unicode(self, s: str) -> str:
        def repl(m):
            try:
                return chr(int(m.group(1), 16))
            except Exception:
                return m.group(0)
        return self._UNICODE_ESC.sub(repl, s)

    def _decode_hex(self, s: str) -> str:
        def repl(m):
            try:
                return chr(int(m.group(1), 16))
            except Exception:
                return m.group(0)
        return self._HEX_ESC.sub(repl, s)

    def _try_base64(self, s: str) -> str:
        # Only try if looks like b64 and is long enough
        stripped = s.strip()
        if len(stripped) < 16 or not re.match(r'^[A-Za-z0-9+/=]+$', stripped):
            return s
        try:
            dec = base64.b64decode(stripped + '==').decode('utf-8', errors='ignore')
            if len(dec) > 4 and dec.isprintable():
                return dec
        except Exception:
            pass
        return s


# ══════════════════════════════════════════════════════════════
# 21-STEP FIREWALL PIPELINE
# ══════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════
# TELEPHONY GUARD — VoIP / SIP / Spam-Caller / Toll-Fraud
# ══════════════════════════════════════════════════════════════

class TelephonyGuard:
    """
    Detects and blocks VoIP abuse, SIP-based attacks, spam callers,
    toll fraud, and PSTN/IP telephony exploitation patterns.

    Operates on HTTP headers and body payloads — works inline with the
    firewall pipeline even when SIP is tunnelled over HTTP/WebSocket.

    Threat model coverage:
      ▸ SIP INVITE floods (VoIP DDoS)
      ▸ SIP REGISTER bombs (credential stuffing on PBX)
      ▸ Caller-ID / ANI spoofing (P-Asserted-Identity abuse)
      ▸ Wangiri / one-ring scam patterns
      ▸ Toll fraud (premium-rate SPIT / PABX hack)
      ▸ SIP enumeration (friendly-scanner, sipvicious)
      ▸ Robocall / auto-dialer fingerprints
      ▸ Vishing social-engineering payload patterns
    """

    # Known VoIP attack tool User-Agents
    _BAD_UA = re.compile(
        r'(?i)(sipvicious|friendly.scanner|sip-scan|voiphopper|'
        r'asterisk|viproy|sipcli|sipp|pjsip.stress|sipsak|'
        r'iwar|enumiax|svmap|svwar|svcrack)',
        re.IGNORECASE
    )

    # SIP method tokens in HTTP body / headers
    _SIP_METHODS = re.compile(
        r'(?i)\b(INVITE|REGISTER|OPTIONS|BYE|CANCEL|ACK|PRACK|'
        r'SUBSCRIBE|NOTIFY|REFER|INFO|UPDATE|MESSAGE|PUBLISH)\s+sip:',
        re.IGNORECASE
    )

    # Caller-ID spoofing indicators
    _CALLERID_SPOOF = re.compile(
        r'(?i)(P-Asserted-Identity|P-Preferred-Identity|'
        r'X-Original-Called|X-Dialed-Party|Remote-Party-ID|'
        r'Privacy:\s*id|Privacy:\s*full)',
        re.IGNORECASE
    )

    # Toll-fraud / premium-rate patterns
    _TOLL_FRAUD = re.compile(
        r'(?i)(\+?1?900|premium.rate|sip.900|wangiri|one.ring|'
        r'\+?(?:882|883|881)\d{6,}|'       # international premium codes
        r'pabx.hack|pbx.brute|voip.crack|'
        r'spit\b|vishing)',
        re.IGNORECASE
    )

    # Robocall / autodial patterns in HTTP payloads (REST telephony APIs)
    _ROBOCALL = re.compile(
        r'(?i)(autodial|robocall|predictive.dial|'
        r'ivr.blast|mass.call|bulk.sms|'
        r'twilio.*(?:calls|messages).*bulk|'
        r'dialer.script|outbound.campaign)',
        re.IGNORECASE
    )

    # SIP enumeration / reconnaissance
    _SIP_ENUM = re.compile(
        r'(?i)(sip.enum|sipvicious|svmap|svwar|svcrack|'
        r'friendly.scanner|sip.scan|OPTIONS.flood|'
        r'sip:\*@|sip:100@|sip:1000@|sip:admin@)',
        re.IGNORECASE
    )

    # Rate tracking per IP for SIP-specific flood detection
    def __init__(self):
        self._sip_counts: dict = {}   # ip → (count, window_start)
        self._lock = threading.Lock()
        self._SIP_RATE_WINDOW  = 30    # seconds
        self._SIP_RATE_MAX     = 15    # SIP-bearing requests per window

    def _check_sip_rate(self, ip: str) -> bool:
        """Returns True if IP exceeds SIP request rate threshold."""
        now = time.time()
        with self._lock:
            entry = self._sip_counts.get(ip)
            if entry is None or (now - entry[1]) > self._SIP_RATE_WINDOW:
                self._sip_counts[ip] = (1, now)
                return False
            count, start = entry
            count += 1
            self._sip_counts[ip] = (count, start)
            return count > self._SIP_RATE_MAX

    def inspect(self, ctx: 'FirewallContext') -> Tuple[int, List[str]]:
        """
        Scan request for telephony threats.
        Returns (risk_delta, list_of_tags).
        """
        score = 0
        tags: List[str] = []

        # Collect inspection surface: path + query + body + headers + UA
        ua      = ctx.headers.get('user-agent', '')
        body_s  = ctx.body.decode('utf-8', errors='ignore')[:4096]
        full    = (ctx.path + ' ' + ctx.query_string + ' ' + body_s + ' '
                   + ' '.join(f'{k}: {v}' for k, v in ctx.headers.items()))

        # 1 — Malicious VoIP tool User-Agent
        if self._BAD_UA.search(ua):
            score += 45
            tags.append('telephony:bad_ua')

        # 2 — SIP method in payload
        if self._SIP_METHODS.search(full):
            score += 20
            tags.append('telephony:sip_method')
            # Apply SIP-specific rate limit on top
            if self._check_sip_rate(ctx.ip):
                score += 30
                tags.append('telephony:sip_flood')

        # 3 — Caller-ID spoofing headers
        if self._CALLERID_SPOOF.search(full):
            score += 25
            tags.append('telephony:callerid_spoof')

        # 4 — Toll fraud patterns
        if self._TOLL_FRAUD.search(full):
            score += 40
            tags.append('telephony:toll_fraud')

        # 5 — Robocall / autodial patterns
        if self._ROBOCALL.search(full):
            score += 35
            tags.append('telephony:robocall')

        # 6 — SIP enumeration / recon
        if self._SIP_ENUM.search(full):
            score += 40
            tags.append('telephony:sip_enum')

        # 7 — Wangiri: suspiciously short body + SIP context + non-standard path
        if ('sip' in full.lower() and len(ctx.body) < 50
                and ctx.method == 'POST' and 'wangiri' not in ''.join(tags)):
            # Low-confidence indicator — add small score only
            score += 10
            tags.append('telephony:short_sip_post')

        return score, tags

class FirewallPipeline:
    """
    Executes 21 inspection steps in sequence.
    Hard-block steps terminate the chain immediately.
    Soft-score steps accumulate risk without early exit.
    After all steps, finalize() applies threshold verdicts.
    """

    def __init__(
        self,
        db:         ThreatDatabase,
        sandbox:    SecureSandbox,
        detector:   AutonomousDetector,
        rate:       RateLimiter,
        replay:     ReplayDetector,
        session:    SessionValidator,
        reputation: IPReputation,
        normalizer: EncodingNormalizer,
        telephony:  'TelephonyGuard' = None,
    ):
        self.db         = db
        self.sandbox    = sandbox
        self.detector   = detector
        self.rate       = rate
        self.replay     = replay
        self.session    = session
        self.reputation = reputation
        self.normalizer = normalizer
        self.telephony  = telephony or TelephonyGuard()
        self._sigs      = self._load_sigs()
        self._sig_lock  = threading.Lock()

        # Reload signatures every 5 minutes in background
        self._start_sig_refresh()

    def _load_sigs(self) -> List[dict]:
        return self.db.get_signatures()

    def _start_sig_refresh(self):
        def _refresh():
            while True:
                time.sleep(300)
                with self._sig_lock:
                    self._sigs = self._load_sigs()
        t = threading.Thread(target=_refresh, daemon=True)
        t.start()

    def _compiled_patterns(self) -> List[Tuple[re.Pattern, ThreatCategory, int]]:
        result = []
        with self._sig_lock:
            for sig in self._sigs:
                try:
                    result.append((
                        re.compile(sig['pattern'], re.IGNORECASE | re.DOTALL),
                        ThreatCategory(sig['category']),
                        sig['severity']
                    ))
                except re.error:
                    pass
        return result

    def run(self, ctx: FirewallContext) -> FirewallContext:
        steps = [
            self._s01_connection_fingerprint,
            self._s02_protocol_validation,
            self._s03_rate_limiting,
            self._s04_ip_reputation,
            self._s05_header_anomaly,
            self._s06_payload_size,
            self._s07_encoding_normalization,
            self._s08_sqli_detection,
            self._s09_xss_detection,
            self._s10_ssti_detection,
            self._s11_path_traversal,
            self._s12_command_injection,
            self._s13_taint_propagation,
            self._s14_behavioral_baseline,
            self._s15_entropy_scoring,
            self._s16_session_integrity,
            self._s17_replay_detection,
            self._s18_privilege_escalation,
            self._s19_output_sanitization,
            self._s20_audit_log,
            self._s21_adaptive_mutation,
            self._s22_telephony_guard,
        ]
        for fn in steps:
            fn(ctx)
            if ctx.verdict == Verdict.BLOCK:
                # Hard block — skip remaining steps
                ctx.step_log.append(f"[--] Pipeline short-circuited at {fn.__name__}")
                break
        ctx.finalize()
        return ctx

    # ── STEP 01 ──────────────────────────────────────────────
    def _s01_connection_fingerprint(self, ctx: FirewallContext):
        n = 1
        issues = []

        # Detect scanner user-agent — checked FIRST, regardless of IP origin
        ua = ctx.headers.get('user-agent', '').lower()
        scanner_patterns = ['nmap', 'nikto', 'sqlmap', 'masscan', 'dirbuster',
                            'gobuster', 'wfuzz', 'hydra', 'metasploit', 'acunetix',
                            'w3af', 'burpsuite', 'zaproxy', 'nuclei']
        for pat in scanner_patterns:
            if pat in ua:
                ctx.flag(40, f'conn:scanner_ua({pat})', n)
                issues.append(f'scanner:{pat}')
                ctx.verdict = Verdict.BLOCK
                break

        if ctx.verdict == Verdict.BLOCK:
            ctx.step(n, 'conn_fingerprint', f"BLOCKED scanner UA detected")
            return

        # IP format / origin checks
        try:
            addr = ipaddress.ip_address(ctx.ip)
            if addr.is_loopback:
                ctx.step(n, 'conn_fingerprint', 'loopback — trusted')
                return
            if addr.is_private:
                ctx.step(n, 'conn_fingerprint', 'private network — UA clean')
                return
            if addr.is_multicast:
                issues.append('multicast_source')
                ctx.flag(25, 'conn:multicast_source', n)
        except ValueError:
            if len(ctx.ip) > 64 or re.search(r'[<>;()\'"]', ctx.ip):
                ctx.flag(30, 'conn:malformed_ip', n)
                issues.append('malformed_ip')

        ctx.step(n, 'conn_fingerprint', f"issues={issues or 'none'}")

    # ── STEP 02 ──────────────────────────────────────────────
    def _s02_protocol_validation(self, ctx: FirewallContext):
        n = 2
        issues = []
        valid_methods = {'GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS','TRACE'}
        if ctx.method.upper() not in valid_methods:
            ctx.flag(35, f'proto:invalid_method({ctx.method})', n)
            issues.append('invalid_method')

        # Path must not be empty
        if not ctx.path or ctx.path[0] != '/':
            ctx.flag(20, 'proto:invalid_path', n)
            issues.append('invalid_path')

        # Null bytes in path
        if '\x00' in ctx.path:
            ctx.flag(50, 'proto:null_byte_in_path', n)
            ctx.verdict = Verdict.BLOCK
            issues.append('null_byte_path')

        # HTTP version (inferred from header presence)
        # Overly long path
        if len(ctx.path) > 2048:
            ctx.flag(15, 'proto:path_too_long', n)
            issues.append('path_too_long')

        ctx.step(n, 'proto_validation', f"method={ctx.method} issues={issues or 'none'}")

    # ── STEP 03 ──────────────────────────────────────────────
    def _s03_rate_limiting(self, ctx: FirewallContext):
        n = 3
        limited, count = self.rate.check(ctx.ip)
        if limited:
            ctx.flag(50, f'rate:exceeded({count}/{RATE_MAX})', n)
            ctx.verdict = Verdict.BLOCK
            ctx.step(n, 'rate_limiting', f"BLOCKED count={count}")
        else:
            ctx.step(n, 'rate_limiting', f"ok count={count}/{RATE_MAX}")

    # ── STEP 04 ──────────────────────────────────────────────
    def _s04_ip_reputation(self, ctx: FirewallContext):
        n = 4
        score = self.reputation.score(ctx.ip)
        if score >= 80:
            ctx.flag(40, f'rep:very_high({score})', n)
            ctx.verdict = Verdict.BLOCK
        elif score >= 50:
            ctx.flag(20, f'rep:elevated({score})', n)
        elif score >= 25:
            ctx.flag(10, f'rep:moderate({score})', n)
        ctx.step(n, 'ip_reputation', f"score={score}/100")

    # ── STEP 05 ──────────────────────────────────────────────
    def _s05_header_anomaly(self, ctx: FirewallContext):
        n = 5
        issues = []
        h = ctx.headers

        # Missing Host header (required in HTTP/1.1)
        if 'host' not in {k.lower() for k in h}:
            ctx.flag(15, 'hdr:missing_host', n)
            issues.append('missing_host')

        # Oversized individual headers
        for k, v in h.items():
            if len(v) > 8192:
                ctx.flag(20, f'hdr:oversized({k})', n)
                issues.append(f'oversized:{k}')

        # Header injection (CRLF)
        for k, v in h.items():
            if '\r' in v or '\n' in v:
                ctx.flag(45, 'hdr:crlf_injection', n)
                ctx.verdict = Verdict.BLOCK
                issues.append('crlf_injection')
                break

        # Too many headers
        if len(h) > 50:
            ctx.flag(10, f'hdr:excessive_count({len(h)})', n)
            issues.append('excessive_headers')

        # Suspicious X- headers
        for k in h:
            if k.lower().startswith('x-') and len(h[k]) > 256:
                ctx.flag(5, f'hdr:suspicious_x_header({k})', n)

        ctx.step(n, 'header_anomaly', f"issues={issues or 'none'}")

    # ── STEP 06 ──────────────────────────────────────────────
    def _s06_payload_size(self, ctx: FirewallContext):
        n = 6
        size = len(ctx.body)
        if size > MAX_PAYLOAD_BYTES:
            ctx.flag(60, f'size:exceeds_max({size}>{MAX_PAYLOAD_BYTES})', n)
            ctx.verdict = Verdict.BLOCK
            ctx.step(n, 'payload_size', f"BLOCKED size={size}")
        elif size > MAX_PAYLOAD_BYTES // 2:
            ctx.flag(10, f'size:large({size})', n)
            ctx.step(n, 'payload_size', f"large size={size}")
        else:
            ctx.step(n, 'payload_size', f"ok size={size}")

    # ── STEP 07 ──────────────────────────────────────────────
    def _s07_encoding_normalization(self, ctx: FirewallContext):
        n = 7
        try:
            raw = ctx.body.decode('utf-8', errors='ignore')
            combined = ctx.path + '?' + ctx.query_string + '&body=' + raw
            normalized = self.normalizer.normalize(combined)
            ctx.normalized_body = normalized
            # Check for double-encoding (a evasion technique)
            if urllib.parse.unquote(normalized) != normalized:
                ctx.flag(15, 'enc:double_encoding', n)
            ctx.step(n, 'encoding_normalization', 'ok')
        except Exception as e:
            ctx.step(n, 'encoding_normalization', f"error:{e}")

    # ── STEP 08 ──────────────────────────────────────────────
    def _s08_sqli_detection(self, ctx: FirewallContext):
        n = 8
        target = ctx.normalized_body or (
            ctx.path + ctx.query_string +
            ctx.body.decode("utf-8", errors="ignore")[:4096]
        )
        # Core SQLi patterns
        sqli_patterns = [
            (r"(?i)(\bunion\b.{0,20}\bselect\b)",                    55),
            (r"(?i)(\bdrop\b.{0,10}\btable\b|\bdrop\b.{0,5}\bdb\b)", 55),
            (r"(?i)(or\s+[\'\"]?\d+[\'\"]?\s*=\s*[\'\"]?\d+)",       20),
            (r"(?i)(--\s*$|#\s*$|/\*[\s\S]*?\*/)",                   15),
            (r"(?i)(\bsleep\b\s*\(|\bbenchmark\b\s*\()",             20),
            (r"(?i)(\bload_file\b|\binto\s+outfile\b)",              55),
            (r"(?i)(information_schema|sys\.tables|pg_tables)",       20),
            (r"(?i)(;\s*(drop|insert|update|delete|exec)\b)",         55),
        ]
        hits = []
        for pattern, score in sqli_patterns:
            if re.search(pattern, target):
                hits.append(pattern[:30])
                ctx.flag(score, f'sqli:{pattern[:20]}', n)
        if hits:
            ctx.verdict = Verdict.BLOCK if ctx.risk_score >= BLOCK_SCORE else ctx.verdict
        ctx.step(n, 'sqli_detection', f"hits={len(hits)}")

    # ── STEP 09 ──────────────────────────────────────────────
    def _s09_xss_detection(self, ctx: FirewallContext):
        n = 9
        target = ctx.normalized_body or (ctx.path + ctx.query_string)
        xss_patterns = [
            (r"(?i)<script[\s>]",                          45),
            (r"(?i)javascript\s*:",                        20),
            (r"(?i)on\w+\s*=\s*[\"']?[^\"'>\s]+",        20),
            (r"(?i)(eval|setTimeout|setInterval)\s*\(",   15),
            (r"(?i)<(iframe|object|embed|svg|math)",       15),
            (r"(?i)document\.(cookie|write|location)",     20),
            (r"(?i)(alert|confirm|prompt)\s*\(",           20),
            (r"(?i)data:text/html",                        20),
        ]
        hits = []
        for pattern, score in xss_patterns:
            if re.search(pattern, target):
                hits.append(pattern[:30])
                ctx.flag(score, f'xss:{pattern[:20]}', n)
        ctx.step(n, 'xss_detection', f"hits={len(hits)}")

    # ── STEP 10 ──────────────────────────────────────────────
    def _s10_ssti_detection(self, ctx: FirewallContext):
        n = 10
        target = ctx.normalized_body or (ctx.path + ctx.query_string)
        ssti_patterns = [
            (r"\{\{.{0,100}\}\}",          25),   # Jinja2 / Twig
            (r"\{%[\s\S]{0,100}%\}",       25),   # Jinja2 / Django
            (r"\$\{.{0,100}\}",            20),   # FreeMarker / EL
            (r"#\{.{0,100}\}",             20),   # Thymeleaf
            (r"@\{.{0,100}\}",             15),   # Thymeleaf URL
            (r"<\?=.{0,100}\?>",           20),   # PHP short echo
            (r"\{\{7\*7\}\}",              30),   # Classic SSTI probe
            (r"\{\{''.{0,20}__class__",    30),   # Python SSTI
        ]
        hits = []
        for pattern, score in ssti_patterns:
            if re.search(pattern, target, re.DOTALL):
                hits.append(pattern[:30])
                ctx.flag(score, f'ssti:{pattern[:20]}', n)
        ctx.step(n, 'ssti_detection', f"hits={len(hits)}")

    # ── STEP 11 ──────────────────────────────────────────────
    def _s11_path_traversal(self, ctx: FirewallContext):
        n = 11
        target = ctx.path + ctx.query_string + ctx.normalized_body
        traversal_patterns = [
            (r"\.\./",                          25),
            (r"\.\.\\",                         25),
            (r"%2e%2e%2f",                      25),
            (r"%252e%252e%252f",                30),   # double-encoded
            (r"/etc/(passwd|shadow|hosts|cron)", 30),
            (r"/proc/self",                     20),
            (r"(win\.ini|boot\.ini|system32)",  25),
            (r"\\windows\\system",              25),
        ]
        hits = []
        for pattern, score in traversal_patterns:
            if re.search(pattern, target, re.IGNORECASE):
                hits.append(pattern[:30])
                ctx.flag(score, f'path_trav:{pattern[:20]}', n)
                if score >= 25:
                    ctx.verdict = Verdict.BLOCK
        ctx.step(n, 'path_traversal', f"hits={len(hits)}")

    # ── STEP 12 ──────────────────────────────────────────────
    def _s12_command_injection(self, ctx: FirewallContext):
        n = 12
        target = ctx.normalized_body or (
            ctx.path + ctx.query_string +
            ctx.body.decode("utf-8", errors="ignore")[:4096]
        )
        cmd_patterns = [
            (r";\s*(ls|cat|id|whoami|wget|curl|nc|bash|sh|cmd|powershell)\b", 30),
            (r"&&\s*(ls|cat|id|whoami|wget|curl|nc|bash|sh)",                 30),
            (r"\|\|\s*(ls|cat|id|whoami|wget|curl|nc|bash|sh)",               30),
            (r"`[^`]{1,200}`",                                                 25),
            (r"\$\([^)]{1,200}\)",                                             25),
            (r"(?i)(exec\s*\(|system\s*\(|passthru\s*\(|shell_exec\s*\()",    30),
            (r"(?i)(python|perl|ruby|php|node)\s+-[ec]\s+['\"]",              25),
            (r"(?i)(wget|curl)\s+https?://",                                   20),
        ]
        hits = []
        for pattern, score in cmd_patterns:
            if re.search(pattern, target, re.DOTALL):
                hits.append(pattern[:30])
                ctx.flag(score, f'cmdinj:{pattern[:20]}', n)
                ctx.verdict = Verdict.BLOCK
        ctx.step(n, 'cmd_injection', f"hits={len(hits)}")

    # ── STEP 13 ──────────────────────────────────────────────
    def _s13_taint_propagation(self, ctx: FirewallContext):
        """
        Track taint: if any user-controlled input (path, query, body)
        contains patterns that appear in multiple input channels simultaneously,
        elevate risk — this indicates a coordinated multi-vector attack.
        """
        n = 13
        sources = {
            'path':  ctx.path,
            'query': ctx.query_string,
            'body':  ctx.body.decode('utf-8', errors='ignore')[:2048],
        }
        # Extract tokens >6 chars from each source
        token_map = {}
        for src, text in sources.items():
            tokens = set(re.findall(r'[^\s&=?#/]{6,}', text))
            token_map[src] = tokens

        # Find tokens common across sources (cross-channel taint)
        common = token_map['path'] & token_map['query']
        common |= token_map['path'] & token_map['body']
        common |= token_map['query'] & token_map['body']

        taint_hits = [t for t in common if re.search(
            r'(?i)(select|union|script|eval|exec|cmd|bash|etc/passwd)', t
        )]
        if taint_hits:
            ctx.flag(20 * len(taint_hits[:3]), f'taint:cross_channel({len(taint_hits)})', n)
        ctx.step(n, 'taint_propagation', f"cross_channel_tokens={len(taint_hits)}")

    # ── STEP 14 ──────────────────────────────────────────────
    def _s14_behavioral_baseline(self, ctx: FirewallContext):
        n = 14
        delta, tags = self.detector.score(ctx)
        if delta > 0:
            ctx.flag(delta, f'behavioral:{",".join(tags)}', n)
        self.detector.record(ctx)
        ctx.step(n, 'behavioral_baseline', f"delta={delta} tags={tags or 'none'}")

    # ── STEP 15 ──────────────────────────────────────────────
    def _s15_entropy_scoring(self, ctx: FirewallContext):
        n = 15
        if not ctx.body:
            ctx.step(n, 'entropy_scoring', 'no body')
            return
        freq  = defaultdict(int)
        for b in ctx.body:
            freq[b] += 1
        total   = len(ctx.body)
        entropy = -sum((c / total) * math.log2(c / total) for c in freq.values())

        if entropy >= ENTROPY_HIGH:
            ctx.flag(40, f'entropy:very_high({entropy:.2f})', n)
            ctx.verdict = Verdict.BLOCK
        elif entropy >= ENTROPY_WARN:
            ctx.flag(15, f'entropy:elevated({entropy:.2f})', n)
        ctx.step(n, 'entropy_scoring', f"entropy={entropy:.3f}")

    # ── STEP 16 ──────────────────────────────────────────────
    def _s16_session_integrity(self, ctx: FirewallContext):
        n = 16
        token = (ctx.headers.get('x-zeus-session') or
                 ctx.headers.get('X-Zeus-Session') or
                 ctx.session_token)
        if not token:
            ctx.step(n, 'session_integrity', 'no token (unscored)')
            return
        valid, reason = self.session.validate_token(token, ctx.ip)
        if not valid:
            ctx.flag(30, f'session:{reason}', n)
            ctx.step(n, 'session_integrity', f"INVALID reason={reason}")
        else:
            ctx.step(n, 'session_integrity', 'valid')

    # ── STEP 17 ──────────────────────────────────────────────
    def _s17_replay_detection(self, ctx: FirewallContext):
        n = 17
        is_replay = self.replay.check(ctx)
        if is_replay:
            ctx.flag(35, 'replay:duplicate_request', n)
            ctx.step(n, 'replay_detection', 'REPLAY DETECTED')
        else:
            ctx.step(n, 'replay_detection', 'ok — unique')

    # ── STEP 18 ──────────────────────────────────────────────
    def _s18_privilege_escalation(self, ctx: FirewallContext):
        n = 18
        target = ctx.normalized_body or (ctx.path + ctx.query_string)
        priv_patterns = [
            (r"(?i)\bsudo\b",                             20),
            (r"(?i)\bsu\s+-\b",                           20),
            (r"(?i)chmod\s+[0-7]{3,4}",                   15),
            (r"(?i)/etc/sudoers",                          30),
            (r"(?i)(setuid|setgid|chown\s+root)",          25),
            (r"(?i)(\brole\s*=\s*admin|\bis_admin\s*=\s*true|\badmin\s*=\s*1)", 25),
            (r"(?i)(privilege|escalate|root|superuser)",   10),
            (r"(?i)Authorization:\s*Bearer\s+.{100,}",    15),  # oversized JWT
        ]
        hits = []
        for pattern, score in priv_patterns:
            if re.search(pattern, target):
                hits.append(pattern[:30])
                ctx.flag(score, f'priv_esc:{pattern[:20]}', n)
        ctx.step(n, 'privilege_escalation', f"hits={len(hits)}")

    # ── STEP 19 ──────────────────────────────────────────────
    def _s19_output_sanitization(self, ctx: FirewallContext):
        """
        Validate that outbound-bound data in body doesn't leak server internals.
        (For responses proxied through — skip if not applicable.)
        """
        n = 19
        leakage_patterns = [
            r"(?i)(traceback|stack trace|exception in|sqlalchemy|pymysql)",
            r"(?i)(server:\s*(apache|nginx|iis|gunicorn|flask)\b)",
            r"(?i)(internal server error|debug mode|werkzeug)",
            r"\b(?:192\.168|10\.\d+|172\.(?:1[6-9]|2\d|3[01]))\.\d+\b",  # private IPs in response
        ]
        body_str = ctx.body.decode('utf-8', errors='ignore')
        for pattern in leakage_patterns:
            if re.search(pattern, body_str):
                ctx.flag(10, f'output:leakage_pattern', n)
        ctx.step(n, 'output_sanitization', 'checked')

    # ── STEP 20 ──────────────────────────────────────────────
    def _s20_audit_log(self, ctx: FirewallContext):
        n = 20
        log_line = (
            f"REQ={ctx.request_id} IP={ctx.ip} METHOD={ctx.method} "
            f"PATH={ctx.path[:80]} SCORE={ctx.risk_score} "
            f"TAGS={ctx.threat_tags[:5]} VERDICT_PRELIM={ctx.verdict.value}"
        )
        if ctx.risk_score >= SANDBOX_SCORE:
            log.warning(log_line)
        else:
            log.info(log_line)
        ctx.step(n, 'audit_log', f"risk_score={ctx.risk_score}")

    # ── STEP 21 ──────────────────────────────────────────────
    def _s21_adaptive_mutation(self, ctx: FirewallContext):
        """
        If this request produced a BLOCK or SANDBOX verdict,
        send the payload to the sandbox for static analysis
        and persist any derived signatures back to the DB.
        """
        n = 21
        if ctx.verdict not in (Verdict.BLOCK, Verdict.SANDBOX):
            ctx.step(n, 'adaptive_mutation', 'skip — non-threatening')
            return

        # Run sandbox analysis asynchronously
        meta = {
            'ip':      ctx.ip,
            'path':    ctx.path,
            'method':  ctx.method,
            'tags':    ctx.threat_tags,
            'score':   ctx.risk_score,
        }
        try:
            analysis = self.sandbox.analyze(ctx.body, meta)
            ctx.sandbox_report = analysis

            # If sandbox derived a signature, store it
            derived = analysis.get('derived_signature')
            if derived:
                sig = ThreatSignature(
                    category=ThreatCategory(derived.get('category', 'unknown')),
                    pattern=derived['pattern'],
                    severity=derived['severity'],
                    description=derived['description'],
                    auto_learned=True,
                )
                self.db.store_signature(sig)
                # Refresh in-memory sig list
                with self._sig_lock:
                    self._sigs = self.db.get_signatures()
                ctx.step(n, 'adaptive_mutation', f"new_sig learned: {sig.description[:50]}")
            else:
                ctx.step(n, 'adaptive_mutation', 'analysis complete — no new signature')

            # Persist the threat to DB
            self.db.store_threat(ctx)

        except Exception as e:
            ctx.step(n, 'adaptive_mutation', f"error:{e}")


    # ── STEP 22 ──────────────────────────────────────────────
    def _s22_telephony_guard(self, ctx: FirewallContext):
        """
        Detect VoIP/SIP abuse, spam callers, toll fraud, and robocall
        patterns in HTTP traffic (including REST telephony API abuse).
        """
        n = 22
        delta, tags = self.telephony.inspect(ctx)
        if delta > 0:
            for tag in tags:
                ctx.flag(delta // max(len(tags), 1), tag, n)
            if delta >= 40:
                ctx.verdict = Verdict.BLOCK
        ctx.step(n, 'telephony_guard',
                 f"delta={delta} tags={tags or 'none'}")


# ══════════════════════════════════════════════════════════════
# MAIN ZEUS FIREWALL ORCHESTRATOR
# ══════════════════════════════════════════════════════════════

class ZeusFirewall:
    """
    Top-level firewall object. Wires all subsystems together.
    Provides inspect() for inline use and adapters for Flask,
    WSGI, standalone HTTP proxy, and raw socket mode.
    """

    def __init__(self, db_path: str = DB_PATH, shard_limit: int = SHARD_LIMIT):
        self.db         = ThreatDatabase(db_path, shard_limit)
        self.sandbox    = SecureSandbox()
        self.detector   = AutonomousDetector()
        self.rate       = RateLimiter()
        self.replay     = ReplayDetector()
        self.session    = SessionValidator()
        self.reputation = IPReputation(self.db)
        self.normalizer = EncodingNormalizer()
        self.telephony  = TelephonyGuard()
        self.pipeline   = FirewallPipeline(
            self.db, self.sandbox, self.detector,
            self.rate, self.replay, self.session,
            self.reputation, self.normalizer,
            self.telephony
        )
        log.info(f"ZeusFirewall ready | platform={PLATFORM.system}/{PLATFORM.machine} | "
                 f"db={db_path} | attrib='{ATTRIB}'")

    def inspect(
        self,
        ip:           str,
        method:       str,
        path:         str,
        headers:      Dict[str, str],
        body:         bytes          = b'',
        query_string: str            = '',
        session_token: Optional[str] = None,
        framework:    str            = 'unknown',
    ) -> dict:
        """
        Primary inspection entry point.
        Returns a dict with verdict, risk_score, threat_tags, step_log.
        """
        ctx = FirewallContext(
            ip=ip,
            method=method.upper(),
            path=path,
            headers={k.lower(): v for k, v in headers.items()},
            body=body,
            query_string=query_string,
            session_token=session_token,
            framework=framework,
        )
        ctx = self.pipeline.run(ctx)
        return ctx.to_dict()

    # ── FLASK MIDDLEWARE ──────────────────────────────────────

    def flask_middleware(self):
        """
        Returns a Flask before_request / after_request handler pair.

        Usage:
            fw = ZeusFirewall()
            before, after = fw.flask_middleware()
            app.before_request(before)
            app.after_request(after)
        """
        try:
            from flask import request, jsonify, g
            import flask

            firewall = self

            def before_request():
                result = firewall.inspect(
                    ip=request.remote_addr or '0.0.0.0',
                    method=request.method,
                    path=request.path,
                    headers=dict(request.headers),
                    body=request.get_data(),
                    query_string=request.query_string.decode('utf-8', errors='ignore'),
                    framework='flask',
                )
                g.zeus_fw = result
                if result['verdict'] == Verdict.BLOCK.value:
                    return jsonify({
                        'error': 'Forbidden',
                        'request_id': result['request_id'],
                        'attrib': ATTRIB,
                    }), 403

            def after_request(response):
                fw_result = getattr(flask.g, 'zeus_fw', None)
                if fw_result:
                    response.headers['X-Zeus-Request-ID'] = fw_result['request_id']
                    response.headers['X-Zeus-Verdict']    = fw_result['verdict']
                return response

            return before_request, after_request

        except ImportError:
            raise RuntimeError("Flask not installed — cannot use flask_middleware()")

    # ── WSGI MIDDLEWARE ───────────────────────────────────────

    def wsgi_middleware(self, app):
        """
        Wrap any WSGI application with Zeus firewall inspection.

        Usage:
            fw = ZeusFirewall()
            gunicorn_app = fw.wsgi_middleware(my_flask_or_django_app)
        """
        firewall = self

        class ZeusWSGIMiddleware:
            def __init__(self, wsgi_app):
                self.app = wsgi_app

            def __call__(self, environ, start_response):
                ip     = environ.get('REMOTE_ADDR', '0.0.0.0')
                method = environ.get('REQUEST_METHOD', 'GET')
                path   = environ.get('PATH_INFO', '/')
                qs     = environ.get('QUERY_STRING', '')
                cl     = int(environ.get('CONTENT_LENGTH', 0) or 0)
                body   = environ['wsgi.input'].read(min(cl, MAX_PAYLOAD_BYTES)) if cl else b''
                hdrs   = {k[5:].replace('_', '-').lower(): v
                          for k, v in environ.items() if k.startswith('HTTP_')}

                result = firewall.inspect(
                    ip=ip, method=method, path=path, headers=hdrs,
                    body=body, query_string=qs, framework='wsgi'
                )

                if result['verdict'] == Verdict.BLOCK.value:
                    body_403 = json.dumps({
                        'error': 'Forbidden',
                        'request_id': result['request_id'],
                    }).encode()
                    start_response('403 Forbidden', [
                        ('Content-Type', 'application/json'),
                        ('Content-Length', str(len(body_403))),
                        ('X-Zeus-Request-ID', result['request_id']),
                    ])
                    return [body_403]

                # Replay body for downstream app
                from io import BytesIO
                environ['wsgi.input']      = BytesIO(body)
                environ['CONTENT_LENGTH']  = str(len(body))
                return self.app(environ, start_response)

        return ZeusWSGIMiddleware(app)

    # ── STANDALONE HTTP PROXY ─────────────────────────────────

    def as_standalone_proxy(self, host: str = '0.0.0.0', port: int = 8888,
                             upstream_host: str = '127.0.0.1',
                             upstream_port: int = 5000):
        """
        Minimal HTTP reverse proxy with Zeus firewall inspection.
        Works in Termux, Userland, Linux, and Windows CMD.
        Does NOT require any external library — pure stdlib sockets.
        """
        import threading

        def handle_client(client_sock, client_addr):
            try:
                data = b''
                client_sock.settimeout(5)
                while True:
                    chunk = client_sock.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                    if b'\r\n\r\n' in data:
                        break

                if not data:
                    client_sock.close()
                    return

                # Parse HTTP request (minimal)
                header_end = data.index(b'\r\n\r\n')
                header_raw = data[:header_end].decode('utf-8', errors='ignore')
                body       = data[header_end + 4:]

                lines  = header_raw.split('\r\n')
                req    = lines[0].split(' ')
                method = req[0] if len(req) > 0 else 'GET'
                full_path = req[1] if len(req) > 1 else '/'
                path_parts = full_path.split('?', 1)
                path   = path_parts[0]
                qs     = path_parts[1] if len(path_parts) > 1 else ''
                headers = {}
                for line in lines[1:]:
                    if ': ' in line:
                        k, v = line.split(': ', 1)
                        headers[k] = v

                result = self.inspect(
                    ip=client_addr[0],
                    method=method,
                    path=path,
                    headers=headers,
                    body=body,
                    query_string=qs,
                    framework='standalone_proxy'
                )

                if result['verdict'] == Verdict.BLOCK.value:
                    resp = (
                        b"HTTP/1.1 403 Forbidden\r\n"
                        b"Content-Type: application/json\r\n"
                        b"Connection: close\r\n\r\n"
                        b'{"error":"Forbidden"}'
                    )
                    client_sock.sendall(resp)
                    client_sock.close()
                    return

                # Forward to upstream
                upstream = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                upstream.settimeout(10)
                upstream.connect((upstream_host, upstream_port))
                upstream.sendall(data)
                response = b''
                while True:
                    chunk = upstream.recv(4096)
                    if not chunk:
                        break
                    response += chunk
                upstream.close()

                client_sock.sendall(response)
                client_sock.close()

            except Exception as e:
                log.debug(f"Proxy handler error: {e}")
                try:
                    client_sock.close()
                except Exception:
                    pass

        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((host, port))
        srv.listen(50)
        log.info(f"Zeus standalone proxy → {host}:{port} → {upstream_host}:{upstream_port}")

        def accept_loop():
            while True:
                try:
                    client, addr = srv.accept()
                    t = threading.Thread(target=handle_client, args=(client, addr), daemon=True)
                    t.start()
                except Exception as e:
                    log.error(f"Accept error: {e}")

        t = threading.Thread(target=accept_loop, daemon=True, name='zeus-proxy')
        t.start()
        return srv

    # ── CLI / MANUAL INSPECT ──────────────────────────────────

    def status(self) -> dict:
        stats = self.db.get_stats()
        stats['platform'] = PLATFORM.summary()
        stats['attrib']   = ATTRIB
        return stats


# ══════════════════════════════════════════════════════════════
# FRAMEWORK-AGNOSTIC DECORATOR
# ══════════════════════════════════════════════════════════════

_default_fw: Optional[ZeusFirewall] = None

def get_firewall(db_path: str = DB_PATH) -> ZeusFirewall:
    global _default_fw
    if _default_fw is None:
        _default_fw = ZeusFirewall(db_path=db_path)
    return _default_fw

def zeus_protect(fw: Optional[ZeusFirewall] = None):
    """
    Decorator for any function that receives (request, *args, **kwargs).
    Works with Flask route functions when applied after @app.route.

    Usage:
        @app.route('/api/data')
        @zeus_protect()
        def api_data():
            ...
    """
    def decorator(fn):
        from functools import wraps

        @wraps(fn)
        def wrapper(*args, **kwargs):
            firewall = fw or get_firewall()
            try:
                from flask import request, jsonify
                result = firewall.inspect(
                    ip=request.remote_addr or '0.0.0.0',
                    method=request.method,
                    path=request.path,
                    headers=dict(request.headers),
                    body=request.get_data(),
                    query_string=request.query_string.decode('utf-8', errors='ignore'),
                    framework='flask_decorator',
                )
                if result['verdict'] == Verdict.BLOCK.value:
                    return jsonify({'error': 'Forbidden', 'id': result['request_id']}), 403
            except ImportError:
                pass  # Non-Flask context — skip
            return fn(*args, **kwargs)
        return wrapper
    return decorator


# ══════════════════════════════════════════════════════════════
# ENTRY POINT — STANDALONE DEMO / TEST
# ══════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Zeus Firewall v1 — The Zeus Project 2026')
    parser.add_argument('--mode',   default='status',
                        choices=['status', 'proxy', 'test'],
                        help='Run mode')
    parser.add_argument('--host',   default='0.0.0.0')
    parser.add_argument('--port',   type=int, default=8888)
    parser.add_argument('--up-host', default='127.0.0.1')
    parser.add_argument('--up-port', type=int, default=5000)
    parser.add_argument('--db',     default=DB_PATH)
    args = parser.parse_args()

    fw = ZeusFirewall(db_path=args.db)

    if args.mode == 'status':
        stats = fw.status()
        print(json.dumps(stats, indent=2))

    elif args.mode == 'proxy':
        srv = fw.as_standalone_proxy(
            host=args.host, port=args.port,
            upstream_host=args.up_host, upstream_port=args.up_port
        )
        print(f"[Zeus] Proxy running on {args.host}:{args.port} → {args.up_host}:{args.up_port}")
        print("Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            srv.close()
            print("[Zeus] Proxy stopped.")

    elif args.mode == 'test':
        print("=== ZeusFirewall Self-Test ===\n")
        tests = [
            ('Clean',    'GET', '/', {}, b'',                   ''),
            ('SQLi',     'GET', '/search', {}, b'',             "q=1' UNION SELECT * FROM users--"),
            ('XSS',      'POST', '/comment', {}, b'<script>alert(1)</script>', ''),
            ('SSTI',     'GET', '/greet', {}, b'',              "name={{7*7}}"),
            ('PathTrav', 'GET', '/file', {}, b'',               "f=../../etc/passwd"),
            ('CmdInj',   'POST', '/run', {}, b'; cat /etc/shadow', ''),
            ('Scanner',  'GET', '/', {'user-agent': 'sqlmap/1.0'}, b'', ''),
            ('Entropy',  'POST', '/upload', {}, os.urandom(512), ''),
        ]
        for name, method, path, hdrs, body, qs in tests:
            r = fw.inspect(ip='10.0.0.99', method=method, path=path,
                           headers=hdrs, body=body, query_string=qs)
            verdict = r['verdict'].upper()
            score   = r['risk_score']
            tags    = r['threat_tags'][:3]
            status  = '✓ BLOCKED' if verdict == 'BLOCK' else ('⚠ SANDBOX' if verdict == 'sandbox' else '✗ ALLOWED')
            print(f"  [{name:10s}] {status:12s} score={score:3d}  tags={tags}")

        print(f"\nDB Stats: {json.dumps(fw.db.get_stats(), indent=2)}")
