# The Zeus Project 2026 — Francois Nel
# gunicorn_zeus.py — Gunicorn config for armv7l

bind             = "0.0.0.0:8080"
workers          = 1          # 1 worker — armv7l memory constraint
worker_class     = "sync"
timeout          = 120
keepalive        = 5
max_requests     = 1000
max_requests_jitter = 100
preload_app      = False      # False = safer on armv7l
daemon           = False      # nohup handles daemonising
accesslog        = "logs/zeus_access.log"
errorlog         = "logs/zeus_error.log"
loglevel         = "info"
capture_output   = True
enable_stdio_inheritance = True
