"""
zeus_geo_intel.py
=================
Zeus GovInt — Geolocation Intelligence Module
Author: Francois Nel | The Zeus Project 2026

Provides tiered geolocation based on authorization level:
  AUTH LEVEL 0 — IP geolocation (public API, no warrant)
  AUTH LEVEL 1 — Enhanced IP + ISP data
  AUTH LEVEL 2 — Subscriber info (requires RICA court order)
  AUTH LEVEL 3 — CSLI carrier data (requires high court warrant)
  AUTH LEVEL 4 — Priority CSLI (requires national security directive)

Carrier CSLI levels 2-4 are gated behind AuthorizationGate.
"""
from __future__ import annotations
import json, logging, os, time, threading, uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
import urllib.request
import urllib.error

from zeus_geo_auth import AuthorizationGate, AuthLevel

log = logging.getLogger("zeus.geo_intel")

# ── IP Geolocation (Level 0 — no warrant, public API) ────────────────────────

class IPGeolocator:
    """
    Real IP geolocation using public APIs.
    No warrant required — city/region level accuracy only.
    Chains through multiple providers for reliability.
    """
    PROVIDERS = [
        "https://ipinfo.io/{ip}/json",
        "http://ip-api.com/json/{ip}?fields=status,country,countryCode,region,regionName,city,lat,lon,isp,org,as,query",
        "https://ipapi.co/{ip}/json/",
    ]
    TIMEOUT = 5

    def resolve(self, ip: str) -> Dict[str, Any]:
        """Resolve IP to location using live public API chain."""
        for provider_url in self.PROVIDERS:
            try:
                url = provider_url.format(ip=ip)
                req = urllib.request.Request(url, headers={"User-Agent": "ZeusGovInt/1.0"})
                with urllib.request.urlopen(req, timeout=self.TIMEOUT) as resp:
                    data = json.loads(resp.read().decode())
                    normalized = self._normalize(data, provider_url)
                    if normalized.get("lat") and normalized.get("lon"):
                        log.info("IP geo resolved %s via %s: %s, %s",
                                 ip, provider_url.split("/")[2],
                                 normalized.get("city"), normalized.get("country"))
                        return normalized
            except Exception as e:
                log.debug("IP geo provider %s failed for %s: %s",
                          provider_url.split("/")[2], ip, e)
                continue
        # All providers failed — return unknown
        return {
            "ip": ip, "city": "Unknown", "region": "Unknown",
            "country": "Unknown", "country_code": "??",
            "lat": 0.0, "lon": 0.0,
            "accuracy_km": 9999, "isp": "Unknown",
            "method": "IP_GEOLOCATION_FAILED",
            "limitation": "All geolocation providers unreachable"
        }

    @staticmethod
    def _normalize(data: Dict, provider_url: str) -> Dict:
        """Normalize different provider response formats."""
        if "ipinfo.io" in provider_url:
            loc = data.get("loc", "0,0").split(",")
            return {
                "ip": data.get("ip",""),
                "city": data.get("city","Unknown"),
                "region": data.get("region","Unknown"),
                "country": data.get("country","Unknown"),
                "country_code": data.get("country","??"),
                "lat": float(loc[0]) if len(loc)==2 else 0.0,
                "lon": float(loc[1]) if len(loc)==2 else 0.0,
                "accuracy_km": 25,
                "isp": data.get("org","Unknown"),
                "method": "IP_GEOLOCATION_IPINFO",
            }
        elif "ip-api.com" in provider_url:
            return {
                "ip": data.get("query",""),
                "city": data.get("city","Unknown"),
                "region": data.get("regionName","Unknown"),
                "country": data.get("country","Unknown"),
                "country_code": data.get("countryCode","??"),
                "lat": float(data.get("lat", 0)),
                "lon": float(data.get("lon", 0)),
                "accuracy_km": 25,
                "isp": data.get("isp","Unknown"),
                "method": "IP_GEOLOCATION_IPAPI",
            }
        elif "ipapi.co" in provider_url:
            return {
                "ip": data.get("ip",""),
                "city": data.get("city","Unknown"),
                "region": data.get("region","Unknown"),
                "country": data.get("country_name","Unknown"),
                "country_code": data.get("country_code","??"),
                "lat": float(data.get("latitude", 0)),
                "lon": float(data.get("longitude", 0)),
                "accuracy_km": 25,
                "isp": data.get("org","Unknown"),
                "method": "IP_GEOLOCATION_IPAPICOUK",
            }
        return data

# ── Carrier CSLI Interface (Level 2-4 — warrant gated) ───────────────────────

class CarrierCSLIInterface:
    """
    Interface to carrier Cell Site Location Information.
    LOCKED until a valid authorization document is verified by AuthorizationGate.
    
    Integration points (configured per-carrier via environment):
      CARRIER_VODACOM_ENDPOINT — Vodacom lawful intercept endpoint
      CARRIER_MTN_ENDPOINT     — MTN lawful intercept endpoint
      CARRIER_CELLC_ENDPOINT   — Cell C lawful intercept endpoint
      CARRIER_API_CERT         — mTLS client certificate path
      CARRIER_API_KEY          — API key (if carrier uses key auth)
    
    These endpoints are configured by carrier agreement and cannot be
    hardcoded. The AuthorizationGate must validate before any call is made.
    """

    SA_CARRIERS = {
        "Vodacom SA":  os.environ.get("CARRIER_VODACOM_ENDPOINT", ""),
        "MTN SA":      os.environ.get("CARRIER_MTN_ENDPOINT", ""),
        "Cell C SA":   os.environ.get("CARRIER_CELLC_ENDPOINT", ""),
        "Telkom SA":   os.environ.get("CARRIER_TELKOM_ENDPOINT", ""),
    }

    def __init__(self, auth_gate: AuthorizationGate):
        self.auth_gate = auth_gate

    def query_subscriber(self, target_identifier: str,
                         doc_id: str, operator: str) -> Dict[str, Any]:
        """Query subscriber info — requires SUBSCRIBER_QUERY auth level."""
        # Determine which carrier endpoint to use
        for carrier, endpoint in self.SA_CARRIERS.items():
            if endpoint:
                try:
                    result = self._call_carrier_api(endpoint, "subscriber_query",
                                                    target_identifier, doc_id)
                    self.auth_gate.log_geolocation_query(
                        doc_id, target_identifier, "subscriber_query",
                        0, 0, 0, f"SUBSCRIBER_DB_{carrier}", operator)
                    return result
                except Exception as e:
                    log.warning("Carrier %s subscriber query failed: %s", carrier, e)
        return {"status": "CARRIER_ENDPOINT_NOT_CONFIGURED",
                "message": "No carrier endpoints configured. Contact carrier for MOU.",
                "target": target_identifier}

    def query_csli(self, msisdn: str, doc_id: str,
                   operator: str) -> Dict[str, Any]:
        """Query CSLI tower data — requires CARRIER_CSLI auth level."""
        for carrier, endpoint in self.SA_CARRIERS.items():
            if endpoint:
                try:
                    result = self._call_carrier_api(endpoint, "csli_query",
                                                    msisdn, doc_id)
                    lat = result.get("lat", 0)
                    lon = result.get("lon", 0)
                    acc = result.get("accuracy_meters", 9999)
                    self.auth_gate.log_geolocation_query(
                        doc_id, msisdn, "csli_triangulation",
                        lat, lon, acc, f"CSLI_{carrier}", operator)
                    return result
                except Exception as e:
                    log.warning("Carrier %s CSLI query failed: %s", carrier, e)
        return {"status": "CARRIER_ENDPOINT_NOT_CONFIGURED",
                "message": "Carrier CSLI endpoints require signed MOU agreement.",
                "msisdn": msisdn,
                "action_required": "Submit MOU to carrier lawful intercept department"}

    def _call_carrier_api(self, endpoint: str, query_type: str,
                           target: str, doc_id: str) -> Dict:
        """
        Makes authenticated call to carrier lawful intercept API.
        Uses mTLS client certificate if configured.
        """
        import ssl, urllib.request
        cert_path = os.environ.get("CARRIER_API_CERT", "")
        api_key   = os.environ.get("CARRIER_API_KEY", "")

        payload = json.dumps({
            "query_type": query_type,
            "target": target,
            "authorization_doc_id": doc_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }).encode()

        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["X-API-Key"] = api_key

        ctx = ssl.create_default_context()
        if cert_path and os.path.exists(cert_path):
            ctx.load_cert_chain(cert_path)

        req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req, context=ctx, timeout=10) as resp:
            return json.loads(resp.read().decode())

# ── Main GeoIntel Module ──────────────────────────────────────────────────────

class ZeusGeoIntel:
    """
    Main geolocation intelligence module.
    Tier-based: IP geo always available, higher tiers require warrant.
    """

    def __init__(self, auth_gate: AuthorizationGate):
        self.auth_gate = auth_gate
        self.ip_geolocator = IPGeolocator()
        self.carrier = CarrierCSLIInterface(auth_gate)

    def locate(self, target_ip: str, operator: str = "system",
               threat_context: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Primary location method. Returns best available location data
        based on current authorization level for this target.
        """
        auth_level = self.auth_gate.get_auth_level(target_ip)
        log.info("Locating %s | auth_level=%s", target_ip, auth_level.name)

        # Always perform IP geolocation (no warrant needed)
        ip_geo = self.ip_geolocator.resolve(target_ip)

        result: Dict[str, Any] = {
            "target_ip": target_ip,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "auth_level": auth_level.name,
            "query_id": str(uuid.uuid4()),
            "ip_geolocation": ip_geo,
            "precise_location": None,
            "subscriber_info": None,
            "threat_context": threat_context,
            "legal_status": self._build_legal_status(auth_level, target_ip),
            "action_recommendations": [],
        }

        if auth_level == AuthLevel.IP_GEOLOCATION:
            result["precise_location"] = {
                "lat": ip_geo.get("lat", 0),
                "lon": ip_geo.get("lon", 0),
                "accuracy_meters": ip_geo.get("accuracy_km", 25) * 1000,
                "method": ip_geo.get("method", "IP_GEOLOCATION"),
                "limitation": "City-level only. Higher accuracy requires RICA warrant.",
            }
            result["action_recommendations"].append({
                "action": "OBTAIN_WARRANT",
                "detail": "Submit RICA court order to unlock subscriber-level data",
                "urgency": "STANDARD"
            })
        elif auth_level.value >= AuthLevel.SUBSCRIBER_QUERY.value:
            # Get active document for this target
            active_warrants = self.auth_gate.get_active_warrants()
            doc_id = next((w["doc_id"] for w in active_warrants
                          if w["target_identifier"] == target_ip), "unknown")

            sub_data = self.carrier.query_subscriber(target_ip, doc_id, operator)
            result["subscriber_info"] = sub_data

            if auth_level.value >= AuthLevel.CARRIER_CSLI.value:
                msisdn = sub_data.get("msisdn", "")
                if msisdn:
                    csli = self.carrier.query_csli(msisdn, doc_id, operator)
                    result["precise_location"] = csli
                else:
                    result["precise_location"] = {
                        "lat": ip_geo.get("lat", 0),
                        "lon": ip_geo.get("lon", 0),
                        "accuracy_meters": ip_geo.get("accuracy_km", 25) * 1000,
                        "method": "IP_FALLBACK_NO_MSISDN",
                    }
            else:
                result["precise_location"] = {
                    "lat": ip_geo.get("lat", 0),
                    "lon": ip_geo.get("lon", 0),
                    "accuracy_meters": ip_geo.get("accuracy_km", 25) * 1000,
                    "method": "IP_GEOLOCATION_WITH_SUBSCRIBER_CONTEXT",
                }

            result["action_recommendations"].append({
                "action": "COORDINATE_WITH_CARRIER",
                "detail": f"Subscriber data available. CSLI requires HIGH_COURT_WARRANT.",
                "urgency": "HIGH" if threat_context else "STANDARD"
            })

        # Add threat-based recommendations
        if threat_context:
            risk = threat_context.get("risk_score", 0)
            if risk > 80:
                result["action_recommendations"].insert(0, {
                    "action": "PRIORITY_RESPONSE",
                    "detail": f"High risk score ({risk}) — active threat in progress",
                    "urgency": "CRITICAL",
                    "map_url": f"https://maps.google.com/?q={result['precise_location'].get('lat',0)},{result['precise_location'].get('lon',0)}"
                    if result.get("precise_location") else ""
                })

        return result

    def _build_legal_status(self, auth_level: AuthLevel, target: str) -> Dict:
        active = self.auth_gate.get_active_warrants()
        warrant = next((w for w in active if w["target_identifier"] == target), None)
        return {
            "auth_level": auth_level.name,
            "warrant_active": warrant is not None,
            "warrant_id": warrant["doc_id"] if warrant else None,
            "issuing_authority": warrant["issuing_authority"] if warrant else None,
            "case_number": warrant["case_number"] if warrant else None,
            "expires_utc": warrant["expires_utc"] if warrant else None,
            "rica_compliant": bool(warrant and warrant.get("rica_compliant")),
        }
