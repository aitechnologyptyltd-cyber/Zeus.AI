# The Zeus Project 2026 — Francois Nel
# full_system_check.py — Comprehensive Zeus System Health Checker
# Tests every subsystem: DB, logic engine, LLM APIs, modules, routes
# Produces a full report with pass/fail/warn per check

import os
import sys
import time
import json
import sqlite3
import logging
import importlib
import threading
import subprocess
import traceback
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("zeus.full_check")

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))
if ZEUS_DIR not in sys.path:
    sys.path.insert(0, ZEUS_DIR)


# ============================================================================
# CHECK RESULT
# ============================================================================

class CheckResult:
    PASS = "PASS"
    FAIL = "FAIL"
    WARN = "WARN"
    SKIP = "SKIP"

    def __init__(self, name: str, status: str, message: str,
                  detail: str = "", duration_ms: float = 0.0):
        self.name        = name
        self.status      = status
        self.message     = message
        self.detail      = detail
        self.duration_ms = round(duration_ms, 1)

    def to_dict(self) -> Dict:
        return {
            "name":        self.name,
            "status":      self.status,
            "message":     self.message,
            "detail":      self.detail[:500],
            "duration_ms": self.duration_ms,
        }

    def __str__(self) -> str:
        icon = {"PASS": "✓", "FAIL": "✗", "WARN": "⚠", "SKIP": "○"}[self.status]
        return f"  {icon} [{self.status}] {self.name}: {self.message} ({self.duration_ms}ms)"


# ============================================================================
# CHECK RUNNER
# ============================================================================

def _run_check(name: str, fn) -> CheckResult:
    t0 = time.time()
    try:
        result = fn()
        ms = (time.time() - t0) * 1000
        if isinstance(result, CheckResult):
            result.duration_ms = round(ms, 1)
            return result
        # Assume True = PASS
        return CheckResult(name, CheckResult.PASS, str(result)[:200], duration_ms=ms)
    except Exception as e:
        ms = (time.time() - t0) * 1000
        return CheckResult(
            name, CheckResult.FAIL,
            f"Exception: {type(e).__name__}: {e}",
            detail=traceback.format_exc(limit=4),
            duration_ms=ms,
        )


# ============================================================================
# INDIVIDUAL CHECKS
# ============================================================================

def check_zeus_dir() -> CheckResult:
    required = ["app.py", "db_init.py", "logic_engine.py", "zeus.db"]
    missing  = [f for f in required if not os.path.exists(os.path.join(ZEUS_DIR, f))]
    if missing:
        return CheckResult("zeus_dir", CheckResult.WARN,
                            f"Missing: {missing}", f"ZEUS_DIR={ZEUS_DIR}")
    return CheckResult("zeus_dir", CheckResult.PASS,
                        f"All required files present in {ZEUS_DIR}")


def check_db_connectivity() -> CheckResult:
    from db_init import get_db, db_health
    conn = get_db()
    conn.execute("SELECT 1")
    conn.close()
    health = db_health()
    if health["status"] != "ok":
        return CheckResult("db_connectivity", CheckResult.FAIL,
                            f"DB health error: {health}")
    return CheckResult("db_connectivity", CheckResult.PASS,
                        f"DB ok, schema v{health.get('schema_version','?')}")


def check_db_wal_mode() -> CheckResult:
    from db_init import get_db
    conn = get_db()
    mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
    conn.close()
    if mode != "wal":
        return CheckResult("db_wal_mode", CheckResult.WARN,
                            f"journal_mode={mode} (expected wal)")
    return CheckResult("db_wal_mode", CheckResult.PASS, f"journal_mode=wal")


def check_db_tables() -> CheckResult:
    from db_init import get_db
    required = [
        "genome", "knowledge", "queue", "blueprints",
        "executor_jobs", "chat_history", "evolution_log",
        "synthesis_blueprints", "logic_rules",
    ]
    conn    = get_db()
    existing = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()]
    conn.close()
    missing = [t for t in required if t not in existing]
    if missing:
        return CheckResult("db_tables", CheckResult.FAIL,
                            f"Missing tables: {missing}")
    return CheckResult("db_tables", CheckResult.PASS,
                        f"All {len(required)} required tables present")


def check_db_counts() -> CheckResult:
    from db_init import get_db
    conn    = get_db()
    genome  = conn.execute("SELECT COUNT(*) FROM genome").fetchone()[0]
    kb      = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM queue WHERE status='pending'").fetchone()[0]
    conn.close()
    return CheckResult("db_counts", CheckResult.PASS,
                        f"genome={genome}, knowledge={kb}, queue_pending={pending}")


def check_logic_engine() -> CheckResult:
    from logic_engine import get_engine, LogicFact
    engine  = get_engine()
    if not engine._ready:
        return CheckResult("logic_engine", CheckResult.FAIL, "Logic engine not booted")
    facts   = [LogicFact(predicate="has_extension", args=("test.py", "py"), source="check")]
    result  = engine.reason(facts, max_depth=5)
    n_conc  = len(result.conclusions)
    n_rules = len(engine._reasoner._rules)
    return CheckResult("logic_engine", CheckResult.PASS,
                        f"Rules={n_rules}, conclusions_on_test={n_conc}, "
                        f"boot_ms={engine._stats.get('boot_time_ms','?')}")


def check_logic_engine_semantic_index() -> CheckResult:
    from logic_engine import get_engine
    engine  = get_engine()
    built   = engine._semantic_idx._built
    n_docs  = len(engine._semantic_idx._docs)
    if not built:
        return CheckResult("semantic_index", CheckResult.WARN,
                            f"Semantic index not yet built (docs={n_docs})")
    results = engine._semantic_idx.search("android security", top_k=3)
    return CheckResult("semantic_index", CheckResult.PASS,
                        f"Built, docs={n_docs}, test search={len(results)} results")


def check_groq_api() -> CheckResult:
    key = os.environ.get("GROQ_API_KEY", "")
    if not key:
        return CheckResult("groq_api", CheckResult.WARN, "GROQ_API_KEY not set")
    try:
        from zeus_llm_router import get_router
        router = get_router()
        text   = router.call_groq("Reply with exactly: OK", fast=True, max_tokens=10)
        if "OK" in text.upper() or len(text) > 0:
            return CheckResult("groq_api", CheckResult.PASS, f"Groq responding (fast model)")
        return CheckResult("groq_api", CheckResult.WARN, f"Unexpected response: {text[:50]}")
    except Exception as e:
        return CheckResult("groq_api", CheckResult.FAIL, f"Groq API error: {e}")


def check_claude_api() -> CheckResult:
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return CheckResult("claude_api", CheckResult.WARN, "ANTHROPIC_API_KEY not set")
    try:
        from zeus_llm_router import get_router
        router = get_router()
        text   = router.call_claude("Reply with exactly: OK", max_tokens=10)
        if "OK" in text.upper() or len(text) > 0:
            return CheckResult("claude_api", CheckResult.PASS, "Claude responding")
        return CheckResult("claude_api", CheckResult.WARN, f"Unexpected: {text[:50]}")
    except Exception as e:
        return CheckResult("claude_api", CheckResult.FAIL, f"Claude API error: {e}")


def check_genome_manager() -> CheckResult:
    from genome_manager import get_genome_engine
    engine = get_genome_engine()
    stats  = engine.stats()
    if "error" in stats:
        return CheckResult("genome_manager", CheckResult.FAIL, stats["error"])
    total = stats.get("total_segments", 0)
    return CheckResult("genome_manager", CheckResult.PASS,
                        f"total={total}, avg_fitness={stats.get('avg_fitness',0):.3f}")


def check_mutator() -> CheckResult:
    from zeus_mutator import get_engine as get_mutator
    mutator = get_mutator()
    status  = mutator.status()
    if "error" in status:
        return CheckResult("mutator", CheckResult.FAIL, status["error"])
    return CheckResult("mutator", CheckResult.PASS,
                        f"pending={status.get('pending',0)}, done={status.get('done',0)}")


def check_search_engine() -> CheckResult:
    from zeus_search import get_engine as get_search
    engine  = get_search()
    results = engine.quick_search("android security", max_results=3)
    stats   = engine.stats()
    return CheckResult("search_engine", CheckResult.PASS,
                        f"quick search returned {len(results)} results, "
                        f"total_queries={stats.get('total_queries',0)}")


def check_learner_scheduler() -> CheckResult:
    from zeus_learner import get_learner_engine
    engine = get_learner_engine()
    stats  = engine.stats()
    sched  = "running" if stats["scheduler"] else "stopped"
    return CheckResult("learner_scheduler", CheckResult.PASS,
                        f"scheduler={sched}, total_learned={stats['total_learned']}, "
                        f"queue_pending={stats['queue_pending']}")


def check_executor() -> CheckResult:
    from zeus_executor import get_executor
    executor = get_executor()
    stats    = executor.stats()
    workers  = stats.get("workers_active", 0)
    running  = stats.get("running", False)
    if not running:
        return CheckResult("executor", CheckResult.WARN, "Executor not running")
    if workers < 1:
        return CheckResult("executor", CheckResult.WARN, f"No active workers (workers={workers})")
    return CheckResult("executor", CheckResult.PASS,
                        f"workers={workers}, total_done={stats.get('total_done',0)}, "
                        f"total_failed={stats.get('total_failed',0)}")


def check_sandbox() -> CheckResult:
    from zeus_sandbox import get_sandbox
    sb = get_sandbox()
    # Run a trivial safe Python snippet
    result = sb.run_python("x = 1 + 1; _result = x")
    if not result.success:
        return CheckResult("sandbox", CheckResult.FAIL, f"Python exec failed: {result.error}")
    return CheckResult("sandbox", CheckResult.PASS,
                        f"Python exec ok, safety_score={result.safety_score:.2f}")


def check_chat_engine() -> CheckResult:
    from zeus_chat import get_chat_engine
    engine = get_chat_engine()
    stats  = engine.stats()
    return CheckResult("chat_engine", CheckResult.PASS,
                        f"threshold={stats['confidence_threshold']}, "
                        f"total_calls={stats['total_calls']}")


def check_scheduler() -> CheckResult:
    from zeus_nightly_scheduler import get_scheduler
    sched = get_scheduler()
    stats = sched.stats()
    jobs  = len(sched._jobs)
    if not stats["running"]:
        return CheckResult("scheduler", CheckResult.WARN,
                            f"Scheduler not running ({jobs} jobs defined)")
    return CheckResult("scheduler", CheckResult.PASS,
                        f"running, {jobs} jobs, "
                        f"total_runs={stats['total_runs']}")


def check_identity_registry() -> CheckResult:
    from zeus_identity import get_registry
    reg   = get_registry()
    stats = reg.stats()
    return CheckResult("identity_registry", CheckResult.PASS,
                        f"modules={stats['total_modules']}, "
                        f"capabilities={stats['total_capabilities']}, "
                        f"uptime={stats['uptime_s']}s")


def check_blueprint_engine() -> CheckResult:
    from zeus_blueprints import get_blueprint_engine
    engine = get_blueprint_engine()
    stats  = engine.stats()
    if "error" in stats:
        return CheckResult("blueprint_engine", CheckResult.FAIL, stats["error"])
    return CheckResult("blueprint_engine", CheckResult.PASS,
                        f"total={stats.get('total_blueprints',0)}, "
                        f"avg_quality={stats.get('avg_quality',0):.3f}")


def check_disk_space() -> CheckResult:
    try:
        stat = os.statvfs(ZEUS_DIR)
        free_mb  = round(stat.f_bavail * stat.f_frsize / 1024 / 1024, 0)
        total_mb = round(stat.f_blocks * stat.f_frsize / 1024 / 1024, 0)
        pct_free = round(free_mb / max(total_mb, 1) * 100, 1)
        if free_mb < 100:
            return CheckResult("disk_space", CheckResult.FAIL,
                                f"Critical: only {free_mb}MB free ({pct_free}%)")
        if free_mb < 500:
            return CheckResult("disk_space", CheckResult.WARN,
                                f"Low: {free_mb}MB free ({pct_free}%)")
        return CheckResult("disk_space", CheckResult.PASS,
                            f"{free_mb}MB free / {total_mb}MB total ({pct_free}%)")
    except Exception as e:
        return CheckResult("disk_space", CheckResult.SKIP, f"statvfs failed: {e}")


def check_memory() -> CheckResult:
    try:
        if os.path.exists("/proc/meminfo"):
            raw   = open("/proc/meminfo").read()
            total = re.search(r"MemTotal:\s+(\d+)", raw)
            avail = re.search(r"MemAvailable:\s+(\d+)", raw)
            if total and avail:
                t_mb = int(total.group(1)) // 1024
                a_mb = int(avail.group(1)) // 1024
                pct  = round(a_mb / max(t_mb, 1) * 100, 1)
                if a_mb < 100:
                    return CheckResult("memory", CheckResult.WARN,
                                        f"Low: {a_mb}MB available ({pct}%)")
                return CheckResult("memory", CheckResult.PASS,
                                    f"{a_mb}MB available / {t_mb}MB total ({pct}%)")
    except Exception:
        pass
    return CheckResult("memory", CheckResult.SKIP, "Cannot read /proc/meminfo")


import re


def check_python_version() -> CheckResult:
    ver = sys.version_info
    if ver < (3, 8):
        return CheckResult("python_version", CheckResult.FAIL,
                            f"Python {ver.major}.{ver.minor} — need 3.8+")
    return CheckResult("python_version", CheckResult.PASS,
                        f"Python {ver.major}.{ver.minor}.{ver.micro}")


def check_required_packages() -> CheckResult:
    required = ["flask", "groq", "anthropic"]
    optional = ["apscheduler", "ddgs", "androguard"]
    missing_req = []
    missing_opt = []
    for pkg in required:
        try:
            importlib.import_module(pkg)
        except ImportError:
            missing_req.append(pkg)
    for pkg in optional:
        try:
            importlib.import_module(pkg)
        except ImportError:
            missing_opt.append(pkg)
    if missing_req:
        return CheckResult("packages", CheckResult.FAIL,
                            f"Missing required: {missing_req}")
    if missing_opt:
        return CheckResult("packages", CheckResult.WARN,
                            f"Required OK. Missing optional: {missing_opt}")
    return CheckResult("packages", CheckResult.PASS,
                        "All required + optional packages installed")


# ============================================================================
# FULL SYSTEM CHECK
# ============================================================================

ALL_CHECKS = [
    ("zeus_dir",            check_zeus_dir),
    ("python_version",      check_python_version),
    ("required_packages",   check_required_packages),
    ("disk_space",          check_disk_space),
    ("memory",              check_memory),
    ("db_connectivity",     check_db_connectivity),
    ("db_wal_mode",         check_db_wal_mode),
    ("db_tables",           check_db_tables),
    ("db_counts",           check_db_counts),
    ("logic_engine",        check_logic_engine),
    ("semantic_index",      check_logic_engine_semantic_index),
    ("genome_manager",      check_genome_manager),
    ("mutator",             check_mutator),
    ("search_engine",       check_search_engine),
    ("learner_scheduler",   check_learner_scheduler),
    ("executor",            check_executor),
    ("sandbox",             check_sandbox),
    ("chat_engine",         check_chat_engine),
    ("scheduler",           check_scheduler),
    ("identity_registry",   check_identity_registry),
    ("blueprint_engine",    check_blueprint_engine),
    ("groq_api",            check_groq_api),
    ("claude_api",          check_claude_api),
]


def run_full_check(verbose: bool = True, skip: List[str] = None) -> Dict:
    """
    Run all system checks. Returns a full report dict.
    skip: list of check names to skip
    """
    skip    = skip or []
    results = []
    t0      = time.time()

    pass_count = fail_count = warn_count = skip_count = 0

    for name, fn in ALL_CHECKS:
        if name in skip:
            r = CheckResult(name, CheckResult.SKIP, "Skipped by caller")
            skip_count += 1
        else:
            r = _run_check(name, fn)
            if r.status == CheckResult.PASS: pass_count += 1
            elif r.status == CheckResult.FAIL: fail_count += 1
            elif r.status == CheckResult.WARN: warn_count += 1
            else: skip_count += 1

        results.append(r)
        if verbose:
            print(str(r))

    duration_s = round(time.time() - t0, 2)
    summary = {
        "total":    len(results),
        "pass":     pass_count,
        "fail":     fail_count,
        "warn":     warn_count,
        "skip":     skip_count,
        "duration_s": duration_s,
        "overall":  "PASS" if fail_count == 0 else "FAIL",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    report = {
        "summary": summary,
        "checks":  [r.to_dict() for r in results],
        "failed":  [r.to_dict() for r in results if r.status == CheckResult.FAIL],
        "warned":  [r.to_dict() for r in results if r.status == CheckResult.WARN],
    }

    if verbose:
        print(f"\n{'='*60}")
        print(f"  Zeus Full System Check — {summary['overall']}")
        print(f"  Pass={pass_count}  Fail={fail_count}  Warn={warn_count}  Skip={skip_count}")
        print(f"  Duration: {duration_s}s")
        print(f"{'='*60}")
        if fail_count > 0:
            print("\n  FAILURES:")
            for r in results:
                if r.status == CheckResult.FAIL:
                    print(f"    ✗ {r.name}: {r.message}")
        print("\n# The Zeus Project 2026 — Francois Nel\n")

    return report


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.WARNING,
        format="[%(asctime)s] %(levelname)s %(name)s — %(message)s"
    )
    import argparse
    parser = argparse.ArgumentParser(description="Zeus Full System Check")
    parser.add_argument("--skip",  nargs="*", default=[], help="Check names to skip")
    parser.add_argument("--json",  action="store_true", help="Output JSON report")
    parser.add_argument("--quiet", action="store_true", help="Suppress per-check output")
    args = parser.parse_args()

    report = run_full_check(verbose=not args.quiet, skip=args.skip)

    if args.json:
        print(json.dumps(report, indent=2, default=str))

    sys.exit(0 if report["summary"]["overall"] == "PASS" else 1)
