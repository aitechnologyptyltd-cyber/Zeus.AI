#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
# The Zeus Project 2026 — Francois Nel
# start_all.sh — Zeus v8.0 Hive Mind Launcher
# Hisense Y82 Pro | armv7l | UserLand Ubuntu
# ══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║         THE ZEUS PROJECT 2026 — FRANCOIS NEL                ║"
echo "║         Zeus v8.0 Hive Mind — One Consciousness             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# ── Load .env if present ──────────────────────────────────────────────────────
if [ -f "$ENV_FILE" ]; then
    echo "[*] Loading API keys from .env..."
    set -a; source "$ENV_FILE"; set +a
    echo "[✓] API keys loaded"
else
    echo "[!] No .env file found — create one with your API keys:"
    echo "    echo 'GROQ_API_KEY=your-key' >> $SCRIPT_DIR/.env"
    echo "    echo 'ANTHROPIC_API_KEY=your-key' >> $SCRIPT_DIR/.env"
fi

# ── Kill any existing instances ───────────────────────────────────────────────
echo "[*] Stopping any existing instances..."
pkill -f "wsgi_zeus:app"      2>/dev/null || true
pkill -f "wsgi:app"           2>/dev/null || true
pkill -f "gunicorn_zeus"      2>/dev/null || true
pkill -f "gunicorn_config"    2>/dev/null || true
sleep 2

# ── Create required directories ───────────────────────────────────────────────
mkdir -p "$SCRIPT_DIR/logs"
mkdir -p "$SCRIPT_DIR/static"
mkdir -p "$SCRIPT_DIR/uploads"

# ── Install quick deps ────────────────────────────────────────────────────────
echo "[*] Checking core Python dependencies..."
python3 -m pip install flask gunicorn requests apscheduler cryptography \
    python-multipart duckduckgo-search \
    --break-system-packages -q 2>/dev/null || true

# ── Start Zeus Architecture (port 8080) ──────────────────────────────────────
echo "[*] Starting Zeus v8.0 on port 8080..."
cd "$SCRIPT_DIR"

nohup gunicorn \
    --workers 1 \
    --bind 0.0.0.0:8080 \
    --timeout 120 \
    --keep-alive 5 \
    --pid /tmp/zeus_arch.pid \
    --access-logfile "$SCRIPT_DIR/logs/zeus_access.log" \
    --error-logfile  "$SCRIPT_DIR/logs/zeus_error.log" \
    wsgi_zeus:app \
    > "$SCRIPT_DIR/logs/zeus_startup.log" 2>&1 &

ZEUS_PID=$!
sleep 4

# Verify Zeus started
if curl -sf http://localhost:8080/ > /dev/null 2>&1; then
    echo "[✓] Zeus v8.0 online (PID $ZEUS_PID)"
else
    echo "[!] Zeus startup may still be loading — check logs/zeus_startup.log"
fi

# ── Start UMP (port 5000) ─────────────────────────────────────────────────────
# REMOVED — UMP Universal Miner/Trader has been removed from this build.
# Zeus GovInt (AEGIS-FIELD + GeoIntel) replaces it and runs INSIDE the main
# Zeus process above as a Flask blueprint — no separate port/process needed.
# Dashboard: http://localhost:8080/govint/dashboard

# ── Print dashboard URLs ──────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  ZEUS v8.0 HIVE MIND — ONLINE"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  ★  MASTER DASHBOARD  →  http://localhost:8080/master"
echo ""
echo "─────────────────────────────────────────────────────────────"
echo "  Zeus Core API        →  http://localhost:8080"
echo "  Zeus Health          →  http://localhost:8080/api/health"
echo "  Zeus Chat API        →  http://localhost:8080/api/chat"
echo "  Zeus Learning        →  http://localhost:8080/api/learner/stats"
echo "  Zeus Evolution       →  http://localhost:8080/api/evolution/status"
echo "  Zeus Genome          →  http://localhost:8080/api/genome/manager/stats"
echo "  Zeus Sovereignty     →  http://localhost:8080/api/sovereignty/status"
echo "  Zeus Tartarus        →  http://localhost:8080/api/tartarus/stats"
echo "  Zeus Code Intel      →  http://localhost:8080/api/code_learner/intelligence"
echo "  Improvement Loop     →  http://localhost:8080/api/improvement/loop_diagram"
echo "─────────────────────────────────────────────────────────────"
echo "  GovInt Dashboard     →  http://localhost:8080/govint/dashboard"
echo "  GovInt Stats         →  http://localhost:8080/govint/api/stats"
echo "  GovInt AEGIS Status  →  http://localhost:8080/govint/api/aegis/status"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  Log files:"
echo "    Zeus  : $SCRIPT_DIR/logs/zeus_error.log"
echo ""
echo "  To stop: bash stop_all.sh"
echo ""
