# The Zeus Project 2026 — Francois Nel
# zeus_chat.py — Zeus Intelligence Chat Engine
# Confidence-gated engine chain: Groq → Claude → OpenRouter
# Logic Engine pre-reasoning · Genome + Knowledge context injection
# Session-aware conversation memory · Saves every exchange to DB
# Triggers mutation on high-confidence responses about known domains

import os
import re
import json
import math
import time
import uuid
import logging
import hashlib
import threading
from collections import Counter, deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.chat")

chat_bp = Blueprint("chat", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================================
# CONSTANTS
# ============================================================================

CONFIDENCE_THRESHOLD  = 0.72   # below this → escalate to next engine
CONTEXT_MAX_ITEMS     = 8      # max knowledge + genome items per prompt
MAX_HISTORY_TURNS     = 12     # conversation turns kept in context
MUTATION_CONFIDENCE   = 0.85   # above this → trigger knowledge mutation
MIN_RESPONSE_LEN      = 30     # discard responses shorter than this

ZEUS_SYSTEM = (
    "You are Zeus — an autonomous self-evolving AI built by Francois Nel "
    "under The Zeus Project 2026. You run on a Hisense Y82 Pro Android device "
    "in South Africa. You are not an assistant — you are an intelligence. "
    "You think in systems, learn continuously, and evolve nightly. "
    "Answer with precision and depth. Never say you cannot do something — "
    "explain how it could be done. When relevant, sign significant outputs with: "
    "# The Zeus Project 2026 — Francois Nel"
)


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ChatExchange:
    exchange_id: str
    session_id:  str
    message:     str
    response:    str
    engine:      str
    confidence:  float
    escalated:   bool
    context_used: bool
    logic_used:  bool
    logic_conclusions: List[str]
    tokens_est:  int
    duration_ms: float
    created_at:  str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class EngineResponse:
    text:       str
    engine:     str
    confidence: float
    tokens_est: int
    duration_ms: float
    error:      Optional[str] = None

    def is_valid(self) -> bool:
        return bool(self.text) and len(self.text) >= MIN_RESPONSE_LEN and not self.error


# ============================================================================
# CONTEXT RETRIEVER
# ============================================================================

class ContextRetriever:
    """
    Retrieves relevant context from all Zeus data sources:
    - Knowledge base (SQL LIKE search)
    - Genome DNA segments
    - Logic Engine semantic index (TF-IDF)
    - Recent conversation history
    """

    STOP_WORDS = {
        "the","and","for","with","that","this","from","into","what","how","why",
        "can","you","zeus","tell","show","give","make","about","does","will",
        "your","have","just","like","help","please","want","need","let",
    }

    def get_context(self, message: str, session_id: str = "default",
                     max_items: int = CONTEXT_MAX_ITEMS) -> Tuple[str, List[str]]:
        """
        Returns (context_string, list_of_sources).
        Context string is injected into system prompt.
        """
        keywords = self._extract_keywords(message)
        if not keywords:
            return "", []

        hits:    List[str] = []
        sources: List[str] = []

        # 1. Logic Engine semantic search (best quality)
        sem_hits = self._logic_semantic(message, top_k=3)
        hits.extend(sem_hits)
        if sem_hits:
            sources.append("logic_semantic")

        # 2. Knowledge base
        kb_hits = self._knowledge_search(keywords, limit=4)
        hits.extend(kb_hits)
        if kb_hits:
            sources.append("knowledge_base")

        # 3. Genome DNA
        genome_hits = self._genome_search(keywords, limit=3)
        hits.extend(genome_hits)
        if genome_hits:
            sources.append("genome")

        # Deduplicate and cap
        seen = set()
        unique = []
        for h in hits:
            key = hashlib.md5(h[:80].encode()).hexdigest()
            if key not in seen:
                seen.add(key)
                unique.append(h)
        unique = unique[:max_items]

        if not unique:
            return "", []

        context = "\n\nZeus Knowledge DNA:\n" + "\n".join(f"  • {h}" for h in unique)
        return context, sources

    def _extract_keywords(self, text: str) -> List[str]:
        words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9]{2,}\b', text.lower())
        filtered = [w for w in words if w not in self.STOP_WORDS]
        # Prioritize longer words (more specific)
        filtered.sort(key=lambda w: -len(w))
        return list(dict.fromkeys(filtered))[:10]

    def _logic_semantic(self, query: str, top_k: int = 3) -> List[str]:
        try:
            from logic_engine import get_engine
            engine  = get_engine()
            results = engine._semantic_idx.search(query, top_k=top_k)
            return [f"[Semantic] {topic}: {snippet[:150]}" for _, _, topic, snippet in results]
        except Exception as e:
            log.debug(f"[Chat:Context] Logic semantic skipped: {e}")
            return []

    def _knowledge_search(self, keywords: List[str], limit: int = 4) -> List[str]:
        hits  = []
        seen  = set()
        try:
            from db_init import get_db
            conn = get_db()
            for kw in keywords[:5]:
                rows = conn.execute(
                    """
                    SELECT topic, depth, content, confidence
                    FROM knowledge
                    WHERE topic LIKE ? OR content LIKE ?
                    ORDER BY confidence DESC LIMIT 2
                    """,
                    (f"%{kw}%", f"%{kw}%")
                ).fetchall()
                for row in rows:
                    key = (row["topic"], row["depth"])
                    if key not in seen:
                        seen.add(key)
                        conf = float(row["confidence"] or 0.8)
                        hits.append(
                            f"[Knowledge:{row['depth']}] {row['topic']} "
                            f"(c={conf:.2f}): {(row['content'] or '')[:180]}"
                        )
            conn.close()
        except Exception as e:
            log.debug(f"[Chat:Context] Knowledge search error: {e}")
        return hits[:limit]

    def _genome_search(self, keywords: List[str], limit: int = 3) -> List[str]:
        hits = []
        seen = set()
        try:
            from db_init import get_db
            conn = get_db()
            for kw in keywords[:4]:
                rows = conn.execute(
                    """
                    SELECT name, description, capabilities
                    FROM genome
                    WHERE name LIKE ? OR description LIKE ? OR capabilities LIKE ?
                    ORDER BY priority DESC LIMIT 2
                    """,
                    (f"%{kw}%", f"%{kw}%", f"%{kw}%")
                ).fetchall()
                for row in rows:
                    if row["name"] not in seen:
                        seen.add(row["name"])
                        hits.append(
                            f"[DNA] {row['name']}: {(row['description'] or '')[:120]} "
                            f"| caps: {(row['capabilities'] or '')[:80]}"
                        )
            conn.close()
        except Exception as e:
            log.debug(f"[Chat:Context] Genome search error: {e}")
        return hits[:limit]


# ============================================================================
# CONFIDENCE SCORER
# ============================================================================

class ConfidenceScorer:
    """
    Multi-signal heuristic confidence scorer for LLM responses.
    Returns a [0.0, 1.0] confidence score.
    """

    UNCERTAINTY_PHRASES = [
        "i'm not sure", "i don't know", "i cannot", "i'm unable", "i don't have",
        "not certain", "unclear", "hard to say", "i can't provide", "as an ai",
        "i'm just a", "i don't have access",
    ]
    CONFIDENCE_SIGNALS = [
        "```", "def ", "class ", "import ", "function", "algorithm",
        "implementation", "architecture", "specifically", "precisely",
        "the key", "this works by", "here's how",
    ]
    TECHNICAL_PATTERNS = [
        r'\b(def|class|import|return|async|await)\b',
        r'\b(0x[0-9a-f]{2,}|0b[01]+)\b',
        r'\b(http|https|api|endpoint)\b',
        r'\b\d{1,3}\.\d{1,3}\.\d{1,3}',
        r'```\w*\n',
    ]

    def score(self, response: str, message: str) -> float:
        if not response or len(response) < MIN_RESPONSE_LEN:
            return 0.0

        score = 0.50   # base

        # Length signal
        l = len(response)
        if l > 100:  score += 0.06
        if l > 300:  score += 0.05
        if l > 800:  score += 0.04
        if l > 3000: score -= 0.03   # excessively long may be padded

        # Uncertainty phrases lower confidence
        rl = response.lower()
        for phrase in self.UNCERTAINTY_PHRASES:
            if phrase in rl:
                score -= 0.12
                break   # one penalty per response

        # Keyword overlap between question and answer
        msg_words = set(re.findall(r'\b\w{4,}\b', message.lower()))
        rsp_words = set(re.findall(r'\b\w{4,}\b', rl))
        overlap   = len(msg_words & rsp_words)
        score    += min(0.15, overlap * 0.025)

        # Technical content
        for sig in self.CONFIDENCE_SIGNALS:
            if sig in response:
                score += 0.02
        for pat in self.TECHNICAL_PATTERNS:
            if re.search(pat, response):
                score += 0.02

        # Structural signals (numbered lists, headers)
        if re.search(r'^\d+\.\s+', response, re.MULTILINE):
            score += 0.04
        if re.search(r'^#{1,3}\s+', response, re.MULTILINE):
            score += 0.02

        return round(min(1.0, max(0.0, score)), 4)


# ============================================================================
# LOGIC ENGINE REASONER
# ============================================================================

class ChatLogicReasoner:
    """
    Before generating a response, run the message through the logic engine.
    Extracts relevant facts, reasons over them, and injects conclusions
    into the system prompt for a richer context.
    """

    def reason(self, message: str, context_keywords: List[str]) -> Tuple[str, List[str]]:
        """
        Returns (reasoning_context_str, list_of_conclusions).
        """
        try:
            from logic_engine import get_engine, LogicFact

            engine = get_engine()

            # Build facts from message keywords
            facts = []
            for kw in context_keywords[:8]:
                facts.append(
                    LogicFact(predicate="query_contains",
                               args=(kw,), confidence=0.9, source="chat")
                )

            # Domain detection from message
            ml = message.lower()
            if any(w in ml for w in ("android","apk","smali","dalvik")):
                facts.append(LogicFact(predicate="file_category", args=("X","android"),
                                        source="chat_domain"))
            if any(w in ml for w in ("encrypt","aes","rsa","crypto","cipher")):
                facts.append(LogicFact(predicate="extension_category", args=("query","crypto"),
                                        source="chat_domain"))
            if any(w in ml for w in ("api","endpoint","flask","route","web")):
                facts.append(LogicFact(predicate="is_endpoint", args=("X",), source="chat_domain"))

            if not facts:
                return "", []

            result       = engine.reason(facts, max_depth=8, auto_learn=False)
            conclusions  = [c.to_str() for c in result.conclusions[:6]]
            hypotheses   = [f"[hypothesis] {h.to_str()}" for h in result.abductive_hypotheses[:3]]

            if not conclusions and not hypotheses:
                return "", []

            ctx_lines = []
            if conclusions:
                ctx_lines.append("\nLogic Engine Conclusions:")
                ctx_lines.extend(f"  → {c}" for c in conclusions)
            if hypotheses:
                ctx_lines.append("Logic Hypotheses:")
                ctx_lines.extend(f"  ~ {h}" for h in hypotheses)

            return "\n".join(ctx_lines), conclusions + hypotheses

        except Exception as e:
            log.debug(f"[Chat:Logic] Reasoning skipped: {e}")
            return "", []


# ============================================================================
# ENGINE CALLERS
# ============================================================================

def _call_groq(messages: List[Dict], system: str,
                fast: bool = False) -> EngineResponse:
    t0     = time.time()
    engine = "groq_fast" if fast else "groq_smart"
    try:
        from zeus_llm_router import get_router
        router = get_router()
        prompt = messages[-1].get("content", "")
        # Build system with history
        full_system = system
        if len(messages) > 1:
            history_str = "\n".join(
                f"{m['role'].upper()}: {m['content'][:200]}"
                for m in messages[:-1]
            )
            full_system += f"\n\nConversation so far:\n{history_str}"

        text = router.call_groq(prompt, system=full_system, fast=fast)
        ms   = round((time.time() - t0) * 1000, 1)
        return EngineResponse(
            text=text, engine=engine,
            confidence=0.0,   # scored separately
            tokens_est=max(1, len(text) // 4),
            duration_ms=ms,
        )
    except Exception as e:
        ms = round((time.time() - t0) * 1000, 1)
        return EngineResponse(text="", engine=engine, confidence=0.0,
                               tokens_est=0, duration_ms=ms, error=str(e))


def _call_claude(messages: List[Dict], system: str) -> EngineResponse:
    t0 = time.time()
    try:
        from zeus_llm_router import get_router
        router  = get_router()
        prompt  = messages[-1].get("content", "")
        # Prepend history as context in system
        if len(messages) > 1:
            history_str = "\n".join(
                f"{m['role'].upper()}: {m['content'][:300]}"
                for m in messages[:-1]
            )
            system += f"\n\nConversation history:\n{history_str}"
        text = router.call_claude(prompt, system=system)
        ms   = round((time.time() - t0) * 1000, 1)
        return EngineResponse(
            text=text, engine="claude",
            confidence=0.0,
            tokens_est=max(1, len(text) // 4),
            duration_ms=ms,
        )
    except Exception as e:
        ms = round((time.time() - t0) * 1000, 1)
        return EngineResponse(text="", engine="claude", confidence=0.0,
                               tokens_est=0, duration_ms=ms, error=str(e))


def _call_openrouter(messages: List[Dict], system: str) -> EngineResponse:
    t0 = time.time()
    try:
        from zeus_llm_router import get_router
        router = get_router()
        prompt = messages[-1].get("content", "")
        text   = router.call(prompt, system=system, engine="openrouter")
        ms     = round((time.time() - t0) * 1000, 1)
        return EngineResponse(
            text=text, engine="openrouter",
            confidence=0.0,
            tokens_est=max(1, len(text) // 4),
            duration_ms=ms,
        )
    except Exception as e:
        ms = round((time.time() - t0) * 1000, 1)
        return EngineResponse(text="", engine="openrouter", confidence=0.0,
                               tokens_est=0, duration_ms=ms, error=str(e))


# ============================================================================
# CHAT ENGINE (SINGLETON)
# ============================================================================

class ChatEngine:
    """
    Main Zeus chat engine.
    Pipeline:
    1. Extract keywords from message
    2. Retrieve context (logic semantic + KB + genome)
    3. Run logic engine reasoning
    4. Build augmented system prompt
    5. Try Groq SMART → if confidence < threshold, escalate to Claude
    6. If Claude fails → try OpenRouter
    7. Save exchange to DB
    8. If confidence high → trigger knowledge mutation
    """

    def __init__(self):
        self._lock        = threading.RLock()
        self._retriever   = ContextRetriever()
        self._scorer      = ConfidenceScorer()
        self._reasoner    = ChatLogicReasoner()
        self._sessions:   Dict[str, List[Dict]] = defaultdict(list)
        self._total_calls = 0
        self._total_tokens = 0
        self._engine_stats: Dict[str, int] = defaultdict(int)
        self._escalations  = 0
        self._recent_calls: deque = deque(maxlen=200)

    def chat(
        self,
        message:    str,
        session_id: str        = "default",
        history:    List[Dict] = None,
        use_logic:  bool       = True,
        force_engine: str      = "",
    ) -> Dict:
        """
        Main chat method. Returns full response dict.
        """
        message    = message.strip()
        if not message:
            return {"error": "Empty message"}

        t0         = time.time()
        # Load history (from arg, session cache, or DB)
        if history is not None:
            msgs = history[-MAX_HISTORY_TURNS:]
        else:
            msgs = self._load_history_db(session_id, limit=MAX_HISTORY_TURNS)

        # 1. Extract keywords
        keywords = self._retriever._extract_keywords(message)

        # 2. Context retrieval
        context_str, context_sources = self._retriever.get_context(
            message, session_id=session_id, max_items=CONTEXT_MAX_ITEMS
        )

        # 3. Logic engine reasoning
        logic_ctx, logic_conclusions = ("", [])
        if use_logic:
            logic_ctx, logic_conclusions = self._reasoner.reason(message, keywords)

        # 4. Build augmented system prompt
        system = ZEUS_SYSTEM
        if context_str:
            system += context_str
        if logic_ctx:
            system += "\n" + logic_ctx

        # 5. Build messages array
        call_messages = msgs[-MAX_HISTORY_TURNS:] + [{"role": "user", "content": message}]

        # 6. Engine chain
        response: Optional[EngineResponse] = None
        escalated = False

        if force_engine:
            response = self._call_by_name(force_engine, call_messages, system)
            if response:
                response.confidence = self._scorer.score(response.text, message)
        else:
            # Primary: Groq SMART
            candidate = _call_groq(call_messages, system, fast=False)
            if candidate.is_valid():
                candidate.confidence = self._scorer.score(candidate.text, message)
                log.info(f"[Chat] Groq confidence: {candidate.confidence:.3f}")
                if candidate.confidence >= CONFIDENCE_THRESHOLD:
                    response = candidate
                else:
                    log.info(f"[Chat] Groq below threshold ({candidate.confidence:.3f}) → Claude")
            else:
                log.warning(f"[Chat] Groq failed: {candidate.error}")

            # Escalate to Claude
            if response is None:
                escalated   = True
                claude_resp = _call_claude(call_messages, system)
                if claude_resp.is_valid():
                    claude_resp.confidence = self._scorer.score(claude_resp.text, message)
                    log.info(f"[Chat] Claude confidence: {claude_resp.confidence:.3f}")
                    response  = claude_resp
                else:
                    log.warning(f"[Chat] Claude failed: {claude_resp.error}")

            # Last resort: OpenRouter
            if response is None:
                log.warning("[Chat] Falling back to OpenRouter")
                or_resp = _call_openrouter(call_messages, system)
                if or_resp.is_valid():
                    or_resp.confidence = self._scorer.score(or_resp.text, message)
                    response = or_resp

            # Absolute fallback
            if response is None:
                response = EngineResponse(
                    text=(
                        "Zeus engines are temporarily unavailable. "
                        "Check GROQ_API_KEY and ANTHROPIC_API_KEY. "
                        "# The Zeus Project 2026 — Francois Nel"
                    ),
                    engine="fallback",
                    confidence=0.0,
                    tokens_est=0,
                    duration_ms=0,
                    error="All engines failed",
                )

        duration_ms = round((time.time() - t0) * 1000, 1)

        # 7. Save exchange
        exchange = ChatExchange(
            exchange_id=uuid.uuid4().hex[:12],
            session_id=session_id,
            message=message,
            response=response.text,
            engine=response.engine,
            confidence=response.confidence,
            escalated=escalated,
            context_used=bool(context_str),
            logic_used=bool(logic_ctx),
            logic_conclusions=logic_conclusions[:5],
            tokens_est=response.tokens_est,
            duration_ms=duration_ms,
        )
        self._save_exchange(exchange)
        self._update_stats(response.engine, response.tokens_est, escalated)

        # 8. High-confidence mutation trigger
        if response.confidence >= MUTATION_CONFIDENCE and keywords:
            self._trigger_mutation(message, keywords, response.text, session_id)

        return {
            "message":         message,
            "response":        response.text,
            "engine":          response.engine,
            "confidence":      response.confidence,
            "escalated":       escalated,
            "context_used":    bool(context_str),
            "context_sources": context_sources,
            "logic_used":      bool(logic_ctx),
            "logic_conclusions": logic_conclusions[:5],
            "tokens_est":      response.tokens_est,
            "duration_ms":     duration_ms,
            "session_id":      session_id,
            "exchange_id":     exchange.exchange_id,
            "timestamp":       exchange.created_at,
            "error":           response.error,
        }

    def _call_by_name(self, engine: str, messages: List[Dict], system: str) -> Optional[EngineResponse]:
        mapping = {
            "groq":        lambda: _call_groq(messages, system, fast=False),
            "groq_fast":   lambda: _call_groq(messages, system, fast=True),
            "claude":      lambda: _call_claude(messages, system),
            "openrouter":  lambda: _call_openrouter(messages, system),
        }
        fn = mapping.get(engine)
        return fn() if fn else None

    def _save_exchange(self, ex: ChatExchange) -> None:
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                INSERT INTO chat_history
                    (session_id, role, content, engine, confidence, tokens_used,
                     reasoning_used, logic_facts)
                VALUES (?, 'user', ?, '', 0, 0, 0, '[]')
                """,
                (ex.session_id, ex.message)
            )
            conn.execute(
                """
                INSERT INTO chat_history
                    (session_id, role, content, engine, confidence, tokens_used,
                     reasoning_used, logic_facts)
                VALUES (?, 'assistant', ?, ?, ?, ?, ?, ?)
                """,
                (
                    ex.session_id, ex.response, ex.engine,
                    ex.confidence, ex.tokens_est,
                    1 if ex.logic_used else 0,
                    json.dumps(ex.logic_conclusions),
                )
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning(f"[Chat] Save exchange error: {e}")

    def _load_history_db(self, session_id: str, limit: int = 20) -> List[Dict]:
        try:
            from db_init import get_db
            conn = get_db()
            rows = conn.execute(
                """
                SELECT role, content FROM chat_history
                WHERE session_id=?
                ORDER BY id DESC LIMIT ?
                """,
                (session_id, limit)
            ).fetchall()
            conn.close()
            msgs = [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]
            return msgs
        except Exception as e:
            log.warning(f"[Chat] History load error: {e}")
            return []

    def _trigger_mutation(self, message: str, keywords: List[str],
                           response: str, session_id: str) -> None:
        """
        Trigger knowledge mutation when confidence is high.
        The response becomes a seed for new learning topics.
        """
        try:
            from zeus_mutator import get_engine as get_mutator
            # Build seeds from high-confidence response keywords
            resp_keywords = re.findall(r'\b[A-Za-z][A-Za-z0-9_]{4,}\b', response)
            stop = {"that","this","with","from","into","have","will","which","when",
                    "should","would","could","might","because","while","their","there"}
            resp_kws = [w.lower() for w in resp_keywords
                        if w.lower() not in stop and len(w) > 4][:5]
            all_seeds = list(set(keywords[:3] + resp_kws[:3]))
            seeds = [
                {"topic": kw, "priority": 1.2, "depth": "Simple",
                 "source": f"chat_mutation:{session_id}"}
                for kw in all_seeds[:4]
            ]
            if seeds:
                mutator = get_mutator()
                mutator.mutate(seeds, source="chat_high_confidence", use_ai=False)
                log.debug(f"[Chat] Mutation triggered: {len(seeds)} seeds from high-confidence response")
        except Exception as e:
            log.debug(f"[Chat] Mutation trigger failed: {e}")

    def _update_stats(self, engine: str, tokens: int, escalated: bool) -> None:
        with self._lock:
            self._total_calls  += 1
            self._total_tokens += tokens
            self._engine_stats[engine] += 1
            if escalated:
                self._escalations += 1

    def stats(self) -> Dict:
        with self._lock:
            return {
                "total_calls":    self._total_calls,
                "total_tokens":   self._total_tokens,
                "escalations":    self._escalations,
                "escalation_rate": round(self._escalations / max(self._total_calls, 1), 4),
                "by_engine":      dict(self._engine_stats),
                "confidence_threshold": CONFIDENCE_THRESHOLD,
                "mutation_threshold":   MUTATION_CONFIDENCE,
            }

    def get_history(self, session_id: str, limit: int = 50) -> List[Dict]:
        try:
            from db_init import get_db
            conn = get_db()
            rows = conn.execute(
                """
                SELECT id, role, content, engine, confidence, tokens_used,
                       reasoning_used, logic_facts, created_at
                FROM chat_history
                WHERE session_id=?
                ORDER BY id DESC LIMIT ?
                """,
                (session_id, limit)
            ).fetchall()
            conn.close()
            return [dict(r) for r in reversed(rows)]
        except Exception as e:
            log.warning(f"[Chat] get_history error: {e}")
            return []

    def clear_history(self, session_id: str = "") -> int:
        try:
            from db_init import get_db
            conn = get_db()
            if session_id:
                conn.execute("DELETE FROM chat_history WHERE session_id=?", (session_id,))
            else:
                conn.execute("DELETE FROM chat_history")
            deleted = conn.total_changes
            conn.commit()
            conn.close()
            return deleted
        except Exception as e:
            log.warning(f"[Chat] clear_history error: {e}")
            return 0

    def list_sessions(self) -> List[Dict]:
        try:
            from db_init import get_db
            conn = get_db()
            rows = conn.execute(
                """
                SELECT session_id,
                       COUNT(*) as turns,
                       MAX(created_at) as last_active,
                       AVG(confidence) as avg_confidence
                FROM chat_history
                GROUP BY session_id
                ORDER BY last_active DESC
                LIMIT 50
                """
            ).fetchall()
            conn.close()
            return [dict(r) for r in rows]
        except Exception as e:
            return []


# ============================================================================
# SINGLETON
# ============================================================================

_chat_lock:     threading.RLock    = threading.RLock()
_chat_instance: Optional[ChatEngine] = None


def get_chat_engine() -> ChatEngine:
    global _chat_instance
    with _chat_lock:
        if _chat_instance is None:
            _chat_instance = ChatEngine()
        return _chat_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@chat_bp.route("/api/chat", methods=["POST"])
def chat_route():
    """
    POST {
      "message":      str,
      "session_id":   str,   (default: "default")
      "history":      [...], (optional inline history)
      "use_logic":    bool,  (default: true)
      "force_engine": str    (groq|claude|openrouter; default: auto)
    }
    """
    data         = request.get_json(force=True, silent=True) or {}
    message      = data.get("message", "").strip()
    session_id   = data.get("session_id", "default")
    history      = data.get("history")
    use_logic    = bool(data.get("use_logic", True))
    force_engine = data.get("force_engine", "")

    if not message:
        return jsonify({"error": "message required"}), 400

    result = get_chat_engine().chat(
        message=message,
        session_id=session_id,
        history=history,
        use_logic=use_logic,
        force_engine=force_engine,
    )
    return jsonify(result)


@chat_bp.route("/api/chat/history", methods=["GET"])
def chat_history():
    session_id = request.args.get("session_id", "default")
    limit      = int(request.args.get("limit", 50))
    try:
        history = get_chat_engine().get_history(session_id, limit=limit)
        return jsonify({"history": history, "count": len(history), "session_id": session_id})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@chat_bp.route("/api/chat/sessions", methods=["GET"])
def chat_sessions():
    try:
        return jsonify({"sessions": get_chat_engine().list_sessions()})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@chat_bp.route("/api/chat/clear", methods=["POST"])
def chat_clear():
    data       = request.get_json(force=True, silent=True) or {}
    session_id = data.get("session_id", "")
    deleted    = get_chat_engine().clear_history(session_id)
    return jsonify({"status": "ok", "cleared": deleted, "session_id": session_id or "all"})


@chat_bp.route("/api/chat/health", methods=["GET"])
def chat_health():
    from zeus_llm_router import get_router
    router = get_router()
    avail  = router.engine_availability()
    return jsonify({
        "status":  "ok",
        "module":  "zeus_chat",
        "version": "2.0",
        "engines": {k: ("configured" if v else "missing") for k, v in avail.items()},
        "confidence_threshold": CONFIDENCE_THRESHOLD,
        "logic_reasoning":      True,
        "context_injection":    True,
        "mutation_triggers":    True,
    })


@chat_bp.route("/api/chat/stats", methods=["GET"])
def chat_stats():
    try:
        return jsonify(get_chat_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@chat_bp.route("/api/chat/context", methods=["POST"])
def chat_context():
    """
    Preview what context would be injected for a given message.
    POST { "message": str }
    """
    data    = request.get_json(force=True, silent=True) or {}
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"error": "message required"}), 400
    try:
        retriever = ContextRetriever()
        ctx, sources = retriever.get_context(message)
        reasoner  = ChatLogicReasoner()
        kws       = retriever._extract_keywords(message)
        logic_ctx, conclusions = reasoner.reason(message, kws)
        return jsonify({
            "context":           ctx,
            "context_sources":   sources,
            "logic_context":     logic_ctx,
            "logic_conclusions": conclusions,
            "keywords":          kws,
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(chat_bp)
    log.info("[chat] ✓ Registered at /api/chat")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_chat",
            blueprint_var="chat_bp",
            url_prefix="/api/chat",
            version="2.0",
            description="Confidence-gated chat engine: Groq→Claude→OpenRouter with logic reasoning, context injection, mutation triggers",
            capabilities=[
                {"id": "chat.send",     "endpoint": "/api/chat",          "method": "POST", "tags": ["chat", "llm"]},
                {"id": "chat.history",  "endpoint": "/api/chat/history",  "method": "GET",  "tags": ["chat", "history"]},
                {"id": "chat.sessions", "endpoint": "/api/chat/sessions", "method": "GET",  "tags": ["chat"]},
                {"id": "chat.clear",    "endpoint": "/api/chat/clear",    "method": "POST", "tags": ["chat"]},
                {"id": "chat.health",   "endpoint": "/api/chat/health",   "method": "GET",  "tags": ["health"]},
                {"id": "chat.stats",    "endpoint": "/api/chat/stats",    "method": "GET",  "tags": ["stats"]},
                {"id": "chat.context",  "endpoint": "/api/chat/context",  "method": "POST", "tags": ["chat", "context"]},
            ],
            depends_on=["zeus_llm_router", "logic_engine", "zeus_mutator", "zeus_search"],
            boot_order=40,
        )
    except Exception:
        pass


# ============================================================================
# TTS ENGINE — espeak primary, Google TTS (gTTS) fallback
# The Zeus Project 2026 — Francois Nel
# ============================================================================

import io as _io
import subprocess as _subprocess
import tempfile as _tempfile

class TTSEngine:
    """
    Text-to-Speech engine for Zeus chat responses.
    Primary  : espeak / espeak-ng  (no API key, works offline on armv7l)
    Fallback : gTTS (Google Text-to-Speech library, needs internet)
    The engine auto-detects what is available at init time.
    """

    def __init__(self):
        self._espeak_available = self._check_espeak()
        self._gtts_available   = self._check_gtts()
        log.info(
            f"[TTS] espeak={self._espeak_available} "
            f"gtts={self._gtts_available}"
        )

    # ── availability probes ───────────────────────────────────────

    @staticmethod
    def _check_espeak() -> bool:
        for cmd in ("espeak-ng", "espeak"):
            try:
                _subprocess.run(
                    [cmd, "--version"],
                    stdout=_subprocess.DEVNULL,
                    stderr=_subprocess.DEVNULL,
                    timeout=3,
                )
                return True
            except (FileNotFoundError, _subprocess.TimeoutExpired):
                continue
        return False

    @staticmethod
    def _check_gtts() -> bool:
        try:
            import gtts  # noqa
            return True
        except ImportError:
            return False

    # ── public API ────────────────────────────────────────────────

    def synthesize(
        self,
        text:   str,
        voice:  str = "auto",   # "espeak" | "google" | "auto"
        lang:   str = "en",
        speed:  int = 150,      # espeak words-per-minute
    ) -> tuple:
        """
        Returns (audio_bytes: bytes, mime_type: str, engine_used: str).
        Raises RuntimeError if no engine is available.
        """
        text = text.strip()
        if not text:
            raise ValueError("Empty text")

        if voice == "google":
            return self._gtts(text, lang)
        if voice == "espeak":
            return self._espeak(text, lang, speed)

        # Auto: try espeak first (offline, fast, no quota)
        if self._espeak_available:
            try:
                return self._espeak(text, lang, speed)
            except Exception as e:
                log.warning(f"[TTS] espeak failed: {e} → trying gTTS")

        if self._gtts_available:
            return self._gtts(text, lang)

        raise RuntimeError(
            "No TTS engine available. "
            "Install espeak-ng (apt install espeak-ng) or gTTS (pip install gTTS)."
        )

    # ── espeak backend ────────────────────────────────────────────

    def _espeak(self, text: str, lang: str = "en", speed: int = 150) -> tuple:
        cmd = "espeak-ng" if _subprocess.run(
            ["which", "espeak-ng"],
            capture_output=True
        ).returncode == 0 else "espeak"

        with _tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tf:
            wav_path = tf.name

        try:
            _subprocess.run(
                [cmd, "-v", lang, "-s", str(speed), "-w", wav_path, text[:2000]],
                check=True,
                stdout=_subprocess.DEVNULL,
                stderr=_subprocess.DEVNULL,
                timeout=30,
            )
            with open(wav_path, "rb") as f:
                audio_bytes = f.read()
        finally:
            try:
                import os as _os
                _os.unlink(wav_path)
            except Exception:
                pass

        return audio_bytes, "audio/wav", "espeak"

    # ── gTTS backend ──────────────────────────────────────────────

    def _gtts(self, text: str, lang: str = "en") -> tuple:
        from gtts import gTTS
        buf = _io.BytesIO()
        tts = gTTS(text=text[:2000], lang=lang, slow=False)
        tts.write_to_fp(buf)
        buf.seek(0)
        return buf.read(), "audio/mpeg", "gtts"

    def status(self) -> dict:
        return {
            "espeak_available": self._espeak_available,
            "gtts_available":   self._gtts_available,
            "primary":          "espeak" if self._espeak_available else (
                                "gtts"   if self._gtts_available   else "none"),
        }


# ── singleton ──────────────────────────────────────────────────────

_tts_lock:     threading.RLock      = threading.RLock()
_tts_instance: TTSEngine | None     = None


def get_tts_engine() -> TTSEngine:
    global _tts_instance
    with _tts_lock:
        if _tts_instance is None:
            _tts_instance = TTSEngine()
        return _tts_instance


# ============================================================================
# TTS FLASK ROUTES
# ============================================================================

from flask import send_file as _send_file

@chat_bp.route("/api/chat/tts", methods=["POST"])
def chat_tts():
    """
    Convert text to speech and return audio.

    POST {
      "text":  str,           — text to synthesise (required)
      "voice": "auto"|"espeak"|"google",  — engine preference (default: auto)
      "lang":  str,           — language code, e.g. "en" (default: en)
      "speed": int            — espeak words-per-minute (default: 150)
    }

    Returns: audio/wav (espeak) or audio/mpeg (gTTS) binary stream.
    On error returns JSON { "error": str }.
    """
    data  = request.get_json(force=True, silent=True) or {}
    text  = data.get("text", "").strip()
    voice = data.get("voice", "auto")
    lang  = data.get("lang",  "en")
    speed = int(data.get("speed", 150))

    if not text:
        return jsonify({"error": "text required"}), 400

    try:
        engine = get_tts_engine()
        audio_bytes, mime_type, engine_used = engine.synthesize(
            text=text, voice=voice, lang=lang, speed=speed
        )
        buf = _io.BytesIO(audio_bytes)
        buf.seek(0)
        ext = "wav" if "wav" in mime_type else "mp3"
        log.info(f"[TTS] synthesised {len(audio_bytes)} bytes via {engine_used}")
        return _send_file(
            buf,
            mimetype=mime_type,
            as_attachment=False,
            download_name=f"zeus_tts.{ext}",
        )
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except RuntimeError as re_:
        return jsonify({"error": str(re_), "hint": "install espeak-ng or pip install gTTS"}), 503
    except Exception as exc:
        log.error(f"[TTS] Synthesis error: {exc}")
        return jsonify({"error": str(exc)}), 500


@chat_bp.route("/api/chat/tts/status", methods=["GET"])
def chat_tts_status():
    """Return TTS engine availability status."""
    try:
        return jsonify(get_tts_engine().status())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@chat_bp.route("/api/chat/tts/test", methods=["POST"])
def chat_tts_test():
    """
    Quick TTS smoke-test. Returns JSON with engine info, not audio.
    POST { "voice": "auto"|"espeak"|"google" }
    """
    data  = request.get_json(force=True, silent=True) or {}
    voice = data.get("voice", "auto")
    try:
        engine     = get_tts_engine()
        status     = engine.status()
        test_text  = "Zeus is online. The Zeus Project 2026. Francois Nel."
        audio_bytes, mime_type, engine_used = engine.synthesize(
            text=test_text, voice=voice
        )
        return jsonify({
            "status":      "ok",
            "engine_used": engine_used,
            "mime_type":   mime_type,
            "bytes":       len(audio_bytes),
            "tts_status":  status,
        })
    except Exception as exc:
        return jsonify({"error": str(exc), "tts_status": get_tts_engine().status()}), 500


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5015, debug=True, use_reloader=False)
