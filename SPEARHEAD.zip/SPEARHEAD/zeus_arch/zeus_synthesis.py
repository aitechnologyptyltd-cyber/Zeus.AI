import os
"""
zeus_synthesis.py - Zeus module: zeus_synthesis
Zeus Project 2026 - Francois Nel
"""
import uvicorn
from fastapi import FastAPI, File, UploadFile, Body
from fastapi.responses import JSONResponse
from typing import List, Dict, Any, Optional, Callable
import traceback
import re
import math
import io
import zipfile
import struct
import binascii
import xml.etree.ElementTree as ET

try:
    import yara
except ImportError:
    yara = None

try:
    from androguard.core.bytecodes.apk import APK
    from androguard.core.bytecodes.dvm import DalvikVMFormat
    from androguard.core.analysis.analysis import Analysis
except ImportError:
    APK = None
    DalvikVMFormat = None
    Analysis = None

try:
    import capstone
except ImportError:
    capstone = None

try:
    import pefile
except ImportError:
    pefile = None

app = FastAPI(
    title="Zeus Synthesis Engine v5.0",
    description="Autonomous tool synthesis engine with maximum-intelligence semantic intent parsing and robust technical tool generation.",
    version="5.0"
)

SUPPORTED_FORMATS = [
    "apk", "dex", "elf", "pe", "mach-o", "oat", "wasm", "so", "jar", "class",
    "deb", "rpm", "ipa", "appimage", "exe", "dll", "bin", "img", "iso", "csv", "json", "xml",
    "smali", "firmware"
]

SUPPORTED_TECH_KEYWORDS = [
    'reverse engineering', 'disassembler', 'static analysis', 'dynamic analysis', 'binary inspector', 'debugger',
    'decompiler', 'packer', 'obfuscation', 'malware analysis', 'threat hunting', 'unpacker', 'API explorer',
    'network sniffer', 'packet analyzer', 'file format explorer', 'hex editor', 'pipeline', 'automation',
    'fuzzing', 'vulnerability scanner', 'payload injector', 'sandbox', 'crypto analysis',
    'performance profiler', 'resource explorer', 'code similarity', 'clone detector', 'symbolic execution',
    'taint analysis', 'memory forensics', 'kernel analysis', 'bootloader analyzer', 'firmware analysis',
    'smali disassembler', 'bytecode viewer', 'firmware unpacker', 'apk analyzer', 'code audit'
]

SEMANTIC_TECH_TAXONOMY = {
    "reverse_engineering_tool": {
        "definition": "A tool for analyzing and reconstructing the internal representation of binary or executable software, often to recover design, discover vulnerabilities, or audit code.",
        "domains": ["binary analysis", "malware analysis", "firmware inspection", "embedded systems"],
        "inputs": ["apk", "pe", "elf", "dex", "firmware", "smali", "bin"],
        "actions": ["deconstruct", "extract", "inspect", "disassemble", "decompile", "analyze", "unpack"],
        "pipelines": [
            ["upload", "format_detect", "unpack", "disassemble", "decompile", "report"],
            ["upload", "manifest_parse", "dex_extraction", "disassemble", "cross_reference", "decompile", "analyze_strings", "summary"]
        ],
        "concepts": ["architecture recovery", "obfuscation handling", "unpacking", "cross-references", "static-dynamic synergy"]
    },
    "static_analysis_tool": {
        "definition": "A tool that inspects code or binary files without running them to find weaknesses, vulnerabilities, or gain structural knowledge.",
        "domains": ["static code scanning", "binary pattern matching", "inspection"],
        "inputs": ["apk", "dex", "pe", "elf", "jar", "firmware", "class"],
        "actions": ["scan", "pattern_match", "identify", "report"],
        "pipelines": [
            ["upload", "static_scan", "heuristic_match", "signature_analyze", "graph_model", "report"]
        ],
        "concepts": ["pattern matching", "heuristic checks", "metadata extraction"]
    },
    "dynamic_analysis_tool": {
        "definition": "A tool that observes, instruments, or manipulates software during execution to analyze runtime behavior and discover vulnerabilities.",
        "domains": ["runtime analysis", "fuzzing", "execution tracing"],
        "inputs": ["apk", "pe", "elf", "bin", "firmware"],
        "actions": ["instrument", "monitor", "execute", "fuzz", "profile"],
        "pipelines": [
            ["upload", "runtime_env", "dynamic_instrument", "data_flow_tracking", "crash_detect", "report"]
        ],
        "concepts": ["sandboxing", "process tracing", "input mutation", "feedback analysis", "behavioral triggers"]
    },
    "disassembler": {
        "definition": "A tool that decodes binaries into human-readable assembly instructions.",
        "domains": ["assembly analysis", "manual reversing"],
        "inputs": ["apk", "dex", "pe", "elf", "bin", "firmware"],
        "actions": ["disassemble", "decode", "instruction_map"],
        "pipelines": [
            ["upload", "format_detect", "disassembly", "section_analysis", "report"]
        ],
        "concepts": ["architecture recognition", "assembly navigation", "code/data separation"]
    },
    "decompiler": {
        "definition": "A tool that transforms binary code into high-level programming language representations.",
        "domains": ["source recovery", "deobfuscation", "malware reverse engineering"],
        "inputs": ["apk", "dex", "class", "jar", "pe", "elf"],
        "actions": ["decompile", "lift", "reconstruct", "refactor"],
        "pipelines": [
            ["upload", "format_detect", "decompilation", "refined_structure", "report"]
        ],
        "concepts": ["cfg recovery", "variable reconstruction", "semantic renaming"]
    },
    "debugger": {
        "definition": "A tool that interacts with live or snapshot software state to diagnose and control flow.",
        "domains": ["interactive debugging", "malware runtime analysis", "embedded debugging"],
        "inputs": ["apk", "pe", "elf", "bin", "firmware", "smali"],
        "actions": ["attach", "set_breakpoint", "step", "inspect", "trace"],
        "pipelines": [
            ["upload", "launch_debug_session", "breakpoint_handling", "memory_inspect", "report"]
        ],
        "concepts": ["symbol lookup", "register view", "tracepoint management"]
    },
    "fuzzer": {
        "definition": "A tool that generates and provides many mutated inputs to a target executable to trigger bugs.",
        "domains": ["protocol fuzzing", "binary fuzzing", "API robustness"],
        "inputs": ["bin", "apk", "elf", "pe"],
        "actions": ["mutate", "inject", "execute", "detect_crash"],
        "pipelines": [
            ["upload", "input_mutation", "automated_execution", "crash_detection", "minimize_case", "report"]
        ],
        "concepts": ["coverage maximization", "feedback loops", "crash triage"]
    },
    "hex_editor": {
        "definition": "A tool offering raw hexadecimal/binary byte-level inspection and editing of files.",
        "domains": ["manual file manipulation", "forensic analysis"],
        "inputs": SUPPORTED_FORMATS,
        "actions": ["view_hex", "patch", "annotate"],
        "pipelines": [
            ["upload", "hex_view", "patching", "save", "report"]
        ],
        "concepts": ["byte navigation", "structure overlay"]
    },
    "format_explorer": {
        "definition": "A tool to visualize, interpret, and interact with the structure of different file formats.",
        "domains": ["file structure", "binary parsing"],
        "inputs": SUPPORTED_FORMATS,
        "actions": ["parse_structure", "visualize", "navigate"],
        "pipelines": [
            ["upload", "format_identify", "structure_graph", "interactive_browse", "report"]
        ],
        "concepts": ["tree visualization", "format protocols", "header analysis"]
    }
}

SEMANTIC_FORMATS = {
    "apk": {"type": "android package", "family": "zip", "domain": "android", "signals": ["dex", "manifest", "resources"], "ontology_vector": [1,1,0,0,1,0,1,1]},
    "dex": {"type": "dalvik bytecode", "family": "bytecode", "domain": "android", "signals": ["class", "field", "code"], "ontology_vector": [1,0,1,0,1,0,0,1]},
    "smali": {"type": "smali assembly", "family": "bytecode", "domain": "android", "signals": ["class", "method"], "ontology_vector": [1,0,1,0,1,0,0,1]},
    "firmware": {"type": "firmware blob", "family": "binary", "domain": "embedded", "signals": ["section", "boot", "loader"], "ontology_vector": [1,0,0,1,0,1,0,1]},
    "pe": {"type": "windows exe/dll", "family": "pe/coff", "domain": "windows", "signals": ["section", "import", "export"], "ontology_vector": [0,1,1,1,0,1,1,0]},
    "elf": {"type": "linux binary", "family": "elf", "domain": "linux", "signals": ["section", "symbol"], "ontology_vector": [0,1,1,1,0,1,1,0]},
    "oat": {"type": "android oat", "family": "bytecode", "domain": "android", "signals": ["dex", "boot"], "ontology_vector": [1,0,1,0,1,0,0,1]},
    "class": {"type": "java bytecode", "family": "java", "domain": "jvm", "signals": ["method", "field"], "ontology_vector": [0,1,1,0,1,0,0,0]},
    "so": {"type": "shared object", "family": "elf", "domain": "unix", "signals": ["symbol", "dynamic"], "ontology_vector": [0,1,1,1,0,0,1,0]},
    "jar": {"type": "java archive", "family": "zip", "domain": "jvm", "signals": ["class", "manifest"], "ontology_vector": [0,1,1,0,1,0,0,0]},
    "deb": {"type": "debian package", "family": "archive", "domain": "debian", "signals": ["control", "data"], "ontology_vector": [0,0,0,0,1,0,0,0]},
    "rpm": {"type": "redhat package", "family": "archive", "domain": "redhat", "signals": ["header", "payload"], "ontology_vector": [0,0,0,0,1,0,0,0]},
    "wasm": {"type": "webassembly", "family": "bytecode", "domain": "wasm", "signals": ["section", "import", "export"], "ontology_vector": [0,1,1,1,0,0,1,0]},
    "ipa": {"type": "ios app", "family": "zip", "domain": "ios", "signals": ["plist", "binary"], "ontology_vector": [1,1,0,0,1,0,0,0]},
    "appimage": {"type": "linux appimage", "family": "elf", "domain": "linux", "signals": ["squashfs", "elf"], "ontology_vector": [0,1,1,1,0,1,0,0]},
    "bin": {"type": "binary blob", "family": "blob", "domain": "unknown", "signals": ["memory"], "ontology_vector": [1,0,0,1,0,0,0,1]},
    "img": {"type": "disk image", "family": "image", "domain": "os", "signals": ["block", "partition"], "ontology_vector": [1,0,0,0,1,0,0,1]},
    "iso": {"type": "optical disk image", "family": "image", "domain": "os", "signals": ["block", "partition"], "ontology_vector": [1,0,0,0,1,0,0,1]},
    "json": {"type": "json", "family": "structured", "domain": "data", "signals": [], "ontology_vector": [0,0,1,0,1,0,0,0]},
    "xml": {"type": "xml", "family": "structured", "domain": "data", "signals": [], "ontology_vector": [0,0,1,0,1,0,0,0]},
    "csv": {"type": "csv", "family": "structured", "domain": "data", "signals": [], "ontology_vector": [0,0,1,0,1,0,0,0]},
    "exe": {"type": "windows exe", "family": "pe/coff", "domain": "windows", "signals": ["section", "entry"], "ontology_vector": [0,1,1,1,0,1,1,0]},
    "dll": {"type": "windows dll", "family": "pe/coff", "domain": "windows", "signals": ["export", "entry"], "ontology_vector": [0,1,1,1,0,1,1,0]},
}

FORMAT_ALIAS_MAP = {f: f for f in SUPPORTED_FORMATS}
for k, v in SEMANTIC_FORMATS.items():
    FORMAT_ALIAS_MAP[k] = k
    FORMAT_ALIAS_MAP[v["type"]] = k
    FORMAT_ALIAS_MAP[v["family"]] = k
    FORMAT_ALIAS_MAP[v["domain"]] = k
    for s in v["signals"]:
        FORMAT_ALIAS_MAP[s] = k
FORMAT_ALIAS_MAP["windows exe"] = "pe"
FORMAT_ALIAS_MAP["windows executable"] = "pe"
FORMAT_ALIAS_MAP["linux binary"] = "elf"
FORMAT_ALIAS_MAP["android app"] = "apk"
FORMAT_ALIAS_MAP["dalvik"] = "dex"
FORMAT_ALIAS_MAP["firmware blob"] = "firmware"
FORMAT_ALIAS_MAP["java archive"] = "jar"
FORMAT_ALIAS_MAP["shared object"] = "so"

class SemanticVector:
    def __init__(self, tokens: List[str]):
        self.vec = {}
        for t in tokens:
            self.vec[t] = self.vec.get(t, 0) + 1
        self.norm = math.sqrt(sum(v*v for v in self.vec.values()))
    @staticmethod
    def from_text(txt: str):
        tokens = re.findall(r'\w+', txt.lower())
        return SemanticVector(tokens)
    def cosine(self, other: "SemanticVector"):
        dot = sum(self.vec.get(t,0) * other.vec.get(t,0) for t in set(self.vec)|set(other.vec))
        return dot / ((self.norm * other.norm) or 1)
    def jaccard(self, other: "SemanticVector"):
        s1 = set(self.vec)
        s2 = set(other.vec)
        return len(s1 & s2) / (len(s1 | s2) or 1)
    def tokens(self):
        return set(self.vec)
    def __contains__(self, word: str):
        return word in self.vec

class SemanticMemory:
    def __init__(self):
        self.tech_tax = SEMANTIC_TECH_TAXONOMY
        self.formats = SEMANTIC_FORMATS
        self.tech_words = [w for tool, meta in SEMANTIC_TECH_TAXONOMY.items() for w in set(meta['domains'] + meta['actions'] + meta['concepts'])]
        self.format_words = [w for k, meta in SEMANTIC_FORMATS.items() for w in ([k, meta["type"], meta["family"], meta["domain"]] + meta["signals"])]
        self.all_vectors = {k: SemanticVector.from_text(k) for k in self.tech_words + self.format_words}

    def concept_similarity(self, query: SemanticVector, label: str):
        label_vec = self.all_vectors[label] if label in self.all_vectors else SemanticVector.from_text(label)
        return query.cosine(label_vec)

    def infer_tech_type(self, query: SemanticVector, context_tokens: set) -> str:
        best = None
        best_score = 0
        for tool_kind, meta in self.tech_tax.items():
            bag = ' '.join(meta['domains']+meta['actions']+meta['concepts']+[meta['definition']]+meta['inputs']+[' '.join([x for seq in meta['pipelines'] for x in seq])])
            bag_vec = SemanticVector.from_text(bag)
            score = query.cosine(bag_vec)
            intersect = context_tokens & set(meta['inputs'])
            if intersect:
                score += 0.2 * len(intersect)
            if score > best_score:
                best_score = score
                best = tool_kind
        return best

    def expand_formats(self, query_tokens: set) -> List[str]:
        results = []
        for fmt, meta in self.formats.items():
            if fmt in query_tokens or meta["type"] in query_tokens or meta["family"] in query_tokens or meta["domain"] in query_tokens:
                results.append(fmt)
            elif set(meta["signals"]) & query_tokens:
                results.append(fmt)
        dedup = []
        for f in results:
            if f not in dedup:
                dedup.append(f)
        return dedup

    def format_ontology_vector(self, formats: List[str]) -> List[int]:
        if not formats:
            return [0]*8
        result = [0]*8
        for f in formats:
            if f in self.formats:
                vec = self.formats[f].get("ontology_vector", [0]*8)
                for i in range(len(result)):
                    result[i] |= vec[i]
        return result

    def best_match_format(self, query: SemanticVector):
        best = None
        best_score = 0
        for k, meta in self.formats.items():
            bag = ' '.join([k, meta["type"], meta["family"], meta["domain"]] + meta["signals"])
            bag_vec = SemanticVector.from_text(bag)
            score = query.cosine(bag_vec)
            if score > best_score:
                best_score = score
                best = k
        return best

    def tool_classes_contextualized(self, tool_kind: str, formats: List[str], tokens: set) -> Dict[str, List[str]]:
        meta = self.tech_tax.get(tool_kind)
        fmt_semantics = [self.formats.get(fmt, {}) for fmt in formats]
        domains = meta["domains"] if meta else []
        actions = meta["actions"] if meta else []
        pipeline_candidates = meta["pipelines"] if meta else []
        relevant_pipeline = []
        if pipeline_candidates:
            if formats:
                for p in pipeline_candidates:
                    for fmt in formats:
                        if fmt in p or any(fmt == x for x in p):
                            relevant_pipeline = p
                            break
            if not relevant_pipeline:
                relevant_pipeline = pipeline_candidates[0]
        else:
            relevant_pipeline = []
        if "interactive" in tokens:
            relevant_pipeline = list(relevant_pipeline) + ["interactive_browse"]
        if "timeline" in tokens:
            relevant_pipeline = list(relevant_pipeline) + ["timeline"]
        return {
            "domains": domains,
            "actions": actions,
            "pipeline": relevant_pipeline if relevant_pipeline else [],
            "arch_hints": formats + list(tokens & set(domains + actions))
        }

memory = SemanticMemory()

class SmartIntentParser:
    def __init__(self):
        self.memory = memory
    def to_semantic_vector(self, sent: str) -> SemanticVector:
        return SemanticVector.from_text(sent)
    def parse_tool_request(self, user_request: str) -> Dict[str, Any]:
        clean_sent = user_request.strip()
        sent = clean_sent.lower()
        semvec = self.to_semantic_vector(sent)
        query_tokens = semvec.tokens()
        fmt_candidates = set()
        for token in query_tokens:
            if token in FORMAT_ALIAS_MAP:
                fmt_candidates.add(FORMAT_ALIAS_MAP[token])
        for alias, canonical in FORMAT_ALIAS_MAP.items():
            if alias in sent and len(alias) > 2:
                fmt_candidates.add(canonical)
        formats = list(fmt_candidates)
        if not formats:
            best_fmt = self.memory.best_match_format(semvec)
            formats = [best_fmt] if best_fmt else []
        tool_kind = self.memory.infer_tech_type(semvec, set(formats))
        context_info = self.memory.tool_classes_contextualized(tool_kind, formats, query_tokens)
        domains = context_info["domains"]
        actions = context_info["actions"]
        pipeline = context_info["pipeline"]
        arch_hints = context_info["arch_hints"]
        ontology_vec = self.memory.format_ontology_vector(formats)
        tool_name = tool_kind.replace("_tool", "").replace("_", " ").title() if tool_kind else "Custom Tool"
        if "tool" not in tool_name.lower():
            tool_name += " Tool"
        return {
            "tool_kind": tool_kind,
            "tool_name": tool_name,
            "formats": formats,
            "domains": domains,
            "actions": actions,
            "concepts": SEMANTIC_TECH_TAXONOMY[tool_kind]["concepts"] if tool_kind in SEMANTIC_TECH_TAXONOMY else [],
            "arch_hints": arch_hints,
            "pipeline": pipeline,
            "ontology_vector": ontology_vec,
            "description": clean_sent
        }

def robust_error_response(detail: str, exc: Optional[Exception] = None, trace: bool = False):
    err = {"error": detail}
    if exc and trace:
        err["traceback"] = traceback.format_exc()
    return JSONResponse(status_code=400, content=err)

class ToolBase:
    def __init__(self, intent: Dict[str, Any]):
        self.intent = intent

    def build_pipeline(self) -> Dict[str, Any]:
        """
        Default pipeline builder used when no subclass overrides this method.
        Inspects the intent's format list and constructs a generic analysis
        pipeline appropriate for the detected format category.
        Subclasses should override for specialised behaviour.
        """
        fmt = self.intent.get("formats", ["file"])
        tool_type = self.intent.get("tool_type", "generic_analysis")
        # Map common format groups to sensible default pipelines
        if any(f in ["apk", "dex", "aar", "aab"] for f in fmt):
            pipeline = ["file_upload", "apk_parse", "manifest_parse",
                        "dex_extraction", "string_extraction", "security_report"]
        elif any(f in ["pe", "exe", "dll"] for f in fmt):
            pipeline = ["file_upload", "pe_parse", "import_export_analysis",
                        "threat_scan", "report"]
        elif any(f in ["elf", "so"] for f in fmt):
            pipeline = ["file_upload", "elf_parse", "symbol_scan",
                        "disassemble", "report"]
        elif any(f in ["wasm"] for f in fmt):
            pipeline = ["file_upload", "wasm_parse", "function_scan", "report"]
        elif any(f in ["firmware", "bin", "img"] for f in fmt):
            pipeline = ["file_upload", "magic_detect", "entropy_scan",
                        "string_extraction", "report"]
        else:
            pipeline = ["file_upload", "magic_detect", "structure_parse",
                        "string_extraction", "entropy_scan", "report"]
        return {
            "type":     tool_type,
            "formats":  fmt,
            "pipeline": pipeline,
        }

    def analyze(self, file: UploadFile) -> Dict[str, Any]:
        """
        Default file analyser used when no subclass overrides this method.
        Performs generic binary analysis: magic bytes, Shannon entropy,
        printable string extraction, and basic format detection.
        Subclasses override for deep format-specific analysis.
        """
        filename = file.filename if file and file.filename else "unknown"
        try:
            data = file.file.read()
        except Exception as exc:
            return {"filename": filename, "error": "Failed to read file: " + str(exc)}

        info = {"filename": filename, "size": len(data)}

        # Magic bytes identification
        magic_hex = binascii.hexlify(data[:8]).decode() if data else ""
        fmt_hint = "unknown"
        if data[:4] == b"\x7fELF":
            fmt_hint = "elf"
        elif data[:2] == b"MZ":
            fmt_hint = "pe"
        elif data[:4] in (b"PK\x03\x04", b"PK\x05\x06"):
            fmt_hint = "zip_apk"
        elif data[:8] == b"dex\n035\x00" or data[:4] == b"dex\n":
            fmt_hint = "dex"
        elif data[:4] == b"\x00asm":
            fmt_hint = "wasm"

        # Shannon entropy
        entropy = 0.0
        if data:
            occur = {}
            for byte in data:
                occur[byte] = occur.get(byte, 0) + 1
            for count in occur.values():
                p = count / len(data)
                if p > 0:
                    entropy -= p * math.log2(p)

        # Printable string extraction (min 8 chars)
        strings_found = re.findall(rb"[\x20-\x7E]{8,}", data)
        strings_sample = [s.decode(errors="ignore") for s in strings_found[:15]]

        # URL/IP extraction
        urls = re.findall(rb"https?://[a-zA-Z0-9.\-/?&%=_]+", data)
        url_sample = [u.decode(errors="ignore") for u in urls[:10]]

        findings = []
        if entropy > 7.5:
            findings.append("High entropy — likely packed, encrypted, or obfuscated.")
        elif entropy < 2.0 and len(data) > 512:
            findings.append("Very low entropy — likely plaintext or sparse binary.")
        if url_sample:
            findings.append("Embedded URLs detected: " + str(len(urls)))

        return {
            "info":           info,
            "format_hint":    fmt_hint,
            "magic_hex":      magic_hex,
            "shannon_entropy": round(entropy, 4),
            "strings_sample": strings_sample,
            "urls_found":     url_sample,
            "findings":       findings,
        }

class ReverseEngineeringTool(ToolBase):
    def build_pipeline(self):
        fmt = self.intent.get('formats', ['file'])
        if "apk" in fmt:
            return {
                "type": "reverse_engineering",
                "formats": fmt,
                "pipeline": [
                    "apk_upload", "apk_parse", "manifest_parse", "dex_extraction",
                    "native_lib_analyze", "obfuscation_detect", "string_extraction", "security_report"
                ]
            }
        elif any(f in ["pe", "exe", "dll"] for f in fmt):
            return {
                "type": "reverse_engineering",
                "formats": fmt,
                "pipeline": [
                    "pe_upload", "pe_parse", "section_parse", "import_export_analysis",
                    "disassemble", "threat_scan", "report"
                ]
            }
        elif "elf" in fmt:
            return {
                "type": "reverse_engineering",
                "formats": fmt,
                "pipeline": [
                    "elf_upload", "elf_parse", "section_parse", "symbol_scan", "disassemble",
                    "threat_scan", "report"
                ]
            }
        else:
            return {
                "type": "reverse_engineering",
                "formats": fmt,
                "pipeline": ["file_upload", "magic_detect", "structure_parse", "disassemble", "report"]
            }

    def analyze(self, file: UploadFile):
        filename = file.filename
        data = file.file.read()
        info = {"filename": filename, "size": len(data)}
        results = {}

        # --- APK
        if filename.endswith(".apk") and APK is not None:
            a = APK(data, raw=True)
            try:
                manifest = a.get_android_manifest_xml()
            except Exception:
                manifest = None
            perms = a.get_permissions() if a else []
            details = {
                "package": a.get_package() if a else None,
                "app_name": a.get_app_name() if a else None,
                "main_activity": a.get_main_activity() if a else None,
                "sdk_version": a.get_min_sdk_version() if a else None,
                "target_sdk": a.get_target_sdk_version() if a else None,
                "permissions": perms,
                "activities": a.get_activities() if a else [],
                "services": a.get_services() if a else [],
                "receivers": a.get_receivers() if a else [],
                "providers": a.get_providers() if a else [],
            }
            dex_files = a.get_all_original_dex() if a else []
            strings = []
            dex_stats = []
            if dex_files and DalvikVMFormat is not None and Analysis is not None:
                for d_data in dex_files:
                    try:
                        d = DalvikVMFormat(d_data)
                        an = Analysis(d)
                        dex_stats.append({
                            "class_count": len(d.get_classes()),
                            "method_count": sum(len(c.get_methods()) for c in d.get_classes()),
                            "field_count": sum(len(c.get_fields()) for c in d.get_classes()),
                        })
                        for s in d.get_strings():
                            if len(s) >= 6: strings.append(s)
                    except Exception as e:
                        dex_stats.append({"error": "DEX parse fail: " + str(e)})
            lib_files = [f for f in a.get_files_names() if f.endswith(".so")] if a else []
            obf_suspicion = False
            if dex_files and DalvikVMFormat is not None:
                try:
                    obf_suspicion = any(
                        re.match(r"L[a-zA-Z]{1,2};", c.get_name())
                        for d in dex_files
                        for c in DalvikVMFormat(d).get_classes()
                    )
                except Exception:
                    obf_suspicion = False
            results = {
                "package_info": details,
                "manifest_present": bool(manifest),
                "permissions": perms,
                "dex_stats": dex_stats,
                "embedded_native_libs": lib_files[:20],
                "obfuscation_suspected": obf_suspicion,
                "strings_sample": strings[:20],
                "security_findings": (
                    ["Dangerous permissions present!" if any('WRITE' in p or 'SMS' in p or 'BOOT' in p for p in perms) else "No high-risk permissions."]
                    + (["Obfuscation probably in use."] if obf_suspicion else [])
                )
            }
        elif filename.endswith(".dex") and DalvikVMFormat is not None:
            try:
                d = DalvikVMFormat(data)
                dex_stats = {
                    "class_count": len(d.get_classes()),
                    "method_count": sum(len(c.get_methods()) for c in d.get_classes()),
                    "field_count": sum(len(c.get_fields()) for c in d.get_classes()),
                    "strings": list(filter(lambda s:len(s)>8, d.get_strings()))[:15],
                    "obfuscation": any(re.match(r"L[a-zA-Z]{1,2};", c.get_name()) for c in d.get_classes())
                }
                results = {"dex_stats": dex_stats}
            except Exception as e:
                results = {"error": f"Failed to analyze DEX: {str(e)}"}
        elif (filename.endswith(".so") or filename.endswith(".elf") or (data[:4]==b'\x7fELF')):
            try:
                e_ident = data[:16]
                arch = "Unknown"
                if len(data) > 18:
                    arch = {3:'x86',40:'ARM',62:'x86_64'}.get(data[18],'unknown')
                entry = struct.unpack('<I', data[24:28])[0] if len(data)>28 else None
                found = data.find(b'.shstrtab')
                sections = []
                if found > 0:
                    for i in range(found, found+80, 8):
                        nm = data[i:i+8].replace(b'\x00', b'').decode(errors='ignore')
                        if nm: sections.append(nm)
                results = {
                    "arch": arch,
                    "entry_point": f"0x{entry:x}" if entry else None,
                    "magic": binascii.hexlify(e_ident).decode(),
                    "sections": sections
                }
            except Exception as e:
                results = {"error": f"Failed to analyze ELF: {str(e)}"}
        elif (filename.lower().endswith(('.exe','.dll','.pe')) or data[:2]==b'MZ') and pefile is not None:
            try:
                pe = pefile.PE(data=data)
                secnames = [s.Name.decode().strip('\x00') for s in pe.sections]
                imports = []
                if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
                    for entry in getattr(pe, "DIRECTORY_ENTRY_IMPORT"):
                        imports += [entry.dll.decode()] + [imp.name.decode() for imp in entry.imports if imp.name]
                results = {
                    "sections": secnames,
                    "entrypoint": hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint),
                    "dll_imports_sample": imports[:15],
                    "section_entropy": [s.get_entropy() for s in pe.sections],
                    "possible_packer": any("UPX" in s for s in secnames),
                    "file_checksum": hex(pe.generate_checksum()),
                }
            except Exception as e:
                results = {"error": f"Failed to analyze PE: {str(e)}"}
        else:
            magic = binascii.hexlify(data[:8]).decode()
            strings = re.findall(rb"[\x20-\x7E]{8,}", data)
            entropy = -sum((p := v/len(data)) * math.log2(p) for v in dict([(i, data.count(i)) for i in set(data)]).values()) if data else 0
            findings = []
            if entropy > 7.5:
                findings.append("High entropy (probably packed/encrypted/obfuscated).")
            results = {
                "magic": magic,
                "ascii_strings": [s.decode(errors="ignore") for s in strings[:10]],
                "size": len(data),
                "shannon_entropy": round(entropy, 3),
                "findings": findings
            }
        return {"info": info, "results": results}

class StaticAnalysisTool(ToolBase):
    def build_pipeline(self):
        fmt = self.intent.get("formats", ["file"])
        return {
            "type": "static_analysis",
            "formats": fmt,
            "pipeline": [
                "file_upload",
                "static_scanner",
                "heuristics",
                "report"
            ]
        }
    def analyze(self, file: UploadFile):
        filename = file.filename
        dat = file.file.read()
        results = {"filename": filename, "size": len(dat)}
        entropy = self._shannon_entropy(dat)
        results["shannon_entropy"] = entropy
        findings = []
        if entropy > 7.5:
            findings.append("File is high entropy (possibly packed/encrypted/obfuscated binary).")
        elif entropy < 3.3:
            findings.append("File is low entropy (likely not packed, mostly text/data).")
        suspicious = []
        upx = False
        if dat[:4] == b'\x7fELF':
            secnames = self._elf_find_sections(dat)
            results["sections"] = secnames
            upx = any("UPX" in s for s in secnames)
            if upx:
                suspicious.append("ELF binary packed (UPX found).")
        elif dat[:2] == b'MZ' and pefile is not None:
            try:
                pe = pefile.PE(data=dat)
                names = [s.Name.decode().strip('\x00') for s in pe.sections]
                results["sections"] = names
                upx = any("UPX" in n for n in names)
                if upx: suspicious.append("PE section (UPX) detected.")
            except Exception as e:
                results["pe_error"] = str(e)
        urls = re.findall(rb"https?://[a-zA-Z0-9\.\-/\?&%=_]+", dat)
        if urls:
            results["urls"] = [u.decode(errors="ignore") for u in urls[:20]]
        yara_findings = []
        if yara is not None:
            try:
                rules = yara.compile(source='rule always_true { condition: true }')
                scans = rules.match(data=dat)
                yara_findings = [str(m) for m in scans]
            except Exception as e:
                yara_findings = [f"YARA error: {str(e)}"]
        strings = re.findall(rb"[\x20-\x7E]{8,}", dat)
        results["string_sample"] = [s.decode(errors="ignore") for s in strings[:10]]
        results["findings"] = findings + suspicious
        if yara_findings:
            results["yara_findings"] = yara_findings
        return results
    def _shannon_entropy(self, data):
        if not data:
            return 0
        occur = {}
        for x in data:
            occur[x] = occur.get(x, 0) + 1
        entropy = 0
        for x in occur:
            p_x = occur[x]/len(data)
            entropy -= p_x * math.log2(p_x)
        return round(entropy,3)
    def _elf_find_sections(self, data):
        try:
            e_shoff = struct.unpack("<Q", data[40:48])[0]
            e_shentsize = struct.unpack("<H", data[58:60])[0]
            e_shnum = struct.unpack("<H", data[60:62])[0]
            sections = []
            for i in range(e_shnum):
                idx = e_shoff + i * e_shentsize
                name = data[idx:idx+8].replace(b'\x00', b'').decode(errors='ignore')
                if name:
                    sections.append(name)
            return sections
        except Exception: return []

class DisassemblerTool(ToolBase):
    def build_pipeline(self):
        fmt = self.intent.get('formats', ['file'])
        return {
            "type": "disassembler",
            "formats": fmt,
            "pipeline": [
                "file_upload",
                "disassembly",
                "report"
            ]
        }
    def analyze(self, file: UploadFile):
        filename = file.filename
        data = file.file.read()
        arch, mode = None, None
        lines = []
        if data[:4] == b'\x7fELF' or (file.filename and file.filename.endswith(('.so', '.elf'))):
            bits = 64 if len(data) > 4 and data[4] == 2 else 32
            if capstone is not None:
                arch, mode = capstone.CS_ARCH_X86, capstone.CS_MODE_64 if bits == 64 else capstone.CS_MODE_32
        elif data[:2] == b'MZ' or (file.filename and file.filename.endswith(('.exe', '.dll', '.pe'))):
            if capstone is not None:
                arch, mode = capstone.CS_ARCH_X86, capstone.CS_MODE_32
        if capstone is not None and arch is not None and mode is not None:
            offset = 0x100 if len(data) > 0x100 else 0x0
            code = data[offset:offset+512]
            md = capstone.Cs(arch, mode)
            for insn in md.disasm(code, offset):
                lines.append("0x%x:\t%-10s %s" % (insn.address, insn.mnemonic, insn.op_str))
        else:
            lines = [binascii.hexlify(data[i:i+16]).decode() for i in range(0, min(len(data),256),16)]
        return {
            "filename": filename,
            "instruction_count": len(lines),
            "instructions": lines[:50]
        }

class FormatExplorerTool(ToolBase):
    def build_pipeline(self):
        fmt = self.intent.get('formats', [])
        return {
            "type": "format_explorer",
            "formats": fmt,
            "pipeline": [
                "file_upload",
                "structure_viewer",
                "hex_viewer",
                "report"
            ]
        }
    def analyze(self, file: UploadFile):
        filename = file.filename
        data = file.file.read()
        structures = []
        magic = data[:4]
        if filename.endswith(".apk") or (magic == b'PK\x03\x04'):
            try:
                z = zipfile.ZipFile(io.BytesIO(data))
                files = z.namelist()
                manifest = z.read("AndroidManifest.xml") if "AndroidManifest.xml" in files else None
                structures.append(f"APK/JAR ZIP: {len(files)} files.")
                if manifest:
                    try:
                        manifest_head = manifest.decode(errors="ignore")[:256]
                        structures.append("Manifest head: " + manifest_head)
                    except Exception as e:
                        structures.append("Manifest decode error: " + str(e))
                structures.append("Files preview: " + str(files[:10]))
            except Exception as e:
                structures.append("ZIP APK structure error: " + str(e))
        elif magic == b'\x7fELF':
            try:
                endian = "little" if data[5] == 1 else "big"
                entry = int.from_bytes(data[24:32], endian)
                arch = {3: "x86", 40: "ARM", 62: "x86_64"}.get(data[18], "unknown")
                structures.append(f"ELF: {arch}, entry: {hex(entry)}")
            except Exception as e:
                structures.append(f"ELF parse error: {str(e)}")
        elif magic[:2] == b"MZ" and pefile is not None:
            try:
                pe = pefile.PE(data=data)
                sectionlist = ",".join(s.Name.decode().strip('\x00') for s in pe.sections)
                entrypoint = hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint)
                structures.append("PE: sections=" + sectionlist)
                structures.append("PE entry: " + entrypoint)
            except Exception as e:
                structures.append(f"PE parse error: {str(e)}")
        else:
            structures.append("Unknown magic: " + binascii.hexlify(magic).decode())
        structures.append("Hex sample: " + binascii.hexlify(data[:32]).decode())
        return {"filename": filename, "structures": structures}

TOOL_REGISTRY: Dict[str, Callable[[Dict[str, Any]], ToolBase]] = {
    "reverse_engineering_tool": ReverseEngineeringTool,
    "static_analysis_tool": StaticAnalysisTool,
    "disassembler": DisassemblerTool,
    "format_explorer": FormatExplorerTool,
}

def resolve_tool_class(intent: Dict[str, Any]) -> ToolBase:
    kind = intent["tool_kind"]
    if kind in TOOL_REGISTRY:
        return TOOL_REGISTRY[kind](intent)
    if kind == "format_explorer":
        return FormatExplorerTool(intent)
    return ReverseEngineeringTool(intent)

@app.post("/synthesize")
async def synthesize_tool(request: Dict[str, str]):
    try:
        description = request["description"]
    except Exception as e:
        return robust_error_response("Missing 'description' field", e)
    parser = SmartIntentParser()
    try:
        parsed = parser.parse_tool_request(description)
        return {
            "success": True,
            "parsed_intent": parsed
        }
    except Exception as e:
        return robust_error_response("Failed to parse tool request", e, trace=True)

@app.post("/tool_pipeline")
async def tool_pipeline(request: Dict[str, Any]):
    try:
        intent = request["intent"]
    except Exception as e:
        return robust_error_response("Missing 'intent' field", e)
    try:
        tool = resolve_tool_class(intent)
        pipeline = tool.build_pipeline()
        return pipeline
    except Exception as e:
        return robust_error_response("Failed to build pipeline", e, trace=True)

@app.post("/analyze")
async def analyze_file(intent: Dict = Body(...), file: UploadFile = File(...)):
    try:
        tool = resolve_tool_class(intent)
    except Exception as e:
        return robust_error_response("Failed to resolve tool", e, trace=True)
    try:
        result = tool.analyze(file)
        return result
    except Exception as e:
        return robust_error_response("Analysis failed", e, trace=True)

# ============================================================================
# FLASK BLUEPRINT WRAPPER
# The synthesis engine runs as FastAPI internally but exposes a Flask
# blueprint so app.py can register it without breaking the Zeus stack.
# All synthesis endpoints are proxied through /api/synthesis/* routes.
# The Zeus Project 2026 — Francois Nel
# ============================================================================

import threading as _synth_threading
import requests as _synth_requests
from flask import Blueprint, jsonify, request as flask_request

synthesis_bp = Blueprint("synthesis", __name__)

_SYNTH_PORT     = int(os.environ.get("SYNTHESIS_PORT", 8846))
_SYNTH_BASE_URL = f"http://127.0.0.1:{_SYNTH_PORT}"
_synth_started  = False
_synth_lock     = _synth_threading.Lock()


def _start_fastapi_server():
    """Launch the FastAPI sub-server in a daemon thread."""
    global _synth_started
    with _synth_lock:
        if _synth_started:
            return
        _synth_started = True

    def _run():
        try:
            import uvicorn
            uvicorn.run(app, host="127.0.0.1", port=_SYNTH_PORT,
                        log_level="warning")
        except Exception as e:
            import logging
            logging.getLogger("zeus.synthesis").error(
                f"[Synthesis] FastAPI thread crashed: {e}"
            )

    t = _synth_threading.Thread(target=_run, name="zeus_synthesis_fastapi", daemon=True)
    t.start()
    import time as _time
    _time.sleep(1.5)   # give FastAPI time to bind


def _proxy(path: str, method: str = "POST", data=None, files=None):
    """Forward a Flask request to the internal FastAPI server."""
    _start_fastapi_server()
    url = f"{_SYNTH_BASE_URL}{path}"
    try:
        if method == "GET":
            resp = _synth_requests.get(url, timeout=30)
        elif files:
            resp = _synth_requests.post(url, data=data, files=files, timeout=60)
        else:
            resp = _synth_requests.post(url, json=data, timeout=60)
        return resp.json(), resp.status_code
    except _synth_requests.exceptions.ConnectionError:
        return {"error": "synthesis engine not ready — retrying", "retry": True}, 503
    except Exception as e:
        return {"error": str(e)}, 500


@synthesis_bp.route("/api/synthesis/health", methods=["GET"])
def synthesis_health():
    return jsonify({
        "status":  "ok",
        "module":  "zeus_synthesis",
        "version": "1.0",
        "engine":  "fastapi",
        "port":    _SYNTH_PORT,
        "routes":  ["/api/synthesis/synthesize",
                    "/api/synthesis/pipeline",
                    "/api/synthesis/analyze"],
    })


@synthesis_bp.route("/api/synthesis/synthesize", methods=["POST"])
def synthesis_synthesize():
    """
    POST { "description": str }
    Parses tool request and returns intent.
    """
    data, code = _proxy("/synthesize", method="POST",
                        data=flask_request.get_json(force=True, silent=True) or {})
    return jsonify(data), code


@synthesis_bp.route("/api/synthesis/pipeline", methods=["POST"])
def synthesis_pipeline():
    """
    POST { "intent": { ... } }
    Builds and returns a tool pipeline from a parsed intent.
    """
    data, code = _proxy("/tool_pipeline", method="POST",
                        data=flask_request.get_json(force=True, silent=True) or {})
    return jsonify(data), code


@synthesis_bp.route("/api/synthesis/analyze", methods=["POST"])
def synthesis_analyze():
    """
    POST multipart/form-data: intent=JSON, file=binary
    Runs a full tool analysis on an uploaded file.
    """
    _start_fastapi_server()
    intent_raw = flask_request.form.get("intent", "{}")
    file_obj   = flask_request.files.get("file")
    if not file_obj:
        return jsonify({"error": "file required"}), 400
    data, code = _proxy(
        "/analyze",
        method="POST",
        data={"intent": intent_raw},
        files={"file": (file_obj.filename, file_obj.stream, file_obj.content_type)},
    )
    return jsonify(data), code


@synthesis_bp.route("/api/synthesis/stats", methods=["GET"])
def synthesis_stats():
    return jsonify({
        "module":     "zeus_synthesis",
        "fastapi_port": _SYNTH_PORT,
        "running":    _synth_started,
        "tools":      ["ReverseEngineeringTool", "StaticAnalysisTool",
                       "DisassemblerTool", "FormatExplorerTool"],
    })


def register(app) -> None:
    _start_fastapi_server()
    app.register_blueprint(synthesis_bp)
    import logging
    logging.getLogger("zeus.synthesis").info(
        "[synthesis] ✓ Registered at /api/synthesis (FastAPI proxy on :%d)" % _SYNTH_PORT
    )


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=_SYNTH_PORT)
