# The Zeus Project 2026 — Francois Nel
# zeus_intelligent_router.py — Elite Blueprint Surgeon & Module Router
# AST analysis · Missing route injection · Dependency resolution
# Conflict detection · Blueprint health monitoring · Live registration
# Logic engine integration · Full interconnect audit · Self-healing

import os
import re
import ast
import sys
import json
import uuid
import time
import shutil
import logging
import threading
import importlib
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.intelligent_router")

intelligent_router_bp = Blueprint("intelligent_router", __name__)

ZEUS_DIR   = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = os.path.join(ZEUS_DIR, "_router_backups")
os.makedirs(BACKUP_DIR, exist_ok=True)

# Files this router will never modify
SKIP_FILES = {
    "__pycache__", "zeus_intelligent_router.py",
    "app.py", "db_init.py", "setup.py",
}


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ModuleProfile:
    """Classification and routing metadata for a Zeus module."""
    module_name:   str
    file:          str
    purpose:       str
    url_prefix:    str
    bp_vars:       List[str]
    routes:        List[str]
    missing_routes: List[str]
    has_health:    bool
    has_register:  bool
    has_stats:     bool
    has_authorship: bool
    line_count:    int
    function_count: int
    complexity:    int
    depends_on:    List[str]
    status:        str   = "unanalyzed"
    error:         str   = ""

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class RoutePatch:
    """A route that needs to be injected into a module."""
    module_name:  str
    route_path:   str
    endpoint:     str
    methods:      List[str]
    response_body: str
    reason:       str
    injected:     bool = False
    error:        str  = ""


@dataclass
class RouterAuditResult:
    """Full audit of the Zeus routing system."""
    audit_id:       str
    modules_scanned: int
    modules_ok:     int
    modules_needing_repair: int
    patches_applied: int
    patches_failed:  int
    conflicts:      List[Dict]
    orphaned_routes: List[str]
    missing_health:  List[str]
    unregistered:    List[str]
    duration_ms:     float
    timestamp:       str
    details:         List[Dict]

    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# MODULE PURPOSE CLASSIFIER
# ============================================================================

MODULE_PROFILES = [
    {
        "tags": ["sandbox", "execut", "run_code"],
        "purpose": "Code Sandbox / Executor",
        "prefix": "/api/sandbox",
        "required_routes": [
            ("/api/sandbox/health",    "sandbox_health",  ["GET"],  "{'status':'ok','module':'sandbox'}"),
            ("/api/sandbox/stats",     "sandbox_stats",   ["GET"],  "{'status':'ok'}"),
        ],
    },
    {
        "tags": ["mutat", "evolv", "genome", "dna"],
        "purpose": "Mutator / Genome Engine",
        "prefix": "/api/mutator",
        "required_routes": [
            ("/api/mutator/status",   "mutator_status",  ["GET"],  "{'status':'ok'}"),
        ],
    },
    {
        "tags": ["chat", "message", "conversation"],
        "purpose": "Chat Engine",
        "prefix": "/api/chat",
        "required_routes": [
            ("/api/chat/health",      "chat_health",     ["GET"],  "{'status':'ok','module':'chat'}"),
            ("/api/chat/stats",       "chat_stats",      ["GET"],  "{'calls':0}"),
        ],
    },
    {
        "tags": ["search", "query", "find"],
        "purpose": "Search Engine",
        "prefix": "/api/search",
        "required_routes": [
            ("/api/search/health",    "search_health",   ["GET"],  "{'status':'ok','module':'search'}"),
        ],
    },
    {
        "tags": ["forge", "generat", "codegen"],
        "purpose": "Code Forge",
        "prefix": "/api/forge",
        "required_routes": [
            ("/api/forge/health",     "forge_health",    ["GET"],  "{'status':'ok','module':'forge'}"),
            ("/api/forge/stats",      "forge_stats",     ["GET"],  "{'jobs':0}"),
        ],
    },
    {
        "tags": ["learn", "knowl", "topic"],
        "purpose": "Learning Engine",
        "prefix": "/api/learner",
        "required_routes": [
            ("/api/learner/health",   "learner_health",  ["GET"],  "{'status':'ok','module':'learner'}"),
            ("/api/learner/stats",    "learner_stats",   ["GET"],  "{'total_learned':0}"),
        ],
    },
    {
        "tags": ["blueprint", "plan"],
        "purpose": "Blueprint Engine",
        "prefix": "/api/blueprints",
        "required_routes": [
            ("/api/blueprints/health","blueprints_health",["GET"], "{'status':'ok','module':'blueprints'}"),
        ],
    },
    {
        "tags": ["apk", "android", "smali"],
        "purpose": "APK Engine",
        "prefix": "/api/apk",
        "required_routes": [
            ("/api/apk/health",       "apk_health",      ["GET"],  "{'status':'ok','module':'apk'}"),
        ],
    },
    {
        "tags": ["evolution", "self_evol", "evolv"],
        "purpose": "Self-Evolution Engine",
        "prefix": "/api/evolution",
        "required_routes": [
            ("/api/evolution/health", "evolution_health",["GET"],  "{'status':'ok','module':'evolution'}"),
            ("/api/evolution/stats",  "evolution_stats", ["GET"],  "{'total_cycles':0}"),
        ],
    },
    {
        "tags": ["identity", "fingerprint", "registry"],
        "purpose": "Identity & Registry",
        "prefix": "/api/identity",
        "required_routes": [
            ("/api/identity/health",  "identity_health", ["GET"],  "{'status':'ok','module':'identity'}"),
        ],
    },
    {
        "tags": ["llm", "router", "groq", "claude"],
        "purpose": "LLM Router",
        "prefix": "/api/llm",
        "required_routes": [
            ("/api/llm/health",       "llm_health",      ["GET"],  "{'status':'ok','module':'llm_router'}"),
            ("/api/llm/status",       "llm_status",      ["GET"],  "{'engines':{}}"),
        ],
    },
    {
        "tags": ["genome", "manager", "dna"],
        "purpose": "Genome Manager",
        "prefix": "/api/genome/manager",
        "required_routes": [
            ("/api/genome/manager/health","genome_health",["GET"], "{'status':'ok','module':'genome_manager'}"),
        ],
    },
    {
        "tags": ["replication", "offspring", "stem"],
        "purpose": "Replication Engine",
        "prefix": "/api/replication",
        "required_routes": [
            ("/api/replication/health","replication_health",["GET"],"{'status':'ok','module':'replication'}"),
        ],
    },
    {
        "tags": ["grok", "bridge", "xai"],
        "purpose": "Grok Bridge",
        "prefix": "/api/grok",
        "required_routes": [
            ("/api/grok/health",      "grok_health",     ["GET"],  "{'status':'ok','module':'grok_bridge'}"),
        ],
    },
    {
        "tags": ["predict", "prediction", "forecast"],
        "purpose": "Prediction Engine",
        "prefix": "/api/prediction",
        "required_routes": [
            ("/api/prediction/health","prediction_health",["GET"], "{'status':'ok','module':'prediction'}"),
        ],
    },
]


# ============================================================================
# AST MODULE SCANNER
# ============================================================================

class ModuleScanner:
    """
    Deep AST analysis of Zeus .py modules.
    Classifies purpose, detects blueprints, routes, and missing infrastructure.
    """

    def scan(self, fpath: str, fname: str) -> Optional[ModuleProfile]:
        try:
            source = open(fpath, encoding="utf-8", errors="replace").read()
            tree   = ast.parse(source)
        except SyntaxError as e:
            return ModuleProfile(
                module_name=fname.replace(".py",""), file=fname,
                purpose="unknown", url_prefix="",
                bp_vars=[], routes=[], missing_routes=[],
                has_health=False, has_register=False, has_stats=False,
                has_authorship=False, line_count=len(source.splitlines()),
                function_count=0, complexity=0, depends_on=[],
                status="syntax_error", error=str(e),
            )

        # Extract Blueprint variables
        bp_vars   = []
        routes    = []
        functions = []
        imports   = []
        complexity = 1

        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id.endswith("_bp"):
                        bp_vars.append(t.id)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                functions.append(node.name)
                for dec in node.decorator_list:
                    if (isinstance(dec, ast.Call) and
                            isinstance(getattr(dec.func, "attr", None), str) and
                            dec.func.attr == "route"):
                        for arg in dec.args:
                            if isinstance(arg, ast.Constant):
                                routes.append(str(arg.value))
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                mod = getattr(node, "module", "") or ""
                for alias in getattr(node, "names", []):
                    imports.append(alias.name or mod)
            elif isinstance(node, (ast.If, ast.For, ast.While, ast.Try)):
                complexity += 1

        # Classify module purpose
        source_lower = source.lower()
        fname_lower  = fname.lower()
        text_for_cls = f"{fname_lower} {source_lower[:3000]}"

        purpose    = "unknown"
        url_prefix = ""
        for profile in MODULE_PROFILES:
            for tag in profile["tags"]:
                if tag in text_for_cls:
                    purpose    = profile["purpose"]
                    url_prefix = profile["prefix"]
                    break
            if purpose != "unknown":
                break

        # Detect missing required routes
        missing = []
        for profile in MODULE_PROFILES:
            if profile["prefix"] == url_prefix:
                for route_path, ep, methods, _ in profile["required_routes"]:
                    # Check if any route ends with the route_path suffix
                    suffix = route_path.replace(url_prefix, "")
                    if suffix and not any(r.endswith(suffix) or r == route_path for r in routes):
                        missing.append(route_path)
                break

        # Dependencies from imports
        depends = [imp for imp in imports
                   if imp.startswith("zeus_") or imp in ("logic_engine", "genome_manager", "db_init")]

        return ModuleProfile(
            module_name=fname.replace(".py", ""),
            file=fname,
            purpose=purpose,
            url_prefix=url_prefix,
            bp_vars=list(set(bp_vars)),
            routes=routes,
            missing_routes=missing,
            has_health=any("/health" in r for r in routes),
            has_register="register" in functions,
            has_stats=any("/stats" in r or "/status" in r for r in routes),
            has_authorship="# The Zeus Project 2026" in source,
            line_count=len(source.splitlines()),
            function_count=len(functions),
            complexity=complexity,
            depends_on=list(set(depends))[:10],
            status="ok" if not missing else "needs_routes",
        )


# ============================================================================
# ROUTE INJECTOR
# ============================================================================

class RouteInjector:
    """
    Injects missing routes into Zeus modules.
    Creates backup before modifying. Validates syntax after injection.
    """

    def inject(self, fpath: str, fname: str,
                patches: List[RoutePatch]) -> Tuple[int, int, List[str]]:
        """
        Inject missing routes into a module file.
        Returns (injected_count, failed_count, log_lines)
        """
        log_lines  = []
        injected   = 0
        failed     = 0
        backup_path = ""

        if not patches:
            return 0, 0, []

        # Backup first
        try:
            ts          = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{fname}_{ts}.bak"
            backup_path = os.path.join(BACKUP_DIR, backup_name)
            shutil.copy2(fpath, backup_path)
            log_lines.append(f"Backup: {backup_path}")
        except Exception as e:
            log_lines.append(f"Backup failed: {e}")
            return 0, 0, log_lines

        # Read current source
        try:
            source = open(fpath, encoding="utf-8").read()
        except Exception as e:
            log_lines.append(f"Read failed: {e}")
            return 0, 0, log_lines

        # Find Blueprint variable name in source
        bp_match = re.search(r'(\w+_bp)\s*=\s*Blueprint\(', source)
        if not bp_match:
            log_lines.append(f"No Blueprint variable found in {fname} — skipping injection")
            return 0, 0, log_lines
        bp_var = bp_match.group(1)

        # Generate route code for each patch
        new_code_blocks = []
        for patch in patches:
            methods_str = ", ".join(f'"{m}"' for m in patch.methods)
            suffix      = patch.route_path.split("/")[-1] or "root"
            new_code_blocks.append(
                f"\n\n@{bp_var}.route(\"{patch.route_path}\", methods=[{methods_str}])\n"
                f"def {patch.endpoint}():\n"
                f"    \"\"\"Auto-generated by zeus_intelligent_router — {patch.reason}\"\"\"\n"
                f"    try:\n"
                f"        return jsonify({patch.response_body})\n"
                f"    except Exception as exc:\n"
                f"        return jsonify({{\"error\": str(exc)}}), 500\n"
            )

        new_source = source + "\n".join(new_code_blocks)

        # Validate syntax before writing
        try:
            ast.parse(new_source)
        except SyntaxError as e:
            log_lines.append(f"Injected code syntax error: {e} — reverting")
            # Restore backup
            shutil.copy2(backup_path, fpath)
            return 0, len(patches), log_lines

        # Write
        try:
            with open(fpath, "w", encoding="utf-8") as f:
                f.write(new_source)
            injected = len(patches)
            failed   = 0
            for patch in patches:
                patch.injected = True
                log_lines.append(f"Injected: {patch.route_path} → {fname}")
        except Exception as e:
            shutil.copy2(backup_path, fpath)
            failed     = len(patches)
            log_lines.append(f"Write failed: {e} — reverted")

        return injected, failed, log_lines


# ============================================================================
# INTELLIGENT ROUTER ENGINE (SINGLETON)
# ============================================================================

class IntelligentRouterEngine:
    """
    Elite Zeus routing intelligence.
    Scans all modules, detects gaps, injects missing routes,
    resolves conflicts, and maintains a live routing table.
    Integrates with logic engine for architectural compliance checking.
    """

    def __init__(self):
        self._lock     = threading.RLock()
        self._scanner  = ModuleScanner()
        self._injector = RouteInjector()
        self._profiles: Dict[str, ModuleProfile]    = {}
        self._routing_table: Dict[str, str]          = {}   # url_prefix → module
        self._conflicts: List[Dict]                  = []
        self._audit_history: deque = deque(maxlen=20)
        self._total_audits    = 0
        self._total_injections = 0

    def scan_all(self, dry_run: bool = False) -> RouterAuditResult:
        """
        Full scan of all Zeus modules.
        Detects missing routes, conflicts, unregistered blueprints.
        dry_run=True → report only, no modifications.
        """
        t0       = time.time()
        audit_id = uuid.uuid4().hex[:10]
        profiles = []
        conflicts = []
        missing_health = []
        unregistered   = []
        patches_applied = 0
        patches_failed  = 0

        # Scan all .py files
        for fname in sorted(os.listdir(ZEUS_DIR)):
            if not fname.endswith(".py"):
                continue
            if fname in SKIP_FILES or any(x in fname for x in [".bak", "_backup"]):
                continue
            fpath   = os.path.join(ZEUS_DIR, fname)
            profile = self._scanner.scan(fpath, fname)
            if profile:
                profiles.append(profile)
                with self._lock:
                    self._profiles[profile.module_name] = profile

        # Detect prefix conflicts
        prefix_map: Dict[str, List[str]] = defaultdict(list)
        for p in profiles:
            if p.url_prefix:
                prefix_map[p.url_prefix].append(p.module_name)
        for prefix, modules in prefix_map.items():
            if len(modules) > 1:
                conflicts.append({
                    "prefix":  prefix,
                    "modules": modules,
                    "severity": "high",
                })

        # Gather missing health + unregistered
        for p in profiles:
            if p.bp_vars and not p.has_health:
                missing_health.append(p.module_name)
            if p.bp_vars and not p.has_register:
                unregistered.append(p.module_name)

        # Route injection (if not dry_run)
        if not dry_run:
            for p in profiles:
                if not p.missing_routes or not p.bp_vars:
                    continue
                fpath   = os.path.join(ZEUS_DIR, p.file)
                patches = self._build_patches(p)
                if patches:
                    inj, fail, inj_log = self._injector.inject(fpath, p.file, patches)
                    patches_applied   += inj
                    patches_failed    += fail
                    self._total_injections += inj
                    if inj > 0:
                        # Re-scan the modified file
                        updated = self._scanner.scan(fpath, p.file)
                        if updated:
                            with self._lock:
                                self._profiles[updated.module_name] = updated

        # Build routing table
        with self._lock:
            self._routing_table = {
                p.url_prefix: p.module_name
                for p in profiles if p.url_prefix
            }
            self._conflicts = conflicts

        duration_ms = round((time.time() - t0) * 1000, 1)
        modules_ok  = sum(1 for p in profiles if not p.missing_routes and p.has_health)

        result = RouterAuditResult(
            audit_id=audit_id,
            modules_scanned=len(profiles),
            modules_ok=modules_ok,
            modules_needing_repair=len(profiles) - modules_ok,
            patches_applied=patches_applied,
            patches_failed=patches_failed,
            conflicts=conflicts,
            orphaned_routes=[],
            missing_health=missing_health,
            unregistered=unregistered,
            duration_ms=duration_ms,
            timestamp=datetime.now(timezone.utc).isoformat(),
            details=[p.to_dict() for p in profiles if p.missing_routes or not p.has_health],
        )

        with self._lock:
            self._audit_history.append(result.to_dict())
            self._total_audits += 1

        # Feed findings to logic engine
        self._notify_logic_engine(result)

        log.info(
            f"[IRouter] Audit {audit_id}: "
            f"{len(profiles)} modules, {modules_ok} ok, "
            f"{patches_applied} patches in {duration_ms}ms"
        )
        return result

    def get_routing_table(self) -> Dict[str, str]:
        with self._lock:
            return dict(self._routing_table)

    def get_module_profile(self, module_name: str) -> Optional[ModuleProfile]:
        with self._lock:
            return self._profiles.get(module_name)

    def health_check_all(self, app) -> Dict:
        """Check /health route on every registered module."""
        results = {}
        routing = self.get_routing_table()
        with app.test_client() as client:
            for prefix, module_name in routing.items():
                health_url = f"{prefix}/health"
                try:
                    t0   = time.time()
                    resp = client.get(health_url)
                    ms   = round((time.time() - t0) * 1000, 1)
                    results[module_name] = {
                        "status":    "ok" if resp.status_code < 400 else "degraded",
                        "http_code": resp.status_code,
                        "latency_ms": ms,
                        "url":        health_url,
                    }
                except Exception as e:
                    results[module_name] = {"status": "error", "error": str(e), "url": health_url}
        return results

    def find_module_for_route(self, route_path: str) -> Optional[str]:
        """Find which module owns a given route path."""
        with self._lock:
            for prefix, module in self._routing_table.items():
                if route_path.startswith(prefix):
                    return module
        return None

    def stats(self) -> Dict:
        with self._lock:
            return {
                "total_audits":     self._total_audits,
                "total_injections": self._total_injections,
                "modules_tracked":  len(self._profiles),
                "routing_entries":  len(self._routing_table),
                "conflicts":        len(self._conflicts),
                "recent_audits":    list(self._audit_history)[-3:],
            }

    # ---- Internal -------------------------------------------------------

    def _build_patches(self, profile: ModuleProfile) -> List[RoutePatch]:
        patches = []
        for route_path in profile.missing_routes:
            suffix    = route_path.split("/")[-1] or "root"
            endpoint  = f"{profile.module_name}_{suffix}_auto"
            methods   = ["GET"]
            if "submit" in suffix or "create" in suffix or "run" in suffix:
                methods = ["POST"]
            # Build response body
            resp = (
                f"{{'status': 'ok', 'module': '{profile.module_name}', "
                f"'route': '{route_path}'}}"
            )
            patches.append(RoutePatch(
                module_name=profile.module_name,
                route_path=route_path,
                endpoint=endpoint,
                methods=methods,
                response_body=resp,
                reason=f"Auto-injected missing route by zeus_intelligent_router",
            ))
        return patches

    def _notify_logic_engine(self, result: RouterAuditResult) -> None:
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            facts  = [
                LogicFact(predicate="router_audit_complete",
                           args=(result.audit_id,), source="intelligent_router"),
            ]
            for conflict in result.conflicts:
                facts.append(LogicFact(
                    predicate="route_conflict_detected",
                    args=(conflict["prefix"],),
                    source="intelligent_router",
                ))
            for module in result.missing_health:
                facts.append(LogicFact(
                    predicate="zeus_module_no_health_route",
                    args=(module,),
                    source="intelligent_router",
                ))
            engine.reason(facts, max_depth=4, auto_learn=True)
        except Exception:
            pass


# ============================================================================
# SINGLETON
# ============================================================================

_irouter_lock:     threading.RLock             = threading.RLock()
_irouter_instance: Optional[IntelligentRouterEngine] = None


def get_irouter() -> IntelligentRouterEngine:
    global _irouter_instance
    with _irouter_lock:
        if _irouter_instance is None:
            _irouter_instance = IntelligentRouterEngine()
        return _irouter_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@intelligent_router_bp.route("/api/irouter/health", methods=["GET"])
def irouter_health():
    stats = get_irouter().stats()
    return jsonify({
        "status":   "ok",
        "module":   "zeus_intelligent_router",
        "version":  "2.0",
        "audits":   stats["total_audits"],
        "modules":  stats["modules_tracked"],
        "conflicts": stats["conflicts"],
    })


@intelligent_router_bp.route("/api/irouter/stats", methods=["GET"])
def irouter_stats():
    try:
        return jsonify(get_irouter().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@intelligent_router_bp.route("/api/irouter/scan", methods=["POST"])
def irouter_scan():
    """
    Run full module scan and route injection.
    POST { "dry_run": bool }
    """
    data    = request.get_json(force=True, silent=True) or {}
    dry_run = bool(data.get("dry_run", True))   # default safe: dry_run

    def _bg():
        get_irouter().scan_all(dry_run=dry_run)

    t = threading.Thread(target=_bg, daemon=True)
    t.start()
    return jsonify({
        "status":  "scanning",
        "dry_run": dry_run,
        "poll":    "/api/irouter/audit_history",
    })


@intelligent_router_bp.route("/api/irouter/scan_sync", methods=["POST"])
def irouter_scan_sync():
    """Synchronous scan — waits for completion."""
    data    = request.get_json(force=True, silent=True) or {}
    dry_run = bool(data.get("dry_run", True))
    try:
        result = get_irouter().scan_all(dry_run=dry_run)
        return jsonify(result.to_dict())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@intelligent_router_bp.route("/api/irouter/routing_table", methods=["GET"])
def irouter_routing_table():
    """Return the current url_prefix → module mapping."""
    try:
        table = get_irouter().get_routing_table()
        return jsonify({"routing_table": table, "entries": len(table)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@intelligent_router_bp.route("/api/irouter/module/<module_name>", methods=["GET"])
def irouter_module(module_name: str):
    """Get detailed profile for a specific module."""
    profile = get_irouter().get_module_profile(module_name)
    if not profile:
        return jsonify({"error": f"Module '{module_name}' not in router cache"}), 404
    return jsonify(profile.to_dict())


@intelligent_router_bp.route("/api/irouter/resolve", methods=["POST"])
def irouter_resolve():
    """
    Find which module owns a route.
    POST { "route": "/api/chat/history" }
    """
    data  = request.get_json(force=True, silent=True) or {}
    route = data.get("route", "").strip()
    if not route:
        return jsonify({"error": "route required"}), 400
    module = get_irouter().find_module_for_route(route)
    return jsonify({"route": route, "module": module or "unknown"})


@intelligent_router_bp.route("/api/irouter/health_check", methods=["POST"])
def irouter_health_check():
    """Health-check all registered modules."""
    try:
        from flask import current_app
        results = get_irouter().health_check_all(current_app._get_current_object())
        ok      = sum(1 for r in results.values() if r.get("status") == "ok")
        return jsonify({
            "results":    results,
            "total":      len(results),
            "healthy":    ok,
            "degraded":   len(results) - ok,
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@intelligent_router_bp.route("/api/irouter/audit_history", methods=["GET"])
def irouter_audit_history():
    limit   = int(request.args.get("limit", 10))
    irouter = get_irouter()
    with irouter._lock:
        history = list(irouter._audit_history)[-limit:]
    return jsonify({"history": list(reversed(history)), "total": irouter._total_audits})


@intelligent_router_bp.route("/api/irouter/conflicts", methods=["GET"])
def irouter_conflicts():
    irouter = get_irouter()
    with irouter._lock:
        conflicts = list(irouter._conflicts)
    return jsonify({"conflicts": conflicts, "count": len(conflicts)})


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(intelligent_router_bp)
    log.info("[intelligent_router] ✓ Registered at /api/irouter")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_intelligent_router",
            blueprint_var="intelligent_router_bp",
            url_prefix="/api/irouter",
            version="2.0",
            description="Elite blueprint surgeon: AST analysis, route injection, conflict detection, health monitoring",
            capabilities=[
                {"id": "irouter.scan",          "endpoint": "/api/irouter/scan",          "method": "POST", "tags": ["router","audit"]},
                {"id": "irouter.routing_table", "endpoint": "/api/irouter/routing_table", "method": "GET",  "tags": ["router"]},
                {"id": "irouter.resolve",       "endpoint": "/api/irouter/resolve",       "method": "POST", "tags": ["router"]},
                {"id": "irouter.health_check",  "endpoint": "/api/irouter/health_check",  "method": "POST", "tags": ["health","router"]},
                {"id": "irouter.conflicts",     "endpoint": "/api/irouter/conflicts",     "method": "GET",  "tags": ["router","conflicts"]},
                {"id": "irouter.health",        "endpoint": "/api/irouter/health",        "method": "GET",  "tags": ["health"]},
                {"id": "irouter.stats",         "endpoint": "/api/irouter/stats",         "method": "GET",  "tags": ["stats"]},
            ],
            depends_on=["logic_engine", "zeus_identity"],
            boot_order=97,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    print("\n=== Zeus Intelligent Router ===")
    result = get_irouter().scan_all(dry_run=True)
    print(f"  Modules scanned:    {result.modules_scanned}")
    print(f"  Modules OK:         {result.modules_ok}")
    print(f"  Needing repair:     {result.modules_needing_repair}")
    print(f"  Missing /health:    {result.missing_health}")
    print(f"  Conflicts:          {len(result.conflicts)}")
    print(f"  Duration:           {result.duration_ms}ms")
    print("\n# The Zeus Project 2026 — Francois Nel\n")
    _app.run(host="0.0.0.0", port=5026, debug=True, use_reloader=False)
