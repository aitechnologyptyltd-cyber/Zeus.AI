# The Zeus Project 2026 — Francois Nel
# zeus_code_learner.py — Central Brain for Code Intelligence v2.0
# Real call graphs · Cognitive complexity (nesting-weighted) · Halstead metrics
# Pure function detection · Dead code analysis · Taint tracking · Behavioral classification
# 5-stage mastery with genuine semantic content — not feature lists, actual understanding
# Fully offline · Zero LLM · Zero stubs · ARM-safe on Hisense Y82 Pro
#
# APP.PY REGISTRATION:
#   _loaded += _register("zeus_code_learner", "code_learner_bp")
# Or POST /api/code_learner/self_register for automatic patching.

import os
import re
import ast
import json
import math
import time
import shutil
import hashlib
import logging
import sqlite3
import threading
import subprocess
from collections import defaultdict, Counter
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from xml.etree import ElementTree as ET

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.code_learner")

code_learner_bp = Blueprint("code_learner", __name__)

ZEUS_DIR    = os.path.dirname(os.path.abspath(__file__))
EVOLVED_DIR = os.path.join(ZEUS_DIR, "evolved_modules")
UPLOAD_DIR  = os.path.join(ZEUS_DIR, "uploads")
DB_PATH     = os.path.join(ZEUS_DIR, "zeus.db")

os.makedirs(EVOLVED_DIR, exist_ok=True)

DEPTHS: List[str] = ["Simple", "Advanced", "Professional", "Complex", "Mastery"]
DEPTH_CONFIDENCE: Dict[str, float] = {
    "Simple": 0.20, "Advanced": 0.20, "Professional": 0.20,
    "Complex": 0.20, "Mastery": 0.20,
}

LANG_MAP: Dict[str, str] = {
    ".py": "python", ".pyw": "python",
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".java": "java", ".kt": "kotlin", ".kts": "kotlin",
    ".scala": "scala", ".clj": "clojure",
    ".smali": "smali",
    ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".hpp": "cpp", ".hxx": "cpp",
    ".cs": "csharp",
    ".rs": "rust", ".go": "go", ".swift": "swift",
    ".hs": "haskell", ".ex": "elixir", ".exs": "elixir",
    ".rb": "ruby", ".php": "php", ".pl": "perl",
    ".lua": "lua", ".r": "r", ".dart": "dart",
    ".sh": "shell", ".bash": "shell", ".zsh": "shell", ".fish": "shell",
    ".ps1": "powershell", ".bat": "batch", ".cmd": "batch",
    ".asm": "assembly", ".s": "assembly",
    ".sql": "sql", ".graphql": "graphql",
    ".html": "html", ".htm": "html",
    ".xml": "xml", ".svg": "xml",
    ".css": "css", ".scss": "css", ".less": "css", ".sass": "css",
    ".json": "json", ".yaml": "yaml", ".yml": "yaml",
    ".toml": "toml", ".ini": "ini", ".cfg": "ini",
    ".conf": "ini", ".env": "env", ".csv": "csv",
    ".md": "markdown", ".rst": "restructuredtext",
    ".txt": "text", ".log": "text", ".adoc": "text",
    ".apk": "apk", ".aab": "apk", ".aar": "apk",
    ".dex": "dex",
    ".so": "elf", ".dll": "pe", ".exe": "pe", ".bin": "binary",
    ".jar": "jar", ".class": "jvm_class",
    ".zip": "archive", ".tar": "archive", ".gz": "archive",
    ".bz2": "archive", ".xz": "archive", ".tgz": "archive",
    ".png": "image", ".jpg": "image", ".jpeg": "image",
    ".gif": "image", ".bmp": "image", ".webp": "image",
    ".mp3": "audio", ".wav": "audio", ".ogg": "audio",
    ".mp4": "video", ".mkv": "video", ".avi": "video",
}

LANG_FAMILIES: Dict[str, List[str]] = {
    "android":   ["smali", "dex", "apk", "java", "kotlin"],
    "jvm":       ["java", "kotlin", "scala", "clojure", "jvm_class", "jar"],
    "systems":   ["c", "cpp", "rust", "go", "assembly", "elf", "pe", "binary"],
    "scripting": ["python", "ruby", "php", "perl", "lua", "r", "dart", "elixir", "haskell"],
    "web":       ["javascript", "typescript", "html", "css", "graphql"],
    "mobile":    ["swift", "dart", "kotlin"],
    "shell":     ["shell", "powershell", "batch"],
    "data":      ["json", "yaml", "toml", "ini", "csv", "sql", "env"],
    "markup":    ["xml", "html", "markdown", "restructuredtext", "text"],
    "binary":    ["elf", "pe", "jar", "archive", "dex", "jvm_class", "apk", "binary"],
    "media":     ["image", "audio", "video"],
}

_BINARY_LANGS: Set[str] = {
    "dex", "elf", "pe", "jar", "archive", "jvm_class",
    "apk", "binary", "image", "audio", "video"
}

_NEVER_DEAD: Set[str] = {
    "__init__", "__str__", "__repr__", "__eq__", "__hash__", "__call__",
    "__enter__", "__exit__", "__getitem__", "__setitem__", "__len__",
    "__iter__", "__next__", "__contains__", "__del__",
    "register", "boot", "main", "run", "start", "stop",
}

# ============================================================================
# DYNAMIC EXTENSION REGISTRY
# Runtime-learned mapping of unknown extensions → inferred language.
# Persisted to a JSON sidecar next to zeus.db so it survives restarts.
# Never blocks — worst case falls back to "unknown_text" or "unknown_binary".
# ============================================================================

_DYN_REGISTRY_PATH = os.path.join(os.path.dirname(DB_PATH), "zeus_ext_registry.json")
_dynamic_ext_registry: Dict[str, Dict] = {}   # ext → {lang, family, purpose, seen_count}
_dynamic_ext_lock = threading.Lock()


def _load_dynamic_registry():
    global _dynamic_ext_registry
    try:
        if os.path.isfile(_DYN_REGISTRY_PATH):
            with open(_DYN_REGISTRY_PATH, encoding="utf-8") as f:
                _dynamic_ext_registry = json.load(f)
    except Exception:
        _dynamic_ext_registry = {}


def _save_dynamic_registry():
    try:
        with open(_DYN_REGISTRY_PATH, "w", encoding="utf-8") as f:
            json.dump(_dynamic_ext_registry, f, indent=2)
    except Exception:
        pass


def _register_unknown_ext(ext: str, lang: str, family: str, purpose: str):
    """Thread-safe registration and persistence of a newly learned extension."""
    with _dynamic_ext_lock:
        if ext in _dynamic_ext_registry:
            _dynamic_ext_registry[ext]["seen_count"] = \
                _dynamic_ext_registry[ext].get("seen_count", 1) + 1
        else:
            _dynamic_ext_registry[ext] = {
                "lang":       lang,
                "family":     family,
                "purpose":    purpose,
                "seen_count": 1,
                "first_seen": datetime.now(timezone.utc).isoformat(),
            }
            log.info(f"[CodeLearner] New extension learned: {ext!r} → {lang} ({purpose})")
        _save_dynamic_registry()


def _lookup_dynamic_ext(ext: str) -> Optional[str]:
    with _dynamic_ext_lock:
        entry = _dynamic_ext_registry.get(ext)
        return entry["lang"] if entry else None


# ============================================================================
# UNKNOWN FILE SNIFFER
# Inspects raw bytes + text content to infer language/purpose for any unknown
# extension. Always produces a result — never returns None or skips the file.
# ============================================================================

class UnknownFileSniffer:
    """
    Content-based language inference for unknown file extensions.
    Uses shebang lines, magic bytes, keyword density, and structural patterns
    to produce a (lang, family, purpose) triple for any file Zeus encounters.
    Deterministic · offline · zero external deps · ARM-safe.
    """

    # Magic byte signatures for binary formats
    _MAGIC: List[Tuple[bytes, str, str, str]] = [
        (b"PK\x03\x04",        "archive",   "binary",  "zip_archive"),
        (b"\x1f\x8b",          "archive",   "binary",  "gzip_compressed"),
        (b"BZh",               "archive",   "binary",  "bzip2_compressed"),
        (b"\xfd7zXZ",          "archive",   "binary",  "xz_compressed"),
        (b"dex\n",             "dex",       "android", "dalvik_bytecode"),
        (b"CAFEBABE",          "jvm_class", "jvm",     "java_classfile"),
        (b"\x7fELF",           "elf",       "systems", "elf_binary"),
        (b"MZ",                "pe",        "systems", "windows_pe_binary"),
        (b"\x89PNG",           "image",     "media",   "png_image"),
        (b"\xff\xd8\xff",      "image",     "media",   "jpeg_image"),
        (b"GIF8",              "image",     "media",   "gif_image"),
        (b"RIFF",              "audio",     "media",   "wav_audio"),
        (b"ID3",               "audio",     "media",   "mp3_audio"),
        (b"\x00\x00\x00\x20ftyp", "video", "media",   "mp4_video"),
        (b"SQLite format 3",   "sqlite_db", "data",    "sqlite_database"),
        (b"\x50\x4b\x05\x06", "archive",   "binary",  "empty_zip"),
        (b"CAFED00D",          "jvm_class", "jvm",     "multi_release_jar"),
    ]

    # Shebang → language
    _SHEBANG: Dict[str, Tuple[str, str, str]] = {
        "python":     ("python",     "scripting", "python_script"),
        "python3":    ("python",     "scripting", "python_script"),
        "bash":       ("shell",      "shell",     "bash_script"),
        "sh":         ("shell",      "shell",     "posix_shell_script"),
        "zsh":        ("shell",      "shell",     "zsh_script"),
        "node":       ("javascript", "web",       "node_script"),
        "nodejs":     ("javascript", "web",       "node_script"),
        "ruby":       ("ruby",       "scripting", "ruby_script"),
        "perl":       ("perl",       "scripting", "perl_script"),
        "php":        ("php",        "scripting", "php_script"),
        "lua":        ("lua",        "scripting", "lua_script"),
        "Rscript":    ("r",          "scripting", "r_script"),
        "env python": ("python",     "scripting", "python_script"),
    }

    # Strong keyword signals — (pattern, lang, family, purpose, min_hits)
    _KEYWORD_RULES: List[Tuple[str, str, str, str, int]] = [
        # Python markers
        (r"\bdef \w+\(|\bimport \w|\bclass \w+:|from \w+ import",
         "python",     "scripting", "python_source",      2),
        # Java markers
        (r"\bpublic\s+class\b|\bimport\s+java\.|\bpackage\s+\w+;",
         "java",       "jvm",       "java_source",        2),
        # Kotlin markers
        (r"\bfun \w+\(|\bval \w+|\bvar \w+|\bobject \w+",
         "kotlin",     "android",   "kotlin_source",      2),
        # Smali markers
        (r"\.class\s+\w|\\.method\s|\\.field\s|\binvoke-virtual\b",
         "smali",      "android",   "android_smali",      2),
        # Shell markers
        (r"\bif\s+\[|\bfi\b|\becho\b|\$\{?\w+\}?|\bexport\s+\w+=",
         "shell",      "shell",     "shell_script",       2),
        # XML/HTML markers
        (r"<\?xml\s|<!DOCTYPE\s|<html[\s>]|<head[\s>]|<body[\s>]",
         "xml",        "markup",    "markup_document",    1),
        # JSON markers
        (r'^\s*[\[{].*[\]}]\s*$',
         "json",       "data",      "json_data",          1),
        # YAML markers
        (r"^---\s*$|^\w[\w_-]*:\s+\S",
         "yaml",       "data",      "yaml_config",        2),
        # TOML markers
        (r"^\[[\w\.]+\]$|^\w+\s*=\s*",
         "toml",       "data",      "toml_config",        2),
        # SQL markers
        (r"\bSELECT\b|\bINSERT\s+INTO\b|\bCREATE\s+TABLE\b|\bDROP\s+TABLE\b",
         "sql",        "data",      "sql_script",         1),
        # JavaScript markers
        (r"\bconst\s+\w+\s*=|\bfunction\s+\w+\s*\(|\b=>\s*\{|\brequire\s*\(",
         "javascript", "web",       "javascript_source",  2),
        # TypeScript markers
        (r"\binterface\s+\w+|\btype\s+\w+\s*=|\bexport\s+(?:class|interface|type)\b",
         "typescript", "web",       "typescript_source",  2),
        # Rust markers
        (r"\bfn\s+\w+\s*\(|\blet\s+mut\s|\bimpl\s+\w+|\buse\s+std::",
         "rust",       "systems",   "rust_source",        2),
        # Go markers
        (r"\bpackage\s+\w+\b|\bfunc\s+\w+\s*\(|\bimport\s+\(",
         "go",         "systems",   "go_source",          2),
        # C/C++ markers
        (r"#include\s+[<\"]|\bprintf\s*\(|\bstd::\w+|\bvoid\s+\w+\s*\(",
         "cpp",        "systems",   "c_cpp_source",       2),
        # Makefile / build markers
        (r"^\w[\w/\.\-]*\s*:\s*[\w/\.\-]*|^\t[\$@]",
         "makefile",   "shell",     "build_script",       2),
        # Gradle / Groovy markers
        (r"\bapply\s+plugin:|dependencies\s*\{|implementation\s+['\"]",
         "groovy",     "jvm",       "gradle_build",       2),
        # Proto / protobuf
        (r"\bsyntax\s*=\s*['\"]proto|\bmessage\s+\w+\s*\{|\bservice\s+\w+\s*\{",
         "protobuf",   "data",      "protobuf_schema",    1),
        # Dockerfile
        (r"^FROM\s+\w|^RUN\s+|^COPY\s+|^CMD\s+|^ENTRYPOINT\s+",
         "dockerfile", "shell",     "docker_config",      2),
        # INI/cfg markers
        (r"^\[[\w\s]+\]\s*$|^\w+\s*=\s*\S",
         "ini",        "data",      "config_file",        3),
        # Markdown markers
        (r"^#+\s+\w|^\*\*\w|\[.+\]\(.+\)|^---$",
         "markdown",   "markup",    "documentation",      2),
        # Gradle Kotlin DSL
        (r"\bplugins\s*\{|\bkotlin\s*\(|\bdependencies\s*\{",
         "kotlin",     "jvm",       "gradle_kts",         2),
        # Assembly markers
        (r"\bsection\s+\.text\b|\bdb\s+\d|\bpush\s+\w+|\bpop\s+\w+|\bmov\s+\w+",
         "assembly",   "systems",   "assembly_source",    2),
        # Swift markers
        (r"\bimport\s+Foundation|\bvar\s+\w+:\s*\w+|\bfunc\s+\w+\s*\(",
         "swift",      "mobile",    "swift_source",       2),
        # Dart markers
        (r"\bvoid\s+main\s*\(\)|\bimport\s+'dart:|\bclass\s+\w+\s+extends\b",
         "dart",       "mobile",    "dart_source",        2),
        # Elixir markers
        (r"\bdefmodule\s+\w|\bdef\s+\w+\s*\(|\bdo\b.*\bend\b",
         "elixir",     "scripting", "elixir_source",      2),
        # Certificate / PEM
        (r"-----BEGIN\s+\w[\w\s]*-----",
         "pem",        "data",      "cryptographic_cert", 1),
        # CSV heuristic
        (r"^[^\n,]+,[^\n,]+,[^\n,]+",
         "csv",        "data",      "tabular_data",       1),
    ]

    def sniff(self, fpath: str, fname: str) -> Tuple[str, str, str, bool]:
        """
        Returns (lang, family, purpose, is_binary).
        Never raises — always produces a result.
        """
        ext = Path(fname).suffix.lower()

        # 1. Read raw bytes for magic detection
        try:
            with open(fpath, "rb") as f:
                raw = f.read(512)
        except Exception:
            return "unknown_binary", "binary", "unreadable_file", True

        # 2. Magic bytes
        for magic, lang, fam, purpose in self._MAGIC:
            if raw.startswith(magic) or magic in raw[:len(magic)+4]:
                _register_unknown_ext(ext, lang, fam, purpose)
                return lang, fam, purpose, True

        # 3. High non-printable byte ratio → treat as binary
        non_print = sum(1 for b in raw if b < 9 or (13 < b < 32) or b == 127)
        if len(raw) > 0 and non_print / len(raw) > 0.15:
            purpose = f"unknown_binary_{ext.lstrip('.') or 'noext'}"
            _register_unknown_ext(ext, "unknown_binary", "binary", purpose)
            return "unknown_binary", "binary", purpose, True

        # 4. Decode as text
        try:
            text = raw.decode("utf-8", errors="replace")
            # also read full file for keyword matching
            with open(fpath, encoding="utf-8", errors="replace") as f:
                full = f.read(8192)
        except Exception:
            purpose = f"unknown_text_{ext.lstrip('.') or 'noext'}"
            _register_unknown_ext(ext, "unknown_text", "general", purpose)
            return "unknown_text", "general", purpose, False

        # 5. Shebang line
        first_line = full.splitlines()[0] if full.splitlines() else ""
        if first_line.startswith("#!"):
            for interp, (lang, fam, purpose) in self._SHEBANG.items():
                if interp in first_line:
                    _register_unknown_ext(ext, lang, fam, purpose)
                    return lang, fam, purpose, False
            # Unknown shebang interpreter
            interp_name = re.search(r"#!.*?/([a-zA-Z0-9_]+)", first_line)
            if interp_name:
                lang = f"script_{interp_name.group(1)}"
                purpose = f"script_using_{interp_name.group(1)}"
                _register_unknown_ext(ext, lang, "shell", purpose)
                return lang, "shell", purpose, False

        # 6. Keyword density scoring
        best_lang, best_fam, best_purpose, best_score = "unknown_text", "general", "unknown_text_file", 0
        for pat, lang, fam, purpose, min_hits in self._KEYWORD_RULES:
            hits = len(re.findall(pat, full, re.MULTILINE | re.IGNORECASE))
            if hits >= min_hits and hits > best_score:
                best_lang, best_fam, best_purpose, best_score = lang, fam, purpose, hits

        # 7. Extension-name heuristics (no content clues found)
        if best_score == 0:
            ext_bare = ext.lstrip(".")
            ext_map_guess = {
                "gen":    ("python",   "scripting", "generated_python_source"),
                "tpl":    ("text",     "markup",    "template_file"),
                "tmpl":   ("text",     "markup",    "template_file"),
                "jinja":  ("text",     "markup",    "jinja_template"),
                "j2":     ("text",     "markup",    "jinja2_template"),
                "erb":    ("ruby",     "scripting", "ruby_erb_template"),
                "lock":   ("toml",     "data",      "dependency_lockfile"),
                "gradle": ("groovy",   "jvm",       "gradle_build_file"),
                "pro":    ("makefile", "shell",     "project_build_file"),
                "mk":     ("makefile", "shell",     "makefile_fragment"),
                "patch":  ("text",     "markup",    "diff_patch_file"),
                "diff":   ("text",     "markup",    "diff_patch_file"),
                "pem":    ("pem",      "data",      "cryptographic_cert"),
                "crt":    ("pem",      "data",      "x509_certificate"),
                "key":    ("pem",      "data",      "private_key"),
                "pub":    ("pem",      "data",      "public_key"),
                "pp":     ("pascal",   "systems",   "pascal_source"),
                "pas":    ("pascal",   "systems",   "pascal_source"),
                "vb":     ("vbasic",   "scripting", "vbasic_source"),
                "m":      ("objc",     "mobile",    "objective_c_source"),
                "mm":     ("objc",     "mobile",    "objective_cpp_source"),
                "nim":    ("nim",      "scripting", "nim_source"),
                "cr":     ("crystal",  "scripting", "crystal_source"),
                "zig":    ("zig",      "systems",   "zig_source"),
                "v":      ("vlang",    "systems",   "vlang_source"),
                "tf":     ("hcl",      "data",      "terraform_config"),
                "hcl":    ("hcl",      "data",      "hashicorp_config"),
                "nix":    ("nix",      "data",      "nix_expression"),
                "cmake":  ("cmake",    "shell",     "cmake_build"),
                "bazel":  ("starlark", "shell",     "bazel_build"),
                "bzl":    ("starlark", "shell",     "bazel_build"),
                "wasm":   ("wasm",     "binary",    "webassembly_binary"),
                "wat":    ("wat",      "systems",   "webassembly_text"),
                "capnp":  ("capnproto","data",      "capnproto_schema"),
                "thrift": ("thrift",   "data",      "thrift_schema"),
                "avsc":   ("json",     "data",      "avro_schema"),
                "jsonl":  ("json",     "data",      "jsonlines_data"),
                "ndjson": ("json",     "data",      "ndjson_data"),
                "snap":   ("text",     "data",      "jest_snapshot"),
                "md5":    ("text",     "data",      "checksum_file"),
                "sha256": ("text",     "data",      "checksum_file"),
                "spec":   ("text",     "markup",    "specification_doc"),
                "feature":("gherkin",  "markup",    "bdd_feature_file"),
                "rspec":  ("ruby",     "scripting", "rspec_test"),
            }
            if ext_bare in ext_map_guess:
                best_lang, best_fam, best_purpose = ext_map_guess[ext_bare]
            else:
                # Last resort: describe based on readable content
                if len(full.strip()) > 0:
                    best_purpose = f"readable_text_{ext_bare or 'noext'}"
                else:
                    best_purpose = f"empty_file_{ext_bare or 'noext'}"

        _register_unknown_ext(ext, best_lang, best_fam, best_purpose)
        return best_lang, best_fam, best_purpose, False


_sniffer = UnknownFileSniffer()


def _get_family(lang: str) -> str:
    for fam, langs in LANG_FAMILIES.items():
        if lang in langs:
            return fam
    return "general"


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class FunctionSemantics:
    name:             str
    start_line:       int
    line_count:       int
    param_count:      int
    is_pure:          bool
    is_generator:     bool
    is_async:         bool
    is_recursive:     bool
    is_property:      bool
    is_classmethod:   bool
    is_staticmethod:  bool
    side_effects:     List[str]
    cognitive_complexity: int
    cyclomatic:       int
    fan_in:           int
    fan_out:          int
    internal_callees: List[str]
    raises:           List[str]
    handles:          List[str]
    has_docstring:    bool
    return_style:     str


@dataclass
class SemanticModel:
    language:            str
    file_path:           str
    analysis_depth:      str
    function_map:        Dict[str, FunctionSemantics]
    pure_functions:      List[str]
    impure_functions:    List[str]
    dead_functions:      List[str]
    recursive_fns:       List[str]
    async_fns:           List[str]
    generator_fns:       List[str]
    entry_points:        List[str]
    call_graph:          Dict[str, List[str]]
    call_chains:         List[List[str]]
    max_chain_depth:     int
    does_io:             bool
    does_network:        bool
    does_db:             bool
    does_subprocess:     bool
    does_threading:      bool
    does_crypto:         bool
    does_eval:           bool
    global_state:        List[str]
    total_cognitive:     int
    avg_cognitive:       float
    max_cognitive_fn:    str
    max_cognitive:       int
    cyclomatic_total:    int
    halstead_volume:     float
    halstead_difficulty: float
    halstead_effort:     float
    maintainability:     float
    taint_sources:       List[str]
    taint_sinks:         List[str]
    taint_paths:         List[str]
    behavioral_role:     str
    role_confidence:     float
    role_signals:        List[str]
    functions:           List[str]
    classes:             List[str]
    imports:             List[str]
    exports:             List[str]
    routes:              List[str]
    error_handler_count: int
    has_tests:           bool
    line_count:          int
    zeus_imports:        List[str]
    blueprint_name:      str
    flask_routes:        List[str]
    parse_error:         str


@dataclass
class CodeUnit:
    file_path:  str
    file_name:  str
    language:   str
    family:     str
    size_bytes: int
    source:     str
    file_hash:  str
    source_tag: str


@dataclass
class MasteryRecord:
    file_path:        str
    file_name:        str
    language:         str
    family:           str
    file_hash:        str
    source_tag:       str
    depths_done:      List[str]
    confidence:       float
    last_updated:     str
    mastery_complete: bool


# ============================================================================
# DATABASE LAYER
# ============================================================================

class CodeLearnerDB:
    _RETRIES    = 5
    _RETRY_BASE = 0.15

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA busy_timeout=20000")
        return conn

    def _retry(self, fn):
        last_err = None
        for attempt in range(self._RETRIES):
            conn = self._conn()
            try:
                result = fn(conn)
                conn.close()
                return result
            except sqlite3.OperationalError as e:
                conn.close()
                last_err = e
                if attempt < self._RETRIES - 1:
                    time.sleep(self._RETRY_BASE * (2 ** attempt))
            except Exception as e:
                conn.close()
                raise
        raise last_err

    def ensure_schema(self):
        def _do(conn):
            conn.execute("""
                CREATE TABLE IF NOT EXISTS code_intelligence (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path     TEXT    NOT NULL UNIQUE,
                    file_name     TEXT    NOT NULL DEFAULT '',
                    language      TEXT    NOT NULL DEFAULT '',
                    family        TEXT    NOT NULL DEFAULT '',
                    file_hash     TEXT    NOT NULL DEFAULT '',
                    source_tag    TEXT    NOT NULL DEFAULT '',
                    depths_done   TEXT    NOT NULL DEFAULT '[]',
                    confidence    REAL    NOT NULL DEFAULT 0.0,
                    semantic_json TEXT    NOT NULL DEFAULT '{}',
                    mastery_done  INTEGER NOT NULL DEFAULT 0,
                    last_analyzed TEXT    DEFAULT (datetime('now'))
                )
            """)
            for idx in (
                "CREATE INDEX IF NOT EXISTS idx_ci_lang    ON code_intelligence(language)",
                "CREATE INDEX IF NOT EXISTS idx_ci_family  ON code_intelligence(family)",
                "CREATE INDEX IF NOT EXISTS idx_ci_conf    ON code_intelligence(confidence DESC)",
                "CREATE INDEX IF NOT EXISTS idx_ci_mastery ON code_intelligence(mastery_done)",
                "CREATE INDEX IF NOT EXISTS idx_ci_tag     ON code_intelligence(source_tag)",
            ):
                conn.execute(idx)
            conn.commit()
        self._retry(_do)

    def upsert(self, rec: MasteryRecord, model: SemanticModel):
        try:
            model_d = {
                "language":          model.language,
                "analysis_depth":    model.analysis_depth,
                "behavioral_role":   model.behavioral_role,
                "role_confidence":   model.role_confidence,
                "role_signals":      model.role_signals,
                "pure_functions":    model.pure_functions,
                "impure_functions":  model.impure_functions[:30],
                "dead_functions":    model.dead_functions,
                "recursive_fns":     model.recursive_fns,
                "async_fns":         model.async_fns,
                "entry_points":      model.entry_points,
                "call_chains":       model.call_chains[:6],
                "max_chain_depth":   model.max_chain_depth,
                "does_io":           model.does_io,
                "does_network":      model.does_network,
                "does_db":           model.does_db,
                "does_subprocess":   model.does_subprocess,
                "does_threading":    model.does_threading,
                "does_crypto":       model.does_crypto,
                "does_eval":         model.does_eval,
                "global_state":      model.global_state,
                "total_cognitive":   model.total_cognitive,
                "avg_cognitive":     model.avg_cognitive,
                "max_cognitive_fn":  model.max_cognitive_fn,
                "max_cognitive":     model.max_cognitive,
                "cyclomatic_total":  model.cyclomatic_total,
                "halstead_volume":   model.halstead_volume,
                "halstead_difficulty": model.halstead_difficulty,
                "halstead_effort":   model.halstead_effort,
                "maintainability":   model.maintainability,
                "taint_sources":     model.taint_sources,
                "taint_sinks":       model.taint_sinks,
                "taint_paths":       model.taint_paths,
                "functions":         model.functions[:40],
                "classes":           model.classes[:20],
                "imports":           model.imports[:30],
                "routes":            model.routes,
                "zeus_imports":      model.zeus_imports,
                "blueprint_name":    model.blueprint_name,
                "line_count":        model.line_count,
                "error_handler_count": model.error_handler_count,
                "has_tests":         model.has_tests,
                "parse_error":       model.parse_error,
                "fn_detail": {
                    fn: {
                        "is_pure":      s.is_pure,
                        "is_async":     s.is_async,
                        "is_recursive": s.is_recursive,
                        "side_effects": s.side_effects,
                        "cognitive":    s.cognitive_complexity,
                        "cyclomatic":   s.cyclomatic,
                        "fan_in":       s.fan_in,
                        "fan_out":      s.fan_out,
                        "callees":      s.internal_callees[:5],
                        "raises":       s.raises[:3],
                        "handles":      s.handles[:3],
                        "lines":        s.line_count,
                        "has_doc":      s.has_docstring,
                        "return_style": s.return_style,
                    }
                    for fn, s in sorted(
                        model.function_map.items(),
                        key=lambda kv: kv[1].cognitive_complexity,
                        reverse=True,
                    )[:20]
                },
            }
            sem_json = json.dumps(model_d)[:300000]
        except Exception:
            sem_json = "{}"

        def _do(conn):
            conn.execute("""
                INSERT INTO code_intelligence
                    (file_path, file_name, language, family, file_hash, source_tag,
                     depths_done, confidence, semantic_json, mastery_done, last_analyzed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
                ON CONFLICT(file_path) DO UPDATE SET
                    file_name     = excluded.file_name,
                    file_hash     = excluded.file_hash,
                    source_tag    = excluded.source_tag,
                    depths_done   = excluded.depths_done,
                    confidence    = excluded.confidence,
                    semantic_json = excluded.semantic_json,
                    mastery_done  = excluded.mastery_done,
                    last_analyzed = datetime('now')
            """, (
                rec.file_path, rec.file_name, rec.language, rec.family,
                rec.file_hash, rec.source_tag,
                json.dumps(rec.depths_done), round(rec.confidence, 6),
                sem_json, 1 if rec.mastery_complete else 0,
            ))
            conn.commit()
        self._retry(_do)

    def get_record(self, file_path: str) -> Optional[Dict]:
        def _do(conn):
            row = conn.execute(
                "SELECT * FROM code_intelligence WHERE file_path = ?", (file_path,)
            ).fetchone()
            return dict(row) if row else None
        return self._retry(_do)

    def get_stats(self) -> Dict:
        def _do(conn):
            total    = conn.execute("SELECT COUNT(*) FROM code_intelligence").fetchone()[0]
            mastered = conn.execute(
                "SELECT COUNT(*) FROM code_intelligence WHERE mastery_done=1"
            ).fetchone()[0]
            avg_conf = conn.execute(
                "SELECT AVG(confidence) FROM code_intelligence"
            ).fetchone()[0] or 0.0
            by_lang  = conn.execute(
                "SELECT language, COUNT(*), AVG(confidence) FROM code_intelligence "
                "GROUP BY language ORDER BY COUNT(*) DESC LIMIT 20"
            ).fetchall()
            return {
                "total":          total,
                "mastered":       mastered,
                "avg_confidence": round(avg_conf, 4),
                "by_language": [
                    {"lang": r[0], "count": r[1], "avg_confidence": round(r[2] or 0, 4)}
                    for r in by_lang
                ],
            }
        return self._retry(_do)

    def query_records(self, language: str = "", family: str = "", limit: int = 50) -> List[Dict]:
        def _do(conn):
            if language:
                rows = conn.execute(
                    "SELECT file_path,file_name,language,family,confidence,mastery_done,"
                    "depths_done,last_analyzed FROM code_intelligence "
                    "WHERE language=? ORDER BY confidence DESC LIMIT ?", (language, limit)
                ).fetchall()
            elif family:
                rows = conn.execute(
                    "SELECT file_path,file_name,language,family,confidence,mastery_done,"
                    "depths_done,last_analyzed FROM code_intelligence "
                    "WHERE family=? ORDER BY confidence DESC LIMIT ?", (family, limit)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT file_path,file_name,language,family,confidence,mastery_done,"
                    "depths_done,last_analyzed FROM code_intelligence "
                    "ORDER BY confidence DESC LIMIT ?", (limit,)
                ).fetchall()
            return [dict(r) for r in rows]
        return self._retry(_do)

    def get_semantic(self, file_path: str) -> Dict:
        def _do(conn):
            row = conn.execute(
                "SELECT semantic_json FROM code_intelligence WHERE file_path=?", (file_path,)
            ).fetchone()
            if row:
                try:
                    return json.loads(row[0])
                except Exception:
                    return {}
            return {}
        return self._retry(_do)

    def save_knowledge(self, topic: str, depth: str, content: str,
                       confidence: float, domain: str = "code_intelligence"):
        def _do(conn):
            conn.execute("""
                INSERT OR IGNORE INTO knowledge
                    (topic, depth, content, source_url, confidence, domain)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (topic, depth, content[:20000], "zeus_code_learner", confidence, domain))
            conn.commit()
        try:
            self._retry(_do)
        except Exception as e:
            log.warning(f"[CodeLearner] knowledge save: {e}")

    def save_genome(self, name: str, description: str, module_type: str,
                    capabilities: str, source_code: str, priority: int = 60):
        def _do(conn):
            conn.execute("""
                INSERT OR IGNORE INTO genome
                    (name, description, module_type, source_code, priority, capabilities)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (name, description[:400], module_type,
                  source_code[:10000], priority, capabilities))
            conn.commit()
        try:
            self._retry(_do)
        except Exception as e:
            log.warning(f"[CodeLearner] genome save: {e}")

    def get_genome_sources(self) -> List[Dict]:
        def _do(conn):
            rows = conn.execute("""
                SELECT name, description, module_type, source_code, capabilities
                FROM genome WHERE source_code != '' AND LENGTH(source_code) > 50
                ORDER BY priority DESC LIMIT 200
            """).fetchall()
            return [dict(r) for r in rows]
        return self._retry(_do)


_db = CodeLearnerDB()


# ============================================================================
# AST VISITORS — Python-only deep semantic extraction
# ============================================================================

class _CallGraphVisitor(ast.NodeVisitor):
    """
    Intra-file call graph, per-function side effect profiles, taint flows,
    exception maps, generator/property/async markers, return-style detection.
    Uses a scope stack so nested definitions stay correctly attributed.
    """

    _IO_FNS:     Set[str] = {"open","print","write","read","readline","readlines",
                              "writelines","flush","seek","tell"}
    _NET_FNS:    Set[str] = {"get","post","put","delete","patch","head","request",
                              "urlopen","urlretrieve","connect","send","recv","sendall",
                              "create_connection","socket"}
    _DB_FNS:     Set[str] = {"execute","executemany","executescript","commit",
                              "rollback","fetchone","fetchall","fetchmany","cursor"}
    _PROC_FNS:   Set[str] = {"call","run","Popen","system","popen",
                              "check_output","check_call","getoutput"}
    _THREAD_FNS: Set[str] = {"Thread","Process","start","join","Lock","RLock",
                              "Event","Semaphore","Condition","Timer",
                              "ThreadPoolExecutor","ProcessPoolExecutor"}
    _CRYPTO_FNS: Set[str] = {"md5","sha1","sha256","sha512","pbkdf2_hmac",
                              "encrypt","decrypt","sign","verify","Cipher","AES",
                              "RSA","HMAC","new"}
    _EVAL_FNS:   Set[str] = {"eval","exec","compile","__import__"}
    _TAINT_SRC:  Set[str] = {"get_json","get_data","args","form","files","input",
                              "argv","environ","fetchone","fetchall","fetchmany",
                              "readline","read"}
    _TAINT_SNK:  Set[str] = {"eval","exec","system","Popen","run","call",
                              "execute","executemany","check_output","write"}

    def __init__(self, defined_fns: Set[str]):
        self.defined_fns    = defined_fns
        self._stack:         List[str]            = []
        self.call_graph:     Dict[str, List[str]] = {}
        self.side_effects:   Dict[str, Set[str]]  = defaultdict(set)
        self.raises_map:     Dict[str, Set[str]]  = defaultdict(set)
        self.handles_map:    Dict[str, Set[str]]  = defaultdict(set)
        self.is_recursive:   Set[str]             = set()
        self.is_generator:   Set[str]             = set()
        self.is_property:    Set[str]             = set()
        self.is_clsmethod:   Set[str]             = set()
        self.is_static:      Set[str]             = set()
        self.return_styles:  Dict[str, str]       = {}
        self.fn_lines:       Dict[str, Tuple[int,int]] = {}
        self.fn_params:      Dict[str, int]       = {}
        self.fn_docs:        Dict[str, bool]      = {}
        self.fn_async:       Set[str]             = set()
        self.globals_written: Set[str]            = set()
        self.module_globals:  Set[str]            = set()
        self.taint_src_fn:   Dict[str, List[str]] = defaultdict(list)
        self.taint_sink_fn:  Dict[str, List[str]] = defaultdict(list)

    def _cur(self) -> str:
        return self._stack[-1] if self._stack else "__module__"

    def visit_FunctionDef(self, node: ast.FunctionDef):
        name = node.name
        self._stack.append(name)
        self.call_graph.setdefault(name, [])
        self.fn_lines[name]  = (node.lineno, getattr(node, "end_lineno", node.lineno))
        self.fn_params[name] = len(node.args.args)
        self.fn_docs[name]   = bool(ast.get_docstring(node))
        if isinstance(node, ast.AsyncFunctionDef):
            self.fn_async.add(name)
        for dec in node.decorator_list:
            dec_id = ""
            if isinstance(dec, ast.Name):       dec_id = dec.id
            elif isinstance(dec, ast.Attribute): dec_id = dec.attr
            if dec_id == "property":             self.is_property.add(name)
            elif dec_id == "classmethod":        self.is_clsmethod.add(name)
            elif dec_id == "staticmethod":       self.is_static.add(name)
        has_ret = has_yield = has_yield_from = False
        for n in ast.walk(node):
            if isinstance(n, ast.Return) and n.value is not None: has_ret = True
            if isinstance(n, ast.Yield):      has_yield = True;      self.is_generator.add(name)
            if isinstance(n, ast.YieldFrom):  has_yield_from = True; self.is_generator.add(name)
        if has_yield or has_yield_from:   self.return_styles[name] = "yields"
        elif has_ret:                      self.return_styles[name] = "sometimes"
        else:                              self.return_styles[name] = "never"
        self.generic_visit(node)
        self._stack.pop()

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_Global(self, node: ast.Global):
        cur = self._cur()
        for n in node.names:
            self.globals_written.add(n)
            self.side_effects[cur].add("global_write")

    def visit_Assign(self, node: ast.Assign):
        if not self._stack:
            for t in node.targets:
                if isinstance(t, ast.Name):
                    self.module_globals.add(t.id)
        self.generic_visit(node)

    def visit_Raise(self, node: ast.Raise):
        cur = self._cur()
        if node.exc:
            exc = ""
            if isinstance(node.exc, ast.Name):
                exc = node.exc.id
            elif isinstance(node.exc, ast.Call) and isinstance(node.exc.func, ast.Name):
                exc = node.exc.func.id
            if exc: self.raises_map[cur].add(exc)
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler):
        cur = self._cur()
        if node.type:
            if isinstance(node.type, ast.Name):
                self.handles_map[cur].add(node.type.id)
            elif isinstance(node.type, ast.Tuple):
                for e in node.type.elts:
                    if isinstance(e, ast.Name): self.handles_map[cur].add(e.id)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        cur    = self._cur()
        callee = self._resolve(node)
        if callee:
            if callee in self.defined_fns:
                if callee not in self.call_graph.get(cur, []):
                    self.call_graph.setdefault(cur, []).append(callee)
                if callee == cur: self.is_recursive.add(cur)
            self._classify(cur, callee)
        self.generic_visit(node)

    def _resolve(self, node: ast.Call) -> Optional[str]:
        if isinstance(node.func, ast.Name):      return node.func.id
        if isinstance(node.func, ast.Attribute): return node.func.attr
        return None

    def _classify(self, fn: str, callee: str):
        if callee in self._IO_FNS:      self.side_effects[fn].add("io")
        if callee in self._NET_FNS:     self.side_effects[fn].add("network")
        if callee in self._DB_FNS:      self.side_effects[fn].add("db")
        if callee in self._PROC_FNS:    self.side_effects[fn].add("subprocess")
        if callee in self._THREAD_FNS:  self.side_effects[fn].add("threading")
        if callee in self._CRYPTO_FNS:  self.side_effects[fn].add("crypto")
        if callee in self._EVAL_FNS:
            self.side_effects[fn].add("eval")
            self.taint_sink_fn[fn].append(callee)
        if callee in self._TAINT_SRC:   self.taint_src_fn[fn].append(callee)
        if callee in self._TAINT_SNK:   self.taint_sink_fn[fn].append(callee)


class _CognitiveComplexity:
    """
    Nesting-weighted cognitive complexity per function.
    Each branch at depth D costs 1+D. Boolean ops and break/continue cost 1.
    Nested function definitions add 1 hybrid increment.
    """

    _STRUCTURAL = (ast.If, ast.For, ast.While, ast.Try, ast.With)

    @staticmethod
    def compute(tree: ast.AST) -> Dict[str, int]:
        scores: Dict[str, int] = {}
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                scores[node.name] = _CognitiveComplexity._score(node)
        return scores

    @staticmethod
    def _score(fn_node: ast.AST) -> int:
        score = [0]
        depth = [0]

        def _walk(node: ast.AST):
            if isinstance(node, _CognitiveComplexity._STRUCTURAL):
                score[0] += 1 + depth[0]
                depth[0] += 1
                for child in ast.iter_child_nodes(node): _walk(child)
                depth[0] -= 1
                return
            if isinstance(node, ast.ExceptHandler): score[0] += 1
            if isinstance(node, ast.BoolOp):        score[0] += 1
            if isinstance(node, (ast.Break, ast.Continue)): score[0] += 1
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node is not fn_node:
                    score[0] += 1
                    depth[0] += 1
                    for child in ast.iter_child_nodes(node): _walk(child)
                    depth[0] -= 1
                    return
            for child in ast.iter_child_nodes(node): _walk(child)

        _walk(fn_node)
        return score[0]


class _Halstead:
    """Counts AST operators/operands → Volume, Difficulty, Effort."""

    def __init__(self):
        self._ops:  Counter = Counter()
        self._opds: Counter = Counter()

    def visit(self, tree: ast.AST):
        for node in ast.walk(tree): self._process(node)

    def _process(self, node: ast.AST):
        if isinstance(node, (ast.BinOp, ast.UnaryOp)):
            self._ops[type(node.op).__name__] += 1
        elif isinstance(node, ast.BoolOp):
            self._ops[type(node.op).__name__] += 1
        elif isinstance(node, ast.Compare):
            for op in node.ops: self._ops[type(op).__name__] += 1
        elif isinstance(node, ast.Call):       self._ops["()"]     += 1
        elif isinstance(node, ast.Subscript):  self._ops["[]"]     += 1
        elif isinstance(node, ast.Attribute):  self._ops["."]      += 1
        elif isinstance(node, ast.Assign):     self._ops["="]      += 1
        elif isinstance(node, ast.AugAssign):  self._ops[f"+={type(node.op).__name__}"] += 1
        elif isinstance(node, ast.Return):     self._ops["return"] += 1
        elif isinstance(node, ast.Yield):      self._ops["yield"]  += 1
        elif isinstance(node, ast.If):         self._ops["if"]     += 1
        elif isinstance(node, ast.For):        self._ops["for"]    += 1
        elif isinstance(node, ast.While):      self._ops["while"]  += 1
        elif isinstance(node, ast.With):       self._ops["with"]   += 1
        elif isinstance(node, ast.Try):        self._ops["try"]    += 1
        elif isinstance(node, ast.Name):
            self._opds[node.id] += 1
        elif isinstance(node, ast.Constant):
            self._opds[repr(node.value)[:25]] += 1

    def metrics(self) -> Dict[str, float]:
        n1 = len(self._ops);  N1 = sum(self._ops.values())
        n2 = len(self._opds); N2 = sum(self._opds.values())
        n  = n1 + n2;         N  = N1 + N2
        if n < 2 or n2 == 0:
            return {"volume": 0.0, "difficulty": 0.0, "effort": 0.0}
        vol  = N  * math.log2(n)
        diff = (n1 / 2.0) * (N2 / n2)
        eff  = vol * diff
        return {
            "volume":     round(vol,  2),
            "difficulty": round(diff, 2),
            "effort":     round(eff,  2),
        }


# ============================================================================
# BEHAVIORAL CLASSIFIER
# ============================================================================

class _BehavioralClassifier:
    """
    Multi-signal behavioral role classification for all languages.
    Function names + class names + imports + side effects + src keywords → role.
    """

    _ROLE_KEYWORDS: Dict[str, List[str]] = {
        "evolution_engine":   ["evolv", "audit", "gap", "merge", "mutation", "ModuleAudit"],
        "learning_engine":    ["learn", "curriculum", "depth", "mastery", "knowledge", "queue", "topic"],
        "analysis_engine":    ["analys", "pars", "inspect", "extract", "detect", "SemanticModel"],
        "flask_service":      ["Blueprint", "route", "jsonify", "request", "flask"],
        "data_layer":         ["execute", "fetchall", "commit", "sqlite3", "get_db", "WAL"],
        "worker_service":     ["ThreadPoolExecutor", "Queue", "daemon", "run_continuous", "loop", "worker"],
        "forge_engine":       ["forge", "generat", "build", "compil", "scaffold", "template"],
        "mutation_engine":    ["mutat", "breed", "crossover", "genome", "offspring"],
        "prediction_engine":  ["predict", "forecast", "probabilit", "model", "infer", "signal"],
        "execution_sandbox":  ["sandbox", "timeout", "isolat", "captur", "proc"],
        "synthesis_engine":   ["synthes", "blueprint", "architect", "design", "plan"],
        "scheduler":          ["schedule", "cron", "nightly", "timer", "interval", "sleep"],
        "upload_handler":     ["upload", "multipart", "stream", "EXT_MAP", "extension"],
        "apk_engine":         ["apk", "apktool", "dex", "smali", "manifest"],
        "test_suite":         ["test_", "assert", "pytest", "unittest", "spec_", "fixture"],
        "genome_manager":     ["genome", "lineage", "fitness", "dna", "segment"],
        "chat_interface":     ["chat", "conversation", "session", "message", "voice", "push_to_talk"],
        "router_engine":      ["router", "groq", "circuit", "breaker", "fallback", "confidence"],
        "stealth_engine":     ["stealth", "integrity", "anti_debug", "vault", "watchdog"],
        "code_intelligence":  ["code_learn", "semantic", "CallGraph", "Halstead", "cognitive"],
        "identity_module":    ["identity", "fingerprint", "signature", "register_self"],
        "logic_engine":       ["LogicFact", "LogicRule", "reason", "infer", "deduce", "unify"],
        "replication_engine": ["replic", "clone", "mirror", "deploy", "distribute"],
    }

    @staticmethod
    def classify(functions: List[str], classes: List[str], imports: List[str],
                 routes: List[str], side_fx: Set[str], src: str = "") -> Tuple[str, float, List[str]]:
        haystack = " ".join(functions + classes + imports) + " " + src[:3000]
        scores:  Dict[str, float]      = defaultdict(float)
        signals: Dict[str, List[str]]  = defaultdict(list)

        for role, kws in _BehavioralClassifier._ROLE_KEYWORDS.items():
            for kw in kws:
                if kw in haystack:
                    scores[role] += 1.0
                    signals[role].append(kw)

        if routes:
            scores["flask_service"] += 2.0
            signals["flask_service"].append(f"{len(routes)}_flask_routes")
        if "threading" in side_fx:
            scores["worker_service"] += 1.5
            signals["worker_service"].append("threading_detected")
        if "db" in side_fx:
            scores["data_layer"] += 0.8
            signals["data_layer"].append("db_writes")
        if "subprocess" in side_fx:
            scores["execution_sandbox"] += 0.8
            signals["execution_sandbox"].append("subprocess_detected")
        if any(fn.lower().startswith("test_") for fn in functions):
            scores["test_suite"] += 3.0
            signals["test_suite"].append("test_functions_present")

        if not scores:
            return "general_utility", 0.40, ["no_dominant_pattern"]
        best  = max(scores, key=lambda r: scores[r])
        total = sum(scores.values())
        conf  = round(min(0.99, scores[best] / max(total * 0.45, 1)), 3)
        return best, conf, signals[best][:8]


# ============================================================================
# PYTHON DEEP SEMANTIC ANALYZER
# ============================================================================

class PythonSemanticAnalyzer:
    """
    Full AST-based semantic analysis. Produces a SemanticModel with:
    call graph, cognitive complexity, Halstead metrics, pure/dead functions,
    taint flows, entry points, call chains, and behavioral role.
    """

    def analyze(self, unit: CodeUnit) -> SemanticModel:
        src = unit.source
        try:
            tree = ast.parse(src)
        except SyntaxError as e:
            return self._empty(unit, f"SyntaxError: {e}")

        defined_fns: Set[str] = {
            n.name for n in ast.walk(tree)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

        cg_vis = _CallGraphVisitor(defined_fns)
        cg_vis.visit(tree)

        cc_scores = _CognitiveComplexity.compute(tree)

        hl = _Halstead()
        hl.visit(tree)
        hl_metrics = hl.metrics()

        classes:  List[str] = []
        fn_list:  List[str] = []
        fn_cyclo: Dict[str, int] = {}
        imports:  List[str] = []
        bp_name:  str = ""
        routes:   List[str] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                classes.append(node.name)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                name = node.name
                fn_list.append(name)
                cc = 1
                for n in ast.walk(node):
                    if isinstance(n, (ast.If, ast.For, ast.While, ast.Try,
                                      ast.ExceptHandler, ast.With)):
                        cc += 1
                    elif isinstance(n, ast.BoolOp):
                        cc += len(n.values) - 1
                fn_cyclo[name] = cc
            elif isinstance(node, ast.Import):
                imports.extend(a.name for a in node.names)
            elif isinstance(node, ast.ImportFrom):
                if node.module: imports.append(node.module)

        # Blueprint name detection
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                if (isinstance(node.value, ast.Call) and
                        isinstance(getattr(node.value.func, "id", None), str) and
                        "Blueprint" in node.value.func.id):
                    if node.targets and isinstance(node.targets[0], ast.Name):
                        bp_name = node.targets[0].id

        # Flask route detection
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for dec in node.decorator_list:
                    if (isinstance(dec, ast.Call) and
                            isinstance(dec.func, ast.Attribute) and
                            dec.func.attr == "route"):
                        for arg in dec.args:
                            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                                routes.append(arg.value)

        imports = list(dict.fromkeys(imports))
        fn_list = list(dict.fromkeys(fn_list))

        # Build call graph and reversal
        call_graph: Dict[str, List[str]] = {
            fn: list(dict.fromkeys(cg_vis.call_graph.get(fn, [])))
            for fn in fn_list
        }
        reverse: Dict[str, List[str]] = defaultdict(list)
        for caller, callees in call_graph.items():
            for callee in callees:
                if caller not in reverse[callee]:
                    reverse[callee].append(caller)

        fan_in  = {fn: len(reverse.get(fn, []))    for fn in fn_list}
        fan_out = {fn: len(call_graph.get(fn, [])) for fn in fn_list}

        # Dead functions: defined, never internally called, not exempted
        called_anywhere: Set[str] = {
            callee for callees in call_graph.values() for callee in callees
        }
        dead_fns: List[str] = [
            fn for fn in fn_list
            if fn not in called_anywhere
            and fn not in _NEVER_DEAD
            and not any(fn.startswith(p) for p in ("route_", "cl_", "on_", "test_"))
        ]

        # Entry points: fan_in == 0
        entry_points: List[str] = [fn for fn in fn_list if fan_in.get(fn, 0) == 0][:12]

        # Pure functions: no side effects, no global writes, not generators
        pure_fns: List[str] = [
            fn for fn in fn_list
            if not cg_vis.side_effects.get(fn)
            and fn not in cg_vis.globals_written
            and fn not in cg_vis.is_generator
        ]
        impure_fns: List[str] = [fn for fn in fn_list if fn not in set(pure_fns)]

        # Call chains via DFS from entry points
        chains: List[List[str]] = []

        def _dfs(fn: str, chain: List[str]):
            if len(chain) > 9 or fn in chain: return
            chain = chain + [fn]
            if len(chain) >= 3: chains.append(chain)
            for callee in call_graph.get(fn, []): _dfs(callee, chain)

        for ep in entry_points[:6]: _dfs(ep, [])

        seen_ch: Set[str] = set()
        unique_chains: List[List[str]] = []
        for ch in sorted(chains, key=len, reverse=True):
            key = "→".join(ch)
            if key not in seen_ch:
                seen_ch.add(key)
                unique_chains.append(ch)
        unique_chains = unique_chains[:8]
        max_chain     = max((len(c) for c in unique_chains), default=0)

        # Complexity metrics
        total_cc = sum(cc_scores.get(fn, 0) for fn in fn_list)
        avg_cc   = round(total_cc / max(len(fn_list), 1), 2)
        max_cc_fn = max(fn_list, key=lambda f: cc_scores.get(f, 0), default="")
        max_cc    = cc_scores.get(max_cc_fn, 0)
        cyc_total = sum(fn_cyclo.values())

        # Maintainability Index (SEI formula)
        vol = hl_metrics["volume"]
        diff = hl_metrics["difficulty"]
        eff  = hl_metrics["effort"]
        loc  = len([l for l in src.splitlines() if l.strip()])
        if vol > 0 and loc > 0:
            mi = max(0.0, (171
                           - 5.2  * math.log(max(vol, 1))
                           - 0.23 * cyc_total
                           - 16.2 * math.log(max(loc, 1))
                           ) * 100.0 / 171.0)
        else:
            mi = 100.0

        # Taint paths
        taint_srcs:  List[str] = []
        taint_snks:  List[str] = []
        taint_paths: List[str] = []
        for fn, srcs in cg_vis.taint_src_fn.items():
            for s in srcs[:2]:
                entry = f"{fn}() ← {s}"
                if entry not in taint_srcs: taint_srcs.append(entry)
        for fn, snks in cg_vis.taint_sink_fn.items():
            for s in snks[:2]:
                entry = f"{fn}() → {s}"
                if entry not in taint_snks: taint_snks.append(entry)
        for fn in fn_list:
            if cg_vis.taint_src_fn.get(fn) and cg_vis.taint_sink_fn.get(fn):
                taint_paths.append(
                    f"{fn}: {cg_vis.taint_src_fn[fn][0]} → {cg_vis.taint_sink_fn[fn][0]}"
                )

        # Module-level side effects
        all_fx: Set[str] = set()
        for fx in cg_vis.side_effects.values(): all_fx.update(fx)

        # Zeus imports
        zeus_imps = [m for m in imports if m.startswith("zeus_") or m in (
            "logic_engine", "db_init", "genome_manager"
        )]

        # Behavioral role
        role, role_conf, role_sigs = _BehavioralClassifier.classify(
            fn_list, classes, imports, routes, all_fx, src
        )

        # Error handler count
        eh_count = sum(1 for n in ast.walk(tree) if isinstance(n, ast.ExceptHandler))
        has_tests = any(fn.lower().startswith(("test_", "spec_")) for fn in fn_list)

        # FunctionSemantics map
        fn_sem: Dict[str, FunctionSemantics] = {}
        for fn in fn_list:
            fx = list(cg_vis.side_effects.get(fn, set()))
            s_line, e_line = cg_vis.fn_lines.get(fn, (0, 0))
            fn_sem[fn] = FunctionSemantics(
                name=fn,
                start_line=s_line,
                line_count=max(0, e_line - s_line + 1),
                param_count=cg_vis.fn_params.get(fn, 0),
                is_pure=(fn in set(pure_fns)),
                is_generator=(fn in cg_vis.is_generator),
                is_async=(fn in cg_vis.fn_async),
                is_recursive=(fn in cg_vis.is_recursive),
                is_property=(fn in cg_vis.is_property),
                is_classmethod=(fn in cg_vis.is_clsmethod),
                is_staticmethod=(fn in cg_vis.is_static),
                side_effects=fx,
                cognitive_complexity=cc_scores.get(fn, 0),
                cyclomatic=fn_cyclo.get(fn, 1),
                fan_in=fan_in.get(fn, 0),
                fan_out=fan_out.get(fn, 0),
                internal_callees=call_graph.get(fn, [])[:8],
                raises=list(cg_vis.raises_map.get(fn, set()))[:5],
                handles=list(cg_vis.handles_map.get(fn, set()))[:5],
                has_docstring=cg_vis.fn_docs.get(fn, False),
                return_style=cg_vis.return_styles.get(fn, "never"),
            )

        exports = (
            [f for f in fn_list if not f.startswith("_")][:20] +
            [c for c in classes if not c.startswith("_")][:10]
        )

        return SemanticModel(
            language="python", file_path=unit.file_path,
            analysis_depth="full_ast",
            function_map=fn_sem,
            pure_functions=pure_fns,
            impure_functions=impure_fns,
            dead_functions=dead_fns,
            recursive_fns=list(cg_vis.is_recursive),
            async_fns=list(cg_vis.fn_async),
            generator_fns=list(cg_vis.is_generator),
            entry_points=entry_points,
            call_graph=call_graph,
            call_chains=unique_chains,
            max_chain_depth=max_chain,
            does_io="io" in all_fx,
            does_network="network" in all_fx,
            does_db="db" in all_fx,
            does_subprocess="subprocess" in all_fx,
            does_threading="threading" in all_fx,
            does_crypto="crypto" in all_fx,
            does_eval="eval" in all_fx,
            global_state=list(cg_vis.module_globals)[:20],
            total_cognitive=total_cc,
            avg_cognitive=avg_cc,
            max_cognitive_fn=max_cc_fn,
            max_cognitive=max_cc,
            cyclomatic_total=cyc_total,
            halstead_volume=vol,
            halstead_difficulty=diff,
            halstead_effort=eff,
            maintainability=round(mi, 1),
            taint_sources=taint_srcs[:10],
            taint_sinks=taint_snks[:10],
            taint_paths=taint_paths[:5],
            behavioral_role=role,
            role_confidence=role_conf,
            role_signals=role_sigs,
            functions=fn_list,
            classes=classes,
            imports=imports[:30],
            exports=exports,
            routes=routes,
            error_handler_count=eh_count,
            has_tests=has_tests,
            line_count=len(src.splitlines()),
            zeus_imports=zeus_imps,
            blueprint_name=bp_name,
            flask_routes=routes,
            parse_error="",
        )

    def _empty(self, unit: CodeUnit, error: str) -> SemanticModel:
        empty_fm: Dict[str, FunctionSemantics] = {}
        return SemanticModel(
            language="python", file_path=unit.file_path,
            analysis_depth="failed", function_map=empty_fm,
            pure_functions=[], impure_functions=[], dead_functions=[],
            recursive_fns=[], async_fns=[], generator_fns=[], entry_points=[],
            call_graph={}, call_chains=[], max_chain_depth=0,
            does_io=False, does_network=False, does_db=False,
            does_subprocess=False, does_threading=False,
            does_crypto=False, does_eval=False, global_state=[],
            total_cognitive=0, avg_cognitive=0.0, max_cognitive_fn="",
            max_cognitive=0, cyclomatic_total=0,
            halstead_volume=0.0, halstead_difficulty=0.0, halstead_effort=0.0,
            maintainability=100.0, taint_sources=[], taint_sinks=[],
            taint_paths=[], behavioral_role="unknown", role_confidence=0.0,
            role_signals=[], functions=[], classes=[], imports=[], exports=[],
            routes=[], error_handler_count=0, has_tests=False,
            line_count=len(unit.source.splitlines()),
            zeus_imports=[], blueprint_name="", flask_routes=[],
            parse_error=error,
        )


# ============================================================================
# SMALI DEEP SEMANTIC ANALYZER
# ============================================================================

class SmaliSemanticAnalyzer:
    """
    Deep semantic analysis of Android Smali bytecode.
    Detects lifecycle roles, dangerous APIs, invoke density, and taint paths.
    """

    _LIFECYCLE: Dict[str, str] = {
        "onCreate": "activity_lifecycle", "onStart": "activity_lifecycle",
        "onResume": "activity_lifecycle", "onPause": "activity_lifecycle",
        "onStop": "activity_lifecycle",   "onDestroy": "activity_lifecycle",
        "onBind": "service_lifecycle",    "onStartCommand": "service_lifecycle",
        "onReceive": "broadcast_receiver",
        "onCreateView": "fragment_lifecycle", "onViewCreated": "fragment_lifecycle",
        "onClick": "ui_handler",          "onTouch": "ui_handler",
        "run": "thread_runnable",         "doInBackground": "async_task",
        "onPostExecute": "async_task",    "query": "content_provider",
        "insert": "content_provider",
    }

    _DANGEROUS: Dict[str, str] = {
        r"Ljava/lang/Runtime;->exec":          "runtime_exec",
        r"DexClassLoader|PathClassLoader":      "dynamic_classloading",
        r"Ljava/lang/reflect":                 "reflection",
        r"Landroid/telephony/SmsManager":      "sms_access",
        r"Landroid/location/LocationManager":  "location_access",
        r"Landroid/hardware/Camera":           "camera_access",
        r"getContentResolver":                 "content_resolver",
        r"Ljavax/crypto":                      "crypto_ops",
        r"/system/bin/su|Runtime.*su":         "root_access",
        r"Ljava/net/URL;->openConnection":     "http_connection",
        r"Landroid/webkit/WebView":            "webview_use",
        r"Landroid/app/admin/DevicePolicyManager": "device_admin",
        r"Landroid/content/pm/PackageInstaller":   "package_install",
    }

    _TAINT_SRC: Set[str] = {"content_resolver", "http_connection"}
    _TAINT_SNK: Set[str] = {"runtime_exec", "dynamic_classloading", "reflection"}

    def analyze(self, unit: CodeUnit) -> SemanticModel:
        src   = unit.source
        lines = src.splitlines()

        methods    = re.findall(r"\.method\s+(?:[\w\s]+)\s+([\w<>$]+)\(", src)
        classes    = re.findall(r"\.class\s+(?:[\w\s]+?)\s+([\w/$]+)", src)
        classes    = [c.split("/")[-1].rstrip(";") for c in classes]
        implements = re.findall(r"\.implements\s+([\w/;]+)", src)
        fields     = re.findall(r"\.field\s+(?:[\w\s]+)\s+([\w$]+):", src)

        lifecycle_hits: List[str] = []
        for m in methods:
            if m in self._LIFECYCLE:
                lifecycle_hits.append(f"{m}:{self._LIFECYCLE[m]}")

        dangerous: List[str] = []
        taint_srcs: List[str] = []
        taint_snks: List[str] = []
        for pat, label in self._DANGEROUS.items():
            if re.search(pat, src):
                dangerous.append(label)
                if label in self._TAINT_SRC: taint_srcs.append(label)
                if label in self._TAINT_SNK: taint_snks.append(label)

        invoke_all    = re.findall(r"\binvoke-(?:virtual|static|direct|interface|super)\b", src)
        invoke_unique = set(re.findall(r"invoke-\w+\s+\{[^}]*\},\s+([\w/$;<>]+)", src))
        branch_count  = len(re.findall(r"\bif-\w+\b", src))
        goto_count    = len(re.findall(r"\bgoto\b", src))

        if any("activity_lifecycle" in h for h in lifecycle_hits):
            role, role_conf = "android_activity", 0.92
        elif any("service_lifecycle" in h for h in lifecycle_hits):
            role, role_conf = "android_service", 0.90
        elif any("broadcast_receiver" in h for h in lifecycle_hits):
            role, role_conf = "android_receiver", 0.88
        elif any("content_provider" in h for h in lifecycle_hits):
            role, role_conf = "android_content_provider", 0.85
        elif "root_access" in dangerous or "dynamic_classloading" in dangerous:
            role, role_conf = "android_privileged_component", 0.80
        else:
            role, role_conf = "android_utility_class", 0.60

        role_sigs = lifecycle_hits[:4] + [f"dangerous:{d}" for d in dangerous[:3]]

        inv_n = len(invoke_all);  inv_u = max(len(invoke_unique), 1)
        vol   = round(inv_n * math.log2(max(inv_u, 2)), 2)
        diff  = round(inv_n / inv_u, 2)
        mi    = max(0.0, 100.0 - len(dangerous) * 8.0 - branch_count * 0.5)
        taint_paths = [f"{s} → {k}" for s in taint_srcs for k in taint_snks][:4]

        empty_fm: Dict[str, FunctionSemantics] = {}
        return SemanticModel(
            language="smali", file_path=unit.file_path,
            analysis_depth="smali_structural",
            function_map=empty_fm,
            pure_functions=[], impure_functions=methods[:30],
            dead_functions=[], recursive_fns=[],
            async_fns=[m for m in methods if m in ("run", "doInBackground")][:5],
            generator_fns=[],
            entry_points=[h.split(":")[0] for h in lifecycle_hits][:6],
            call_graph={}, call_chains=[], max_chain_depth=0,
            does_io=("runtime_exec" in dangerous or "file" in src.lower()),
            does_network="http_connection" in dangerous,
            does_db="content_resolver" in dangerous,
            does_subprocess="runtime_exec" in dangerous,
            does_threading=("run" in methods or "doInBackground" in methods),
            does_crypto="crypto_ops" in dangerous,
            does_eval="dynamic_classloading" in dangerous,
            global_state=fields[:10],
            total_cognitive=branch_count + goto_count,
            avg_cognitive=round((branch_count + goto_count) / max(len(methods), 1), 2),
            max_cognitive_fn="", max_cognitive=branch_count,
            cyclomatic_total=branch_count + 1,
            halstead_volume=vol, halstead_difficulty=diff,
            halstead_effort=round(vol * diff, 2),
            maintainability=round(mi, 1),
            taint_sources=taint_srcs, taint_sinks=taint_snks, taint_paths=taint_paths,
            behavioral_role=role, role_confidence=role_conf, role_signals=role_sigs,
            functions=methods[:50], classes=classes[:20],
            imports=implements[:20], exports=fields[:20], routes=[],
            error_handler_count=src.count("move-exception"),
            has_tests=False, line_count=len(lines),
            zeus_imports=[], blueprint_name="", flask_routes=[],
            parse_error="",
        )


# ============================================================================
# GENERIC SEMANTIC ANALYZER — all other text-based languages
# ============================================================================

class GenericSemanticAnalyzer:
    """
    Deep structural analysis for non-Python text languages.
    Detects functions, classes, recursive calls, async patterns, dead private functions,
    nesting depth, Halstead (token-based), taint, and behavioral role.
    """

    _FUNC: Dict[str, List[str]] = {
        "javascript": [r"function\s+(\w+)\s*\(",
                       r"(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:function|\()"],
        "typescript": [r"function\s+(\w+)\s*\(",
                       r"(?:async\s+)?(\w+)\s*\([^)]*\)\s*(?::\s*[\w<>[\]|]+)?\s*\{"],
        "java":       [r"(?:public|private|protected|static|final|abstract|synchronized)"
                       r"(?:\s+[\w<>\[\]]+)+\s+(\w+)\s*\("],
        "kotlin":     [r"(?:override\s+)?fun\s+(\w+)\s*(?:<[^>]*>)?\s*\("],
        "c":          [r"^(?:[\w\*]+\s+)+(\w+)\s*\([^;{]*\)\s*\{"],
        "cpp":        [r"(?:[\w:~\*&<>\s]+)\s+(\w+)\s*\([^;]*\)\s*(?:const\s*)?\{"],
        "csharp":     [r"(?:public|private|protected|internal|static|override|virtual|abstract)"
                       r"(?:\s+[\w<>\[\]]+)+\s+(\w+)\s*\("],
        "rust":       [r"(?:pub\s+)?(?:async\s+)?fn\s+(\w+)\s*(?:<[^>]*>)?\s*\("],
        "go":         [r"func\s+(?:\([^)]*\)\s+)?(\w+)\s*\("],
        "swift":      [r"(?:func|init)\s+(\w+)\s*(?:<[^>]*>)?\s*\("],
        "ruby":       [r"def\s+(?:self\.)?(\w+)"],
        "php":        [r"function\s+(\w+)\s*\("],
        "shell":      [r"^(\w+)\s*\(\)\s*\{", r"^function\s+(\w+)"],
        "lua":        [r"function\s+(\w+)\s*\(", r"local\s+function\s+(\w+)\s*\("],
        "dart":       [r"(?:Future|void|dynamic|\w+)\s+(\w+)\s*\("],
        "elixir":     [r"def\s+(\w+)\s*\(", r"defp\s+(\w+)\s*\("],
        "sql":        [r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:FUNCTION|PROCEDURE)\s+(\w+)"],
    }

    _CLASS: Dict[str, List[str]] = {
        "java":       [r"(?:class|interface|enum|@interface)\s+(\w+)"],
        "kotlin":     [r"(?:data\s+|sealed\s+|abstract\s+|open\s+)?(?:class|object|interface)\s+(\w+)"],
        "typescript": [r"(?:export\s+)?(?:abstract\s+)?class\s+(\w+)",
                       r"(?:export\s+)?interface\s+(\w+)"],
        "javascript": [r"class\s+(\w+)"],
        "c":          [r"(?:struct|union)\s+(\w+)"],
        "cpp":        [r"(?:class|struct|template[^{]*class)\s+(\w+)"],
        "csharp":     [r"(?:class|interface|struct|enum|record)\s+(\w+)"],
        "rust":       [r"(?:pub\s+)?(?:struct|enum|trait)\s+(\w+)", r"impl\s+(\w+)"],
        "go":         [r"type\s+(\w+)\s+(?:struct|interface)"],
        "swift":      [r"(?:class|struct|protocol|enum|extension)\s+(\w+)"],
        "ruby":       [r"class\s+(\w+)", r"module\s+(\w+)"],
        "dart":       [r"(?:abstract\s+)?class\s+(\w+)"],
        "elixir":     [r"defmodule\s+([\w.]+)"],
    }

    _IMPORT: Dict[str, List[str]] = {
        "javascript": [r"(?:import|require)\s*\(?['\"]([^'\"]+)['\"]"],
        "typescript": [r"from\s+['\"]([^'\"]+)['\"]"],
        "java":       [r"^import\s+(?:static\s+)?([\w\.]+)"],
        "kotlin":     [r"^import\s+([\w\.]+)"],
        "c":          [r"#include\s+[<\"]([^>\"]+)"],
        "cpp":        [r"#include\s+[<\"]([^>\"]+)"],
        "csharp":     [r"^using\s+([\w\.]+)"],
        "rust":       [r"use\s+([\w:{}\s*,]+);"],
        "go":         [r'"([\w\./\-]+)"'],
        "swift":      [r"^import\s+(\w+)"],
        "ruby":       [r"require\s+['\"]([^'\"]+)['\"]"],
        "php":        [r"use\s+([\w\\]+);"],
        "shell":      [r"source\s+['\"]?([^\s'\"#]+)"],
        "lua":        [r"require\s*\(?['\"]([^'\"]+)"],
        "elixir":     [r"^(?:import|alias|use|require)\s+([\w.]+)"],
    }

    _ROUTE_PATS: List[str] = [
        r"@[\w_]+\.route\(['\"]([^'\"]+)['\"]",
        r"app\.(?:get|post|put|delete|patch|use)\(['\"]([^'\"]+)['\"]",
        r"router\.(?:get|post|put|delete|patch)\(['\"]([^'\"]+)['\"]",
        r"@(?:Get|Post|Put|Delete|Patch|RequestMapping)\(['\"]([^'\"]+)['\"]",
    ]

    _BRANCH: Dict[str, str] = {
        "java":       r"\b(?:if|else|for|while|switch|catch|case)\b",
        "kotlin":     r"\b(?:if|else|for|when|while|catch)\b",
        "cpp":        r"\b(?:if|else|for|while|switch|catch|try)\b",
        "csharp":     r"\b(?:if|else|for|foreach|while|switch|catch)\b",
        "rust":       r"\b(?:if|else|for|while|match|loop)\b",
        "go":         r"\b(?:if|else|for|switch|select|case)\b",
        "javascript": r"\b(?:if|else|for|while|switch|catch|try)\b",
        "typescript": r"\b(?:if|else|for|while|switch|catch|try)\b",
        "shell":      r"\b(?:if|elif|for|while|case|until)\b",
        "ruby":       r"\b(?:if|elsif|unless|while|for|case|rescue)\b",
        "php":        r"\b(?:if|elseif|for|foreach|while|switch|catch)\b",
        "swift":      r"\b(?:if|else|for|while|switch|catch|guard)\b",
        "dart":       r"\b(?:if|else|for|while|switch|catch|try)\b",
        "lua":        r"\b(?:if|elseif|for|while|repeat)\b",
        "elixir":     r"\b(?:if|unless|case|cond|with|rescue)\b",
    }

    def analyze(self, unit: CodeUnit) -> SemanticModel:
        lang = unit.language
        src  = unit.source
        lns  = src.splitlines()

        functions = self._extract(src, self._FUNC.get(lang, []))
        classes   = self._extract(src, self._CLASS.get(lang, []))
        imports   = self._extract(src, self._IMPORT.get(lang, []))
        routes: List[str] = []
        for pat in self._ROUTE_PATS:
            routes.extend(m.group(1) for m in re.finditer(pat, src))

        branch_pat   = self._BRANCH.get(lang, r"\b(?:if|for|while)\b")
        branch_count = len(re.findall(branch_pat, src))
        max_depth    = self._max_nesting(src, lang)
        total_cc     = branch_count + max_depth
        eh_count     = self._error_handlers(src, lang)
        has_tests    = bool(re.search(
            r"\b(?:test_\w+|describe\s*\(|it\s*\(|@Test|assert\w*\(|expect\(|should\b)\b", src
        ))

        # Dead private/unexported functions (one occurrence = only definition, never called)
        dead_fns: List[str] = []
        vis_pats = {
            "java":    r"private\s+(?:static\s+)?[\w<>\[\]]+\s+(\w+)\s*\(",
            "kotlin":  r"private\s+fun\s+(\w+)\s*\(",
            "csharp":  r"private\s+(?:static\s+)?[\w<>\[\]]+\s+(\w+)\s*\(",
            "rust":    r"fn\s+(\w+)\s*\(",
            "go":      r"^func\s+([a-z]\w*)\s*\(",
        }
        if lang in vis_pats:
            for pfn in re.findall(vis_pats[lang], src, re.MULTILINE):
                if pfn and pfn not in _NEVER_DEAD:
                    if len(re.findall(r'\b' + re.escape(pfn) + r'\b', src)) == 1:
                        dead_fns.append(pfn)

        # Recursive functions (body contains the function name followed by a call)
        recursive_fns: List[str] = []
        for fn in functions:
            if len(fn) < 3: continue
            m = re.search(
                r'(?:fun|func|function|def)\s+' + re.escape(fn) +
                r'\s*\([^{]*\{([^}]{0,2000})',
                src, re.DOTALL
            )
            if m and re.search(r'\b' + re.escape(fn) + r'\s*\(', m.group(1)):
                recursive_fns.append(fn)

        # Async functions
        async_pats = {
            "javascript": r"async\s+function\s+(\w+)|async\s+(\w+)\s*=\s*async",
            "typescript": r"async\s+(?:function\s+)?(\w+)\s*\(",
            "rust":       r"async\s+fn\s+(\w+)",
            "kotlin":     r"suspend\s+fun\s+(\w+)",
            "dart":       r"Future\s+(\w+)\s*\(",
            "elixir":     r"Task\.async.*def\s+(\w+)",
        }
        async_fns: List[str] = []
        if lang in async_pats:
            raw = re.findall(async_pats[lang], src)
            for r in raw:
                name = r if isinstance(r, str) else next((x for x in r if x), "")
                if name and len(name) > 1: async_fns.append(name)

        # Side effects
        does_io   = bool(re.search(r"\b(?:fopen|File|FileInputStream|open\(|read_file|write_file)\b", src))
        does_net  = bool(re.search(r"\b(?:http|socket|connect|fetch|axios|HttpClient|URL)\b", src, re.I))
        does_db   = bool(re.search(r"\b(?:SELECT|INSERT|UPDATE|DELETE|execute|query|cursor|sqlite)\b", src, re.I))
        does_proc = bool(re.search(r"\b(?:exec\(|system\(|popen|ProcessBuilder|Runtime\.exec|spawn)\b", src))
        does_thr  = bool(re.search(r"\b(?:Thread|goroutine|go\s+func|async\s+fn|tokio|thread::spawn|pthread)\b", src))
        does_cry  = bool(re.search(r"\b(?:encrypt|decrypt|AES|RSA|SHA|md5|crypto|cipher)\b", src, re.I))
        does_eval = bool(re.search(r"\beval\b|\bexec\b", src))

        # Taint
        taint_srcs: List[str] = []
        taint_snks: List[str] = []
        if re.search(r"argv|args\.|getParam|getQuery|getBody|FormValue|request\.", src):
            taint_srcs.append("user_input_detected")
        if does_proc or does_eval:
            taint_snks.append("code_execution_sink")
        if re.search(r"(?i)(?:password|secret)\s*=\s*['\"][^'\"]{6}", src):
            taint_snks.append("hardcoded_credential")
        taint_paths = [f"{s} → {k}" for s in taint_srcs for k in taint_snks][:3]

        # Entry points
        entry_points: List[str] = []
        if lang in ("java", "kotlin", "csharp"):
            entry_points = [f for f in functions if "main" in f.lower()][:3]
        elif lang == "go":
            entry_points = [f for f in functions if f == "main" or f[:1].isupper()][:4]
        elif lang == "rust":
            entry_points = [f for f in functions if f == "main"][:2]
        elif lang == "shell":
            entry_points = [f for f in functions if "main" in f.lower()][:3]

        # Halstead (token-based for non-AST languages)
        tokens = re.findall(r"[a-zA-Z_]\w*|[+\-*/=<>!&|^~%]+|[(){}[\];,]", src)
        n_toks = len(tokens); u_toks = max(len(set(tokens)), 2)
        vol    = round(n_toks * math.log2(u_toks), 2)
        diff   = round(n_toks / u_toks, 2)
        eff    = round(vol * diff, 2)
        loc    = len([l for l in lns if l.strip()])
        if vol > 0 and loc > 0:
            mi = max(0.0, (171
                           - 5.2  * math.log(max(vol, 1))
                           - 0.23 * branch_count
                           - 16.2 * math.log(max(loc, 1))
                           ) * 100.0 / 171.0)
        else:
            mi = 100.0

        all_fx: Set[str] = set()
        if does_io:   all_fx.add("io")
        if does_net:  all_fx.add("network")
        if does_db:   all_fx.add("db")
        if does_proc: all_fx.add("subprocess")
        if does_thr:  all_fx.add("threading")
        if does_cry:  all_fx.add("crypto")
        if does_eval: all_fx.add("eval")

        role, role_conf, role_sigs = _BehavioralClassifier.classify(
            functions, classes, imports, routes, all_fx, src
        )
        zeus_imps = [i for i in imports if "zeus_" in i or i in ("logic_engine", "db_init")]
        exports   = (
            [f for f in functions if not f.startswith("_")][:20] +
            [c for c in classes if not c.startswith("_")][:10]
        )

        empty_fm: Dict[str, FunctionSemantics] = {}
        return SemanticModel(
            language=lang, file_path=unit.file_path,
            analysis_depth="regex_structural",
            function_map=empty_fm,
            pure_functions=[], impure_functions=functions[:30],
            dead_functions=dead_fns[:10],
            recursive_fns=recursive_fns[:10],
            async_fns=async_fns[:10],
            generator_fns=[],
            entry_points=entry_points,
            call_graph={}, call_chains=[], max_chain_depth=0,
            does_io=does_io, does_network=does_net,
            does_db=does_db, does_subprocess=does_proc,
            does_threading=does_thr, does_crypto=does_cry, does_eval=does_eval,
            global_state=[],
            total_cognitive=total_cc,
            avg_cognitive=round(total_cc / max(len(functions), 1), 2),
            max_cognitive_fn="", max_cognitive=max_depth,
            cyclomatic_total=branch_count + 1,
            halstead_volume=vol, halstead_difficulty=diff, halstead_effort=eff,
            maintainability=round(mi, 1),
            taint_sources=taint_srcs, taint_sinks=taint_snks, taint_paths=taint_paths,
            behavioral_role=role, role_confidence=role_conf, role_signals=role_sigs,
            functions=functions[:50], classes=classes[:30],
            imports=imports[:40], exports=exports, routes=routes,
            error_handler_count=eh_count, has_tests=has_tests,
            line_count=len(lns),
            zeus_imports=zeus_imps, blueprint_name="", flask_routes=routes,
            parse_error="",
        )

    def _extract(self, src: str, patterns: List[str]) -> List[str]:
        found: List[str] = []
        for pat in patterns:
            for m in re.finditer(pat, src, re.MULTILINE):
                name = next((g for g in (m.groups() or ()) if g and len(g) > 1), None)
                if name: found.append(name)
        return list(dict.fromkeys(found))

    def _max_nesting(self, src: str, lang: str) -> int:
        if lang in ("python", "yaml", "elixir"):
            max_d = cur_d = 0
            for line in src.splitlines():
                stripped = line.lstrip()
                if not stripped or stripped.startswith("#"): continue
                cur_d = (len(line) - len(stripped)) // 4
                max_d = max(max_d, cur_d)
            return min(max_d, 20)
        max_d = cur_d = 0
        for ch in src:
            if ch == "{":
                cur_d += 1; max_d = max(max_d, cur_d)
            elif ch == "}":
                cur_d = max(0, cur_d - 1)
        return min(max_d, 30)

    def _error_handlers(self, src: str, lang: str) -> int:
        pats = {
            "go":     r"if\s+err\s*!=\s*nil",
            "rust":   r"\.unwrap_or|\.map_err|\.ok\(\)|match.*Err",
            "shell":  r"if\s+\[\[?\s*\$\?|trap\s+",
            "elixir": r"\{:error,|rescue\b",
        }
        return len(re.findall(pats.get(lang, r"\bcatch\b"), src))


# ============================================================================
# BINARY ANALYZER
# ============================================================================

class BinaryAnalyzer:
    def analyze(self, unit: CodeUnit) -> SemanticModel:
        lang = unit.language
        role_map = {
            "apk": ("android_package", 0.95), "dex": ("dalvik_bytecode", 0.95),
            "elf": ("native_binary", 0.95),    "pe":  ("windows_binary",  0.95),
            "jar": ("java_archive",  0.90),    "jvm_class": ("jvm_bytecode", 0.90),
            "archive": ("compressed_archive", 0.85),
            "image": ("media_asset", 0.80),    "audio": ("media_asset", 0.80),
            "video": ("media_asset", 0.80),    "binary": ("raw_binary",   0.70),
        }
        role, conf = role_map.get(lang, ("binary_artifact", 0.60))
        empty_fm: Dict[str, FunctionSemantics] = {}
        return SemanticModel(
            language=lang, file_path=unit.file_path,
            analysis_depth="binary", function_map=empty_fm,
            pure_functions=[], impure_functions=[], dead_functions=[],
            recursive_fns=[], async_fns=[], generator_fns=[], entry_points=[],
            call_graph={}, call_chains=[], max_chain_depth=0,
            does_io=False, does_network=False, does_db=False,
            does_subprocess=False, does_threading=False,
            does_crypto=False, does_eval=False, global_state=[],
            total_cognitive=0, avg_cognitive=0.0, max_cognitive_fn="",
            max_cognitive=0, cyclomatic_total=0,
            halstead_volume=0.0, halstead_difficulty=0.0, halstead_effort=0.0,
            maintainability=100.0,
            taint_sources=[], taint_sinks=[], taint_paths=[],
            behavioral_role=role, role_confidence=conf,
            role_signals=[f"{lang}_binary"],
            functions=[], classes=[], imports=[], exports=[], routes=[],
            error_handler_count=0, has_tests=False, line_count=0,
            zeus_imports=[], blueprint_name="", flask_routes=[],
            parse_error="",
        )


# ============================================================================
# UNKNOWN FILE ANALYZER
# Produces a SemanticModel for any file whose language was inferred by the
# sniffer rather than found in the static LANG_MAP. Extracts whatever
# structure is visible: functions/methods via multi-pattern regex, class-like
# blocks, import-like statements, key=value config pairs, keyword density,
# token-based Halstead, and a purpose narrative written from sniffer metadata.
# ============================================================================

class UnknownFileAnalyzer:
    """
    Semantic analyzer for unknown / dynamically-learned file types.
    Uses a broad catch-all regex pass to extract as much structure as possible,
    then classifies the behavioral role and records the inferred purpose in the
    knowledge DB so Zeus learns what the file type is FOR — not just what it contains.
    """

    # Generic function-like patterns covering most syntax styles
    _FN_PATS: List[str] = [
        r"(?:def|func|function|fn|fun|sub|proc|method)\s+(\w+)\s*[\(\{]",
        r"^(\w+)\s*\([^)]{0,60}\)\s*(?:->|:|\{)",       # C/Rust/Go style
        r"^\s{0,4}(\w+)\s*=\s*(?:lambda|async\s+)?(?:function|\()",  # JS assignments
        r"(?:public|private|protected|static)\s+[\w<>\[\]]+\s+(\w+)\s*\(",  # Java/C# style
        r"^\s{0,4}def\s+(\w[\w_]+)\b",                  # Ruby/Python bare
    ]

    # Generic class-like patterns
    _CLS_PATS: List[str] = [
        r"(?:class|struct|interface|trait|type|module|object)\s+(\w+)",
        r"^(\w+)\s*(?:extends|implements|:)\s*\w+",
        r"defmodule\s+([\w.]+)",
    ]

    # Generic import-like patterns
    _IMP_PATS: List[str] = [
        r"(?:import|require|include|use|load|source)\s+['\"]?([^\s'\";\n]+)",
        r"from\s+([^\s]+)\s+import",
        r"#include\s+[<\"]([^>\"]+)",
    ]

    # Key=value config detection
    _KV_PAT  = r"^([\w\-\.]+)\s*[=:]\s*(.+)$"

    def analyze(self, unit: CodeUnit) -> SemanticModel:
        src  = unit.source
        lang = unit.language
        lns  = src.splitlines() if src else []

        # Retrieve sniffer metadata if available
        dyn_entry = _dynamic_ext_registry.get(Path(unit.file_name).suffix.lower(), {})
        purpose   = dyn_entry.get("purpose", f"unknown_{lang}_file")
        fam       = dyn_entry.get("family",  unit.family or "general")

        # If binary (no source text), use binary analyzer logic
        if not src:
            role = f"binary_{lang}" if lang != "unknown_binary" else "binary_artifact"
            empty_fm: Dict[str, FunctionSemantics] = {}
            return SemanticModel(
                language=lang, file_path=unit.file_path,
                analysis_depth="binary_unknown",
                function_map=empty_fm,
                pure_functions=[], impure_functions=[], dead_functions=[],
                recursive_fns=[], async_fns=[], generator_fns=[], entry_points=[],
                call_graph={}, call_chains=[], max_chain_depth=0,
                does_io=False, does_network=False, does_db=False,
                does_subprocess=False, does_threading=False,
                does_crypto=False, does_eval=False, global_state=[],
                total_cognitive=0, avg_cognitive=0.0, max_cognitive_fn="",
                max_cognitive=0, cyclomatic_total=0,
                halstead_volume=0.0, halstead_difficulty=0.0, halstead_effort=0.0,
                maintainability=100.0, taint_sources=[], taint_sinks=[], taint_paths=[],
                behavioral_role=role, role_confidence=0.70,
                role_signals=[f"binary_sniffed:{purpose}"],
                functions=[], classes=[], imports=[], exports=[], routes=[],
                error_handler_count=0, has_tests=False, line_count=0,
                zeus_imports=[], blueprint_name="", flask_routes=[],
                parse_error="",
            )

        # ── Text analysis pass ────────────────────────────────────────────

        functions = self._extract_multi(src, self._FN_PATS)
        classes   = self._extract_multi(src, self._CLS_PATS)
        imports   = self._extract_multi(src, self._IMP_PATS)

        # Config files: key=value pairs as "constants"
        kv_keys: List[str] = []
        if not functions:
            kv_keys = [m.group(1) for m in re.finditer(self._KV_PAT, src, re.MULTILINE)][:30]

        # Branch/complexity proxy
        branch_count = len(re.findall(
            r"\b(?:if|else|for|while|case|switch|when|do|until|rescue|catch|try)\b", src
        ))
        max_depth = 0
        cur_depth = 0
        for ch in src:
            if ch in "{(":  cur_depth += 1; max_depth = max(max_depth, cur_depth)
            elif ch in "})": cur_depth = max(0, cur_depth - 1)

        # Token-based Halstead
        tokens  = re.findall(r"[a-zA-Z_]\w*|[+\-*/=<>!&|^~%]+|[(){}[\];,]", src)
        n_toks  = len(tokens); u_toks = max(len(set(tokens)), 2)
        vol     = round(n_toks * math.log2(u_toks), 2)
        diff    = round(n_toks / u_toks, 2)
        eff     = round(vol * diff, 2)
        loc     = len([l for l in lns if l.strip()])
        if vol > 0 and loc > 0:
            mi = max(0.0, (171
                           - 5.2  * math.log(max(vol, 1))
                           - 0.23 * branch_count
                           - 16.2 * math.log(max(loc, 1))
                           ) * 100.0 / 171.0)
        else:
            mi = 100.0

        # Side effects
        does_net  = bool(re.search(r"\b(?:http|https|socket|fetch|curl|wget|URL)\b", src, re.I))
        does_db   = bool(re.search(r"\b(?:SELECT|INSERT|DELETE|UPDATE|sqlite|database|cursor)\b", src, re.I))
        does_io   = bool(re.search(r"\b(?:open|fopen|read|write|File|Path|Stream)\b", src))
        does_proc = bool(re.search(r"\b(?:exec|system|popen|spawn|Process|Runtime)\b", src))
        does_cry  = bool(re.search(r"\b(?:encrypt|decrypt|AES|RSA|sha|md5|cipher|crypto)\b", src, re.I))
        all_fx: Set[str] = set()
        if does_io:   all_fx.add("io")
        if does_net:  all_fx.add("network")
        if does_db:   all_fx.add("db")
        if does_proc: all_fx.add("subprocess")
        if does_cry:  all_fx.add("crypto")

        # Behavioral role — attempt full classifier, fall back to purpose-derived role
        role, role_conf, role_sigs = _BehavioralClassifier.classify(
            functions, classes, imports, [], all_fx, src
        )
        if role == "general_utility" and purpose != f"unknown_{lang}_file":
            role      = purpose                    # use sniffer's purpose label
            role_conf = 0.65
            role_sigs = [f"sniffer_inferred:{lang}", f"ext:{Path(unit.file_name).suffix}"]

        has_tests = bool(re.search(
            r"\b(?:test_\w+|describe\s*\(|it\s*\(|assert|expect\s*\(|should\b)\b", src
        ))

        exports = [f for f in functions if not f.startswith("_")][:20] + classes[:10]

        empty_fm2: Dict[str, FunctionSemantics] = {}
        return SemanticModel(
            language=lang, file_path=unit.file_path,
            analysis_depth="unknown_sniffed",
            function_map=empty_fm2,
            pure_functions=[], impure_functions=functions[:30],
            dead_functions=[], recursive_fns=[], async_fns=[], generator_fns=[],
            entry_points=[f for f in functions if "main" in f.lower()][:3],
            call_graph={}, call_chains=[], max_chain_depth=0,
            does_io=does_io, does_network=does_net, does_db=does_db,
            does_subprocess=does_proc, does_threading=False,
            does_crypto=does_cry, does_eval=False,
            global_state=kv_keys[:10],
            total_cognitive=branch_count + max_depth,
            avg_cognitive=round((branch_count + max_depth) / max(len(functions), 1), 2),
            max_cognitive_fn="", max_cognitive=max_depth,
            cyclomatic_total=branch_count + 1,
            halstead_volume=vol, halstead_difficulty=diff, halstead_effort=eff,
            maintainability=round(mi, 1),
            taint_sources=[], taint_sinks=[], taint_paths=[],
            behavioral_role=role, role_confidence=role_conf, role_signals=role_sigs,
            functions=functions[:50], classes=classes[:20],
            imports=imports[:30], exports=exports, routes=[],
            error_handler_count=len(re.findall(r"\b(?:catch|rescue|except|error)\b", src)),
            has_tests=has_tests, line_count=len(lns),
            zeus_imports=[], blueprint_name="", flask_routes=[],
            parse_error="",
        )

    def _extract_multi(self, src: str, patterns: List[str]) -> List[str]:
        found: List[str] = []
        for pat in patterns:
            for m in re.finditer(pat, src, re.MULTILINE):
                name = next((g for g in (m.groups() or ()) if g and len(g) > 1), None)
                if name and name not in found:
                    found.append(name)
        return found[:50]


# ============================================================================
# Dispatcher — handles ALL file types including unknowns
# ============================================================================

_py_an   = PythonSemanticAnalyzer()
_sm_an   = SmaliSemanticAnalyzer()
_gen_an  = GenericSemanticAnalyzer()
_bin_an  = BinaryAnalyzer()
_unk_an  = UnknownFileAnalyzer()

_KNOWN_TEXT_LANGS: Set[str] = set(LANG_MAP.values()) - _BINARY_LANGS


def _analyze(unit: CodeUnit) -> SemanticModel:
    lang = unit.language

    # Known binary formats
    if lang in _BINARY_LANGS or lang.startswith("unknown_binary"):
        return _bin_an.analyze(unit)

    # Known text languages with dedicated analyzers
    if lang == "python":  return _py_an.analyze(unit)
    if lang == "smali":   return _sm_an.analyze(unit)

    # Known text languages handled by generic structural analyzer
    if lang in _KNOWN_TEXT_LANGS:
        return _gen_an.analyze(unit)

    # Unknown / dynamically-learned language → specialized unknown analyzer
    # (covers .gen, .h inferred as c, .tpl, .gradle, .lock, novel extensions…)
    return _unk_an.analyze(unit)


# ============================================================================
# MASTERY PROCESSOR — 5 stages, genuine semantic content at every depth
# ============================================================================

class MasteryProcessor:
    """
    Drives the 5-stage mastery pipeline.
    Every stage generates content derived from the actual SemanticModel —
    no template filler, no label slapping. Real findings at every depth.
    """

    def process(self, unit: CodeUnit, model: SemanticModel,
                existing: Optional[Dict] = None) -> Tuple[MasteryRecord, SemanticModel]:
        done:       List[str] = []
        confidence: float     = 0.0

        if existing:
            done       = json.loads(existing.get("depths_done", "[]"))
            confidence = float(existing.get("confidence", 0.0))
            if existing.get("file_hash") != unit.file_hash:
                log.info(f"[CodeLearner] Hash change — resetting {unit.file_name}")
                done = []; confidence = 0.0

        for depth in DEPTHS:
            if depth in done: continue
            content    = self._content(unit, model, depth)
            topic      = f"code:{unit.language}:{unit.file_name}"
            confidence = min(1.0, confidence + DEPTH_CONFIDENCE[depth])
            _db.save_knowledge(topic=topic, depth=depth,
                               content=content, confidence=confidence,
                               domain="code_intelligence")
            done.append(depth)
            log.debug(f"[CodeLearner] {unit.file_name} → {depth} conf={confidence:.2f}")
            if depth == "Professional": self._assert_logic_facts(unit, model)
            if depth == "Mastery":      self._register_genome(unit, model)

        mastery_complete = set(done) == set(DEPTHS)
        rec = MasteryRecord(
            file_path=unit.file_path, file_name=unit.file_name,
            language=unit.language, family=unit.family,
            file_hash=unit.file_hash, source_tag=unit.source_tag,
            depths_done=done, confidence=confidence,
            last_updated=datetime.now(timezone.utc).isoformat(),
            mastery_complete=mastery_complete,
        )
        return rec, model

    # ------------------------------------------------------------------
    # Stage content generators
    # ------------------------------------------------------------------

    def _content(self, unit: CodeUnit, m: SemanticModel, depth: str) -> str:
        if depth == "Simple":       return self._simple(unit, m)
        if depth == "Advanced":     return self._advanced(unit, m)
        if depth == "Professional": return self._professional(unit, m)
        if depth == "Complex":      return self._complex(unit, m)
        if depth == "Mastery":      return self._mastery(unit, m)
        return ""

    def _simple(self, unit: CodeUnit, m: SemanticModel) -> str:
        fx = self._fx_summary(m)
        # Unknown/dynamically-learned file: include sniffer metadata
        unk_note = ""
        if m.analysis_depth in ("unknown_sniffed", "binary_unknown"):
            ext     = Path(unit.file_name).suffix.lower()
            dyn     = _dynamic_ext_registry.get(ext, {})
            purpose = dyn.get("purpose", "not yet classified")
            seen    = dyn.get("seen_count", 1)
            unk_note = (
                f"\nDynamic extension: {ext!r} → purpose: {purpose}"
                f" | times seen: {seen}"
                f"\nLearning status: registered in zeus_ext_registry.json"
            )
        return (
            f"Code: {unit.file_name} | {m.language} | {unit.family}\n"
            f"Lines: {m.line_count:,} | Size: {unit.size_bytes:,} bytes | Source: {unit.source_tag}\n"
            f"Behavioral role: {m.behavioral_role} (confidence: {m.role_confidence:.2f})\n"
            f"Analysis depth: {m.analysis_depth}\n"
            f"Side effects: {fx}"
            f"{unk_note}\n"
            f"Parse status: {'OK' if not m.parse_error else 'ERROR: ' + m.parse_error}\n"
            f"Hash: {unit.file_hash[:16]}\n"
            f"The Zeus Project 2026 — Francois Nel"
        )

    def _advanced(self, unit: CodeUnit, m: SemanticModel) -> str:
        fn_count  = len(m.functions)
        pure_pct  = round(len(m.pure_functions) / max(fn_count, 1) * 100)
        dead_note = f" | Dead: {len(m.dead_functions)}" if m.dead_functions else ""
        chain_note = (
            f"Call chains: {len(m.call_chains)} detected, max depth {m.max_chain_depth}"
            if m.call_graph else "Call graph: not available (non-Python)"
        )
        top_fns = ""
        if m.function_map:
            ranked = sorted(m.function_map.items(),
                            key=lambda kv: kv[1].cognitive_complexity, reverse=True)[:3]
            top_fns = "\nTop complexity functions:\n" + "\n".join(
                f"  {fn}: cognitive={s.cognitive_complexity}, "
                f"cyclomatic={s.cyclomatic}, fan_out={s.fan_out}"
                for fn, s in ranked
            )
        bp_note    = (f"\nBlueprint: {m.blueprint_name} | Routes: {len(m.routes)} "
                      f"{m.routes[:4]}" if m.blueprint_name else "")
        rec_note   = f" | Recursive: {', '.join(m.recursive_fns[:4])}" if m.recursive_fns else ""
        async_note = f" | Async: {', '.join(m.async_fns[:4])}" if m.async_fns else ""
        zeus_note  = f"\nZeus deps: {', '.join(m.zeus_imports)}" if m.zeus_imports else ""
        state_note = f"\nGlobal state: {', '.join(m.global_state[:8])}" if m.global_state else ""
        return (
            f"Advanced: {unit.file_name} ({m.language})\n"
            f"Functions: {fn_count} | Pure: {len(m.pure_functions)} ({pure_pct}%)"
            f" | Impure: {len(m.impure_functions)}{dead_note}\n"
            f"Classes: {len(m.classes)} {m.classes[:6]}\n"
            f"Imports: {len(m.imports)} {m.imports[:8]}\n"
            f"{chain_note}{rec_note}{async_note}"
            f"{top_fns}{bp_note}{zeus_note}{state_note}\n"
            f"The Zeus Project 2026 — Francois Nel"
        )

    def _professional(self, unit: CodeUnit, m: SemanticModel) -> str:
        lines = [f"Professional: {unit.file_name} ({m.language})"]

        if m.function_map:
            lines.append("\nFUNCTION BEHAVIORS (top by cognitive complexity):")
            ranked = sorted(m.function_map.items(),
                            key=lambda kv: kv[1].cognitive_complexity, reverse=True)[:6]
            for fn, s in ranked:
                fx      = "+".join(s.side_effects) if s.side_effects else "pure"
                callees = ", ".join(s.internal_callees[:4]) or "none"
                exc     = f" | raises: {', '.join(s.raises[:2])}" if s.raises else ""
                hdl     = f" | handles: {', '.join(s.handles[:2])}" if s.handles else ""
                rty     = f" | returns: {s.return_style}" if s.return_style != "never" else ""
                lines.append(
                    f"  {fn}() [{fx}] fan_in={s.fan_in} fan_out={s.fan_out} "
                    f"cognitive={s.cognitive_complexity} cyclomatic={s.cyclomatic}{rty}\n"
                    f"    calls: {callees}{exc}{hdl}"
                )
            if m.pure_functions:
                lines.append(f"\nPURE ({len(m.pure_functions)}): "
                             f"{', '.join(m.pure_functions[:8])}")
            else:
                lines.append("\nPURE FUNCTIONS: None — every function carries side effects")
            if m.dead_functions:
                lines.append(f"\nDEAD CODE ({len(m.dead_functions)}): "
                             f"{', '.join(m.dead_functions[:6])} — defined, never internally called")

        mi_label = ("high" if m.maintainability > 80 else
                    "moderate" if m.maintainability > 60 else "low")
        lines.append(
            f"\nHALSTEAD: Volume={m.halstead_volume:,.0f} | "
            f"Difficulty={m.halstead_difficulty:.1f} | "
            f"Effort={m.halstead_effort:,.0f}\n"
            f"Maintainability: {m.maintainability:.1f}/100 ({mi_label})"
        )

        if m.taint_sources or m.taint_sinks:
            lines.append("\nSECURITY:")
            if m.taint_sources: lines.append(f"  Sources: {', '.join(m.taint_sources[:4])}")
            if m.taint_sinks:   lines.append(f"  Sinks:   {', '.join(m.taint_sinks[:4])}")
            if m.taint_paths:   lines.append(f"  Paths:   {', '.join(m.taint_paths[:3])}")
        else:
            lines.append("\nSECURITY: No taint source/sink crossings detected")

        lines.append("\nLogic engine: capability facts asserted at this stage")
        lines.append("The Zeus Project 2026 — Francois Nel")
        return "\n".join(lines)

    def _complex(self, unit: CodeUnit, m: SemanticModel) -> str:
        lines = [f"Complex synthesis: {unit.file_name} ({m.language})"]
        lines.append(
            f"\nBEHAVIORAL ROLE: {m.behavioral_role} (confidence: {m.role_confidence:.2f})\n"
            f"Evidence: {{{', '.join(m.role_signals[:6])}}}"
        )

        if m.call_chains:
            lines.append(f"\nCALL CHAINS (deepest {min(3, len(m.call_chains))}):")
            for ch in sorted(m.call_chains, key=len, reverse=True)[:3]:
                lines.append(f"  {' → '.join(ch)} [depth={len(ch)}]")

        if m.function_map:
            high_fo = sorted(
                [(fn, s) for fn, s in m.function_map.items() if s.fan_out >= 5],
                key=lambda x: x[1].fan_out, reverse=True
            )
            high_fi = sorted(
                [(fn, s) for fn, s in m.function_map.items() if s.fan_in >= 4],
                key=lambda x: x[1].fan_in, reverse=True
            )
            if high_fo:
                lines.append("\nCOUPLING — High fan-out (orchestrators):")
                for fn, s in high_fo[:3]:
                    lines.append(f"  {fn}: fan_out={s.fan_out} → consider decomposition")
            if high_fi:
                lines.append("Coupling — High fan-in (central dependencies):")
                for fn, s in high_fi[:3]:
                    lines.append(f"  {fn}: fan_in={s.fan_in} → single point of change risk")

        if m.zeus_imports:
            lines.append(f"\nZEUS DEPENDENCIES: {', '.join(m.zeus_imports)}")
        if m.flask_routes:
            lines.append(f"EXPOSED ENDPOINTS: {', '.join(m.flask_routes[:8])}")

        improvements: List[str] = []
        if m.function_map:
            for fn, s in sorted(m.function_map.items(),
                                 key=lambda kv: kv[1].cognitive_complexity,
                                 reverse=True)[:2]:
                if s.cognitive_complexity > 15:
                    improvements.append(
                        f"{fn}() cognitive={s.cognitive_complexity} "
                        f"— extract sub-functions to reduce below 10"
                    )
            low_eh = [
                fn for fn, s in m.function_map.items()
                if not s.handles and s.side_effects and not s.is_pure
            ][:3]
            if low_eh:
                improvements.append(f"Missing exception handling: {', '.join(low_eh)}")
        if m.dead_functions:
            improvements.append(f"Remove dead code: {', '.join(m.dead_functions[:4])}")
        if not m.has_tests:
            improvements.append("No test functions detected — add coverage")
        if improvements:
            lines.append("\nIMPROVEMENT CANDIDATES:")
            for i, imp in enumerate(improvements, 1):
                lines.append(f"  {i}. {imp}")

        lines.append(f"\nMaintainability: {m.maintainability:.1f}/100")
        lines.append("The Zeus Project 2026 — Francois Nel")
        return "\n".join(lines)

    def _mastery(self, unit: CodeUnit, m: SemanticModel) -> str:
        lines = [
            f"MASTERY: {unit.file_name} ({m.language}) — Complete semantic intelligence",
            "Confidence: 1.00 | All 5 stages complete",
        ]

        lines.append(f"\nTHIS MODULE IS:\n{self._role_description(m)}")

        # Threading + state hazards
        if m.does_threading and m.global_state:
            guards = [g for g in m.global_state if "lock" in g.lower() or "event" in g.lower()]
            lines.append(
                f"\nTHREADING: concurrent execution | "
                f"Shared state: {', '.join(m.global_state[:6])} | "
                f"Guards: {', '.join(guards) or 'none detected — verify manually'}"
            )
        elif m.does_threading:
            lines.append("\nTHREADING: concurrent execution detected")
        elif m.global_state:
            lines.append(f"STATE: module-level mutable: {', '.join(m.global_state[:6])}")

        # Data flow narrative
        flow: List[str] = []
        if m.flask_routes: flow.append(f"HTTP [{', '.join(m.flask_routes[:3])}]")
        if m.does_db:      flow.append("SQLite r/w")
        if m.does_io:      flow.append("file I/O")
        if m.does_network: flow.append("network")
        if m.does_subprocess: flow.append("subprocess")
        if flow: lines.append(f"DATA FLOW: {' → '.join(flow)}")

        # Error handling coverage (Python only)
        if m.function_map:
            covered = sum(1 for s in m.function_map.values() if s.handles)
            total   = max(len(m.function_map), 1)
            pct     = round(covered / total * 100)
            lines.append(
                f"ERROR HANDLING: {covered}/{total} functions have catch blocks ({pct}%)"
            )
            uncovered = [fn for fn, s in m.function_map.items()
                         if not s.handles and s.side_effects][:4]
            if uncovered:
                lines.append(f"  Unhandled side-effect functions: {', '.join(uncovered)}")

        # Security summary
        if m.taint_paths:
            lines.append(f"\nSECURITY PATHS: {', '.join(m.taint_paths[:3])}")
        elif not m.taint_sources and not m.taint_sinks:
            lines.append("\nSECURITY: Clean — no taint flows detected")

        # Halstead interpretation
        if m.halstead_effort > 0:
            est_hours = round(m.halstead_effort / 18.0 / 3600.0, 2)
            lines.append(
                f"\nHALSTEAD EFFORT: {m.halstead_effort:,.0f} "
                f"(estimated implementation time: ~{est_hours}h)"
            )

        # Final genome marker
        lines.append(
            f"\nGenome entry: code_intel:{m.language}:{unit.file_hash[:8]}\n"
            f"Zeus code intelligence — mastery complete.\n"
            f"The Zeus Project 2026 — Francois Nel"
        )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _fx_summary(self, m: SemanticModel) -> str:
        active = []
        if m.does_io:         active.append("file_io")
        if m.does_network:    active.append("network")
        if m.does_db:         active.append("database")
        if m.does_subprocess: active.append("subprocess")
        if m.does_threading:  active.append("threading")
        if m.does_crypto:     active.append("crypto")
        if m.does_eval:       active.append("eval_exec")
        return ", ".join(active) if active else "none detected"

    def _role_description(self, m: SemanticModel) -> str:
        desc_map = {
            "evolution_engine":   "An evolution engine that audits Zeus modules for gaps and drives code improvement.",
            "learning_engine":    "A learning engine that processes knowledge topics through staged mastery curricula.",
            "analysis_engine":    "An analysis engine that extracts semantic structure from code or data.",
            "flask_service":      "A Flask web service exposing REST endpoints to the Zeus HTTP layer.",
            "data_layer":         "A database access layer providing WAL-mode SQLite reads and writes.",
            "worker_service":     "A long-running worker with daemon threads and a queue-based processing loop.",
            "forge_engine":       "A code forge that generates or scaffolds new module implementations.",
            "mutation_engine":    "A mutation engine that breeds code variants via genome-based crossover.",
            "prediction_engine":  "A prediction engine that infers signals or probabilities from observed data.",
            "execution_sandbox":  "An execution sandbox that runs untrusted code in an isolated subprocess.",
            "synthesis_engine":   "A synthesis engine that transpiles or transforms code across languages.",
            "scheduler":          "A scheduler that runs timed background tasks on a fixed interval.",
            "upload_handler":     "A file upload handler supporting 80+ extension types and stream processing.",
            "apk_engine":         "An APK analysis engine using apktool to extract and inspect Android packages.",
            "test_suite":         "A test suite verifying correctness of one or more Zeus modules.",
            "genome_manager":     "A genome manager tracking module lineage, fitness, and DNA segments.",
            "chat_interface":     "A chat interface providing conversational access to Zeus with push-to-talk voice.",
            "router_engine":      "A routing engine that dispatches queries between LLMs with circuit-breaker logic.",
            "stealth_engine":     "A stealth engine providing file integrity, anti-debug, and secure key vault.",
            "code_intelligence":  "A code intelligence module performing deep semantic analysis of source files.",
            "identity_module":    "An identity module that maintains Zeus's self-model and capability fingerprint.",
            "logic_engine":       "A logic engine maintaining facts and rules for deterministic inference.",
            "replication_engine": "A replication engine that deploys or mirrors Zeus modules across targets.",
            "general_utility":    "A general utility module providing shared helpers to the Zeus stack.",
        }
        return desc_map.get(m.behavioral_role,
                            f"A {m.behavioral_role.replace('_', ' ')} module.")

    def _assert_logic_facts(self, unit: CodeUnit, m: SemanticModel):
        try:
            from logic_engine import get_engine
            engine = get_engine()
            engine.assert_fact(
                predicate="code_role",
                args=(unit.file_name, m.behavioral_role),
                source="code_learner",
                confidence=m.role_confidence,
            )
            for fx in ["io", "network", "db", "subprocess", "threading", "crypto"]:
                if getattr(m, f"does_{fx}", False):
                    engine.assert_fact(
                        predicate="code_side_effect",
                        args=(unit.file_name, fx),
                        source="code_learner",
                        confidence=0.90,
                    )
            if m.taint_paths:
                engine.assert_fact(
                    predicate="code_taint_risk",
                    args=(unit.file_name, m.taint_paths[0]),
                    source="code_learner",
                    confidence=0.80,
                )
            if m.dead_functions:
                engine.assert_fact(
                    predicate="code_dead_code",
                    args=(unit.file_name, str(len(m.dead_functions))),
                    source="code_learner",
                    confidence=0.75,
                )
        except Exception as e:
            log.debug(f"[CodeLearner] Logic facts skipped for {unit.file_name}: {e}")

    def _register_genome(self, unit: CodeUnit, m: SemanticModel):
        name = f"code_intel:{m.language}:{unit.file_hash[:8]}"
        desc = (
            f"Code intelligence — {unit.file_name} ({m.language}/{unit.family}). "
            f"Role: {m.behavioral_role} | Functions: {len(m.functions)} | "
            f"Classes: {len(m.classes)} | MI: {m.maintainability:.1f}"
        )
        caps = ", ".join([m.behavioral_role] + m.role_signals[:4])
        src_snippet = unit.source[:3000] if unit.source else ""
        _db.save_genome(
            name=name, description=desc,
            module_type=f"code_intelligence_{unit.family}",
            capabilities=caps, source_code=src_snippet, priority=60,
        )
        log.debug(f"[CodeLearner] Genome registered: {name}")


_mastery_proc = MasteryProcessor()


# ============================================================================
# CODE INDEXER
# ============================================================================

class CodeIndexer:
    MAX_FILE_SIZE = 2 * 1024 * 1024

    def scan_all(self) -> List[CodeUnit]:
        units: List[CodeUnit] = []
        seen:  Set[str]       = set()
        units.extend(self._scan_dir(ZEUS_DIR,    "zeus_root", seen, max_depth=1))
        units.extend(self._scan_dir(EVOLVED_DIR, "evolved",   seen, max_depth=2))
        units.extend(self._scan_dir(UPLOAD_DIR,  "upload",    seen, max_depth=2))
        units.extend(self._scan_genome(seen))
        log.info(f"[CodeLearner] Indexed {len(units)} code units")
        return units

    def _scan_dir(self, directory: str, tag: str,
                  seen: Set[str], max_depth: int = 1) -> List[CodeUnit]:
        units: List[CodeUnit] = []
        if not os.path.isdir(directory): return units
        skip = {"__pycache__", "node_modules", "venv", ".git", ".tox", "dist", "build"}
        for root, dirs, files in os.walk(directory):
            depth = root[len(directory):].count(os.sep)
            if depth >= max_depth:
                dirs[:] = []
                continue
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in skip]
            for fname in files:
                fpath = os.path.join(root, fname)
                if fpath in seen: continue
                seen.add(fpath)
                ext  = Path(fname).suffix.lower()
                lang = LANG_MAP.get(ext) or _lookup_dynamic_ext(ext)
                if not lang:
                    # Unknown extension — sniff content and learn it
                    lang, _fam, _purpose, _is_bin = _sniffer.sniff(fpath, fname)
                unit = self._load(fpath, fname, lang, tag)
                if unit: units.append(unit)
        return units

    def _scan_genome(self, seen: Set[str]) -> List[CodeUnit]:
        units: List[CodeUnit] = []
        try:
            for row in _db.get_genome_sources():
                src = row.get("source_code", "")
                if not src or len(src) < 50: continue
                vpath = f"genome://{row['name']}"
                if vpath in seen: continue
                seen.add(vpath)
                lang  = "python" if ("def " in src or "import " in src) else "text"
                fam   = _get_family(lang)
                fhash = hashlib.md5(src.encode()).hexdigest()
                units.append(CodeUnit(
                    file_path=vpath, file_name=row["name"] + ".gen",
                    language=lang, family=fam,
                    size_bytes=len(src.encode()),
                    source=src, file_hash=fhash, source_tag="genome",
                ))
        except Exception as e:
            log.warning(f"[CodeLearner] Genome scan: {e}")
        return units

    def _load(self, fpath: str, fname: str, lang: str, tag: str) -> Optional[CodeUnit]:
        """
        Load any file regardless of extension. Unknown langs are routed through
        the sniffer which detects binary vs text, learns the extension, and
        assigns a meaningful language/purpose label. Never returns None for a
        readable non-empty file — worst case produces an unknown_text CodeUnit.
        """
        try:
            size = os.path.getsize(fpath)
            if size == 0 or size > self.MAX_FILE_SIZE: return None

            # If lang is still blank (caller passed empty string), sniff now
            is_binary = False
            if not lang or lang in ("", "unknown"):
                lang, sniffed_fam, sniffed_purpose, is_binary = _sniffer.sniff(fpath, fname)

            # Determine binary treatment:
            # - known binary langs from static registry, OR
            # - sniffer flagged it as binary, OR
            # - lang starts with "unknown_binary"
            treat_as_binary = (
                lang in _BINARY_LANGS or
                is_binary or
                lang.startswith("unknown_binary")
            )

            fam = _get_family(lang)

            if treat_as_binary:
                try:
                    with open(fpath, "rb") as f: raw = f.read(4096)
                except Exception:
                    return None
                fhash = hashlib.md5(raw).hexdigest()
                return CodeUnit(file_path=fpath, file_name=fname,
                                language=lang, family=fam,
                                size_bytes=size, source="",
                                file_hash=fhash, source_tag=tag)

            # Text path
            try:
                with open(fpath, encoding="utf-8", errors="replace") as f:
                    source = f.read()
            except Exception:
                return None

            if not source.strip():
                return None

            fhash = hashlib.md5(source.encode()).hexdigest()
            return CodeUnit(file_path=fpath, file_name=fname,
                            language=lang, family=fam,
                            size_bytes=size, source=source,
                            file_hash=fhash, source_tag=tag)

        except Exception as e:
            log.debug(f"[CodeLearner] Load error {fpath}: {e}")
            return None

    def load_single(self, fpath: str, tag: str = "on_demand") -> Optional[CodeUnit]:
        """Load a single file for on-demand analysis. Always attempts sniffing for unknowns."""
        fname = os.path.basename(fpath)
        ext   = Path(fname).suffix.lower()
        # Try static map first, then dynamic registry, then sniff
        lang  = LANG_MAP.get(ext) or _lookup_dynamic_ext(ext) or ""
        return self._load(fpath, fname, lang, tag)


_indexer = CodeIndexer()


# ============================================================================
# LEARNING ENGINE — main orchestrator
# ============================================================================

class CodeLearnerEngine:
    _CYCLE_INTERVAL = 300  # seconds

    def __init__(self):
        self._lock    = threading.RLock()
        self._stop    = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._stats: Dict = {
            "cycles": 0, "files_scanned": 0, "files_processed": 0,
            "depths_completed": 0, "mastered": 0, "errors": 0,
            "started_at": None, "last_cycle_at": None, "current_file": "",
        }

    def start(self) -> Dict:
        with self._lock:
            if self._running and self._thread and self._thread.is_alive():
                return {"status": "already_running", "stats": self._safe_stats()}
            self._stop.clear()
            self._running = True
            self._thread  = threading.Thread(
                target=self._loop, daemon=True, name="zeus_code_learner"
            )
            self._thread.start()
            log.info("[CodeLearner] Engine started")
            return {"status": "started", "interval_s": self._CYCLE_INTERVAL}

    def stop(self) -> Dict:
        self._stop.set()
        self._running = False
        log.info("[CodeLearner] Stop requested")
        return {"status": "stop_requested"}

    def is_running(self) -> bool:
        return self._running and bool(self._thread) and self._thread.is_alive()

    def get_stats(self) -> Dict:
        with self._lock: return self._safe_stats()

    def _safe_stats(self) -> Dict:
        s = dict(self._stats)
        s["running"] = self.is_running()
        return s

    def _loop(self):
        self._stats["started_at"] = datetime.now(timezone.utc).isoformat()
        while not self._stop.is_set():
            with self._lock: self._stats["cycles"] += 1; cycle = self._stats["cycles"]
            log.info(f"[CodeLearner] Cycle {cycle} — full source scan")
            try:
                units = _indexer.scan_all()
                with self._lock: self._stats["files_scanned"] = len(units)
                for unit in units:
                    if self._stop.is_set(): break
                    with self._lock: self._stats["current_file"] = unit.file_name
                    try:
                        existing = _db.get_record(unit.file_path)
                        if (existing and
                                existing.get("mastery_done") == 1 and
                                existing.get("file_hash") == unit.file_hash):
                            continue
                        model      = _analyze(unit)
                        rec, model = _mastery_proc.process(unit, model, existing)
                        _db.upsert(rec, model)
                        with self._lock:
                            self._stats["files_processed"]  += 1
                            self._stats["depths_completed"] += len(rec.depths_done)
                            if rec.mastery_complete: self._stats["mastered"] += 1
                    except Exception as e:
                        log.warning(f"[CodeLearner] Error on {unit.file_name}: {e}")
                        with self._lock: self._stats["errors"] += 1
                with self._lock:
                    self._stats["last_cycle_at"] = datetime.now(timezone.utc).isoformat()
                log.info(
                    f"[CodeLearner] Cycle {cycle} done — "
                    f"processed={self._stats['files_processed']} "
                    f"mastered={self._stats['mastered']} "
                    f"errors={self._stats['errors']}"
                )
                self._stop.wait(self._CYCLE_INTERVAL)
            except Exception as e:
                log.error(f"[CodeLearner] Cycle error: {e}")
                self._stop.wait(30)
        self._running = False
        log.info("[CodeLearner] Engine stopped")

    def analyze_file(self, file_path: str) -> Dict:
        if not os.path.isfile(file_path):
            return {"error": f"File not found: {file_path}"}
        unit = _indexer.load_single(file_path, "on_demand")
        if not unit:
            return {"error": "Could not load file (unsupported or unreadable)"}
        model      = _analyze(unit)
        existing   = _db.get_record(file_path)
        rec, model = _mastery_proc.process(unit, model, existing)
        _db.upsert(rec, model)
        return {
            "file":       unit.file_name,
            "language":   unit.language,
            "family":     unit.family,
            "confidence": rec.confidence,
            "mastery":    rec.mastery_complete,
            "depths":     rec.depths_done,
            "role":       model.behavioral_role,
            "role_confidence": model.role_confidence,
            "maintainability": model.maintainability,
            "halstead":   {"volume": model.halstead_volume,
                           "difficulty": model.halstead_difficulty,
                           "effort": model.halstead_effort},
            "pure_functions":  model.pure_functions,
            "dead_functions":  model.dead_functions,
            "recursive_fns":   model.recursive_fns,
            "taint_paths":     model.taint_paths,
            "call_chains":     model.call_chains,
            "max_chain_depth": model.max_chain_depth,
            "analysis_depth":  model.analysis_depth,
        }

    def analyze_snippet(self, code: str, language: str = "python") -> Dict:
        fam   = _get_family(language)
        fhash = hashlib.md5(code.encode()).hexdigest()
        unit  = CodeUnit(
            file_path=f"snippet://{fhash[:16]}",
            file_name=f"snippet.{language[:6]}",
            language=language, family=fam,
            size_bytes=len(code.encode()),
            source=code, file_hash=fhash, source_tag="snippet",
        )
        model      = _analyze(unit)
        existing   = _db.get_record(unit.file_path)
        rec, model = _mastery_proc.process(unit, model, existing)
        _db.upsert(rec, model)
        return {
            "language":        language,
            "confidence":      rec.confidence,
            "mastery":         rec.mastery_complete,
            "role":            model.behavioral_role,
            "maintainability": model.maintainability,
            "pure_functions":  model.pure_functions,
            "dead_functions":  model.dead_functions,
            "taint_paths":     model.taint_paths,
            "call_chains":     model.call_chains,
        }


_engine_lock:     threading.Lock                   = threading.Lock()
_engine_instance: Optional[CodeLearnerEngine]      = None


def get_code_learner() -> CodeLearnerEngine:
    global _engine_instance
    with _engine_lock:
        if _engine_instance is None:
            _engine_instance = CodeLearnerEngine()
        return _engine_instance


# ============================================================================
# SELF-REGISTRATION
# ============================================================================

def patch_app_py() -> Dict:
    """
    Safe one-time patch of app.py to register code_learner_bp.
    Idempotent · timestamped backup · syntax-verified · auto-reverts on error.
    """
    app_path = os.path.join(ZEUS_DIR, "app.py")
    if not os.path.isfile(app_path):
        return {"error": "app.py not found"}
    with open(app_path, encoding="utf-8") as f:
        content = f.read()
    if "zeus_code_learner" in content:
        return {"status": "already_registered", "skipped": True}
    ts  = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    bak = f"{app_path}.bak_{ts}"
    shutil.copy2(app_path, bak)
    inject = '    _loaded += _register("zeus_code_learner",       "code_learner_bp")'
    target = '_loaded += _register("zeus_recursive_learner"'
    if target not in content:
        target = '_loaded += _register("zeus_search"'
    if target not in content:
        return {"error": "Injection point not found — register manually", "backup": bak}
    new_content = content.replace(target, inject + "\n    " + target)
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(new_content)
    try:
        result = subprocess.run(
            ["python3", "-m", "py_compile", app_path],
            capture_output=True, timeout=15
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.decode(errors="replace"))
    except Exception as e:
        shutil.copy2(bak, app_path)
        return {"error": f"Syntax error — reverted. Details: {e}", "backup": bak}
    log.info(f"[CodeLearner] app.py patched. Backup: {bak}")
    return {"status": "patched", "injected": inject, "backup": bak}


# ============================================================================
# FLASK BLUEPRINT — REST API
# ============================================================================

@code_learner_bp.route("/api/code_learner/health")
def cl_health():
    engine = get_code_learner()
    stats  = _db.get_stats()
    return jsonify({
        "status":        "ok",
        "module":        "zeus_code_learner",
        "version":       "v2.0",
        "running":       engine.is_running(),
        "mastery_stats": stats,
        "project":       "The Zeus Project 2026",
        "architect":     "Francois Nel",
    })


@code_learner_bp.route("/api/code_learner/start", methods=["POST"])
def cl_start():
    return jsonify(get_code_learner().start())


@code_learner_bp.route("/api/code_learner/stop", methods=["POST"])
def cl_stop():
    return jsonify(get_code_learner().stop())


@code_learner_bp.route("/api/code_learner/status")
def cl_status():
    engine = get_code_learner()
    return jsonify({
        "running":       engine.is_running(),
        "engine_stats":  engine.get_stats(),
        "mastery_stats": _db.get_stats(),
        "mastery_system": {
            "stages":              DEPTHS,
            "confidence_per_stage": DEPTH_CONFIDENCE,
            "max_confidence":      1.0,
        },
        "languages":  len(LANG_MAP),
        "families":   len(LANG_FAMILIES),
        "version":    "v2.0",
    })


@code_learner_bp.route("/api/code_learner/intelligence")
def cl_intelligence():
    language = request.args.get("language", "")
    family   = request.args.get("family", "")
    limit    = min(int(request.args.get("limit", 50)), 500)
    try:
        records = _db.query_records(language=language, family=family, limit=limit)
        return jsonify({"count": len(records), "records": records})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@code_learner_bp.route("/api/code_learner/semantic")
def cl_semantic():
    """Return the full stored semantic model for a file."""
    file_path = request.args.get("file_path", "")
    if not file_path:
        return jsonify({"error": "Provide ?file_path="}), 400
    model = _db.get_semantic(file_path)
    if not model:
        return jsonify({"error": "Not found — run /analyze first"}), 404
    return jsonify(model)


@code_learner_bp.route("/api/code_learner/analyze", methods=["POST"])
def cl_analyze():
    data = request.get_json(silent=True) or {}
    if "file_path" in data:
        return jsonify(get_code_learner().analyze_file(data["file_path"]))
    if "code" in data:
        lang = data.get("language", "python")
        return jsonify(get_code_learner().analyze_snippet(data["code"], lang))
    return jsonify({"error": "Provide 'file_path' or 'code' in body"}), 400


@code_learner_bp.route("/api/code_learner/mastery")
def cl_mastery():
    return jsonify({
        "mastery_system": {
            "stages":               DEPTHS,
            "confidence_per_stage": DEPTH_CONFIDENCE,
            "max_confidence":       1.0,
            "semantic_features": [
                "call_graph", "cognitive_complexity", "halstead_metrics",
                "pure_function_detection", "dead_code_detection",
                "taint_tracking", "recursive_detection", "behavioral_classification",
                "maintainability_index", "entry_point_mapping",
            ],
        },
        "stats":    _db.get_stats(),
        "families": list(LANG_FAMILIES.keys()),
    })


@code_learner_bp.route("/api/code_learner/languages")
def cl_languages():
    return jsonify({
        "total_extensions": len(LANG_MAP),
        "total_languages":  len(set(LANG_MAP.values())),
        "extension_map":    LANG_MAP,
        "families":         LANG_FAMILIES,
    })


@code_learner_bp.route("/api/code_learner/extensions")
def cl_extensions():
    """Return all known extensions: static LANG_MAP + dynamically learned."""
    with _dynamic_ext_lock:
        dyn_copy = dict(_dynamic_ext_registry)
    return jsonify({
        "static_extensions":  len(LANG_MAP),
        "dynamic_extensions": len(dyn_copy),
        "total_extensions":   len(LANG_MAP) + len(dyn_copy),
        "static_map":         LANG_MAP,
        "dynamic_registry":   dyn_copy,
        "registry_path":      _DYN_REGISTRY_PATH,
    })


@code_learner_bp.route("/api/code_learner/self_register", methods=["POST"])
def cl_self_register():
    return jsonify(patch_app_py())


# ============================================================================
# BOOT
# ============================================================================

def _boot():
    try:
        _db.ensure_schema()
        _load_dynamic_registry()
        dyn_count = len(_dynamic_ext_registry)
        log.info(
            "[CodeLearner] v2.0 schema ready — "
            f"{len(LANG_MAP)} static extensions · "
            f"{dyn_count} dynamic extensions loaded · "
            f"{len(set(LANG_MAP.values()))} languages · "
            "full_ast+halstead+callgraph+taint+deadcode+unknown_sniff "
            "— The Zeus Project 2026"
        )
    except Exception as e:
        log.error(f"[CodeLearner] Boot error: {e}")


_boot()
