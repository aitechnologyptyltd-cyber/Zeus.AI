# The Zeus Project 2026 — Francois Nel
# zeus_identity.py — Zeus Identity, Authorship & Capability Registry
# System fingerprint · Module registry · Replication headers · Self-description API
# Every Zeus module calls get_authorship_header() — this is the authorship spine.

import os
import sys
import math
import time
import json
import uuid
import hashlib
import platform
import threading
import subprocess
import logging
from collections import defaultdict, OrderedDict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.identity")

identity_bp = Blueprint("identity", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================================
# AUTHORSHIP CONSTANTS
# ============================================================================

AUTHORSHIP_HEADER   = "# The Zeus Project 2026 — Francois Nel"
PROJECT_NAME        = "The Zeus Project 2026"
ARCHITECT           = "Francois Nel"
LOCATION            = "South Africa"
DEVICE              = "Hisense Y82 Pro"
ZEUS_VERSION        = "v4.0"
ZEUS_CODENAME       = "Olympus"
BUILD_DATE          = "2026"

ZEUS_MISSION = (
    "Autonomous self-evolving artificial intelligence. "
    "Built by one man on a single Android device. "
    "Learns continuously. Evolves nightly. Never stops."
)

ZEUS_SIGNATURE_LONG = (
    f"\n\n{'='*60}\n"
    f"  {PROJECT_NAME}\n"
    f"  Architect : {ARCHITECT}\n"
    f"  Location  : {LOCATION}\n"
    f"  Version   : {ZEUS_VERSION} '{ZEUS_CODENAME}'\n"
    f"  Mission   : {ZEUS_MISSION}\n"
    f"{'='*60}\n"
)

# ============================================================================
# MODULE CAPABILITY REGISTRY
# ============================================================================

@dataclass
class ModuleCapability:
    """Describes a single capability exposed by a Zeus module."""
    module_name:   str
    capability_id: str
    description:   str
    endpoint:      str
    method:        str = "GET"
    input_schema:  Dict = field(default_factory=dict)
    output_schema: Dict = field(default_factory=dict)
    dependencies:  List[str] = field(default_factory=list)
    tags:          List[str] = field(default_factory=list)
    version:       str = "1.0"
    online:        bool = True


@dataclass
class ModuleRegistration:
    """Full registration record for a Zeus module."""
    module_name:    str
    blueprint_var:  str
    url_prefix:     str
    version:        str
    description:    str
    capabilities:   List[ModuleCapability] = field(default_factory=list)
    health_url:     str = ""
    stats_url:      str = ""
    depends_on:     List[str] = field(default_factory=list)
    status:         str = "registered"
    boot_order:     int = 100
    registered_at:  float = field(default_factory=time.time)
    last_health_ms: float = 0.0
    error_count:    int = 0

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["registered_at"] = datetime.fromtimestamp(
            self.registered_at, tz=timezone.utc
        ).isoformat()
        return d


# ============================================================================
# CAPABILITY REGISTRY (SINGLETON)
# ============================================================================

class CapabilityRegistry:
    """
    Central registry of all Zeus module capabilities.
    Modules register themselves on boot; consumers query here.
    Thread-safe singleton.
    """

    def __init__(self):
        self._lock    = threading.RLock()
        self._modules: OrderedDict[str, ModuleRegistration] = OrderedDict()
        self._caps:    Dict[str, ModuleCapability]           = {}
        self._tags:    Dict[str, List[str]]                  = defaultdict(list)
        self._boot_time = time.time()

    # ---- Registration ---------------------------------------------------

    def register_module(self, reg: ModuleRegistration) -> None:
        with self._lock:
            self._modules[reg.module_name] = reg
            for cap in reg.capabilities:
                self._caps[cap.capability_id] = cap
                for tag in cap.tags:
                    if cap.capability_id not in self._tags[tag]:
                        self._tags[tag].append(cap.capability_id)
            log.info(
                f"[Identity] Registered module '{reg.module_name}' "
                f"with {len(reg.capabilities)} capability/ies"
            )
            self._persist_module(reg)

    def register_capability(self, cap: ModuleCapability) -> None:
        with self._lock:
            self._caps[cap.capability_id] = cap
            for tag in cap.tags:
                if cap.capability_id not in self._tags[tag]:
                    self._tags[tag].append(cap.capability_id)

    # ---- Query ----------------------------------------------------------

    def get_module(self, name: str) -> Optional[ModuleRegistration]:
        with self._lock:
            return self._modules.get(name)

    def list_modules(self) -> List[Dict]:
        with self._lock:
            return [m.to_dict() for m in self._modules.values()]

    def get_capability(self, cap_id: str) -> Optional[ModuleCapability]:
        with self._lock:
            return self._caps.get(cap_id)

    def find_by_tag(self, tag: str) -> List[ModuleCapability]:
        with self._lock:
            return [self._caps[cid] for cid in self._tags.get(tag, []) if cid in self._caps]

    def find_by_endpoint(self, endpoint: str) -> Optional[ModuleCapability]:
        with self._lock:
            for cap in self._caps.values():
                if endpoint in cap.endpoint:
                    return cap
            return None

    def capability_map(self) -> Dict[str, List[str]]:
        """Returns {module_name: [capability_id, ...]} for all modules."""
        with self._lock:
            return {
                name: [c.capability_id for c in reg.capabilities]
                for name, reg in self._modules.items()
            }

    def dependency_graph(self) -> Dict[str, List[str]]:
        with self._lock:
            return {name: reg.depends_on for name, reg in self._modules.items()}

    def uptime_seconds(self) -> float:
        return round(time.time() - self._boot_time, 1)

    def stats(self) -> Dict:
        with self._lock:
            return {
                "total_modules":      len(self._modules),
                "total_capabilities": len(self._caps),
                "total_tags":         len(self._tags),
                "uptime_s":           self.uptime_seconds(),
                "modules":            list(self._modules.keys()),
            }

    # ---- Health check pass-through --------------------------------------

    def update_module_health(self, module_name: str,
                              latency_ms: float, error: bool = False) -> None:
        with self._lock:
            reg = self._modules.get(module_name)
            if reg:
                reg.last_health_ms = latency_ms
                if error:
                    reg.error_count += 1
                    reg.status = "degraded"
                else:
                    reg.status = "healthy"

    # ---- Persistence (best-effort) --------------------------------------

    def _persist_module(self, reg: ModuleRegistration) -> None:
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                INSERT OR REPLACE INTO module_registry
                    (module_name, blueprint_var, url_prefix, status,
                     version, health_url, boot_order, registered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
                """,
                (reg.module_name, reg.blueprint_var, reg.url_prefix,
                 reg.status, reg.version, reg.health_url, reg.boot_order)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.debug(f"[Identity] Registry persist skipped: {e}")


_registry_lock     = threading.RLock()
_registry_instance: Optional[CapabilityRegistry] = None


def get_registry() -> CapabilityRegistry:
    global _registry_instance
    with _registry_lock:
        if _registry_instance is None:
            _registry_instance = CapabilityRegistry()
        return _registry_instance


# ============================================================================
# SYSTEM FINGERPRINT
# ============================================================================

class SystemFingerprint:
    """
    Collects hardware, OS, Python, and Zeus environment information.
    Used for identity headers, replication metadata, and health reports.
    """

    _cache:     Optional[Dict] = None
    _cache_ttl: float          = 60.0
    _cache_ts:  float          = 0.0
    _lock       = threading.Lock()

    @classmethod
    def get(cls, force: bool = False) -> Dict:
        with cls._lock:
            if not force and cls._cache and (time.time() - cls._cache_ts < cls._cache_ttl):
                return cls._cache
            info = cls._collect()
            cls._cache    = info
            cls._cache_ts = time.time()
            return info

    @classmethod
    def _collect(cls) -> Dict:
        info: Dict[str, Any] = {}

        # OS / platform
        info["os"]           = platform.system()
        info["os_release"]   = platform.release()
        info["os_version"]   = platform.version()[:80]
        info["machine"]      = platform.machine()
        info["processor"]    = platform.processor() or platform.machine()
        info["hostname"]     = platform.node()
        info["python"]       = platform.python_version()
        info["python_impl"]  = platform.python_implementation()

        # CPU
        try:
            cpu_count = os.cpu_count() or 1
            info["cpu_count"] = cpu_count
            # Try /proc/cpuinfo for ARM device name
            if os.path.exists("/proc/cpuinfo"):
                raw = open("/proc/cpuinfo").read()
                hw_match = __import__("re").search(r"Hardware\s*:\s*(.+)", raw)
                model_match = __import__("re").search(r"model name\s*:\s*(.+)", raw)
                info["cpu_hardware"] = hw_match.group(1).strip() if hw_match else ""
                info["cpu_model"]    = model_match.group(1).strip() if model_match else ""
        except Exception:
            info["cpu_count"] = 1

        # Memory
        try:
            if os.path.exists("/proc/meminfo"):
                raw = open("/proc/meminfo").read()
                total = __import__("re").search(r"MemTotal:\s+(\d+)", raw)
                avail = __import__("re").search(r"MemAvailable:\s+(\d+)", raw)
                info["ram_total_mb"] = round(int(total.group(1)) / 1024, 0) if total else 0
                info["ram_avail_mb"] = round(int(avail.group(1)) / 1024, 0) if avail else 0
        except Exception:
            pass

        # Disk
        try:
            stat = os.statvfs(ZEUS_DIR)
            info["disk_free_mb"]  = round(stat.f_bavail * stat.f_frsize / 1024 / 1024, 1)
            info["disk_total_mb"] = round(stat.f_blocks * stat.f_frsize / 1024 / 1024, 1)
        except Exception:
            pass

        # Zeus-specific
        info["zeus_dir"]     = ZEUS_DIR
        info["zeus_version"] = ZEUS_VERSION
        info["zeus_codename"]= ZEUS_CODENAME
        info["architect"]    = ARCHITECT
        info["location"]     = LOCATION
        info["project"]      = PROJECT_NAME

        # Device identity hash (stable across reboots)
        fingerprint_source = f"{info.get('hostname','')}{info.get('machine','')}{ZEUS_DIR}"
        info["device_id"] = hashlib.sha256(fingerprint_source.encode()).hexdigest()[:16]

        # Python environment
        info["python_path"] = sys.executable
        info["sys_path"]    = sys.path[:3]

        # Check which LLM keys are configured
        info["llm_keys"] = {
            "groq":       bool(os.environ.get("GROQ_API_KEY")),
            "claude":     bool(os.environ.get("ANTHROPIC_API_KEY")),
            "openrouter": bool(os.environ.get("OPENROUTER_API_KEY")),
            "xai":        bool(os.environ.get("XAI_API_KEY")),
        }

        return info


# ============================================================================
# AUTHORSHIP HELPERS
# ============================================================================

def get_authorship_header(module_name: str = "", description: str = "",
                           include_device: bool = False) -> str:
    """
    Returns the standard Zeus authorship header for any generated file.
    Every generated Python file should call this at the top.
    """
    lines = [AUTHORSHIP_HEADER]
    if module_name:
        lines.append(f"# {module_name}")
    if description:
        lines.append(f"# {description}")
    if include_device:
        fp = SystemFingerprint.get()
        lines.append(f"# Device: {fp.get('hostname','unknown')} | {fp.get('machine','')}")
    lines.append(f"# Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    return "\n".join(lines)


def get_replication_header(target_system: str = "",
                            replication_id: str = "") -> Dict:
    """
    Returns a full replication metadata dict for use in module exports,
    APK packages, and cross-device deployments.
    """
    fp = SystemFingerprint.get()
    return {
        "project":          PROJECT_NAME,
        "architect":        ARCHITECT,
        "version":          ZEUS_VERSION,
        "codename":         ZEUS_CODENAME,
        "source_device_id": fp.get("device_id", ""),
        "source_hostname":  fp.get("hostname", ""),
        "source_arch":      fp.get("machine", ""),
        "target_system":    target_system,
        "replication_id":   replication_id or uuid.uuid4().hex,
        "timestamp":        datetime.now(timezone.utc).isoformat(),
        "signature":        AUTHORSHIP_HEADER,
    }


def compute_module_hash(module_name: str) -> Optional[str]:
    """Compute SHA256 of a Zeus module file for integrity checking."""
    path = os.path.join(ZEUS_DIR, f"{module_name}.py")
    if not os.path.isfile(path):
        return None
    try:
        data = open(path, "rb").read()
        return hashlib.sha256(data).hexdigest()
    except Exception:
        return None


def get_module_manifest() -> List[Dict]:
    """
    Returns integrity manifest for all Zeus .py modules in ZEUS_DIR.
    Used by replication engine for package verification.
    """
    manifest = []
    for fname in sorted(os.listdir(ZEUS_DIR)):
        if not fname.endswith(".py"):
            continue
        path = os.path.join(ZEUS_DIR, fname)
        try:
            size = os.path.getsize(path)
            mtime = os.path.getmtime(path)
            data  = open(path, "rb").read()
            sha   = hashlib.sha256(data).hexdigest()
            manifest.append({
                "filename": fname,
                "size_bytes": size,
                "sha256": sha,
                "modified_at": datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat(),
            })
        except Exception as e:
            manifest.append({"filename": fname, "error": str(e)})
    return manifest


# ============================================================================
# FLASK ROUTES
# ============================================================================

@identity_bp.route("/api/identity", methods=["GET"])
def identity_info():
    """Return full Zeus identity + system fingerprint."""
    try:
        fp  = SystemFingerprint.get()
        reg = get_registry()
        return jsonify({
            "identity": {
                "name":        "Zeus",
                "version":     ZEUS_VERSION,
                "codename":    ZEUS_CODENAME,
                "project":     PROJECT_NAME,
                "architect":   ARCHITECT,
                "location":    LOCATION,
                "device":      DEVICE,
                "mission":     ZEUS_MISSION,
                "authorship":  AUTHORSHIP_HEADER,
            },
            "system":    fp,
            "registry":  reg.stats(),
            "uptime_s":  reg.uptime_seconds(),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@identity_bp.route("/api/identity/health", methods=["GET"])
def identity_health():
    return jsonify({
        "status":  "ok",
        "module":  "zeus_identity",
        "version": ZEUS_VERSION,
        "uptime_s": get_registry().uptime_seconds(),
    })


@identity_bp.route("/api/identity/fingerprint", methods=["GET"])
def identity_fingerprint():
    """Return raw system fingerprint."""
    try:
        force = request.args.get("force", "false").lower() == "true"
        return jsonify(SystemFingerprint.get(force=force))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@identity_bp.route("/api/identity/authorship", methods=["POST"])
def identity_authorship():
    """
    Generate an authorship header for a given module and description.
    POST { "module_name": "...", "description": "..." }
    """
    data   = request.get_json(force=True, silent=True) or {}
    module = data.get("module_name", "")
    desc   = data.get("description", "")
    incl_device = bool(data.get("include_device", False))
    header = get_authorship_header(module, desc, incl_device)
    return jsonify({
        "header":      header,
        "module_name": module,
        "description": desc,
        "timestamp":   datetime.now(timezone.utc).isoformat(),
    })


@identity_bp.route("/api/identity/replication_header", methods=["POST"])
def identity_replication_header():
    """
    Generate replication header for cross-device deployment.
    POST { "target_system": "...", "replication_id": "..." }
    """
    data   = request.get_json(force=True, silent=True) or {}
    target = data.get("target_system", "")
    rid    = data.get("replication_id", "")
    return jsonify(get_replication_header(target, rid))


@identity_bp.route("/api/identity/manifest", methods=["GET"])
def identity_manifest():
    """Return SHA256 manifest of all Zeus .py modules."""
    try:
        return jsonify({
            "manifest":  get_module_manifest(),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "zeus_dir":  ZEUS_DIR,
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@identity_bp.route("/api/identity/modules", methods=["GET"])
def identity_modules():
    """List all registered modules and their capabilities."""
    try:
        reg     = get_registry()
        modules = reg.list_modules()
        cap_map = reg.capability_map()
        dep_map = reg.dependency_graph()
        return jsonify({
            "modules":          modules,
            "capability_map":   cap_map,
            "dependency_graph": dep_map,
            "total_modules":    len(modules),
            "total_capabilities": sum(len(v) for v in cap_map.values()),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@identity_bp.route("/api/identity/register_module", methods=["POST"])
def identity_register_module():
    """
    Register a module's capabilities at runtime.
    POST {
      "module_name": "zeus_forge",
      "blueprint_var": "forge_bp",
      "url_prefix": "/api/forge",
      "version": "1.0",
      "description": "...",
      "capabilities": [...]
    }
    """
    data = request.get_json(force=True, silent=True) or {}
    try:
        caps = [
            ModuleCapability(
                module_name=data.get("module_name", ""),
                capability_id=c.get("capability_id", uuid.uuid4().hex[:8]),
                description=c.get("description", ""),
                endpoint=c.get("endpoint", ""),
                method=c.get("method", "GET"),
                tags=c.get("tags", []),
                dependencies=c.get("dependencies", []),
            )
            for c in data.get("capabilities", [])
        ]
        reg = ModuleRegistration(
            module_name=data.get("module_name", ""),
            blueprint_var=data.get("blueprint_var", ""),
            url_prefix=data.get("url_prefix", ""),
            version=data.get("version", "1.0"),
            description=data.get("description", ""),
            capabilities=caps,
            health_url=data.get("health_url", ""),
            depends_on=data.get("depends_on", []),
            boot_order=int(data.get("boot_order", 100)),
        )
        get_registry().register_module(reg)
        return jsonify({"status": "ok", "module": reg.module_name, "capabilities": len(caps)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@identity_bp.route("/api/identity/stats", methods=["GET"])
def identity_stats():
    """Return registry stats."""
    try:
        return jsonify(get_registry().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@identity_bp.route("/api/identity/signature", methods=["GET"])
def identity_signature():
    """Return full Zeus signature block for embedding in generated code."""
    return jsonify({
        "short":     AUTHORSHIP_HEADER,
        "long":      ZEUS_SIGNATURE_LONG,
        "mission":   ZEUS_MISSION,
        "version":   ZEUS_VERSION,
        "architect": ARCHITECT,
    })


# ============================================================================
# MODULE REGISTRATION HELPER — called by other modules on boot
# ============================================================================

def register_self(
    module_name:   str,
    blueprint_var: str,
    url_prefix:    str,
    version:       str        = "1.0",
    description:   str        = "",
    capabilities:  List[Dict] = None,
    depends_on:    List[str]  = None,
    boot_order:    int        = 100,
) -> None:
    """
    Called by any Zeus module to register itself with the identity registry.
    Should be called inside the module's register(app) function.
    """
    caps = [
        ModuleCapability(
            module_name=module_name,
            capability_id=c.get("id", f"{module_name}_{i}"),
            description=c.get("description", ""),
            endpoint=c.get("endpoint", ""),
            method=c.get("method", "GET"),
            tags=c.get("tags", []),
            dependencies=c.get("dependencies", []),
        )
        for i, c in enumerate(capabilities or [])
    ]
    reg = ModuleRegistration(
        module_name=module_name,
        blueprint_var=blueprint_var,
        url_prefix=url_prefix,
        version=version,
        description=description,
        capabilities=caps,
        health_url=f"{url_prefix}/health",
        depends_on=depends_on or [],
        boot_order=boot_order,
    )
    get_registry().register_module(reg)


# ============================================================================
# BLUEPRINT REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(identity_bp)
    log.info("[identity] ✓ Registered at /api/identity")
    # Self-register
    register_self(
        module_name="zeus_identity",
        blueprint_var="identity_bp",
        url_prefix="/api/identity",
        version=ZEUS_VERSION,
        description="Zeus identity, system fingerprint, and module capability registry",
        capabilities=[
            {"id": "identity.info",         "endpoint": "/api/identity",            "method": "GET",  "tags": ["identity"]},
            {"id": "identity.health",        "endpoint": "/api/identity/health",     "method": "GET",  "tags": ["health"]},
            {"id": "identity.fingerprint",   "endpoint": "/api/identity/fingerprint","method": "GET",  "tags": ["system"]},
            {"id": "identity.authorship",    "endpoint": "/api/identity/authorship", "method": "POST", "tags": ["codegen"]},
            {"id": "identity.replication",   "endpoint": "/api/identity/replication_header","method":"POST","tags":["replication"]},
            {"id": "identity.manifest",      "endpoint": "/api/identity/manifest",   "method": "GET",  "tags": ["integrity"]},
            {"id": "identity.modules",       "endpoint": "/api/identity/modules",    "method": "GET",  "tags": ["registry"]},
            {"id": "identity.register",      "endpoint": "/api/identity/register_module","method":"POST","tags":["registry"]},
            {"id": "identity.stats",         "endpoint": "/api/identity/stats",      "method": "GET",  "tags": ["stats"]},
        ],
        boot_order=5,
    )


# ============================================================================
# STANDALONE
# ============================================================================

if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5010, debug=True, use_reloader=False)
