# The Zeus Project 2026 — Francois Nel
# zeus_sys_aware.py — System Awareness & Environmental Adaptation Engine v1.0
# ══════════════════════════════════════════════════════════════════════════════
#
# ARCHITECTURE ROLE:  LAYER 8 — ENVIRONMENTAL AWARENESS
#
# Zeus has always scanned his own code. Now he scans his world.
#
# This module gives Zeus full situational awareness of the physical and
# operating environment he runs in. Every 10 minutes a daemon polls:
#
#   ▸ CPU_LAYER      — architecture, cores, clock, ARM feature flags
#   ▸ MEMORY_LAYER   — total, available, swap, pressure, huge pages
#   ▸ DISK_LAYER     — I/O patterns, filesystem type, throughput, latency
#   ▸ KERNEL_LAYER   — version, syscalls, loaded modules, capabilities
#   ▸ NETWORK_LAYER  — interfaces, open ports, latency, bandwidth
#   ▸ PROCESS_LAYER  — running processes, cgroup support, namespace support
#   ▸ RESOURCE_LAYER — live load average, fd limits, inode pressure
#
# The live scan is published as a shared OperationalContext object that
# any Zeus module can import and query synchronously — zero API call needed.
#
# AUTONOMOUS ADAPTATION ENGINE:
#   Reads OperationalContext and fires constraint-aware rules:
#   - Switches code-gen to ARM-safe patterns when armv7l confirmed
#   - Flags hot Python paths for ARM assembly rewrite (.s + gcc pipeline)
#   - Falls back to C-extension pattern suggestions when gcc unavailable
#   - Activates memory-mapped I/O preference under memory pressure
#   - Gates web-harvesting jobs on network availability
#   - Routes evolution sandboxes through cgroup isolation if available
#   - Compresses data structures under storage pressure
#   - Caches aggressively under high network latency
#
# ARM ASSEMBLY CODE GENERATOR:
#   zeus_sys_aware generates real .s files for hot Python paths and
#   compiles them via gcc/as into .so shared libraries callable from
#   ctypes. Full fallback to C-extension pattern suggester if gcc absent.
#
# APP.PY REGISTRATION (LAYER 8):
#   _loaded += _register("zeus_sys_aware", "sys_aware_bp")
#
# SCHEDULER HOOK (zeus_nightly_scheduler.py DEFAULT_JOBS):
#   ScheduledJob("sys_aware_deep_scan", "Deep System Scan", 4, 0,
#                "_job_sys_aware_deep_scan", priority=10, timeout_s=180)
#
# API ROUTES:
#   GET  /api/sysaware/context          — full live OperationalContext JSON
#   GET  /api/sysaware/cpu              — CPU profile
#   GET  /api/sysaware/memory           — memory profile
#   GET  /api/sysaware/disk             — disk I/O profile
#   GET  /api/sysaware/kernel           — kernel capabilities
#   GET  /api/sysaware/network          — network profile
#   GET  /api/sysaware/constraints      — derived constraint profile
#   GET  /api/sysaware/adaptations      — active adaptation decisions
#   GET  /api/sysaware/hotpaths         — hot Python paths flagged for rewrite
#   POST /api/sysaware/compile_hotpath  — trigger ARM asm rewrite for path
#   GET  /api/sysaware/asm_builds       — all compiled .so artefacts
#   POST /api/sysaware/force_scan       — trigger immediate full scan
#   GET  /api/sysaware/history          — scan history (last 48 cycles)
#   GET  /api/sysaware/health           — daemon health
# ══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations

import ast
import ctypes
import glob
import hashlib
import json
import logging
import mmap
import os
import platform
import re
import shutil
import signal
import socket
import sqlite3
import struct
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from flask import Blueprint, jsonify, request

# ──────────────────────────────────────────────────────────────────────────────
# LOGGING & BLUEPRINT
# ──────────────────────────────────────────────────────────────────────────────

log = logging.getLogger("zeus.sysaware")

sys_aware_bp = Blueprint("sys_aware", __name__)

ZEUS_DIR    = os.path.dirname(os.path.abspath(__file__))
ASM_DIR     = os.path.join(ZEUS_DIR, "asm_builds")
LOGS_DIR    = os.path.join(ZEUS_DIR, "logs")
DB_PATH     = os.path.join(ZEUS_DIR, "zeus.db")

for _d in [ASM_DIR, LOGS_DIR]:
    os.makedirs(_d, exist_ok=True)

# ──────────────────────────────────────────────────────────────────────────────
# DATABASE INITIALISATION
# ──────────────────────────────────────────────────────────────────────────────

def _init_db():
    con = sqlite3.connect(DB_PATH)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS sys_aware_scans (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id     TEXT UNIQUE NOT NULL,
            scanned_at  TEXT NOT NULL,
            context_json TEXT NOT NULL,
            constraints_json TEXT NOT NULL,
            adaptations_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sys_aware_asm_builds (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            build_id    TEXT UNIQUE NOT NULL,
            built_at    TEXT NOT NULL,
            source_path TEXT NOT NULL,
            asm_path    TEXT NOT NULL,
            so_path     TEXT NOT NULL,
            fn_name     TEXT NOT NULL,
            success     INTEGER NOT NULL DEFAULT 0,
            error       TEXT,
            notes       TEXT
        );
        CREATE TABLE IF NOT EXISTS sys_aware_hotpaths (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            detected_at TEXT NOT NULL,
            file_path   TEXT NOT NULL,
            fn_name     TEXT NOT NULL,
            reason      TEXT NOT NULL,
            complexity  INTEGER,
            suggestion  TEXT,
            status      TEXT DEFAULT 'pending'
        );
    """)
    con.commit()
    con.close()

_init_db()

# ──────────────────────────────────────────────────────────────────────────────
# DATA STRUCTURES
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class CPUProfile:
    architecture:   str = ""          # armv7l, aarch64, x86_64 …
    bits:           int = 32
    cores:          int = 1
    model_name:     str = ""
    max_freq_mhz:   float = 0.0
    cur_freq_mhz:   float = 0.0
    arm_features:   List[str] = field(default_factory=list)   # neon, vfpv4 …
    byte_order:     str = ""
    cache_l1_kb:    int = 0
    cache_l2_kb:    int = 0
    load_1m:        float = 0.0
    load_5m:        float = 0.0
    load_15m:       float = 0.0
    is_arm:         bool = False
    is_armv7l:      bool = False
    supports_neon:  bool = False
    supports_vfp:   bool = False

@dataclass
class MemoryProfile:
    total_mb:       float = 0.0
    available_mb:   float = 0.0
    used_mb:        float = 0.0
    free_mb:        float = 0.0
    cached_mb:      float = 0.0
    swap_total_mb:  float = 0.0
    swap_used_mb:   float = 0.0
    swap_free_mb:   float = 0.0
    pressure_pct:   float = 0.0   # used/total * 100
    huge_pages:     bool = False
    mmap_available: bool = True

@dataclass
class DiskProfile:
    root_total_gb:  float = 0.0
    root_used_gb:   float = 0.0
    root_free_gb:   float = 0.0
    root_fs_type:   str = ""
    zeus_dir_gb:    float = 0.0
    read_bps:       float = 0.0   # bytes/s measured over 1s
    write_bps:      float = 0.0
    inode_pct:      float = 0.0
    io_scheduler:   str = ""
    storage_pressure: bool = False  # <500 MB free

@dataclass
class KernelProfile:
    version:           str = ""
    release:           str = ""
    machine:           str = ""
    cgroups_v1:        bool = False
    cgroups_v2:        bool = False
    namespaces:        bool = False
    seccomp:           bool = False
    perf_events:       bool = False
    loaded_modules:    List[str] = field(default_factory=list)
    max_open_files:    int = 0
    open_files:        int = 0
    available_syscalls: List[str] = field(default_factory=list)
    gcc_available:     bool = False
    gcc_version:       str = ""
    as_available:      bool = False

@dataclass
class NetworkProfile:
    interfaces:         List[Dict] = field(default_factory=list)
    has_internet:       bool = False
    latency_ms:         float = 0.0
    open_ports:         List[int] = field(default_factory=list)
    listening_services: List[Dict] = field(default_factory=list)
    bandwidth_kbps:     float = 0.0
    dns_resolves:       bool = False

@dataclass
class ConstraintProfile:
    """Translated from raw scan — what Zeus can and cannot do."""
    # code generation
    must_use_arm_safe_code:     bool = False
    can_use_neon_intrinsics:    bool = False
    can_use_simd:               bool = False
    prefer_mmap_io:             bool = False
    # memory
    memory_pressure:            bool = False
    compress_data_structures:   bool = False
    # sandbox / isolation
    can_use_cgroup_sandbox:     bool = False
    can_use_namespace_sandbox:  bool = False
    # networking
    network_available:          bool = False
    can_harvest_web:            bool = False
    cache_aggressively:         bool = False
    # storage
    storage_tight:              bool = False
    # compilation
    gcc_pipeline_available:     bool = False
    fallback_to_c_suggestions:  bool = False
    # assembly
    asm_target_arch:            str = "armv7-a"
    asm_float_abi:              str = "softfp"
    asm_fpu:                    str = "vfpv3"

@dataclass
class AdaptationDecision:
    decision_id:  str
    decided_at:   str
    category:     str   # CODE_GEN | MEMORY | SANDBOX | NETWORK | STORAGE | ASM
    action:       str
    reason:       str
    active:       bool = True

@dataclass
class OperationalContext:
    """Single source of truth — published every 10 min, read by all modules."""
    context_id:    str = ""
    captured_at:   str = ""
    cpu:           CPUProfile    = field(default_factory=CPUProfile)
    memory:        MemoryProfile = field(default_factory=MemoryProfile)
    disk:          DiskProfile   = field(default_factory=DiskProfile)
    kernel:        KernelProfile = field(default_factory=KernelProfile)
    network:       NetworkProfile= field(default_factory=NetworkProfile)
    constraints:   ConstraintProfile = field(default_factory=ConstraintProfile)
    adaptations:   List[AdaptationDecision] = field(default_factory=list)
    scan_duration_s: float = 0.0

    def to_dict(self) -> Dict:
        return asdict(self)

# ──────────────────────────────────────────────────────────────────────────────
# GLOBAL LIVE CONTEXT — MODULE-LEVEL SINGLETON
# Any Zeus module can:  from zeus_sys_aware import get_context
# ──────────────────────────────────────────────────────────────────────────────

_ctx_lock    = threading.RLock()
_live_ctx:   Optional[OperationalContext] = None
_ctx_history: deque = deque(maxlen=48)   # 48 × 10 min = 8 hours

def get_context() -> Optional[OperationalContext]:
    """Return the latest live OperationalContext (thread-safe)."""
    with _ctx_lock:
        return _live_ctx

def _publish_context(ctx: OperationalContext):
    global _live_ctx
    with _ctx_lock:
        _live_ctx = ctx
        _ctx_history.append(ctx)
    log.info("[sysaware] context published — scan_id=%s  %.2fs",
             ctx.context_id, ctx.scan_duration_s)

# ──────────────────────────────────────────────────────────────────────────────
# LAYER SCANNERS
# ──────────────────────────────────────────────────────────────────────────────

def _scan_cpu() -> CPUProfile:
    p = CPUProfile()
    p.architecture = platform.machine()
    p.bits         = struct.calcsize("P") * 8
    p.byte_order   = sys.byteorder
    p.is_arm       = p.architecture.startswith("arm") or p.architecture == "aarch64"
    p.is_armv7l    = p.architecture == "armv7l"

    # /proc/cpuinfo
    try:
        raw = Path("/proc/cpuinfo").read_text()
        cores = raw.count("processor\t:")
        p.cores = max(cores, 1)

        model_m = re.search(r"model name\s*:\s*(.+)", raw)
        if model_m:
            p.model_name = model_m.group(1).strip()

        feat_m = re.search(r"Features\s*:\s*(.+)", raw)
        if feat_m:
            p.arm_features = feat_m.group(1).strip().split()
            p.supports_neon = "neon" in p.arm_features
            p.supports_vfp  = any(f.startswith("vfp") for f in p.arm_features)

        cache_m = re.search(r"cache size\s*:\s*(\d+)\s*KB", raw)
        if cache_m:
            p.cache_l2_kb = int(cache_m.group(1))
    except Exception:
        pass

    # /sys/devices/system/cpu/cpu0/cpufreq
    try:
        max_f = Path("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq").read_text()
        cur_f = Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").read_text()
        p.max_freq_mhz = float(max_f.strip()) / 1000
        p.cur_freq_mhz = float(cur_f.strip()) / 1000
    except Exception:
        pass

    # Load average
    try:
        la = os.getloadavg()
        p.load_1m, p.load_5m, p.load_15m = la
    except Exception:
        pass

    return p


def _scan_memory() -> MemoryProfile:
    m = MemoryProfile()
    try:
        raw = Path("/proc/meminfo").read_text()
        def _kb(key):
            match = re.search(rf"^{key}:\s+(\d+)", raw, re.M)
            return int(match.group(1)) if match else 0

        total   = _kb("MemTotal")
        free    = _kb("MemFree")
        avail   = _kb("MemAvailable")
        cached  = _kb("Cached")
        s_total = _kb("SwapTotal")
        s_free  = _kb("SwapFree")

        m.total_mb      = total   / 1024
        m.free_mb       = free    / 1024
        m.available_mb  = avail   / 1024
        m.cached_mb     = cached  / 1024
        m.used_mb       = (total - avail) / 1024
        m.swap_total_mb = s_total / 1024
        m.swap_free_mb  = s_free  / 1024
        m.swap_used_mb  = (s_total - s_free) / 1024
        m.pressure_pct  = (m.used_mb / m.total_mb * 100) if m.total_mb else 0
        m.huge_pages    = _kb("HugePages_Total") > 0
        m.mmap_available = True   # mmap always available on Linux
    except Exception:
        pass
    return m


def _scan_disk() -> DiskProfile:
    d = DiskProfile()
    try:
        st = os.statvfs("/")
        d.root_total_gb = (st.f_blocks * st.f_frsize) / (1024**3)
        d.root_free_gb  = (st.f_bavail * st.f_frsize) / (1024**3)
        d.root_used_gb  = d.root_total_gb - d.root_free_gb

        # inode pressure
        if st.f_files > 0:
            d.inode_pct = (1 - st.f_ffree / st.f_files) * 100

        d.storage_pressure = d.root_free_gb < 0.5

        # zeus dir size
        try:
            result = subprocess.run(
                ["du", "-sh", ZEUS_DIR], capture_output=True, text=True, timeout=5)
            size_str = result.stdout.split()[0] if result.returncode == 0 else "0"
            # convert rough du output (e.g. 45M, 2.1G) to GB
            if size_str.endswith("G"):
                d.zeus_dir_gb = float(size_str[:-1])
            elif size_str.endswith("M"):
                d.zeus_dir_gb = float(size_str[:-1]) / 1024
        except Exception:
            pass

        # filesystem type from /proc/mounts
        try:
            mounts = Path("/proc/mounts").read_text()
            for line in mounts.splitlines():
                parts = line.split()
                if len(parts) >= 3 and parts[1] == "/":
                    d.root_fs_type = parts[2]
                    break
        except Exception:
            pass

        # I/O scheduler
        try:
            sched_path = "/sys/block/sda/queue/scheduler"
            if not os.path.exists(sched_path):
                sched_path = "/sys/block/mmcblk0/queue/scheduler"
            if os.path.exists(sched_path):
                raw = Path(sched_path).read_text()
                m = re.search(r"\[(\w+)\]", raw)
                d.io_scheduler = m.group(1) if m else raw.strip()
        except Exception:
            pass

        # Quick I/O throughput probe (1s)
        try:
            tmp_path = os.path.join(ZEUS_DIR, "_io_probe.tmp")
            data = b"Z" * (512 * 1024)   # 512 KB
            t0 = time.monotonic()
            with open(tmp_path, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            d.write_bps = len(data) / max(time.monotonic() - t0, 1e-6)
            t1 = time.monotonic()
            with open(tmp_path, "rb") as f:
                _ = f.read()
            d.read_bps = len(data) / max(time.monotonic() - t1, 1e-6)
            os.remove(tmp_path)
        except Exception:
            pass

    except Exception:
        pass
    return d


def _scan_kernel() -> KernelProfile:
    k = KernelProfile()
    try:
        u = os.uname()
        k.version = u.version
        k.release = u.release
        k.machine = u.machine

        # cgroups
        k.cgroups_v1 = os.path.isdir("/sys/fs/cgroup/memory")
        k.cgroups_v2 = os.path.isfile("/sys/fs/cgroup/cgroup.controllers")

        # namespaces — check unshare availability
        k.namespaces = shutil.which("unshare") is not None

        # seccomp — check /proc/self/status
        try:
            status = Path("/proc/self/status").read_text()
            k.seccomp = "Seccomp:" in status
        except Exception:
            pass

        # perf_events
        k.perf_events = os.path.isdir("/sys/kernel/debug/tracing")

        # loaded modules (first 30)
        try:
            mods = Path("/proc/modules").read_text()
            k.loaded_modules = [l.split()[0] for l in mods.splitlines()][:30]
        except Exception:
            pass

        # fd limits
        try:
            import resource
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            k.max_open_files = hard
        except Exception:
            pass

        # open fd count
        try:
            k.open_files = len(os.listdir(f"/proc/{os.getpid()}/fd"))
        except Exception:
            pass

        # gcc / as
        gcc = shutil.which("gcc") or shutil.which("arm-linux-gnueabihf-gcc")
        if gcc:
            k.gcc_available = True
            try:
                r = subprocess.run([gcc, "--version"], capture_output=True, text=True, timeout=5)
                k.gcc_version = r.stdout.splitlines()[0].strip() if r.returncode == 0 else ""
            except Exception:
                pass
        k.as_available = shutil.which("as") is not None

        # Key syscalls — check via strace -c echo if available or /proc/kallsyms
        k.available_syscalls = _probe_syscalls()

    except Exception:
        pass
    return k


def _probe_syscalls() -> List[str]:
    """Return list of confirmed-available syscalls by probing /proc/kallsyms."""
    targets = ["mmap2", "mprotect", "clone", "unshare", "pivot_root",
               "io_uring_enter", "io_uring_setup", "epoll_create1",
               "inotify_init1", "timerfd_create", "signalfd4"]
    found = []
    try:
        syms = Path("/proc/kallsyms").read_text(errors="ignore")
        for sc in targets:
            if f"sys_{sc}" in syms or f"__se_sys_{sc}" in syms:
                found.append(sc)
    except Exception:
        pass
    return found


def _scan_network() -> NetworkProfile:
    n = NetworkProfile()
    # interfaces from /proc/net/dev
    try:
        raw = Path("/proc/net/dev").read_text()
        for line in raw.splitlines()[2:]:
            parts = line.split(":")
            if len(parts) == 2:
                iface = parts[0].strip()
                if iface == "lo":
                    continue
                stats = parts[1].split()
                rx_bytes = int(stats[0])
                tx_bytes = int(stats[8])
                n.interfaces.append({
                    "name": iface,
                    "rx_bytes": rx_bytes,
                    "tx_bytes": tx_bytes,
                })
    except Exception:
        pass

    # internet connectivity check (fast, offline-safe)
    try:
        sock = socket.create_connection(("8.8.8.8", 53), timeout=3)
        sock.close()
        n.has_internet = True
        n.dns_resolves = True
    except Exception:
        pass

    # latency to 8.8.8.8
    if n.has_internet:
        try:
            t0 = time.monotonic()
            sock = socket.create_connection(("8.8.8.8", 53), timeout=5)
            sock.close()
            n.latency_ms = (time.monotonic() - t0) * 1000
        except Exception:
            pass

    # listening ports via /proc/net/tcp + tcp6
    try:
        for tcp_file in ["/proc/net/tcp", "/proc/net/tcp6"]:
            if not os.path.exists(tcp_file):
                continue
            raw = Path(tcp_file).read_text()
            for line in raw.splitlines()[1:]:
                parts = line.split()
                if len(parts) < 4:
                    continue
                state = parts[3]
                if state != "0A":   # 0A = LISTEN
                    continue
                local_addr = parts[1]
                port_hex   = local_addr.split(":")[1]
                port       = int(port_hex, 16)
                if port not in n.open_ports:
                    n.open_ports.append(port)
    except Exception:
        pass

    return n

# ──────────────────────────────────────────────────────────────────────────────
# CONSTRAINT PROFILE BUILDER
# ──────────────────────────────────────────────────────────────────────────────

def _build_constraints(cpu: CPUProfile, mem: MemoryProfile,
                       disk: DiskProfile, kernel: KernelProfile,
                       net: NetworkProfile) -> ConstraintProfile:
    c = ConstraintProfile()

    # ARM code generation rules
    c.must_use_arm_safe_code  = cpu.is_arm
    c.can_use_neon_intrinsics = cpu.supports_neon
    c.can_use_simd            = cpu.supports_neon
    c.prefer_mmap_io          = mem.mmap_available and disk.read_bps > 5_000_000

    # Memory pressure
    c.memory_pressure         = mem.pressure_pct > 75
    c.compress_data_structures= mem.pressure_pct > 85

    # Sandboxing
    c.can_use_cgroup_sandbox  = kernel.cgroups_v1 or kernel.cgroups_v2
    c.can_use_namespace_sandbox = kernel.namespaces

    # Networking
    c.network_available       = net.has_internet
    c.can_harvest_web         = net.has_internet and net.latency_ms < 2000
    c.cache_aggressively      = net.has_internet and net.latency_ms > 500

    # Storage
    c.storage_tight           = disk.storage_pressure

    # Compilation pipeline
    c.gcc_pipeline_available  = kernel.gcc_available and kernel.as_available
    c.fallback_to_c_suggestions = not c.gcc_pipeline_available

    # Assembly target tuning for armv7l
    if cpu.is_armv7l:
        c.asm_target_arch = "armv7-a"
        c.asm_float_abi   = "hard" if cpu.supports_vfp else "softfp"
        c.asm_fpu         = "neon-vfpv4" if cpu.supports_neon else (
                             "vfpv4" if cpu.supports_vfp else "vfpv3")
    elif cpu.architecture == "aarch64":
        c.asm_target_arch = "armv8-a"
        c.asm_float_abi   = "hard"
        c.asm_fpu         = "crypto-neon-fp-armv8"

    return c

# ──────────────────────────────────────────────────────────────────────────────
# ADAPTATION DECISION ENGINE
# ──────────────────────────────────────────────────────────────────────────────

def _make_adaptations(ctx_id: str,
                      c: ConstraintProfile,
                      cpu: CPUProfile,
                      mem: MemoryProfile,
                      disk: DiskProfile,
                      net: NetworkProfile) -> List[AdaptationDecision]:
    """Fire constraint-aware rules → list of active adaptation decisions."""
    now = datetime.now(timezone.utc).isoformat()
    decisions: List[AdaptationDecision] = []

    def _add(category, action, reason):
        decisions.append(AdaptationDecision(
            decision_id = f"{ctx_id[:8]}-{len(decisions):02d}",
            decided_at  = now,
            category    = category,
            action      = action,
            reason      = reason,
        ))

    # ── CODE GENERATION ────────────────────────────────────────────
    if c.must_use_arm_safe_code:
        _add("CODE_GEN",
             "enforce_arm_safe_patterns",
             f"Running on {cpu.architecture}. "
             "All code generation must avoid x86/x64 assumptions. "
             "No AVX, SSE, __int128. Use 32-bit-safe integer arithmetic.")

    if c.can_use_neon_intrinsics:
        _add("CODE_GEN",
             "enable_neon_vectorisation",
             "CPU supports NEON. Hot numeric loops can use ARM NEON "
             "intrinsics via C extension or inline assembly for 4× throughput.")

    if not c.must_use_arm_safe_code:
        _add("CODE_GEN",
             "standard_x86_patterns_allowed",
             f"Architecture is {cpu.architecture}. "
             "Standard Python/C code patterns apply.")

    # ── MEMORY ─────────────────────────────────────────────────────
    if c.memory_pressure:
        _add("MEMORY",
             "activate_memory_pressure_mode",
             f"Memory pressure at {mem.pressure_pct:.1f}%. "
             "Reduce in-memory caches. Prefer streaming reads. "
             "Avoid large list comprehensions. Use generators.")

    if c.compress_data_structures:
        _add("MEMORY",
             "compress_active_data_structures",
             f"Memory pressure critical at {mem.pressure_pct:.1f}%. "
             "Activate zlib compression on genome + knowledge JSON blobs. "
             "Evict cold cache entries immediately.")

    if c.prefer_mmap_io:
        _add("MEMORY",
             "prefer_mmap_over_buffered_io",
             f"mmap available, disk read at {disk.read_bps/1024/1024:.1f} MB/s. "
             "Use mmap for large file reads in zeus_learner, zeus_search, "
             "genome_manager. Reduces copies by 1 per read.")

    # ── SANDBOX ────────────────────────────────────────────────────
    if c.can_use_cgroup_sandbox:
        kind = "v2" if os.path.isfile("/sys/fs/cgroup/cgroup.controllers") else "v1"
        _add("SANDBOX",
             f"use_cgroup_{kind}_isolation_for_evolution",
             f"cgroups {kind} available. Route all evolutionary code execution "
             "through cgroup-isolated subprocesses. Caps memory/CPU to prevent "
             "runaway mutations from destabilising the host Zeus instance.")

    if c.can_use_namespace_sandbox:
        _add("SANDBOX",
             "use_namespace_isolation_for_dangerous_modules",
             "Linux namespaces (unshare) available. "
             "Kernel module probes and experimental daemons can be isolated "
             "in separate mount/PID/net namespaces before deployment.")

    # ── NETWORK ────────────────────────────────────────────────────
    if c.can_harvest_web:
        _add("NETWORK",
             "web_harvesting_available",
             f"Internet reachable, latency {net.latency_ms:.0f}ms. "
             "Autonomous knowledge harvesting may activate. "
             "Learning queues can trigger outbound scraping jobs.")

    if c.cache_aggressively:
        _add("NETWORK",
             "aggressive_cache_mode",
             f"Network latency at {net.latency_ms:.0f}ms. "
             "Cache all external API responses for ≥1 hour. "
             "Prefetch predicted next queries in LLM routing layer.")

    if not c.network_available:
        _add("NETWORK",
             "offline_mode_enforced",
             "No internet connectivity. All harvesting jobs suspended. "
             "Zeus operates on local genome + knowledge only. "
             "LLM router falls back to local Groq if available.")

    # ── STORAGE ────────────────────────────────────────────────────
    if c.storage_tight:
        _add("STORAGE",
             "storage_compression_and_pruning",
             f"Root disk only {disk.root_free_gb:.2f} GB free. "
             "Activate log rotation immediately. Prune evolved_modules/ "
             "keeping only top-10 by fitness score. Compress genome archives.")

    # ── ASSEMBLY PIPELINE ──────────────────────────────────────────
    if c.gcc_pipeline_available:
        _add("ASM",
             "arm_asm_rewrite_pipeline_active",
             f"gcc available ({cpu.architecture}). "
             "Hot Python paths can be compiled to .s ARM assembly, "
             "assembled to .so, and called via ctypes for bare-metal speed.")
    else:
        _add("ASM",
             "c_extension_pattern_suggester_active",
             "gcc not found. ARM assembly pipeline inactive. "
             "Hot path analyser will emit C-extension pattern suggestions "
             "instead. Install gcc to unlock full assembly pipeline.")

    # ── CPU LOAD ───────────────────────────────────────────────────
    if cpu.load_1m > cpu.cores * 0.8:
        _add("CODE_GEN",
             "throttle_background_jobs",
             f"CPU load {cpu.load_1m:.2f} against {cpu.cores} cores. "
             "Background evolution and mutation jobs should yield. "
             "Prioritise in-flight LLM requests.")

    return decisions

# ──────────────────────────────────────────────────────────────────────────────
# FULL SCAN ORCHESTRATOR
# ──────────────────────────────────────────────────────────────────────────────

def run_full_scan() -> OperationalContext:
    """Execute all layer scanners, build context, publish, persist."""
    t0 = time.monotonic()
    ctx = OperationalContext(
        context_id  = str(uuid.uuid4()),
        captured_at = datetime.now(timezone.utc).isoformat(),
    )

    log.info("[sysaware] beginning full system scan …")

    ctx.cpu     = _scan_cpu()
    log.debug("[sysaware] cpu done")

    ctx.memory  = _scan_memory()
    log.debug("[sysaware] memory done")

    ctx.disk    = _scan_disk()
    log.debug("[sysaware] disk done")

    ctx.kernel  = _scan_kernel()
    log.debug("[sysaware] kernel done")

    ctx.network = _scan_network()
    log.debug("[sysaware] network done")

    ctx.constraints = _build_constraints(
        ctx.cpu, ctx.memory, ctx.disk, ctx.kernel, ctx.network)

    ctx.adaptations = _make_adaptations(
        ctx.context_id, ctx.constraints,
        ctx.cpu, ctx.memory, ctx.disk, ctx.network)

    ctx.scan_duration_s = time.monotonic() - t0

    _publish_context(ctx)
    _persist_scan(ctx)

    log.info("[sysaware] scan complete — %d adaptations active — %.2fs",
             len(ctx.adaptations), ctx.scan_duration_s)
    return ctx


def _persist_scan(ctx: OperationalContext):
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute("""
            INSERT OR REPLACE INTO sys_aware_scans
            (scan_id, scanned_at, context_json, constraints_json, adaptations_json)
            VALUES (?,?,?,?,?)
        """, (
            ctx.context_id,
            ctx.captured_at,
            json.dumps(asdict(ctx.cpu) | asdict(ctx.memory) |
                       asdict(ctx.disk) | asdict(ctx.kernel) |
                       asdict(ctx.network)),
            json.dumps(asdict(ctx.constraints)),
            json.dumps([asdict(a) for a in ctx.adaptations]),
        ))
        # keep last 48 scans
        con.execute("""
            DELETE FROM sys_aware_scans
            WHERE id NOT IN (
                SELECT id FROM sys_aware_scans ORDER BY id DESC LIMIT 48)
        """)
        con.commit()
        con.close()
    except Exception as e:
        log.warning("[sysaware] persist failed: %s", e)

# ──────────────────────────────────────────────────────────────────────────────
# HOT PATH ANALYSER — detects Python functions suitable for ASM rewrite
# ──────────────────────────────────────────────────────────────────────────────

def _cyclomatic_complexity(node: ast.FunctionDef) -> int:
    """Approximate cyclomatic complexity of an AST function node."""
    count = 1
    for child in ast.walk(node):
        if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler,
                               ast.With, ast.Assert, ast.comprehension)):
            count += 1
        elif isinstance(child, ast.BoolOp):
            count += len(child.values) - 1
    return count


def analyse_hotpaths(file_path: str) -> List[Dict]:
    """
    Parse a Python file, find functions that are hot-path candidates
    for ARM assembly rewrite based on:
      - High cyclomatic complexity (≥ 10)
      - Numeric-heavy signatures (float/int annotations or names)
      - Tight loops with arithmetic operations
    Returns a list of candidate dicts.
    """
    candidates = []
    try:
        src = Path(file_path).read_text(errors="ignore")
        tree = ast.parse(src, filename=file_path)
    except Exception:
        return candidates

    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue

        complexity = _cyclomatic_complexity(node)

        # Count arithmetic ops in the function body
        arith_ops = sum(
            1 for n in ast.walk(node)
            if isinstance(n, (ast.Add, ast.Sub, ast.Mult, ast.Div,
                               ast.Mod, ast.Pow, ast.FloorDiv,
                               ast.BitAnd, ast.BitOr, ast.BitXor,
                               ast.LShift, ast.RShift))
        )

        # Count loop depth
        loop_nodes = sum(
            1 for n in ast.walk(node)
            if isinstance(n, (ast.For, ast.While))
        )

        # Heuristic score
        score = complexity + arith_ops * 0.5 + loop_nodes * 2

        if score < 8:
            continue

        # Classify reason
        reasons = []
        if complexity >= 10:
            reasons.append(f"cyclomatic_complexity={complexity}")
        if arith_ops >= 10:
            reasons.append(f"arithmetic_ops={arith_ops}")
        if loop_nodes >= 2:
            reasons.append(f"nested_loops={loop_nodes}")

        if not reasons:
            continue

        ctx = get_context()
        if ctx and ctx.constraints.gcc_pipeline_available:
            suggestion = (
                f"Compile {node.name} to ARM assembly via "
                f"gcc -march={ctx.constraints.asm_target_arch} "
                f"-mfpu={ctx.constraints.asm_fpu} "
                f"-mfloat-abi={ctx.constraints.asm_float_abi} -O3"
            )
        else:
            suggestion = (
                f"Rewrite {node.name} as a C extension module (.pyx or .c) "
                "and build with python3 setup.py build_ext --inplace. "
                "Install gcc to unlock direct ARM assembly pipeline."
            )

        candidates.append({
            "file_path":  file_path,
            "fn_name":    node.name,
            "line":       node.lineno,
            "complexity": complexity,
            "arith_ops":  arith_ops,
            "loop_nodes": loop_nodes,
            "score":      round(score, 1),
            "reason":     ", ".join(reasons),
            "suggestion": suggestion,
        })

    # Sort by score descending
    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates


def scan_zeus_hotpaths() -> List[Dict]:
    """Scan all Zeus .py files for hot-path candidates."""
    all_candidates = []
    for py_file in Path(ZEUS_DIR).glob("*.py"):
        if py_file.name == "zeus_sys_aware.py":
            continue
        candidates = analyse_hotpaths(str(py_file))
        all_candidates.extend(candidates)

    # Persist to DB
    if all_candidates:
        try:
            con = sqlite3.connect(DB_PATH)
            now = datetime.now(timezone.utc).isoformat()
            con.executemany("""
                INSERT INTO sys_aware_hotpaths
                (detected_at, file_path, fn_name, reason, complexity, suggestion, status)
                VALUES (?,?,?,?,?,?,'pending')
            """, [
                (now, c["file_path"], c["fn_name"],
                 c["reason"], c["complexity"], c["suggestion"])
                for c in all_candidates
            ])
            con.commit()
            con.close()
        except Exception as e:
            log.warning("[sysaware] hotpath persist failed: %s", e)

    return all_candidates

# ──────────────────────────────────────────────────────────────────────────────
# ARM ASSEMBLY CODE GENERATOR
# ──────────────────────────────────────────────────────────────────────────────

# Template generators for common hot-path patterns on armv7l.
# Each returns (asm_source: str, c_wrapper: str) for the given function.

def _asm_template_integer_sum_loop(fn_name: str, ctx: OperationalContext) -> Tuple[str,str]:
    """
    Template: tight integer accumulation loop.
    Generates a callable void fn(int32_t* arr, int32_t n, int64_t* out).
    """
    arch   = ctx.constraints.asm_target_arch
    fpu    = ctx.constraints.asm_fpu
    float_abi = ctx.constraints.asm_float_abi

    asm_src = textwrap.dedent(f"""\
        @ ARM assembly generated by zeus_sys_aware.py
        @ Target: {arch}  FPU: {fpu}  ABI: {float_abi}
        @ Function: {fn_name}_asm — integer accumulation kernel
        @
        .arch {arch}
        .fpu  {fpu}
        .syntax unified
        .thumb
        .global {fn_name}_asm
        .type   {fn_name}_asm, %function

        @ void {fn_name}_asm(int32_t* arr, int32_t n, int64_t* out)
        @ r0 = arr ptr, r1 = n (count), r2 = output ptr
        {fn_name}_asm:
            push    {{r4, r5, r6, r7, lr}}
            mov     r4, r0          @ arr ptr
            mov     r5, r1          @ count
            mov     r6, #0          @ accumulator lo
            mov     r7, #0          @ accumulator hi (64-bit)
            cmp     r5, #0
            ble     .done_{fn_name}

        .loop_{fn_name}:
            ldr     r3, [r4], #4    @ load *arr++
            adds    r6, r6, r3      @ acc_lo += *arr (sets carry)
            adc     r7, r7, #0      @ acc_hi += carry
            subs    r5, r5, #1
            bgt     .loop_{fn_name}

        .done_{fn_name}:
            str     r6, [r2]        @ store lo word
            str     r7, [r2, #4]    @ store hi word
            pop     {{r4, r5, r6, r7, pc}}
        .size {fn_name}_asm, . - {fn_name}_asm
    """)

    c_wrapper = textwrap.dedent(f"""\
        /* C wrapper generated by zeus_sys_aware.py */
        #include <stdint.h>
        #include <python3.9/Python.h>

        extern void {fn_name}_asm(int32_t* arr, int32_t n, int64_t* out);

        static PyObject* py_{fn_name}(PyObject* self, PyObject* args) {{
            PyObject* list_obj;
            if (!PyArg_ParseTuple(args, "O", &list_obj)) return NULL;
            Py_ssize_t n = PyList_Size(list_obj);
            int32_t* arr = (int32_t*)malloc(n * sizeof(int32_t));
            if (!arr) return PyErr_NoMemory();
            for (Py_ssize_t i = 0; i < n; i++)
                arr[i] = (int32_t)PyLong_AsLong(PyList_GET_ITEM(list_obj, i));
            int64_t result = 0;
            {fn_name}_asm(arr, (int32_t)n, &result);
            free(arr);
            return PyLong_FromLongLong(result);
        }}

        static PyMethodDef methods[] = {{
            {{"{fn_name}", py_{fn_name}, METH_VARARGS, "ARM-optimised {fn_name}"}},
            {{NULL, NULL, 0, NULL}}
        }};
        static struct PyModuleDef moduledef = {{
            PyModuleDef_HEAD_INIT, "{fn_name}_arm", NULL, -1, methods
        }};
        PyMODINIT_FUNC PyInit_{fn_name}_arm(void) {{
            return PyModule_Create(&moduledef);
        }}
    """)
    return asm_src, c_wrapper


def _asm_template_neon_float_dot(fn_name: str, ctx: OperationalContext) -> Tuple[str,str]:
    """
    Template: NEON-vectorised float dot product.
    Requires NEON support (verified before use).
    """
    asm_src = textwrap.dedent(f"""\
        @ ARM NEON assembly generated by zeus_sys_aware.py
        @ Target: {ctx.constraints.asm_target_arch}  FPU: neon
        @ Function: {fn_name}_neon — vectorised float dot product
        @
        .arch {ctx.constraints.asm_target_arch}
        .fpu  neon
        .syntax unified
        .thumb
        .global {fn_name}_neon
        .type   {fn_name}_neon, %function

        @ float {fn_name}_neon(float* a, float* b, int n)
        @ r0=a, r1=b, r2=n, result in s0
        {fn_name}_neon:
            push    {{r4, lr}}
            veor    q0, q0, q0      @ accumulator = 0 (4 lanes)
            mov     r4, r2
            asrs    r4, r4, #2      @ r4 = n / 4  (4 floats per iteration)
            ble     .scalar_{fn_name}

        .vec_loop_{fn_name}:
            vld1.32 {{q1}}, [r0]!   @ load 4 floats from a
            vld1.32 {{q2}}, [r1]!   @ load 4 floats from b
            vmla.f32 q0, q1, q2     @ q0 += q1 * q2 (elementwise)
            subs    r4, r4, #1
            bgt     .vec_loop_{fn_name}

        @ Horizontal add q0 → s0
            vadd.f32 d0, d0, d1
            vpadd.f32 d0, d0, d0

        .scalar_{fn_name}:
            @ handle remaining elements (n % 4) with scalar fallback
            ands    r2, r2, #3
            ble     .done_{fn_name}
        .sc_loop_{fn_name}:
            vld1.32 {{s2}}, [r0]!
            vld1.32 {{s3}}, [r1]!
            vmla.f32 s0, s2, s3
            subs    r2, r2, #1
            bgt     .sc_loop_{fn_name}

        .done_{fn_name}:
            pop     {{r4, pc}}
        .size {fn_name}_neon, . - {fn_name}_neon
    """)

    c_wrapper = textwrap.dedent(f"""\
        /* NEON dot product C wrapper — zeus_sys_aware.py */
        #include <stdint.h>
        #include <stdlib.h>
        #include <python3.9/Python.h>

        extern float {fn_name}_neon(float* a, float* b, int n);

        static PyObject* py_{fn_name}(PyObject* self, PyObject* args) {{
            PyObject *la, *lb;
            if (!PyArg_ParseTuple(args, "OO", &la, &lb)) return NULL;
            Py_ssize_t n = PyList_Size(la);
            float* a = (float*)malloc(n * sizeof(float));
            float* b = (float*)malloc(n * sizeof(float));
            if (!a || !b) {{ free(a); free(b); return PyErr_NoMemory(); }}
            for (Py_ssize_t i = 0; i < n; i++) {{
                a[i] = (float)PyFloat_AsDouble(PyList_GET_ITEM(la, i));
                b[i] = (float)PyFloat_AsDouble(PyList_GET_ITEM(lb, i));
            }}
            float result = {fn_name}_neon(a, b, (int)n);
            free(a); free(b);
            return PyFloat_FromDouble((double)result);
        }}

        static PyMethodDef methods[] = {{
            {{"{fn_name}", py_{fn_name}, METH_VARARGS, "NEON dot product"}},
            {{NULL, NULL, 0, NULL}}
        }};
        static struct PyModuleDef moduledef = {{
            PyModuleDef_HEAD_INIT, "{fn_name}_neon_ext", NULL, -1, methods
        }};
        PyMODINIT_FUNC PyInit_{fn_name}_neon_ext(void) {{
            return PyModule_Create(&moduledef);
        }}
    """)
    return asm_src, c_wrapper


def compile_hotpath_to_asm(source_file: str, fn_name: str,
                            template: str = "auto") -> Dict:
    """
    Main entry point for ARM assembly compilation pipeline.

    1. Select template (auto-detect from fn_name or use explicit template)
    2. Generate .s assembly + .c wrapper
    3. Assemble .s → .o via as
    4. Compile .c → .o via gcc
    5. Link both → .so shared library
    6. Validate the .so is loadable via ctypes
    7. Persist build record to DB
    8. Return build result dict

    Falls back to pattern suggestion if gcc/as unavailable.
    """
    build_id  = str(uuid.uuid4())
    built_at  = datetime.now(timezone.utc).isoformat()
    result    = {
        "build_id":    build_id,
        "built_at":    built_at,
        "fn_name":     fn_name,
        "source_file": source_file,
        "success":     False,
        "asm_path":    "",
        "so_path":     "",
        "error":       "",
        "notes":       "",
    }

    ctx = get_context()
    if ctx is None:
        result["error"] = "No operational context available — run a scan first"
        return result

    # ── Fallback: gcc not available ────────────────────────────────
    if not ctx.constraints.gcc_pipeline_available:
        candidates = analyse_hotpaths(source_file)
        match = next((c for c in candidates if c["fn_name"] == fn_name), None)
        result["notes"] = match["suggestion"] if match else (
            f"gcc/as not found. Rewrite {fn_name} as a C extension or install gcc.")
        result["success"] = False
        result["error"]   = "gcc_not_available"
        _persist_build(result)
        return result

    # ── Choose template ─────────────────────────────────────────────
    if template == "auto":
        name_lower = fn_name.lower()
        if "dot" in name_lower or "inner" in name_lower or "cosine" in name_lower:
            if ctx.constraints.can_use_neon_intrinsics:
                template = "neon_dot"
            else:
                template = "int_sum"
        else:
            template = "int_sum"

    # ── Generate sources ────────────────────────────────────────────
    try:
        if template == "neon_dot" and ctx.constraints.can_use_neon_intrinsics:
            asm_src, c_src = _asm_template_neon_float_dot(fn_name, ctx)
        else:
            asm_src, c_src = _asm_template_integer_sum_loop(fn_name, ctx)
    except Exception as e:
        result["error"] = f"Template generation failed: {e}"
        _persist_build(result)
        return result

    # ── Write source files ──────────────────────────────────────────
    safe_name   = re.sub(r"[^\w]", "_", fn_name)
    build_dir   = os.path.join(ASM_DIR, safe_name)
    os.makedirs(build_dir, exist_ok=True)

    asm_path    = os.path.join(build_dir, f"{safe_name}.s")
    c_path      = os.path.join(build_dir, f"{safe_name}_wrap.c")
    asm_obj     = os.path.join(build_dir, f"{safe_name}_asm.o")
    c_obj       = os.path.join(build_dir, f"{safe_name}_wrap.o")
    so_path     = os.path.join(build_dir, f"{safe_name}_arm.so")

    Path(asm_path).write_text(asm_src)
    Path(c_path).write_text(c_src)

    result["asm_path"] = asm_path
    result["so_path"]  = so_path

    # Detect available gcc
    gcc = shutil.which("gcc") or shutil.which("arm-linux-gnueabihf-gcc") or "gcc"
    arch  = ctx.constraints.asm_target_arch
    fpu   = ctx.constraints.asm_fpu
    fabi  = ctx.constraints.asm_float_abi

    def _run(cmd: List[str], step: str) -> Optional[str]:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if r.returncode != 0:
                return f"{step} failed (rc={r.returncode}): {r.stderr[:400]}"
            return None
        except Exception as e:
            return f"{step} exception: {e}"

    # ── Assemble .s ─────────────────────────────────────────────────
    err = _run([
        "as", f"--march={arch}", "-mfpu={fpu}".replace("=", f"={fpu}"),
        "-o", asm_obj, asm_path
    ], "assemble")
    # Try simpler invocation if first fails (armv7l `as` is fussy)
    if err:
        err = _run(["as", "-o", asm_obj, asm_path], "assemble_simple")
    if err:
        result["error"] = err
        _persist_build(result)
        return result

    # ── Compile .c wrapper ──────────────────────────────────────────
    err = _run([
        gcc, "-O3", f"-march={arch}", f"-mfpu={fpu}", f"-mfloat-abi={fabi}",
        "-shared", "-fPIC", "-c", c_path, "-o", c_obj
    ], "compile_wrapper")
    if err:
        result["error"] = err
        _persist_build(result)
        return result

    # ── Link .so ────────────────────────────────────────────────────
    err = _run([
        gcc, "-shared", "-o", so_path, asm_obj, c_obj
    ], "link")
    if err:
        result["error"] = err
        _persist_build(result)
        return result

    # ── Validate .so via ctypes ─────────────────────────────────────
    try:
        lib = ctypes.CDLL(so_path)
        assert hasattr(lib, f"{fn_name}_asm") or hasattr(lib, f"{fn_name}_neon")
        result["notes"] = f"Loaded successfully. Symbol confirmed in {so_path}."
    except Exception as e:
        result["error"] = f"ctypes load validation failed: {e}"
        _persist_build(result)
        return result

    result["success"] = True
    log.info("[sysaware] compiled %s → %s", fn_name, so_path)
    _persist_build(result)
    return result


def _persist_build(b: Dict):
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute("""
            INSERT OR REPLACE INTO sys_aware_asm_builds
            (build_id, built_at, source_path, asm_path, so_path,
             fn_name, success, error, notes)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (b["build_id"], b["built_at"], b.get("source_file",""),
              b.get("asm_path",""), b.get("so_path",""),
              b["fn_name"], 1 if b["success"] else 0,
              b.get("error",""), b.get("notes","")))
        con.commit()
        con.close()
    except Exception as e:
        log.warning("[sysaware] build persist: %s", e)

# ──────────────────────────────────────────────────────────────────────────────
# BACKGROUND DAEMON — polls every 10 minutes
# ──────────────────────────────────────────────────────────────────────────────

_POLL_INTERVAL_S = 600   # 10 minutes
_daemon_thread: Optional[threading.Thread] = None
_daemon_running = threading.Event()
_daemon_started = False

def _daemon_loop():
    log.info("[sysaware] daemon started — polling every %ds", _POLL_INTERVAL_S)
    # initial scan immediately on start
    try:
        run_full_scan()
    except Exception as e:
        log.error("[sysaware] initial scan error: %s", e)

    while _daemon_running.is_set():
        # Sleep in 10s chunks so we can exit cleanly
        for _ in range(_POLL_INTERVAL_S // 10):
            if not _daemon_running.is_set():
                break
            time.sleep(10)

        if not _daemon_running.is_set():
            break

        try:
            run_full_scan()
        except Exception as e:
            log.error("[sysaware] scan error: %s", e)

    log.info("[sysaware] daemon stopped")


def start_daemon():
    global _daemon_thread, _daemon_started
    if _daemon_started:
        return
    _daemon_running.set()
    _daemon_thread = threading.Thread(
        target=_daemon_loop, name="zeus-sysaware-daemon", daemon=True)
    _daemon_thread.start()
    _daemon_started = True
    log.info("[sysaware] daemon thread launched")


def stop_daemon():
    _daemon_running.clear()
    if _daemon_thread:
        _daemon_thread.join(timeout=15)

# ──────────────────────────────────────────────────────────────────────────────
# SCHEDULER JOB HOOK (called by zeus_nightly_scheduler)
# ──────────────────────────────────────────────────────────────────────────────

def _job_sys_aware_deep_scan() -> Dict:
    """
    Full deep scan + hot-path analysis.
    Registered as: ScheduledJob("sys_aware_deep_scan", ..., "_job_sys_aware_deep_scan")
    """
    ctx = run_full_scan()
    hotpaths = scan_zeus_hotpaths()
    return {
        "scan_id":       ctx.context_id,
        "captured_at":   ctx.captured_at,
        "adaptations":   len(ctx.adaptations),
        "hotpaths_found": len(hotpaths),
        "top_hotpaths":  hotpaths[:5],
        "constraints_summary": {
            "arm_safe_mode":    ctx.constraints.must_use_arm_safe_code,
            "memory_pressure":  ctx.constraints.memory_pressure,
            "network_online":   ctx.constraints.network_available,
            "gcc_available":    ctx.constraints.gcc_pipeline_available,
            "cgroup_sandbox":   ctx.constraints.can_use_cgroup_sandbox,
        }
    }

# ──────────────────────────────────────────────────────────────────────────────
# FLASK API ROUTES
# ──────────────────────────────────────────────────────────────────────────────

def _ctx_or_404():
    ctx = get_context()
    if ctx is None:
        return None, (jsonify({"error": "No scan available yet. "
                               "POST /api/sysaware/force_scan to trigger."}), 503)
    return ctx, None


@sys_aware_bp.route("/api/sysaware/health")
def route_health():
    return jsonify({
        "status":          "online",
        "daemon_running":  _daemon_running.is_set(),
        "daemon_started":  _daemon_started,
        "poll_interval_s": _POLL_INTERVAL_S,
        "scans_in_history": len(_ctx_history),
        "last_scan_at":    (_live_ctx.captured_at if _live_ctx else None),
    })


@sys_aware_bp.route("/api/sysaware/context")
def route_context():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify(ctx.to_dict())


@sys_aware_bp.route("/api/sysaware/cpu")
def route_cpu():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify(asdict(ctx.cpu))


@sys_aware_bp.route("/api/sysaware/memory")
def route_memory():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify(asdict(ctx.memory))


@sys_aware_bp.route("/api/sysaware/disk")
def route_disk():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify(asdict(ctx.disk))


@sys_aware_bp.route("/api/sysaware/kernel")
def route_kernel():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify(asdict(ctx.kernel))


@sys_aware_bp.route("/api/sysaware/network")
def route_network():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify(asdict(ctx.network))


@sys_aware_bp.route("/api/sysaware/constraints")
def route_constraints():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify(asdict(ctx.constraints))


@sys_aware_bp.route("/api/sysaware/adaptations")
def route_adaptations():
    ctx, err = _ctx_or_404()
    if err:
        return err
    return jsonify({
        "count":       len(ctx.adaptations),
        "captured_at": ctx.captured_at,
        "adaptations": [asdict(a) for a in ctx.adaptations],
    })


@sys_aware_bp.route("/api/sysaware/hotpaths")
def route_hotpaths():
    try:
        con = sqlite3.connect(DB_PATH)
        rows = con.execute("""
            SELECT detected_at, file_path, fn_name, reason,
                   complexity, suggestion, status
            FROM sys_aware_hotpaths
            ORDER BY complexity DESC LIMIT 50
        """).fetchall()
        con.close()
        return jsonify({
            "count": len(rows),
            "hotpaths": [
                {"detected_at": r[0], "file_path": r[1], "fn_name": r[2],
                 "reason": r[3], "complexity": r[4],
                 "suggestion": r[5], "status": r[6]}
                for r in rows
            ]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@sys_aware_bp.route("/api/sysaware/compile_hotpath", methods=["POST"])
def route_compile_hotpath():
    data = request.get_json(silent=True) or {}
    source_file = data.get("source_file", "")
    fn_name     = data.get("fn_name", "")
    template    = data.get("template", "auto")

    if not source_file or not fn_name:
        return jsonify({"error": "source_file and fn_name required"}), 400

    if not os.path.isabs(source_file):
        source_file = os.path.join(ZEUS_DIR, source_file)

    if not os.path.isfile(source_file):
        return jsonify({"error": f"File not found: {source_file}"}), 404

    result = compile_hotpath_to_asm(source_file, fn_name, template)
    code = 200 if result["success"] else 422
    return jsonify(result), code


@sys_aware_bp.route("/api/sysaware/asm_builds")
def route_asm_builds():
    try:
        con = sqlite3.connect(DB_PATH)
        rows = con.execute("""
            SELECT build_id, built_at, source_path, asm_path, so_path,
                   fn_name, success, error, notes
            FROM sys_aware_asm_builds ORDER BY id DESC LIMIT 50
        """).fetchall()
        con.close()
        return jsonify({
            "count": len(rows),
            "builds": [
                {"build_id": r[0], "built_at": r[1], "source_path": r[2],
                 "asm_path": r[3], "so_path": r[4], "fn_name": r[5],
                 "success": bool(r[6]), "error": r[7], "notes": r[8]}
                for r in rows
            ]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@sys_aware_bp.route("/api/sysaware/force_scan", methods=["POST"])
def route_force_scan():
    try:
        ctx = run_full_scan()
        return jsonify({
            "scan_id":        ctx.context_id,
            "captured_at":    ctx.captured_at,
            "duration_s":     ctx.scan_duration_s,
            "adaptations":    len(ctx.adaptations),
            "architecture":   ctx.cpu.architecture,
            "memory_free_mb": ctx.memory.available_mb,
            "network_online": ctx.network.has_internet,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@sys_aware_bp.route("/api/sysaware/history")
def route_history():
    snapshots = []
    with _ctx_lock:
        for c in list(_ctx_history):
            snapshots.append({
                "scan_id":        c.context_id,
                "captured_at":    c.captured_at,
                "duration_s":     c.scan_duration_s,
                "adaptations":    len(c.adaptations),
                "memory_pct":     c.memory.pressure_pct,
                "load_1m":        c.cpu.load_1m,
                "network_online": c.network.has_internet,
            })
    return jsonify({"count": len(snapshots), "history": snapshots[::-1]})  # newest first


# ──────────────────────────────────────────────────────────────────────────────
# AUTO-START DAEMON ON BLUEPRINT REGISTRATION
# ──────────────────────────────────────────────────────────────────────────────

# Starts 2 seconds after Flask app registers this blueprint, so Flask is
# fully initialised before the first scan touches the filesystem.
def _delayed_start():
    time.sleep(2)
    start_daemon()
    # Register with zeus_identity capability registry
    try:
        from zeus_identity import register_self
        register_self(
            module_name   = "zeus_sys_aware",
            blueprint_var = "sys_aware_bp",
            url_prefix    = "/api/sysaware",
            version       = "1.0",
            description   = (
                "Continuous 10-min hardware/OS daemon. Publishes live OperationalContext "
                "to all Zeus layers. ARM assembly hot-path compiler. "
                "Constraint-aware adaptation engine."
            ),
            boot_order    = 8,
            depends_on    = [],
            capabilities  = [
                {"id": "sysaware_context",      "endpoint": "/api/sysaware/context",
                 "description": "Full live OperationalContext snapshot",
                 "tags": ["sysaware", "hardware", "context"]},
                {"id": "sysaware_constraints",  "endpoint": "/api/sysaware/constraints",
                 "description": "Derived constraint profile (ARM-safe, cgroup, network flags)",
                 "tags": ["sysaware", "constraints", "arm"]},
                {"id": "sysaware_adaptations",  "endpoint": "/api/sysaware/adaptations",
                 "description": "Active adaptation decisions fired this cycle",
                 "tags": ["sysaware", "adaptation", "decisions"]},
                {"id": "sysaware_hotpaths",     "endpoint": "/api/sysaware/hotpaths",
                 "description": "Hot Python paths flagged for ARM assembly rewrite",
                 "tags": ["sysaware", "asm", "hotpath", "optimisation"]},
                {"id": "sysaware_compile",      "endpoint": "/api/sysaware/compile_hotpath",
                 "description": "Compile a hot path to ARM .s assembly + .so via gcc",
                 "method": "POST",
                 "tags": ["sysaware", "asm", "compiler", "arm"]},
                {"id": "sysaware_force_scan",   "endpoint": "/api/sysaware/force_scan",
                 "description": "Trigger an immediate full system scan",
                 "method": "POST",
                 "tags": ["sysaware", "scan"]},
                {"id": "sysaware_cpu",          "endpoint": "/api/sysaware/cpu",
                 "description": "CPU profile: architecture, ARM flags, load, frequency",
                 "tags": ["sysaware", "cpu", "hardware"]},
                {"id": "sysaware_memory",       "endpoint": "/api/sysaware/memory",
                 "description": "Memory profile: pressure, swap, mmap availability",
                 "tags": ["sysaware", "memory", "hardware"]},
                {"id": "sysaware_network",      "endpoint": "/api/sysaware/network",
                 "description": "Network profile: internet, latency, open ports",
                 "tags": ["sysaware", "network"]},
                {"id": "sysaware_kernel",       "endpoint": "/api/sysaware/kernel",
                 "description": "Kernel profile: cgroups, namespaces, gcc, syscalls",
                 "tags": ["sysaware", "kernel", "capabilities"]},
                {"id": "sysaware_asm_builds",   "endpoint": "/api/sysaware/asm_builds",
                 "description": "All compiled ARM assembly .so artefacts",
                 "tags": ["sysaware", "asm", "builds"]},
                {"id": "sysaware_history",      "endpoint": "/api/sysaware/history",
                 "description": "Scan history — last 48 cycles (8 hours)",
                 "tags": ["sysaware", "history"]},
            ],
        )
        log.info("[sysaware] registered with zeus_identity capability registry")
    except Exception as e:
        log.warning("[sysaware] identity registration skipped: %s", e)

threading.Thread(target=_delayed_start, name="zeus-sysaware-init", daemon=True).start()
log.info("[sysaware] zeus_sys_aware.py loaded — daemon starting in 2s")
