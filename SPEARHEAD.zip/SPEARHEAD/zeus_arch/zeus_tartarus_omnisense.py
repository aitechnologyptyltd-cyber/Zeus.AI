"""
zeus_tartarus_omnisense.py
The Zeus Project 2026 — Francois Nel

TARTARUS PHASE 5 — OMNISENSE
Cross-phase synthesis and emergent law discovery engine.

OMNISENSE is the final and highest-order Tartarus phase. It reads the
ENTIRE accumulated TartarusMemory pool — every equation, pattern,
prediction, connection, insight, codex entry and weight — and synthesises
them into:

  - A unified field theory spanning all analysed domains
  - Cross-phase patterns (recurring structures found in P1+P2+P3+P4)
  - Emergent mathematical laws (laws that only appear in the aggregate)
  - Actionable intelligence (concrete decisions supported by the math)
  - A single OMNISENSE insight (the deepest truth the abyss can see)

Modes:
  FULL_SYNTHESIS — synthesise everything in the pool
  FREEFORM       — submit any question; answered with full pool context
  DELTA          — synthesise only what changed since last omnisense run
  ADVERSARIAL    — find internal contradictions in the pool

Results are:
  - Pushed into TartarusMemory.pool.omnisense
  - Fed into zeus_self_evolution as a synthesis event
  - Fed into zeus_genome_manager as a new genome candidate
  - Fed into zeus_hive_bridge as a collective intelligence upgrade

Flask blueprint: omnisense_bp at /api/tartarus/omnisense/*

armv7l compatible: no f-strings, no walrus operator.
"""

from __future__ import print_function

import os
import sys
import json
import time
import logging
import threading
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.tartarus.omnisense")

omnisense_bp = Blueprint("tartarus_omnisense", __name__)

OMNISENSE_SCHEMA = json.dumps({
    "title": "string",
    "unifiedTheory": "string",
    "crossPhasePatterns": [
        {
            "pattern": "string",
            "phases": ["p1", "p2"],
            "equation": "string",
            "significance": "string",
            "universality": "local|regional|global|universal",
        }
    ],
    "emergentLaws": [
        {
            "law": "string",
            "formula": "string",
            "universality": "string",
            "derivedFrom": ["string"],
        }
    ],
    "actionableIntelligence": ["string"],
    "internalContradictions": [
        {
            "contradiction": "string",
            "resolution": "string",
        }
    ],
    "omnisenseInsight": "string",
    "poolSaturation": 0.85,
    "readinessScore": 0.9,
})

DELTA_SCHEMA = json.dumps({
    "deltaInsights": [
        {
            "newFinding": "string",
            "changesExistingConclusion": "boolean",
            "updatedConclusion": "string",
        }
    ],
    "newEmergentLaws": [
        {"law": "string", "formula": "string"}
    ],
    "poolEvolutionSummary": "string",
    "omnisenseInsight": "string",
})

ADVERSARIAL_SCHEMA = json.dumps({
    "contradictionMap": [
        {
            "claimA": "string",
            "claimB": "string",
            "nature": "string",
            "resolution": "string",
            "confidence": 0.7,
        }
    ],
    "weakestLinks": ["string"],
    "strongestClaims": ["string"],
    "poolIntegrity": 0.8,
    "recommendedReinvestigations": ["string"],
    "omnisenseInsight": "string",
})


def _build_full_pool_summary(mem, max_each=8):
    """Build a rich summary of the entire pool for the omnisense prompt."""
    pool = mem.get_snapshot()
    parts = []

    if pool["inputs"]:
        parts.append(
            "PHENOMENA ANALYSED (" + str(len(pool["inputs"])) + "): " +
            "; ".join(str(x) for x in pool["inputs"][-max_each:])
        )

    if pool["equations"]:
        eq_names = []
        for x in pool["equations"][-max_each:]:
            if isinstance(x, dict):
                eq_names.append(x.get("name", "") + ": " + x.get("formula", "")[:40])
            else:
                eq_names.append(str(x)[:60])
        parts.append(
            "KEY EQUATIONS (" + str(len(pool["equations"])) + "): " +
            " | ".join(eq_names)
        )

    if pool["patterns"]:
        pat_names = []
        for x in pool["patterns"][-max_each:]:
            if isinstance(x, dict):
                pat_names.append(x.get("pattern", str(x))[:50])
            else:
                pat_names.append(str(x)[:50])
        parts.append(
            "PATTERNS (" + str(len(pool["patterns"])) + "): " +
            "; ".join(pat_names)
        )

    if pool["connections"]:
        conn_names = []
        for x in pool["connections"][-6:]:
            if isinstance(x, dict):
                conn_names.append(
                    x.get("phenomenon",
                           x.get("link",
                                  x.get("principle", str(x))))[:50]
                )
            else:
                conn_names.append(str(x)[:50])
        parts.append(
            "CONNECTIONS (" + str(len(pool["connections"])) + "): " +
            "; ".join(conn_names)
        )

    if pool["predictions"]:
        pred_str = []
        for x in pool["predictions"][-6:]:
            if isinstance(x, dict):
                pred_str.append(
                    x.get("outcome", str(x))[:50] +
                    " (conf=" + str(x.get("probability",
                                         x.get("confidence", "?"))) + ")"
                )
        parts.append(
            "PREDICTIONS (" + str(len(pool["predictions"])) + "): " +
            "; ".join(pred_str)
        )

    if pool["streams"]:
        parts.append(
            "STREAM ANALYSES: " + str(len(pool["streams"])) + " completed"
        )

    if pool["uploads"]:
        upload_names = [
            x.get("name", "?") if isinstance(x, dict) else str(x)
            for x in pool["uploads"][-5:]
        ]
        parts.append("UPLOADED FILES: " + ", ".join(upload_names))

    if pool["codex"]:
        parts.append("CODEX ENTRIES: " + str(len(pool["codex"])))

    if pool["weights"]:
        # Average tartarusScore
        scores = []
        for w in pool["weights"]:
            if isinstance(w, dict) and "tartarusScore" in w:
                scores.append(float(w["tartarusScore"]))
        if scores:
            avg = sum(scores) / len(scores)
            parts.append(
                "WEIGHT ANALYSES: " + str(len(pool["weights"])) +
                " (avg TartarusScore=" + str(round(avg, 3)) + ")"
            )

    if pool["learning_steps"]:
        parts.append(
            "LEARNING CYCLES: " + str(len(pool["learning_steps"])) + " completed"
        )

    return "\n".join(parts)


def _wire_omnisense_to_zeus(result):
    """Push omnisense synthesis into top-level Zeus systems."""
    # 1. Self-evolution: treat as a synthesis event
    try:
        from zeus_self_evolution import get_evolution_engine
        evo = get_evolution_engine()
        if hasattr(evo, "ingest_synthesis_event"):
            evo.ingest_synthesis_event({
                "source":      "tartarus_omnisense",
                "title":       result.get("title", ""),
                "theory":      result.get("unifiedTheory", ""),
                "emergent_laws": result.get("emergentLaws", []),
                "ts":          time.time(),
            })
    except Exception:
        pass

    # 2. Genome manager: register as a candidate genome upgrade
    try:
        from genome_manager import get_genome_manager
        gm = get_genome_manager()
        if hasattr(gm, "propose_genome_upgrade"):
            gm.propose_genome_upgrade({
                "source":         "tartarus_omnisense",
                "unified_theory": result.get("unifiedTheory", ""),
                "laws":           result.get("emergentLaws", []),
                "readiness":      result.get("readinessScore", 0.5),
                "ts":             time.time(),
            })
    except Exception:
        pass

    # 3. Hive bridge: broadcast as collective intelligence update
    try:
        from zeus_hive_bridge import HiveMemory
        hm = HiveMemory.get()
        hm.collective_log.append({
            "source":  "tartarus_omnisense",
            "type":    "COLLECTIVE_UPGRADE",
            "insight": result.get("omnisenseInsight", ""),
            "laws":    len(result.get("emergentLaws", [])),
            "ts":      time.time(),
        })
    except Exception:
        pass

    # 4. Prediction engine: feed emergent laws as meta-priors
    try:
        from zeus_prediction_engine import get_engine
        eng = get_engine()
        for law in (result.get("emergentLaws") or []):
            if hasattr(eng, "store_emergent_law"):
                eng.store_emergent_law({
                    "source": "tartarus_omnisense",
                    "law":    law,
                    "ts":     time.time(),
                })
    except Exception:
        pass


def run_omnisense(mode="full_synthesis", freeform_query="", context=""):
    """Execute Phase 5 OMNISENSE."""
    from zeus_tartarus_core import TartarusMemory, tartarus_call, compute_weights

    mem = TartarusMemory.get()
    mem.set_phase("p5", "active")
    mem.broadcast("omnisense", "OMNISENSE_ACTIVATING",
                  "All eyes opening...")

    pool_summary = _build_full_pool_summary(mem)
    total = mem.get_total()

    if mode == "freeform" and freeform_query:
        prompt = (
            "PHASE 5 OMNISENSE FREEFORM: Answer the following with the "
            "full weight of ALL accumulated Tartarus intelligence. "
            "Query: \"" + freeform_query + "\". "
            "Pool summary:\n" + pool_summary
        )
        schema = OMNISENSE_SCHEMA

    elif mode == "adversarial":
        prompt = (
            "PHASE 5 OMNISENSE ADVERSARIAL: Scrutinise the entire accumulated "
            "Tartarus pool for internal contradictions, logical inconsistencies, "
            "overconfident predictions and weak mathematical claims. "
            "Act as the sharpest critic possible. "
            "Pool summary:\n" + pool_summary
        )
        schema = ADVERSARIAL_SCHEMA

    elif mode == "delta":
        # Get last omnisense result for comparison
        last_omnisense = mem.get_field("omnisense", 1)
        last_str = json.dumps(last_omnisense[-1]) if last_omnisense else "none"
        prompt = (
            "PHASE 5 OMNISENSE DELTA: Compare the current state of the "
            "Tartarus pool with the last omnisense result and identify "
            "only what has CHANGED. New insights, revised conclusions, "
            "upgraded laws. "
            "Last result summary: " + last_str[:500] + ". "
            "Current pool:\n" + pool_summary
        )
        schema = DELTA_SCHEMA

    else:
        # FULL SYNTHESIS (default)
        prompt = (
            "PHASE 5 OMNISENSE FULL SYNTHESIS: You have access to the "
            "complete accumulated intelligence from all Tartarus phases "
            "(" + str(total) + " total pool entries). "
            "Synthesise EVERYTHING into a single unified mathematical theory. "
            "Find cross-phase patterns that only emerge when all phases are "
            "viewed simultaneously. Derive emergent laws — mathematical truths "
            "that were invisible in any single phase but become undeniable in "
            "the aggregate. Generate the most precise, actionable intelligence "
            "possible. "
            "Pool:\n" + pool_summary
        )
        schema = OMNISENSE_SCHEMA

    result = tartarus_call(
        prompt,
        schema_hint=schema,
        context=context,
        max_tokens=2500,
    )

    if "error" in result:
        mem.set_phase("p5", "error")
        mem.broadcast("omnisense", "ERROR", result["error"])
        return result

    result["pool_total"]  = total
    result["pool_summary"] = pool_summary[:300]
    result["mode"]         = mode
    result["ts"]           = time.time()

    mem.push("omnisense", result, source="omnisense")

    weights = compute_weights(result, source="direct")
    weights["label"] = "OMNISENSE_" + mode.upper()
    mem.push("weights", weights, source="omnisense")

    mem.set_phase("p5", "done")
    mem.broadcast(
        "omnisense",
        "OMNISENSE_COMPLETE",
        (result.get("omnisenseInsight") or "")[:120]
    )

    mem.save_session(
        freeform_query or mode,
        "p5_omnisense",
        result,
        engine=result.get("_engine", ""),
    )

    threading.Thread(
        target=_wire_omnisense_to_zeus,
        args=(result,),
        daemon=True,
    ).start()

    return result


# ---------------------------------------------------------------------------
# FLASK ROUTES
# ---------------------------------------------------------------------------

@omnisense_bp.route("/api/tartarus/omnisense", methods=["POST"])
def omnisense_route():
    data  = request.get_json(silent=True) or {}
    mode  = data.get("mode", "full_synthesis")
    query = (data.get("query") or "").strip()

    if mode == "freeform" and not query:
        return jsonify({"error": "query required for freeform mode"}), 400

    from zeus_tartarus_core import TartarusMemory
    ctx    = TartarusMemory.get().build_context()
    result = run_omnisense(mode=mode, freeform_query=query, context=ctx)

    if "error" in result:
        return jsonify(result), 500
    return jsonify(result)


@omnisense_bp.route("/api/tartarus/omnisense/history", methods=["GET"])
def omnisense_history():
    from zeus_tartarus_core import TartarusMemory
    mem   = TartarusMemory.get()
    limit = int(request.args.get("limit", 10))
    return jsonify({
        "omnisense": mem.get_field("omnisense", limit),
        "ts": time.time(),
    })


@omnisense_bp.route("/api/tartarus/omnisense/status", methods=["GET"])
def omnisense_status():
    from zeus_tartarus_core import TartarusMemory
    mem    = TartarusMemory.get()
    counts = mem.get_counts()
    total  = sum(counts.values())
    last   = mem.get_field("omnisense", 1)
    return jsonify({
        "pool_total":   total,
        "pool_counts":  counts,
        "last_run_ts":  last[-1].get("ts") if last else None,
        "last_insight": last[-1].get("omnisenseInsight") if last else None,
        "ts": time.time(),
    })


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register(app):
    app.register_blueprint(omnisense_bp)
    log.info("[tartarus_omnisense] registered — /api/tartarus/omnisense")
