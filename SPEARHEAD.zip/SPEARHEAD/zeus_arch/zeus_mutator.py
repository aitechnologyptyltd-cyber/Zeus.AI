# The Zeus Project 2026 — Francois Nel
# zeus_mutator.py — Knowledge Mutation Engine
# Turns genome DNA into infinite research topic trees.
# Every topic → 8 subtopics → queued → learned → mutated again. Forever.

import os
import re
import json
import time
import logging
import threading
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("zeus.mutator")

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------ #
# FAST PATTERN SEEDS — no AI needed, fires instantly                  #
# ------------------------------------------------------------------ #
UNIVERSAL_SUBTOPIC_PATTERNS = [
    "{topic} — implementation in Python",
    "{topic} — security vulnerabilities and CVEs",
    "{topic} — reverse engineering techniques",
    "{topic} — architecture and design patterns",
    "{topic} — performance optimisation strategies",
    "{topic} — open source tools and frameworks",
    "{topic} — real-world attack case studies",
    "{topic} — defence and mitigation strategies",
]

ANDROID_SUBTOPIC_PATTERNS = [
    "{topic} — Smali bytecode representation",
    "{topic} — Frida dynamic instrumentation",
    "{topic} — static analysis with jadx",
    "{topic} — Android security model interaction",
    "{topic} — network traffic interception",
    "{topic} — memory forensics on Android",
    "{topic} — automation with adb and shell",
    "{topic} — detection evasion techniques",
]

CRYPTO_SUBTOPIC_PATTERNS = [
    "{topic} — key derivation functions (PBKDF2, scrypt, Argon2)",
    "{topic} — side-channel attack vectors",
    "{topic} — implementation pitfalls and common mistakes",
    "{topic} — cryptographic protocol design",
    "{topic} — post-quantum cryptography considerations",
    "{topic} — hardware security module integration",
    "{topic} — certificate pinning and trust anchors",
    "{topic} — timing attack analysis",
]

NETWORK_SUBTOPIC_PATTERNS = [
    "{topic} — packet-level protocol analysis",
    "{topic} — man-in-the-middle interception",
    "{topic} — TLS fingerprinting techniques",
    "{topic} — API endpoint enumeration",
    "{topic} — rate limiting and throttling bypass",
    "{topic} — proxy chaining and anonymisation",
    "{topic} — WebSocket frame analysis",
    "{topic} — DNS-over-HTTPS and SNI inspection",
]


def _pick_patterns(topic: str) -> List[str]:
    """Choose the best pattern set based on topic keywords."""
    tl = topic.lower()
    if any(k in tl for k in ["android", "apk", "smali", "dalvik", "dex"]):
        return ANDROID_SUBTOPIC_PATTERNS
    if any(k in tl for k in ["crypto", "aes", "rsa", "encrypt", "cipher", "hash"]):
        return CRYPTO_SUBTOPIC_PATTERNS
    if any(k in tl for k in ["network", "http", "websocket", "tcp", "dns", "tls"]):
        return NETWORK_SUBTOPIC_PATTERNS
    return UNIVERSAL_SUBTOPIC_PATTERNS


# ================================================================== #
# MUTATOR ENGINE                                                       #
# ================================================================== #

class MutatorEngine:
    """
    Infinite knowledge mutation loop.
    Takes seeds (topics) → generates 8 subtopics via pattern-match (fast)
    and via AI (deep) → injects into learning queue → when learned,
    Advanced depth triggers another mutation cycle. Forever.
    The Zeus Project 2026 — Francois Nel
    """

    def __init__(self):
        self._lock   = threading.Lock()
        self._active = False
        self._thread: Optional[threading.Thread] = None

    # -------------------------------------------------------------- #
    # PUBLIC API                                                       #
    # -------------------------------------------------------------- #

    def mutate(
        self,
        seeds:    List[Dict],
        source:   str = "unknown",
        use_ai:   bool = True,
        priority: float = 1.5,
    ) -> Dict:
        """
        Main entry point. Takes a list of seed dicts:
            {"topic": str, "source": str, "priority": float, "depth": str}
        Returns mutation report.
        """
        from db_init import get_db

        total_queued = 0
        ai_topics    = []
        fast_topics  = []

        for seed in seeds:
            topic = seed.get("topic", "").strip()
            if not topic:
                continue
            pri = float(seed.get("priority", priority))
            dep = seed.get("depth", "Simple")

            # Fast: pattern-match subtopics (immediate, no API cost)
            fast = self._fast_subtopics(topic)
            fast_topics.extend(fast)

            # Queue the seed topic itself first
            queued = self._queue_topic(topic, dep, pri, source)
            if queued:
                total_queued += 1

            # Queue fast subtopics
            for sub in fast:
                queued = self._queue_topic(sub, "Simple", pri * 0.9, f"mutator:fast:{source}")
                if queued:
                    total_queued += 1

        # AI-deep topics (async — doesn't block return)
        if use_ai and seeds:
            all_topics = [s.get("topic", "") for s in seeds if s.get("topic")]
            ai_thread = threading.Thread(
                target=self._ai_subtopics_async,
                args=(all_topics, source, priority),
                daemon=True,
            )
            ai_thread.start()

        report = {
            "status":        "ok",
            "seeds_received": len(seeds),
            "fast_topics":   len(fast_topics),
            "total_queued":  total_queued,
            "ai_running":    use_ai,
            "source":        source,
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        }

        log.info(
            f"[Mutator] {source} — {len(seeds)} seeds → "
            f"{len(fast_topics)} fast topics → {total_queued} queued"
        )

        return report

    def mutate_from_knowledge(self, topic: str, depth_reached: str, source: str = "learner") -> int:
        """
        Called by the learner when a topic reaches Advanced depth.
        Generates 8 subtopics and injects them back into the queue.
        This is the core of the infinite loop.
        """
        if depth_reached not in ("Advanced", "Professional", "Complex", "Mastery"):
            return 0

        subtopics = self._fast_subtopics(topic)
        queued = 0
        for sub in subtopics:
            if self._queue_topic(sub, "Simple", 1.3, f"mutator:loop:{source}"):
                queued += 1

        # Also trigger AI expansion asynchronously
        threading.Thread(
            target=self._ai_subtopics_async,
            args=([topic], f"loop:{source}", 1.3),
            daemon=True,
        ).start()

        log.info(
            f"[Mutator] Loop triggered: '{topic}' @ {depth_reached} "
            f"→ {queued} new subtopics queued"
        )
        return queued

    def status(self) -> Dict:
        from db_init import get_db
        try:
            conn    = get_db()
            pending = conn.execute(
                "SELECT COUNT(*) FROM queue WHERE status='pending'"
            ).fetchone()[0]
            done    = conn.execute(
                "SELECT COUNT(*) FROM queue WHERE status='done'"
            ).fetchone()[0]
            conn.close()
            return {
                "active":  self._active,
                "pending": pending,
                "done":    done,
            }
        except Exception as e:
            return {"error": str(e)}

    # -------------------------------------------------------------- #
    # FAST SUBTOPIC GENERATION — pattern-match, instant, no API       #
    # -------------------------------------------------------------- #

    def _fast_subtopics(self, topic: str) -> List[str]:
        patterns = _pick_patterns(topic)
        return [p.replace("{topic}", topic) for p in patterns]

    # -------------------------------------------------------------- #
    # AI SUBTOPIC GENERATION — deep, async, uses Groq then Claude     #
    # -------------------------------------------------------------- #

    def _ai_subtopics_async(
        self, topics: List[str], source: str, priority: float
    ):
        """Runs in background thread. Calls Groq (fast) then Claude (deep)."""
        try:
            combined = "; ".join(topics[:5])  # batch up to 5 topics per call

            prompt = (
                f"You are the Zeus knowledge mutation engine. "
                f"Given these research topics: {combined}\n\n"
                f"Generate exactly 8 high-value research subtopics for EACH topic above. "
                f"Make them specific, technically deep, and actionable. "
                f"Return ONLY a JSON array of strings — no explanation, no markdown:\n"
                f'["subtopic 1", "subtopic 2", ...]'
            )

            subtopics = self._call_groq(prompt) or self._call_claude(prompt)
            if not subtopics:
                return

            queued = 0
            for sub in subtopics:
                if isinstance(sub, str) and sub.strip():
                    if self._queue_topic(
                        sub.strip(), "Simple",
                        priority * 0.85,
                        f"mutator:ai:{source}"
                    ):
                        queued += 1

            log.info(
                f"[Mutator] AI expansion for {len(topics)} topics "
                f"→ {len(subtopics)} subtopics → {queued} queued"
            )

        except Exception as e:
            log.warning(f"[Mutator] AI subtopic error: {e}")

    def _call_groq(self, prompt: str) -> Optional[List[str]]:
        api_key = os.environ.get("GROQ_API_KEY", "")
        model   = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
        if not api_key:
            return None
        try:
            from groq import Groq
            client = Groq(api_key=api_key)
            resp   = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1024,
                temperature=0.7,
            )
            raw = resp.choices[0].message.content.strip()
            return self._parse_json_list(raw)
        except Exception as e:
            log.warning(f"[Mutator] Groq error: {e}")
            return None

    def _call_claude(self, prompt: str) -> Optional[List[str]]:
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            return None
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            msg    = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            raw = msg.content[0].text.strip()
            return self._parse_json_list(raw)
        except Exception as e:
            log.warning(f"[Mutator] Claude error: {e}")
            return None

    def _parse_json_list(self, raw: str) -> Optional[List[str]]:
        try:
            # Strip markdown fences if present
            raw = re.sub(r"```(?:json)?", "", raw).strip().rstrip("```").strip()
            data = json.loads(raw)
            if isinstance(data, list):
                return [str(x) for x in data if x]
        except (json.JSONDecodeError, ValueError):
            # Try to extract quoted strings
            items = re.findall(r'"([^"]{10,})"', raw)
            if items:
                return items
        return None

    # -------------------------------------------------------------- #
    # QUEUE INJECTION                                                  #
    # -------------------------------------------------------------- #

    def _queue_topic(
        self,
        topic:    str,
        depth:    str  = "Simple",
        priority: float = 1.0,
        source:   str  = "mutator",
    ) -> bool:
        """Insert a topic into the learning queue. Returns True if inserted."""
        from db_init import get_db

        topic = topic.strip()[:500]
        if not topic:
            return False

        try:
            conn = get_db()
            conn.execute("""
                INSERT OR IGNORE INTO queue
                    (topic, depth, priority, status, attempts)
                VALUES (?, ?, ?, 'pending', 0)
            """, (topic, depth, priority))
            changes = conn.total_changes
            conn.commit()
            conn.close()
            return changes > 0
        except Exception as e:
            log.warning(f"[Mutator] Queue insert error: {e}")
            return False


# ================================================================== #
# FLASK BLUEPRINT                                                      #
# ================================================================== #

from flask import Blueprint, jsonify, request

mutator_bp = Blueprint("mutator", __name__)
_engine    = MutatorEngine()


@mutator_bp.route("/api/mutator/status")
def mutator_status():
    return jsonify(_engine.status())


@mutator_bp.route("/api/mutator/mutate", methods=["POST"])
def mutator_run():
    data   = request.get_json(silent=True) or {}
    seeds  = data.get("seeds", [])
    source = data.get("source", "api")
    use_ai = data.get("use_ai", True)

    if not seeds:
        topic = data.get("topic", "").strip()
        if not topic:
            return jsonify({"error": "seeds or topic required"}), 400
        seeds = [{"topic": topic, "priority": 1.5, "depth": "Simple"}]

    result = _engine.mutate(seeds, source=source, use_ai=use_ai)
    return jsonify(result)


@mutator_bp.route("/api/mutator/loop", methods=["POST"])
def mutator_loop():
    """Trigger the mutation loop from a learned topic."""
    data  = request.get_json(silent=True) or {}
    topic = data.get("topic", "").strip()
    depth = data.get("depth_reached", "Advanced")

    if not topic:
        return jsonify({"error": "topic required"}), 400

    queued = _engine.mutate_from_knowledge(topic, depth, source="api")
    return jsonify({"status": "ok", "topic": topic, "subtopics_queued": queued})


@mutator_bp.route("/api/mutator/seeds", methods=["POST"])
def mutator_seeds():
    """Accept raw seed list from APK engine or other DNA sources."""
    data   = request.get_json(silent=True) or {}
    seeds  = data.get("seeds", [])
    source = data.get("source", "seeds_api")

    if not seeds:
        return jsonify({"error": "seeds list required"}), 400

    result = _engine.mutate(seeds, source=source, use_ai=True)
    return jsonify(result)


@mutator_bp.route("/api/mutator/health", methods=["GET"])
def mutator_health():
    """Health check for the mutator engine."""
    s = _engine.status()
    return jsonify({
        "status":  "ok",
        "module":  "zeus_mutator",
        "version": "2.0",
        "active":  s.get("active", False),
        "pending": s.get("pending", 0),
        "done":    s.get("done", 0),
        "patterns": {
            "universal":  len(UNIVERSAL_SUBTOPIC_PATTERNS),
            "android":    len(ANDROID_SUBTOPIC_PATTERNS),
            "crypto":     len(CRYPTO_SUBTOPIC_PATTERNS),
            "network":    len(NETWORK_SUBTOPIC_PATTERNS),
        },
    })


@mutator_bp.route("/api/mutator/queue/reset", methods=["POST"])
def mutator_queue_reset():
    """Reset stuck 'running' queue items back to 'pending'."""
    try:
        from db_init import get_db
        conn = get_db()
        conn.execute(
            "UPDATE queue SET status='pending' WHERE status='running'"
        )
        reset = conn.total_changes
        conn.commit()
        conn.close()
        return jsonify({"status": "ok", "reset": reset})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@mutator_bp.route("/api/mutator/genome/seed", methods=["POST"])
def mutator_genome_seed():
    """
    Pull topics from genome capabilities and seed the mutation queue.
    POST { "limit": int, "priority": float }
    """
    data     = request.get_json(silent=True) or {}
    limit    = int(data.get("limit", 50))
    priority = float(data.get("priority", 1.2))
    try:
        from db_init import get_db
        conn  = get_db()
        rows  = conn.execute(
            "SELECT name, description, capabilities FROM genome "
            "ORDER BY priority DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        seeds = []
        for row in rows:
            topic = row["name"] or ""
            if topic:
                seeds.append({"topic": topic, "priority": priority, "depth": "Simple"})
            caps = (row["capabilities"] or "").split(",")
            for cap in caps:
                cap = cap.strip()
                if cap and len(cap) > 4:
                    seeds.append({"topic": cap, "priority": priority * 0.9, "depth": "Simple"})
        if not seeds:
            return jsonify({"error": "no genome segments found"}), 404
        result = _engine.mutate(seeds, source="genome_seed", use_ai=False)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ================================================================== #
# MODULE EXPORT                                                        #
# ================================================================== #

def get_engine() -> MutatorEngine:
    return _engine
