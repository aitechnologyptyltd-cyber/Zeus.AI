# The Zeus Project 2026 — Francois Nel
# zeus_learning_dashboard.py — Zeus v4.0 Live Dashboard
# Dark UI · Tabs · Live logs · Blueprints tab · Forge buttons · Download buttons

import os
import logging
from flask import Blueprint, jsonify, Response

log = logging.getLogger("zeus.dashboard")
learning_bp = Blueprint("learning_dashboard", __name__)

# ================================================================== #
# DASHBOARD HTML                                                       #
# ================================================================== #

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zeus v4.0 — The Zeus Project 2026</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0a0f;color:#c8d0e0;font-family:'Courier New',monospace;font-size:13px;overflow-x:hidden}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:#111}::-webkit-scrollbar-thumb{background:#1e90ff44}

/* HEADER */
.hdr{background:#0d0d14;border-bottom:1px solid #1e90ff33;padding:10px 16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.hdr-logo{background:#1e90ff;color:#000;font-weight:bold;padding:4px 8px;border-radius:4px;font-size:13px}
.hdr-title{color:#1e90ff;font-size:14px;letter-spacing:2px;font-weight:bold}
.hdr-sub{color:#444;font-size:10px}
.hdr-right{margin-left:auto;display:flex;gap:16px;align-items:center;flex-wrap:wrap}
.hdr-stat{text-align:center}
.hdr-stat .v{color:#1e90ff;font-size:14px;font-weight:bold}
.hdr-stat .l{color:#444;font-size:9px;letter-spacing:1px}
.dot{width:7px;height:7px;border-radius:50%;background:#1e90ff;display:inline-block;margin-right:4px;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}

/* TABS */
.tabs{display:flex;gap:2px;padding:10px 16px 0;border-bottom:1px solid #1a1a2e;overflow-x:auto}
.tab{padding:7px 16px;border-radius:4px 4px 0 0;cursor:pointer;font-size:11px;letter-spacing:1px;color:#555;border:1px solid transparent;border-bottom:none;white-space:nowrap}
.tab:hover{color:#888;background:#111}
.tab.active{color:#1e90ff;background:#0d0d14;border-color:#1e90ff33;border-bottom:1px solid #0d0d14}
.tab-content{display:none;padding:16px}
.tab-content.active{display:block}

/* CARDS */
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px}
.card{background:#0d0d14;border:1px solid #1a1a2e;border-radius:6px;padding:12px}
.card h3{color:#444;font-size:9px;letter-spacing:1px;text-transform:uppercase;margin-bottom:6px}
.card .val{color:#1e90ff;font-size:26px;font-weight:bold}
.card .sub{color:#333;font-size:10px;margin-top:3px}

/* TABLES */
table{width:100%;border-collapse:collapse}
td,th{padding:7px 10px;border-bottom:1px solid #111;font-size:12px;text-align:left}
th{color:#444;font-size:9px;text-transform:uppercase;letter-spacing:1px}
tr:hover td{background:#0d0d14}

/* BUTTONS */
.btn{display:inline-block;padding:5px 12px;border-radius:4px;cursor:pointer;font-size:11px;font-family:inherit;border:none;letter-spacing:1px;text-decoration:none}
.btn-blue{background:#1e90ff22;color:#1e90ff;border:1px solid #1e90ff44}
.btn-blue:hover{background:#1e90ff44}
.btn-green{background:#00c85322;color:#00c853;border:1px solid #00c85344}
.btn-green:hover{background:#00c85344}
.btn-orange{background:#ff6d0022;color:#ff6d00;border:1px solid #ff6d0044}
.btn-orange:hover{background:#ff6d0044}
.btn-red{background:#f4433622;color:#f44336;border:1px solid #f4433644}
.btn-sm{padding:3px 8px;font-size:10px}

/* STATUS BADGES */
.badge{display:inline-block;padding:2px 7px;border-radius:10px;font-size:10px}
.badge-done{background:#00c85322;color:#00c853}
.badge-forging{background:#1e90ff22;color:#1e90ff;animation:pulse 1.5s infinite}
.badge-pending{background:#33333322;color:#555}
.badge-failed{background:#f4433622;color:#f44336}
.badge-running{background:#ff6d0022;color:#ff6d00;animation:pulse 1.5s infinite}
.badge-queued{background:#9c27b022;color:#9c27b0}

/* DEPTH COLOURS */
.d-Simple{color:#4caf50}.d-Advanced{color:#1e90ff}
.d-Professional{color:#ff9800}.d-Complex{color:#e91e63}.d-Mastery{color:#9c27b0}

/* LOG BOX */
.logbox{background:#060608;border:1px solid #1a1a2e;border-radius:4px;padding:10px;height:220px;overflow-y:auto;font-size:11px;line-height:1.6}
.log-ok{color:#00c853}.log-warn{color:#ff9800}.log-err{color:#f44336}.log-info{color:#1e90ff}.log-dim{color:#333}

/* FORGE PANEL */
.forge-panel{background:#0d0d14;border:1px solid #1e90ff22;border-radius:6px;padding:14px;margin-bottom:16px}
.forge-panel h3{color:#1e90ff;font-size:11px;letter-spacing:2px;text-transform:uppercase;margin-bottom:12px}
.fg-row{display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap}
.fg-input{flex:1;min-width:200px;background:#060608;border:1px solid #1a1a2e;color:#c8d0e0;padding:7px 10px;border-radius:4px;font-family:inherit;font-size:12px}
.fg-input:focus{outline:none;border-color:#1e90ff44}
select.fg-input{cursor:pointer}

/* PROGRESS BAR */
.bar-wrap{background:#1a1a2e;border-radius:2px;height:4px;margin-top:4px}
.bar{background:#1e90ff;height:4px;border-radius:2px;transition:width .5s}

/* REFRESH BAR */
.rbar{height:2px;background:#1e90ff33;overflow:hidden}
.rbar-inner{height:2px;background:#1e90ff;animation:rbaranim 10s linear infinite}
@keyframes rbaranim{0%{width:0%;margin-left:0}100%{width:100%;margin-left:0}}

/* SECTION TITLE */
.sec-title{color:#1e90ff;font-size:10px;letter-spacing:2px;text-transform:uppercase;margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid #1a1a2e}

/* DOWNLOAD LINK */
.dl-links{display:flex;gap:6px;flex-wrap:wrap}
.dl-link{padding:3px 8px;font-size:10px;border-radius:3px;text-decoration:none;border:1px solid}
.dl-apk{color:#00c853;border-color:#00c85344;background:#00c85311}
.dl-pdf{color:#ff9800;border-color:#ff980044;background:#ff980011}
.dl-zip{color:#9c27b0;border-color:#9c27b044;background:#9c27b011}
.dl-py {color:#1e90ff;border-color:#1e90ff44;background:#1e90ff11}
</style>
</head>
<body>

<!-- HEADER -->
<div class="hdr">
  <div class="hdr-logo">Z</div>
  <div>
    <div class="hdr-title">ZEUS v4.0</div>
    <div class="hdr-sub">The Zeus Project 2026 — Francois Nel</div>
  </div>
  <div class="hdr-right">
    <div class="hdr-stat"><div class="val" id="h-knowledge">—</div><div class="l">KNOWLEDGE</div></div>
    <div class="hdr-stat"><div class="val" id="h-genome">—</div><div class="l">GENOME</div></div>
    <div class="hdr-stat"><div class="val" id="h-blueprints">—</div><div class="l">BLUEPRINTS</div></div>
    <div class="hdr-stat"><div class="val" id="h-queue">—</div><div class="l">QUEUE</div></div>
    <div style="color:#444;font-size:10px" id="h-time">—</div>
  </div>
</div>
<div class="rbar"><div class="rbar-inner"></div></div>

<!-- TABS -->
<div class="tabs">
  <div class="tab active" onclick="tab('overview',this)">OVERVIEW</div>
  <div class="tab" onclick="tab('chat',this)">💬 CHAT</div>
  <div class="tab" onclick="tab('blueprints',this)">⚡ BLUEPRINTS</div>
  <div class="tab" onclick="tab('knowledge',this)">KNOWLEDGE</div>
  <div class="tab" onclick="tab('queue',this)">QUEUE</div>
  <div class="tab" onclick="tab('genome',this)">GENOME</div>
  <div class="tab" onclick="tab('evolution',this)">EVOLUTION</div>
  <div class="tab" onclick="tab('executor',this)">EXECUTOR</div>
  <div class="tab" onclick="tab('upload',this)">📁 UPLOAD</div>
  <div class="tab" onclick="tab('logs',this)">LIVE LOGS</div>
</div>

<!-- ===== OVERVIEW ===== -->
<div id="pane-overview" class="tab-content active">
  <div class="cards">
    <div class="card"><h3>Knowledge</h3><div class="val" id="ov-know">—</div><div class="sub">articles saved</div></div>
    <div class="card"><h3>Genome</h3><div class="val" id="ov-genome">—</div><div class="sub">DNA segments</div></div>
    <div class="card"><h3>Blueprints</h3><div class="val" id="ov-bp">—</div><div class="sub">forged total</div></div>
    <div class="card"><h3>Queue</h3><div class="val" id="ov-queue">—</div><div class="sub">pending topics</div></div>
    <div class="card"><h3>Learner</h3><div class="val" id="ov-learner" style="font-size:15px">—</div><div class="sub">scheduler</div></div>
    <div class="card"><h3>Evolution</h3><div class="val" id="ov-evo" style="font-size:15px">—</div><div class="sub">last cycle</div></div>
  </div>

  <div class="sec-title">Depth Progress</div>
  <div id="depth-bars" style="margin-bottom:16px"></div>

  <div class="sec-title">System Status</div>
  <div id="sys-status" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:6px"></div>
</div>

<!-- ===== CHAT ===== -->
<div id="pane-chat" class="tab-content">
  <div style="max-width:800px">

    <!-- MESSAGES -->
    <div id="chat-messages" style="height:420px;overflow-y:auto;padding:10px;
         background:#060608;border:1px solid #1a1a2e;border-radius:6px;
         margin-bottom:12px;display:flex;flex-direction:column;gap:10px">
      <div style="color:#333;text-align:center;margin-top:160px;font-size:11px">
        Zeus is listening. Ask anything.
      </div>
    </div>

    <!-- ENGINE STATUS BAR -->
    <div id="chat-status-bar" style="display:flex;gap:12px;margin-bottom:8px;font-size:10px;color:#444">
      <span id="cs-engine">engine: —</span>
      <span id="cs-conf">confidence: —</span>
      <span id="cs-escalated"></span>
      <span id="cs-ctx"></span>
    </div>

    <!-- INPUT ROW -->
    <div style="display:flex;gap:8px">
      <input id="chat-input" class="fg-input" placeholder="Ask Zeus…"
             onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendChat()}">
      <button class="btn btn-blue" onclick="sendChat()">SEND</button>
      <button class="btn btn-sm" style="color:#333;border:1px solid #1a1a2e"
              onclick="clearChat()">CLR</button>
    </div>

    <!-- CHAT METADATA -->
    <div style="margin-top:8px;color:#222;font-size:10px">
      Groq primary · Claude fallback · confidence threshold 0.72 · context injection from knowledge + genome
    </div>
  </div>
</div>

<!-- ===== BLUEPRINTS ===== -->
<div id="pane-blueprints" class="tab-content">

  <!-- FORGE PANEL -->
  <div class="forge-panel">
    <h3>⚡ Forge New Blueprint</h3>
    <div class="fg-row">
      <input id="bp-desc" class="fg-input" placeholder="Describe what to forge… e.g. 'Android keylogger detector module'">
      <select id="bp-type" class="fg-input" style="max-width:180px">
        <option value="python_module">Python Module</option>
        <option value="flask_blueprint">Flask Blueprint</option>
        <option value="capability">Capability</option>
        <option value="shell_script">Shell Script</option>
        <option value="apk">APK (builds .apk via sandbox)</option>
      </select>
      <button class="btn btn-blue" onclick="forgeBlueprint()">⚡ FORGE + LOOP</button>
      <button class="btn btn-orange" onclick="forgeBlueprint(false)">FORGE ONCE</button>
    </div>
    <div id="forge-status" style="color:#444;font-size:11px;margin-top:6px"></div>
  </div>

  <!-- BLUEPRINTS TABLE -->
  <div class="sec-title">Stored Blueprints</div>
  <div style="margin-bottom:8px;display:flex;gap:8px">
    <button class="btn btn-sm btn-blue" onclick="loadBlueprints()">↻ Refresh</button>
    <span style="color:#333;font-size:10px;line-height:28px">Auto-refreshes every 10s</span>
  </div>
  <table>
    <thead><tr>
      <th>#</th><th>Name</th><th>Type</th><th>Status</th>
      <th>Loop</th><th>Created</th><th>Export</th>
    </tr></thead>
    <tbody id="bp-table"></tbody>
  </table>

  <!-- LIVE LOG FOR BLUEPRINTS -->
  <div class="sec-title" style="margin-top:16px">Blueprint Forge Log</div>
  <div class="logbox" id="bp-log"></div>
</div>

<!-- ===== KNOWLEDGE ===== -->
<div id="pane-knowledge" class="tab-content">
  <div class="sec-title">Latest Knowledge Articles</div>
  <div id="know-feed"></div>
</div>

<!-- ===== QUEUE ===== -->
<div id="pane-queue" class="tab-content">
  <div class="cards">
    <div class="card"><h3>Pending</h3><div class="val" id="q-pending">—</div></div>
    <div class="card"><h3>Done</h3><div class="val" id="q-done">—</div></div>
    <div class="card"><h3>Failed</h3><div class="val" id="q-failed">—</div></div>
    <div class="card"><h3>Running</h3><div class="val" id="q-running">—</div></div>
  </div>
  <div style="margin-bottom:8px;display:flex;gap:6px;flex-wrap:wrap">
    <button class="btn btn-sm btn-orange" onclick="resetQueue()">↺ Reset Stuck</button>
    <button class="btn btn-sm btn-blue" onclick="startLearner()">▶ Start Learner</button>
    <button class="btn btn-sm" style="background:#00c85322;color:#00c853;border:1px solid #00c85344"
            onclick="fastBlast()">⚡ FAST BLAST — Zero LLM</button>
    <button class="btn btn-sm" onclick="seedQueue()" style="color:#9c27b0;border:1px solid #9c27b044;background:#9c27b011">⊕ Seed 2610 Topics</button>
  </div>
  <div id="queue-msg" style="color:#444;font-size:11px;margin-bottom:8px"></div>
</div>

<!-- ===== GENOME ===== -->
<div id="pane-genome" class="tab-content">
  <div class="sec-title">Genome Segments</div>
  <input id="genome-search" class="fg-input" style="margin-bottom:10px;width:100%;max-width:400px"
         placeholder="Search genome…" oninput="loadGenome()">
  <table>
    <thead><tr><th>#</th><th>Name</th><th>Type</th><th>Priority</th></tr></thead>
    <tbody id="genome-table"></tbody>
  </table>
</div>

<!-- ===== EVOLUTION ===== -->
<div id="pane-evolution" class="tab-content">
  <div style="margin-bottom:12px;display:flex;gap:8px">
    <button class="btn btn-blue" onclick="triggerEvolution()">▶ Run Evolution Cycle</button>
    <span id="evo-status" style="color:#444;font-size:11px;line-height:30px"></span>
  </div>
  <div class="sec-title">Evolution History</div>
  <table>
    <thead><tr>
      <th>Cycle</th><th>Modules</th><th>Gaps</th><th>Merges</th><th>Completed</th>
    </tr></thead>
    <tbody id="evo-table"></tbody>
  </table>
</div>

<!-- ===== EXECUTOR ===== -->
<div id="pane-executor" class="tab-content">
  <div class="forge-panel">
    <h3>Submit Task</h3>
    <div class="fg-row">
      <select id="ex-type" class="fg-input" style="max-width:150px" onchange="updateExForm()">
        <option value="shell">Shell</option>
        <option value="python">Python</option>
        <option value="forge">Forge</option>
        <option value="learn">Learn</option>
        <option value="evolve">Evolve</option>
      </select>
      <input id="ex-param" class="fg-input" placeholder="Command / code / description / topic…">
      <button class="btn btn-blue" onclick="submitTask()">▶ RUN</button>
    </div>
    <div id="ex-status" style="color:#444;font-size:11px;margin-top:6px"></div>
  </div>
  <div class="sec-title">Jobs</div>
  <table>
    <thead><tr>
      <th>Job ID</th><th>Type</th><th>Label</th><th>Status</th>
      <th>Submitted</th><th>Export</th>
    </tr></thead>
    <tbody id="exec-table"></tbody>
  </table>
</div>

<!-- ===== UPLOAD ===== -->
<div id="pane-upload" class="tab-content">
  <div class="forge-panel">
    <h3>📁 Upload File → DNA Splice into Zeus</h3>
    <div class="fg-row" style="align-items:center">
      <label style="color:#888;font-size:11px;min-width:100px">Select File:</label>
      <input type="file" id="upload-file" style="flex:1;background:#060608;
             border:1px solid #1a1a2e;color:#c8d0e0;padding:6px 10px;border-radius:4px;
             font-family:inherit;font-size:12px" accept="*/*">
    </div>
    <div class="fg-row" style="margin-top:8px">
      <input id="upload-tag" class="fg-input" placeholder="Optional tag / label for this upload">
      <button class="btn btn-blue" onclick="uploadFile()">⬆ UPLOAD + SPLICE</button>
    </div>
    <div id="upload-progress" style="display:none;margin-top:8px">
      <div class="bar-wrap"><div class="bar" id="upload-bar" style="width:0%"></div></div>
    </div>
    <div id="upload-status" style="color:#444;font-size:11px;margin-top:8px"></div>
  </div>

  <!-- SUPPORTED TYPES -->
  <div class="sec-title">Supported File Types</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:6px;margin-bottom:16px">
    <div style="background:#0d0d14;border:1px solid #111;border-radius:4px;padding:8px">
      <div style="color:#1e90ff;font-size:10px;letter-spacing:1px">ANDROID</div>
      <div style="color:#555;font-size:10px">.apk .aab .dex .smali</div>
    </div>
    <div style="background:#0d0d14;border:1px solid #111;border-radius:4px;padding:8px">
      <div style="color:#00c853;font-size:10px;letter-spacing:1px">CODE</div>
      <div style="color:#555;font-size:10px">.py .js .ts .java .kt .rs .go</div>
    </div>
    <div style="background:#0d0d14;border:1px solid #111;border-radius:4px;padding:8px">
      <div style="color:#ff9800;font-size:10px;letter-spacing:1px">ARCHIVES</div>
      <div style="color:#555;font-size:10px">.zip .tar .gz .7z</div>
    </div>
    <div style="background:#0d0d14;border:1px solid #111;border-radius:4px;padding:8px">
      <div style="color:#9c27b0;font-size:10px;letter-spacing:1px">DOCUMENTS</div>
      <div style="color:#555;font-size:10px">.pdf .docx .txt .md</div>
    </div>
    <div style="background:#0d0d14;border:1px solid #111;border-radius:4px;padding:8px">
      <div style="color:#e91e63;font-size:10px;letter-spacing:1px">DATA</div>
      <div style="color:#555;font-size:10px">.json .csv .yaml .xml</div>
    </div>
    <div style="background:#0d0d14;border:1px solid #111;border-radius:4px;padding:8px">
      <div style="color:#ff6d00;font-size:10px;letter-spacing:1px">BINARY</div>
      <div style="color:#555;font-size:10px">.so .dll .exe .bin</div>
    </div>
  </div>

  <!-- RECENT UPLOADS -->
  <div class="sec-title">Recent Uploads</div>
  <div style="margin-bottom:8px">
    <button class="btn btn-sm btn-blue" onclick="loadUploads()">↻ Refresh</button>
  </div>
  <table>
    <thead><tr>
      <th>#</th><th>Filename</th><th>Category</th><th>Size</th>
      <th>Genome Segments</th><th>Status</th><th>Uploaded</th>
    </tr></thead>
    <tbody id="upload-table"><tr><td colspan="7" style="color:#333;padding:20px">No uploads yet</td></tr></tbody>
  </table>
</div>

<!-- ===== LIVE LOGS ===== -->
<div id="pane-logs" class="tab-content">
  <div style="margin-bottom:8px;display:flex;gap:8px;align-items:center">
    <button class="btn btn-sm btn-blue" onclick="loadLogs()">↻ Refresh</button>
    <label style="color:#444;font-size:11px">
      <input type="checkbox" id="log-autoscroll" checked style="margin-right:4px">Auto-scroll
    </label>
  </div>
  <div class="logbox" id="live-log" style="height:400px"></div>
</div>

<script>
// ================================================================
// UTILS
// ================================================================
async function api(url){
  try{const r=await fetch(url);return await r.json()}catch(e){return null}
}
async function post(url,body){
  try{
    const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    return await r.json()
  }catch(e){return null}
}
function fmt(n){return n!=null?Number(n).toLocaleString():'—'}
function ts(s){return s?(s+'').substring(0,16):'—'}
function badge(s){
  const m={done:'badge-done',forging:'badge-forging',pending:'badge-pending',
           failed:'badge-failed',running:'badge-running',queued:'badge-queued'};
  return `<span class="badge ${m[s]||'badge-pending'}">${s||'—'}</span>`;
}
function dlLinks(id, fmt){
  if(!id||id==='')return '—';
  const exts = fmt?[fmt]:['py','zip'];
  return exts.map(e=>
    `<a class="dl-link dl-${e}" href="/api/export/${id}?format=${e}" download>↓ ${e.toUpperCase()}</a>`
  ).join(' ');
}

function apkButton(id){
  if(!id)return '';
  return `<a class="dl-link dl-apk" href="/api/export/${id}?format=apk" download>↓ APK</a>`;
}

// ================================================================
// TABS
// ================================================================
let activeTab='overview';
function tab(name,el){
  document.querySelectorAll('.tab-content').forEach(e=>e.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(e=>e.classList.remove('active'));
  document.getElementById('pane-'+name).classList.add('active');
  el.classList.add('active');
  activeTab=name;
  refreshTab();
}

// ================================================================
// HEADER STATS
// ================================================================
async function refreshHeader(){
  const h=await api('/api/health');
  if(!h)return;
  document.getElementById('h-knowledge').textContent=fmt(h.knowledge);
  document.getElementById('h-genome').textContent=fmt(h.genome_segments);
  document.getElementById('h-queue').textContent=fmt(h.queue_pending);
  document.getElementById('h-time').textContent=new Date().toLocaleTimeString();

  const bs=await api('/api/blueprints/stats');
  if(bs)document.getElementById('h-blueprints').textContent=fmt(bs.total);
}

// ================================================================
// OVERVIEW TAB
// ================================================================
async function loadOverview(){
  const h=await api('/api/health');
  const l=await api('/api/learner/status');
  const bs=await api('/api/blueprints/stats');
  const es=await api('/api/evolution/status');

  if(h){
    document.getElementById('ov-know').textContent=fmt(h.knowledge);
    document.getElementById('ov-genome').textContent=fmt(h.genome_segments);
    document.getElementById('ov-queue').textContent=fmt(h.queue_pending);
  }
  if(bs)document.getElementById('ov-bp').textContent=fmt(bs.total);
  if(l){
    document.getElementById('ov-learner').textContent=
      l.scheduler_running?'🟢 ON':'🔴 OFF';
  }
  if(es){
    document.getElementById('ov-evo').textContent=
      es.running?'🔄 RUNNING':'✓ IDLE';
  }

  // Depth bars
  if(l&&l.queue){
    const depths=[
      {name:'Simple',   color:'#4caf50'},
      {name:'Advanced', color:'#1e90ff'},
      {name:'Professional',color:'#ff9800'},
      {name:'Complex',  color:'#e91e63'},
      {name:'Mastery',  color:'#9c27b0'},
    ];
    const total=(l.queue.done||0)+(l.queue.pending||0);
    const done=l.queue.done||0;
    let html='';
    for(const d of depths){
      const pct=total>0?Math.min(100,Math.round((done/total)*100)):0;
      html+=`<div style="margin-bottom:8px">
        <div style="display:flex;justify-content:space-between">
          <span class="d-${d.name}">${d.name}</span>
          <span style="color:#333">${pct}%</span>
        </div>
        <div class="bar-wrap"><div class="bar" style="width:${pct}%;background:${d.color}"></div></div>
      </div>`;
    }
    document.getElementById('depth-bars').innerHTML=html;
  }

  // System status
  const modules=[
    'Zeus Core','Flask API','SQLite DB','Genome Manager',
    'Upload Engine','Forge Engine','Sandbox Executor',
    'Learning Engine','Mutator Engine','Blueprint Engine',
    'Evolution Engine','Nightly Scheduler',
  ];
  document.getElementById('sys-status').innerHTML=
    modules.map(m=>`<div style="display:flex;justify-content:space-between;
      padding:5px 10px;background:#0d0d14;border-radius:4px;border:1px solid #111">
      <span style="color:#888">${m}</span>
      <span><span class="dot"></span><span style="color:#00c853;font-size:10px">ACTIVE</span></span>
    </div>`).join('');
}

// ================================================================
// BLUEPRINTS TAB
// ================================================================
async function loadBlueprints(){
  const data=await api('/api/blueprints/list?limit=60');
  if(!data)return;
  const rows=data.blueprints||[];

  document.getElementById('bp-table').innerHTML=rows.map(r=>{
    const hasDl=r.status==='done'&&r.blueprint_id;
    const isApk=r.type==='apk';
    const fmt=isApk?'apk':(r.file_format||'py');
    const dlHtml=hasDl
      ?`<div class="dl-links">
          ${isApk
            ? `<a class="dl-link dl-apk" href="/api/export/${r.blueprint_id}?format=apk" download>↓ APK</a>`
            : `<a class="dl-link dl-${fmt}" href="/api/export/${r.blueprint_id}?format=${fmt}" download>↓ ${fmt.toUpperCase()}</a>`
          }
          <a class="dl-link dl-zip" href="/api/export/${r.blueprint_id}?format=zip" download>↓ ZIP</a>
          <a class="dl-link dl-pdf" href="/api/export/${r.blueprint_id}?format=pdf" download>↓ PDF</a>
        </div>`
      :'—';
    return `<tr>
      <td style="color:#333">${r.id}</td>
      <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#c8d0e0"
          title="${r.description}">${r.name||r.description}</td>
      <td style="color:#555">${r.type}</td>
      <td>${badge(r.status)}</td>
      <td style="color:#444">${r.loop_count||0}</td>
      <td style="color:#333;font-size:10px">${ts(r.created_at)}</td>
      <td>${dlHtml}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="7" style="color:#333;padding:20px">No blueprints yet — forge one above</td></tr>';

  // Update blueprint log
  appendLog('bp-log', rows.filter(r=>r.status==='done').slice(0,5)
    .map(r=>`<span class="log-ok">[done]</span> <span class="log-info">${r.name}</span> → ${r.type} • loop ${r.loop_count}`).join('\n'));
}

function appendLog(id, text){
  const el=document.getElementById(id);
  if(!el)return;
  if(text)el.innerHTML=text+'<br>'+el.innerHTML;
}

async function forgeBlueprint(loop=true){
  const desc=document.getElementById('bp-desc').value.trim();
  const type=document.getElementById('bp-type').value;
  if(!desc){alert('Enter a description');return}

  document.getElementById('forge-status').innerHTML=
    '<span class="log-info">⚡ Forging… polling for result…</span>';

  const r=await post('/api/blueprints/forge',{description:desc,type:type,loop:loop});
  if(!r||r.error){
    document.getElementById('forge-status').innerHTML=
      `<span class="log-err">Error: ${r?.error||'unknown'}</span>`;
    return;
  }

  document.getElementById('forge-status').innerHTML=
    `<span class="log-ok">Queued: ${r.blueprint_id.substring(0,8)}…</span>
     ${loop?'<span class="log-info"> — Infinite loop active</span>':''}`;

  // Add to log
  const logEl=document.getElementById('bp-log');
  const ts_=new Date().toLocaleTimeString();
  logEl.innerHTML=
    `<span class="log-dim">[${ts_}]</span> <span class="log-ok">blueprint forged</span> → <span class="log-info">${desc.substring(0,60)}</span> → mutator seeding…\n`
    +logEl.innerHTML;

  setTimeout(loadBlueprints, 3000);
}

// ================================================================
// KNOWLEDGE TAB
// ================================================================
async function loadKnowledge(){
  const data=await api('/api/knowledge?limit=40');
  if(!data)return;
  document.getElementById('know-feed').innerHTML=
    (data.articles||[]).map(a=>`
      <div style="border-bottom:1px solid #111;padding:8px 0">
        <div style="color:#c8d0e0">${a.topic}</div>
        <div style="display:flex;gap:8px;margin-top:3px">
          <span class="d-${a.depth}" style="font-size:10px">${a.depth}</span>
          <span style="color:#333;font-size:10px">conf ${(a.confidence||0).toFixed(2)}</span>
          <span style="color:#222;font-size:10px">${ts(a.created_at)}</span>
        </div>
        <div style="color:#444;font-size:11px;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
          ${(a.content||'').substring(0,120)}
        </div>
      </div>`).join('');
}

// ================================================================
// QUEUE TAB
// ================================================================
async function loadQueue(){
  const d=await api('/api/learner/status');
  if(!d)return;
  const q=d.queue||{};
  document.getElementById('q-pending').textContent=fmt(q.pending);
  document.getElementById('q-done').textContent=fmt(q.done);
  document.getElementById('q-failed').textContent=fmt(q.failed);
  document.getElementById('q-running').textContent=fmt(q.running);
}
async function resetQueue(){
  const r=await post('/api/learner/queue/reset',{});
  document.getElementById('queue-msg').textContent=
    r?`Reset ${r.reset} stuck topics`:'Error';
  loadQueue();
}
async function fastBlast(){
  document.getElementById('queue-msg').innerHTML=
    '<span style="color:#00c853">⚡ Fast blast started — zero LLM calls, maximum speed. Watch queue drain in real time.</span>';
  await post('/api/recursive_learner/fast',{});
}
async function seedQueue(){
  document.getElementById('queue-msg').textContent='Seeding 2610 topics…';
  const r=await post('/api/recursive_learner/seed',{force:false});
  document.getElementById('queue-msg').textContent=
    r?`Seeded ${r.seeded} new entries`:'Error';
  loadQueue();
}
async function startLearner(){
  const r=await post('/api/learner/scheduler/start',{});
  document.getElementById('queue-msg').textContent=
    r?.status==='ok'?'Learner started':r?.status||'Error';
}

// ================================================================
// GENOME TAB
// ================================================================
async function loadGenome(){
  const q=document.getElementById('genome-search')?.value||'';
  const url=q?`/api/genome/manager/search?q=${encodeURIComponent(q)}&limit=50`
              :'/api/genome?limit=50';
  const data=await api(url);
  const rows=(data?.genomes||data?.results||[]);
  document.getElementById('genome-table').innerHTML=
    rows.map((g,i)=>`<tr>
      <td style="color:#333">${i+1}</td>
      <td style="color:#c8d0e0;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
          title="${g.description||''}">${g.name}</td>
      <td style="color:#555">${g.module_type||''}</td>
      <td style="color:#1e90ff">${g.priority||0}</td>
    </tr>`).join('');
}

// ================================================================
// EVOLUTION TAB
// ================================================================
async function loadEvolution(){
  const data=await api('/api/evolution/history');
  document.getElementById('evo-table').innerHTML=
    (data?.history||[]).map(e=>`<tr>
      <td style="color:#555;font-size:10px">${e.cycle||'—'}</td>
      <td>${e.modules_scanned||0}</td>
      <td style="color:#ff9800">${e.gaps_found||0}</td>
      <td style="color:#00c853">${e.gaps_filled||0}</td>
      <td style="color:#333;font-size:10px">${ts(e.completed_at)}</td>
    </tr>`).join('') ||
    '<tr><td colspan="5" style="color:#333;padding:20px">No evolution cycles yet</td></tr>';
}
async function triggerEvolution(){
  document.getElementById('evo-status').textContent='Starting…';
  const r=await post('/api/evolution/start',{});
  document.getElementById('evo-status').textContent=
    r?.status==='started'?'Running in background…':r?.error||'Error';
  setTimeout(loadEvolution,5000);
}

// ================================================================
// EXECUTOR TAB
// ================================================================
async function loadExecutor(){
  const data=await api('/api/executor/jobs?limit=30');
  document.getElementById('exec-table').innerHTML=
    (data?.jobs||[]).map(j=>{
      const hasDl=j.status==='done'&&j.export_path;
      const fp=j.export_path||'';
      const ext=fp?fp.split('.').pop():'py';
      // Detect APK from forge result or file extension
      const forgeType=(j.forge_result||{}).output_type||'';
      const isApkJob=ext==='apk'||forgeType==='apk';
      const dlHtml=hasDl
        ?`${isApkJob
            ? `<a class="dl-link dl-apk" href="/api/export/${j.job_id}?format=apk" download>↓ APK</a>`
            : `<a class="dl-link dl-${ext}" href="/api/export/${j.job_id}?format=${ext}" download>↓ ${ext.toUpperCase()}</a>`
          }
           <a class="dl-link dl-zip" href="/api/export/${j.job_id}?format=zip" download>↓ ZIP</a>`
        :'—';
      return `<tr>
        <td style="color:#333;font-size:10px">${(j.job_id||'').substring(0,8)}</td>
        <td style="color:#555">${j.task_type}</td>
        <td style="color:#888;max-width:150px;overflow:hidden;text-overflow:ellipsis">${j.label||'—'}</td>
        <td>${badge(j.status)}</td>
        <td style="color:#333;font-size:10px">${ts(j.submitted_at)}</td>
        <td>${dlHtml}</td>
      </tr>`;
    }).join('') ||
    '<tr><td colspan="6" style="color:#333;padding:20px">No jobs submitted yet</td></tr>';
}

async function submitTask(){
  const type=document.getElementById('ex-type').value;
  const param=document.getElementById('ex-param').value.trim();
  if(!param&&type!=='evolve'){alert('Enter a value');return}

  const params={};
  if(type==='shell')  params.command=param;
  if(type==='python') params.code=param;
  if(type==='forge')  {params.description=param;params.output_type='python_module'}
  if(type==='learn')  {params.topic=param;params.depth='Advanced'}

  document.getElementById('ex-status').textContent='Submitting…';
  const r=await post('/api/executor/submit',{task_type:type,params,label:param.substring(0,40)});
  document.getElementById('ex-status').innerHTML=
    r?.job_id
      ?`<span class="log-ok">Job ${r.job_id.substring(0,8)} queued</span>`
      :`<span class="log-err">${r?.error||'Error'}</span>`;
  setTimeout(loadExecutor,2000);
}

// ================================================================
// LIVE LOGS TAB
// ================================================================
let logLines=[];
async function loadLogs(){
  // Poll zeus.log tail via health + append simulated activity
  const h=await api('/api/health');
  const l=await api('/api/learner/status');
  const bs=await api('/api/blueprints/stats');

  const now=new Date().toLocaleTimeString();
  const newLines=[];
  if(h) newLines.push(`<span class="log-dim">[${now}]</span> <span class="log-ok">[✓]</span> Health OK — knowledge ${fmt(h.knowledge)} | genome ${fmt(h.genome_segments)} | modules ${h.modules_loaded}`);
  if(l?.queue) newLines.push(`<span class="log-dim">[${now}]</span> <span class="log-info">[→]</span> Queue: ${l.queue.pending} pending | ${l.queue.done} done | scheduler ${l.scheduler_running?'RUNNING':'STOPPED'}`);
  if(bs) newLines.push(`<span class="log-dim">[${now}]</span> <span class="log-info">[⚡]</span> Blueprints: ${bs.total} total | ${bs.done} done | ${bs.forging} forging`);

  logLines=newLines.concat(logLines).slice(0,200);
  const el=document.getElementById('live-log');
  if(el){
    el.innerHTML=logLines.join('\n');
    if(document.getElementById('log-autoscroll')?.checked)
      el.scrollTop=0;
  }
}

// ================================================================
// TAB REFRESH ROUTER
// ================================================================
function refreshTab(){
  if(activeTab==='chat')        loadChat();
  if(activeTab==='overview')   loadOverview();
  if(activeTab==='blueprints') loadBlueprints();
  if(activeTab==='knowledge')  loadKnowledge();
  if(activeTab==='queue')      loadQueue();
  if(activeTab==='genome')     loadGenome();
  if(activeTab==='evolution')  loadEvolution();
  if(activeTab==='executor')   loadExecutor();
  if(activeTab==='upload')     loadUploads();
  if(activeTab==='logs')       loadLogs();
}


// ================================================================
// CHAT TAB
// ================================================================
let chatHistory = [];

function msgBubble(role, text, meta){
  const isUser = role === 'user';
  const color  = isUser ? '#1e90ff22' : '#0d0d14';
  const border = isUser ? '#1e90ff33' : '#1a1a2e';
  const align  = isUser ? 'flex-end' : 'flex-start';
  const metaHtml = meta
    ? `<div style="font-size:9px;color:#333;margin-top:4px">${meta}</div>`
    : '';
  // Convert code blocks
  let html = text
    .replace(/```([\w]*)
?([\s\S]*?)```/g,
      '<pre style="background:#060608;border:1px solid #1a1a2e;padding:8px;border-radius:4px;overflow-x:auto;font-size:11px;margin:6px 0">$2</pre>')
    .replace(/
/g, '<br>');
  return `<div style="display:flex;justify-content:${align}">
    <div style="max-width:85%;background:${color};border:1px solid ${border};
         border-radius:6px;padding:10px 12px;font-size:12px;line-height:1.6">
      ${html}${metaHtml}
    </div>
  </div>`;
}

function scrollChat(){
  const el = document.getElementById('chat-messages');
  el.scrollTop = el.scrollHeight;
}

async function sendChat(){
  const input = document.getElementById('chat-input');
  const msg   = input.value.trim();
  if(!msg) return;
  input.value = '';

  // Add user bubble
  const el = document.getElementById('chat-messages');
  // Clear placeholder on first message
  if(el.innerHTML.includes('Zeus is listening'))
    el.innerHTML = '';
  el.innerHTML += msgBubble('user', msg);
  scrollChat();

  // Thinking indicator
  const thinkId = 'think-'+Date.now();
  el.innerHTML += `<div id="${thinkId}" style="color:#444;font-size:11px;padding:4px 8px">
    <span style="animation:pulse 1s infinite;display:inline-block">⚡ Zeus thinking…</span>
  </div>`;
  scrollChat();

  // Send to API
  chatHistory.push({role:'user', content:msg});
  const r = await post('/api/chat', {
    message:    msg,
    session_id: 'dashboard',
    history:    chatHistory.slice(-10),
  });

  // Remove thinking
  const th = document.getElementById(thinkId);
  if(th) th.remove();

  if(!r || r.error){
    el.innerHTML += msgBubble('assistant',
      r?.error || 'Connection error — check API keys');
    scrollChat();
    return;
  }

  chatHistory.push({role:'assistant', content:r.response});

  const meta = `${r.engine} · conf ${(r.confidence||0).toFixed(2)}`
    + (r.escalated ? ' · escalated' : '')
    + (r.context_used ? ' · DNA injected' : '');

  el.innerHTML += msgBubble('assistant', r.response, meta);
  scrollChat();

  // Update status bar
  document.getElementById('cs-engine').textContent    = 'engine: ' + (r.engine||'—');
  document.getElementById('cs-conf').textContent      = 'confidence: ' + (r.confidence||0).toFixed(2);
  document.getElementById('cs-escalated').textContent = r.escalated ? '↑ escalated' : '';
  document.getElementById('cs-ctx').textContent       = r.context_used ? '🧬 DNA used' : '';
}

async function clearChat(){
  chatHistory = [];
  document.getElementById('chat-messages').innerHTML =
    '<div style="color:#333;text-align:center;margin-top:160px;font-size:11px">Cleared. Ask anything.</div>';
  await post('/api/chat/clear', {});
}

async function loadChat(){
  // Load recent history from DB on tab open
  if(chatHistory.length > 0) return;
  const data = await api('/api/chat/history?limit=20');
  if(!data || !data.history || !data.history.length) return;
  const el = document.getElementById('chat-messages');
  el.innerHTML = '';
  const msgs = [...data.history].reverse();
  chatHistory = msgs.map(m=>({role:m.role, content:m.content}));
  for(const m of msgs){
    const meta = m.role==='assistant'
      ? `${m.engine||'?'} · conf ${(m.confidence||0).toFixed(2)}`
      : null;
    el.innerHTML += msgBubble(m.role, m.content, meta);
  }
  scrollChat();
}
// ================================================================
// UPLOAD TAB
// ================================================================
async function uploadFile(){
  const fileInput = document.getElementById('upload-file');
  const tagInput  = document.getElementById('upload-tag');
  const statusEl  = document.getElementById('upload-status');
  const barEl     = document.getElementById('upload-bar');
  const progEl    = document.getElementById('upload-progress');

  if(!fileInput.files || !fileInput.files[0]){
    statusEl.innerHTML='<span style="color:#f44336">Select a file first</span>';
    return;
  }

  const file = fileInput.files[0];
  const tag  = tagInput.value.trim();
  const fd   = new FormData();
  fd.append('file', file);
  if(tag) fd.append('tag', tag);

  progEl.style.display='block';
  barEl.style.width='10%';
  statusEl.innerHTML=`<span style="color:#1e90ff">⬆ Uploading ${file.name} (${(file.size/1024).toFixed(1)} KB)…</span>`;

  try{
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload');
    xhr.upload.onprogress = e=>{
      if(e.lengthComputable){
        barEl.style.width = Math.round((e.loaded/e.total)*80)+'%';
      }
    };
    xhr.onload = ()=>{
      barEl.style.width='100%';
      try{
        const r = JSON.parse(xhr.responseText);
        if(r.error){
          statusEl.innerHTML=`<span style="color:#f44336">Error: ${r.error}</span>`;
        } else {
          statusEl.innerHTML=
            `<span style="color:#00c853">✓ Uploaded: <strong>${r.filename||file.name}</strong></span>
             <span style="color:#555"> | category: ${r.category||'?'}</span>
             <span style="color:#555"> | genome segments: ${r.genome_segments||0}</span>
             <span style="color:#555"> | knowledge entries: ${r.knowledge_entries||0}</span>`;
          fileInput.value='';
          tagInput.value='';
          setTimeout(loadUploads, 1000);
        }
      }catch(e){
        statusEl.innerHTML=`<span style="color:#f44336">Parse error: ${e.message}</span>`;
      }
    };
    xhr.onerror = ()=>{
      statusEl.innerHTML='<span style="color:#f44336">Network error — check Flask is running</span>';
    };
    xhr.send(fd);
  }catch(e){
    statusEl.innerHTML=`<span style="color:#f44336">Upload failed: ${e.message}</span>`;
  }
}

async function loadUploads(){
  const data = await api('/api/upload/list?limit=30');
  if(!data) return;
  const rows = data.uploads || data.files || [];
  document.getElementById('upload-table').innerHTML =
    rows.length === 0
    ? '<tr><td colspan="7" style="color:#333;padding:20px">No uploads yet</td></tr>'
    : rows.map((u,i)=>`<tr>
        <td style="color:#333">${i+1}</td>
        <td style="color:#c8d0e0;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
            title="${u.filename||u.name||''}">${u.filename||u.name||'—'}</td>
        <td style="color:#555">${u.category||'—'}</td>
        <td style="color:#444">${u.size_kb?u.size_kb+'KB':(u.size?Math.round(u.size/1024)+'KB':'—')}</td>
        <td style="color:#1e90ff">${u.genome_segments||0}</td>
        <td>${badge(u.status||'done')}</td>
        <td style="color:#333;font-size:10px">${ts(u.created_at||u.uploaded_at||'')}</td>
      </tr>`).join('');
}

// ================================================================
// BOOT + AUTO-REFRESH
// ================================================================
refreshHeader();
loadOverview();
setInterval(()=>{refreshHeader();refreshTab()},10000);
</script>
</body>
</html>"""


@learning_bp.route("/learning")
def dashboard():
    return Response(DASHBOARD_HTML, mimetype="text/html")


@learning_bp.route("/api/dashboard/stats/quick")
def dashboard_stats_quick():
    """Quick stats endpoint (lightweight DB count only)."""
    try:
        from db_init import get_db
        conn      = get_db()
        knowledge = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
        genome    = conn.execute("SELECT COUNT(*) FROM genome").fetchone()[0]
        pending   = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='pending'"
        ).fetchone()[0]
        done      = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='done'"
        ).fetchone()[0]
        blueprints = 0
        try:
            blueprints = conn.execute(
                "SELECT COUNT(*) FROM blueprints"
            ).fetchone()[0]
        except Exception:
            pass
        conn.close()
        return jsonify({
            "knowledge":   knowledge,
            "genome":      genome,
            "blueprints":  blueprints,
            "queue":       {"pending": pending, "done": done},
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ============================================================================
# ADDITIONAL ROUTES — Health, Stats, Logic Engine Status
# ============================================================================

@learning_bp.route("/api/dashboard/health", methods=["GET"])
def dashboard_health():
    """Health check for the Zeus Learning Dashboard."""
    return jsonify({
        "status":  "ok",
        "module":  "zeus_learning_dashboard",
        "version": "2.1",
        "routes":  ["/learning", "/api/dashboard/health", "/api/dashboard/stats",
                    "/api/dashboard/stats/quick", "/api/dashboard/system_status",
                    "/api/dashboard/upload"],
    })


@learning_bp.route("/api/dashboard/stats", methods=["GET"])
def dashboard_stats():
    """Aggregate stats from all Zeus subsystems for the dashboard."""
    stats = {}

    # DB counts
    try:
        from db_init import get_db
        conn = get_db()
        stats["genome"]    = conn.execute("SELECT COUNT(*) FROM genome").fetchone()[0]
        stats["knowledge"] = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
        stats["queue_pending"] = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='pending'"
        ).fetchone()[0]
        stats["queue_done"] = conn.execute(
            "SELECT COUNT(*) FROM queue WHERE status='done'"
        ).fetchone()[0]
        stats["evolutions"] = conn.execute("SELECT COUNT(*) FROM evolution_log").fetchone()[0]
        conn.close()
    except Exception as e:
        stats["db_error"] = str(e)

    # Logic engine
    try:
        from logic_engine import get_engine
        engine = get_engine()
        stats["logic_rules"]   = len(engine._reasoner._rules)
        stats["logic_ready"]   = engine._ready
        stats["logic_sem_docs"] = len(engine._semantic_idx._docs)
    except Exception:
        stats["logic_ready"] = False

    # Mutator
    try:
        from zeus_mutator import get_engine as get_mutator
        ms = get_mutator().status()
        stats["mutator_pending"] = ms.get("pending", 0)
        stats["mutator_done"]    = ms.get("done", 0)
    except Exception:
        pass

    # LLM
    try:
        from zeus_llm_router import get_router
        avail = get_router().engine_availability()
        stats["llm_engines"] = {k: ("up" if v else "missing") for k, v in avail.items()}
    except Exception:
        pass

    # Learner
    try:
        from zeus_learner import get_learner_engine
        ls = get_learner_engine().stats()
        stats["learned_total"]    = ls.get("total_learned", 0)
        stats["learner_running"]  = ls.get("scheduler", False)
    except Exception:
        pass

    # Identity registry
    try:
        from zeus_identity import get_registry
        reg = get_registry()
        rs  = reg.stats()
        stats["modules_registered"]  = rs.get("total_modules", 0)
        stats["capabilities_total"]  = rs.get("total_capabilities", 0)
        stats["system_uptime_s"]     = rs.get("uptime_s", 0)
    except Exception:
        pass

    return jsonify({"stats": stats, "timestamp": __import__("datetime").datetime.utcnow().isoformat()})


@learning_bp.route("/api/dashboard/system_status", methods=["GET"])
def dashboard_system_status():
    """Full system status snapshot for the dashboard live view."""
    status = {"modules": {}, "timestamp": __import__("datetime").datetime.utcnow().isoformat()}

    module_checks = [
        ("logic_engine",  lambda: __import__("logic_engine").get_engine()._ready),
        ("genome",        lambda: bool(__import__("genome_manager").get_genome_engine().stats().get("total_segments"))),
        ("mutator",       lambda: "error" not in __import__("zeus_mutator").get_engine().status()),
        ("learner",       lambda: __import__("zeus_learner").get_learner_engine().stats()["scheduler"]),
        ("llm_router",    lambda: any(__import__("zeus_llm_router").get_router().engine_availability().values())),
        ("evolution",     lambda: not __import__("zeus_self_evolution")._running),
        ("scheduler",     lambda: __import__("zeus_nightly_scheduler").get_scheduler()._running),
    ]

    for mod_name, check_fn in module_checks:
        try:
            ok = check_fn()
            status["modules"][mod_name] = "ok" if ok else "degraded"
        except Exception as e:
            status["modules"][mod_name] = f"error: {str(e)[:50]}"

    healthy = sum(1 for v in status["modules"].values() if v == "ok")
    status["overall"] = "ok" if healthy >= len(module_checks) - 1 else "degraded"
    status["healthy_modules"] = healthy
    status["total_modules"]   = len(module_checks)

    return jsonify(status)


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    """Register the Zeus Learning Dashboard blueprint."""
    app.register_blueprint(learning_bp)
    log.info("[learning_dashboard] ✓ Registered at /learning + /api/dashboard")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_learning_dashboard",
            blueprint_var="learning_bp",
            url_prefix="/api/dashboard",
            version="2.1",
            description="Zeus v4.0 live dashboard: dark UI, tabs, live logs, blueprints, forge, upload, TTS, system status",
            capabilities=[
                {"id": "dashboard.ui",      "endpoint": "/learning",                   "method": "GET",  "tags": ["dashboard","ui"]},
                {"id": "dashboard.health",  "endpoint": "/api/dashboard/health",       "method": "GET",  "tags": ["health"]},
                {"id": "dashboard.stats",   "endpoint": "/api/dashboard/stats",        "method": "GET",  "tags": ["stats","dashboard"]},
                {"id": "dashboard.quick",   "endpoint": "/api/dashboard/stats/quick",  "method": "GET",  "tags": ["stats","dashboard"]},
                {"id": "dashboard.status",  "endpoint": "/api/dashboard/system_status","method": "GET",  "tags": ["dashboard","monitoring"]},
            ],
            depends_on=["logic_engine", "genome_manager", "zeus_learner", "zeus_llm_router", "zeus_upload"],
            boot_order=80,
        )
    except Exception:
        pass
