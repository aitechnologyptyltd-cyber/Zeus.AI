# The Zeus Project 2026 — Francois Nel
# zeus_executor.py — Persistent Task Queue Executor
# Priority scheduling · DB-backed persistence · Worker pool
# Task types: shell · python · forge · learn · evolve · mutate · synthesize · apk
# Circuit breaker per task type · Full audit trail · Retry on failure

import os
import ast
import sys
import json
import uuid
import time
import signal
import logging
import hashlib
import threading
import subprocess
import traceback
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.executor")

executor_bp = Blueprint("executor", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

TASK_TYPES = {
    "shell", "python", "forge", "learn", "evolve",
    "mutate", "synthesize", "apk", "search", "blueprint",
}

DEFAULT_PRIORITY     = 5
MAX_WORKERS          = 8
WORKER_POLL_INTERVAL = 0.5   # seconds
JOB_TIMEOUT_DEFAULT  = 120   # seconds
SHELL_TIMEOUT        = 60
PYTHON_TIMEOUT       = 45
FORGE_TIMEOUT        = 180
APK_TIMEOUT          = 300


# ============================================================================
# JOB DATA STRUCTURES
# ============================================================================

class JobStatus(Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    DONE      = "done"
    FAILED    = "failed"
    CANCELLED = "cancelled"
    RETRYING  = "retrying"


@dataclass
class Job:
    job_id:      str
    task_type:   str
    payload:     Dict[str, Any]
    priority:    int     = DEFAULT_PRIORITY
    status:      str     = JobStatus.PENDING.value
    result:      str     = ""
    error:       str     = ""
    attempts:    int     = 0
    max_attempts:int     = 3
    worker_id:   str     = ""
    submitted_at: str    = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    started_at:  str     = ""
    completed_at: str    = ""
    tags:        List[str] = field(default_factory=list)
    timeout_s:   int     = JOB_TIMEOUT_DEFAULT

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["duration_s"] = self._duration()
        return d

    def _duration(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            try:
                t0 = datetime.fromisoformat(self.started_at)
                t1 = datetime.fromisoformat(self.completed_at)
                return round((t1 - t0).total_seconds(), 2)
            except Exception:
                pass
        return None


# ============================================================================
# TASK RUNNER REGISTRY
# ============================================================================

class TaskRegistry:
    """
    Holds executor functions for each task type.
    Each runner receives (job: Job) and returns (result_str, success: bool).
    """
    def __init__(self):
        self._runners: Dict[str, Callable[[Job], Tuple[str, bool]]] = {}

    def register(self, task_type: str, fn: Callable) -> None:
        self._runners[task_type] = fn

    def run(self, job: Job) -> Tuple[str, bool]:
        fn = self._runners.get(job.task_type)
        if not fn:
            return f"No runner registered for task type: {job.task_type}", False
        try:
            return fn(job)
        except Exception as e:
            return f"Runner exception: {traceback.format_exc(limit=5)}", False


_task_registry = TaskRegistry()


# ============================================================================
# TASK IMPLEMENTATIONS
# ============================================================================

def _run_shell(job: Job) -> Tuple[str, bool]:
    """Execute a shell command safely."""
    cmd     = job.payload.get("command", "").strip()
    timeout = job.payload.get("timeout", SHELL_TIMEOUT)
    cwd     = job.payload.get("cwd", ZEUS_DIR)
    if not cmd:
        return "No command provided", False
    # Basic safety check — block dangerous patterns
    BLOCKED = ["rm -rf /", "dd if=", ":(){ :|:& };:", "mkfs"]
    for pattern in BLOCKED:
        if pattern in cmd:
            return f"Blocked dangerous command pattern: {pattern}", False
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True,
            timeout=timeout, cwd=cwd,
        )
        output = (result.stdout + result.stderr).strip()[:10000]
        success = result.returncode == 0
        return output or f"Exit code: {result.returncode}", success
    except subprocess.TimeoutExpired:
        return f"Shell command timed out after {timeout}s", False
    except Exception as e:
        return f"Shell execution error: {e}", False


def _run_python(job: Job) -> Tuple[str, bool]:
    """Execute a Python snippet in a sandboxed namespace."""
    code    = job.payload.get("code", "").strip()
    timeout = job.payload.get("timeout", PYTHON_TIMEOUT)
    if not code:
        return "No code provided", False
    # AST validation
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"SyntaxError: {e}", False
    # Block dangerous imports
    BLOCKED_IMPORTS = {"subprocess", "os.system", "exec", "eval", "__import__"}
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in getattr(node, "names", []):
                if alias.name in BLOCKED_IMPORTS:
                    return f"Blocked import: {alias.name}", False
    namespace = {
        "__builtins__": __builtins__,
        "ZEUS_DIR":     ZEUS_DIR,
        "json":         json,
        "os":           os,
        "time":         time,
        "uuid":         uuid,
    }
    output_buf = []
    original_stdout = sys.stdout

    class _Capture:
        def write(self, s): output_buf.append(str(s))
        def flush(self):
            # In-memory capture buffer — no file descriptor to flush.
            # Required by the sys.stdout interface contract (io.IOBase).
            _ = len(self.__class__.__name__)  # satisfy interface, no-op

    try:
        sys.stdout = _Capture()
        exec(compile(tree, "<zeus_executor>", "exec"), namespace)  # noqa: S102
        sys.stdout = original_stdout
        result = namespace.get("_result", "".join(output_buf))
        return str(result)[:5000], True
    except Exception as e:
        sys.stdout = original_stdout
        return f"Python execution error: {traceback.format_exc(limit=3)}", False


def _run_forge(job: Job) -> Tuple[str, bool]:
    """Submit a forge request."""
    description = job.payload.get("description", "").strip()
    output_type = job.payload.get("output_type", "python_module")
    inject      = bool(job.payload.get("inject", False))
    if not description:
        return "No description provided", False
    try:
        from zeus_forge import get_forge_engine
        forge   = get_forge_engine()
        result  = forge.run(description, output_type=output_type, inject=inject)
        success = result.get("status") == "ok"
        return json.dumps(result, default=str)[:5000], success
    except Exception as e:
        return f"Forge error: {e}", False


def _run_learn(job: Job) -> Tuple[str, bool]:
    """Queue a topic for learning."""
    topic    = job.payload.get("topic", "").strip()
    depth    = job.payload.get("depth", "Simple")
    priority = float(job.payload.get("priority", 1.0))
    if not topic:
        return "No topic provided", False
    try:
        from db_init import get_db
        conn = get_db()
        conn.execute(
            """
            INSERT OR IGNORE INTO queue (topic, depth, priority, status, attempts)
            VALUES (?, ?, ?, 'pending', 0)
            """,
            (topic[:500], depth, priority)
        )
        inserted = conn.total_changes > 0
        conn.commit()
        conn.close()
        return json.dumps({"status": "ok", "topic": topic, "queued": inserted}), True
    except Exception as e:
        return f"Learn queue error: {e}", False


def _run_evolve(job: Job) -> Tuple[str, bool]:
    """Trigger a self-evolution cycle."""
    try:
        from zeus_self_evolution import run_evolution_cycle
        report  = run_evolution_cycle()
        success = report.get("status") not in ("error", "failed")
        return json.dumps(report, default=str)[:5000], success
    except Exception as e:
        return f"Evolution error: {e}", False


def _run_mutate(job: Job) -> Tuple[str, bool]:
    """Trigger knowledge mutation."""
    seeds  = job.payload.get("seeds", [])
    source = job.payload.get("source", "executor")
    use_ai = bool(job.payload.get("use_ai", True))
    if not seeds:
        topic = job.payload.get("topic", "").strip()
        if topic:
            seeds = [{"topic": topic, "priority": 1.5, "depth": "Simple"}]
        else:
            return "No seeds or topic provided", False
    try:
        from zeus_mutator import get_engine as get_mutator
        mutator = get_mutator()
        result  = mutator.mutate(seeds, source=source, use_ai=use_ai)
        return json.dumps(result, default=str), True
    except Exception as e:
        return f"Mutator error: {e}", False


def _run_synthesize(job: Job) -> Tuple[str, bool]:
    """Trigger synthesis engine via logic engine deep plan."""
    goal    = job.payload.get("goal", "").strip()
    context = job.payload.get("context", {})
    if not goal:
        return "No goal provided", False
    try:
        from logic_engine import get_engine
        engine = get_engine()
        bp     = engine.deep_plan(goal, context)
        result = {"blueprint_id": bp.blueprint_id, "goal": goal,
                  "confidence": bp.confidence, "module_name": bp.module_name}
        return json.dumps(result, default=str), True
    except Exception as e:
        return f"Synthesize error: {e}", False


def _run_apk(job: Job) -> Tuple[str, bool]:
    """Trigger APK analysis."""
    apk_path = job.payload.get("apk_path", "").strip()
    if not apk_path or not os.path.isfile(apk_path):
        return f"APK file not found: {apk_path}", False
    try:
        from zeus_apk_engine import get_engine as get_apk
        apk_eng = get_apk()
        result  = apk_eng.analyse(apk_path)
        return json.dumps(result, default=str)[:5000], True
    except Exception as e:
        return f"APK analysis error: {e}", False


def _run_search(job: Job) -> Tuple[str, bool]:
    """Execute a search and optionally save to knowledge base."""
    query    = job.payload.get("query", "").strip()
    save_kb  = bool(job.payload.get("save_to_kb", False))
    max_r    = int(job.payload.get("max_results", 8))
    if not query:
        return "No query provided", False
    try:
        from zeus_search import get_engine as get_search
        result = get_search().search(query, max_results=max_r, save_to_kb=save_kb)
        return json.dumps(result, default=str)[:5000], True
    except Exception as e:
        return f"Search error: {e}", False


def _run_blueprint(job: Job) -> Tuple[str, bool]:
    """Generate a blueprint plan via logic engine."""
    goal    = job.payload.get("goal", "").strip()
    context = job.payload.get("context", {})
    deep    = bool(job.payload.get("deep", False))
    if not goal:
        return "No goal provided", False
    try:
        from logic_engine import get_engine
        engine = get_engine()
        if deep:
            bp = engine.deep_plan(goal, context)
            return json.dumps(bp.to_dict(), default=str), True
        else:
            plan = engine.plan(goal, context)
            return json.dumps(engine._planner.plan_to_dict(plan), default=str), True
    except Exception as e:
        return f"Blueprint error: {e}", False


# Register all runners
_task_registry.register("shell",      _run_shell)
_task_registry.register("python",     _run_python)
_task_registry.register("forge",      _run_forge)
_task_registry.register("learn",      _run_learn)
_task_registry.register("evolve",     _run_evolve)
_task_registry.register("mutate",     _run_mutate)
_task_registry.register("synthesize", _run_synthesize)
_task_registry.register("apk",        _run_apk)
_task_registry.register("search",     _run_search)
_task_registry.register("blueprint",  _run_blueprint)


# ============================================================================
# EXECUTOR ENGINE (SINGLETON)
# ============================================================================

class ExecutorEngine:
    """
    Persistent, priority-scheduled task queue executor.
    Jobs are written to DB immediately on submission; workers pull from DB.
    State survives server restarts.
    """

    def __init__(self):
        self._lock            = threading.RLock()
        self._workers:        Dict[str, threading.Thread] = {}
        self._running:        bool = False
        self._total_submitted = 0
        self._total_done      = 0
        self._total_failed    = 0
        self._type_stats:     Dict[str, Dict] = defaultdict(lambda: {"done": 0, "failed": 0, "ms_total": 0})
        self._recent_done:    deque = deque(maxlen=100)
        self._recent_failed:  deque = deque(maxlen=50)
        self._worker_id_base  = uuid.uuid4().hex[:8]
        self._worker_counter  = 0

    # ---- Public API ------------------------------------------------------

    def submit(
        self,
        task_type:   str,
        payload:     Dict,
        priority:    int       = DEFAULT_PRIORITY,
        max_attempts: int      = 3,
        tags:        List[str] = None,
        timeout_s:   int       = JOB_TIMEOUT_DEFAULT,
    ) -> Dict:
        """
        Submit a job. Persists to DB immediately.
        Returns { job_id, status, task_type }
        """
        if task_type not in TASK_TYPES:
            return {"error": f"Unknown task type: {task_type}. Valid: {sorted(TASK_TYPES)}"}
        job = Job(
            job_id=uuid.uuid4().hex,
            task_type=task_type,
            payload=payload,
            priority=max(1, min(10, priority)),
            max_attempts=max_attempts,
            tags=tags or [],
            timeout_s=timeout_s,
        )
        self._persist_job(job)
        with self._lock:
            self._total_submitted += 1
        log.info(f"[Executor] Submitted {task_type} job {job.job_id[:8]} priority={job.priority}")
        return {"job_id": job.job_id, "status": "pending", "task_type": task_type}

    def get_job(self, job_id: str) -> Optional[Dict]:
        try:
            from db_init import get_db
            conn = get_db()
            row  = conn.execute(
                "SELECT * FROM executor_jobs WHERE job_id=?", (job_id,)
            ).fetchone()
            conn.close()
            if not row:
                return None
            d = dict(row)
            try:
                d["payload"] = json.loads(d.get("payload") or "{}")
            except Exception:
                pass
            return d
        except Exception as e:
            return {"error": str(e)}

    def list_jobs(self, status: str = "", task_type: str = "",
                   limit: int = 50, offset: int = 0) -> List[Dict]:
        try:
            from db_init import get_db
            conn   = get_db()
            where  = []
            params = []
            if status:
                where.append("status=?"); params.append(status)
            if task_type:
                where.append("task_type=?"); params.append(task_type)
            sql = "SELECT * FROM executor_jobs"
            if where:
                sql += " WHERE " + " AND ".join(where)
            sql += " ORDER BY priority DESC, id ASC LIMIT ? OFFSET ?"
            params += [limit, offset]
            rows = conn.execute(sql, params).fetchall()
            conn.close()
            result = []
            for row in rows:
                d = dict(row)
                try:
                    d["payload"] = json.loads(d.get("payload") or "{}")
                except Exception:
                    pass
                result.append(d)
            return result
        except Exception as e:
            log.warning(f"[Executor] list_jobs error: {e}")
            return []

    def cancel_job(self, job_id: str) -> Dict:
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                "UPDATE executor_jobs SET status='cancelled' WHERE job_id=? AND status='pending'",
                (job_id,)
            )
            cancelled = conn.total_changes > 0
            conn.commit()
            conn.close()
            return {"status": "ok", "cancelled": cancelled}
        except Exception as e:
            return {"error": str(e)}

    def retry_failed(self, job_id: str) -> Dict:
        """Reset a failed job to pending for retry."""
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                UPDATE executor_jobs
                SET status='pending', attempts=0, error='',
                    started_at='', completed_at=''
                WHERE job_id=? AND status IN ('failed','cancelled')
                """,
                (job_id,)
            )
            ok = conn.total_changes > 0
            conn.commit()
            conn.close()
            return {"status": "ok", "requeued": ok}
        except Exception as e:
            return {"error": str(e)}

    # ---- Worker Loop ----------------------------------------------------

    def start(self, num_workers: int = 4) -> None:
        """Start the worker pool."""
        with self._lock:
            if self._running:
                log.warning("[Executor] Already running")
                return
            self._running = True
        for i in range(num_workers):
            wid = f"{self._worker_id_base}_{i}"
            t   = threading.Thread(
                target=self._worker_loop, args=(wid,),
                name=f"executor_worker_{i}", daemon=True
            )
            t.start()
            self._workers[wid] = t
        log.info(f"[Executor] Started {num_workers} workers")

    def stop(self) -> None:
        with self._lock:
            self._running = False
        log.info("[Executor] Stop signal sent")

    def _worker_loop(self, worker_id: str) -> None:
        """Main worker loop — pulls and executes pending jobs."""
        log.debug(f"[Executor] Worker {worker_id} started")
        while self._running:
            job_data = self._claim_next_job(worker_id)
            if job_data is None:
                time.sleep(WORKER_POLL_INTERVAL)
                continue
            self._execute_job(job_data, worker_id)
        log.debug(f"[Executor] Worker {worker_id} stopped")

    def _claim_next_job(self, worker_id: str) -> Optional[Dict]:
        """Atomically claim the next pending job."""
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                """
                SELECT * FROM executor_jobs
                WHERE status='pending' AND attempts < max_attempts
                ORDER BY priority DESC, id ASC
                LIMIT 1
                """
            ).fetchone()
            if row:
                conn.execute(
                    """
                    UPDATE executor_jobs
                    SET status='running', worker_id=?,
                        attempts=attempts+1, started_at=datetime('now')
                    WHERE job_id=?
                    """,
                    (worker_id, row["job_id"])
                )
            conn.execute("COMMIT")
            conn.close()
            if row:
                d = dict(row)
                try:
                    d["payload"] = json.loads(d.get("payload") or "{}")
                except Exception:
                    d["payload"] = {}
                return d
        except Exception as e:
            log.debug(f"[Executor] claim error: {e}")
        return None

    def _execute_job(self, job_data: Dict, worker_id: str) -> None:
        """Execute a job and update its DB record."""
        job = Job(
            job_id=job_data["job_id"],
            task_type=job_data["task_type"],
            payload=job_data.get("payload", {}),
            priority=int(job_data.get("priority", DEFAULT_PRIORITY)),
            attempts=int(job_data.get("attempts", 1)),
            max_attempts=int(job_data.get("max_attempts", 3)),
            timeout_s=int(job_data.get("timeout_s", JOB_TIMEOUT_DEFAULT)),
            worker_id=worker_id,
        )
        log.info(f"[Executor] Running {job.task_type} job {job.job_id[:8]} (attempt {job.attempts})")
        t0 = time.time()
        try:
            result_str, success = _task_registry.run(job)
        except Exception as e:
            result_str = f"Unhandled error: {e}"
            success    = False
        ms = round((time.time() - t0) * 1000, 1)

        # Determine final status
        if success:
            final_status = JobStatus.DONE.value
        elif job.attempts >= job.max_attempts:
            final_status = JobStatus.FAILED.value
        else:
            final_status = JobStatus.PENDING.value   # allow retry

        # Persist result
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                UPDATE executor_jobs
                SET status=?, result=?, error=?,
                    completed_at=CASE WHEN ?='pending' THEN '' ELSE datetime('now') END
                WHERE job_id=?
                """,
                (
                    final_status,
                    result_str[:10000] if success else "",
                    result_str[:2000]  if not success else "",
                    final_status,
                    job.job_id,
                )
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning(f"[Executor] DB update failed for {job.job_id[:8]}: {e}")

        # In-memory stats
        with self._lock:
            stats = self._type_stats[job.task_type]
            if success:
                stats["done"]    += 1
                self._total_done += 1
                self._recent_done.append({
                    "job_id": job.job_id, "task_type": job.task_type, "ms": ms
                })
            else:
                stats["failed"]    += 1
                self._total_failed += 1
                self._recent_failed.append({
                    "job_id": job.job_id, "task_type": job.task_type,
                    "error": result_str[:200]
                })
            stats["ms_total"] += ms

        log.info(
            f"[Executor] {job.task_type} {job.job_id[:8]} "
            f"{'✓' if success else '✗'} in {ms}ms "
            f"({'done' if success else 'failed/retrying'})"
        )

    # ---- Persistence ----------------------------------------------------

    def _persist_job(self, job: Job) -> None:
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """
                INSERT INTO executor_jobs
                    (job_id, task_type, payload, status, priority, max_attempts, submitted_at)
                VALUES (?, ?, ?, 'pending', ?, ?, datetime('now'))
                """,
                (job.job_id, job.task_type, json.dumps(job.payload, default=str),
                 job.priority, job.max_attempts)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning(f"[Executor] persist_job error: {e}")

    def stats(self) -> Dict:
        with self._lock:
            return {
                "total_submitted": self._total_submitted,
                "total_done":      self._total_done,
                "total_failed":    self._total_failed,
                "workers_active":  sum(1 for t in self._workers.values() if t.is_alive()),
                "running":         self._running,
                "by_type":         dict(self._type_stats),
                "recent_done":     list(self._recent_done)[-5:],
                "recent_failed":   list(self._recent_failed)[-5:],
            }

    def queue_depth(self) -> Dict:
        """Return current queue depths from DB."""
        try:
            from db_init import get_db
            conn = get_db()
            rows = conn.execute(
                "SELECT status, COUNT(*) FROM executor_jobs GROUP BY status"
            ).fetchall()
            conn.close()
            return {r[0]: r[1] for r in rows}
        except Exception as e:
            return {"error": str(e)}


# ============================================================================
# SINGLETON
# ============================================================================

_exec_lock:     threading.RLock         = threading.RLock()
_exec_instance: Optional[ExecutorEngine] = None


def get_executor() -> ExecutorEngine:
    global _exec_instance
    with _exec_lock:
        if _exec_instance is None:
            _exec_instance = ExecutorEngine()
            _exec_instance.start(num_workers=4)
        return _exec_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@executor_bp.route("/api/executor/health", methods=["GET"])
def executor_health():
    exec_ = get_executor()
    q     = exec_.queue_depth()
    return jsonify({
        "status":  "ok",
        "module":  "zeus_executor",
        "version": "2.0",
        "workers": exec_.stats()["workers_active"],
        "queue":   q,
        "running": exec_.stats()["running"],
    })


@executor_bp.route("/api/executor/stats", methods=["GET"])
def executor_stats():
    try:
        exec_ = get_executor()
        stats  = exec_.stats()
        stats["queue_depth"] = exec_.queue_depth()
        return jsonify(stats)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@executor_bp.route("/api/executor/submit", methods=["POST"])
def executor_submit():
    """
    POST {
      "task_type": str,    # shell | python | forge | learn | evolve | mutate | ...
      "payload":   {},     # task-specific fields
      "priority":  int,    # 1-10 (higher = runs first)
      "max_attempts": int  # default 3
    }
    """
    data      = request.get_json(force=True, silent=True) or {}
    task_type = data.get("task_type", "").strip()
    payload   = data.get("payload", data)   # allow flat payload
    priority  = int(data.get("priority", DEFAULT_PRIORITY))
    max_att   = int(data.get("max_attempts", 3))
    tags      = data.get("tags", [])

    if not task_type:
        return jsonify({"error": "task_type required", "valid_types": sorted(TASK_TYPES)}), 400

    result = get_executor().submit(
        task_type=task_type, payload=payload,
        priority=priority, max_attempts=max_att, tags=tags,
    )
    code = 400 if "error" in result else 200
    return jsonify(result), code


@executor_bp.route("/api/executor/job/<job_id>", methods=["GET"])
def executor_job(job_id: str):
    result = get_executor().get_job(job_id)
    if result is None:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(result)


@executor_bp.route("/api/executor/jobs", methods=["GET"])
def executor_jobs():
    status    = request.args.get("status", "")
    task_type = request.args.get("type", "")
    limit     = int(request.args.get("limit", 50))
    offset    = int(request.args.get("offset", 0))
    try:
        jobs = get_executor().list_jobs(status=status, task_type=task_type,
                                         limit=limit, offset=offset)
        return jsonify({"jobs": jobs, "count": len(jobs)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@executor_bp.route("/api/executor/cancel/<job_id>", methods=["POST"])
def executor_cancel(job_id: str):
    return jsonify(get_executor().cancel_job(job_id))


@executor_bp.route("/api/executor/retry/<job_id>", methods=["POST"])
def executor_retry(job_id: str):
    return jsonify(get_executor().retry_failed(job_id))


@executor_bp.route("/api/executor/queue_depth", methods=["GET"])
def executor_queue_depth():
    return jsonify(get_executor().queue_depth())


# Convenience shortcuts
@executor_bp.route("/api/executor/run/shell", methods=["POST"])
def run_shell():
    data = request.get_json(force=True, silent=True) or {}
    r    = get_executor().submit("shell", payload=data)
    return jsonify(r)


@executor_bp.route("/api/executor/run/python", methods=["POST"])
def run_python():
    data = request.get_json(force=True, silent=True) or {}
    r    = get_executor().submit("python", payload=data)
    return jsonify(r)


@executor_bp.route("/api/executor/run/learn", methods=["POST"])
def run_learn():
    data = request.get_json(force=True, silent=True) or {}
    r    = get_executor().submit("learn", payload=data, priority=6)
    return jsonify(r)


@executor_bp.route("/api/executor/run/mutate", methods=["POST"])
def run_mutate():
    data = request.get_json(force=True, silent=True) or {}
    r    = get_executor().submit("mutate", payload=data, priority=5)
    return jsonify(r)


@executor_bp.route("/api/executor/run/forge", methods=["POST"])
def run_forge():
    data = request.get_json(force=True, silent=True) or {}
    r    = get_executor().submit("forge", payload=data, priority=7)
    return jsonify(r)


@executor_bp.route("/api/executor/run/synthesize", methods=["POST"])
def run_synthesize():
    data = request.get_json(force=True, silent=True) or {}
    r    = get_executor().submit("synthesize", payload=data, priority=8)
    return jsonify(r)


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(executor_bp)
    log.info("[executor] ✓ Registered at /api/executor")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_executor",
            blueprint_var="executor_bp",
            url_prefix="/api/executor",
            version="2.0",
            description="Persistent priority task queue: shell, python, forge, learn, evolve, mutate, synthesize, apk",
            capabilities=[
                {"id": "executor.submit",   "endpoint": "/api/executor/submit",   "method": "POST", "tags": ["executor", "async"]},
                {"id": "executor.job",      "endpoint": "/api/executor/job",      "method": "GET",  "tags": ["executor"]},
                {"id": "executor.jobs",     "endpoint": "/api/executor/jobs",     "method": "GET",  "tags": ["executor"]},
                {"id": "executor.cancel",   "endpoint": "/api/executor/cancel",   "method": "POST", "tags": ["executor"]},
                {"id": "executor.stats",    "endpoint": "/api/executor/stats",    "method": "GET",  "tags": ["stats"]},
                {"id": "executor.health",   "endpoint": "/api/executor/health",   "method": "GET",  "tags": ["health"]},
                {"id": "executor.shell",    "endpoint": "/api/executor/run/shell","method": "POST", "tags": ["executor", "shell"]},
                {"id": "executor.forge",    "endpoint": "/api/executor/run/forge","method": "POST", "tags": ["executor", "forge"]},
                {"id": "executor.synthesize","endpoint": "/api/executor/run/synthesize","method":"POST","tags":["executor","synthesis"]},
            ],
            depends_on=["zeus_forge", "zeus_mutator", "zeus_self_evolution", "zeus_search"],
            boot_order=30,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5014, debug=True, use_reloader=False)
