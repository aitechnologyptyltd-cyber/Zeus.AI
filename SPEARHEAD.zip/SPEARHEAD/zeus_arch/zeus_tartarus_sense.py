"""
zeus_tartarus_sense.py
The Zeus Project 2026 — Francois Nel

TARTARUS PHASE 1 — SENSE
Deep mathematical extraction engine.

Given any phenomenon, query or concept, SENSE extracts:
  - Governing equations (with genius attribution, formula, depth rating)
  - Cross-domain mathematical connections
  - Pattern signatures
  - Probabilistic predictions
  - A single Tartarus insight (synthesised judgment)

All results are pushed into TartarusMemory.pool and also:
  - equations    → feed zeus_prediction_engine domain weighting
  - patterns     → feed zeus_code_learner pattern registry
  - predictions  → feed zeus_prediction_engine prediction store
  - connections  → feed logic_engine inference graph
  - weights      → feed zeus_tartarus_weights dashboard

Flask blueprint: sense_bp at /api/tartarus/sense/*

Fixes vs JSX Phase1:
  - LLM errors surface as structured error response (not silent)
  - Weight computation stored in pool.weights (not just returned)
  - All results persisted to zeus.db via TartarusMemory
  - Downstream wiring to Zeus subsystems added

armv7l compatible: no f-strings, no walrus operator.
"""

from __future__ import print_function

import os
import sys
import json
import time
import logging
import threading
import traceback
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.tartarus.sense")

sense_bp = Blueprint("tartarus_sense", __name__)

EXAMPLES = [
    "A criminal's decision",
    "Hurricane formation",
    "Stock market crash",
    "Human heartbeat",
    "A viral social post",
    "Traffic jam",
    "A burning star",
    "Sleep cycles",
    "DNA replication",
    "Quantum entanglement",
    "Bitcoin price movement",
    "Neural network convergence",
    "Ecosystem collapse",
    "Language evolution",
    "Supply chain disruption",
]

SENSE_SCHEMA = json.dumps({
    "title": "string",
    "essence": "string",
    "domains": ["string"],
    "equations": [
        {
            "name": "string",
            "genius": "string",
            "formula": "string",
            "application": "string",
            "depth": "surface|deep|profound",
        }
    ],
    "crossDomainConnections": [
        {
            "phenomenon": "string",
            "sharedMath": "string",
            "insight": "string",
        }
    ],
    "patterns": [
        {
            "pattern": "string",
            "description": "string",
            "mathematical_basis": "string",
        }
    ],
    "predictions": [
        {
            "outcome": "string",
            "confidence": 0.8,
            "basis": "string",
            "timeframe": "string",
        }
    ],
    "tartarusInsight": "string",
})


def _wire_to_zeus(result, query):
    """Push Sense results into live Zeus subsystems."""
    # 1. Feed equations into prediction engine domain knowledge
    try:
        from zeus_prediction_engine import get_engine
        eng = get_engine()
        for eq in (result.get("equations") or []):
            if hasattr(eng, "inject_domain_knowledge"):
                eng.inject_domain_knowledge({
                    "source": "tartarus_sense",
                    "query": query,
                    "equation": eq,
                    "ts": time.time(),
                })
    except Exception:
        pass

    # 2. Feed patterns into code learner registry
    try:
        from zeus_code_learner import get_learner
        learner = get_learner()
        for pat in (result.get("patterns") or []):
            if hasattr(learner, "ingest_pattern"):
                learner.ingest_pattern({
                    "source": "tartarus_sense",
                    "query": query,
                    "pattern": pat,
                    "ts": time.time(),
                })
    except Exception:
        pass

    # 3. Feed predictions into prediction store
    try:
        from zeus_prediction_engine import get_engine
        eng = get_engine()
        for pred in (result.get("predictions") or []):
            if hasattr(eng, "store_external_prediction"):
                eng.store_external_prediction({
                    "source": "tartarus_sense",
                    "query": query,
                    "prediction": pred,
                    "ts": time.time(),
                })
    except Exception:
        pass

    # 4. Feed connections into logic engine
    try:
        from logic_engine import get_engine as get_logic
        le = get_logic()
        for conn in (result.get("crossDomainConnections") or []):
            if hasattr(le, "add_inference"):
                le.add_inference(
                    premise=query,
                    conclusion=conn.get("phenomenon", ""),
                    rule=conn.get("sharedMath", ""),
                    confidence=0.7,
                )
    except Exception:
        pass


def run_sense(query, context=""):
    """
    Execute Phase 1 SENSE analysis.
    Returns full result dict. All side-effects handled internally.
    """
    from zeus_tartarus_core import TartarusMemory, tartarus_call, compute_weights

    mem = TartarusMemory.get()
    mem.set_phase("p1", "active")
    mem.broadcast("sense", "SENSING", query)

    prompt = (
        "PHASE 1 SENSE: Perform the deepest possible mathematical extraction "
        "on the following phenomenon or concept: \"" + query + "\". "
        "Extract ALL governing equations with their originators, ALL "
        "cross-domain mathematical connections, ALL structural patterns, "
        "and generate high-confidence predictions. Think across physics, "
        "biology, economics, information theory, chaos theory, game theory, "
        "topology, and every other relevant domain simultaneously."
    )

    result = tartarus_call(
        prompt,
        schema_hint=SENSE_SCHEMA,
        context=context,
        max_tokens=2000,
    )

    if "error" in result:
        mem.set_phase("p1", "error")
        mem.broadcast("sense", "ERROR", result["error"])
        return result

    # Push to pool
    mem.push("inputs", query, source="sense")
    mem.push_many("equations",
                  result.get("equations") or [],
                  source="sense")
    mem.push_many("patterns",
                  result.get("patterns") or [],
                  source="sense")
    mem.push_many("predictions",
                  result.get("predictions") or [],
                  source="sense")
    mem.push_many("connections",
                  result.get("crossDomainConnections") or [],
                  source="sense")
    if result.get("tartarusInsight"):
        mem.push("insights", result["tartarusInsight"], source="sense")

    # Compute and store weights (fixes JSX: weights now persisted)
    weights = compute_weights(result, source="direct")
    weights["label"] = query
    mem.push("weights", weights, source="sense")

    mem.set_phase("p1", "done")
    mem.broadcast(
        "sense",
        "SENSE_COMPLETE",
        str(len(result.get("equations") or [])) + " equations | TartarusScore: " +
        str(int(weights["tartarusScore"] * 100)) + "%"
    )

    # Save session
    mem.save_session(
        query, "p1_sense", result,
        engine=result.get("_engine", "")
    )

    # Wire into Zeus subsystems
    t = threading.Thread(
        target=_wire_to_zeus,
        args=(result, query),
        daemon=True
    )
    t.start()

    return result


# ---------------------------------------------------------------------------
# FLASK ROUTES
# ---------------------------------------------------------------------------

@sense_bp.route("/api/tartarus/sense", methods=["POST"])
def sense_route():
    data = request.get_json(silent=True) or {}
    query = (data.get("query") or "").strip()
    if not query:
        return jsonify({"error": "query required"}), 400

    from zeus_tartarus_core import TartarusMemory
    context = TartarusMemory.get().build_context()
    result = run_sense(query, context=context)

    if "error" in result:
        return jsonify(result), 500
    return jsonify(result)


@sense_bp.route("/api/tartarus/sense/examples", methods=["GET"])
def sense_examples():
    return jsonify({"examples": EXAMPLES})


@sense_bp.route("/api/tartarus/sense/history", methods=["GET"])
def sense_history():
    from zeus_tartarus_core import TartarusMemory
    mem = TartarusMemory.get()
    limit = int(request.args.get("limit", 20))
    return jsonify({
        "inputs":    mem.get_field("inputs",    limit),
        "equations": mem.get_field("equations", limit),
        "patterns":  mem.get_field("patterns",  limit),
        "insights":  mem.get_field("insights",  limit),
        "ts": time.time(),
    })


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register(app):
    app.register_blueprint(sense_bp)
    log.info("[tartarus_sense] registered — /api/tartarus/sense")
