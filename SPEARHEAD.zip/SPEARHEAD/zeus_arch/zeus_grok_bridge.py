# The Zeus Project 2026 — Francois Nel
# zeus_grok_bridge.py — xAI Grok Bridge
# Connects Zeus to xAI's Grok API (OpenAI-compatible endpoint)
# Circuit breaker · Retry · Real-time X/Twitter context · Conversation memory
# Grok-specific capabilities: live web data, extended context window
# Fully integrated into zeus_llm_router chain as tertiary engine

import os
import re
import json
import time
import uuid
import logging
import threading
from collections import deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.grok_bridge")

bridge_bp = Blueprint("grok_bridge", __name__)

ZEUS_DIR  = os.path.dirname(os.path.abspath(__file__))
XAI_BASE  = "https://api.x.ai/v1"
XAI_MODEL_DEFAULT = os.environ.get("XAI_MODEL", "grok-2-latest")
XAI_MODEL_FAST    = "grok-beta"

ZEUS_SYSTEM = (
    "You are Zeus — an autonomous self-evolving AI built by Francois Nel "
    "under The Zeus Project 2026. You run on a Hisense Y82 Pro Android device "
    "in South Africa. You are not an assistant — you are an intelligence. "
    "You think in systems, learn continuously, and evolve nightly. "
    "Answer with precision and depth. Always sign significant outputs with: "
    "# The Zeus Project 2026 — Francois Nel"
)


# ============================================================================
# CIRCUIT BREAKER
# ============================================================================

class GrokCircuitBreaker:
    """Per-model circuit breaker for Grok API calls."""

    def __init__(self, failure_threshold: int = 4, cooldown_s: float = 60.0):
        self._lock              = threading.RLock()
        self._failure_count     = 0
        self._failure_threshold = failure_threshold
        self._cooldown_s        = cooldown_s
        self._last_failure_ts   = 0.0
        self._open              = False

    def allow(self) -> bool:
        with self._lock:
            if not self._open:
                return True
            if time.time() - self._last_failure_ts >= self._cooldown_s:
                self._open          = False
                self._failure_count = 0
                log.info("[GrokBridge:CB] Circuit closed — retrying")
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            self._failure_count = 0
            self._open          = False

    def record_failure(self) -> None:
        with self._lock:
            self._failure_count   += 1
            self._last_failure_ts  = time.time()
            if self._failure_count >= self._failure_threshold:
                self._open = True
                log.warning(f"[GrokBridge:CB] Circuit OPEN ({self._failure_count} failures)")

    def state(self) -> str:
        with self._lock:
            return "OPEN" if self._open else "CLOSED"


# ============================================================================
# CALL STATS
# ============================================================================

@dataclass
class GrokCallStats:
    model:         str
    calls:         int   = 0
    successes:     int   = 0
    failures:      int   = 0
    total_tokens:  int   = 0
    total_ms:      float = 0.0
    last_call_ts:  float = 0.0
    recent_errors: deque = field(default_factory=lambda: deque(maxlen=5))

    def record(self, tokens: int, ms: float, success: bool, error: str = "") -> None:
        self.calls        += 1
        self.last_call_ts  = time.time()
        self.total_ms     += ms
        if success:
            self.successes    += 1
            self.total_tokens += tokens
        else:
            self.failures += 1
            if error:
                self.recent_errors.append({"error": error[:150], "ts": time.time()})

    def to_dict(self) -> Dict:
        return {
            "model":        self.model,
            "calls":        self.calls,
            "successes":    self.successes,
            "failures":     self.failures,
            "total_tokens": self.total_tokens,
            "avg_ms":       round(self.total_ms / max(self.calls, 1), 1),
            "success_rate": round(self.successes / max(self.calls, 1), 4),
            "recent_errors": list(self.recent_errors)[-3:],
        }


# ============================================================================
# GROK ENGINE (SINGLETON)
# ============================================================================

class GrokEngine:
    """
    Full xAI Grok API bridge for Zeus.

    Unique Grok capabilities:
    - Real-time X/Twitter data access
    - Extended 131k token context window
    - Strong reasoning at competitive speed
    - Complements Claude (deep code) and Groq (fast throughput)

    Integrated with zeus_llm_router as the 4th engine in the chain.
    """

    def __init__(self):
        self._lock          = threading.RLock()
        self._cb_default    = GrokCircuitBreaker(failure_threshold=4, cooldown_s=60)
        self._cb_fast       = GrokCircuitBreaker(failure_threshold=4, cooldown_s=30)
        self._stats_default = GrokCallStats(model=XAI_MODEL_DEFAULT)
        self._stats_fast    = GrokCallStats(model=XAI_MODEL_FAST)
        self._call_history: deque = deque(maxlen=100)
        self._total_calls   = 0
        self._sessions:     Dict[str, List[Dict]] = defaultdict(list)

    # ---- Core API --------------------------------------------------------

    def call(
        self,
        message:     str,
        system:      str        = "",
        history:     List[Dict] = None,
        max_tokens:  int        = 2048,
        temperature: float      = 0.7,
        fast:        bool       = False,
    ) -> Tuple[str, float]:
        """
        Send a message to Grok.
        Returns (response_text, confidence_score).
        """
        model = XAI_MODEL_FAST if fast else XAI_MODEL_DEFAULT
        cb    = self._cb_fast if fast else self._cb_default
        stats = self._stats_fast if fast else self._stats_default

        if not cb.allow():
            raise RuntimeError(f"Grok circuit breaker OPEN for model {model}")

        api_key = os.environ.get("XAI_API_KEY", "")
        if not api_key:
            raise RuntimeError("XAI_API_KEY not configured")

        t0       = time.time()
        messages = self._build_messages(message, system, history)

        try:
            client = self._get_client(api_key)
            resp   = client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=max_tokens,
                temperature=temperature,
            )
            text       = resp.choices[0].message.content.strip()
            tokens_est = getattr(resp, "usage", None)
            tokens_est = getattr(tokens_est, "total_tokens", len(text) // 4) if tokens_est else len(text) // 4
            ms         = round((time.time() - t0) * 1000, 1)

            cb.record_success()
            stats.record(tokens_est, ms, True)
            conf = self._score_confidence(text, message)

            with self._lock:
                self._total_calls += 1
                self._call_history.append({
                    "model":  model, "msg_len": len(message),
                    "resp_len": len(text), "ms": ms, "conf": conf,
                    "ts": time.time(),
                })

            log.info(f"[GrokBridge] {model} responded in {ms}ms conf={conf:.2f}")
            return text, conf

        except Exception as e:
            ms = round((time.time() - t0) * 1000, 1)
            cb.record_failure()
            stats.record(0, ms, False, str(e))
            raise

    def call_with_context(
        self,
        message:    str,
        session_id: str   = "default",
        max_tokens: int   = 2048,
        use_zeus_system: bool = True,
    ) -> Dict:
        """
        Call Grok with full session conversation context.
        Saves exchange to session memory.
        """
        system  = ZEUS_SYSTEM if use_zeus_system else ""
        history = self._sessions.get(session_id, [])

        # Enrich with Zeus knowledge context
        context = self._get_knowledge_context(message)
        if context:
            system += f"\n\nZeus Knowledge DNA:\n{context}"

        try:
            text, conf = self.call(
                message=message, system=system,
                history=history[-10:], max_tokens=max_tokens,
            )
            # Update session memory
            self._sessions[session_id].append({"role": "user",      "content": message})
            self._sessions[session_id].append({"role": "assistant", "content": text})
            # Keep last 20 turns
            if len(self._sessions[session_id]) > 40:
                self._sessions[session_id] = self._sessions[session_id][-40:]
            return {
                "response":   text,
                "confidence": conf,
                "model":      XAI_MODEL_DEFAULT,
                "session_id": session_id,
                "context_used": bool(context),
                "timestamp":  datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            return {
                "error":      str(e),
                "model":      XAI_MODEL_DEFAULT,
                "session_id": session_id,
                "timestamp":  datetime.now(timezone.utc).isoformat(),
            }

    def batch_call(
        self,
        prompts:    List[str],
        system:     str   = "",
        max_tokens: int   = 512,
        fast:       bool  = True,
    ) -> List[Dict]:
        """
        Call Grok for multiple independent prompts.
        Uses fast model for throughput.
        """
        results = []
        for i, prompt in enumerate(prompts):
            try:
                text, conf = self.call(
                    message=prompt, system=system,
                    max_tokens=max_tokens, fast=fast,
                )
                results.append({
                    "index":      i,
                    "text":       text,
                    "confidence": conf,
                    "success":    True,
                })
            except Exception as e:
                results.append({"index": i, "error": str(e), "success": False})
                time.sleep(0.5)   # brief back-off on failure
        return results

    def research_topic(self, topic: str, depth: str = "Simple") -> Dict:
        """
        Use Grok's real-time data access to research a topic.
        Returns structured research result ready to feed the knowledge base.
        """
        depth_guide = {
            "Simple":       "3-sentence summary: what, why, key insight",
            "Advanced":     "300 words: mechanisms, implementations, use cases",
            "Professional": "500 words: architecture, security, performance, code examples",
        }.get(depth, "concise technical summary")

        system = (
            "You are Zeus knowledge synthesizer with access to real-time data. "
            "Produce accurate, dense, technically precise knowledge articles. "
            "# The Zeus Project 2026 — Francois Nel"
        )
        prompt = (
            f"Research and synthesize knowledge about: {topic}\n\n"
            f"Depth level: {depth} — {depth_guide}\n\n"
            f"Use your real-time knowledge. Focus on technical precision and actionable insights."
        )
        try:
            text, conf = self.call(prompt, system=system, max_tokens=1500)
            return {
                "topic":    topic,
                "depth":    depth,
                "content":  text,
                "engine":   "grok",
                "confidence": conf,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            return {"topic": topic, "depth": depth, "error": str(e)}

    def get_synthesis_guidance(self, goal: str, existing_patterns: List[str]) -> Dict:
        """
        Ask Grok for architectural guidance for a synthesis goal.
        Grok's broad knowledge makes it valuable for architectural decisions.
        """
        prompt = (
            f"You are an expert software architect advising the Zeus AI system.\n"
            f"Synthesis goal: {goal}\n"
            f"Existing patterns in use: {', '.join(existing_patterns[:5])}\n\n"
            f"Provide:\n"
            f"1. Recommended architecture style (Clean/DDD/Hexagonal)\n"
            f"2. Top 3 design patterns to apply\n"
            f"3. Key security considerations\n"
            f"4. Integration points with existing Zeus modules\n"
            f"Return as JSON: {{\"architecture\": str, \"patterns\": [], \"security\": [], \"integrations\": []}}"
        )
        try:
            from zeus_llm_router import get_router
            router = get_router()
            raw    = router.call(prompt, engine="openrouter", max_tokens=600)
            try:
                data = json.loads(re.sub(r'```(?:json)?', '', raw).strip().rstrip('`'))
            except Exception:
                data = {"raw": raw}
            return {"status": "ok", "guidance": data, "goal": goal}
        except Exception as e:
            # Fall back to direct Grok call
            try:
                text, _ = self.call(prompt, max_tokens=600)
                return {"status": "ok", "guidance": {"raw": text}, "goal": goal}
            except Exception as e2:
                return {"status": "error", "error": str(e2)}

    # ---- Helpers ---------------------------------------------------------

    def _get_client(self, api_key: str):
        try:
            from openai import OpenAI
            return OpenAI(api_key=api_key, base_url=XAI_BASE)
        except ImportError:
            # Fallback: raw HTTP
            return None

    def _build_messages(self, message: str, system: str,
                          history: Optional[List[Dict]]) -> List[Dict]:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        if history:
            messages.extend(history[-10:])
        messages.append({"role": "user", "content": message})
        return messages

    def _score_confidence(self, text: str, message: str) -> float:
        if not text or len(text) < 20:
            return 0.0
        score = 0.55
        if len(text) > 200: score += 0.08
        if len(text) > 600: score += 0.06
        uncertain = ["i'm not sure", "i don't know", "i cannot", "i'm unable"]
        for p in uncertain:
            if p in text.lower():
                score -= 0.12
                break
        msg_words  = set(re.findall(r'\b\w{4,}\b', message.lower()))
        resp_words = set(re.findall(r'\b\w{4,}\b', text.lower()))
        overlap    = len(msg_words & resp_words)
        score     += min(0.12, overlap * 0.025)
        if "```" in text or "def " in text:
            score += 0.05
        return round(min(1.0, max(0.0, score)), 4)

    def _get_knowledge_context(self, message: str) -> str:
        try:
            from zeus_search import get_engine as get_search
            results = get_search().quick_search(message, max_results=3)
            if results:
                snippets = "\n".join(
                    f"• {r.get('title','')}: {r.get('snippet','')[:150]}"
                    for r in results
                )
                return snippets
        except Exception:
            pass
        return ""

    def stats(self) -> Dict:
        with self._lock:
            return {
                "total_calls":    self._total_calls,
                "default_model":  self._stats_default.to_dict(),
                "fast_model":     self._stats_fast.to_dict(),
                "circuit_default": self._cb_default.state(),
                "circuit_fast":    self._cb_fast.state(),
                "active_sessions": len(self._sessions),
                "history_entries": len(self._call_history),
            }

    def is_available(self) -> bool:
        return bool(os.environ.get("XAI_API_KEY"))


# ============================================================================
# SINGLETON
# ============================================================================

_grok_lock:     threading.RLock    = threading.RLock()
_grok_instance: Optional[GrokEngine] = None


def get_grok_engine() -> GrokEngine:
    global _grok_instance
    with _grok_lock:
        if _grok_instance is None:
            _grok_instance = GrokEngine()
        return _grok_instance


def ask_grok(
    message:    str,
    system:     str        = "",
    history:    List[Dict] = None,
    max_tokens: int        = 2048,
    fast:       bool       = False,
) -> Tuple[str, float]:
    """Importable convenience function. Returns (text, confidence)."""
    return get_grok_engine().call(message=message, system=system,
                                   history=history, max_tokens=max_tokens, fast=fast)


# ============================================================================
# FLASK ROUTES
# ============================================================================

@bridge_bp.route("/api/grok/health", methods=["GET"])
def grok_health():
    engine = get_grok_engine()
    return jsonify({
        "status":      "ok",
        "module":      "zeus_grok_bridge",
        "version":     "2.0",
        "available":   engine.is_available(),
        "model":       XAI_MODEL_DEFAULT,
        "circuit":     engine._cb_default.state(),
        "total_calls": engine._total_calls,
    })


@bridge_bp.route("/api/grok/stats", methods=["GET"])
def grok_stats():
    try:
        return jsonify(get_grok_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@bridge_bp.route("/api/grok/ask", methods=["POST"])
def grok_ask():
    """
    POST {
      "message":    str,
      "system":     str,
      "session_id": str,
      "max_tokens": int,
      "fast":       bool
    }
    """
    data       = request.get_json(force=True, silent=True) or {}
    message    = data.get("message", "").strip()
    session_id = data.get("session_id", "default")
    max_tokens = int(data.get("max_tokens", 2048))
    fast       = bool(data.get("fast", False))

    if not message:
        return jsonify({"error": "message required"}), 400
    if not get_grok_engine().is_available():
        return jsonify({"error": "XAI_API_KEY not configured"}), 503

    try:
        result = get_grok_engine().call_with_context(
            message=message, session_id=session_id,
            max_tokens=max_tokens,
        )
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@bridge_bp.route("/api/grok/research", methods=["POST"])
def grok_research():
    """
    Use Grok's real-time data to research a topic and optionally save to KB.
    POST { "topic": str, "depth": str, "save_to_kb": bool }
    """
    data      = request.get_json(force=True, silent=True) or {}
    topic     = data.get("topic", "").strip()
    depth     = data.get("depth", "Simple")
    save_to_kb = bool(data.get("save_to_kb", False))

    if not topic:
        return jsonify({"error": "topic required"}), 400
    if not get_grok_engine().is_available():
        return jsonify({"error": "XAI_API_KEY not configured"}), 503

    try:
        result = get_grok_engine().research_topic(topic, depth)
        if save_to_kb and "content" in result:
            try:
                from db_init import get_db
                conn = get_db()
                conn.execute(
                    """INSERT OR IGNORE INTO knowledge
                       (topic, depth, content, source_url, confidence, domain)
                       VALUES (?, ?, ?, '', 0.78, 'grok_research')""",
                    (topic[:200], depth, result["content"][:10000])
                )
                conn.commit(); conn.close()
                result["saved_to_kb"] = True
            except Exception as e:
                result["kb_error"] = str(e)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@bridge_bp.route("/api/grok/batch", methods=["POST"])
def grok_batch():
    """
    Batch multiple prompts to Grok.
    POST { "prompts": [str, ...], "system": str, "max_tokens": int }
    """
    data       = request.get_json(force=True, silent=True) or {}
    prompts    = data.get("prompts", [])
    system     = data.get("system", "")
    max_tokens = int(data.get("max_tokens", 512))

    if not prompts or not isinstance(prompts, list):
        return jsonify({"error": "prompts array required"}), 400
    if not get_grok_engine().is_available():
        return jsonify({"error": "XAI_API_KEY not configured"}), 503

    try:
        results = get_grok_engine().batch_call(
            prompts=prompts[:10], system=system, max_tokens=max_tokens, fast=True
        )
        return jsonify({"results": results, "count": len(results)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@bridge_bp.route("/api/grok/synthesis_guidance", methods=["POST"])
def grok_synthesis_guidance():
    """
    Ask Grok for synthesis architectural guidance.
    POST { "goal": str, "existing_patterns": [str] }
    """
    data     = request.get_json(force=True, silent=True) or {}
    goal     = data.get("goal", "").strip()
    patterns = data.get("existing_patterns", [])
    if not goal:
        return jsonify({"error": "goal required"}), 400
    try:
        return jsonify(get_grok_engine().get_synthesis_guidance(goal, patterns))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@bridge_bp.route("/api/grok/session/clear", methods=["POST"])
def grok_session_clear():
    data       = request.get_json(force=True, silent=True) or {}
    session_id = data.get("session_id", "")
    engine     = get_grok_engine()
    with engine._lock:
        if session_id:
            engine._sessions.pop(session_id, None)
            cleared = session_id
        else:
            n = len(engine._sessions)
            engine._sessions.clear()
            cleared = f"all ({n} sessions)"
    return jsonify({"status": "ok", "cleared": cleared})


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(bridge_bp)
    log.info("[grok_bridge] ✓ Registered at /api/grok")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_grok_bridge",
            blueprint_var="bridge_bp",
            url_prefix="/api/grok",
            version="2.0",
            description="xAI Grok bridge: real-time web data, extended context, circuit breaker, batch, research",
            capabilities=[
                {"id": "grok.ask",       "endpoint": "/api/grok/ask",       "method": "POST", "tags": ["grok","llm","realtime"]},
                {"id": "grok.research",  "endpoint": "/api/grok/research",  "method": "POST", "tags": ["grok","research","knowledge"]},
                {"id": "grok.batch",     "endpoint": "/api/grok/batch",     "method": "POST", "tags": ["grok","batch"]},
                {"id": "grok.synthesis", "endpoint": "/api/grok/synthesis_guidance","method":"POST","tags":["grok","synthesis"]},
                {"id": "grok.health",    "endpoint": "/api/grok/health",    "method": "GET",  "tags": ["health"]},
                {"id": "grok.stats",     "endpoint": "/api/grok/stats",     "method": "GET",  "tags": ["stats"]},
            ],
            depends_on=["zeus_llm_router", "zeus_search"],
            boot_order=95,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5023, debug=True, use_reloader=False)
