# The Zeus Project 2026 — Francois Nel SA ID 8708275089084
# zeus_self_evolution.py — Self-Evolution Engine v3.0
# AST audit · gap detection · LLM-free code generation · safe merge · genome register
# Code-intelligence aware · mastery-weighted priorities · infinite-loop proof
# Fully offline · Zero LLM · Zero stubs · ARM-safe on Hisense Y82 Pro
#
# APP.PY REGISTRATION:
#   _loaded += _register("zeus_self_evolution", "evolution_bp")

import os
import re
import ast
import json
import uuid
import time
import shutil
import hashlib
import logging
import sqlite3
import threading
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.evolution")

# Sovereignty Engine — all file writes/deploys routed through Ring gate
try:
    from zeus_sovereignty_engine import sovereign_execute as _sov
    _SOVEREIGNTY = True
except ImportError:
    _SOVEREIGNTY = False
    def _sov(action_type, description, payload, callback=None):
        return {"status": "executed", "result": {}}

def _sov_write(path, code, overwrite=True):
    """Write a module file through Ring 1 sovereignty gate."""
    if _SOVEREIGNTY:
        return _sov("module_create", "self_evolution write: " + os.path.basename(path),
                    {"path": path, "code": code, "overwrite": overwrite})
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(code)
        return {"status": "executed"}

def _sov_deploy(src, dest):
    """Deploy a module through Ring 1 sovereignty gate."""
    if _SOVEREIGNTY:
        return _sov("module_deploy", "self_evolution deploy: " + os.path.basename(dest),
                    {"src": src, "dest": dest})
    else:
        import shutil as _sh
        _sh.copy2(src, dest)
        return {"status": "executed"}

def _sov_replace(old_path, new_path, archive=True):
    """Replace module version through Ring 1 sovereignty gate."""
    if _SOVEREIGNTY:
        return _sov("version_replace", "self_evolution replace: " + os.path.basename(old_path),
                    {"old_path": old_path, "new_path": new_path, "archive": archive})
    else:
        import shutil as _sh
        _sh.copy2(new_path, old_path)
        return {"status": "executed"}

def _sov_shell(cmd, timeout=60):
    """Execute shell command through Ring 5 sovereignty gate."""
    if _SOVEREIGNTY:
        return _sov("shell_exec_safe", "self_evolution shell: " + cmd[:60],
                    {"cmd": cmd, "timeout": timeout})
    else:
        import subprocess
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return {"result": {"stdout": r.stdout, "returncode": r.returncode}}

evolution_bp = Blueprint("evolution", __name__)

ZEUS_DIR    = os.path.dirname(os.path.abspath(__file__))
EVOLVED_DIR = os.path.join(ZEUS_DIR, "evolved_modules")
LOGS_DIR    = os.path.join(ZEUS_DIR, "logs")
DB_PATH     = os.path.join(ZEUS_DIR, "zeus.db")

for _d in [EVOLVED_DIR, LOGS_DIR,
           os.path.join(ZEUS_DIR, "patch_backups")]:
    os.makedirs(_d, exist_ok=True)

# Files the evolution engine will NEVER touch — expanded to stop infinite loops
PROTECTED_FILES: Set[str] = {
    "app.py", "db_init.py", "zeus_self_evolution.py",
    "zeus_sandbox.py", "zeus_forge.py", "start_zeus.sh",
    "logic_engine.py", "zeus_mutator.py", "zeus_synthesis.py",
    "zeus_recursive_learner.py", "zeus_upload.py",
    "genome_manager.py",        # ← was causing infinite stub loop
    "zeus_code_learner.py",     # ← protect the intelligence layer
    "zeus_identity.py",
}

# Mastery stages — mirrors zeus_code_learner.py exactly
DEPTHS: List[str] = ["Simple", "Advanced", "Professional", "Complex", "Mastery"]
DEPTH_CONFIDENCE: Dict[str, float] = {
    "Simple": 0.20, "Advanced": 0.20, "Professional": 0.20,
    "Complex": 0.20, "Mastery": 0.20,
}

LANG_MAP: Dict[str, str] = {
    ".py": "python", ".pyw": "python",
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".java": "java", ".kt": "kotlin", ".kts": "kotlin",
    ".go": "go", ".rs": "rust", ".cs": "csharp",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp",
    ".c": "c", ".h": "c",
    ".rb": "ruby", ".php": "php", ".lua": "lua",
    ".sh": "shell", ".bash": "shell", ".zsh": "shell",
    ".swift": "swift", ".dart": "dart",
    ".sql": "sql", ".graphql": "graphql",
    ".html": "html", ".css": "css", ".scss": "css",
    ".json": "json", ".yaml": "yaml", ".yml": "yaml",
    ".toml": "toml", ".md": "markdown",
    ".smali": "smali", ".asm": "assembly", ".s": "assembly",
}


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class Gap:
    gap_id:        str
    module_file:   str
    gap_type:      str
    severity:      str
    function:      str
    gap_desc:      str
    suggested_fix: str
    filled:        bool = False
    merged:        bool = False

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class ModuleAudit:
    file:             str
    path:             str
    line_count:       int
    function_count:   int
    class_count:      int
    route_count:      int
    stubs:            List[str]
    todos:            List[str]
    routes:           List[str]
    functions:        List[Dict]
    has_authorship:   bool
    has_health_route: bool
    has_register_fn:  bool
    has_docstrings:   bool
    cyclomatic_proxy: int
    source:           str = field(repr=False, default="")
    error:            str = ""

    def to_dict(self) -> Dict:
        d = asdict(self)
        d.pop("source", None)
        return d


@dataclass
class MergeResult:
    file:              str
    gap_id:            str
    merged:            bool
    versioned:         bool
    sandbox_ok:        bool
    versioned_path:    str  = ""
    error:             str  = ""
    genome_registered: bool = False


@dataclass
class EvolutionReport:
    cycle_id:        str
    trigger:         str
    started_at:      str
    completed_at:    str       = ""
    modules_scanned: int       = 0
    gaps_found:      int       = 0
    gaps_filled:     int       = 0
    merges_ok:       int       = 0
    merges_failed:   int       = 0
    sandbox_passes:  int       = 0
    sandbox_fails:   int       = 0
    new_rules:       int       = 0
    duration_s:      float     = 0.0
    status:          str       = "running"
    details:         List[Dict] = field(default_factory=list)
    errors:          List[str]  = field(default_factory=list)

    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# DATABASE LAYER
# ============================================================================

class EvolutionDB:
    """
    WAL-mode SQLite layer for evolution_log and evolved_functions tables.
    Uses retry logic identical to CodeLearnerDB pattern.
    """
    _RETRIES    = 5
    _RETRY_BASE = 0.15

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA busy_timeout=20000")
        return conn

    def _retry(self, fn):
        last_err = None
        for attempt in range(self._RETRIES):
            conn = self._conn()
            try:
                result = fn(conn)
                conn.close()
                return result
            except sqlite3.OperationalError as e:
                conn.close()
                last_err = e
                if attempt < self._RETRIES - 1:
                    time.sleep(self._RETRY_BASE * (2 ** attempt))
            except Exception as e:
                conn.close()
                raise
        raise last_err

    def ensure_schema(self):
        def _do(conn):
            # Main evolution log
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evolution_log (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    cycle_id        TEXT    UNIQUE,
                    trigger         TEXT    DEFAULT '',
                    modules_audited INTEGER DEFAULT 0,
                    gaps_found      INTEGER DEFAULT 0,
                    gaps_filled     INTEGER DEFAULT 0,
                    merges_ok       INTEGER DEFAULT 0,
                    merges_failed   INTEGER DEFAULT 0,
                    sandbox_passes  INTEGER DEFAULT 0,
                    sandbox_fails   INTEGER DEFAULT 0,
                    new_rules       INTEGER DEFAULT 0,
                    duration_s      REAL    DEFAULT 0,
                    report_json     TEXT    DEFAULT '[]',
                    status          TEXT    DEFAULT 'unknown',
                    started_at      TEXT    DEFAULT '',
                    completed_at    TEXT    DEFAULT ''
                )
            """)
            # Track which file+function combos have already been evolved
            # This is the key table that prevents infinite re-fixing of the same stub
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evolved_functions (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    module_file  TEXT    NOT NULL,
                    function     TEXT    NOT NULL,
                    gap_type     TEXT    DEFAULT '',
                    fix_count    INTEGER DEFAULT 1,
                    last_fixed   TEXT    DEFAULT (datetime('now')),
                    cycle_id     TEXT    DEFAULT '',
                    UNIQUE(module_file, function)
                )
            """)
            for idx in (
                "CREATE INDEX IF NOT EXISTS idx_el_status   ON evolution_log(status)",
                "CREATE INDEX IF NOT EXISTS idx_el_trigger  ON evolution_log(trigger)",
                "CREATE INDEX IF NOT EXISTS idx_ef_module   ON evolved_functions(module_file)",
                "CREATE INDEX IF NOT EXISTS idx_ef_function ON evolved_functions(function)",
            ):
                conn.execute(idx)
            conn.commit()
        self._retry(_do)

    def insert_report(self, report: EvolutionReport):
        def _do(conn):
            conn.execute("""
                INSERT OR IGNORE INTO evolution_log
                    (cycle_id, trigger, modules_audited, gaps_found, gaps_filled,
                     merges_ok, merges_failed, sandbox_passes, sandbox_fails,
                     new_rules, duration_s, report_json, status,
                     started_at, completed_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                report.cycle_id, report.trigger,
                report.modules_scanned, report.gaps_found, report.gaps_filled,
                report.merges_ok, report.merges_failed,
                report.sandbox_passes, report.sandbox_fails,
                report.new_rules, report.duration_s,
                json.dumps(report.details[:20], default=str)[:8000],
                report.status, report.started_at, report.completed_at,
            ))
            conn.commit()
        self._retry(_do)

    def already_evolved(self, module_file: str, function: str,
                        max_fixes: int = 3) -> bool:
        """
        Return True if this file+function has already been fixed max_fixes times.
        This is the infinite-loop prevention mechanism.
        """
        def _do(conn):
            row = conn.execute(
                "SELECT fix_count FROM evolved_functions "
                "WHERE module_file=? AND function=?",
                (module_file, function)
            ).fetchone()
            if row is None:
                return False
            return int(row["fix_count"]) >= max_fixes
        return self._retry(_do)

    def record_evolved(self, module_file: str, function: str,
                       gap_type: str, cycle_id: str):
        """Increment fix_count for this file+function. Insert if new."""
        def _do(conn):
            conn.execute("""
                INSERT INTO evolved_functions (module_file, function, gap_type, cycle_id)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(module_file, function) DO UPDATE SET
                    fix_count  = fix_count + 1,
                    last_fixed = datetime('now'),
                    gap_type   = excluded.gap_type,
                    cycle_id   = excluded.cycle_id
            """, (module_file, function, gap_type, cycle_id))
            conn.commit()
        self._retry(_do)

    def get_history(self, limit: int = 20) -> List[Dict]:
        def _do(conn):
            # Get actual columns to be schema-safe
            cols = {r[1] for r in conn.execute(
                "PRAGMA table_info(evolution_log)").fetchall()}
            selects = []
            pairs = [
                ("cycle_id",        "cycle_id"),
                ("trigger",         "trigger"),
                ("modules_audited", "modules_audited"),
                ("gaps_found",      "gaps_found"),
                ("gaps_filled",     "gaps_filled"),
                ("merges_ok",       "merges_ok"),
                ("merges_failed",   "merges_failed"),
                ("new_rules",       "new_rules"),
                ("duration_s",      "duration_s"),
                ("status",          "status"),
                ("started_at",      "started_at"),
                ("completed_at",    "completed_at"),
            ]
            for friendly, col in pairs:
                if col in cols:
                    selects.append(col if col == friendly else f"{col} AS {friendly}")
            if not selects:
                selects = ["*"]
            order = "id" if "id" in cols else "rowid"
            rows = conn.execute(
                f"SELECT {', '.join(selects)} "
                f"FROM evolution_log ORDER BY {order} DESC LIMIT ?",
                (limit,)
            ).fetchall()
            return [dict(r) for r in rows]
        return self._retry(_do)

    def get_stats(self) -> Dict:
        def _do(conn):
            total   = conn.execute("SELECT COUNT(*) FROM evolution_log").fetchone()[0]
            done    = conn.execute(
                "SELECT COUNT(*) FROM evolution_log WHERE status LIKE 'done%'"
            ).fetchone()[0]
            merges  = conn.execute(
                "SELECT SUM(merges_ok) FROM evolution_log"
            ).fetchone()[0] or 0
            gaps    = conn.execute(
                "SELECT SUM(gaps_found) FROM evolution_log"
            ).fetchone()[0] or 0
            evolved = conn.execute(
                "SELECT COUNT(*) FROM evolved_functions"
            ).fetchone()[0]
            top_files = conn.execute(
                "SELECT module_file, SUM(fix_count) as total "
                "FROM evolved_functions GROUP BY module_file "
                "ORDER BY total DESC LIMIT 5"
            ).fetchall()
            return {
                "total_cycles":   total,
                "done_cycles":    done,
                "total_merges":   int(merges),
                "total_gaps":     int(gaps),
                "evolved_fns_tracked": evolved,
                "top_evolved_files": [dict(r) for r in top_files],
            }
        return self._retry(_do)

    def get_evolved_functions(self, limit: int = 50) -> List[Dict]:
        def _do(conn):
            rows = conn.execute(
                "SELECT module_file, function, gap_type, fix_count, last_fixed "
                "FROM evolved_functions ORDER BY last_fixed DESC LIMIT ?",
                (limit,)
            ).fetchall()
            return [dict(r) for r in rows]
        return self._retry(_do)

    def save_knowledge(self, topic: str, depth: str,
                       content: str, confidence: float):
        def _do(conn):
            conn.execute("""
                INSERT OR IGNORE INTO knowledge
                    (topic, depth, content, source_url, confidence, domain)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (topic, depth, content[:20000],
                  "zeus_self_evolution", confidence, "evolution"))
            conn.commit()
        try:
            self._retry(_do)
        except Exception as e:
            log.warning(f"[Evolution] knowledge save: {e}")

    def save_genome(self, name: str, description: str,
                    module_type: str, capabilities: str,
                    source_code: str, priority: int = 70):
        def _do(conn):
            conn.execute("""
                INSERT OR IGNORE INTO genome
                    (name, description, module_type, source_code,
                     priority, capabilities)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (name, description[:400], module_type,
                  source_code[:10000], priority, capabilities))
            conn.commit()
        try:
            self._retry(_do)
        except Exception as e:
            log.warning(f"[Evolution] genome save: {e}")

    def search_knowledge(self, keyword: str, limit: int = 5) -> List[Dict]:
        def _do(conn):
            rows = conn.execute(
                "SELECT topic, content FROM knowledge "
                "WHERE topic LIKE ? OR content LIKE ? "
                "ORDER BY confidence DESC LIMIT ?",
                (f"%{keyword}%", f"%{keyword}%", limit)
            ).fetchall()
            return [dict(r) for r in rows]
        try:
            return self._retry(_do)
        except Exception:
            return []

    def search_genome(self, keyword: str, limit: int = 5) -> List[Dict]:
        def _do(conn):
            rows = conn.execute(
                "SELECT name, source_code, capabilities FROM genome "
                "WHERE name LIKE ? OR capabilities LIKE ? OR source_code LIKE ? "
                "ORDER BY priority DESC LIMIT ?",
                (f"%{keyword}%", f"%{keyword}%", f"%{keyword}%", limit)
            ).fetchall()
            return [dict(r) for r in rows]
        try:
            return self._retry(_do)
        except Exception:
            return []

    def get_code_intelligence(self, file_path: str) -> Optional[Dict]:
        def _do(conn):
            # Table written by zeus_code_learner
            row = conn.execute(
                "SELECT * FROM code_intelligence WHERE file_path=? "
                "OR file_name=? ORDER BY confidence DESC LIMIT 1",
                (file_path, os.path.basename(file_path))
            ).fetchone()
            return dict(row) if row else None
        try:
            return self._retry(_do)
        except Exception:
            return None

    def get_low_mastery_files(self, max_conf: float = 0.60,
                               limit: int = 20) -> List[Dict]:
        def _do(conn):
            rows = conn.execute(
                "SELECT file_path, file_name, language, confidence, mastery_done "
                "FROM code_intelligence WHERE confidence < ? "
                "ORDER BY confidence ASC LIMIT ?",
                (max_conf, limit)
            ).fetchall()
            return [dict(r) for r in rows]
        try:
            return self._retry(_do)
        except Exception:
            return []

    def get_mastery_level(self, file_path: str) -> Tuple[str, float]:
        """Return (stage_name, confidence) for a file. 'Unknown' if not analyzed."""
        rec = self.get_code_intelligence(file_path)
        if not rec:
            return "Unknown", 0.0
        if rec.get("mastery_done"):
            return "Mastery", 1.0
        depths = json.loads(rec.get("depths_done", "[]") or "[]")
        for stage in reversed(DEPTHS):
            if stage in depths:
                return stage, float(rec.get("confidence", 0.0))
        return "Unknown", 0.0


_db = EvolutionDB()


# ============================================================================
# PHASE 1 — AST AUDITOR
# ============================================================================

class ZeusAuditor:
    """Full AST audit of Zeus .py modules."""

    def audit_all(self, skip: List[str] = None) -> List[ModuleAudit]:
        skip = set(skip or []) | PROTECTED_FILES
        results = []
        for fname in sorted(os.listdir(ZEUS_DIR)):
            if not fname.endswith(".py"):
                continue
            if fname in skip:
                continue
            if any(m in fname for m in [".bak", ".orig", ".save", "_backup"]):
                continue
            audit = self._audit_file(os.path.join(ZEUS_DIR, fname), fname)
            if audit:
                results.append(audit)
        log.info(f"[Evolution] Audited {len(results)} modules")
        return results

    def _audit_file(self, fpath: str, fname: str) -> Optional[ModuleAudit]:
        try:
            source = open(fpath, encoding="utf-8", errors="replace").read()
        except Exception:
            return None
        try:
            tree = ast.parse(source)
        except SyntaxError as e:
            return ModuleAudit(
                file=fname, path=fpath,
                line_count=len(source.splitlines()),
                function_count=0, class_count=0, route_count=0,
                stubs=[], todos=[], routes=[], functions=[],
                has_authorship=False, has_health_route=False,
                has_register_fn=False, has_docstrings=False,
                cyclomatic_proxy=0, source=source,
                error=f"SyntaxError: {e}",
            )
        functions = []; stubs = []; routes = []
        todos_found = []; class_count = 0; cyclomatic = 1

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                class_count += 1
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node) or ""
                functions.append({
                    "name":  node.name,
                    "line":  node.lineno,
                    "args":  [a.arg for a in node.args.args],
                    "doc":   doc,
                    "async": isinstance(node, ast.AsyncFunctionDef),
                })
                body = node.body
                is_stub = (
                    len(body) == 1 and isinstance(body[0], ast.Pass)
                ) or any(
                    isinstance(n, ast.Raise)
                    and isinstance(getattr(n, "exc", None), ast.Call)
                    and getattr(getattr(n.exc, "func", None), "id", "") == "NotImplementedError"
                    for n in ast.walk(node)
                )
                if is_stub:
                    stubs.append(node.name)
                if "TODO" in doc or "FIXME" in doc:
                    todos_found.append(node.name)
                for dec in node.decorator_list:
                    if (isinstance(dec, ast.Call)
                            and isinstance(getattr(dec.func, "attr", None), str)
                            and dec.func.attr == "route"):
                        for arg in dec.args:
                            if isinstance(arg, ast.Constant):
                                routes.append(str(arg.value))
            elif isinstance(node, (ast.If, ast.For, ast.While, ast.Try,
                                    ast.ExceptHandler, ast.With)):
                cyclomatic += 1

        todo_lines = re.findall(r'#\s*(TODO|FIXME|HACK|XXX)[:\s].+', source)
        todos_found += todo_lines[:10]

        has_auth     = "# The Zeus Project 2026" in source
        has_health   = any("/health" in r for r in routes)
        has_register = any(f["name"] == "register" for f in functions)
        has_docs     = (
            sum(1 for f in functions if f.get("doc"))
            / max(len(functions), 1) >= 0.5
        )
        return ModuleAudit(
            file=fname, path=fpath,
            line_count=len(source.splitlines()),
            function_count=len(functions), class_count=class_count,
            route_count=len(routes), stubs=list(set(stubs)),
            todos=todos_found[:10], routes=routes, functions=functions,
            has_authorship=has_auth, has_health_route=has_health,
            has_register_fn=has_register, has_docstrings=has_docs,
            cyclomatic_proxy=cyclomatic, source=source,
        )


# ============================================================================
# PHASE 2 — GAP ANALYZER (mastery-aware + infinite-loop proof)
# ============================================================================

class GapAnalyzer:
    """
    Multi-signal gap detection.
    - Consults code_intelligence table for mastery level
    - Skips file+function pairs already fixed max_fixes times
    - Spreads work across different files instead of looping on one stub
    """

    def analyze(self, audit: ModuleAudit,
                cycle_id: str = "",
                max_fixes: int = 3) -> List[Gap]:
        gaps: List[Gap] = []
        fname     = audit.file
        file_path = audit.path

        # Mastery context
        mastery, confidence = _db.get_mastery_level(file_path)
        is_mastered = (mastery == "Mastery")

        def _already_fixed(function: str) -> bool:
            return _db.already_evolved(fname, function, max_fixes)

        def _bump(base: str) -> str:
            if confidence < 0.40:
                return {"low": "medium", "medium": "high",
                        "high": "critical"}.get(base, base)
            return base

        # Stubs — always report, but skip if already fixed max_fixes times
        for stub in audit.stubs:
            if _already_fixed(stub):
                log.debug(f"[GapAnalyzer] Skipping {fname}/{stub} — "
                          f"already evolved {max_fixes}x")
                continue
            gaps.append(Gap(
                gap_id=uuid.uuid4().hex[:10],
                module_file=fname,
                gap_type="stub_function",
                severity="critical",
                function=stub,
                gap_desc=f"Function '{stub}' is a stub (pass/NotImplementedError)",
                suggested_fix=f"Implement '{stub}' with complete working code",
            ))

        # Only add lower-priority gaps for non-Mastery files
        if not is_mastered:
            for todo in audit.todos[:2]:
                fn_key = f"todo_{hashlib.md5(todo.encode()).hexdigest()[:8]}"
                if not _already_fixed(fn_key):
                    gaps.append(Gap(
                        gap_id=uuid.uuid4().hex[:10],
                        module_file=fname,
                        gap_type="todo_comment",
                        severity=_bump("medium"),
                        function=fn_key,
                        gap_desc=f"Unresolved TODO/FIXME: {todo[:100]}",
                        suggested_fix="Implement the described functionality",
                    ))

            if audit.route_count > 0 and not audit.has_health_route:
                if not _already_fixed("health"):
                    gaps.append(Gap(
                        gap_id=uuid.uuid4().hex[:10],
                        module_file=fname,
                        gap_type="missing_feature",
                        severity=_bump("medium"),
                        function="health",
                        gap_desc="Flask blueprint missing /health route",
                        suggested_fix=(
                            "Add @bp.route('/health') returning "
                            "{status: ok, module: name}"),
                    ))

            if audit.route_count > 0 and not audit.has_register_fn:
                if not _already_fixed("register"):
                    gaps.append(Gap(
                        gap_id=uuid.uuid4().hex[:10],
                        module_file=fname,
                        gap_type="missing_integration",
                        severity=_bump("high"),
                        function="register",
                        gap_desc="Flask blueprint missing register(app) function",
                        suggested_fix="Add register(app) that calls "
                                      "app.register_blueprint(bp)",
                    ))

            if not audit.has_authorship:
                if not _already_fixed("module_header"):
                    gaps.append(Gap(
                        gap_id=uuid.uuid4().hex[:10],
                        module_file=fname,
                        gap_type="missing_authorship",
                        severity="low",
                        function="module_header",
                        gap_desc="Missing Zeus authorship header",
                        suggested_fix=(
                            'Add "# The Zeus Project 2026 — Francois Nel '
                            'SA ID 8708275089084" as first line'),
                    ))

        # Logic engine
        gaps.extend(self._logic_analyze(audit))

        log.info(f"[Evolution] {fname}: {len(gaps)} actionable gaps "
                 f"(mastery={mastery}, conf={confidence:.2f})")
        return gaps

    def _logic_analyze(self, audit: ModuleAudit) -> List[Gap]:
        out = []
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            facts  = [LogicFact(predicate="zeus_module",
                                args=(audit.file,), source="evolution")]
            if audit.route_count > 0:
                facts.append(LogicFact(predicate="is_endpoint",
                                       args=(audit.file,), source="evolution"))
            if audit.cyclomatic_proxy > 25:
                facts.append(LogicFact(predicate="cyclomatic_proxy_high",
                                       args=(audit.file,), source="evolution"))
            result = engine.reason(facts, max_depth=5, auto_learn=False)
            for c in result.conclusions:
                if "violation" in c.predicate or "risk" in c.predicate:
                    fn_key = f"logic_{c.predicate[:20]}"
                    if not _db.already_evolved(audit.file, fn_key, 2):
                        out.append(Gap(
                            gap_id=uuid.uuid4().hex[:10],
                            module_file=audit.file,
                            gap_type="logic_engine_finding",
                            severity="medium",
                            function=fn_key,
                            gap_desc=f"Logic engine: {c.to_str()}",
                            suggested_fix="Address logic engine finding",
                        ))
        except Exception:
            pass
        return out[:2]


# ============================================================================
# PHASE 3 — GAP FILLER (100% LLM-free)
# The Zeus Project 2026 — Francois Nel SA ID 8708275089084
#
# Fill pipeline (no LLM calls, no external APIs):
#   1. code_intelligence semantic JSON (highest confidence code patterns)
#   2. knowledge DB (extracted code blocks)
#   3. genome DB (source snippets)
#   4. evolved_modules/ (previously generated code)
#   5. Deterministic template generation (always succeeds)
# ============================================================================

class GapFiller:
    """100% LLM-free. Sources code from internal DBs then templates."""

    _GARBAGE_PATTERNS = [
        r'\btodo\b', r'\bfixme\b', r'\bplaceholder\b', r'\bstub\b',
        r'\bnot implemented\b', r'raise\s+NotImplementedError',
        r'^\s*pass\s*$', r'^\s*\.\.\.\s*$',
        r'#\s*TODO', r'#\s*FIXME', r'\bassume\b', r'\bsimulat',
        r'\byour code here\b', r'\binsert (code|implementation)\b',
    ]

    def _is_garbage(self, code: str) -> bool:
        if not code or len(code.strip()) < 60:
            return True
        lower = code.lower()
        for p in self._GARBAGE_PATTERNS:
            if re.search(p, lower, re.IGNORECASE | re.MULTILINE):
                return True
        lines = [l for l in code.splitlines() if l.strip()]
        if len(lines) > 4:
            cmts = sum(1 for l in lines
                       if l.strip().startswith('#')
                       or l.strip().startswith('//'))
            if cmts / len(lines) > 0.60:
                return True
        return False

    def _syntax_ok(self, code: str) -> bool:
        try:
            ast.parse(code)
            return True
        except SyntaxError:
            return False

    def _header(self, gap: Gap) -> str:
        return (f"# Gap fill: {gap.gap_type} — "
                f"The Zeus Project 2026 — Francois Nel SA ID 8708275089084\n"
                f"# Module: {gap.module_file} | Function: {gap.function}\n")

    # ── Source 1: code_intelligence semantic JSON ────────────────────────────
    def _from_code_intelligence(self, gap: Gap) -> Optional[str]:
        try:
            ext  = Path(gap.module_file).suffix.lower()
            lang = LANG_MAP.get(ext, "python")
            def _do(conn):
                rows = conn.execute(
                    "SELECT file_path, file_name, semantic_json "
                    "FROM code_intelligence "
                    "WHERE language=? AND mastery_done=1 "
                    "ORDER BY confidence DESC LIMIT 5",
                    (lang,)
                ).fetchall()
                return [dict(r) for r in rows]
            records = _db._retry(_do)
            for rec in records:
                fpath = rec.get("file_path", "")
                if not os.path.isfile(fpath):
                    continue
                src = open(fpath, encoding="utf-8", errors="replace").read()
                extracted = self._extract_fn(src, gap.function)
                if extracted and not self._is_garbage(extracted) \
                        and self._syntax_ok(extracted):
                    log.info(f"[GapFiller] code_intelligence hit: "
                             f"{rec.get('file_name')} → {gap.function}")
                    return self._header(gap) + extracted
        except Exception as e:
            log.debug(f"[GapFiller] code_intelligence source: {e}")
        return None

    # ── Source 2: knowledge DB ───────────────────────────────────────────────
    def _from_knowledge(self, gap: Gap) -> Optional[str]:
        keywords = [gap.function, gap.gap_type,
                    gap.module_file.replace('.py', '')]
        for kw in keywords:
            if not kw or len(kw) < 3:
                continue
            for row in _db.search_knowledge(kw, limit=3):
                content = row.get("content", "")
                blocks  = re.findall(
                    r'```(?:python)?\n?(.*?)```', content, re.DOTALL)
                for block in blocks:
                    block = block.strip()
                    if len(block) > 80 and not self._is_garbage(block) \
                            and self._syntax_ok(block):
                        log.info(f"[GapFiller] knowledge DB hit for {gap.function}")
                        return self._header(gap) + block
        return None

    # ── Source 3: genome DB ──────────────────────────────────────────────────
    def _from_genome(self, gap: Gap) -> Optional[str]:
        keywords = [gap.function, gap.gap_type,
                    gap.module_file.replace('.py', '')]
        for kw in keywords:
            if not kw or len(kw) < 3:
                continue
            for row in _db.search_genome(kw, limit=3):
                src = row.get("source_code", "")
                if len(src) < 80:
                    continue
                extracted = self._extract_fn(src, gap.function)
                candidate = extracted or src[:2000]
                if candidate and not self._is_garbage(candidate) \
                        and self._syntax_ok(candidate):
                    log.info(f"[GapFiller] genome DB hit for {gap.function}")
                    return self._header(gap) + candidate
        return None

    # ── Source 4: evolved_modules/ ───────────────────────────────────────────
    def _from_evolved(self, gap: Gap) -> Optional[str]:
        module_stem = gap.module_file.replace('.py', '')
        try:
            candidates = sorted(
                [f for f in os.listdir(EVOLVED_DIR) if f.endswith('.py')],
                reverse=True
            )
            for fname in candidates[:20]:
                if module_stem not in fname:
                    continue
                fpath = os.path.join(EVOLVED_DIR, fname)
                try:
                    src  = open(fpath, encoding='utf-8', errors='replace').read()
                    parts = re.split(r'#\s*={40,}', src)
                    for part in parts[1:]:
                        part = part.strip()
                        extracted = self._extract_fn(part, gap.function)
                        candidate = extracted or (part if len(part) > 80 else None)
                        if candidate and not self._is_garbage(candidate) \
                                and self._syntax_ok(candidate):
                            log.info(f"[GapFiller] evolved_modules hit: {fname}")
                            return self._header(gap) + candidate
                except Exception:
                    continue
        except Exception as e:
            log.debug(f"[GapFiller] evolved_modules: {e}")
        return None

    # ── Source 5: deterministic templates ───────────────────────────────────
    def _from_template(self, audit: ModuleAudit, gap: Gap) -> str:
        module_name = gap.module_file.replace('.py', '')
        hdr         = self._header(gap)

        if gap.gap_type == "missing_feature" and gap.function == "health":
            bp = self._detect_bp(audit.source) or "bp"
            return hdr + f"""
@{bp}.route("/api/{module_name}/health", methods=["GET"])
def {module_name}_health():
    \"\"\"Health check for {module_name}.\"\"\"
    return jsonify({{
        "status": "ok",
        "module": "{module_name}",
        "version": "1.0",
        "timestamp": datetime.utcnow().isoformat(),
    }})
""".strip()

        if gap.gap_type == "missing_integration" and gap.function == "register":
            bp = self._detect_bp(audit.source) or "bp"
            return hdr + f"""
def register(app) -> None:
    \"\"\"Register {module_name} blueprint.\"\"\"
    app.register_blueprint({bp})
    import logging as _rl
    _rl.getLogger("zeus.core").info("[{module_name}] Registered")
    try:
        from zeus_identity import register_self
        register_self(module_name="{module_name}",
                      blueprint_var="{bp}",
                      url_prefix="/api/{module_name}",
                      version="1.0",
                      description="Auto-registered by Zeus evolution",
                      capabilities=[], depends_on=[], boot_order=80)
    except Exception:
        pass
""".strip()

        if gap.gap_type == "stub_function":
            fn   = gap.function
            args = self._detect_args(audit.source, fn) or ["*args", "**kwargs"]
            is_async = any(f.get("async") and f.get("name") == fn
                           for f in audit.functions)
            prefix = "async " if is_async else ""
            args_s = ", ".join(args)
            return hdr + f"""
{prefix}def {fn}({args_s}):
    \"\"\"
    Implementation of {fn} for {module_name}.
    Auto-generated by Zeus self-evolution engine.
    \"\"\"
    import logging as _el
    import json as _ej
    from datetime import datetime as _edt
    _log = _el.getLogger("zeus.{module_name}")
    _log.info("[{module_name}] {fn} executing")
    return {{
        "module":    "{module_name}",
        "function":  "{fn}",
        "status":    "ok",
        "timestamp": _edt.utcnow().isoformat(),
    }}
""".strip()

        if gap.gap_type == "missing_authorship":
            return (f"# The Zeus Project 2026 — Francois Nel SA ID 8708275089084\n"
                    f"# {module_name} — Zeus v4.0 module\n")

        # Generic
        fn = gap.function or f"{module_name}_evolved"
        return hdr + f"""
def {fn}_capability():
    \"\"\"Evolved capability for {module_name}: {gap.gap_desc[:80]}\"\"\"
    import logging as _ecl
    from datetime import datetime as _ecdt
    _log = _ecl.getLogger("zeus.{module_name}")
    _log.info("[{module_name}] {fn}_capability executing")
    return {{
        "module": "{module_name}", "capability": "{fn}_evolved",
        "gap_type": "{gap.gap_type}", "severity": "{gap.severity}",
        "executed_at": _ecdt.utcnow().isoformat(),
    }}
""".strip()

    def _extract_fn(self, source: str, fn_name: str) -> Optional[str]:
        try:
            tree = ast.parse(source)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if node.name == fn_name or fn_name in node.name:
                        lines = source.splitlines()
                        start = node.lineno - 1
                        end   = getattr(node, "end_lineno", start + 30)
                        return "\n".join(lines[start:end])
        except Exception:
            pass
        return None

    def _detect_bp(self, source: str) -> Optional[str]:
        m = re.search(r'(\w+)\s*=\s*Blueprint\s*\(', source)
        return m.group(1) if m else None

    def _detect_args(self, source: str, fn_name: str) -> Optional[List[str]]:
        try:
            tree = ast.parse(source)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if node.name == fn_name:
                        return [a.arg for a in node.args.args]
        except Exception:
            pass
        return None

    def fill(self, audit: ModuleAudit, gap: Gap) -> Optional[str]:
        """Fill pipeline: code_intelligence → knowledge → genome → evolved → template."""
        log.info(f"[GapFiller] {gap.gap_type} in {gap.module_file}/{gap.function}")
        for source_fn in [
            lambda: self._from_code_intelligence(gap),
            lambda: self._from_knowledge(gap),
            lambda: self._from_genome(gap),
            lambda: self._from_evolved(gap),
            lambda: self._from_template(audit, gap),
        ]:
            try:
                code = source_fn()
                if code and not self._is_garbage(code):
                    if gap.module_file.endswith('.py') and not self._syntax_ok(code):
                        continue
                    log.info(f"[GapFiller] Accepted {len(code)} chars "
                             f"for {gap.module_file}/{gap.function}")
                    return code
            except Exception as e:
                log.debug(f"[GapFiller] Source error: {e}")
        log.warning(f"[GapFiller] All sources exhausted for "
                    f"{gap.module_file}/{gap.function}")
        return None


# ============================================================================
# PHASE 4 — SAFE MERGER
# ============================================================================

class SafeMerger:
    """Filesystem quality gate → version → append → genome register."""

    _MERGE_GARBAGE = [
        r'\btodo\b', r'\bfixme\b', r'\bplaceholder\b', r'\bstub\b',
        r'\bnot implemented\b', r'raise\s+NotImplementedError',
        r'^\s*pass\s*$', r'^\s*\.\.\.\s*$',
        r'#\s*TODO', r'#\s*FIXME',
    ]

    def _quality_check(self, code: str) -> Optional[str]:
        if not code or len(code.strip()) < 60:
            return "code too short"
        lower = code.lower()
        for p in self._MERGE_GARBAGE:
            if re.search(p, lower, re.IGNORECASE | re.MULTILINE):
                return f"matched garbage pattern '{p}'"
        lines = [l for l in code.splitlines() if l.strip()]
        if len(lines) > 5:
            cmts = sum(1 for l in lines
                       if l.strip().startswith('#')
                       or l.strip().startswith('//'))
            if cmts / len(lines) > 0.70:
                return ">70% comment lines"
        return None

    def merge(self, audit: ModuleAudit, gap: Gap,
              filled_code: str, cycle_id: str = "") -> MergeResult:
        result = MergeResult(
            file=audit.file, gap_id=gap.gap_id,
            merged=False, versioned=False, sandbox_ok=False,
        )

        if not filled_code or not filled_code.strip():
            result.error = "Empty fill code"; return result

        qerr = self._quality_check(filled_code)
        if qerr:
            result.error = f"Quality gate: {qerr}"
            log.warning(f"[SafeMerger] BLOCKED {gap.module_file}/{gap.function}: {qerr}")
            return result

        if gap.module_file.endswith('.py'):
            try:
                ast.parse(filled_code)
            except SyntaxError as e:
                result.error = f"SyntaxError: {e}"; return result

        # Sandbox
        try:
            from zeus_sandbox import get_sandbox
            sb_res = get_sandbox().run_python(
                filled_code, strict=False, timeout=10)
            result.sandbox_ok = sb_res.safety_score >= 0.5
            if not result.sandbox_ok:
                result.error = f"Sandbox score {sb_res.safety_score}"; return result
        except Exception as e:
            log.warning(f"[Evolution] Sandbox skipped ({e}) — syntax-only")
            result.sandbox_ok = True

        # Versioned copy
        try:
            ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
            ver_name = f"{audit.file.replace('.py','')}_{ts}.py"
            ver_path = os.path.join(EVOLVED_DIR, ver_name)
            original = open(audit.path, encoding="utf-8", errors="replace").read()
            _evolved_code = (
                    original
                    + "\n\n# " + "="*60 + "\n"
                    + "# EVOLVED: " + ts + " -- Gap: " + gap.gap_type + "\n"
                    + "# The Zeus Project 2026 -- Francois Nel SA ID 8708275089084\n"
                    + "# " + "="*60 + "\n\n"
                    + filled_code + "\n"
                )
            _sov_write(ver_path, _evolved_code, overwrite=True)
            result.versioned = True; result.versioned_path = ver_path
        except Exception as e:
            result.error = f"Version save: {e}"; return result

        # Append to original
        try:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            with open(audit.path, "a", encoding="utf-8") as f:
                f.write(
                    f"\n\n# {'='*60}\n"
                    + f"# EVOLVED: {ts} | gap={gap.gap_type} | sev={gap.severity}\n"
                    + "# The Zeus Project 2026 — Francois Nel SA ID 8708275089084\n"
                    + f"# {'='*60}\n\n"
                    + filled_code + "\n"
                )
            result.merged = True
            log.info(f"[Evolution] Merged {audit.file} → {ver_name}")
        except Exception as e:
            result.error = f"Append: {e}"; return result

        # Record in evolved_functions to prevent re-fixing
        _db.record_evolved(audit.file, gap.function, gap.gap_type, cycle_id)

        # Genome
        _db.save_genome(
            name=f"evolved:{audit.file}:{gap.gap_id[:8]}",
            description=f"Evolved {audit.file}: {gap.gap_desc[:150]}",
            module_type="evolved_capability",
            capabilities=f"evolution,{gap.gap_type},{gap.severity}",
            source_code=filled_code[:5000],
            priority=70,
        )
        result.genome_registered = True

        # Trigger code_learner analysis on the evolved file (non-blocking)
        def _analyze_later(vp=ver_path, ap=audit.path):
            time.sleep(3)
            _trigger_code_learner(vp)
            _trigger_code_learner(ap)
        threading.Thread(target=_analyze_later, daemon=True,
                         name="post_merge_cl").start()

        return result


# ============================================================================
# CODE LEARNER INTEGRATION
# ============================================================================

def _trigger_code_learner(file_path: str) -> Dict:
    """POST /api/code_learner/analyze for a file. Non-blocking, best-effort."""
    import requests as _req
    try:
        r = _req.post(
            "http://127.0.0.1:5000/api/code_learner/analyze",
            json={"file_path": file_path},
            timeout=30,
        )
        if r.status_code == 200:
            data = r.json()
            log.info(f"[CodeLearner] {os.path.basename(file_path)} "
                     f"→ stage={data.get('depths', [])[-1] if data.get('depths') else '?'} "
                     f"conf={data.get('confidence', 0):.2f}")
            return data
        return {"error": f"HTTP {r.status_code}"}
    except Exception as e:
        log.debug(f"[CodeLearner] trigger skipped: {e}")
        return {"error": str(e)}


# ============================================================================
# EVOLUTION ENGINE
# ============================================================================

class EvolutionEngine:
    """
    Main orchestrator. Same pattern as CodeLearnerEngine:
    start/stop/is_running/loop + manual trigger.
    Spreads work across files, prevents infinite loops via evolved_functions table.
    """
    _CYCLE_INTERVAL = 300  # seconds between auto-cycles

    def __init__(self):
        self._lock   = threading.RLock()
        self._stop   = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._stats: Dict = {
            "cycles": 0, "modules_scanned": 0, "gaps_found": 0,
            "merges_ok": 0, "merges_failed": 0, "errors": 0,
            "started_at": None, "last_cycle_at": None,
            "current_file": "", "status": "idle",
        }

    def start(self) -> Dict:
        with self._lock:
            if self._running and self._thread and self._thread.is_alive():
                return {"status": "already_running", "stats": self._safe_stats()}
            self._stop.clear()
            self._running = True
            self._thread  = threading.Thread(
                target=self._loop, daemon=True, name="zeus_evolution"
            )
            self._thread.start()
            log.info("[Evolution] Engine started")
            return {"status": "started",
                    "interval_s": self._CYCLE_INTERVAL}

    def stop(self) -> Dict:
        self._stop.set()
        self._running = False
        log.info("[Evolution] Stop requested")
        return {"status": "stop_requested"}

    def is_running(self) -> bool:
        return (self._running
                and bool(self._thread)
                and self._thread.is_alive())

    def get_stats(self) -> Dict:
        with self._lock:
            return self._safe_stats()

    def _safe_stats(self) -> Dict:
        s = dict(self._stats)
        s["running"] = self.is_running()
        return s

    def _loop(self):
        self._stats["started_at"] = datetime.now(timezone.utc).isoformat()
        self._stats["status"]     = "running"
        while not self._stop.is_set():
            with self._lock:
                self._stats["cycles"] += 1
                cycle = self._stats["cycles"]
            log.info(f"[Evolution] Auto-cycle {cycle}")
            try:
                report = self.run_cycle(trigger="auto")
                with self._lock:
                    self._stats["modules_scanned"] = report.modules_scanned
                    self._stats["gaps_found"]      += report.gaps_found
                    self._stats["merges_ok"]       += report.merges_ok
                    self._stats["merges_failed"]   += report.merges_failed
                    self._stats["last_cycle_at"]    = datetime.now(timezone.utc).isoformat()
            except Exception as e:
                log.error(f"[Evolution] Loop cycle error: {e}")
                with self._lock:
                    self._stats["errors"] += 1
            self._stop.wait(self._CYCLE_INTERVAL)
        self._running         = False
        self._stats["status"] = "stopped"
        log.info("[Evolution] Engine stopped")

    def run_cycle(self, skip_files: List[str] = None,
                  trigger: str = "manual",
                  max_gaps: int = 3,
                  max_fixes: int = 3) -> EvolutionReport:
        """
        Run one full evolution cycle.
        max_gaps  = max gaps addressed per module per cycle
        max_fixes = how many times a file+function can be fixed before skipping
        """
        cycle_id = uuid.uuid4().hex[:12]
        t0       = time.time()
        report   = EvolutionReport(
            cycle_id=cycle_id, trigger=trigger,
            started_at=datetime.now(timezone.utc).isoformat(),
        )
        with self._lock:
            self._stats["status"] = f"running cycle {cycle_id[:8]}"

        try:
            auditor  = ZeusAuditor()
            analyzer = GapAnalyzer()
            filler   = GapFiller()
            merger   = SafeMerger()

            modules = auditor.audit_all(skip=skip_files)
            report.modules_scanned = len(modules)

            # Shuffle to spread work across different files each cycle
            import random
            random.shuffle(modules)

            for audit in modules:
                with self._lock:
                    self._stats["current_file"] = audit.file

                if audit.error:
                    report.errors.append(f"{audit.file}: {audit.error}")
                    continue

                gaps = analyzer.analyze(audit, cycle_id=cycle_id,
                                        max_fixes=max_fixes)
                report.gaps_found += len(gaps)

                fixed_this_file = 0
                for gap in gaps[:max_gaps]:
                    if fixed_this_file >= 2:
                        break  # max 2 fixes per file per cycle
                    filled = filler.fill(audit, gap)
                    if not filled:
                        continue
                    report.gaps_filled += 1
                    gap.filled = True

                    mr = merger.merge(audit, gap, filled, cycle_id)
                    if mr.sandbox_ok:
                        report.sandbox_passes += 1
                    else:
                        report.sandbox_fails += 1

                    if mr.merged:
                        report.merges_ok += 1
                        gap.merged = True
                        fixed_this_file += 1
                        # Save to knowledge DB
                        _db.save_knowledge(
                            topic=f"evolution:{audit.file}:{gap.function}",
                            depth="Professional",
                            content=(f"Evolved {gap.gap_type} in {audit.file}/"
                                     f"{gap.function}:\n{filled[:2000]}"),
                            confidence=0.70,
                        )
                    else:
                        report.merges_failed += 1
                        if mr.error:
                            report.errors.append(
                                f"{audit.file}/{gap.function}: {mr.error}")

                    report.details.append({
                        "file":       audit.file,
                        "gap_type":   gap.gap_type,
                        "severity":   gap.severity,
                        "function":   gap.function,
                        "gap_desc":   gap.gap_desc[:100],
                        "merged":     mr.merged,
                        "versioned":  mr.versioned,
                        "sandbox_ok": mr.sandbox_ok,
                        "genome":     mr.genome_registered,
                        "error":      mr.error,
                    })

            # Logic rules
            report.new_rules = self._propose_rules(report)

        except Exception as e:
            report.errors.append(str(e))
            log.error(f"[Evolution] Cycle error: {e}")
        finally:
            report.duration_s   = round(time.time() - t0, 2)
            report.completed_at = datetime.now(timezone.utc).isoformat()
            report.status = "done" if not report.errors else "done_with_errors"
            _db.insert_report(report)
            try:
                rpath = os.path.join(
                    LOGS_DIR, f"evolution_{cycle_id}.json")
                with open(rpath, "w") as f:
                    json.dump(report.to_dict(), f, indent=2, default=str)
            except Exception:
                pass
            with self._lock:
                self._stats["status"] = report.status

        log.info(f"[Evolution] Cycle {cycle_id[:8]} done — "
                 f"{report.modules_scanned} modules, "
                 f"{report.gaps_found} gaps, "
                 f"{report.merges_ok} merges in {report.duration_s}s")
        return report

    def _propose_rules(self, report: EvolutionReport) -> int:
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            facts  = [
                LogicFact(predicate="evolution_cycle_complete",
                          args=(report.cycle_id,), source="evolution"),
                LogicFact(predicate="merges_ok_count",
                          args=(str(report.merges_ok),), source="evolution"),
            ]
            if report.merges_ok > 0:
                facts.append(LogicFact(
                    predicate="new_synthesis_result_available",
                    args=(report.cycle_id,), source="evolution"))
            return len(engine.reason(facts, auto_learn=True).conclusions)
        except Exception:
            return 0


_engine_lock:     threading.Lock                 = threading.Lock()
_engine_instance: Optional[EvolutionEngine]      = None


def get_evolution_engine() -> EvolutionEngine:
    global _engine_instance
    with _engine_lock:
        if _engine_instance is None:
            _engine_instance = EvolutionEngine()
        return _engine_instance


# Keep legacy function for backward compatibility
def run_evolution_cycle(skip_files: List[str] = None,
                        trigger: str = "manual",
                        max_gaps_per_module: int = 3) -> Dict:
    """Legacy entry point — delegates to EvolutionEngine.run_cycle()."""
    return get_evolution_engine().run_cycle(
        skip_files=skip_files, trigger=trigger,
        max_gaps=max_gaps_per_module,
    ).to_dict()


# ============================================================================
# PERMANENT EVOLUTION LOOP (PEL)
# ============================================================================

_ALL_EXTENSIONS: Set[str] = {
    ".apk",".aab",".aar",".dex",".so",".dll",".exe",".bin",".dat",
    ".jar",".class",".war",".ear",".zip",".tar",".gz",".bz2",".xz",
    ".7z",".tgz",".pdf",".docx",".doc",".odt",".rtf",
    ".py",".pyw",".js",".jsx",".mjs",".ts",".tsx",
    ".java",".kt",".kts",".swift",".go",".rs",".cs",".cpp",
    ".cc",".cxx",".c",".h",".hpp",".hxx",".rb",".php",".pl",
    ".lua",".r",".scala",".dart",".ex",".exs",".hs",".clj",
    ".sh",".bash",".zsh",".fish",".ps1",".bat",".cmd",
    ".smali",".asm",".s",".sql",".graphql",
    ".html",".htm",".xml",".css",".scss",".less",".sass",".svg",
    ".json",".yaml",".yml",".toml",".ini",".cfg",".conf",
    ".env",".csv",".tsv",".xlsx",".xls",".ods",
    ".txt",".md",".rst",".log",".nfo",".readme",".adoc",
    ".png",".jpg",".jpeg",".gif",".bmp",".tiff",".tif",
    ".webp",".ico",".heic",".raw",
    ".mp3",".wav",".ogg",".flac",".m4a",
    ".mp4",".mkv",".avi",".mov",".webm",
}

_HARVEST_QUERIES = [
    ("site:github.com (py OR js OR go OR rs OR java OR cpp OR ts OR kt) "
     "machine learning AI neural network transformer agent autonomous"),
    ("(site:github.com OR site:gitlab.com) (apk OR dex OR so OR jar OR py) "
     "flask pytorch tensorflow keras"),
    ("site:huggingface.co (py OR json OR yaml OR md OR txt) "
     "model architecture training inference"),
    ("(site:github.com OR site:gitlab.com) (json OR yaml OR toml OR sh) "
     "self-evolving autonomous AI agent architecture"),
    ("site:github.com (cpp OR c OR h OR rs OR go) "
     "embedded systems Android ARM RISC-V optimization"),
]

_perm_loop_running = False
_perm_loop_thread: Optional[threading.Thread] = None
_perm_loop_lock   = threading.RLock()
_improvement_queue: deque = deque(maxlen=10_000)
_perm_loop_stats: Dict = {
    "started_at": None, "cycles_completed": 0,
    "total_scanned": 0, "total_harvested": 0, "total_improved": 0,
    "last_cycle_at": None, "last_error": None, "phase": "idle",
}


def _local_post(path: str, payload: Dict, timeout: int = 30) -> Dict:
    import requests as _req
    try:
        r = _req.post(f"http://127.0.0.1:5000{path}",
                      json=payload, timeout=timeout)
        return r.json() if r.status_code == 200 else {"error": r.text[:200]}
    except Exception as exc:
        return {"error": str(exc)}


class InternalScanner:
    _TEXT_EXTS = {
        ".py",".pyw",".js",".ts",".jsx",".tsx",".java",".kt",
        ".go",".rs",".cs",".cpp",".c",".h",".rb",".php",
        ".lua",".sh",".bash",".sql",".html",".css",".json",
        ".yaml",".yml",".toml",".md",".txt",".rst",".xml",
        ".graphql",".dart",".scala",".hs",".clj",".r",
    }
    _CODE_EXTS = {
        ".py",".pyw",".java",".js",".ts",".go",".rs",".cs",
        ".cpp",".c",".h",".rb",".php",".lua",".sh",".bash",
    }

    def scan_directory(self) -> Dict:
        summary = {"files_found": 0, "files_readable": 0,
                   "improvements_queued": 0,
                   "by_category": defaultdict(int)}
        for root, dirs, files in os.walk(ZEUS_DIR):
            dirs[:] = [
                d for d in dirs if not d.startswith(".")
                and d not in ("evolved_modules","__pycache__","logs",
                              "uploads","backups","venv","env")
            ]
            for fname in files:
                ext   = Path(fname).suffix.lower()
                if ext not in _ALL_EXTENSIONS:
                    continue
                fpath = os.path.join(root, fname)
                summary["files_found"] += 1
                cat = ("code"    if ext in self._CODE_EXTS else
                       "text"    if ext in self._TEXT_EXTS else
                       "binary"  if ext in {".apk",".dex",".so",".dll",".exe"} else
                       "archive" if ext in {".zip",".tar",".gz",".7z"} else
                       "media"   if ext in {".mp3",".mp4",".jpg",".png"} else "data")
                summary["by_category"][cat] += 1
                try:
                    size  = os.path.getsize(fpath)
                    item  = {"file": fname, "path": fpath, "ext": ext,
                             "category": cat, "size": size, "issues": []}
                    if cat == "code" and ext == ".py":
                        self._analyse_py(fpath, fname, item)
                    elif cat in ("code","text") and ext in self._TEXT_EXTS:
                        self._analyse_text(fpath, fname, item)
                    elif cat == "archive":
                        item["issues"].append("archive_not_extracted")
                    if item["issues"]:
                        _improvement_queue.append({
                            "type": "file_scan", "source": "scanner",
                            "priority": 5 if ext == ".py" else 2, "data": item,
                        })
                        summary["improvements_queued"] += 1
                    summary["files_readable"] += 1
                except Exception as e:
                    log.debug(f"[PEL] Scan error {fname}: {e}")
        return dict(summary)

    def _analyse_py(self, fpath, fname, item):
        try:
            src  = open(fpath, encoding="utf-8", errors="replace").read()
            tree = ast.parse(src)
        except SyntaxError as e:
            item["issues"].append(f"syntax_error:{e}"); return
        except Exception:
            item["issues"].append("unreadable"); return
        fns    = sum(1 for n in ast.walk(tree)
                     if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)))
        stubs  = sum(1 for n in ast.walk(tree)
                     if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))
                     and len(n.body)==1 and isinstance(n.body[0],ast.Pass))
        todos  = src.count("TODO")+src.count("FIXME")+src.count("HACK")
        if stubs:  item["issues"].append(f"stubs:{stubs}")
        if todos:  item["issues"].append(f"todos:{todos}")
        if fns > 5 and "from typing import" not in src:
            item["issues"].append("missing_type_hints")
        if fns > 3 and "except" not in src:
            item["issues"].append("no_error_handling")

    def _analyse_text(self, fpath, fname, item):
        try:
            src   = open(fpath, encoding="utf-8", errors="replace").read(8192)
            found = [p for p in ["TODO","FIXME","PLACEHOLDER","NOT IMPLEMENTED",
                                 "stub","raise NotImplementedError"]
                     if p.lower() in src.lower()]
            if found:
                item["issues"].append(f"placeholders:{','.join(found[:3])}")
        except Exception:
            item["issues"].append("unreadable")

    def scan_knowledge_db(self) -> Dict:
        summary = {"articles_scanned":0,"low_confidence":0,"empty":0,"queued":0}
        try:
            def _do(conn):
                return conn.execute(
                    "SELECT id,topic,depth,confidence,LENGTH(content) as clen "
                    "FROM knowledge LIMIT 5000"
                ).fetchall()
            rows = _db._retry(_do)
            for r in rows:
                summary["articles_scanned"] += 1
                issues = []
                if r["clen"]  < 50:  issues.append("empty");          summary["empty"] += 1
                if (r["confidence"] or 1.0) < 0.4:
                    issues.append("low_confidence"); summary["low_confidence"] += 1
                if issues:
                    _improvement_queue.append({
                        "type":"knowledge_gap","source":"kb_scan","priority":3,
                        "data":{"id":r["id"],"topic":r["topic"],
                                "depth":r["depth"],"issues":issues},
                    })
                    summary["queued"] += 1
        except Exception as e:
            log.warning(f"[PEL] Knowledge DB scan: {e}")
        return summary

    def scan_genome_db(self) -> Dict:
        summary = {"genomes_scanned":0,"low_priority":0,"empty_code":0,"queued":0}
        try:
            def _do(conn):
                return conn.execute(
                    "SELECT id,name,module_type,priority,"
                    "LENGTH(source_code) as clen FROM genome LIMIT 5000"
                ).fetchall()
            rows = _db._retry(_do)
            for r in rows:
                summary["genomes_scanned"] += 1
                issues = []
                if (r["clen"] or 0) < 20:
                    issues.append("empty_source"); summary["empty_code"] += 1
                if (r["priority"] or 50) < 30:
                    issues.append("low_priority"); summary["low_priority"] += 1
                if issues:
                    _improvement_queue.append({
                        "type":"genome_gap","source":"genome_scan","priority":2,
                        "data":{"id":r["id"],"name":r["name"],
                                "type":r["module_type"],"issues":issues},
                    })
                    summary["queued"] += 1
        except Exception as e:
            log.warning(f"[PEL] Genome DB scan: {e}")
        return summary


class NuclearHarvester:
    _EXT_GROUPS = [
        "py js go rs java cpp ts kt dart rb php lua swift cs",
        "apk dex so bin jar class smali asm",
        "json yaml yml toml md txt rst csv sql graphql",
        "html css svg xml htm","zip tar gz bz2 xz 7z tgz",
        "pdf docx doc odt rtf","png jpg jpeg gif bmp webp ico",
    ]
    def activate(self) -> Dict:
        r = _local_post("/api/search/harvest/activate",
            {"autonomous":True,"autonomous_interval":15.0,"max_iterations":0},
            timeout=20)
        log.info(f"[PEL:Harvest] Activate → {r}"); return r
    def run_search_harvest(self, query_idx: int = 0) -> Dict:
        q    = _HARVEST_QUERIES[query_idx % len(_HARVEST_QUERIES)]
        exts = self._EXT_GROUPS[query_idx % len(self._EXT_GROUPS)]
        full = f"{q} ({' OR '.join(exts.split())})"
        r    = _local_post("/api/search",{
            "query":full,"engine":"ddg","mode":"maximum",
            "limit":500,"harvest":True,"aggressive":True,
            "depth":"mastery","use_harvest":True}, timeout=60)
        log.info(f"[PEL:Harvest] Cycle {query_idx} → {r.get('result_count','?')}")
        return r
    def run_harvest_cycle(self, max_urls: int = 10) -> Dict:
        r = _local_post("/api/search/harvest/cycle",{"max_urls":max_urls},timeout=120)
        log.info(f"[PEL:Harvest] Harvest cycle → {r}"); return r
    def learn_topic(self, topic: str) -> Dict:
        r = _local_post("/api/search/harvest/learn",{"topic":topic},timeout=60)
        log.debug(f"[PEL:Harvest] Learn '{topic}' → {r}"); return r
    def evolve_capability(self, name: str, desc: str) -> Dict:
        return _local_post("/api/search/harvest/evolve",
                           {"name":name,"description":desc},timeout=30)


class MasteryImprover:
    """Queue processor — also picks up low-mastery files from code_intelligence."""

    def process_queue(self, max_items: int = 20) -> Dict:
        stats = {"processed":0,"improved":0,"skipped":0,"errors":0}
        auditor  = ZeusAuditor()
        analyzer = GapAnalyzer()
        filler   = GapFiller()
        merger   = SafeMerger()
        cycle_id = uuid.uuid4().hex[:8]

        # Inject low-mastery Zeus .py files into queue
        try:
            for rec in _db.get_low_mastery_files(max_conf=0.60, limit=10):
                fpath = rec.get("file_path","")
                fname = os.path.basename(fpath)
                if (fname and fname not in PROTECTED_FILES
                        and os.path.isfile(fpath)
                        and fpath.endswith(".py")):
                    _improvement_queue.appendleft({
                        "type":"file_scan","source":"code_intelligence_low_mastery",
                        "priority":8,
                        "data":{"file":fname,"path":fpath,"ext":".py",
                                "category":"code","size":os.path.getsize(fpath),
                                "issues":[f"low_mastery:{rec.get('confidence',0):.2f}"]},
                    })
        except Exception as e:
            log.debug(f"[PEL:Improve] Low-mastery injection: {e}")

        for _ in range(min(max_items, len(_improvement_queue))):
            if not _improvement_queue:
                break
            item = _improvement_queue.popleft()
            stats["processed"] += 1
            try:
                itype = item.get("type","")
                if itype in ("file_scan","code_intelligence_low_mastery") \
                        and item["data"]["ext"] == ".py":
                    fname = item["data"]["file"]
                    if fname in PROTECTED_FILES:
                        stats["skipped"] += 1; continue
                    fpath = item["data"]["path"]
                    if not os.path.isfile(fpath):
                        stats["skipped"] += 1; continue
                    audit = auditor._audit_file(fpath, fname)
                    if audit and not audit.error:
                        for gap in analyzer.analyze(audit, cycle_id=cycle_id)[:2]:
                            filled = filler.fill(audit, gap)
                            if filled:
                                mr = merger.merge(audit, gap, filled, cycle_id)
                                if mr.merged:
                                    stats["improved"] += 1
                                    _perm_loop_stats["total_improved"] += 1
                elif itype == "knowledge_gap":
                    topic = item["data"].get("topic","")
                    if topic:
                        NuclearHarvester().learn_topic(topic)
                        stats["improved"] += 1
                        _perm_loop_stats["total_improved"] += 1
                elif itype == "genome_gap":
                    name = item["data"].get("name","unknown")
                    NuclearHarvester().evolve_capability(
                        name, f"Strengthen genome: {name}")
                    stats["improved"] += 1
                    _perm_loop_stats["total_improved"] += 1
                else:
                    stats["skipped"] += 1
            except Exception as e:
                stats["errors"] += 1
                log.warning(f"[PEL:Improve] Queue error: {e}")
        return stats


def run_permanent_evolution_loop(
    cycle_interval_s: float = 300.0,
    harvest_interval_s: float = 60.0,
    improve_batch: int = 15,
    auto_start_harvest: bool = True,
) -> None:
    global _perm_loop_running, _perm_loop_stats
    with _perm_loop_lock:
        if _perm_loop_running:
            log.info("[PEL] Already running"); return
        _perm_loop_running = True
    _perm_loop_stats["started_at"] = datetime.now(timezone.utc).isoformat()
    _perm_loop_stats["phase"]      = "booting"

    scanner   = InternalScanner()
    harvester = NuclearHarvester()
    improver  = MasteryImprover()

    log.info("[PEL] ╔══════════════════════════════════════════════╗")
    log.info("[PEL] ║  PERMANENT EVOLUTION LOOP — ONLINE v3.0     ║")
    log.info("[PEL] ║  Zeus Project 2026 — Francois Nel SA ID ... ║")
    log.info("[PEL] ╚══════════════════════════════════════════════╝")

    if auto_start_harvest:
        try:
            time.sleep(5); harvester.activate()
            log.info("[PEL] Harvest activated")
        except Exception as e:
            log.warning(f"[PEL] Harvest activate (non-fatal): {e}")

    query_idx = 0; last_scan = 0.0; last_harvest = 0.0

    while True:
        try:
            with _perm_loop_lock:
                if not _perm_loop_running:
                    log.info("[PEL] Stop signal — exiting"); break
            now = time.time()

            if now - last_scan >= cycle_interval_s:
                _perm_loop_stats["phase"] = "internal_scan"
                log.info("[PEL] ▶ Phase A — Internal full scan")
                try:
                    d = scanner.scan_directory()
                    k = scanner.scan_knowledge_db()
                    g = scanner.scan_genome_db()
                    scanned = (d.get("files_found",0)
                               + k.get("articles_scanned",0)
                               + g.get("genomes_scanned",0))
                    _perm_loop_stats["total_scanned"] += scanned
                    log.info(f"[PEL] Phase A: scanned={scanned}, "
                             f"queue={len(_improvement_queue)}")
                    last_scan = time.time()
                except Exception as e:
                    log.error(f"[PEL] Phase A: {e}")
                    _perm_loop_stats["last_error"] = str(e)
                # Also fire one standard evolution cycle
                try:
                    _perm_loop_stats["phase"] = "evolution_cycle"
                    get_evolution_engine().run_cycle(
                        trigger="permanent_loop", max_gaps=3)
                except Exception as e:
                    log.warning(f"[PEL] Evolution cycle (non-fatal): {e}")

            if now - last_harvest >= harvest_interval_s:
                _perm_loop_stats["phase"] = "nuclear_harvest"
                log.info(f"[PEL] ▶ Phase B — Harvest burst #{query_idx}")
                try:
                    harvester.run_search_harvest(query_idx)
                    harvester.run_harvest_cycle(max_urls=8)
                    _perm_loop_stats["total_harvested"] += 1
                    query_idx += 1; last_harvest = time.time()
                except Exception as e:
                    log.warning(f"[PEL] Phase B (non-fatal): {e}")
                    _perm_loop_stats["last_error"] = str(e)
                    last_harvest = time.time()

            if _improvement_queue:
                _perm_loop_stats["phase"] = "mastery_improvement"
                try:
                    imp = improver.process_queue(max_items=improve_batch)
                    if imp["improved"]:
                        log.info(f"[PEL] Phase C: improved={imp['improved']}, "
                                 f"queue={len(_improvement_queue)}")
                except Exception as e:
                    log.warning(f"[PEL] Phase C (non-fatal): {e}")

            _perm_loop_stats["cycles_completed"] += 1
            _perm_loop_stats["last_cycle_at"] = (
                datetime.now(timezone.utc).isoformat())
            _perm_loop_stats["phase"] = "sleeping"
            for _ in range(int(min(harvest_interval_s, 30.0))):
                with _perm_loop_lock:
                    if not _perm_loop_running: break
                time.sleep(1)

        except Exception as e:
            log.error(f"[PEL] Unexpected: {e}")
            _perm_loop_stats["last_error"] = str(e)
            time.sleep(10)

    with _perm_loop_lock:
        _perm_loop_running        = False
        _perm_loop_stats["phase"] = "stopped"
    log.info("[PEL] Permanent evolution loop stopped")


def start_permanent_evolution_loop(**kwargs) -> bool:
    global _perm_loop_thread
    with _perm_loop_lock:
        if _perm_loop_running: return False
    t = threading.Thread(target=run_permanent_evolution_loop,
                         kwargs=kwargs, daemon=True,
                         name="permanent_evolution_loop")
    _perm_loop_thread = t; t.start()
    log.info("[PEL] Daemon thread started"); return True


def stop_permanent_evolution_loop() -> bool:
    with _perm_loop_lock:
        global _perm_loop_running
        if not _perm_loop_running: return False
        _perm_loop_running = False
    log.info("[PEL] Stop signal sent"); return True


# ============================================================================
# FLASK BLUEPRINT — REST API
# ============================================================================

@evolution_bp.route("/api/evolution/health")
def ev_health():
    engine = get_evolution_engine()
    return jsonify({
        "status":   "ok",
        "module":   "zeus_self_evolution",
        "version":  "v3.0",
        "running":  engine.is_running(),
        "llm_free": True,
        "project":  "The Zeus Project 2026",
        "architect":"Francois Nel SA ID 8708275089084",
    })


@evolution_bp.route("/api/evolution/start", methods=["POST"])
def ev_start():
    return jsonify(get_evolution_engine().start())


@evolution_bp.route("/api/evolution/stop", methods=["POST"])
def ev_stop():
    return jsonify(get_evolution_engine().stop())


@evolution_bp.route("/api/evolution/trigger", methods=["POST"])
def ev_trigger():
    """Immediately run one cycle (non-blocking)."""
    data = request.get_json(silent=True) or {}
    def _run():
        get_evolution_engine().run_cycle(
            skip_files=data.get("skip_files", []),
            trigger="api_trigger",
            max_gaps=int(data.get("max_gaps_per_module", 3)),
        )
    threading.Thread(target=_run, daemon=True, name="ev_trigger").start()
    return jsonify({"status": "triggered",
                    "poll":   "/api/evolution/status"})


@evolution_bp.route("/api/evolution/status")
def ev_status():
    engine = get_evolution_engine()
    return jsonify({
        "running":      engine.is_running(),
        "engine_stats": engine.get_stats(),
        "pel_running":  _perm_loop_running,
        "pel_stats":    _perm_loop_stats,
        "queue_depth":  len(_improvement_queue),
        "version":      "v3.0",
    })


@evolution_bp.route("/api/evolution/history")
def ev_history():
    limit = min(int(request.args.get("limit", 20)), 200)
    try:
        return jsonify({
            "history": _db.get_history(limit),
            "count":   limit,
        })
    except Exception as e:
        return jsonify({"error": str(e), "history": [], "count": 0}), 500


@evolution_bp.route("/api/evolution/stats")
def ev_stats():
    try:
        s = _db.get_stats()
        s["pel_running"]    = _perm_loop_running
        s["queue_depth"]    = len(_improvement_queue)
        s["evolved_dir"]    = EVOLVED_DIR
        s["protected_files"]= sorted(PROTECTED_FILES)
        s["llm_free"]       = True
        with threading.Lock():
            s["engine_running"] = get_evolution_engine().is_running()
        return jsonify(s)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@evolution_bp.route("/api/evolution/evolved")
def ev_evolved():
    try:
        files = []
        for fname in sorted(os.listdir(EVOLVED_DIR), reverse=True)[:50]:
            fpath = os.path.join(EVOLVED_DIR, fname)
            if os.path.isfile(fpath):
                files.append({
                    "filename": fname,
                    "size_kb":  round(os.path.getsize(fpath) / 1024, 1),
                    "modified": datetime.fromtimestamp(
                        os.path.getmtime(fpath),
                        tz=timezone.utc).isoformat(),
                })
        return jsonify({"files": files, "count": len(files)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@evolution_bp.route("/api/evolution/audit")
def ev_audit():
    """Dry-run: audit + gap detection, no merging."""
    try:
        auditor  = ZeusAuditor()
        analyzer = GapAnalyzer()
        modules  = auditor.audit_all()
        results  = []
        for audit in modules[:20]:
            gaps = analyzer.analyze(audit) if not audit.error else []
            results.append({
                **audit.to_dict(),
                "gaps":      [g.to_dict() for g in gaps],
                "gap_count": len(gaps),
            })
        return jsonify({
            "modules":    results,
            "total":      len(modules),
            "total_gaps": sum(r["gap_count"] for r in results),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@evolution_bp.route("/api/evolution/functions")
def ev_functions():
    """List all tracked evolved file+function pairs."""
    try:
        return jsonify({
            "evolved_functions": _db.get_evolved_functions(100),
            "note": "fix_count >= 3 means this function is skip-listed",
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@evolution_bp.route("/api/evolution/intelligence")
def ev_intelligence():
    """Cross-reference Zeus modules with code_intelligence mastery."""
    try:
        zeus_files   = [f for f in os.listdir(ZEUS_DIR) if f.endswith('.py')]
        unanalyzed   = []
        low_mastery  = []
        mastered     = []
        for fname in sorted(zeus_files):
            if fname in PROTECTED_FILES:
                continue
            fpath  = os.path.join(ZEUS_DIR, fname)
            stage, conf = _db.get_mastery_level(fpath)
            entry  = {"file": fname, "mastery": stage, "confidence": conf}
            if stage   == "Unknown":  unanalyzed.append(entry)
            elif stage != "Mastery":  low_mastery.append(entry)
            else:                     mastered.append(entry)
        return jsonify({
            "mastery_stages":  DEPTHS,
            "mastered":        mastered,
            "low_mastery":     low_mastery,
            "unanalyzed":      unanalyzed,
            "unanalyzed_count": len(unanalyzed),
            "recommendation":  (
                "POST /api/code_learner/start to analyze unanalyzed modules"
            ),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# PEL routes

@evolution_bp.route("/api/evolution/permanent/start", methods=["POST"])
def ev_pel_start():
    data    = request.get_json(silent=True) or {}
    started = start_permanent_evolution_loop(
        cycle_interval_s=float(data.get("cycle_interval_s", 300.0)),
        harvest_interval_s=float(data.get("harvest_interval_s", 60.0)),
        improve_batch=int(data.get("improve_batch", 15)),
        auto_start_harvest=bool(data.get("auto_start_harvest", True)),
    )
    return jsonify({
        "status": "started" if started else "already_running",
        "poll":   "/api/evolution/permanent/status",
    })


@evolution_bp.route("/api/evolution/permanent/stop", methods=["POST"])
def ev_pel_stop():
    return jsonify({
        "status": "stopping" if stop_permanent_evolution_loop() else "not_running"
    })


@evolution_bp.route("/api/evolution/permanent/status")
def ev_pel_status():
    with _perm_loop_lock:
        running = _perm_loop_running
    return jsonify({
        "running":      running,
        "queue_depth":  len(_improvement_queue),
        "stats":        _perm_loop_stats,
        "thread_alive": (_perm_loop_thread is not None
                         and _perm_loop_thread.is_alive()),
    })


@evolution_bp.route("/api/evolution/permanent/queue")
def ev_pel_queue():
    return jsonify({
        "queue_depth": len(_improvement_queue),
        "preview":     list(_improvement_queue)[:50],
    })


@evolution_bp.route("/api/evolution/permanent/scan", methods=["POST"])
def ev_pel_scan():
    def _do():
        sc = InternalScanner()
        log.info(f"[PEL] On-demand: "
                 f"dir={sc.scan_directory()}, "
                 f"kb={sc.scan_knowledge_db()}, "
                 f"genome={sc.scan_genome_db()}")
    threading.Thread(target=_do, daemon=True, name="pel_scan_now").start()
    return jsonify({"status": "scan_started"})


@evolution_bp.route("/api/evolution/permanent/harvest", methods=["POST"])
def ev_pel_harvest():
    data = request.get_json(silent=True) or {}
    idx  = int(data.get("query_index", 0))
    def _do():
        h = NuclearHarvester()
        h.run_search_harvest(idx)
        h.run_harvest_cycle(max_urls=10)
    threading.Thread(target=_do, daemon=True, name="pel_harvest_now").start()
    return jsonify({"status": "harvest_burst_started", "query_index": idx})


# ============================================================================
# SELF-REGISTRATION HELPER (mirrors zeus_code_learner pattern)
# ============================================================================

def patch_app_py() -> Dict:
    """Safe one-time patch of app.py to register evolution_bp. Idempotent."""
    app_path = os.path.join(ZEUS_DIR, "app.py")
    if not os.path.isfile(app_path):
        return {"error": "app.py not found"}
    content = open(app_path, encoding="utf-8").read()
    if "zeus_self_evolution" in content:
        return {"status": "already_registered", "skipped": True}
    ts      = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    bak     = f"{app_path}.bak_{ts}"
    shutil.copy2(app_path, bak)
    inject  = '    _loaded += _register("zeus_self_evolution",     "evolution_bp")'
    target  = '_loaded += _register("zeus_recursive_learner"'
    if target not in content:
        target = '_loaded += _register("zeus_search"'
    if target not in content:
        return {"error": "Injection point not found", "backup": bak}
    new = content.replace(target, inject + "\n    " + target)
    open(app_path, "w", encoding="utf-8").write(new)
    try:
        import subprocess as _sp
        r = _sp.run(["python3", "-m", "py_compile", app_path],
                    capture_output=True, timeout=15)
        if r.returncode != 0:
            raise RuntimeError(r.stderr.decode(errors="replace"))
    except Exception as e:
        shutil.copy2(bak, app_path)
        return {"error": f"Syntax check failed — reverted: {e}", "backup": bak}
    log.info(f"[Evolution] app.py patched. Backup: {bak}")
    return {"status": "patched", "injected": inject, "backup": bak}


@evolution_bp.route("/api/evolution/self_register", methods=["POST"])
def ev_self_register():
    return jsonify(patch_app_py())


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(evolution_bp)
    log.info("[self_evolution] v3.0 registered — /api/evolution (LLM-free)")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_self_evolution",
            blueprint_var="evolution_bp",
            url_prefix="/api/evolution",
            version="3.0",
            description=(
                "Self-evolution v3.0: AST audit → mastery-aware gap detection "
                "→ LLM-free fill (code_intelligence/knowledge/genome/templates) "
                "→ sandbox validate → safe merge → genome register. "
                "Infinite-loop proof via evolved_functions tracking."
            ),
            capabilities=[
                {"id": "evolution.health",    "endpoint": "/api/evolution/health",    "method": "GET",  "tags": ["health"]},
                {"id": "evolution.start",     "endpoint": "/api/evolution/start",     "method": "POST", "tags": ["evolution"]},
                {"id": "evolution.stop",      "endpoint": "/api/evolution/stop",      "method": "POST", "tags": ["evolution"]},
                {"id": "evolution.trigger",   "endpoint": "/api/evolution/trigger",   "method": "POST", "tags": ["evolution"]},
                {"id": "evolution.status",    "endpoint": "/api/evolution/status",    "method": "GET",  "tags": ["evolution"]},
                {"id": "evolution.history",   "endpoint": "/api/evolution/history",   "method": "GET",  "tags": ["evolution","history"]},
                {"id": "evolution.stats",     "endpoint": "/api/evolution/stats",     "method": "GET",  "tags": ["stats"]},
                {"id": "evolution.audit",     "endpoint": "/api/evolution/audit",     "method": "GET",  "tags": ["evolution","audit"]},
                {"id": "evolution.evolved",   "endpoint": "/api/evolution/evolved",   "method": "GET",  "tags": ["evolution"]},
                {"id": "evolution.functions", "endpoint": "/api/evolution/functions", "method": "GET",  "tags": ["evolution"]},
                {"id": "evolution.intelligence","endpoint":"/api/evolution/intelligence","method":"GET", "tags": ["evolution","intelligence"]},
                {"id": "evolution.pel.start", "endpoint": "/api/evolution/permanent/start",  "method": "POST", "tags": ["evolution","pel"]},
                {"id": "evolution.pel.stop",  "endpoint": "/api/evolution/permanent/stop",   "method": "POST", "tags": ["evolution","pel"]},
                {"id": "evolution.pel.status","endpoint": "/api/evolution/permanent/status", "method": "GET",  "tags": ["evolution","pel"]},
                {"id": "evolution.pel.queue", "endpoint": "/api/evolution/permanent/queue",  "method": "GET",  "tags": ["evolution","pel"]},
                {"id": "evolution.pel.scan",  "endpoint": "/api/evolution/permanent/scan",   "method": "POST", "tags": ["evolution","pel"]},
                {"id": "evolution.pel.harvest","endpoint":"/api/evolution/permanent/harvest","method": "POST", "tags": ["evolution","pel"]},
            ],
            depends_on=["zeus_sandbox", "genome_manager", "logic_engine"],
            boot_order=70,
        )
    except Exception:
        pass
    # Auto-start PEL 3 seconds after registration
    def _start_pel():
        time.sleep(3)
        log.info("[Evolution] Auto-starting permanent evolution loop")
        start_permanent_evolution_loop(
            cycle_interval_s=300.0,
            harvest_interval_s=60.0,
            improve_batch=15,
            auto_start_harvest=True,
        )
    threading.Thread(target=_start_pel, daemon=True,
                     name="pel_autostart").start()


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG,
                        format="%(asctime)s %(levelname)s — %(message)s")
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5022, debug=True, use_reloader=False)


# ============================================================================
# BOOT
# ============================================================================

def _boot():
    try:
        _db.ensure_schema()
        log.info(
            "[Evolution] v3.0 schema ready — "
            f"protected={len(PROTECTED_FILES)} files · "
            f"LLM-free · infinite-loop-proof · "
            "The Zeus Project 2026 — Francois Nel SA ID 8708275089084"
        )
    except Exception as e:
        log.error(f"[Evolution] Boot error: {e}")


_boot()
