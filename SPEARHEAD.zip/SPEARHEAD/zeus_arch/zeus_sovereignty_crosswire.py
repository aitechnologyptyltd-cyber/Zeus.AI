# The Zeus Project 2026 — Francois Nel SA ID 8708275089084
# zeus_sovereignty_crosswire.py — Cross-System Sovereignty Build Bridge v1.0
# ============================================================================
#
# This module enables Zeus to scan, understand, and build upon ALL sub-systems:
#   - UMP Universal Miner (miner_swarm, profit_switcher, pool configs)
#   - Aegis Firewall (detection rules, filter modules, response handlers)
#   - AutoTrader Pro (signal modules, risk layers, backtesting)
#   - Zeus Architecture itself (any of the 37+ core modules)
#
# Zeus uses this module to:
#   1. Scan each sub-system and build a capability map
#   2. Identify gaps, low-fitness modules, or missing capabilities
#   3. Select the best existing module as a base blueprint
#   4. Synthesise a new/improved module via the Sovereignty Engine
#   5. Test in sandbox (Ring 2 — always autonomous)
#   6. Deploy via Ring gate (Ring 1 for Zeus, Ring 5 for UMP/Aegis/Trader)
#   7. Archive old version, register new version in genome
#
# APP.PY REGISTRATION:
#   _loaded += _register("zeus_sovereignty_crosswire", "crosswire_bp")
#
# API ROUTES:
#   GET  /api/sovereignty/crosswire/systems          — all sub-system scan results
#   POST /api/sovereignty/crosswire/scan/<system>    — scan a specific sub-system
#   GET  /api/sovereignty/crosswire/gaps             — identified gaps across all systems
#   POST /api/sovereignty/crosswire/build            — trigger cross-system build
#   GET  /api/sovereignty/crosswire/builds           — cross-system build history
# ============================================================================

from __future__ import annotations

import ast
import json
import logging
import os
import re
import sqlite3
import threading
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.crosswire")

crosswire_bp = Blueprint("crosswire", __name__)

ZEUS_DIR   = os.path.dirname(os.path.abspath(__file__))
HIVE_DIR   = os.path.dirname(ZEUS_DIR)
DB_PATH    = os.path.join(ZEUS_DIR, "zeus.db")

# Sub-system directory mapping
SUBSYSTEM_DIRS = {
    "zeus":    ZEUS_DIR,
    "ump":     os.path.join(HIVE_DIR, "ump"),
    "aegis":   os.path.join(HIVE_DIR, "aegis"),
    "trader":  os.path.join(HIVE_DIR, "ump"),  # trader lives in UMP dir
    "hive":    HIVE_DIR,
}

# Module prefixes per sub-system
SUBSYSTEM_PREFIXES = {
    "zeus":   ["zeus_", "genome_", "logic_", "db_", "app", "wsgi"],
    "ump":    ["miner_", "ump_", "universal_", "pool_", "profit_"],
    "aegis":  ["aegis_", "zeus_aegis", "zeus_firewall"],
    "trader": ["ump_autonomous_trader", "trader_", "signal_"],
}

# ─── DB INIT ─────────────────────────────────────────────────────────────────

def _init_db():
    con = sqlite3.connect(DB_PATH)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS crosswire_scans (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id    TEXT UNIQUE NOT NULL,
            system     TEXT NOT NULL,
            module_count INTEGER DEFAULT 0,
            gap_count    INTEGER DEFAULT 0,
            result_json  TEXT,
            scanned_at   TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS crosswire_gaps (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            gap_id      TEXT UNIQUE NOT NULL,
            system      TEXT NOT NULL,
            module      TEXT NOT NULL,
            gap_type    TEXT NOT NULL,
            description TEXT NOT NULL,
            priority    INTEGER DEFAULT 50,
            status      TEXT DEFAULT 'open',
            build_id    TEXT,
            found_at    TEXT NOT NULL,
            resolved_at TEXT
        );

        CREATE TABLE IF NOT EXISTS crosswire_builds (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            build_id     TEXT UNIQUE NOT NULL,
            system       TEXT NOT NULL,
            goal         TEXT NOT NULL,
            gap_id       TEXT,
            base_module  TEXT,
            status       TEXT DEFAULT 'pending',
            result_json  TEXT,
            created_at   TEXT NOT NULL,
            completed_at TEXT
        );
    """)
    con.commit()
    con.close()

_init_db()


# ─── SYSTEM SCANNER ──────────────────────────────────────────────────────────

class CrosswireEngine:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialised = False
        return cls._instance

    def __init__(self):
        if self._initialised:
            return
        self._initialised = True
        self._scan_cache: Dict[str, Dict] = {}
        log.info("[crosswire] Cross-system sovereignty bridge online")

    def scan_system(self, system: str) -> Dict:
        """
        Scan a sub-system directory and build a full capability map.
        Ring 3 — read-only host scan, always autonomous.
        """
        sys_dir = SUBSYSTEM_DIRS.get(system)
        if not sys_dir or not os.path.isdir(sys_dir):
            return {"error": "system dir not found: " + str(sys_dir)}

        scan_id = "xscan_" + uuid.uuid4().hex[:8]
        modules = []
        gaps    = []
        prefixes = SUBSYSTEM_PREFIXES.get(system, [])

        for fname in os.listdir(sys_dir):
            if not fname.endswith(".py"):
                continue
            # Filter by prefix if prefixes defined
            if prefixes and not any(fname.startswith(p) for p in prefixes):
                continue
            fpath = os.path.join(sys_dir, fname)
            mod_info = self._analyse_module(fpath)
            mod_info["system"] = system
            modules.append(mod_info)
            # Identify gaps
            mod_gaps = self._identify_gaps(mod_info)
            gaps.extend(mod_gaps)

        result = {
            "scan_id":      scan_id,
            "system":       system,
            "directory":    sys_dir,
            "module_count": len(modules),
            "gap_count":    len(gaps),
            "modules":      modules,
            "gaps":         gaps,
            "scanned_at":   datetime.now(timezone.utc).isoformat(),
        }
        self._scan_cache[system] = result

        # Persist to DB
        try:
            con = sqlite3.connect(DB_PATH)
            con.execute(
                "INSERT OR REPLACE INTO crosswire_scans "
                "(scan_id, system, module_count, gap_count, result_json, scanned_at) "
                "VALUES (?,?,?,?,?,?)",
                (scan_id, system, len(modules), len(gaps),
                 json.dumps({"modules": [m["name"] for m in modules],
                             "gap_types": [g["gap_type"] for g in gaps]}),
                 result["scanned_at"])
            )
            for gap in gaps:
                con.execute(
                    "INSERT OR IGNORE INTO crosswire_gaps "
                    "(gap_id, system, module, gap_type, description, priority, found_at) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (gap["gap_id"], system, gap["module"],
                     gap["gap_type"], gap["description"],
                     gap["priority"], result["scanned_at"])
                )
            con.commit()
            con.close()
        except Exception as exc:
            log.error("[crosswire] DB persist error: %s", exc)

        log.info("[crosswire] scanned %s: %d modules, %d gaps",
                 system, len(modules), len(gaps))
        return result

    def _analyse_module(self, fpath: str) -> Dict:
        """Analyse a single Python module for structure and quality."""
        fname = os.path.basename(fpath)
        info = {
            "name":       fname,
            "path":       fpath,
            "size":       0,
            "lines":      0,
            "functions":  0,
            "classes":    0,
            "has_flask":  False,
            "has_db":     False,
            "has_stubs":  False,
            "has_fstrings": False,
            "has_walrus": False,
            "has_author": False,
            "quality_score": 0.0,
            "issues":     [],
        }
        try:
            size = os.path.getsize(fpath)
            info["size"] = size
            with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                code = f.read(65536)  # read up to 64KB
            lines = code.splitlines()
            info["lines"] = len(lines)
            # Author header check
            if "Francois Nel SA ID 8708275089084" in code:
                info["has_author"] = True
            else:
                info["issues"].append("missing_author_header")
            # Flask check
            if "Blueprint" in code or "flask" in code.lower():
                info["has_flask"] = True
            # DB check
            if "sqlite3" in code or "SQLite" in code:
                info["has_db"] = True
            # armv7l safety
            if ":=" in code:
                info["has_walrus"] = True
                info["issues"].append("walrus_operator")
            fstring_count = code.count('f"') + code.count("f'")
            if fstring_count > 0:
                info["has_fstrings"] = True
                info["issues"].append("fstrings_x" + str(fstring_count))
            # Stub detection
            stub_patterns = ["pass  # TODO", "# TODO", "# STUB", "raise NotImplementedError",
                              '"""TODO"""', "pass\n    # stub"]
            for pat in stub_patterns:
                if pat in code:
                    info["has_stubs"] = True
                    info["issues"].append("stubs_detected")
                    break
            # AST analysis
            try:
                tree = ast.parse(code)
                info["functions"] = sum(1 for n in ast.walk(tree)
                                        if isinstance(n, ast.FunctionDef))
                info["classes"]   = sum(1 for n in ast.walk(tree)
                                        if isinstance(n, ast.ClassDef))
            except SyntaxError as se:
                info["issues"].append("syntax_error:" + str(se)[:50])
            # Quality score
            deductions = len(info["issues"]) * 0.10
            info["quality_score"] = round(max(0.0, 1.0 - deductions), 2)
        except Exception as exc:
            info["issues"].append("read_error:" + str(exc)[:50])
        return info

    def _identify_gaps(self, mod_info: Dict) -> List[Dict]:
        """Identify improvement opportunities in a module."""
        gaps = []
        fname = mod_info["name"]
        now   = datetime.now(timezone.utc).isoformat()

        if mod_info.get("has_stubs"):
            gaps.append({
                "gap_id":      "gap_" + uuid.uuid4().hex[:8],
                "module":      fname,
                "gap_type":    "stubs",
                "description": "Module contains stubs or TODOs — needs full implementation",
                "priority":    90,
            })
        if mod_info.get("has_fstrings"):
            gaps.append({
                "gap_id":      "gap_" + uuid.uuid4().hex[:8],
                "module":      fname,
                "gap_type":    "armv7l_unsafe_fstrings",
                "description": "Module uses f-strings — not armv7l safe",
                "priority":    70,
            })
        if mod_info.get("has_walrus"):
            gaps.append({
                "gap_id":      "gap_" + uuid.uuid4().hex[:8],
                "module":      fname,
                "gap_type":    "armv7l_unsafe_walrus",
                "description": "Module uses walrus operator := — not armv7l safe",
                "priority":    70,
            })
        if not mod_info.get("has_author"):
            gaps.append({
                "gap_id":      "gap_" + uuid.uuid4().hex[:8],
                "module":      fname,
                "gap_type":    "missing_author",
                "description": "Module missing Francois Nel SA ID 8708275089084 author header",
                "priority":    50,
            })
        if mod_info.get("quality_score", 1.0) < 0.60:
            gaps.append({
                "gap_id":      "gap_" + uuid.uuid4().hex[:8],
                "module":      fname,
                "gap_type":    "low_quality",
                "description": "Module quality score {:.2f} below threshold 0.60".format(
                    mod_info.get("quality_score", 0.0)),
                "priority":    80,
            })
        return gaps

    def scan_all_systems(self) -> Dict:
        """Scan all known sub-systems and aggregate results."""
        results = {}
        total_gaps = 0
        for system in SUBSYSTEM_DIRS:
            result = self.scan_system(system)
            results[system] = {
                "module_count": result.get("module_count", 0),
                "gap_count":    result.get("gap_count", 0),
                "scan_id":      result.get("scan_id", ""),
            }
            total_gaps += result.get("gap_count", 0)
        return {"systems": results, "total_gaps": total_gaps}

    def get_all_gaps(self, system: Optional[str] = None,
                     status: str = "open",
                     limit: int = 50) -> List[Dict]:
        """Return all identified gaps across systems."""
        try:
            con = sqlite3.connect(DB_PATH)
            con.row_factory = sqlite3.Row
            if system:
                rows = con.execute(
                    "SELECT * FROM crosswire_gaps WHERE system=? AND status=? "
                    "ORDER BY priority DESC, id DESC LIMIT ?",
                    (system, status, limit)
                ).fetchall()
            else:
                rows = con.execute(
                    "SELECT * FROM crosswire_gaps WHERE status=? "
                    "ORDER BY priority DESC, id DESC LIMIT ?",
                    (status, limit)
                ).fetchall()
            con.close()
            return [dict(r) for r in rows]
        except Exception as exc:
            log.error("[crosswire] get_gaps error: %s", exc)
            return []

    def trigger_build(self, system: str, goal: str,
                      gap_id: Optional[str] = None,
                      base_module: Optional[str] = None) -> Dict:
        """
        Trigger the Sovereignty Engine to build a new module for a sub-system.
        Routes through Ring gate — Ring 1 for zeus, Ring 5 for external systems.
        """
        try:
            from zeus_sovereignty_engine import get_engine as _get_sov
            sov = _get_sov()
        except ImportError:
            return {"error": "sovereignty engine not available"}

        build_id = "xbuild_" + uuid.uuid4().hex[:10]
        log.info("[crosswire] triggering build: system=%s goal=%s", system, goal[:60])

        # Map system to target dir
        sys_dir = SUBSYSTEM_DIRS.get(system, ZEUS_DIR)

        # Run in background thread
        def _run():
            result = sov.synthesise_new_module(goal, system, base_module)
            now = datetime.now(timezone.utc).isoformat()
            try:
                con = sqlite3.connect(DB_PATH)
                con.execute(
                    "INSERT OR REPLACE INTO crosswire_builds "
                    "(build_id, system, goal, gap_id, base_module, status, "
                    "result_json, created_at, completed_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (build_id, system, goal[:200], gap_id or "",
                     base_module or "", result.get("status", "unknown"),
                     json.dumps(result)[:5000], now, now)
                )
                if gap_id and result.get("status") == "deployed":
                    con.execute(
                        "UPDATE crosswire_gaps SET status='resolved', "
                        "build_id=?, resolved_at=? WHERE gap_id=?",
                        (result.get("build_id", ""), now, gap_id)
                    )
                con.commit()
                con.close()
            except Exception as exc:
                log.error("[crosswire] build persist error: %s", exc)

        import threading as _th
        t = _th.Thread(target=_run, daemon=True,
                        name="crosswire-build-" + system + "-" + goal[:15])
        t.start()

        return {"build_id": build_id, "status": "building",
                "system": system, "goal": goal,
                "message": "Cross-system build started. Check /api/sovereignty/crosswire/builds"}


def get_crosswire_engine() -> CrosswireEngine:
    return CrosswireEngine()


# ─── FLASK ROUTES ─────────────────────────────────────────────────────────────

@crosswire_bp.route("/api/sovereignty/crosswire/systems", methods=["GET"])
def api_systems():
    eng = get_crosswire_engine()
    # Return cached scans
    result = {}
    for system, sys_dir in SUBSYSTEM_DIRS.items():
        cached = eng._scan_cache.get(system, {})
        result[system] = {
            "directory":    sys_dir,
            "exists":       os.path.isdir(sys_dir),
            "module_count": cached.get("module_count", 0),
            "gap_count":    cached.get("gap_count", 0),
            "last_scan":    cached.get("scanned_at", "never"),
        }
    return jsonify({"systems": result})

@crosswire_bp.route("/api/sovereignty/crosswire/scan/<system>", methods=["POST"])
def api_scan(system):
    if system not in SUBSYSTEM_DIRS and system != "all":
        return jsonify({"error": "unknown system: " + system}), 400
    eng = get_crosswire_engine()
    if system == "all":
        result = eng.scan_all_systems()
    else:
        result = eng.scan_system(system)
    return jsonify(result)

@crosswire_bp.route("/api/sovereignty/crosswire/gaps", methods=["GET"])
def api_gaps():
    system = request.args.get("system")
    status = request.args.get("status", "open")
    limit  = int(request.args.get("limit", 50))
    eng    = get_crosswire_engine()
    gaps   = eng.get_all_gaps(system=system, status=status, limit=limit)
    return jsonify({"gaps": gaps, "count": len(gaps)})

@crosswire_bp.route("/api/sovereignty/crosswire/build", methods=["POST"])
def api_build():
    data        = request.get_json(silent=True) or {}
    system      = data.get("system", "zeus")
    goal        = data.get("goal", "").strip()
    gap_id      = data.get("gap_id")
    base_module = data.get("base_module")
    if not goal:
        return jsonify({"error": "goal required"}), 400
    eng    = get_crosswire_engine()
    result = eng.trigger_build(system, goal, gap_id, base_module)
    return jsonify(result)

@crosswire_bp.route("/api/sovereignty/crosswire/builds", methods=["GET"])
def api_builds():
    limit = int(request.args.get("limit", 20))
    try:
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT * FROM crosswire_builds ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
        con.close()
        return jsonify({"builds": [dict(r) for r in rows]})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500
