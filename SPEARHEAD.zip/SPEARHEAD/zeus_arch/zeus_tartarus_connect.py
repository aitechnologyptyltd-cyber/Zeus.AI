"""
zeus_tartarus_connect.py
The Zeus Project 2026 — Francois Nel

TARTARUS PHASE 3 — CONNECT
Mathematical DNA bridge engine.

Given two phenomena (or a raw dataset), CONNECT discovers:
  - Shared mathematical principles (with genius attribution)
  - Unexpected cross-domain links
  - Emergent patterns that only appear in the union
  - A unified governing equation spanning both phenomena

Modes:
  DUAL     — two named phenomena (phenomenon A ↔ phenomenon B)
  DATASET  — raw numeric or textual dataset (finds hidden structure)
  MULTI    — three or more phenomena (finds universal attractor)

All results:
  - Push connections into TartarusMemory.pool.connections
  - Feed logic_engine inference graph as bidirectional edges
  - Feed zeus_prediction_engine as cross-domain priors
  - Feed zeus_self_evolution as synthesis candidates

Flask blueprint: connect_bp at /api/tartarus/connect/*

armv7l compatible: no f-strings, no walrus operator.
"""

from __future__ import print_function

import os
import sys
import json
import time
import logging
import threading
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.tartarus.connect")

connect_bp = Blueprint("tartarus_connect", __name__)

EXAMPLE_PAIRS = [
    ("Heartbeat", "Stock crash"),
    ("Criminal behavior", "Weather"),
    ("Music", "Architecture"),
    ("DNA replication", "Internet routing"),
    ("Sleep cycles", "Economic cycles"),
    ("Bird flocking", "Traffic flow"),
    ("Bitcoin mining", "Neural evolution"),
    ("Immune system", "Cybersecurity"),
    ("Language entropy", "Market volatility"),
    ("Predator-prey dynamics", "Supply and demand"),
]

CONNECT_SCHEMA = json.dumps({
    "title": "string",
    "connectionStrength": 0.8,
    "sharedMathDNA": [
        {
            "principle": "string",
            "genius": "string",
            "inA": "string",
            "inB": "string",
            "equation": "string",
        }
    ],
    "unexpectedLinks": [
        {
            "link": "string",
            "sharedEquation": "string",
            "insight": "string",
            "noveltyScore": 0.9,
        }
    ],
    "emergentPattern": "string",
    "unifiedEquation": "string",
    "deepestConnection": "string",
    "universalAttractor": "string",
})

MULTI_SCHEMA = json.dumps({
    "title": "string",
    "universalPrinciple": "string",
    "sharedTopology": "string",
    "unifiedEquation": "string",
    "connectionMatrix": [
        {
            "pair": "string",
            "bridge": "string",
            "strength": 0.8,
        }
    ],
    "emergentSupraPattern": "string",
    "tartarusInsight": "string",
})

DATASET_SCHEMA = json.dumps({
    "dataType": "string",
    "dominantStructure": "string",
    "hiddenPatterns": [
        {
            "pattern": "string",
            "equation": "string",
            "confidence": 0.8,
            "significance": "string",
        }
    ],
    "governingLaw": "string",
    "anomalies": [
        {"position": "string", "description": "string", "mathematicalBasis": "string"}
    ],
    "predictiveModel": "string",
    "unifiedEquation": "string",
})


def _wire_connections_to_zeus(connections, phenomena):
    """Feed discovered connections into Zeus logic and prediction engines."""
    try:
        from logic_engine import get_engine as get_logic
        le = get_logic()
        for conn in connections:
            if hasattr(le, "add_inference"):
                le.add_inference(
                    premise=phenomena[0] if phenomena else "",
                    conclusion=phenomena[1] if len(phenomena) > 1 else "",
                    rule=conn.get("equation",
                                  conn.get("sharedEquation", "")),
                    confidence=conn.get("strength", 0.7),
                )
    except Exception:
        pass

    try:
        from zeus_prediction_engine import get_engine
        eng = get_engine()
        for conn in connections:
            if hasattr(eng, "store_cross_domain_prior"):
                eng.store_cross_domain_prior({
                    "source": "tartarus_connect",
                    "phenomena": phenomena,
                    "connection": conn,
                    "ts": time.time(),
                })
    except Exception:
        pass

    try:
        from zeus_self_evolution import get_evolution_engine
        evo = get_evolution_engine()
        if hasattr(evo, "ingest_synthesis_candidate"):
            for conn in connections:
                evo.ingest_synthesis_candidate({
                    "source": "tartarus_connect",
                    "type": "cross_domain_bridge",
                    "phenomena": phenomena,
                    "principle": conn.get("principle", conn.get("link", "")),
                    "ts": time.time(),
                })
    except Exception:
        pass


def run_connect_dual(phenomenon_a, phenomenon_b, context=""):
    """Run dual-mode connection analysis."""
    from zeus_tartarus_core import TartarusMemory, tartarus_call, compute_weights

    mem = TartarusMemory.get()
    mem.set_phase("p3", "active")
    mem.broadcast("connect", "CONNECTING",
                  phenomenon_a + " <-> " + phenomenon_b)

    prompt = (
        "PHASE 3 CONNECT: Find ALL mathematical DNA connections between "
        "\"" + phenomenon_a + "\" and \"" + phenomenon_b + "\". "
        "Go beyond the obvious — find the deepest shared mathematical "
        "structures, hidden topological similarities, identical "
        "differential equations appearing in different domains, and "
        "surprising connections that no standard analysis would reveal. "
        "Attribute every principle to its originating mathematician or physicist. "
        "Derive a single unified equation that governs both phenomena."
    )

    result = tartarus_call(
        prompt,
        schema_hint=CONNECT_SCHEMA,
        context=context,
        max_tokens=2000,
    )

    if "error" in result:
        mem.set_phase("p3", "error")
        mem.broadcast("connect", "ERROR", result["error"])
        return result

    all_connections = (
        (result.get("sharedMathDNA") or []) +
        (result.get("unexpectedLinks") or [])
    )
    mem.push_many("connections", all_connections, source="connect")

    weights = compute_weights(result, source="direct")
    weights["label"] = phenomenon_a + " <-> " + phenomenon_b
    mem.push("weights", weights, source="connect")

    mem.set_phase("p3", "done")
    mem.broadcast("connect", "CONNECT_COMPLETE",
                  result.get("emergentPattern", ""))

    mem.save_session(
        phenomenon_a + " | " + phenomenon_b,
        "p3_connect_dual",
        result,
        engine=result.get("_engine", ""),
    )

    threading.Thread(
        target=_wire_connections_to_zeus,
        args=(all_connections, [phenomenon_a, phenomenon_b]),
        daemon=True,
    ).start()

    return result


def run_connect_multi(phenomena, context=""):
    """Run multi-mode: find universal attractor across 3+ phenomena."""
    from zeus_tartarus_core import TartarusMemory, tartarus_call, compute_weights

    mem = TartarusMemory.get()
    mem.set_phase("p3", "active")
    mem.broadcast("connect", "CONNECTING_MULTI",
                  str(len(phenomena)) + " phenomena")

    phenomena_str = "; ".join(phenomena)
    prompt = (
        "PHASE 3 CONNECT MULTI: Discover the universal mathematical attractor "
        "shared by ALL of the following phenomena simultaneously: "
        "[" + phenomena_str + "]. "
        "Find the single deepest principle from which all of these emerge. "
        "Construct the full connection matrix between every pair. "
        "Identify the supra-emergent pattern that only becomes visible "
        "when all are viewed simultaneously."
    )

    result = tartarus_call(
        prompt,
        schema_hint=MULTI_SCHEMA,
        context=context,
        max_tokens=2000,
    )

    if "error" in result:
        mem.set_phase("p3", "error")
        mem.broadcast("connect", "ERROR", result["error"])
        return result

    # Extract connections from matrix
    connections = []
    for entry in (result.get("connectionMatrix") or []):
        connections.append({
            "link":          entry.get("pair", ""),
            "sharedEquation": entry.get("bridge", ""),
            "insight":        entry.get("bridge", ""),
        })
    mem.push_many("connections", connections, source="connect_multi")

    weights = compute_weights(result, source="direct")
    weights["label"] = "MULTI: " + phenomena_str[:60]
    mem.push("weights", weights, source="connect_multi")

    mem.set_phase("p3", "done")
    mem.broadcast("connect", "MULTI_COMPLETE",
                  result.get("universalPrinciple", ""))

    mem.save_session(
        phenomena_str[:200], "p3_connect_multi", result,
        engine=result.get("_engine", ""),
    )

    threading.Thread(
        target=_wire_connections_to_zeus,
        args=(connections, phenomena),
        daemon=True,
    ).start()

    return result


def run_connect_dataset(dataset_text, context=""):
    """Analyse raw dataset for hidden mathematical structure."""
    from zeus_tartarus_core import TartarusMemory, tartarus_call, compute_weights

    mem = TartarusMemory.get()
    mem.set_phase("p3", "active")
    mem.broadcast("connect", "DATASET_ANALYSIS",
                  str(len(dataset_text)) + " chars")

    # Truncate dataset for prompt budget
    truncated = dataset_text[:3000]
    prompt = (
        "PHASE 3 CONNECT DATASET: Analyse the following raw dataset for "
        "hidden mathematical structure, patterns and governing laws. "
        "Do not assume what the data represents — derive its nature purely "
        "from the mathematical patterns you observe. "
        "Dataset: [" + truncated + "]"
    )

    result = tartarus_call(
        prompt,
        schema_hint=DATASET_SCHEMA,
        context=context,
        max_tokens=2000,
    )

    if "error" in result:
        mem.set_phase("p3", "error")
        mem.broadcast("connect", "ERROR", result["error"])
        return result

    result["dataset_length"] = len(dataset_text)
    mem.push("datasets", result, source="connect_dataset")

    # Extract patterns into pool
    for pat in (result.get("hiddenPatterns") or []):
        mem.push("patterns", {
            "pattern":            pat.get("pattern", ""),
            "description":        pat.get("significance", ""),
            "mathematical_basis": pat.get("equation", ""),
            "source":             "dataset_analysis",
        }, source="connect")

    weights = compute_weights(result, source="indirect")
    weights["label"] = "DATASET_" + str(len(dataset_text)) + "chars"
    mem.push("weights", weights, source="connect_dataset")

    mem.set_phase("p3", "done")
    mem.broadcast("connect", "DATASET_COMPLETE",
                  result.get("dominantStructure", ""))

    mem.save_session(
        "dataset:" + str(len(dataset_text)) + "chars",
        "p3_connect_dataset",
        result,
        engine=result.get("_engine", ""),
    )

    return result


# ---------------------------------------------------------------------------
# FLASK ROUTES
# ---------------------------------------------------------------------------

@connect_bp.route("/api/tartarus/connect/dual", methods=["POST"])
def connect_dual():
    data = request.get_json(silent=True) or {}
    a = (data.get("phenomenon_a") or data.get("a") or "").strip()
    b = (data.get("phenomenon_b") or data.get("b") or "").strip()
    if not a or not b:
        return jsonify({"error": "phenomenon_a and phenomenon_b required"}), 400
    from zeus_tartarus_core import TartarusMemory
    ctx = TartarusMemory.get().build_context()
    result = run_connect_dual(a, b, context=ctx)
    if "error" in result:
        return jsonify(result), 500
    return jsonify(result)


@connect_bp.route("/api/tartarus/connect/multi", methods=["POST"])
def connect_multi():
    data = request.get_json(silent=True) or {}
    phenomena = data.get("phenomena") or []
    if len(phenomena) < 3:
        return jsonify({"error": "at least 3 phenomena required"}), 400
    from zeus_tartarus_core import TartarusMemory
    ctx = TartarusMemory.get().build_context()
    result = run_connect_multi(phenomena, context=ctx)
    if "error" in result:
        return jsonify(result), 500
    return jsonify(result)


@connect_bp.route("/api/tartarus/connect/dataset", methods=["POST"])
def connect_dataset():
    data = request.get_json(silent=True) or {}
    dataset = (data.get("dataset") or "").strip()
    if not dataset:
        return jsonify({"error": "dataset required"}), 400
    from zeus_tartarus_core import TartarusMemory
    ctx = TartarusMemory.get().build_context()
    result = run_connect_dataset(dataset, context=ctx)
    if "error" in result:
        return jsonify(result), 500
    return jsonify(result)


@connect_bp.route("/api/tartarus/connect/examples", methods=["GET"])
def connect_examples():
    return jsonify({
        "pairs": [{"a": a, "b": b} for a, b in EXAMPLE_PAIRS]
    })


@connect_bp.route("/api/tartarus/connect/history", methods=["GET"])
def connect_history():
    from zeus_tartarus_core import TartarusMemory
    mem = TartarusMemory.get()
    limit = int(request.args.get("limit", 30))
    return jsonify({
        "connections": mem.get_field("connections", limit),
        "datasets":    mem.get_field("datasets",    limit),
        "ts": time.time(),
    })


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register(app):
    app.register_blueprint(connect_bp)
    log.info("[tartarus_connect] registered — /api/tartarus/connect")
