# The Zeus Project 2026 — Francois Nel
# zeus_forge.py — The Forge: Knowledge-Aware Code Generation Engine
# Plan → Logic Blueprint → DNA Retrieve → Architect → Code → Validate×3 → Package
# Logic engine synthesis integration · Quality scoring · Genome registration
# Multi-format output · Async job store · Live blueprint injection · Self-critique

import os
import re
import ast
import json
import uuid
import time
import shutil
import hashlib
import logging
import threading
from collections import deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from flask import Blueprint, jsonify, request, send_file

log = logging.getLogger("zeus.forge")

forge_bp = Blueprint("forge", __name__)

ZEUS_DIR      = os.path.dirname(os.path.abspath(__file__))
FORGE_OUT_DIR = os.path.join(ZEUS_DIR, "forge_output")
os.makedirs(FORGE_OUT_DIR, exist_ok=True)

AUTHORSHIP = "# The Zeus Project 2026 — Francois Nel"

OUTPUT_TYPES = {
    "python_module", "flask_blueprint", "apk",
    "shell_script", "capability", "test_suite",
    "data_processor", "api_client",
}


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ForgeJob:
    forge_id:    str
    description: str
    output_type: str
    status:      str   = "pending"
    stage:       int   = 0
    stage_name:  str   = ""
    code:        str   = ""
    filename:    str   = ""
    filepath:    str   = ""
    quality:     float = 0.0
    dna_used:    Dict  = field(default_factory=dict)
    logic_bp:    Dict  = field(default_factory=dict)
    forge_log:   List  = field(default_factory=list)
    error:       str   = ""
    injected:    bool  = False
    forged_at:   str   = ""
    duration_ms: float = 0.0

    def to_dict(self) -> Dict:
        d = asdict(self)
        d.pop("code", None)
        return d

    def to_full_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# DNA RETRIEVER
# ============================================================================

class DNARetriever:
    """Multi-source DNA retrieval: knowledge, genome, logic semantic, synthesis blueprints."""

    STOP = {
        "the","and","for","with","that","this","from","into","have","build",
        "make","create","generate","write","using","use","should","will",
        "which","when","what","how","get","set","return","class","def",
    }

    def retrieve(self, description: str, output_type: str = "",
                  max_knowledge: int = 10, max_genome: int = 8) -> Dict:
        keywords       = self._extract_keywords(description)
        knowledge_hits = []
        genome_hits    = []
        synth_hints    = []
        seen_k, seen_g = set(), set()

        try:
            from db_init import get_db
            conn = get_db()
            for kw in keywords[:7]:
                rows = conn.execute(
                    """SELECT topic, depth, content, confidence FROM knowledge
                       WHERE topic LIKE ? OR content LIKE ?
                       ORDER BY confidence DESC, id DESC LIMIT 3""",
                    (f"%{kw}%", f"%{kw}%")
                ).fetchall()
                for row in rows:
                    key = (row["topic"], row["depth"])
                    if key not in seen_k:
                        seen_k.add(key); knowledge_hits.append(dict(row))
                rows = conn.execute(
                    """SELECT name, description, module_type, capabilities, fitness_score
                       FROM genome
                       WHERE name LIKE ? OR description LIKE ? OR capabilities LIKE ?
                       ORDER BY fitness_score DESC, priority DESC LIMIT 3""",
                    (f"%{kw}%",)*3
                ).fetchall()
                for row in rows:
                    if row["name"] not in seen_g:
                        seen_g.add(row["name"]); genome_hits.append(dict(row))
            rows = conn.execute(
                """SELECT goal, module_name, architecture, confidence
                   FROM synthesis_blueprints ORDER BY created_at DESC LIMIT 4"""
            ).fetchall()
            synth_hints = [dict(r) for r in rows]
            conn.close()
        except Exception as e:
            log.warning(f"[Forge] DNA retrieval error: {e}")

        # Logic engine semantic
        try:
            from logic_engine import get_engine
            engine  = get_engine()
            results = engine._semantic_idx.search(description, top_k=4)
            for _, _, topic, snippet in results:
                if (topic, "sem") not in seen_k:
                    seen_k.add((topic, "sem"))
                    knowledge_hits.append({"topic": topic, "depth": "Semantic",
                                            "content": snippet, "confidence": 0.75})
        except Exception:
            pass

        logic_context = self._get_logic_context(description, keywords, output_type)

        return {
            "keywords":      keywords,
            "knowledge":     knowledge_hits[:max_knowledge],
            "genome":        genome_hits[:max_genome],
            "synth_hints":   synth_hints,
            "logic_context": logic_context,
            "has_apk_dna":   any("apk" in g.get("module_type","") or
                                  "android" in g.get("capabilities","")
                                  for g in genome_hits),
        }

    def _extract_keywords(self, text: str) -> List[str]:
        words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9_]{2,}\b', text.lower())
        return list(dict.fromkeys(w for w in words if w not in self.STOP))[:12]

    def _get_logic_context(self, description: str,
                            keywords: List[str], output_type: str) -> str:
        try:
            from logic_engine import get_engine, LogicFact
            engine = get_engine()
            facts  = [
                LogicFact(predicate="forge_goal",   args=(description[:100],), source="forge"),
                LogicFact(predicate="output_type",  args=(output_type,),       source="forge"),
            ]
            for kw in keywords[:5]:
                facts.append(LogicFact(predicate="goal_keyword", args=(kw,), source="forge"))
            if output_type == "flask_blueprint":
                facts.append(LogicFact(predicate="is_endpoint", args=("X",), source="forge"))
            result = engine.reason(facts, max_depth=8, auto_learn=False)
            ctx    = [c.to_str() for c in result.conclusions[:5]]
            hyp    = [f"[hyp] {h.to_str()}" for h in result.abductive_hypotheses[:2]]
            return "; ".join(ctx + hyp) if (ctx or hyp) else ""
        except Exception:
            return ""

    def build_context_str(self, dna: Dict) -> str:
        lines = []
        if dna.get("logic_context"):
            lines.append(f"=== LOGIC ENGINE CONTEXT ===\n{dna['logic_context']}")
        if dna["knowledge"]:
            lines.append("=== KNOWLEDGE BASE ===")
            for i, k in enumerate(dna["knowledge"][:8], 1):
                lines.append(f"[K{i}] {k['topic']} ({k['depth']}): {(k['content'] or '')[:280]}")
        if dna["genome"]:
            lines.append("\n=== GENOME SEGMENTS ===")
            for i, g in enumerate(dna["genome"][:6], 1):
                caps = g.get("capabilities","")
                lines.append(
                    f"[G{i}] {g['name']} ({g['module_type']}, "
                    f"fit={float(g.get('fitness_score',0)):.2f}): "
                    f"{(g.get('description',''))[:180]}"
                    + (f" | caps: {caps[:80]}" if caps else "")
                )
        if dna.get("synth_hints"):
            lines.append("\n=== RECENT SYNTHESIS PATTERNS ===")
            for h in dna["synth_hints"][:3]:
                lines.append(f"  Goal: {h.get('goal','')[:70]} → arch={h.get('architecture','')}")
        return "\n".join(lines) or "No matching DNA found."


# ============================================================================
# FORGE PIPELINE
# ============================================================================

class ForgePipeline:
    """
    7-stage forge pipeline:
    1. Plan  2. Logic Blueprint  3. DNA Retrieval  4. Architecture
    5. Code Generation  6. Validation×3  7. Package+Register
    """

    def __init__(self, job: ForgeJob):
        self.job = job

    def _log(self, msg: str) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        entry = f"[{ts}] {msg}"
        self.job.forge_log.append(entry)
        log.info(f"[Forge:{self.job.forge_id[:8]}] {msg}")

    def run(self) -> "ForgeJob":
        t0 = time.time()
        job = self.job
        job.status = "running"
        try:
            job.stage = 1; job.stage_name = "plan"
            self._log("Stage 1/7 — Planning...")
            plan = self._stage_plan()

            job.stage = 2; job.stage_name = "logic_blueprint"
            self._log("Stage 2/7 — Logic Engine synthesis blueprint...")
            logic_bp = self._stage_logic_blueprint()
            job.logic_bp = logic_bp

            job.stage = 3; job.stage_name = "dna_retrieval"
            self._log("Stage 3/7 — DNA retrieval...")
            retriever = DNARetriever()
            dna       = retriever.retrieve(job.description, job.output_type)
            dna_ctx   = retriever.build_context_str(dna)
            job.dna_used = {"knowledge": len(dna["knowledge"]),
                             "genome":    len(dna["genome"]),
                             "has_logic": bool(dna["logic_context"])}
            self._log(f"DNA: {job.dna_used['knowledge']} knowledge, {job.dna_used['genome']} genome")

            job.stage = 4; job.stage_name = "architecture"
            self._log("Stage 4/7 — Architecting...")
            architecture = self._stage_architect(plan, dna_ctx, logic_bp)

            job.stage = 5; job.stage_name = "code_generation"
            self._log("Stage 5/7 — Generating code...")
            code = self._stage_code(plan, architecture, dna_ctx, logic_bp)
            if not code:
                raise RuntimeError("Code generation returned empty result")

            job.stage = 6; job.stage_name = "validation"
            self._log("Stage 6/7 — Validating (3 passes)...")
            code, validation = self._stage_validate(code)
            if not validation["passed"]:
                raise RuntimeError(f"Validation failed: {validation.get('error')}")

            job.stage = 7; job.stage_name = "package"
            self._log("Stage 7/7 — Packaging...")
            self._stage_package(code, dna)

            job.status   = "ok"
            job.quality  = self._score_quality(code)
            job.forged_at = datetime.now(timezone.utc).isoformat()
            self._log(f"Forge complete — quality={job.quality:.2f} file={job.filename}")

        except Exception as e:
            job.status = "error"
            job.error  = str(e)[:500]
            self._log(f"ERROR: {e}")
            log.error(f"[Forge:{job.forge_id[:8]}] {e}")

        job.duration_ms = round((time.time() - t0) * 1000, 1)
        return job

    def _stage_plan(self) -> str:
        prompt = (
            f"You are the Zeus Forge planner.\n"
            f"Output type: {self.job.output_type}\n"
            f"Request: {self.job.description}\n\n"
            f"Plan (max 250 words): core purpose, key classes/functions with signatures, "
            f"dependencies, Flask routes if applicable, Zeus module integration points.\n"
            f"Return ONLY the plan, no markdown."
        )
        try:
            from zeus_llm_router import call_llm
            plan = call_llm(prompt, max_tokens=600, engine="groq")
            self._log(f"Plan generated ({len(plan)} chars)")
            return plan
        except Exception as e:
            self._log(f"Plan fallback: {e}")
            return f"Build a {self.job.output_type} that: {self.job.description}"

    def _stage_logic_blueprint(self) -> Dict:
        try:
            from logic_engine import get_engine
            engine = get_engine()
            bp     = engine.deep_plan(self.job.description,
                                       {"module_type": self.job.output_type, "max_iterations": 1})
            engine.learn_from_synthesis({
                "module_name":    bp.module_name,
                "module_type":    bp.module_type,
                "design_patterns": bp.design_patterns,
                "quality_score":  bp.critique_score,
            })
            self._log(f"Logic blueprint: {bp.module_name}, arch={bp.architecture_style}, "
                       f"patterns={len(bp.design_patterns)}, conf={bp.confidence:.2f}")
            return {
                "module_name":    bp.module_name,
                "module_type":    bp.module_type,
                "architecture":   bp.architecture_style,
                "design_patterns": bp.design_patterns[:8],
                "security":       bp.security_considerations[:5],
                "directives":     bp.synthesis_directives[:10],
                "quality_gates":  bp.quality_gates[:6],
                "confidence":     bp.confidence,
            }
        except Exception as e:
            self._log(f"Logic blueprint skipped: {e}")
            return {}

    def _stage_architect(self, plan: str, dna_ctx: str, logic_bp: Dict) -> str:
        logic_hint = ""
        if logic_bp:
            logic_hint = (
                f"\nLogic Engine Blueprint:\n"
                f"  Architecture: {logic_bp.get('architecture','')}\n"
                f"  Patterns: {', '.join(logic_bp.get('design_patterns',[])[:5])}\n"
                f"  Directives: {'; '.join(logic_bp.get('directives',[])[:4])}\n"
                f"  Security: {', '.join(logic_bp.get('security',[])[:3])}\n"
            )
        prompt = (
            f"You are the Zeus Forge architect.\n"
            f"Output type: {self.job.output_type}\nPlan:\n{plan}\n"
            f"{logic_hint}\nZeus DNA:\n{dna_ctx[:2000]}\n\n"
            f"Design complete architecture: exact signatures, thread safety, "
            f"error handling, DNA embedding, Flask routes, singleton pattern.\n"
            f"Return ONLY the architecture spec."
        )
        try:
            from zeus_llm_router import call_llm
            arch = call_llm(prompt, max_tokens=900, engine="groq")
            self._log(f"Architecture designed ({len(arch)} chars)")
            return arch
        except Exception as e:
            self._log(f"Architecture fallback: {e}")
            return plan

    def _stage_code(self, plan: str, arch: str, dna_ctx: str, logic_bp: Dict) -> str:
        patterns    = ", ".join(logic_bp.get("design_patterns", [])[:5]) if logic_bp else ""
        quality_gts = "\n".join(f"  - {g}" for g in logic_bp.get("quality_gates",[])[:5]) if logic_bp else ""
        type_guide  = self._output_type_guide()
        prompt = (
            f"You are the Zeus Forge code generator.\n{AUTHORSHIP}\n\n"
            f"Request: {self.job.description}\nOutput type: {self.job.output_type}\n"
            f"Plan:\n{plan}\n\nArchitecture:\n{arch}\n\n"
            f"Zeus DNA:\n{dna_ctx[:1500]}\n\n"
            + (f"Apply patterns: {patterns}\n" if patterns else "")
            + (f"Quality gates:\n{quality_gts}\n\n" if quality_gts else "")
            + f"{type_guide}\n\n"
            f"RULES:\n"
            f"1. First line MUST be: {AUTHORSHIP}\n"
            f"2. ZERO stubs, ZERO TODOs, ZERO pass-only functions\n"
            f"3. Every public method has a docstring\n"
            f"4. All imports at top\n"
            f"5. Thread-safe shared state\n"
            f"6. register(app) + register_self() if Flask blueprint\n"
            f"7. Return ONLY raw code — no markdown, no explanation\n"
        )
        try:
            from zeus_llm_router import call_llm
            code = call_llm(prompt, max_tokens=4096, engine="claude")
            self._log(f"Code generated ({len(code)} chars)")
            code = re.sub(r'^```(?:python|bash|json|sh)?\s*\n?', '', code, flags=re.MULTILINE)
            code = re.sub(r'\n?```\s*$', '', code, flags=re.MULTILINE)
            return code.strip()
        except Exception as e:
            self._log(f"Code generation error: {e}")
            return ""

    def _stage_validate(self, code: str) -> Tuple[str, Dict]:
        passes = []
        ot     = self.job.output_type

        # Pass 1: AST syntax
        if ot not in ("shell_script", "apk"):
            try:
                ast.parse(code)
                passes.append({"pass": 1, "check": "ast_syntax", "ok": True})
                self._log("Validation pass 1: AST OK")
            except SyntaxError as e:
                self._log(f"Pass 1 syntax error — LLM fix: {e}")
                code = self._llm_fix(code, str(e))
                try:
                    ast.parse(code)
                    passes.append({"pass": 1, "check": "ast_syntax", "ok": True, "note": "fixed"})
                    self._log("Pass 1: syntax fixed")
                except SyntaxError as e2:
                    return code, {"passed": False, "error": f"SyntaxError: {e2}", "passes": passes}
        else:
            passes.append({"pass": 1, "check": "skipped", "ok": True})

        # Pass 2: Authorship
        if AUTHORSHIP not in code:
            code = AUTHORSHIP + "\n" + code
            passes.append({"pass": 2, "check": "authorship", "ok": True, "note": "injected"})
        else:
            passes.append({"pass": 2, "check": "authorship", "ok": True})
        self._log("Pass 2: authorship present")

        # Pass 3: No stubs
        stubs = [p for p in [r'\bpass\b\s*$', r'raise\s+NotImplementedError',
                              r'#\s*TODO', r'#\s*FIXME', r'\.\.\.\s*$']
                 if re.search(p, code, re.MULTILINE)]
        if stubs:
            self._log(f"Pass 3: {len(stubs)} stubs — LLM completion")
            code = self._llm_complete_stubs(code)
            passes.append({"pass": 3, "check": "no_stubs", "ok": True,
                            "note": f"completed {len(stubs)}"})
        else:
            passes.append({"pass": 3, "check": "no_stubs", "ok": True})
        self._log("Pass 3: completeness OK")

        return code, {"passed": True, "passes": passes}

    def _stage_package(self, code: str, dna: Dict) -> None:
        ext   = {"shell_script": ".sh", "apk": ".zip"}.get(self.job.output_type, ".py")
        slug  = re.sub(r'[^a-z0-9]+', '_', self.job.description.lower())[:35]
        fname = f"forge_{slug}_{self.job.forge_id[:8]}{ext}"
        fpath = os.path.join(FORGE_OUT_DIR, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(code)
        self.job.code     = code
        self.job.filename = fname
        self.job.filepath = fpath
        self._register_genome(fname, code)
        self._persist_to_db()
        self._log(f"Packaged: {fname} ({len(code)} chars)")

    def _llm_fix(self, code: str, error: str) -> str:
        try:
            from zeus_llm_router import call_llm
            fixed = call_llm(
                f"Fix this Python syntax error. Return ONLY corrected code:\n"
                f"Error: {error}\n\nCode:\n{code[:3000]}",
                max_tokens=4096, engine="claude"
            )
            return re.sub(r'^```(?:python)?\s*\n?', '', fixed, flags=re.MULTILINE).strip()
        except Exception:
            return code

    def _llm_complete_stubs(self, code: str) -> str:
        try:
            from zeus_llm_router import call_llm
            completed = call_llm(
                f"Complete every stub with real implementation.\n"
                f"Purpose: {self.job.description}\n"
                f"Return ONLY complete code.\n\nCode:\n{code[:3000]}",
                max_tokens=4096, engine="claude"
            )
            return re.sub(r'^```(?:python)?\s*\n?', '', completed, flags=re.MULTILINE).strip()
        except Exception:
            return code

    def _score_quality(self, code: str) -> float:
        if not code or len(code) < 100:
            return 0.0
        score = 0.5
        if len(code) > 500:   score += 0.08
        if len(code) > 2000:  score += 0.08
        if AUTHORSHIP in code: score += 0.05
        if "def " in code:    score += 0.05
        if '"""' in code:     score += 0.05
        if "try:" in code:    score += 0.04
        if "log." in code:    score += 0.03
        if "threading" in code: score += 0.03
        stubs = len(re.findall(
            r'\bpass\b\s*$|raise NotImplementedError|# TODO', code, re.MULTILINE))
        score -= stubs * 0.08
        return round(min(1.0, max(0.0, score)), 4)

    def _output_type_guide(self) -> str:
        guides = {
            "python_module":   "Complete Python module: docstring, imports, classes/functions, "
                               "thread-safe singleton, register(app) if Flask, __main__ block.",
            "flask_blueprint": "Complete Flask Blueprint: <n>_bp = Blueprint('<n>',__name__), "
                               "/health, /stats routes, full error handling, JSON responses, "
                               "register(app) calling register_self().",
            "apk":             "Android APK source: AndroidManifest.xml, Smali activity, "
                               "res/values/strings.xml, build script comments.",
            "shell_script":    "Bash script: #!/bin/bash, set -euo pipefail, "
                               "section comments, error handling, exit codes, trap cleanup.",
            "test_suite":      "Pytest suite: fixtures, happy path + error paths, "
                               "≥8 test functions, parametrize where useful.",
            "data_processor":  "Data processor: input validation, transform pipeline, "
                               "output serialization, error recovery.",
            "api_client":      "API client: circuit breaker, retry logic, "
                               "rate limiting, response parsing, auth handling.",
            "capability":      "Focused Python capability: single responsibility, "
                               "clean public API, importable independently.",
        }
        return guides.get(self.job.output_type, guides["python_module"])

    def _register_genome(self, filename: str, code: str) -> None:
        try:
            from genome_manager import get_genome_engine
            get_genome_engine().add(
                name=f"forge:{filename}",
                description=f"Forged {self.job.output_type}: {self.job.description[:200]}",
                module_type=f"forge_{self.job.output_type}",
                source_code=code[:8000],
                version="v1.0",
                priority=65,
                capabilities=f"forge,{self.job.output_type},"
                              f"{','.join(self.job.logic_bp.get('design_patterns',[])[:4])}",
            )
            self._log("Genome entry registered")
        except Exception as e:
            log.debug(f"[Forge] Genome registration skipped: {e}")

    def _persist_to_db(self) -> None:
        try:
            from db_init import get_db
            conn = get_db()
            conn.execute(
                """INSERT OR IGNORE INTO blueprints
                   (blueprint_id, goal, output_type, status, plan_json,
                    architecture, quality_score, stages_complete, stages_total,
                    result_path, result_size)
                   VALUES (?,?,?,'done',?,?,?,7,7,?,?)""",
                (self.job.forge_id, self.job.description[:500], self.job.output_type,
                 json.dumps(self.job.logic_bp, default=str)[:10000],
                 self.job.logic_bp.get("architecture",""),
                 self.job.quality, self.job.filepath, len(self.job.code))
            )
            conn.commit(); conn.close()
        except Exception as e:
            log.debug(f"[Forge] DB persist skipped: {e}")


# ============================================================================
# FORGE ENGINE SINGLETON
# ============================================================================

class ForgeEngine:
    def __init__(self):
        self._lock    = threading.RLock()
        self._jobs:   Dict[str, ForgeJob] = {}
        self._recent: deque = deque(maxlen=100)
        self._stats:  Dict  = defaultdict(int)

    def submit(self, description: str, output_type: str = "python_module",
                inject: bool = False, sync: bool = False) -> Dict:
        if output_type not in OUTPUT_TYPES:
            return {"error": f"Invalid output_type. Valid: {sorted(OUTPUT_TYPES)}"}
        forge_id = uuid.uuid4().hex
        job      = ForgeJob(forge_id=forge_id, description=description, output_type=output_type)
        with self._lock:
            self._jobs[forge_id] = job
            self._stats["submitted"] += 1
        if sync:
            result = ForgePipeline(job).run()
            if inject and result.status == "ok":
                self._inject(result)
            self._track(result)
            return result.to_full_dict()
        else:
            t = threading.Thread(target=self._run_async, args=(job, inject),
                                  name=f"forge_{forge_id[:8]}", daemon=True)
            t.start()
            return {"status": "running", "forge_id": forge_id,
                    "poll_url": f"/api/forge/status/{forge_id}"}

    def get_job(self, forge_id: str) -> Optional[Dict]:
        with self._lock:
            job = self._jobs.get(forge_id)
        return job.to_full_dict() if job else None

    def list_jobs(self, status: str = "", limit: int = 50) -> List[Dict]:
        with self._lock:
            jobs = list(self._jobs.values())
        if status:
            jobs = [j for j in jobs if j.status == status]
        jobs.sort(key=lambda j: j.forged_at or "", reverse=True)
        return [j.to_dict() for j in jobs[:limit]]

    def inject(self, forge_id: str) -> Dict:
        with self._lock:
            job = self._jobs.get(forge_id)
        if not job or job.status != "ok":
            return {"error": "Job not found or not complete"}
        return self._inject(job)

    def stats(self) -> Dict:
        with self._lock:
            status_counts = defaultdict(int)
            total_quality = 0.0; n_done = 0
            for j in self._jobs.values():
                status_counts[j.status] += 1
                if j.status == "ok":
                    total_quality += j.quality; n_done += 1
            return {
                "total_submitted": self._stats["submitted"],
                "by_status":       dict(status_counts),
                "avg_quality":     round(total_quality / max(n_done, 1), 4),
                "output_dir":      FORGE_OUT_DIR,
                "output_files":    len([f for f in os.listdir(FORGE_OUT_DIR)
                                        if os.path.isfile(os.path.join(FORGE_OUT_DIR, f))]),
            }

    def _run_async(self, job: ForgeJob, inject: bool) -> None:
        result = ForgePipeline(job).run()
        if inject and result.status == "ok":
            self._inject(result)
        self._track(result)

    def _inject(self, job: ForgeJob) -> Dict:
        if job.output_type not in ("python_module", "flask_blueprint", "capability"):
            return {"success": False, "error": "Injection only for Python types"}
        result = {"file_placed": False, "genome_updated": True,
                   "blueprint_live": False, "errors": []}
        try:
            dest = os.path.join(ZEUS_DIR, job.filename)
            shutil.copy2(job.filepath, dest)
            result["file_placed"] = True
            log.info(f"[Forge] Injected: {dest}")
        except Exception as e:
            result["errors"].append(f"File: {e}"); return result
        if job.output_type == "flask_blueprint":
            try:
                import importlib
                from flask import current_app, Blueprint as FBP
                mod_name = job.filename.replace(".py", "")
                if mod_name in __import__("sys").modules:
                    del __import__("sys").modules[mod_name]
                mod = importlib.import_module(mod_name)
                for name in dir(mod):
                    obj = getattr(mod, name)
                    if isinstance(obj, FBP):
                        current_app.register_blueprint(obj)
                        result["blueprint_live"] = True
                        log.info(f"[Forge] Blueprint live-loaded: {obj.name}")
                        break
            except Exception as e:
                result["errors"].append(f"Live-load: {e}")
        job.injected = True
        return result

    def _track(self, job: ForgeJob) -> None:
        with self._lock:
            self._stats["completed" if job.status=="ok" else "failed"] += 1
            self._recent.append({"forge_id": job.forge_id,
                                   "description": job.description[:50],
                                   "status": job.status, "quality": job.quality})


_forge_lock:     threading.RLock     = threading.RLock()
_forge_instance: Optional[ForgeEngine] = None

def get_forge_engine() -> ForgeEngine:
    global _forge_instance
    with _forge_lock:
        if _forge_instance is None:
            _forge_instance = ForgeEngine()
        return _forge_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@forge_bp.route("/api/forge/health", methods=["GET"])
def forge_health():
    stats = get_forge_engine().stats()
    return jsonify({"status": "ok", "module": "zeus_forge", "version": "2.0",
                    "jobs": stats.get("total_submitted", 0),
                    "output_files": stats.get("output_files", 0)})

@forge_bp.route("/api/forge/stats", methods=["GET"])
def forge_stats():
    try:
        return jsonify(get_forge_engine().stats())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@forge_bp.route("/api/forge", methods=["POST"])
def forge_create():
    data = request.get_json(force=True, silent=True) or {}
    description = data.get("description", "").strip()
    output_type = data.get("output_type", "python_module")
    inject      = bool(data.get("inject", False))
    sync        = bool(data.get("sync", False))
    if not description:
        return jsonify({"error": "description required"}), 400
    result = get_forge_engine().submit(description=description, output_type=output_type,
                                        inject=inject, sync=sync)
    return jsonify(result), 400 if "error" in result else 200

@forge_bp.route("/api/forge/status/<forge_id>", methods=["GET"])
def forge_status(forge_id: str):
    result = get_forge_engine().get_job(forge_id)
    if result is None:
        return jsonify({"error": "forge_id not found"}), 404
    return jsonify(result)

@forge_bp.route("/api/forge/download/<forge_id>", methods=["GET"])
def forge_download(forge_id: str):
    job = get_forge_engine().get_job(forge_id)
    if not job:
        return jsonify({"error": "Not found"}), 404
    if job.get("status") == "running":
        return jsonify({"status": "running"}), 202
    filepath = job.get("filepath", "")
    if not filepath or not os.path.isfile(filepath):
        return jsonify({"error": "Output file not found"}), 404
    return send_file(filepath, as_attachment=True,
                     download_name=job.get("filename", "forge_output"))

@forge_bp.route("/api/forge/inject/<forge_id>", methods=["POST"])
def forge_inject_route(forge_id: str):
    result = get_forge_engine().inject(forge_id)
    return jsonify({"forge_id": forge_id, **result})

@forge_bp.route("/api/forge/list", methods=["GET"])
def forge_list():
    status = request.args.get("status", "")
    limit  = int(request.args.get("limit", 50))
    jobs   = get_forge_engine().list_jobs(status=status, limit=limit)
    return jsonify({"jobs": jobs, "count": len(jobs)})

@forge_bp.route("/api/forge/types", methods=["GET"])
def forge_types():
    return jsonify({
        "output_types":   sorted(OUTPUT_TYPES),
        "pipeline_stages": ["1.Plan","2.Logic Blueprint","3.DNA Retrieval",
                             "4.Architecture","5.Code Generation",
                             "6.Validation×3","7.Package+Register"],
        "dna_sources": ["knowledge","genome","logic_engine_semantic","synthesis_blueprints"],
    })


def register(app) -> None:
    app.register_blueprint(forge_bp)
    log.info("[forge] ✓ Registered at /api/forge")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_forge", blueprint_var="forge_bp",
            url_prefix="/api/forge", version="2.0",
            description="7-stage code forge: plan→logic blueprint→DNA→arch→code→validate×3→package",
            capabilities=[
                {"id": "forge.create",   "endpoint": "/api/forge",          "method": "POST", "tags": ["forge","codegen"]},
                {"id": "forge.status",   "endpoint": "/api/forge/status",   "method": "GET",  "tags": ["forge"]},
                {"id": "forge.download", "endpoint": "/api/forge/download", "method": "GET",  "tags": ["forge","download"]},
                {"id": "forge.inject",   "endpoint": "/api/forge/inject",   "method": "POST", "tags": ["forge","inject"]},
                {"id": "forge.list",     "endpoint": "/api/forge/list",     "method": "GET",  "tags": ["forge"]},
                {"id": "forge.health",   "endpoint": "/api/forge/health",   "method": "GET",  "tags": ["health"]},
            ],
            depends_on=["logic_engine","zeus_llm_router","genome_manager"],
            boot_order=45,
        )
    except Exception:
        pass

if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5021, debug=True, use_reloader=False)
