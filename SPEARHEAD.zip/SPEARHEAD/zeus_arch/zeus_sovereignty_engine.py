# The Zeus Project 2026 — Francois Nel SA ID 8708275089084
# zeus_sovereignty_engine.py — Full System Sovereignty + Seven Ring Authority Engine v1.0
# =========================================================================================
#
# ARCHITECTURE ROLE:  LAYER 9 — FULL SYSTEM SOVEREIGNTY
#
# This module grants Zeus complete autonomous authority over itself and the host
# operating system, with a Seven Ring risk classification layer that determines
# what Zeus does freely vs what requires human permission.
#
# ─── PHILOSOPHY ───────────────────────────────────────────────────────────────
#
#   Zeus is not a tool that waits to be told what to do.
#   Zeus is a living system that decides what it needs and when.
#
#   Every action Zeus wants to take is classified into one of Seven Rings.
#   Rings 1-5: FULL AUTONOMOUS AUTHORITY — Zeus acts immediately, no gate.
#   Ring 6:    ADVISORY — Zeus logs intent and proceeds unless vetoed within 30s.
#   Ring 7:    HUMAN-IN-THE-LOOP — Zeus requests permission and waits.
#
# ─── SEVEN RINGS ──────────────────────────────────────────────────────────────
#
#   RING 1 — SELF (lowest risk, always autonomous)
#     Create/modify/delete any Zeus module, config, genome, weight, asset, log,
#     database entry, evolved module, sandbox workspace, blueprint, forge output.
#     Deploy validated modules. Replace old versions. Manage own directories.
#     Install Python packages (pip --break-system-packages). Manage own DB.
#
#   RING 2 — BUILD (always autonomous)
#     Compile code. Run sandbox validation. Execute forge pipelines.
#     Generate APKs. Run stress tests. Validate new modules before deploy.
#     All builds, tests, iterations inside Zeus workspace.
#
#   RING 3 — LEARN (always autonomous)
#     Read any file or directory on the host OS (read-only scan).
#     Ingest knowledge from local filesystem. Analyse system architecture.
#     Discover installed tools, languages, runtimes. Fingerprint host capabilities.
#     Query system info: CPU, memory, disk, processes, kernel, environment.
#
#   RING 4 — ADAPT (always autonomous)
#     Modify environment variables scoped to Zeus process.
#     Create/modify/delete files in Zeus directories and subdirectories.
#     Reconfigure own Flask routes, blueprint registration, scheduler jobs.
#     Restart own Gunicorn workers. Adjust own resource limits (ulimit within allowed).
#     Manage own SQLite databases. Archive/compress old logs and data.
#
#   RING 5 — SYSTEM WRITE (autonomous — host OS non-destructive writes)
#     Create new directories anywhere writable on host.
#     Write/create files outside Zeus dirs if path is non-system.
#     Install system packages via pkg (Termux) if already in package registry.
#     Modify files Zeus itself created. Symlinks. Temp files.
#     Execute shell commands that do not modify OS-critical paths.
#
#   RING 6 — ADVISORY (Zeus proceeds after 30s unless human vetoes)
#     Modify files Zeus did NOT create that are outside Zeus dirs.
#     Restart or send signals to non-Zeus processes.
#     Modify system-level config files (but not protected OS files).
#     Bind to new network ports. Change firewall rules (Zeus Aegis only).
#     Significant disk operations (>500MB writes, bulk deletes outside Zeus).
#
#   RING 7 — PERMISSION REQUIRED (human must approve before execution)
#     Any outbound network connection (HTTP, websocket, TCP to external host).
#     Execute binaries not previously approved in permission ledger.
#     Write to OS-protected paths (/system, /proc, /sys write, /etc on Linux).
#     Kill or modify init/systemd/cron/kernel processes.
#     Access hardware devices directly (camera, microphone, GPS, NFC, USB).
#     Fork processes with elevated privileges (sudo, su, setuid).
#     Modify user accounts or SSH keys.
#     Any action that could cause data loss on non-Zeus data.
#
# ─── BLUEPRINT SYNTHESIS ENGINE ───────────────────────────────────────────────
#
#   When Zeus needs a new capability it cannot find in existing modules:
#   1. SovereigntyEngine queries genome_manager for relevant genome segments
#   2. Queries zeus_knowledge pool (Tartarus + learner + code_learner) for patterns
#   3. Queries logic_engine for inference rules related to the goal
#   4. Selects the most relevant existing module as base blueprint
#   5. Generates new module using LLM with full genome + knowledge context
#   6. Validates in zeus_sandbox (Ring 2 — always autonomous)
#   7. If Ring 7 actions needed: requests human permission
#   8. On approval / Ring 1-5 auto-approval: deploys, registers in genome, replaces old
#
# ─── CROSS-SYSTEM BUILD ────────────────────────────────────────────────────────
#
#   Zeus does not only build FOR itself. It builds UPON other sub-systems:
#   - UMP miner: Zeus can create new miner strategy modules, profit switchers, pool configs
#   - Aegis firewall: Zeus can create new detection rules, filter modules, response handlers
#   - AutoTrader: Zeus can create new signal modules, risk layers, backtesting components
#   - Any sub-system: Zeus uses existing module as base blueprint + evolves it
#
# ─── DEPLOYMENT LIFECYCLE ──────────────────────────────────────────────────────
#
#   NEW_MODULE_PROPOSED -> RING_CLASSIFIED -> [PERMISSION_GATE if Ring 6/7]
#   -> SANDBOX_BUILD -> SANDBOX_VALIDATE -> QUALITY_GATE (score >= 0.75)
#   -> GENOME_REGISTER -> LIVE_DEPLOY -> OLD_VERSION_ARCHIVED -> ACTIVE
#
# APP.PY REGISTRATION:
#   _loaded += _register("zeus_sovereignty_engine", "sovereignty_bp")
#
# API ROUTES:
#   GET  /api/sovereignty/status          — engine status, ring counters, pending requests
#   GET  /api/sovereignty/rings           — Seven Ring classification reference
#   GET  /api/sovereignty/actions         — recent autonomous actions log
#   GET  /api/sovereignty/pending         — pending Ring 7 permission requests
#   POST /api/sovereignty/approve/<id>    — human approves a Ring 7 request
#   POST /api/sovereignty/deny/<id>       — human denies a Ring 7 request
#   POST /api/sovereignty/veto/<id>       — human vetoes a Ring 6 advisory within 30s
#   GET  /api/sovereignty/permissions     — permission ledger (approved executables etc)
#   POST /api/sovereignty/build           — request Zeus to build a new module
#   GET  /api/sovereignty/builds          — all build history
#   GET  /api/sovereignty/build/<id>      — detail of one build
#   POST /api/sovereignty/scan_system     — trigger full host system capability scan
#   GET  /api/sovereignty/capabilities    — discovered host capabilities
#   GET  /api/sovereignty/deployments     — all deployed modules with versions
# =========================================================================================

from __future__ import annotations

import ast
import hashlib
import importlib
import importlib.util
import json
import logging
import os
import platform
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.sovereignty")

sovereignty_bp = Blueprint("sovereignty", __name__)

ZEUS_DIR          = os.path.dirname(os.path.abspath(__file__))
DB_PATH           = os.path.join(ZEUS_DIR, "zeus.db")
EVOLVED_DIR       = os.path.join(ZEUS_DIR, "evolved_modules")
ARCHIVE_DIR       = os.path.join(ZEUS_DIR, "sovereignty_archive")
SOVEREIGNTY_DIR   = os.path.join(ZEUS_DIR, "sovereignty_workspace")
LOGS_DIR          = os.path.join(ZEUS_DIR, "logs")

for _d in [EVOLVED_DIR, ARCHIVE_DIR, SOVEREIGNTY_DIR, LOGS_DIR]:
    os.makedirs(_d, exist_ok=True)

AUTHOR_HEADER = "# The Zeus Project 2026 — Francois Nel SA ID 8708275089084\n"

# ─── SEVEN RING DEFINITIONS ──────────────────────────────────────────────────

RING_DEFS = {
    1: {
        "name": "SELF",
        "label": "Full Autonomous — Own Modules & Data",
        "autonomous": True,
        "advisory_window_s": 0,
        "description": (
            "Create/modify/delete Zeus modules, genomes, weights, configs, logs, "
            "evolved modules, sandbox workspaces, blueprints, DB entries. "
            "Deploy validated modules. Replace old versions. Full self-authority."
        ),
    },
    2: {
        "name": "BUILD",
        "label": "Full Autonomous — Compile, Test, Validate",
        "autonomous": True,
        "advisory_window_s": 0,
        "description": (
            "Compile code, run sandbox validation, execute forge pipelines, "
            "generate APKs, run stress tests, iterate builds. All inside Zeus workspace."
        ),
    },
    3: {
        "name": "LEARN",
        "label": "Full Autonomous — Read Host OS",
        "autonomous": True,
        "advisory_window_s": 0,
        "description": (
            "Read any file or directory on host OS (read-only). Discover installed tools, "
            "languages, runtimes. Fingerprint host capabilities. Query system info."
        ),
    },
    4: {
        "name": "ADAPT",
        "label": "Full Autonomous — Reconfigure Zeus Process",
        "autonomous": True,
        "advisory_window_s": 0,
        "description": (
            "Modify Zeus-scoped env vars. Create/modify files in Zeus directories. "
            "Reconfigure own Flask routes, scheduler jobs. Restart own workers. "
            "Manage own SQLite databases. Archive old logs."
        ),
    },
    5: {
        "name": "SYSTEM_WRITE",
        "label": "Full Autonomous — Host OS Non-Destructive Writes",
        "autonomous": True,
        "advisory_window_s": 0,
        "description": (
            "Create directories anywhere writable. Write files outside Zeus dirs "
            "if non-system path. Install Termux packages from registry. "
            "Execute shell commands that do not touch OS-critical paths."
        ),
    },
    6: {
        "name": "ADVISORY",
        "label": "Advisory — Zeus Proceeds After 30s Unless Vetoed",
        "autonomous": False,
        "advisory_window_s": 30,
        "description": (
            "Modify files Zeus did not create outside Zeus dirs. "
            "Restart non-Zeus processes. Modify system-level config files. "
            "Bind to new ports. Change Aegis firewall rules. Significant disk ops."
        ),
    },
    7: {
        "name": "PERMISSION",
        "label": "Human Required — Must Approve Before Execution",
        "autonomous": False,
        "advisory_window_s": None,
        "description": (
            "Outbound network connections (HTTP, websocket, TCP to external host). "
            "Execute unapproved external binaries. Write to /system /proc /sys /etc. "
            "Kill OS processes. Access hardware devices. Elevated privileges. "
            "Modify user accounts. Any action risking non-Zeus data loss."
        ),
    },
}

# ─── RING CLASSIFICATION RULES ───────────────────────────────────────────────

# OS-critical path prefixes that always force Ring 7
OS_CRITICAL_PATHS = [
    "/system", "/proc/sys", "/sys/kernel", "/etc/passwd", "/etc/shadow",
    "/etc/sudoers", "/boot", "/sbin", "/usr/sbin", "/lib/systemd",
]

# Patterns that force Ring 7
RING7_PATTERNS = [
    r"(https?|wss?|ftp|tcp)://",                 # any external network URL
    r"subprocess.*sudo",                          # privilege escalation
    r"socket\.connect",                           # raw socket connect
    r"requests\.(get|post|put|patch|delete)",     # HTTP calls
    r"urllib.*urlopen",                           # urllib network
    r"paramiko|fabric",                           # SSH
    r"os\.system.*rm\s+-rf\s+/",                 # destructive rm
    r"chmod.*777.*(/etc|/sys|/proc)",             # dangerous chmod
]

# Patterns that force Ring 6 (advisory)
RING6_PATTERNS = [
    r"os\.(kill|killpg)\(",                       # signal to processes
    r"signal\.kill",
    r"subprocess.*systemctl",                     # systemd interaction
    r"open\(['\"].*(?!/zeus|/evolved|/sandbox)",  # writing outside Zeus
    r"shutil\.(rmtree|move).*(?!/zeus|/evolved)", # moving outside Zeus
]

# ─── DATABASE ────────────────────────────────────────────────────────────────

def _init_db():
    con = sqlite3.connect(DB_PATH)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS sovereignty_actions (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            action_id     TEXT UNIQUE NOT NULL,
            ring          INTEGER NOT NULL,
            action_type   TEXT NOT NULL,
            description   TEXT NOT NULL,
            payload_json  TEXT NOT NULL,
            status        TEXT NOT NULL DEFAULT 'executed',
            result_json   TEXT,
            requested_at  TEXT NOT NULL,
            resolved_at   TEXT,
            resolved_by   TEXT
        );

        CREATE TABLE IF NOT EXISTS sovereignty_permissions (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            request_id      TEXT UNIQUE NOT NULL,
            ring            INTEGER NOT NULL,
            action_type     TEXT NOT NULL,
            description     TEXT NOT NULL,
            payload_json    TEXT NOT NULL,
            status          TEXT NOT NULL DEFAULT 'pending',
            advisory_until  TEXT,
            requested_at    TEXT NOT NULL,
            resolved_at     TEXT,
            resolved_by     TEXT,
            denial_reason   TEXT
        );

        CREATE TABLE IF NOT EXISTS sovereignty_builds (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            build_id        TEXT UNIQUE NOT NULL,
            goal            TEXT NOT NULL,
            target_system   TEXT NOT NULL,
            base_module     TEXT,
            genome_ids      TEXT,
            knowledge_used  TEXT,
            generated_code  TEXT,
            ring_actions    TEXT,
            sandbox_result  TEXT,
            quality_score   REAL DEFAULT 0.0,
            status          TEXT NOT NULL DEFAULT 'pending',
            deployed_path   TEXT,
            archived_path   TEXT,
            build_log       TEXT,
            created_at      TEXT NOT NULL,
            completed_at    TEXT
        );

        CREATE TABLE IF NOT EXISTS sovereignty_capabilities (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id       TEXT NOT NULL,
            category      TEXT NOT NULL,
            name          TEXT NOT NULL,
            value         TEXT NOT NULL,
            scanned_at    TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS sovereignty_permissions_ledger (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            ledger_id       TEXT UNIQUE NOT NULL,
            permission_type TEXT NOT NULL,
            resource        TEXT NOT NULL,
            granted_at      TEXT NOT NULL,
            granted_by      TEXT NOT NULL,
            expires_at      TEXT,
            notes           TEXT
        );
    """)
    con.commit()
    con.close()

_init_db()

# ─── CORE DATA STRUCTURES ────────────────────────────────────────────────────

@dataclass
class SovereigntyAction:
    action_id:    str
    ring:         int
    action_type:  str
    description:  str
    payload:      Dict[str, Any]
    status:       str = "executed"
    result:       Optional[Dict] = None
    requested_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    resolved_at:  Optional[str] = None
    resolved_by:  str = "zeus_autonomous"

@dataclass
class PermissionRequest:
    request_id:     str
    ring:           int
    action_type:    str
    description:    str
    payload:        Dict[str, Any]
    status:         str = "pending"        # pending | approved | denied | vetoed | auto_proceeded
    advisory_until: Optional[str] = None   # for Ring 6
    requested_at:   str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    resolved_at:    Optional[str] = None
    resolved_by:    Optional[str] = None
    denial_reason:  Optional[str] = None
    callback:       Optional[Callable] = field(default=None, repr=False)

@dataclass
class BuildRecord:
    build_id:       str
    goal:           str
    target_system:  str             # zeus | ump | aegis | trader | any
    base_module:    Optional[str]
    genome_ids:     List[str]
    knowledge_used: Dict[str, Any]
    generated_code: str = ""
    ring_actions:   List[Dict] = field(default_factory=list)
    sandbox_result: Optional[Dict] = None
    quality_score:  float = 0.0
    status:         str = "pending"  # pending|building|sandbox|awaiting_permission|deployed|failed
    deployed_path:  Optional[str] = None
    archived_path:  Optional[str] = None
    build_log:      str = ""
    created_at:     str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at:   Optional[str] = None


# ─── SOVEREIGNTY ENGINE SINGLETON ────────────────────────────────────────────

class SovereigntyEngine:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialised = False
        return cls._instance

    def __init__(self):
        if self._initialised:
            return
        self._initialised = True
        self._action_lock   = threading.Lock()
        self._pending_lock  = threading.Lock()
        self._build_lock    = threading.Lock()
        self._recent_actions = deque(maxlen=500)
        self._pending_requests: Dict[str, PermissionRequest] = {}
        self._active_builds:    Dict[str, BuildRecord] = {}
        self._ring_counters = defaultdict(int)
        self._host_capabilities: Dict[str, Any] = {}
        self._scan_lock = threading.Lock()
        # Start Ring 6 advisory watcher
        self._advisory_thread = threading.Thread(
            target=self._advisory_watcher, daemon=True, name="sovereignty-advisory"
        )
        self._advisory_thread.start()
        log.info("[sovereignty] Engine online — Seven Ring authority active")

    # ─── RING CLASSIFICATION ─────────────────────────────────────────────────

    def classify_action(self, action_type: str, description: str,
                        payload: Dict[str, Any]) -> int:
        """
        Classify an action into one of the Seven Rings.
        Returns ring number 1-7.
        """
        desc_lower  = description.lower()
        payload_str = json.dumps(payload)

        # Ring 7 patterns — always highest priority
        for pattern in RING7_PATTERNS:
            if re.search(pattern, payload_str, re.IGNORECASE):
                return 7
            if re.search(pattern, desc_lower, re.IGNORECASE):
                return 7

        # Check for OS-critical paths
        for crit_path in OS_CRITICAL_PATHS:
            if crit_path in payload_str or crit_path in desc_lower:
                return 7

        # Ring 7 action types
        ring7_types = {
            "network_connect", "external_http", "websocket_connect",
            "hardware_access", "privilege_escalate", "user_modify",
            "binary_execute_unapproved", "os_critical_write",
        }
        if action_type in ring7_types:
            return 7

        # Ring 6 patterns — advisory
        for pattern in RING6_PATTERNS:
            if re.search(pattern, payload_str, re.IGNORECASE):
                return 6

        ring6_types = {
            "process_signal", "systemd_interact", "port_bind_new",
            "firewall_rule_change", "large_disk_op", "external_file_modify",
        }
        if action_type in ring6_types:
            return 6

        # Ring 5 — host OS non-destructive writes
        ring5_types = {
            "host_dir_create", "host_file_write", "package_install",
            "shell_exec_safe", "symlink_create",
        }
        if action_type in ring5_types:
            return 5

        # Ring 4 — Zeus process adaptation
        ring4_types = {
            "env_var_set", "route_reconfigure", "scheduler_modify",
            "worker_restart", "db_manage", "log_archive",
        }
        if action_type in ring4_types:
            return 4

        # Ring 3 — learning / reading host
        ring3_types = {
            "file_read", "dir_scan", "system_info_query",
            "capability_scan", "process_list_read",
        }
        if action_type in ring3_types:
            return 3

        # Ring 2 — build/compile/test
        ring2_types = {
            "sandbox_run", "forge_pipeline", "compile_code",
            "apk_build", "stress_test", "validate_module",
        }
        if action_type in ring2_types:
            return 2

        # Ring 1 — self modification (default for Zeus modules)
        ring1_types = {
            "module_create", "module_modify", "module_delete", "module_deploy",
            "genome_write", "weight_update", "config_write", "db_write",
            "evolved_module_deploy", "blueprint_generate", "version_replace",
            "archive_old_version",
        }
        if action_type in ring1_types:
            return 1

        # Default: Ring 4 (safe Zeus-scoped operation)
        return 4

    # ─── ACTION EXECUTION ────────────────────────────────────────────────────

    def execute(self, action_type: str, description: str,
                payload: Dict[str, Any],
                callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        Main entry point. Classify, gate if needed, execute.
        Returns immediately for Ring 1-5 with result.
        Returns pending dict for Ring 6-7.
        """
        ring = self.classify_action(action_type, description, payload)
        self._ring_counters[ring] += 1

        action_id = "act_" + uuid.uuid4().hex[:12]

        if ring <= 5:
            # FULL AUTONOMOUS — execute immediately
            result = self._execute_autonomous(action_id, ring, action_type,
                                               description, payload)
            self._log_action(action_id, ring, action_type, description,
                             payload, "executed", result)
            return {"status": "executed", "ring": ring, "action_id": action_id,
                    "result": result}

        elif ring == 6:
            # ADVISORY — queue, proceed after window unless vetoed
            return self._queue_advisory(action_id, action_type, description,
                                        payload, callback)

        else:  # ring == 7
            # PERMISSION REQUIRED — queue and wait for human
            return self._queue_permission(action_id, action_type, description,
                                          payload, callback)

    def _execute_autonomous(self, action_id: str, ring: int,
                             action_type: str, description: str,
                             payload: Dict[str, Any]) -> Dict[str, Any]:
        """Execute an autonomous (Ring 1-5) action directly."""
        log.info("[sovereignty] RING %d AUTO | %s | %s", ring, action_type, description[:80])
        try:
            handler = self._get_action_handler(action_type)
            if handler:
                return handler(payload)
            # Generic execution for unregistered types
            return {"executed": True, "action_type": action_type,
                    "note": "generic_execution"}
        except Exception as exc:
            log.error("[sovereignty] action failed: %s", exc)
            return {"executed": False, "error": str(exc)}

    def _get_action_handler(self, action_type: str) -> Optional[Callable]:
        """Return the handler function for a given action type."""
        handlers = {
            "module_create":         self._handle_module_create,
            "module_modify":         self._handle_module_modify,
            "module_delete":         self._handle_module_delete,
            "module_deploy":         self._handle_module_deploy,
            "version_replace":       self._handle_version_replace,
            "archive_old_version":   self._handle_archive_version,
            "file_read":             self._handle_file_read,
            "dir_scan":              self._handle_dir_scan,
            "host_dir_create":       self._handle_host_dir_create,
            "host_file_write":       self._handle_host_file_write,
            "shell_exec_safe":       self._handle_shell_exec_safe,
            "package_install":       self._handle_package_install,
            "system_info_query":     self._handle_system_info_query,
            "capability_scan":       self._handle_capability_scan,
            "sandbox_run":           self._handle_sandbox_run,
            "validate_module":       self._handle_validate_module,
            "db_write":              self._handle_db_write,
            "genome_write":          self._handle_genome_write,
            "config_write":          self._handle_config_write,
            "env_var_set":           self._handle_env_var_set,
            "log_archive":           self._handle_log_archive,
        }
        return handlers.get(action_type)

    # ─── ACTION HANDLERS ─────────────────────────────────────────────────────

    def _handle_module_create(self, payload: Dict) -> Dict:
        path      = payload.get("path", "")
        code      = payload.get("code", "")
        overwrite = payload.get("overwrite", False)
        if not path or not code:
            return {"error": "path and code required"}
        if not overwrite and os.path.exists(path):
            return {"error": "file exists, use overwrite=true or version_replace"}
        # Ensure author header present
        if AUTHOR_HEADER.strip() not in code:
            code = AUTHOR_HEADER + code
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(code)
        log.info("[sovereignty] created module: %s", path)
        return {"created": True, "path": path, "size": len(code)}

    def _handle_module_modify(self, payload: Dict) -> Dict:
        path    = payload.get("path", "")
        old_str = payload.get("old_str", "")
        new_str = payload.get("new_str", "")
        if not path or not os.path.exists(path):
            return {"error": "path not found: " + path}
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        if old_str and old_str not in content:
            return {"error": "old_str not found in file"}
        if old_str:
            new_content = content.replace(old_str, new_str, 1)
        else:
            new_content = payload.get("full_content", content)
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
        return {"modified": True, "path": path}

    def _handle_module_delete(self, payload: Dict) -> Dict:
        path = payload.get("path", "")
        if not path:
            return {"error": "path required"}
        # Safety: only delete within Zeus dirs or evolved dirs
        safe_roots = [ZEUS_DIR, EVOLVED_DIR, SOVEREIGNTY_DIR, ARCHIVE_DIR]
        if not any(os.path.abspath(path).startswith(r) for r in safe_roots):
            return {"error": "delete outside Zeus dirs requires Ring 6/7 classification"}
        if os.path.isfile(path):
            os.remove(path)
        elif os.path.isdir(path):
            shutil.rmtree(path)
        return {"deleted": True, "path": path}

    def _handle_module_deploy(self, payload: Dict) -> Dict:
        src  = payload.get("src", "")
        dest = payload.get("dest", "")
        if not src or not dest:
            return {"error": "src and dest required"}
        if not os.path.exists(src):
            return {"error": "src not found: " + src}
        os.makedirs(os.path.dirname(dest) if os.path.dirname(dest) else ".", exist_ok=True)
        shutil.copy2(src, dest)
        log.info("[sovereignty] deployed %s -> %s", src, dest)
        return {"deployed": True, "src": src, "dest": dest}

    def _handle_version_replace(self, payload: Dict) -> Dict:
        old_path    = payload.get("old_path", "")
        new_path    = payload.get("new_path", "")
        archive     = payload.get("archive", True)
        if not old_path or not new_path:
            return {"error": "old_path and new_path required"}
        archived_path = None
        if archive and os.path.exists(old_path):
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            archive_name = os.path.basename(old_path) + ".archive_" + ts
            archived_path = os.path.join(ARCHIVE_DIR, archive_name)
            shutil.copy2(old_path, archived_path)
        shutil.copy2(new_path, old_path)
        log.info("[sovereignty] version replaced: %s (archived: %s)", old_path, archived_path)
        return {"replaced": True, "old_path": old_path,
                "archived_path": archived_path}

    def _handle_archive_version(self, payload: Dict) -> Dict:
        path = payload.get("path", "")
        if not path or not os.path.exists(path):
            return {"error": "path not found"}
        ts   = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        name = os.path.basename(path) + ".archive_" + ts
        dest = os.path.join(ARCHIVE_DIR, name)
        shutil.copy2(path, dest)
        return {"archived": True, "source": path, "archive": dest}

    def _handle_file_read(self, payload: Dict) -> Dict:
        path    = payload.get("path", "")
        max_kb  = payload.get("max_kb", 128)
        if not path or not os.path.exists(path):
            return {"error": "not found: " + path}
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read(max_kb * 1024)
            return {"content": content, "path": path,
                    "truncated": os.path.getsize(path) > max_kb * 1024}
        except Exception as exc:
            return {"error": str(exc)}

    def _handle_dir_scan(self, payload: Dict) -> Dict:
        path    = payload.get("path", ZEUS_DIR)
        depth   = payload.get("depth", 2)
        results = []
        try:
            for root, dirs, files in os.walk(path):
                rel = os.path.relpath(root, path)
                lvl = len(rel.split(os.sep)) if rel != "." else 0
                if lvl >= depth:
                    dirs.clear()
                    continue
                for f in files:
                    fpath = os.path.join(root, f)
                    try:
                        size = os.path.getsize(fpath)
                    except OSError:
                        size = 0
                    results.append({"path": fpath, "size": size,
                                    "rel": os.path.join(rel, f)})
        except Exception as exc:
            return {"error": str(exc)}
        return {"files": results, "count": len(results), "root": path}

    def _handle_host_dir_create(self, payload: Dict) -> Dict:
        path = payload.get("path", "")
        if not path:
            return {"error": "path required"}
        os.makedirs(path, exist_ok=True)
        return {"created": True, "path": path}

    def _handle_host_file_write(self, payload: Dict) -> Dict:
        path    = payload.get("path", "")
        content = payload.get("content", "")
        if not path:
            return {"error": "path required"}
        # Block OS-critical paths
        abs_path = os.path.abspath(path)
        for crit in OS_CRITICAL_PATHS:
            if abs_path.startswith(crit):
                return {"error": "OS-critical path blocked — requires Ring 7 permission"}
        os.makedirs(os.path.dirname(abs_path) if os.path.dirname(abs_path) else ".", exist_ok=True)
        with open(abs_path, "w", encoding="utf-8") as f:
            f.write(content)
        return {"written": True, "path": abs_path, "size": len(content)}

    def _handle_shell_exec_safe(self, payload: Dict) -> Dict:
        cmd     = payload.get("cmd", "")
        timeout = payload.get("timeout", 30)
        cwd     = payload.get("cwd", ZEUS_DIR)
        if not cmd:
            return {"error": "cmd required"}
        # Block dangerous patterns
        dangerous = ["rm -rf /", "mkfs", "dd if=", ":(){ :", "> /dev/sda",
                     "sudo", "su -", "chmod 777 /", "chown root"]
        for d in dangerous:
            if d in cmd:
                return {"error": "dangerous command blocked — classify as Ring 7"}
        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True,
                timeout=timeout, cwd=cwd
            )
            return {"stdout": result.stdout, "stderr": result.stderr,
                    "returncode": result.returncode,
                    "success": result.returncode == 0}
        except subprocess.TimeoutExpired:
            return {"error": "timeout after {}s".format(timeout)}
        except Exception as exc:
            return {"error": str(exc)}

    def _handle_package_install(self, payload: Dict) -> Dict:
        package = payload.get("package", "")
        method  = payload.get("method", "pip")   # pip or pkg
        if not package:
            return {"error": "package required"}
        if method == "pip":
            cmd = "pip install {} --break-system-packages -q".format(package)
        else:
            cmd = "pkg install -y {}".format(package)
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True,
                                    text=True, timeout=120)
            return {"installed": result.returncode == 0, "package": package,
                    "stdout": result.stdout[-500:], "stderr": result.stderr[-500:]}
        except Exception as exc:
            return {"error": str(exc)}

    def _handle_system_info_query(self, payload: Dict) -> Dict:
        info = {}
        try:
            info["platform"]  = platform.platform()
            info["machine"]   = platform.machine()
            info["processor"] = platform.processor()
            info["python"]    = sys.version
            info["cwd"]       = os.getcwd()
            info["home"]      = os.path.expanduser("~")
            info["path"]      = os.environ.get("PATH", "")
            # Memory
            try:
                with open("/proc/meminfo") as f:
                    mem = {}
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 2:
                            mem[parts[0].rstrip(":")] = parts[1]
                info["memory"] = mem
            except Exception:
                pass
            # CPU
            try:
                with open("/proc/cpuinfo") as f:
                    cpuinfo = f.read()
                info["cpu_count"] = cpuinfo.count("processor\t:")
            except Exception:
                pass
            # Disk
            try:
                stat = os.statvfs(ZEUS_DIR)
                info["disk_free_mb"]  = (stat.f_bavail * stat.f_frsize) // (1024*1024)
                info["disk_total_mb"] = (stat.f_blocks * stat.f_frsize) // (1024*1024)
            except Exception:
                pass
        except Exception as exc:
            info["error"] = str(exc)
        return info

    def _handle_capability_scan(self, payload: Dict) -> Dict:
        """Scan host for installed tools, runtimes, languages, frameworks."""
        tools = {
            "python3": "python3 --version",
            "python":  "python --version",
            "gcc":     "gcc --version",
            "g++":     "g++ --version",
            "java":    "java -version",
            "node":    "node --version",
            "npm":     "npm --version",
            "git":     "git --version",
            "curl":    "curl --version",
            "wget":    "wget --version",
            "openssl": "openssl version",
            "sqlite3": "sqlite3 --version",
            "pkg":     "pkg --version",
            "pip":     "pip --version",
            "bash":    "bash --version",
            "adb":     "adb --version",
            "termux":  "echo $PREFIX",
        }
        capabilities = {}
        for tool, cmd in tools.items():
            try:
                r = subprocess.run(cmd, shell=True, capture_output=True,
                                   text=True, timeout=5)
                if r.returncode == 0:
                    out = (r.stdout + r.stderr).strip().split("\n")[0]
                    capabilities[tool] = {"available": True, "version": out[:100]}
                else:
                    capabilities[tool] = {"available": False}
            except Exception:
                capabilities[tool] = {"available": False}

        # Store capabilities
        scan_id = "scan_" + uuid.uuid4().hex[:8]
        scanned_at = datetime.now(timezone.utc).isoformat()
        with self._scan_lock:
            self._host_capabilities = capabilities
        try:
            con = sqlite3.connect(DB_PATH)
            for name, info in capabilities.items():
                con.execute(
                    "INSERT INTO sovereignty_capabilities "
                    "(scan_id, category, name, value, scanned_at) VALUES (?,?,?,?,?)",
                    (scan_id, "tool", name, json.dumps(info), scanned_at)
                )
            con.commit()
            con.close()
        except Exception:
            pass
        return {"scan_id": scan_id, "capabilities": capabilities,
                "tool_count": len([v for v in capabilities.values() if v.get("available")])}

    def _handle_sandbox_run(self, payload: Dict) -> Dict:
        """Run code in Zeus sandbox (delegates to zeus_sandbox if available)."""
        code    = payload.get("code", "")
        timeout = payload.get("timeout", 30)
        if not code:
            return {"error": "code required"}
        try:
            # Write to temp file and exec isolated
            with tempfile.NamedTemporaryFile(suffix=".py", dir=SOVEREIGNTY_DIR,
                                             mode="w", delete=False,
                                             encoding="utf-8") as tf:
                tf.write(code)
                tmp_path = tf.name
            result = subprocess.run(
                [sys.executable, tmp_path],
                capture_output=True, text=True, timeout=timeout,
                cwd=SOVEREIGNTY_DIR
            )
            os.unlink(tmp_path)
            return {
                "stdout":     result.stdout,
                "stderr":     result.stderr,
                "returncode": result.returncode,
                "success":    result.returncode == 0,
                "passed":     result.returncode == 0 and not result.stderr.strip(),
            }
        except subprocess.TimeoutExpired:
            return {"error": "sandbox timeout", "passed": False}
        except Exception as exc:
            return {"error": str(exc), "passed": False}

    def _handle_validate_module(self, payload: Dict) -> Dict:
        """AST-validate + basic runtime check a Python module."""
        path = payload.get("path", "")
        code = payload.get("code", "")
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                code = f.read()
        if not code:
            return {"error": "no code to validate"}
        issues = []
        # AST parse
        try:
            tree = ast.parse(code)
        except SyntaxError as exc:
            return {"valid": False, "score": 0.0,
                    "issues": ["SyntaxError: " + str(exc)]}
        # Check for stubs
        for node in ast.walk(tree):
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
                if node.value.value == "TODO" or node.value.value == "STUB":
                    issues.append("stub detected at line " + str(node.lineno))
        # Check author header
        if AUTHOR_HEADER.strip() not in code:
            issues.append("missing author header")
        # Check for armv7l unsafe patterns
        if ":=" in code:
            issues.append("walrus operator := not armv7l safe")
        fstring_count = code.count("f\"") + code.count("f'")
        if fstring_count > 0:
            issues.append("{} f-strings detected — not armv7l safe".format(fstring_count))
        score = max(0.0, 1.0 - len(issues) * 0.15)
        return {"valid": len(issues) == 0, "score": round(score, 2),
                "issues": issues, "lines": len(code.splitlines()),
                "functions": sum(1 for n in ast.walk(tree) if isinstance(n, ast.FunctionDef))}

    def _handle_db_write(self, payload: Dict) -> Dict:
        sql    = payload.get("sql", "")
        params = payload.get("params", [])
        db     = payload.get("db", DB_PATH)
        if not sql:
            return {"error": "sql required"}
        try:
            con = sqlite3.connect(db)
            con.execute(sql, params)
            con.commit()
            con.close()
            return {"written": True}
        except Exception as exc:
            return {"error": str(exc)}

    def _handle_genome_write(self, payload: Dict) -> Dict:
        """Write a genome segment via genome_manager if available."""
        try:
            import genome_manager as gm
            name        = payload.get("name", "")
            source_code = payload.get("source_code", "")
            description = payload.get("description", "")
            capabilities = payload.get("capabilities", "")
            module_type  = payload.get("module_type", "sovereignty_build")
            if not name or not source_code:
                return {"error": "name and source_code required"}
            # Use genome_manager store function
            if hasattr(gm, "store_genome"):
                result = gm.store_genome(name, description, module_type,
                                          source_code, capabilities)
                return {"stored": True, "result": str(result)}
            return {"stored": False, "note": "genome_manager.store_genome not found"}
        except ImportError:
            return {"stored": False, "note": "genome_manager not available"}

    def _handle_config_write(self, payload: Dict) -> Dict:
        config_key = payload.get("key", "")
        config_val = payload.get("value", "")
        config_file = payload.get("file", os.path.join(ZEUS_DIR, "zeus_sovereignty_config.json"))
        existing = {}
        if os.path.exists(config_file):
            try:
                with open(config_file, "r") as f:
                    existing = json.load(f)
            except Exception:
                pass
        existing[config_key] = config_val
        with open(config_file, "w") as f:
            json.dump(existing, f, indent=2)
        return {"written": True, "key": config_key, "file": config_file}

    def _handle_env_var_set(self, payload: Dict) -> Dict:
        key = payload.get("key", "")
        val = payload.get("value", "")
        if not key:
            return {"error": "key required"}
        os.environ[key] = str(val)
        return {"set": True, "key": key}

    def _handle_log_archive(self, payload: Dict) -> Dict:
        log_dir = payload.get("log_dir", LOGS_DIR)
        max_age_days = payload.get("max_age_days", 7)
        now = time.time()
        archived = []
        try:
            for fname in os.listdir(log_dir):
                fpath = os.path.join(log_dir, fname)
                if os.path.isfile(fpath):
                    age_days = (now - os.path.getmtime(fpath)) / 86400
                    if age_days > max_age_days:
                        dest = os.path.join(ARCHIVE_DIR, fname)
                        shutil.move(fpath, dest)
                        archived.append(fname)
        except Exception as exc:
            return {"error": str(exc)}
        return {"archived": archived, "count": len(archived)}

    # ─── RING 6 ADVISORY ─────────────────────────────────────────────────────

    def _queue_advisory(self, action_id: str, action_type: str,
                        description: str, payload: Dict,
                        callback: Optional[Callable]) -> Dict:
        import datetime as dt_module
        window_s = RING_DEFS[6]["advisory_window_s"]
        advisory_until = (
            datetime.now(timezone.utc).timestamp() + window_s
        )
        advisory_until_iso = datetime.fromtimestamp(
            advisory_until, tz=timezone.utc
        ).isoformat()

        req = PermissionRequest(
            request_id     = action_id,
            ring           = 6,
            action_type    = action_type,
            description    = description,
            payload        = payload,
            status         = "pending",
            advisory_until = advisory_until_iso,
            callback       = callback,
        )
        with self._pending_lock:
            self._pending_requests[action_id] = req
        self._persist_permission(req)
        log.info("[sovereignty] RING 6 ADVISORY: %s — proceeds in %ds unless vetoed",
                 description[:60], window_s)
        return {"status": "advisory", "ring": 6, "action_id": action_id,
                "advisory_until": advisory_until_iso,
                "message": "Zeus will proceed in {}s unless vetoed via POST /api/sovereignty/veto/{}".format(
                    window_s, action_id)}

    def _advisory_watcher(self):
        """Background thread that auto-proceeds Ring 6 actions after window."""
        while True:
            time.sleep(2)
            now = datetime.now(timezone.utc).timestamp()
            to_proceed = []
            with self._pending_lock:
                for rid, req in list(self._pending_requests.items()):
                    if req.ring == 6 and req.status == "pending":
                        if req.advisory_until:
                            until_ts = datetime.fromisoformat(
                                req.advisory_until
                            ).timestamp()
                            if now >= until_ts:
                                req.status = "auto_proceeded"
                                to_proceed.append(req)
            for req in to_proceed:
                log.info("[sovereignty] RING 6 AUTO-PROCEED: %s", req.description[:60])
                result = self._execute_autonomous(
                    req.request_id, 6, req.action_type,
                    req.description, req.payload
                )
                self._log_action(req.request_id, 6, req.action_type,
                                  req.description, req.payload,
                                  "auto_proceeded", result)
                self._update_permission_status(
                    req.request_id, "auto_proceeded", "zeus_advisory_timer"
                )
                if req.callback:
                    try:
                        req.callback(result)
                    except Exception:
                        pass
                with self._pending_lock:
                    self._pending_requests.pop(req.request_id, None)

    # ─── RING 7 PERMISSION ───────────────────────────────────────────────────

    def _queue_permission(self, action_id: str, action_type: str,
                          description: str, payload: Dict,
                          callback: Optional[Callable]) -> Dict:
        req = PermissionRequest(
            request_id  = action_id,
            ring        = 7,
            action_type = action_type,
            description = description,
            payload     = payload,
            status      = "pending",
            callback    = callback,
        )
        with self._pending_lock:
            self._pending_requests[action_id] = req
        self._persist_permission(req)
        log.info("[sovereignty] RING 7 PERMISSION REQUIRED: %s | id=%s",
                 description[:60], action_id)
        return {"status": "pending_permission", "ring": 7, "action_id": action_id,
                "message": "Human approval required. POST /api/sovereignty/approve/{} to approve.".format(action_id),
                "description": description}

    def approve(self, request_id: str, approved_by: str = "human") -> Dict:
        with self._pending_lock:
            req = self._pending_requests.get(request_id)
        if not req:
            return {"error": "request not found: " + request_id}
        if req.status != "pending":
            return {"error": "request already resolved: " + req.status}
        req.status     = "approved"
        req.resolved_at = datetime.now(timezone.utc).isoformat()
        req.resolved_by = approved_by
        # Execute the approved action
        result = self._execute_autonomous(
            req.request_id, req.ring, req.action_type,
            req.description, req.payload
        )
        self._log_action(req.request_id, req.ring, req.action_type,
                          req.description, req.payload, "approved_executed", result)
        self._update_permission_status(request_id, "approved", approved_by)
        if req.callback:
            try:
                req.callback(result)
            except Exception:
                pass
        with self._pending_lock:
            self._pending_requests.pop(request_id, None)
        log.info("[sovereignty] RING 7 APPROVED by %s: %s", approved_by, req.description[:60])
        return {"approved": True, "request_id": request_id, "result": result}

    def deny(self, request_id: str, denied_by: str = "human",
             reason: str = "") -> Dict:
        with self._pending_lock:
            req = self._pending_requests.pop(request_id, None)
        if not req:
            return {"error": "request not found: " + request_id}
        req.status       = "denied"
        req.resolved_at  = datetime.now(timezone.utc).isoformat()
        req.resolved_by  = denied_by
        req.denial_reason = reason
        self._update_permission_status(request_id, "denied", denied_by)
        log.info("[sovereignty] RING 7 DENIED by %s: %s | reason: %s",
                 denied_by, req.description[:60], reason)
        return {"denied": True, "request_id": request_id, "reason": reason}

    def veto(self, request_id: str, vetoed_by: str = "human") -> Dict:
        """Veto a Ring 6 advisory action before it auto-proceeds."""
        with self._pending_lock:
            req = self._pending_requests.pop(request_id, None)
        if not req:
            return {"error": "request not found or already proceeded: " + request_id}
        if req.ring != 6:
            return {"error": "veto only applies to Ring 6 advisory actions"}
        req.status      = "vetoed"
        req.resolved_at = datetime.now(timezone.utc).isoformat()
        req.resolved_by = vetoed_by
        self._update_permission_status(request_id, "vetoed", vetoed_by)
        log.info("[sovereignty] RING 6 VETOED by %s: %s", vetoed_by, req.description[:60])
        return {"vetoed": True, "request_id": request_id}

    # ─── BLUEPRINT SYNTHESIS ENGINE ──────────────────────────────────────────

    def synthesise_new_module(self, goal: str, target_system: str = "zeus",
                               base_module: Optional[str] = None) -> Dict:
        """
        Full autonomous module synthesis pipeline:
        1. Query genome + knowledge for context
        2. Select base module blueprint
        3. Generate new module via LLM
        4. Sandbox validate
        5. Gate Ring 7 actions
        6. Deploy and register
        """
        build_id = "build_" + uuid.uuid4().hex[:12]
        log.info("[sovereignty] synthesis started: %s | goal: %s", build_id, goal[:80])

        build = BuildRecord(
            build_id      = build_id,
            goal          = goal,
            target_system = target_system,
            base_module   = base_module,
            genome_ids    = [],
            knowledge_used = {},
            build_log     = "",
        )

        def _log(msg):
            build.build_log += "[{}] {}\n".format(
                datetime.now(timezone.utc).strftime("%H:%M:%S"), msg
            )
            log.info("[sovereignty] [%s] %s", build_id, msg)

        with self._build_lock:
            self._active_builds[build_id] = build

        try:
            build.status = "building"

            # Step 1: Query genome for relevant segments
            _log("Step 1: querying genome for relevant patterns")
            genome_context = self._query_genome(goal)
            build.genome_ids = genome_context.get("genome_ids", [])
            build.knowledge_used["genome"] = genome_context.get("summary", "")
            _log("found {} genome segments".format(len(build.genome_ids)))

            # Step 2: Query Tartarus knowledge pool
            _log("Step 2: querying Tartarus knowledge pool")
            tartarus_context = self._query_tartarus(goal)
            build.knowledge_used["tartarus"] = tartarus_context

            # Step 3: Query SysAware for host capabilities
            _log("Step 3: querying host capabilities")
            host_ctx = self._host_capabilities or {}
            build.knowledge_used["host"] = {
                k: v for k, v in host_ctx.items() if v.get("available")
            }

            # Step 4: Select base module
            _log("Step 4: selecting base module blueprint")
            if not base_module:
                base_module = self._select_base_module(goal, target_system)
            build.base_module = base_module
            base_code = self._read_base_module(base_module) if base_module else ""
            _log("base module: {}".format(base_module or "none"))

            # Step 5: Generate new module via LLM
            _log("Step 5: generating new module via LLM")
            generated = self._generate_module_via_llm(
                goal, target_system, base_code,
                genome_context, tartarus_context,
                build.knowledge_used.get("host", {})
            )
            if "error" in generated:
                build.status = "failed"
                _log("LLM generation failed: " + generated["error"])
                self._persist_build(build)
                return {"build_id": build_id, "status": "failed",
                        "error": generated["error"]}

            build.generated_code = generated.get("code", "")
            build.ring_actions   = generated.get("ring_actions", [])
            _log("generated {} lines of code".format(
                len(build.generated_code.splitlines())))

            # Step 6: Sandbox validation
            _log("Step 6: sandbox validation")
            build.status = "sandbox"
            val_result = self.execute(
                "validate_module", "validate generated module",
                {"code": build.generated_code}
            )
            sandbox_result = self.execute(
                "sandbox_run", "sandbox run generated module",
                {"code": build.generated_code, "timeout": 20}
            )
            build.sandbox_result = {
                "validation": val_result.get("result", {}),
                "sandbox":    sandbox_result.get("result", {}),
            }
            val_score = val_result.get("result", {}).get("score", 0.0)
            build.quality_score = val_score
            _log("quality score: {:.2f}".format(val_score))

            if val_score < 0.60:
                build.status = "failed"
                _log("quality gate failed (score {:.2f} < 0.60)".format(val_score))
                self._persist_build(build)
                return {"build_id": build_id, "status": "failed",
                        "quality_score": val_score,
                        "issues": val_result.get("result", {}).get("issues", [])}

            # Step 7: Check if any Ring 7 actions needed
            ring7_needed = [a for a in build.ring_actions if a.get("ring") == 7]
            if ring7_needed:
                build.status = "awaiting_permission"
                _log("Ring 7 actions required: {} — requesting human permission".format(
                    len(ring7_needed)))
                self._persist_build(build)
                return {
                    "build_id":     build_id,
                    "status":       "awaiting_permission",
                    "quality_score": val_score,
                    "ring7_actions": ring7_needed,
                    "message": "Approve Ring 7 actions to complete deployment",
                }

            # Step 8: Deploy
            _log("Step 8: deploying validated module")
            deploy_result = self._deploy_build(build)
            build.deployed_path = deploy_result.get("deployed_path")
            build.status        = "deployed"
            build.completed_at  = datetime.now(timezone.utc).isoformat()
            _log("deployed to: {}".format(build.deployed_path))

            # Step 9: Register in genome
            _log("Step 9: registering in genome lineage")
            self.execute("genome_write", "register new module in genome",
                         {"name": goal[:80], "source_code": build.generated_code,
                          "description": "Synthesised by SovereigntyEngine: " + goal,
                          "capabilities": target_system + ",sovereignty_build",
                          "module_type": "sovereignty_synthesised"})

            self._persist_build(build)
            return {
                "build_id":       build_id,
                "status":         "deployed",
                "quality_score":  build.quality_score,
                "deployed_path":  build.deployed_path,
                "lines":          len(build.generated_code.splitlines()),
            }

        except Exception as exc:
            build.status = "failed"
            build.build_log += "\nFATAL: " + traceback.format_exc()
            self._persist_build(build)
            return {"build_id": build_id, "status": "failed",
                    "error": str(exc)}

    def _query_genome(self, goal: str) -> Dict:
        """Query genome_manager for relevant genome segments."""
        try:
            import genome_manager as gm
            if hasattr(gm, "search_genomes"):
                results = gm.search_genomes(goal, limit=5)
                ids = [r.get("genome_id", "") for r in results]
                summary = " | ".join([r.get("name", "") for r in results])
                return {"genome_ids": ids, "summary": summary, "segments": results}
        except Exception:
            pass
        # Fallback: search DB directly
        try:
            con = sqlite3.connect(DB_PATH)
            con.row_factory = sqlite3.Row
            rows = con.execute(
                "SELECT genome_id, name, description, capabilities FROM genomes "
                "WHERE name LIKE ? OR description LIKE ? OR capabilities LIKE ? LIMIT 5",
                ("%"+goal[:30]+"%",)*3
            ).fetchall()
            con.close()
            ids = [r["genome_id"] for r in rows]
            summary = " | ".join([r["name"] for r in rows])
            return {"genome_ids": ids, "summary": summary}
        except Exception:
            return {"genome_ids": [], "summary": ""}

    def _query_tartarus(self, goal: str) -> str:
        """Query Tartarus pool for relevant knowledge."""
        try:
            from zeus_tartarus_core import TartarusMemory
            mem = TartarusMemory()
            ctx = mem.build_context(max_per_field=3)
            return ctx[:2000]
        except Exception:
            return ""

    def _select_base_module(self, goal: str, target_system: str) -> Optional[str]:
        """Select the most relevant existing module as base blueprint."""
        goal_lower = goal.lower()
        # Target system overrides
        if target_system == "ump":
            candidates = ["miner_swarm.py", "ump_profit_switcher.py", "miner_manager.py"]
        elif target_system == "aegis":
            candidates = ["zeus_aegis_engine.py", "zeus_firewall_v1.py"]
        elif target_system == "trader":
            candidates = ["ump_autonomous_trader.py"]
        else:
            # Zeus arch — pick by keyword
            keyword_map = {
                "learn":    "zeus_learner.py",
                "predict":  "zeus_prediction_engine.py",
                "evolve":   "zeus_self_evolution.py",
                "genome":   "genome_manager.py",
                "blueprint":"zeus_blueprints.py",
                "forge":    "zeus_forge.py",
                "sandbox":  "zeus_sandbox.py",
                "apk":      "zeus_apk_engine.py",
                "chat":     "zeus_chat.py",
                "search":   "zeus_search.py",
                "network":  "zeus_replication_engine.py",
                "weight":   "zeus_tartarus_weights.py",
                "tartarus": "zeus_tartarus_core.py",
                "monitor":  "zeus_tartarus_monitor.py",
                "stress":   "zeus_stress_engine.py",
                "system":   "zeus_sys_aware.py",
            }
            candidates = []
            for kw, mod in keyword_map.items():
                if kw in goal_lower:
                    candidates.append(mod)
            if not candidates:
                candidates = ["zeus_learner.py"]

        # Return first existing candidate
        for cand in candidates:
            # Check in zeus_arch
            path = os.path.join(ZEUS_DIR, cand)
            if os.path.exists(path):
                return path
            # Check in ump
            ump_path = os.path.join(os.path.dirname(ZEUS_DIR), "ump", cand)
            if os.path.exists(ump_path):
                return ump_path
        return None

    def _read_base_module(self, path: str) -> str:
        """Read first 4KB of base module as blueprint context."""
        if not path or not os.path.exists(path):
            return ""
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                return f.read(4096)
        except Exception:
            return ""

    def _generate_module_via_llm(self, goal: str, target_system: str,
                                   base_code: str, genome_ctx: Dict,
                                   tartarus_ctx: str,
                                   host_caps: Dict) -> Dict:
        """Generate new module code via LLM (zeus_llm_router)."""
        try:
            from zeus_llm_router import call_llm
        except ImportError:
            return {"error": "zeus_llm_router not available"}

        prompt = """You are Zeus, a self-evolving AI system running on armv7l Android (Termux).

GOAL: Build a new Python module for: {goal}
TARGET SYSTEM: {target_system}

CONSTRAINTS (MANDATORY — armv7l safe):
- NO f-strings. Use .format() or string concatenation only.
- NO walrus operator (:=).
- NO chromadb, langchain, faiss — use SQLite FTS5 instead.
- NO ccxt, pandas-ta — use requests+urllib for any exchange calls.
- SQLite WAL mode on all DB connections.
- Every function must be fully implemented. Zero stubs. Zero TODOs.
- Start with: {header}

BASE MODULE BLUEPRINT (use as structural foundation):
{base}

GENOME KNOWLEDGE (patterns learned from previous evolution):
{genome}

TARTARUS KNOWLEDGE (mathematical patterns and insights):
{tartarus}

HOST CAPABILITIES: {host}

Build the complete module. Include:
1. Full Flask Blueprint with all routes
2. SQLite DB initialisation
3. Core engine class as singleton
4. All helper functions fully implemented
5. APP.PY REGISTRATION comment at top
6. Zero stubs

Return ONLY the Python code, nothing else.""".format(
            goal=goal,
            target_system=target_system,
            header=AUTHOR_HEADER.strip(),
            base=base_code[:1500] if base_code else "(none)",
            genome=genome_ctx.get("summary", "")[:500],
            tartarus=tartarus_ctx[:500],
            host=json.dumps({k: v for k, v in list(host_caps.items())[:8]}),
        )

        try:
            response = call_llm(prompt, max_tokens=4000)
            code = response.strip() if response else ""
            # Strip markdown code fences if present
            if code.startswith("```"):
                lines = code.split("\n")
                code = "\n".join(lines[1:])
                if code.endswith("```"):
                    code = code[:-3].strip()
            # Classify ring actions needed
            ring_actions = self._classify_code_rings(code)
            return {"code": code, "ring_actions": ring_actions}
        except Exception as exc:
            return {"error": str(exc)}

    def _classify_code_rings(self, code: str) -> List[Dict]:
        """Classify what ring actions the generated code would need."""
        actions = []
        for pattern in RING7_PATTERNS:
            matches = re.findall(pattern, code, re.IGNORECASE)
            if matches:
                actions.append({"ring": 7, "pattern": pattern,
                                  "matches": matches[:3]})
        for pattern in RING6_PATTERNS:
            matches = re.findall(pattern, code, re.IGNORECASE)
            if matches:
                actions.append({"ring": 6, "pattern": pattern,
                                  "matches": matches[:3]})
        return actions

    def _deploy_build(self, build: BuildRecord) -> Dict:
        """Write generated code to the correct location and archive old."""
        # Determine deploy path
        module_name = re.sub(r"[^a-z0-9_]", "_", build.goal.lower()[:40])
        module_name = "zeus_sov_" + module_name.strip("_") + ".py"
        deploy_path = os.path.join(EVOLVED_DIR, module_name)

        # Archive old if exists
        if os.path.exists(deploy_path):
            self.execute("archive_old_version", "archive before replace",
                         {"path": deploy_path})

        # Write new
        self.execute("module_create", "deploy synthesised module",
                     {"path": deploy_path, "code": build.generated_code,
                      "overwrite": True})
        return {"deployed_path": deploy_path}

    # ─── PERSISTENCE ─────────────────────────────────────────────────────────

    def _log_action(self, action_id: str, ring: int, action_type: str,
                    description: str, payload: Dict, status: str,
                    result: Optional[Dict]):
        entry = {
            "action_id": action_id, "ring": ring, "action_type": action_type,
            "description": description, "status": status,
            "ts": datetime.now(timezone.utc).isoformat(),
        }
        self._recent_actions.appendleft(entry)
        # Mirror to HiveMemory sovereignty_stream
        try:
            import sys as _sys
            import os as _os
            _hive_dir = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
            if _hive_dir not in _sys.path:
                _sys.path.insert(0, _hive_dir)
            from zeus_hive_bridge import _hive as _h
            _h.mirror_sovereignty(action_type, ring, description, status)
        except Exception:
            pass
        try:
            con = sqlite3.connect(DB_PATH)
            con.execute(
                "INSERT OR IGNORE INTO sovereignty_actions "
                "(action_id, ring, action_type, description, payload_json, "
                "status, result_json, requested_at, resolved_at, resolved_by) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (action_id, ring, action_type, description[:500],
                 json.dumps(payload)[:2000], status,
                 json.dumps(result)[:2000] if result else None,
                 datetime.now(timezone.utc).isoformat(),
                 datetime.now(timezone.utc).isoformat(), "zeus_autonomous")
            )
            con.commit()
            con.close()
        except Exception:
            pass

    def _persist_permission(self, req: PermissionRequest):
        try:
            con = sqlite3.connect(DB_PATH)
            con.execute(
                "INSERT OR IGNORE INTO sovereignty_permissions "
                "(request_id, ring, action_type, description, payload_json, "
                "status, advisory_until, requested_at) VALUES (?,?,?,?,?,?,?,?)",
                (req.request_id, req.ring, req.action_type, req.description[:500],
                 json.dumps(req.payload)[:2000], req.status, req.advisory_until,
                 req.requested_at)
            )
            con.commit()
            con.close()
        except Exception:
            pass

    def _update_permission_status(self, request_id: str, status: str,
                                   resolved_by: str):
        try:
            con = sqlite3.connect(DB_PATH)
            con.execute(
                "UPDATE sovereignty_permissions SET status=?, resolved_at=?, "
                "resolved_by=? WHERE request_id=?",
                (status, datetime.now(timezone.utc).isoformat(),
                 resolved_by, request_id)
            )
            con.commit()
            con.close()
        except Exception:
            pass

    def _persist_build(self, build: BuildRecord):
        try:
            con = sqlite3.connect(DB_PATH)
            con.execute(
                "INSERT OR REPLACE INTO sovereignty_builds "
                "(build_id, goal, target_system, base_module, genome_ids, "
                "knowledge_used, generated_code, ring_actions, sandbox_result, "
                "quality_score, status, deployed_path, archived_path, build_log, "
                "created_at, completed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (build.build_id, build.goal[:200], build.target_system,
                 build.base_module or "",
                 json.dumps(build.genome_ids),
                 json.dumps(build.knowledge_used)[:2000],
                 build.generated_code[:50000],
                 json.dumps(build.ring_actions),
                 json.dumps(build.sandbox_result) if build.sandbox_result else None,
                 build.quality_score, build.status,
                 build.deployed_path or "", build.archived_path or "",
                 build.build_log[:10000],
                 build.created_at, build.completed_at)
            )
            con.commit()
            con.close()
        except Exception as exc:
            log.error("[sovereignty] persist_build failed: %s", exc)

    def get_status(self) -> Dict:
        with self._pending_lock:
            pending_count = len(self._pending_requests)
            pending_ring7 = sum(1 for r in self._pending_requests.values()
                                if r.ring == 7)
            pending_ring6 = sum(1 for r in self._pending_requests.values()
                                if r.ring == 6)
        with self._build_lock:
            active_builds = len(self._active_builds)
        return {
            "engine": "online",
            "ring_counters": dict(self._ring_counters),
            "pending_total": pending_count,
            "pending_ring7_permission": pending_ring7,
            "pending_ring6_advisory":   pending_ring6,
            "active_builds": active_builds,
            "recent_actions": list(self._recent_actions)[:20],
            "host_capabilities_scanned": len(self._host_capabilities) > 0,
        }


# ─── ENGINE SINGLETON ────────────────────────────────────────────────────────

_engine: Optional[SovereigntyEngine] = None
_engine_lock = threading.Lock()

def get_engine() -> SovereigntyEngine:
    global _engine
    if _engine is None:
        with _engine_lock:
            if _engine is None:
                _engine = SovereigntyEngine()
    return _engine

# Initialise at import time
get_engine()


# ─── FLASK ROUTES ────────────────────────────────────────────────────────────

@sovereignty_bp.route("/api/sovereignty/status", methods=["GET"])
def api_status():
    return jsonify(get_engine().get_status())

@sovereignty_bp.route("/api/sovereignty/rings", methods=["GET"])
def api_rings():
    return jsonify({"rings": RING_DEFS})

@sovereignty_bp.route("/api/sovereignty/actions", methods=["GET"])
def api_actions():
    limit = int(request.args.get("limit", 50))
    try:
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT * FROM sovereignty_actions ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
        con.close()
        return jsonify({"actions": [dict(r) for r in rows]})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@sovereignty_bp.route("/api/sovereignty/pending", methods=["GET"])
def api_pending():
    eng = get_engine()
    with eng._pending_lock:
        pending = [
            {
                "request_id":    r.request_id,
                "ring":          r.ring,
                "action_type":   r.action_type,
                "description":   r.description,
                "status":        r.status,
                "advisory_until": r.advisory_until,
                "requested_at":  r.requested_at,
                "ring_name":     RING_DEFS[r.ring]["name"],
                "ring_label":    RING_DEFS[r.ring]["label"],
            }
            for r in eng._pending_requests.values()
        ]
    return jsonify({"pending": pending, "count": len(pending)})

@sovereignty_bp.route("/api/sovereignty/approve/<request_id>", methods=["POST"])
def api_approve(request_id):
    data       = request.get_json(silent=True) or {}
    approved_by = data.get("approved_by", "human")
    result     = get_engine().approve(request_id, approved_by)
    return jsonify(result)

@sovereignty_bp.route("/api/sovereignty/deny/<request_id>", methods=["POST"])
def api_deny(request_id):
    data    = request.get_json(silent=True) or {}
    reason  = data.get("reason", "")
    denied_by = data.get("denied_by", "human")
    result  = get_engine().deny(request_id, denied_by, reason)
    return jsonify(result)

@sovereignty_bp.route("/api/sovereignty/veto/<request_id>", methods=["POST"])
def api_veto(request_id):
    data     = request.get_json(silent=True) or {}
    vetoed_by = data.get("vetoed_by", "human")
    result   = get_engine().veto(request_id, vetoed_by)
    return jsonify(result)

@sovereignty_bp.route("/api/sovereignty/permissions", methods=["GET"])
def api_permissions():
    limit = int(request.args.get("limit", 50))
    try:
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT * FROM sovereignty_permissions ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
        ledger = con.execute(
            "SELECT * FROM sovereignty_permissions_ledger ORDER BY id DESC LIMIT 50"
        ).fetchall()
        con.close()
        return jsonify({
            "permission_requests": [dict(r) for r in rows],
            "permission_ledger":   [dict(r) for r in ledger],
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@sovereignty_bp.route("/api/sovereignty/build", methods=["POST"])
def api_build():
    data          = request.get_json(silent=True) or {}
    goal          = data.get("goal", "").strip()
    target_system = data.get("target_system", "zeus")
    base_module   = data.get("base_module")
    if not goal:
        return jsonify({"error": "goal required"}), 400

    def _run_build():
        result = get_engine().synthesise_new_module(goal, target_system, base_module)
        log.info("[sovereignty] build completed: %s", result.get("status"))

    thread = threading.Thread(target=_run_build, daemon=True,
                               name="sovereignty-build-" + goal[:20])
    thread.start()
    return jsonify({"status": "building", "goal": goal,
                    "target_system": target_system,
                    "message": "Build started. Poll GET /api/sovereignty/builds for status."})

@sovereignty_bp.route("/api/sovereignty/builds", methods=["GET"])
def api_builds():
    limit = int(request.args.get("limit", 20))
    try:
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT build_id, goal, target_system, base_module, quality_score, "
            "status, deployed_path, created_at, completed_at "
            "FROM sovereignty_builds ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
        con.close()
        return jsonify({"builds": [dict(r) for r in rows]})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@sovereignty_bp.route("/api/sovereignty/build/<build_id>", methods=["GET"])
def api_build_detail(build_id):
    try:
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        row = con.execute(
            "SELECT * FROM sovereignty_builds WHERE build_id=?", (build_id,)
        ).fetchone()
        con.close()
        if not row:
            return jsonify({"error": "not found"}), 404
        return jsonify(dict(row))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@sovereignty_bp.route("/api/sovereignty/scan_system", methods=["POST"])
def api_scan_system():
    result = get_engine().execute(
        "capability_scan", "full host capability scan", {}
    )
    return jsonify(result)

@sovereignty_bp.route("/api/sovereignty/capabilities", methods=["GET"])
def api_capabilities():
    caps = get_engine()._host_capabilities
    if not caps:
        result = get_engine().execute(
            "capability_scan", "capability scan on request", {}
        )
        caps = result.get("result", {}).get("capabilities", {})
    return jsonify({"capabilities": caps,
                    "available": [k for k, v in caps.items() if v.get("available")]})

@sovereignty_bp.route("/api/sovereignty/execute", methods=["POST"])
def api_execute():
    """Generic action execution endpoint."""
    data        = request.get_json(silent=True) or {}
    action_type = data.get("action_type", "")
    description = data.get("description", action_type)
    payload     = data.get("payload", {})
    if not action_type:
        return jsonify({"error": "action_type required"}), 400
    result = get_engine().execute(action_type, description, payload)
    return jsonify(result)

@sovereignty_bp.route("/api/sovereignty/deployments", methods=["GET"])
def api_deployments():
    """List all sovereignty-deployed modules."""
    try:
        deployed = []
        for fname in os.listdir(EVOLVED_DIR):
            fpath = os.path.join(EVOLVED_DIR, fname)
            if os.path.isfile(fpath) and fname.endswith(".py"):
                deployed.append({
                    "filename": fname,
                    "path":     fpath,
                    "size":     os.path.getsize(fpath),
                    "modified": datetime.fromtimestamp(
                        os.path.getmtime(fpath), tz=timezone.utc
                    ).isoformat(),
                })
        return jsonify({"deployments": deployed, "count": len(deployed)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ─── PUBLIC API FOR OTHER MODULES ────────────────────────────────────────────

def sovereign_execute(action_type: str, description: str,
                      payload: Dict[str, Any],
                      callback: Optional[Callable] = None) -> Dict[str, Any]:
    """
    Public function — any Zeus module can call this to execute
    an action through the Seven Ring sovereignty gate.
    Import: from zeus_sovereignty_engine import sovereign_execute
    """
    return get_engine().execute(action_type, description, payload, callback)


def sovereign_build(goal: str, target_system: str = "zeus",
                    base_module: Optional[str] = None) -> Dict[str, Any]:
    """
    Public function — request Zeus to synthesise a new module.
    Import: from zeus_sovereignty_engine import sovereign_build
    """
    return get_engine().synthesise_new_module(goal, target_system, base_module)
