"""
zeus_tartarus_upload.py
The Zeus Project 2026 — Francois Nel

TARTARUS UPLOAD ENGINE — Universal file analysis with 150+ format support

Extends zeus_upload.py with Tartarus-grade deep analysis.
Every uploaded file is:
  1. Format-detected (150+ extensions, mirrors JSX FILE_FORMATS exactly)
  2. Content-extracted per type:
       text/code/web/config → full text extraction
       image                → base64 encoded, sent to Claude vision API
                              (FIXES JSX: correct multipart vision call)
       binary_parseable     → 4KB partial decode
       archive              → manifest listing only
       media                → metadata only
  3. Analysed by Tartarus:
       - Mathematical/structural patterns extracted
       - Hidden patterns in the data
       - Cross-domain connections suggested
       - Predictions derived from file content
  4. Results pushed into TartarusMemory.pool.uploads

Flask blueprint: upload_bp at /api/tartarus/upload/*

armv7l compatible: no f-strings, no walrus operator.
"""

from __future__ import print_function

import os
import sys
import json
import time
import uuid
import base64
import logging
import hashlib
import mimetypes
import threading
import traceback
from collections import OrderedDict
from typing import Any, Dict, List, Optional, Tuple

from flask import Blueprint, jsonify, request

log = logging.getLogger("zeus.tartarus.upload")

upload_bp = Blueprint("tartarus_upload", __name__)

ZEUS_DIR    = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR  = os.path.join(ZEUS_DIR, "tartarus_uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

MAX_TEXT_BYTES  = 120_000   # ~30K tokens
MAX_IMAGE_BYTES = 5_000_000 # 5MB

# ---------------------------------------------------------------------------
# FORMAT REGISTRY — mirrors JSX FILE_FORMATS exactly
# ---------------------------------------------------------------------------

FILE_FORMATS = OrderedDict([
    ("text", {
        "label": "Text & Documents",
        "formats": [
            "txt", "md", "markdown", "rst", "tex", "rtf", "log",
            "nfo", "me", "readme", "csv", "tsv", "tab", "asc",
            "diff", "patch",
        ],
    }),
    ("code", {
        "label": "Source Code",
        "formats": [
            "js", "jsx", "ts", "tsx", "py", "java", "c", "cpp",
            "h", "hpp", "cs", "go", "rs", "rb", "php", "swift",
            "kt", "scala", "r", "m", "sh", "bash", "zsh", "fish",
            "ps1", "bat", "cmd", "asm", "s", "lua", "pl", "pm",
            "ex", "exs", "erl", "hs", "ml", "f90", "f95", "vb",
            "vba", "pas", "d", "nim", "cr", "jl", "dart",
            "groovy", "tcl", "awk", "sed",
        ],
    }),
    ("web", {
        "label": "Web & Markup",
        "formats": [
            "html", "htm", "xhtml", "xml", "svg", "css", "scss",
            "sass", "less", "json", "jsonl", "yaml", "yml", "toml",
            "ini", "cfg", "conf", "properties", "env", "graphql",
            "gql", "wsdl", "dtd", "xsd",
        ],
    }),
    ("data", {
        "label": "Data & Database",
        "formats": [
            "sql", "sqlite", "db", "dbf", "mdb", "accdb", "psql",
            "mongo", "redis", "hdf5", "h5", "parquet", "avro",
            "orc", "arrow", "feather", "pickle", "pkl", "npy",
            "npz", "mat", "rds", "rdata",
        ],
    }),
    ("config", {
        "label": "Config & System",
        "formats": [
            "plist", "reg", "inf", "sys", "lock", "gitignore",
            "gitconfig", "editorconfig", "eslintrc", "babelrc",
            "webpack", "makefile", "dockerfile", "vagrantfile",
            "procfile", "gemfile", "requirements", "pipfile",
            "package", "composer", "cargo",
        ],
    }),
    ("binary_parseable", {
        "label": "Partially Readable Binary",
        "formats": [
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
            "odt", "ods", "odp", "epub", "mobi", "fb2", "djvu",
        ],
    }),
    ("image", {
        "label": "Images (AI Vision)",
        "formats": [
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "tiff",
            "tif", "ico", "heic",
        ],
    }),
    ("archive", {
        "label": "Archives (Metadata)",
        "formats": [
            "zip", "tar", "gz", "bz2", "xz", "7z", "rar",
            "iso", "dmg", "pkg", "deb", "rpm",
        ],
    }),
    ("media", {
        "label": "Media (Metadata)",
        "formats": [
            "mp3", "mp4", "wav", "avi", "mov", "mkv", "flv",
            "wmv", "m4a", "ogg", "flac", "aac", "webm",
        ],
    }),
    ("scientific", {
        "label": "Scientific & Research",
        "formats": [
            "fits", "cif", "mol", "sdf", "pdb", "xyz", "fasta",
            "fastq", "vcf", "bed", "gff", "sam", "bam",
            "nexus", "newick",
        ],
    }),
])

TEXT_TYPES   = {"text", "code", "web", "config"}
BINARY_TYPES = {"binary_parseable"}
IMAGE_TYPES  = {"image"}
DATA_TYPES   = {"data", "scientific"}
META_TYPES   = {"archive", "media"}

ALL_FORMATS = {}
for fmt_type, grp in FILE_FORMATS.items():
    for ext in grp["formats"]:
        ALL_FORMATS[ext] = fmt_type


def detect_format(filename):
    """Detect format type from filename extension."""
    ext = ""
    if "." in filename:
        ext = filename.rsplit(".", 1)[-1].lower()
    fmt_type = ALL_FORMATS.get(ext, "unknown")
    label = "Unknown Format"
    if fmt_type in FILE_FORMATS:
        label = FILE_FORMATS[fmt_type]["label"]
    return {"ext": ext, "type": fmt_type, "label": label}


# ---------------------------------------------------------------------------
# CONTENT EXTRACTION
# ---------------------------------------------------------------------------

def extract_content(filepath, fmt, filename):
    """
    Extract content from a file for analysis.
    Returns (content_str, parse_level, metadata_dict).
    """
    content    = ""
    parse_level = "none"
    metadata   = {}

    fmt_type = fmt["type"]

    try:
        file_size = os.path.getsize(filepath)
        metadata["size"] = file_size
        metadata["filename"] = filename

        if fmt_type in TEXT_TYPES or fmt_type in DATA_TYPES:
            with open(filepath, "rb") as f:
                raw = f.read(MAX_TEXT_BYTES)
            try:
                content = raw.decode("utf-8", errors="replace")
            except Exception:
                content = raw.decode("latin-1", errors="replace")
            parse_level = "full" if file_size <= MAX_TEXT_BYTES else "partial"
            metadata["char_count"] = len(content)

        elif fmt_type in IMAGE_TYPES:
            # FIXED vs JSX: read file as base64 for proper vision API call
            if file_size <= MAX_IMAGE_BYTES:
                with open(filepath, "rb") as f:
                    image_bytes = f.read()
                content    = base64.b64encode(image_bytes).decode("ascii")
                parse_level = "vision"
                metadata["image_b64_len"] = len(content)
                metadata["mime"] = mimetypes.guess_type(filename)[0] or "image/jpeg"
            else:
                content     = "[Image too large for vision — " + str(file_size) + " bytes]"
                parse_level = "metadata"

        elif fmt_type in BINARY_TYPES:
            # Read first 4KB, decode best-effort
            with open(filepath, "rb") as f:
                raw = f.read(4096)
            chars = []
            for b in bytearray(raw):
                if 0x20 <= b <= 0x7E or b in (0x09, 0x0A, 0x0D):
                    chars.append(chr(b))
                else:
                    chars.append(".")
            content     = "".join(chars)
            parse_level = "partial"
            metadata["first_bytes"] = " ".join(
                hex(b) for b in bytearray(raw[:16])
            )

        elif fmt_type in META_TYPES:
            content     = "[Binary " + fmt["label"] + " — metadata only]"
            parse_level = "metadata"

        else:
            # Unknown: try text
            try:
                with open(filepath, "rb") as f:
                    raw = f.read(MAX_TEXT_BYTES)
                content     = raw.decode("utf-8", errors="replace")
                parse_level = "full"
            except Exception:
                content     = "[Unreadable format]"
                parse_level = "none"

    except Exception as exc:
        log.warning("[tartarus_upload] extract error: %s", exc)
        content     = "[Extraction failed: " + str(exc) + "]"
        parse_level = "error"

    return content, parse_level, metadata


# ---------------------------------------------------------------------------
# TARTARUS ANALYSIS OF FILE
# ---------------------------------------------------------------------------

UPLOAD_SCHEMA = json.dumps({
    "fileNature": "string",
    "dominantStructure": "string",
    "mathematicalPatterns": [
        {"pattern": "string", "equation": "string",
         "confidence": 0.8, "location": "string"}
    ],
    "hiddenConnections": [
        {"connection": "string", "domain": "string", "insight": "string"}
    ],
    "anomalies": [
        {"description": "string", "severity": "low|medium|high",
         "location": "string"}
    ],
    "predictions": [
        {"outcome": "string", "confidence": 0.7, "basis": "string"}
    ],
    "codexEntry": {
        "entry": "string",
        "decoded": "string",
        "significance": "string",
    },
    "tartarusInsight": "string",
})

IMAGE_SCHEMA = json.dumps({
    "visualNature": "string",
    "geometricPatterns": [
        {"pattern": "string", "mathematicalBasis": "string"}
    ],
    "symbolicContent": ["string"],
    "colorMathematics": "string",
    "hiddenStructures": ["string"],
    "numerologicalFeatures": "string",
    "sacredGeometry": "string",
    "tartarusInsight": "string",
})


def _analyse_file_content(content, parse_level, fmt, filename, context):
    """Call Tartarus LLM to analyse extracted file content."""
    from zeus_tartarus_core import tartarus_call

    if parse_level == "none" or parse_level == "error":
        return {"fileNature": "unreadable", "tartarusInsight": "File could not be analysed"}

    if parse_level == "vision":
        # FIXED vs JSX: proper Anthropic vision API multipart call
        return _analyse_image_vision(content, fmt, filename, context)

    if parse_level == "metadata":
        prompt = (
            "TARTARUS FILE ANALYSIS (METADATA ONLY): Analyse this "
            + fmt["label"] + " file named \"" + filename + "\". "
            "No content is available — analyse based on filename, "
            "format characteristics and any structural inferences."
        )
    elif parse_level == "partial":
        prompt = (
            "TARTARUS FILE ANALYSIS (PARTIAL): Analyse the first bytes "
            "of this " + fmt["label"] + " file \"" + filename + "\". "
            "Partial content: [" + content[:2000] + "]"
        )
    else:
        # Full text
        prompt = (
            "TARTARUS FILE ANALYSIS (FULL): Perform deep mathematical "
            "and structural analysis of this " + fmt["label"] + " file "
            "\"" + filename + "\". Full content: [" + content[:4000] + "]"
        )

    return tartarus_call(
        prompt,
        schema_hint=UPLOAD_SCHEMA,
        context=context,
        max_tokens=1500,
    )


def _analyse_image_vision(b64_content, fmt, filename, context):
    """
    FIXED vs JSX: proper vision API call using Anthropic messages format.
    JSX passed base64 as a string in the text prompt — this sends it
    correctly as a multipart content block.
    """
    try:
        from zeus_llm_router import get_router
        router = get_router()

        mime = fmt.get("mime", "image/jpeg")
        if "png" in filename.lower():
            mime = "image/png"
        elif "gif" in filename.lower():
            mime = "image/gif"
        elif "webp" in filename.lower():
            mime = "image/webp"

        # Build proper multipart message for Claude vision
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": mime,
                            "data": b64_content,
                        },
                    },
                    {
                        "type": "text",
                        "text": (
                            "You are THE EYES OF TARTARUS. Perform deep "
                            "mathematical and symbolic analysis of this image. "
                            "Find geometric patterns, sacred geometry, symbolic "
                            "content, hidden mathematical structures, color "
                            "mathematics and numerological features. "
                            "Respond ONLY in pure JSON: " + IMAGE_SCHEMA
                        ),
                    },
                ],
            }
        ]

        # Call Claude directly for vision (Groq/OpenRouter don't support vision)
        raw = router.call_claude_raw_messages(messages, max_tokens=1200)
        parsed = router.parse_json_response(raw)
        parsed["_engine"] = "claude_vision"
        return parsed

    except Exception as exc:
        log.warning("[tartarus_upload] vision analysis error: %s", exc)
        # Graceful fallback
        return {
            "visualNature": "vision analysis unavailable: " + str(exc)[:100],
            "tartarusInsight": "Image uploaded but vision analysis failed",
            "_engine": "none",
        }


def _push_analysis_to_pool(filename, fmt, analysis, parse_level, metadata):
    """Push upload analysis results into TartarusMemory pool."""
    from zeus_tartarus_core import TartarusMemory, compute_weights

    mem = TartarusMemory.get()

    upload_record = {
        "name":         filename,
        "format":       fmt,
        "parse_level":  parse_level,
        "metadata":     metadata,
        "analysis":     analysis,
        "ts":           time.time(),
    }
    mem.push("uploads", upload_record, source="upload")

    # Extract patterns
    for pat in (analysis.get("mathematicalPatterns") or
                analysis.get("geometricPatterns") or []):
        if isinstance(pat, dict):
            mem.push("patterns", {
                "pattern":            pat.get("pattern", ""),
                "description":        pat.get("location", pat.get("mathematicalBasis", "")),
                "mathematical_basis": pat.get("equation", ""),
                "source":             "file:" + filename,
            }, source="upload")

    # Extract predictions
    for pred in (analysis.get("predictions") or []):
        mem.push("predictions", pred, source="upload")

    # Extract connections
    for conn in (analysis.get("hiddenConnections") or []):
        mem.push("connections", {
            "phenomenon": conn.get("connection", ""),
            "sharedMath": conn.get("domain", ""),
            "insight":    conn.get("insight", ""),
            "source":     "file:" + filename,
        }, source="upload")

    # Codex entry
    if analysis.get("codexEntry"):
        entry = analysis["codexEntry"]
        entry["filename"] = filename
        mem.push("codex", entry, source="upload")

    # Insight
    if analysis.get("tartarusInsight"):
        mem.push("insights", analysis["tartarusInsight"], source="upload")

    # Weights
    weights = compute_weights(analysis, source="direct")
    weights["label"] = "FILE:" + filename
    mem.push("weights", weights, source="upload")


# ---------------------------------------------------------------------------
# MAIN UPLOAD HANDLER
# ---------------------------------------------------------------------------

def process_upload(file_storage, context=""):
    """
    Process a Flask file upload through the Tartarus engine.
    file_storage: werkzeug FileStorage object.
    Returns analysis result dict.
    """
    filename  = file_storage.filename
    fmt       = detect_format(filename)
    file_hash = hashlib.sha256(filename.encode()).hexdigest()[:12]
    savepath  = os.path.join(UPLOAD_DIR, file_hash + "_" + filename[-40:])

    try:
        file_storage.save(savepath)
    except Exception as exc:
        return {"error": "save failed: " + str(exc)}

    content, parse_level, metadata = extract_content(savepath, fmt, filename)

    analysis = _analyse_file_content(
        content, parse_level, fmt, filename, context
    )

    _push_analysis_to_pool(filename, fmt, analysis, parse_level, metadata)

    from zeus_tartarus_core import TartarusMemory
    TartarusMemory.get().broadcast(
        "upload", "UPLOAD_COMPLETE",
        filename + " (" + fmt["label"] + ", " + parse_level + ")"
    )

    return {
        "filename":    filename,
        "format":      fmt,
        "parse_level": parse_level,
        "metadata":    metadata,
        "analysis":    analysis,
        "ts":          time.time(),
    }


# ---------------------------------------------------------------------------
# FLASK ROUTES
# ---------------------------------------------------------------------------

@upload_bp.route("/api/tartarus/upload", methods=["POST"])
def upload_route():
    if "file" not in request.files:
        return jsonify({"error": "no file in request"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "empty filename"}), 400

    from zeus_tartarus_core import TartarusMemory
    ctx    = TartarusMemory.get().build_context()
    result = process_upload(f, context=ctx)

    if "error" in result:
        return jsonify(result), 500
    return jsonify(result)


@upload_bp.route("/api/tartarus/upload/formats", methods=["GET"])
def list_formats():
    return jsonify({
        "format_groups": {
            k: {"label": v["label"], "count": len(v["formats"])}
            for k, v in FILE_FORMATS.items()
        },
        "total_formats": len(ALL_FORMATS),
    })


@upload_bp.route("/api/tartarus/upload/history", methods=["GET"])
def upload_history():
    from zeus_tartarus_core import TartarusMemory
    mem   = TartarusMemory.get()
    limit = int(request.args.get("limit", 20))
    return jsonify({
        "uploads": mem.get_field("uploads", limit),
        "ts": time.time(),
    })


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register(app):
    app.register_blueprint(upload_bp)
    log.info("[tartarus_upload] registered — /api/tartarus/upload")
