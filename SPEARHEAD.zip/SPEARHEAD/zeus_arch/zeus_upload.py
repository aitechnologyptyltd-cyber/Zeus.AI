# The Zeus Project 2026 - Francois Nel
# zeus_upload.py - Universal File Upload + DNA Splicing Engine
# Every common file type. Smart routing per category.
# DNA splice → genome → knowledge → mutator → infinite loop.

import os
import re
import json
import uuid
import shutil
import logging
import zipfile
import tarfile
import threading
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from flask import Blueprint, request, jsonify

log = logging.getLogger("zeus.upload")

ZEUS_DIR   = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(ZEUS_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

upload_bp = Blueprint("upload", __name__)

# ================================================================== #
# EXTENSION REGISTRY - every supported type mapped to a category      #
# ================================================================== #

EXT_MAP = {
    # Android / Mobile
    ".apk":  "android", ".aab": "android", ".aar": "android",
    ".dex":  "android",

    # Native binaries / libraries
    ".so":   "binary",  ".dll": "binary",  ".exe": "binary",
    ".bin":  "binary",  ".dat": "binary",  ".o":   "binary",
    ".a":    "binary",  ".lib": "binary",  ".dylib": "binary",

    # Java / JVM
    ".jar":  "jvm",     ".class": "jvm",   ".war": "jvm",
    ".ear":  "jvm",

    # Archives
    ".zip":  "archive", ".tar": "archive", ".gz":  "archive",
    ".bz2":  "archive", ".xz":  "archive", ".7z":  "archive",
    ".tgz":  "archive", ".tar.gz": "archive",

    # Documents
    ".pdf":  "document", ".docx": "document", ".doc": "document",
    ".odt":  "document", ".rtf":  "document",

    # Code - parsed with AST / regex
    ".py":   "code", ".pyw":  "code",
    ".js":   "code", ".jsx":  "code", ".mjs": "code",
    ".ts":   "code", ".tsx":  "code",
    ".java": "code", ".kt":   "code", ".kts": "code",
    ".swift":"code", ".go":   "code",
    ".rs":   "code", ".cs":   "code", ".cpp": "code",
    ".cc":   "code", ".cxx":  "code", ".c":   "code",
    ".h":    "code", ".hpp":  "code", ".hxx": "code",
    ".rb":   "code", ".php":  "code", ".pl":  "code",
    ".lua":  "code", ".r":    "code", ".scala": "code",
    ".dart": "code", ".ex":   "code", ".exs": "code",
    ".hs":   "code", ".clj":  "code", ".sh":  "code",
    ".bash": "code", ".zsh":  "code", ".fish": "code",
    ".ps1":  "code", ".bat":  "code", ".cmd": "code",
    ".smali":"code", ".asm":  "code", ".s":   "code",
    ".sql":  "code", ".graphql": "code",

    # Web / markup
    ".html": "web",  ".htm":  "web",  ".xml": "web",
    ".css":  "web",  ".scss": "web",  ".less": "web",
    ".sass": "web",  ".svg":  "web",

    # Data / config
    ".json": "data", ".yaml": "data", ".yml":  "data",
    ".toml": "data", ".ini":  "data", ".cfg":  "data",
    ".conf": "data", ".env":  "data", ".csv":  "data",
    ".tsv":  "data", ".xlsx": "data", ".xls":  "data",
    ".ods":  "data",

    # Text / docs
    ".txt":  "text", ".md":   "text", ".rst":  "text",
    ".log":  "text", ".nfo":  "text", ".readme": "text",
    ".adoc": "text",

    # Images - OCR + metadata
    ".png":  "image", ".jpg":  "image", ".jpeg": "image",
    ".gif":  "image", ".bmp":  "image", ".tiff": "image",
    ".tif":  "image", ".webp": "image", ".ico":  "image",
    ".heic": "image", ".raw":  "image",

    # Audio / Video - metadata only
    ".mp3":  "media", ".wav":  "media", ".ogg":  "media",
    ".flac": "media", ".m4a":  "media",
    ".mp4":  "media", ".mkv":  "media", ".avi":  "media",
    ".mov":  "media", ".webm": "media",
}

ALLOWED_EXTENSIONS = set(EXT_MAP.keys())


# ================================================================== #
# DB HELPERS                                                           #
# ================================================================== #

def _db():
    from db_init import get_db
    return get_db()


def _save_knowledge(topic: str, depth: str, content: str,
                    source: str, confidence: float = 0.80):
    try:
        conn = _db()
        conn.execute("""
            INSERT OR IGNORE INTO knowledge
                (topic, depth, content, source_url, confidence)
            VALUES (?, ?, ?, ?, ?)
        """, (topic, depth, content[:20000], source, confidence))
        conn.commit()
        conn.close()
    except Exception as e:
        log.warning(f"[Upload] Knowledge save error: {e}")


def _save_genome(name: str, description: str, module_type: str,
                 capabilities: str = "", priority: int = 55,
                 source_code: str = ""):
    try:
        conn = _db()
        conn.execute("""
            INSERT OR IGNORE INTO genome
                (name, description, module_type, source_code, priority, capabilities)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (name, description[:400], module_type,
              source_code[:10000], priority, capabilities))
        conn.commit()
        conn.close()
    except Exception as e:
        log.warning(f"[Upload] Genome save error: {e}")


def _fire_mutator(seeds: List[Dict], source: str):
    try:
        from zeus_mutator import get_engine
        get_engine().mutate(seeds, source=source, use_ai=True, priority=1.5)
    except Exception as e:
        log.warning(f"[Upload] Mutator error: {e}")


# ================================================================== #
# CATEGORY PROCESSORS                                                  #
# ================================================================== #

# ---- ANDROID --------------------------------------------------------

def _process_android(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    from zeus_apk_engine import extract_apk
    result = extract_apk(path, file_id)
    if result.get("error"):
        raise RuntimeError(result["error"])

    conn = _db()
    g = k = 0
    for entry in result.get("genome_entries", []):
        conn.execute("""
            INSERT OR IGNORE INTO genome
                (name, description, module_type, version, priority, capabilities)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (entry["name"], entry.get("description",""),
              entry.get("module_type","apk_dna"),
              entry.get("version","v1.0"),
              int(entry.get("priority",60)),
              entry.get("capabilities","")))
        g += 1
    for art in result.get("knowledge_articles", []):
        conn.execute("""
            INSERT OR IGNORE INTO knowledge
                (topic, depth, content, source_url, confidence)
            VALUES (?, ?, ?, ?, ?)
        """, (art["topic"], art.get("depth","Simple"),
              art["content"], f"apk:{filename}",
              float(art.get("confidence",0.85))))
        k += 1
    conn.commit(); conn.close()

    seeds = result.get("mutator_seeds", [])
    if seeds:
        threading.Thread(target=_fire_mutator,
                         args=(seeds, f"apk:{filename}"), daemon=True).start()
    return g + k, g, k


# ---- BINARY ---------------------------------------------------------

def _process_binary(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    """
    Hex header detection + strings extraction.
    Identifies file type from magic bytes, extracts printable strings.
    """
    size = os.path.getsize(path)
    ext  = Path(filename).suffix.lower()

    # Magic byte detection
    magic_map = {
        b"MZ":         "Windows PE executable",
        b"\x7fELF":    "ELF binary (Linux/Android)",
        b"\xca\xfe\xba\xbe": "Java class file / Mach-O fat binary",
        b"PK\x03\x04": "ZIP archive (may be APK/JAR/AAR)",
        b"\xde\xc0\x17\x0b": "LLVM bitcode",
        b"dex\n":       "Android DEX bytecode",
    }
    file_type = f"Binary file ({ext})"
    try:
        with open(path, "rb") as f:
            header = f.read(8)
        for magic, label in magic_map.items():
            if header.startswith(magic):
                file_type = label
                break
    except Exception:
        pass

    # Extract printable strings (like 'strings' command)
    strings_found: List[str] = []
    try:
        result = subprocess.run(
            ["strings", "-n", "6", path],
            capture_output=True, text=True, timeout=20
        )
        if result.returncode == 0:
            raw = result.stdout.splitlines()
            strings_found = [
                s for s in raw
                if re.match(r'^[\x20-\x7e]{6,}$', s)
                and not s.startswith("GLIBC")
            ][:200]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        # strings not available - do it in Python
        try:
            data = open(path, "rb").read()
            strings_found = re.findall(rb'[\x20-\x7e]{6,}', data)
            strings_found = [s.decode("ascii", errors="ignore")
                             for s in strings_found[:200]]
        except Exception:
            pass

    # Detect interesting patterns in strings
    urls      = [s for s in strings_found if s.startswith(("http://","https://"))]
    lib_names = [s for s in strings_found
                 if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]{4,}\.(so|dll|dylib)$', s)]
    funcs     = [s for s in strings_found
                 if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]{5,}$', s)][:50]

    desc = (
        f"{file_type}: {filename} - {size:,} bytes - "
        f"{len(strings_found)} strings extracted - "
        f"{len(urls)} URLs - {len(lib_names)} library refs"
    )
    content = (
        f"{desc}\n\n"
        f"URLs found: {'; '.join(urls[:10])}\n"
        f"Libraries: {'; '.join(lib_names[:10])}\n"
        f"Sample strings: {'; '.join(funcs[:20])}"
    )

    _save_knowledge(f"Binary analysis: {filename}", "Advanced",
                    content, f"binary:{filename}", 0.75)
    _save_genome(f"binary:{filename}", desc, "binary_dna",
                 capabilities=json.dumps(funcs[:20]))

    seeds = [
        {"topic": f"Binary file format analysis: {file_type}",
         "source": f"binary:{filename}", "priority": 1.1, "depth": "Simple"},
        {"topic": f"Reverse engineering {ext} files",
         "source": f"binary:{filename}", "priority": 1.0, "depth": "Simple"},
    ]
    if urls:
        seeds.append({"topic": f"Network endpoints in {filename}: {urls[0]}",
                      "source": f"binary:{filename}", "priority": 1.2,
                      "depth": "Simple"})
    threading.Thread(target=_fire_mutator,
                     args=(seeds, f"binary:{filename}"), daemon=True).start()

    return 2, 1, 1


# ---- JVM (JAR / CLASS) ---------------------------------------------

def _process_jvm(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    """JARs are ZIPs - extract, scan class names, fire mutator."""
    ext = Path(filename).suffix.lower()
    if ext == ".jar" or ext == ".war" or ext == ".ear":
        # Extract and recurse
        return _process_archive(path, filename, file_id)
    # .class - treat as binary
    return _process_binary(path, filename, file_id)


# ---- ARCHIVE --------------------------------------------------------

def _process_archive(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    extract_dir = os.path.join(UPLOAD_DIR, f"arc_{file_id}")
    os.makedirs(extract_dir, exist_ok=True)
    items = genome = know = 0

    try:
        # Extract based on type
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path, "r") as z:
                z.extractall(extract_dir)
        elif tarfile.is_tarfile(path):
            with tarfile.open(path) as t:
                t.extractall(extract_dir)
        else:
            # Try gunzip for plain .gz
            try:
                import gzip
                out_path = os.path.join(extract_dir,
                                        filename.replace(".gz",""))
                with gzip.open(path, "rb") as gz:
                    with open(out_path, "wb") as out:
                        out.write(gz.read())
            except Exception:
                _save_genome(f"archive:{filename}",
                             f"Unrecognised archive: {filename}",
                             "archive", priority=40)
                return 1, 1, 0

        # Recurse into extracted files
        for root, _, files in os.walk(extract_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                sub_id = f"{file_id}_{fname.replace(os.sep,'_')[:30]}"
                try:
                    i, g, k = _route_file(fpath, fname, sub_id)
                    items += i; genome += g; know += k
                except Exception as e:
                    log.warning(f"[Upload] Archive member {fname}: {e}")

    finally:
        shutil.rmtree(extract_dir, ignore_errors=True)

    return items, genome, know


# ---- DOCUMENT (PDF) -------------------------------------------------

def _process_document(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    text = ""
    try:
        from pdfminer.high_level import extract_text
        text = extract_text(path)
    except Exception:
        pass

    if not text:
        try:
            import pypdf
            text = "\n".join(
                p.extract_text() or "" for p in pypdf.PdfReader(path).pages
            )
        except Exception:
            pass

    if not text or not text.strip():
        # Fallback: treat as binary to at least get strings
        return _process_binary(path, filename, file_id)

    return _process_text_chunks(text, filename, file_id, "pdf")


# ---- CODE -----------------------------------------------------------

_LANG_MAP = {
    ".py":"Python", ".pyw":"Python",
    ".js":"JavaScript", ".jsx":"JavaScript/React", ".mjs":"JavaScript",
    ".ts":"TypeScript", ".tsx":"TypeScript/React",
    ".java":"Java", ".kt":"Kotlin", ".kts":"Kotlin",
    ".swift":"Swift", ".go":"Go", ".rs":"Rust",
    ".cs":"C#", ".cpp":"C++", ".cc":"C++", ".cxx":"C++",
    ".c":"C", ".h":"C/C++ Header", ".hpp":"C++ Header",
    ".rb":"Ruby", ".php":"PHP", ".pl":"Perl",
    ".lua":"Lua", ".r":"R", ".scala":"Scala",
    ".dart":"Dart", ".ex":"Elixir", ".exs":"Elixir",
    ".hs":"Haskell", ".clj":"Clojure",
    ".sh":"Shell", ".bash":"Bash", ".zsh":"Zsh",
    ".ps1":"PowerShell", ".bat":"Batch", ".cmd":"Batch",
    ".smali":"Smali/Android", ".asm":"Assembly", ".s":"Assembly",
    ".sql":"SQL", ".graphql":"GraphQL",
}

def _process_code(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    ext  = Path(filename).suffix.lower()
    lang = _LANG_MAP.get(ext, "Unknown")

    try:
        content = Path(path).read_text(errors="replace")
    except Exception as e:
        raise RuntimeError(f"Cannot read {filename}: {e}")

    lines = content.splitlines()
    lc    = len(lines)

    # Language-specific identifier extraction
    identifiers = _extract_identifiers(content, ext)

    # For Python: try AST for richer extraction
    func_names = []
    class_names= []
    imports    = []
    if ext in (".py", ".pyw"):
        try:
            import ast as _ast
            tree = _ast.parse(content)
            func_names  = [n.name for n in _ast.walk(tree)
                           if isinstance(n, _ast.FunctionDef)][:30]
            class_names = [n.name for n in _ast.walk(tree)
                           if isinstance(n, _ast.ClassDef)][:20]
            imports     = []
            for n in _ast.walk(tree):
                if isinstance(n, _ast.Import):
                    imports += [a.name for a in n.names]
                elif isinstance(n, _ast.ImportFrom):
                    if n.module:
                        imports.append(n.module)
            imports = list(set(imports))[:20]
        except Exception:
            pass

    desc = (
        f"{lang} source: {filename} - {lc} lines - "
        f"{len(func_names)} functions - "
        f"{len(class_names)} classes - "
        f"{len(imports)} imports"
    )
    article = (
        f"{desc}\n\n"
        f"Functions: {', '.join(func_names[:15])}\n"
        f"Classes:   {', '.join(class_names[:10])}\n"
        f"Imports:   {', '.join(imports[:15])}\n"
        f"Identifiers: {', '.join(identifiers[:20])}\n\n"
        f"Preview:\n{content[:800]}"
    )

    _save_knowledge(f"Source code: {filename}", "Advanced",
                    article, f"code:{filename}", 0.85)
    _save_genome(f"code:{filename}", desc, "source_code",
                 source_code=content[:10000], priority=58)

    seeds = [
        {"topic": f"{lang} programming patterns: {filename}",
         "source": f"code:{filename}", "priority": 1.2, "depth": "Simple"},
    ]
    if func_names:
        seeds.append({
            "topic": f"Software design in {lang}: {', '.join(func_names[:4])}",
            "source": f"code:{filename}", "priority": 1.1, "depth": "Simple",
        })
    if imports:
        seeds.append({
            "topic": f"{lang} libraries: {', '.join(imports[:4])}",
            "source": f"code:{filename}", "priority": 1.0, "depth": "Simple",
        })
    threading.Thread(target=_fire_mutator,
                     args=(seeds, f"code:{filename}"), daemon=True).start()
    return lc, 1, 1


def _extract_identifiers(content: str, ext: str) -> List[str]:
    """Regex-based identifier extraction for non-Python languages."""
    patterns = {
        ".java": r'\b(?:class|interface|enum|void|int|String)\s+(\w+)',
        ".kt":   r'\b(?:fun|class|object|val|var)\s+(\w+)',
        ".go":   r'\b(?:func|type|struct|interface)\s+(\w+)',
        ".rs":   r'\b(?:fn|struct|enum|trait|impl)\s+(\w+)',
        ".cs":   r'\b(?:class|interface|struct|void|public|private)\s+(\w+)',
        ".cpp":  r'\b(?:class|struct|void|int|namespace)\s+(\w+)',
        ".c":    r'\b(?:int|void|char|struct)\s+(\w+)\s*\(',
        ".js":   r'\b(?:function|class|const|let|var)\s+(\w+)',
        ".ts":   r'\b(?:function|class|interface|type|const)\s+(\w+)',
        ".rb":   r'\b(?:def|class|module)\s+(\w+)',
        ".php":  r'\b(?:function|class|interface)\s+(\w+)',
        ".smali":r'\.method\s+\w+\s+(\w+)\(',
    }
    pat = patterns.get(ext, r'\b([A-Z][a-zA-Z]{4,})\b')
    return list(set(re.findall(pat, content)))[:30]


# ---- WEB (HTML / XML / CSS) ----------------------------------------

def _process_web(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    try:
        content = Path(path).read_text(errors="replace")
    except Exception as e:
        raise RuntimeError(str(e))

    ext = Path(filename).suffix.lower()

    # Strip HTML tags for cleaner knowledge
    if ext in (".html", ".htm"):
        clean = re.sub(r'<[^>]+>', ' ', content)
        clean = re.sub(r'\s+', ' ', clean).strip()
        # Extract URLs
        urls  = re.findall(r'href=["\']([^"\']+)["\']', content)[:20]
        title_m = re.search(r'<title[^>]*>([^<]+)</title>', content, re.I)
        title = title_m.group(1) if title_m else filename
    elif ext == ".xml":
        clean = content
        urls  = []
        title = filename
    else:
        clean = content
        urls  = []
        title = filename

    return _process_text_chunks(
        clean, filename, file_id, "web",
        extra_seeds=[
            {"topic": f"Web technologies in {filename}: {title}",
             "source": f"web:{filename}", "priority": 1.1, "depth": "Simple"},
        ]
    )


# ---- DATA (JSON / YAML / CSV / XLSX) --------------------------------

def _process_data(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    ext = Path(filename).suffix.lower()

    if ext == ".xlsx" or ext == ".xls" or ext == ".ods":
        try:
            import openpyxl
            wb    = openpyxl.load_workbook(path, read_only=True, data_only=True)
            lines = []
            for sheet in wb.sheetnames[:5]:
                ws = wb[sheet]
                for row in ws.iter_rows(max_row=100, values_only=True):
                    lines.append(
                        "\t".join(str(c) for c in row if c is not None)
                    )
            content = f"Spreadsheet: {filename}\n" + "\n".join(lines[:200])
            return _process_text_chunks(content, filename, file_id, "spreadsheet")
        except ImportError:
            pass  # fall through to text

    if ext == ".json":
        try:
            content = Path(path).read_text(errors="replace")
            data    = json.loads(content)
            # Flatten keys for knowledge
            keys    = _flatten_json_keys(data, max_depth=4)
            summary = (
                f"JSON file: {filename}\n"
                f"Top-level keys: {', '.join(list(data.keys())[:20]) if isinstance(data, dict) else 'array'}\n"
                f"All paths: {'; '.join(keys[:50])}\n\n"
                f"Raw (truncated): {content[:2000]}"
            )
            _save_knowledge(f"JSON structure: {filename}", "Advanced",
                            summary, f"data:{filename}", 0.80)
            _save_genome(f"data:{filename}", f"JSON: {filename}",
                         "data_json", priority=50)
            seeds = [{"topic": f"JSON data structure: {filename}",
                      "source": f"data:{filename}", "priority": 1.0,
                      "depth": "Simple"}]
            threading.Thread(target=_fire_mutator,
                             args=(seeds, f"data:{filename}"), daemon=True).start()
            return 1, 1, 1
        except Exception:
            pass  # fall through to text chunks

    # Everything else - read as text and chunk
    try:
        content = Path(path).read_text(errors="replace")
        return _process_text_chunks(content, filename, file_id, "data")
    except Exception as e:
        raise RuntimeError(str(e))


def _flatten_json_keys(obj, prefix="", max_depth=3, depth=0) -> List[str]:
    keys = []
    if depth >= max_depth:
        return keys
    if isinstance(obj, dict):
        for k, v in list(obj.items())[:30]:
            full = f"{prefix}.{k}" if prefix else str(k)
            keys.append(full)
            keys.extend(_flatten_json_keys(v, full, max_depth, depth+1))
    elif isinstance(obj, list) and obj:
        keys.extend(_flatten_json_keys(obj[0], f"{prefix}[]", max_depth, depth+1))
    return keys[:100]


# ---- IMAGE (OCR + metadata) ----------------------------------------

def _process_image(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    ext  = Path(filename).suffix.lower()
    size = os.path.getsize(path)
    meta = {"filename": filename, "size": size, "format": ext}
    ocr_text = ""

    # Try to get image metadata
    try:
        from PIL import Image
        with Image.open(path) as img:
            meta["width"]  = img.width
            meta["height"] = img.height
            meta["mode"]   = img.mode
            meta["format_detected"] = img.format or ext
    except ImportError:
        pass
    except Exception:
        pass

    # Try OCR
    try:
        import pytesseract
        from PIL import Image
        with Image.open(path) as img:
            ocr_text = pytesseract.image_to_string(img).strip()
    except (ImportError, Exception):
        pass

    desc = (
        f"Image: {filename} - {size:,} bytes - "
        f"{meta.get('width','?')}×{meta.get('height','?')} px"
    )
    content = desc
    if ocr_text:
        content += f"\n\nOCR text:\n{ocr_text[:3000]}"

    _save_knowledge(f"Image: {filename}", "Simple",
                    content, f"image:{filename}", 0.70)
    _save_genome(f"image:{filename}", desc, "image_asset", priority=40)

    seeds = []
    if ocr_text and len(ocr_text) > 50:
        seeds.append({
            "topic": f"Content from image {filename}: {ocr_text[:80]}",
            "source": f"image:{filename}", "priority": 1.0, "depth": "Simple",
        })
    if seeds:
        threading.Thread(target=_fire_mutator,
                         args=(seeds, f"image:{filename}"), daemon=True).start()
    return 1, 1, 1


# ---- MEDIA (audio / video - metadata only) -------------------------

def _process_media(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    size = os.path.getsize(path)
    ext  = Path(filename).suffix.lower()

    meta_str = ""
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json",
             "-show_format", "-show_streams", path],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            meta_str = result.stdout[:1000]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    desc = f"Media file: {filename} - {size:,} bytes - {ext}"
    content = desc + (f"\n\nMetadata:\n{meta_str}" if meta_str else "")

    _save_knowledge(f"Media: {filename}", "Simple",
                    content, f"media:{filename}", 0.60)
    _save_genome(f"media:{filename}", desc, "media_asset", priority=35)
    return 1, 1, 1


# ---- TEXT -----------------------------------------------------------

def _process_text(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    try:
        content = Path(path).read_text(errors="replace")
    except Exception as e:
        raise RuntimeError(str(e))
    return _process_text_chunks(content, filename, file_id, "text")


# ---- SHARED: TEXT CHUNKER ------------------------------------------

def _process_text_chunks(text: str, filename: str, file_id: str,
                          source_type: str = "text",
                          extra_seeds: List[Dict] = None) -> Tuple[int,int,int]:
    text = text.strip()
    if not text:
        return 0, 0, 0

    CHUNK = 4000
    chunks = [text[i:i+CHUNK] for i in range(0, len(text), CHUNK)]

    conn  = _db()
    added = 0
    for i, chunk in enumerate(chunks):
        topic = f"{filename} - part {i+1}/{len(chunks)}"
        try:
            conn.execute("""
                INSERT OR IGNORE INTO knowledge
                    (topic, depth, content, source_url, confidence)
                VALUES (?, 'Simple', ?, ?, 0.75)
            """, (topic, chunk, f"{source_type}:{filename}"))
            added += 1
        except Exception:
            pass

    conn.execute("""
        INSERT OR IGNORE INTO genome
            (name, description, module_type, priority)
        VALUES (?, ?, ?, 50)
    """, (
        f"doc:{filename}",
        f"{source_type.upper()}: {filename} - {len(text):,} chars - {len(chunks)} chunks",
        f"document_{source_type}",
    ))
    conn.commit()
    conn.close()

    seeds = [{
        "topic":    f"Topics from {source_type}: {filename}",
        "source":   f"{source_type}:{filename}",
        "priority": 1.0, "depth": "Simple",
    }] + (extra_seeds or [])
    threading.Thread(target=_fire_mutator,
                     args=(seeds, f"{source_type}:{filename}"), daemon=True).start()

    return len(chunks), 1, added


# ================================================================== #
# MASTER ROUTER                                                        #
# ================================================================== #


def _process_unknown(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    """
    Fallback for any extension not in EXT_MAP.
    1. Probe magic bytes to identify actual format.
    2. Try UTF-8 text read then chunk into knowledge.
    3. If binary, run strings extraction + metadata.
    4. Always fires mutator with whatever was found.
    """
    ext  = Path(filename).suffix.lower()
    size = os.path.getsize(path)

    magic_label = "unknown binary"
    magic_map = {
        b"MZ":               "Windows PE executable",
        b"\x7fELF":          "ELF binary (Linux/Android)",
        b"PK\x03\x04":       "ZIP-based archive",
        b"dex\n":            "Android DEX bytecode",
        b"\xca\xfe\xba\xbe": "Java class / Mach-O fat binary",
        b"%PDF":             "PDF document",
        b"\x89PNG":          "PNG image",
        b"\xff\xd8\xff":     "JPEG image",
        b"GIF8":             "GIF image",
        b"RIFF":             "RIFF media (WAV/AVI)",
        b"\x1f\x8b":         "gzip compressed",
        b"BZh":              "bzip2 compressed",
    }
    try:
        with open(path, "rb") as f:
            header = f.read(8)
        for magic, label in magic_map.items():
            if header.startswith(magic):
                magic_label = label
                break
    except Exception:
        pass

    meta_desc = (
        f"Unknown file type: {filename} - ext='{ext}' - "
        f"{size:,} bytes - detected: {magic_label}"
    )

    # Attempt 1: read as clean UTF-8 text
    try:
        text = Path(path).read_text(errors="strict")
        log.info(f"[Upload] Unknown ext '{ext}' reads as text - chunking")
        _save_genome(f"unknown:{filename}", meta_desc, "unknown_text", priority=45)
        seeds = [{"topic": f"Unknown file analysis: {filename} ({ext})",
                  "source": f"unknown:{filename}", "priority": 0.9, "depth": "Simple"}]
        return _process_text_chunks(text, filename, file_id, "unknown", extra_seeds=seeds)
    except (UnicodeDecodeError, Exception):
        pass

    # Attempt 2: binary - strings + metadata
    log.info(f"[Upload] Unknown ext '{ext}' is binary - strings + metadata")
    strings_found: List[str] = []
    try:
        r = subprocess.run(["strings", "-n", "6", path],
                           capture_output=True, text=True, timeout=15)
        if r.returncode == 0:
            strings_found = [s for s in r.stdout.splitlines()
                             if re.match(r'^[\x20-\x7e]{6,}$', s)][:150]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        try:
            data = open(path, "rb").read()
            strings_found = [s.decode("ascii", errors="ignore")
                             for s in re.findall(rb'[\x20-\x7e]{6,}', data)][:150]
        except Exception:
            pass

    urls  = [s for s in strings_found if s.startswith(("http://", "https://"))]
    funcs = [s for s in strings_found
             if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]{5,}$', s)][:40]

    content = (
        f"{meta_desc}\n\n"
        f"Strings: {len(strings_found)} extracted\n"
        f"URLs: {'; '.join(urls[:10])}\n"
        f"Identifiers: {'; '.join(funcs[:20])}\n"
        f"Sample: {'; '.join(strings_found[:15])}"
    )
    _save_knowledge(f"Unknown file: {filename}", "Simple",
                    content, f"unknown:{filename}", 0.60)
    _save_genome(f"unknown:{filename}", meta_desc, "unknown_binary",
                 capabilities=json.dumps(funcs[:20]), priority=40)

    seeds = [{"topic": f"File format: {magic_label} ({ext})",
              "source": f"unknown:{filename}", "priority": 0.9, "depth": "Simple"}]
    if urls:
        seeds.append({"topic": f"Network endpoints in unknown file: {filename}",
                      "source": f"unknown:{filename}", "priority": 1.0, "depth": "Simple"})
    threading.Thread(target=_fire_mutator,
                     args=(seeds, f"unknown:{filename}"), daemon=True).start()
    return 2, 1, 1

def _route_file(path: str, filename: str, file_id: str) -> Tuple[int,int,int]:
    """Route a file to the correct processor based on its extension."""
    # Handle compound extensions like .tar.gz
    fname_lower = filename.lower()
    if fname_lower.endswith(".tar.gz") or fname_lower.endswith(".tar.bz2"):
        return _process_archive(path, filename, file_id)

    ext      = Path(filename).suffix.lower()
    category = EXT_MAP.get(ext)

    if category is None:
        return _process_unknown(path, filename, file_id)

    router = {
        "android":  _process_android,
        "binary":   _process_binary,
        "jvm":      _process_jvm,
        "archive":  _process_archive,
        "document": _process_document,
        "code":     _process_code,
        "web":      _process_web,
        "data":     _process_data,
        "image":    _process_image,
        "media":    _process_media,
        "text":     _process_text,
    }

    processor = router.get(category, _process_text)
    return processor(path, filename, file_id)


# ================================================================== #
# FLASK ROUTES                                                         #
# ================================================================== #

@upload_bp.route("/api/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file in request"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    filename  = f.filename
    ext       = Path(filename).suffix.lower()
    file_id   = uuid.uuid4().hex
    save_path = os.path.join(UPLOAD_DIR, f"{file_id}_{filename}")

    try:
        f.save(save_path)
    except Exception as e:
        return jsonify({"error": f"Save failed: {e}"}), 500

    size = os.path.getsize(save_path)
    if size == 0:
        os.remove(save_path)
        return jsonify({"error": "Empty file"}), 400

    # Warn but don't reject unknown extensions
    known = ext in ALLOWED_EXTENSIONS or filename.lower().endswith(".tar.gz")
    category = EXT_MAP.get(ext, "unknown")

    # Record in DB
    conn = _db()
    conn.execute("""
        INSERT INTO uploaded_files
            (file_id, filename, file_type, size_bytes, status)
        VALUES (?, ?, ?, ?, 'processing')
    """, (file_id, filename, ext, size))
    conn.commit()
    conn.close()

    def _do():
        try:
            items, genes, kn = _route_file(save_path, filename, file_id)
            conn2 = _db()
            conn2.execute("""
                UPDATE uploaded_files
                SET status='done', items_extracted=?,
                    genome_segments=?, knowledge_added=?,
                    processed_at=?
                WHERE file_id=?
            """, (items, genes, kn,
                  datetime.now(timezone.utc).isoformat(), file_id))
            conn2.commit(); conn2.close()
            log.info(f"[Upload] ✓ {filename} - {items} items, "
                     f"{genes} genome, {kn} knowledge")
        except Exception as e:
            conn2 = _db()
            conn2.execute("""
                UPDATE uploaded_files
                SET status='error', error_msg=? WHERE file_id=?
            """, (str(e), file_id))
            conn2.commit(); conn2.close()
            log.error(f"[Upload] ✗ {filename}: {e}")

    # Large files and complex types → async
    async_types = {"android", "archive", "binary", "jvm", "image", "media"}
    if size > 512_000 or category in async_types:
        threading.Thread(target=_do, daemon=True).start()
        return jsonify({
            "status":    "processing",
            "file_id":   file_id,
            "filename":  filename,
            "size_bytes": size,
            "category":  category,
            "known_type": known,
            "poll":      f"/api/upload/status/{file_id}",
        })
    else:
        _do()
        conn3 = _db()
        row   = conn3.execute(
            "SELECT * FROM uploaded_files WHERE file_id=?", (file_id,)
        ).fetchone()
        conn3.close()
        return jsonify(dict(row) if row else {"status": "done", "file_id": file_id})


@upload_bp.route("/api/upload/status/<file_id>")
def upload_status(file_id):
    try:
        conn = _db()
        row  = conn.execute(
            "SELECT * FROM uploaded_files WHERE file_id=?", (file_id,)
        ).fetchone()
        conn.close()
        if not row:
            return jsonify({"error": "not found"}), 404
        return jsonify(dict(row))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@upload_bp.route("/api/upload/list")
def upload_list():
    try:
        limit = int(request.args.get("limit", 50))
        conn  = _db()
        rows  = conn.execute("""
            SELECT * FROM uploaded_files
            ORDER BY uploaded_at DESC LIMIT ?
        """, (limit,)).fetchall()
        conn.close()
        return jsonify({"files": [dict(r) for r in rows], "count": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@upload_bp.route("/api/upload/types")
def upload_types():
    # Group extensions by category
    by_cat: Dict[str, List] = {}
    for ext, cat in EXT_MAP.items():
        by_cat.setdefault(cat, []).append(ext)
    return jsonify({
        "categories":       by_cat,
        "total_extensions": len(EXT_MAP),
        "processing": {
            "android":  "apktool decompile → Smali + manifest + strings + libs → genome + knowledge + mutator",
            "binary":   "magic bytes + strings extraction → genome + knowledge + mutator",
            "jvm":      "unzip JAR → recurse → class analysis",
            "archive":  "extract → recurse every member → process each",
            "document": "pdfminer/pypdf text extraction → chunk → knowledge + mutator",
            "code":     "AST/regex parse → functions/classes/imports → knowledge + genome + mutator",
            "web":      "strip tags → clean text → chunk → knowledge + mutator",
            "data":     "JSON flatten / YAML / CSV / XLSX → chunk → knowledge + mutator",
            "image":    "PIL metadata + pytesseract OCR → knowledge + mutator",
            "media":    "ffprobe metadata → knowledge",
            "text":     "chunk 4000 chars → knowledge + mutator",
        },
    })
