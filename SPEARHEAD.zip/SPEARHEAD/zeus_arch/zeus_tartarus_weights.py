"""
zeus_tartarus_weights.py
The Zeus Project 2026 — Francois Nel

TARTARUS WEIGHT DASHBOARD — 6-axis multidimensional weight analysis

Every entity, concept, system or phenomenon that passes through any
Tartarus phase is measured across 6 mathematical axes:

  tartarusScore  — composite universal significance (0-1)
  complexity     — structural/lexical complexity (0-1)
  entropy        — Shannon information entropy, normalised (0-1)
  connectivity   — cross-domain linkage density (0-1)
  temporality    — time-sensitivity and causal chain length (0-1)
  emergence      — presence of emergent/unexpected properties (0-1)

Plus two Zeus-specific axes added in v7:
  criticality    — systemic impact if this entity fails/changes (0-1)
  reversibility  — how easily changes to this entity are undone (0-1)

Sources of weight data:
  - Phase1 SENSE      : equations, patterns, connections
  - Phase2 MONITOR    : stream analyses
  - Phase3 CONNECT    : bridges, DNA connections
  - Phase4 PREDICT    : forecasts, black swan risks
  - Phase5 OMNISENSE  : emergent laws, cross-phase patterns
  - LearningEngine    : step11 entity weight maps
  - UploadEngine      : file analyses
  - Direct API call   : weight any entity on demand

The dashboard also:
  - Generates ranking tables (top N by any axis)
  - Detects weight clusters (groups of similarly-weighted entities)
  - Tracks weight evolution over time (entity measured multiple times)
  - Feeds zeus_prediction_engine Bayesian domain weights
  - Exports weight matrix as CSV

Flask blueprint: weights_bp at /api/tartarus/weights/*

armv7l compatible: no f-strings, no walrus operator.
"""

from __future__ import print_function

import os
import sys
import json
import time
import math
import uuid
import csv
import io
import logging
import sqlite3
import threading
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from flask import Blueprint, jsonify, request, Response

log = logging.getLogger("zeus.tartarus.weights")

weights_bp = Blueprint("tartarus_weights", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(ZEUS_DIR, "zeus.db")

WEIGHT_AXES = [
    "tartarusScore", "complexity", "entropy",
    "connectivity", "temporality", "emergence",
    "criticality", "reversibility",
]

WEIGHT_SCHEMA = json.dumps({
    "weights": [
        {
            "entity":        "string",
            "tartarusScore": 0.8,
            "complexity":    0.7,
            "entropy":       0.6,
            "connectivity":  0.5,
            "temporality":   0.4,
            "emergence":     0.9,
            "criticality":   0.8,
            "reversibility": 0.3,
            "reasoning":     "string",
        }
    ],
    "heaviestEntity":     "string",
    "lightestEntity":     "string",
    "mostEmergent":       "string",
    "mostCritical":       "string",
    "leastReversible":    "string",
    "systemicBalance":    0.75,
    "tartarusVerdict":    "string",
})


# ---------------------------------------------------------------------------
# DB HELPERS
# ---------------------------------------------------------------------------

def _db_connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=15)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn


def _init_weights_db():
    conn = _db_connect()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tartarus_weights (
            weight_id    TEXT PRIMARY KEY,
            entity       TEXT NOT NULL,
            source       TEXT DEFAULT 'direct',
            tartarus_score  REAL DEFAULT 0,
            complexity      REAL DEFAULT 0,
            entropy         REAL DEFAULT 0,
            connectivity    REAL DEFAULT 0,
            temporality     REAL DEFAULT 0,
            emergence       REAL DEFAULT 0,
            criticality     REAL DEFAULT 0,
            reversibility   REAL DEFAULT 0,
            reasoning       TEXT DEFAULT '',
            raw_payload     TEXT DEFAULT '{}',
            ts              REAL NOT NULL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_tw_entity ON tartarus_weights(entity)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_tw_ts ON tartarus_weights(ts)"
    )
    conn.commit()
    conn.close()


_init_weights_db()

_db_lock = threading.Lock()


def _persist_weight(entity, source, w, raw):
    try:
        with _db_lock:
            conn = _db_connect()
            conn.execute(
                "INSERT INTO tartarus_weights "
                "(weight_id, entity, source, tartarus_score, complexity, "
                "entropy, connectivity, temporality, emergence, "
                "criticality, reversibility, reasoning, raw_payload, ts) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    str(uuid.uuid4()),
                    entity[:200],
                    source,
                    float(w.get("tartarusScore", w.get("tartarus_score", 0)) or 0),
                    float(w.get("complexity",    0) or 0),
                    float(w.get("entropy",       0) or 0),
                    float(w.get("connectivity",  0) or 0),
                    float(w.get("temporality",   0) or 0),
                    float(w.get("emergence",     0) or 0),
                    float(w.get("criticality",   0) or 0),
                    float(w.get("reversibility", 0) or 0),
                    str(w.get("reasoning", ""))[:500],
                    json.dumps(raw, default=str)[:2000],
                    time.time(),
                )
            )
            conn.commit()
            conn.close()
    except Exception as exc:
        log.warning("[tartarus_weights] persist error: %s", exc)


# ---------------------------------------------------------------------------
# WEIGHT ENGINE
# ---------------------------------------------------------------------------

class WeightEngine(object):
    """
    Computes, stores and analyses weights for all Tartarus entities.
    Wraps both the heuristic compute_weights() from tartarus_core
    and LLM-powered deep weight analysis.
    """

    _instance = None
    _lock = threading.Lock()

    @classmethod
    def get(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def __init__(self):
        log.info("[tartarus_weights] WeightEngine ready")

    def weigh_entity(self, entity, data=None, source="direct", context=""):
        """
        Compute full 8-axis weight for an entity.
        Uses heuristic first, then LLM for reasoning and criticality/reversibility.
        Returns weight dict.
        """
        from zeus_tartarus_core import TartarusMemory, compute_weights, tartarus_call

        mem = TartarusMemory.get()

        # Step 1: heuristic 6-axis weight
        heuristic = compute_weights(data or {"entity": entity}, source=source)

        # Step 2: LLM for criticality + reversibility + reasoning
        schema = json.dumps({
            "entity":        entity,
            "criticality":   0.7,
            "reversibility": 0.3,
            "reasoning":     "string",
            "tartarusVerdict": "string",
        })

        prompt = (
            "TARTARUS WEIGHT ANALYSIS: Rate the entity/concept "
            "\"" + entity + "\" on two additional dimensions: "
            "CRITICALITY (0-1): how catastrophic is failure or "
            "significant change to this entity for the overall system? "
            "REVERSIBILITY (0-1): how easily can changes to this entity "
            "be undone or recovered from? "
            "Provide detailed mathematical reasoning."
        )

        llm_result = tartarus_call(
            prompt,
            schema_hint=schema,
            context=context,
            max_tokens=600,
        )

        # Merge
        weight = dict(heuristic)
        weight["entity"]        = entity
        weight["source"]        = source
        weight["criticality"]   = float(llm_result.get("criticality",   0.5) or 0.5)
        weight["reversibility"] = float(llm_result.get("reversibility", 0.5) or 0.5)
        weight["reasoning"]     = llm_result.get("reasoning", "")
        weight["tartarusVerdict"] = llm_result.get("tartarusVerdict", "")
        weight["ts"]            = time.time()

        # Persist to DB and pool
        _persist_weight(entity, source, weight, data or {})
        mem.push("weights", weight, source=source)

        # Feed criticality into prediction engine domain weights
        self._feed_prediction_engine(entity, weight)

        return weight

    def weigh_batch(self, entities, source="batch", context=""):
        """
        Weight multiple entities using a single LLM call.
        More efficient than individual calls for > 3 entities.
        """
        from zeus_tartarus_core import TartarusMemory, tartarus_call, compute_weights

        mem = TartarusMemory.get()

        entities_str = "; ".join(
            (e if isinstance(e, str) else str(e)) for e in entities[:20]
        )

        prompt = (
            "TARTARUS BATCH WEIGHT ANALYSIS: Measure ALL of the following "
            "entities/concepts across all 8 weight dimensions. "
            "Entities: [" + entities_str + "]"
        )

        result = tartarus_call(
            prompt,
            schema_hint=WEIGHT_SCHEMA,
            context=context,
            max_tokens=2000,
        )

        weights_out = []
        for w in (result.get("weights") or []):
            entity = w.get("entity", "unknown")
            _persist_weight(entity, source, w, w)
            mem.push("weights", w, source=source)
            weights_out.append(w)

        return {
            "weights":          weights_out,
            "heaviestEntity":   result.get("heaviestEntity", ""),
            "lightestEntity":   result.get("lightestEntity", ""),
            "mostEmergent":     result.get("mostEmergent", ""),
            "mostCritical":     result.get("mostCritical", ""),
            "leastReversible":  result.get("leastReversible", ""),
            "systemicBalance":  result.get("systemicBalance", 0.5),
            "tartarusVerdict":  result.get("tartarusVerdict", ""),
            "ts":               time.time(),
        }

    def _feed_prediction_engine(self, entity, weight):
        try:
            from zeus_prediction_engine import get_engine
            eng = get_engine()
            if hasattr(eng, "update_domain_weight"):
                eng.update_domain_weight(entity, weight.get("tartarusScore", 0.5))
        except Exception:
            pass

    # ---------------------------------------------------------------- queries

    def get_top_n(self, axis="tartarusScore", n=20, source=None):
        """Return top N weights ranked by a given axis."""
        col_map = {
            "tartarusScore": "tartarus_score",
            "complexity":    "complexity",
            "entropy":       "entropy",
            "connectivity":  "connectivity",
            "temporality":   "temporality",
            "emergence":     "emergence",
            "criticality":   "criticality",
            "reversibility": "reversibility",
        }
        col = col_map.get(axis, "tartarus_score")
        try:
            conn = _db_connect()
            query_str = (
                "SELECT entity, source, tartarus_score, complexity, entropy, "
                "connectivity, temporality, emergence, criticality, "
                "reversibility, reasoning, ts "
                "FROM tartarus_weights"
            )
            params = []
            if source:
                query_str += " WHERE source=?"
                params.append(source)
            query_str += " ORDER BY " + col + " DESC LIMIT ?"
            params.append(n)
            rows = conn.execute(query_str, params).fetchall()
            conn.close()
            return [dict(r) for r in rows]
        except Exception as exc:
            log.warning("[tartarus_weights] top_n error: %s", exc)
            return []

    def get_entity_history(self, entity, limit=50):
        """Return historical weight measurements for an entity."""
        try:
            conn = _db_connect()
            rows = conn.execute(
                "SELECT tartarus_score, complexity, entropy, connectivity, "
                "temporality, emergence, criticality, reversibility, "
                "source, ts "
                "FROM tartarus_weights WHERE entity LIKE ? "
                "ORDER BY ts DESC LIMIT ?",
                ("%" + entity + "%", limit)
            ).fetchall()
            conn.close()
            return [dict(r) for r in rows]
        except Exception as exc:
            return []

    def get_clusters(self, n_clusters=5):
        """
        Simple k-means-like clustering on tartarus_score × emergence.
        Returns groups of similarly-weighted entities.
        """
        try:
            conn = _db_connect()
            rows = conn.execute(
                "SELECT entity, tartarus_score, emergence "
                "FROM tartarus_weights ORDER BY ts DESC LIMIT 500"
            ).fetchall()
            conn.close()
        except Exception:
            return []

        if not rows:
            return []

        points = [(r["entity"], r["tartarus_score"], r["emergence"])
                  for r in rows]

        # Bin into a simple 2D grid
        bins = defaultdict(list)
        for entity, ts_score, em in points:
            bx = int(ts_score * n_clusters)
            by = int(em * n_clusters)
            bins[(bx, by)].append(entity)

        clusters = []
        for (bx, by), entities in sorted(bins.items(), key=lambda x: -len(x[1])):
            if entities:
                clusters.append({
                    "tartarusScore_band": round(bx / n_clusters, 2),
                    "emergence_band":     round(by / n_clusters, 2),
                    "entity_count":       len(entities),
                    "entities":           entities[:10],
                })
        return clusters[:n_clusters]

    def export_csv(self, limit=500):
        """Export weight matrix as CSV string."""
        try:
            conn = _db_connect()
            rows = conn.execute(
                "SELECT entity, source, tartarus_score, complexity, "
                "entropy, connectivity, temporality, emergence, "
                "criticality, reversibility, ts "
                "FROM tartarus_weights ORDER BY ts DESC LIMIT ?",
                (limit,)
            ).fetchall()
            conn.close()
        except Exception as exc:
            return "error," + str(exc)

        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow([
            "entity", "source", "tartarusScore", "complexity", "entropy",
            "connectivity", "temporality", "emergence",
            "criticality", "reversibility", "ts",
        ])
        for r in rows:
            writer.writerow([
                r["entity"], r["source"],
                round(r["tartarus_score"], 4),
                round(r["complexity"],     4),
                round(r["entropy"],        4),
                round(r["connectivity"],   4),
                round(r["temporality"],    4),
                round(r["emergence"],      4),
                round(r["criticality"],    4),
                round(r["reversibility"],  4),
                r["ts"],
            ])
        return buf.getvalue()

    def get_summary_stats(self):
        """Return aggregate statistics across all weight records."""
        try:
            conn = _db_connect()
            row = conn.execute(
                "SELECT COUNT(*) as total, "
                "AVG(tartarus_score) as avg_ts, "
                "MAX(tartarus_score) as max_ts, "
                "AVG(emergence) as avg_em, "
                "AVG(criticality) as avg_cr, "
                "AVG(reversibility) as avg_rev "
                "FROM tartarus_weights"
            ).fetchone()
            conn.close()
            if row:
                return {
                    "total_measurements": row["total"],
                    "avg_tartarusScore":  round(row["avg_ts"]  or 0, 4),
                    "max_tartarusScore":  round(row["max_ts"]  or 0, 4),
                    "avg_emergence":      round(row["avg_em"]  or 0, 4),
                    "avg_criticality":    round(row["avg_cr"]  or 0, 4),
                    "avg_reversibility":  round(row["avg_rev"] or 0, 4),
                }
        except Exception:
            pass
        return {}


# ---------------------------------------------------------------------------
# FLASK ROUTES
# ---------------------------------------------------------------------------

@weights_bp.route("/api/tartarus/weights/analyse", methods=["POST"])
def analyse_weight():
    data   = request.get_json(silent=True) or {}
    entity = (data.get("entity") or "").strip()
    if not entity:
        return jsonify({"error": "entity required"}), 400
    payload = data.get("data")
    source  = data.get("source", "direct")

    from zeus_tartarus_core import TartarusMemory
    ctx    = TartarusMemory.get().build_context()
    result = WeightEngine.get().weigh_entity(
        entity, data=payload, source=source, context=ctx
    )
    return jsonify(result)


@weights_bp.route("/api/tartarus/weights/batch", methods=["POST"])
def batch_weight():
    data     = request.get_json(silent=True) or {}
    entities = data.get("entities") or []
    if not entities:
        return jsonify({"error": "entities list required"}), 400
    source = data.get("source", "batch")

    from zeus_tartarus_core import TartarusMemory
    ctx    = TartarusMemory.get().build_context()
    result = WeightEngine.get().weigh_batch(entities, source=source, context=ctx)
    return jsonify(result)


@weights_bp.route("/api/tartarus/weights/top", methods=["GET"])
def top_weights():
    axis   = request.args.get("axis", "tartarusScore")
    n      = int(request.args.get("n", 20))
    source = request.args.get("source")
    rows   = WeightEngine.get().get_top_n(axis=axis, n=n, source=source)
    return jsonify({"axis": axis, "top": rows, "ts": time.time()})


@weights_bp.route("/api/tartarus/weights/entity/<entity>", methods=["GET"])
def entity_history(entity):
    limit = int(request.args.get("limit", 50))
    hist  = WeightEngine.get().get_entity_history(entity, limit=limit)
    return jsonify({"entity": entity, "history": hist, "ts": time.time()})


@weights_bp.route("/api/tartarus/weights/clusters", methods=["GET"])
def weight_clusters():
    n = int(request.args.get("n", 5))
    clusters = WeightEngine.get().get_clusters(n_clusters=n)
    return jsonify({"clusters": clusters, "ts": time.time()})


@weights_bp.route("/api/tartarus/weights/stats", methods=["GET"])
def weight_stats():
    stats = WeightEngine.get().get_summary_stats()
    stats["axes"] = WEIGHT_AXES
    stats["ts"]   = time.time()
    return jsonify(stats)


@weights_bp.route("/api/tartarus/weights/export.csv", methods=["GET"])
def weight_export():
    limit = int(request.args.get("limit", 500))
    csv_data = WeightEngine.get().export_csv(limit=limit)
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=tartarus_weights.csv"},
    )


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register(app):
    app.register_blueprint(weights_bp)
    # Warm up singleton
    WeightEngine.get()
    log.info("[tartarus_weights] registered — /api/tartarus/weights")
