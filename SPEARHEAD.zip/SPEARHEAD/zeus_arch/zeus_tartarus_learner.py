"""
zeus_tartarus_learner.py
The Zeus Project 2026 — Francois Nel

TARTARUS LEARNING ENGINE — 11-Step Sequential Epistemological Pipeline

The deepest learning system in Zeus. Given any query, it runs 11
sequential analysis steps where each step feeds the next, producing
a complete epistemological map of the subject.

Step definitions (mirrors JSX LearningEngine STEP_DEFS exactly):
  1  SEARCH & SCRAPE    — find all related and unrelated data
  2  DEEP DIVE          — first digital byte mapping: What/Why/How/When/Where
  3  THOROUGH AUDIT     — deep audits across all extracted data
  4  DEPTH = MAXIMUM    — push every finding to absolute deepest level
  5  LENGTH = MAXIMUM   — expand every thread to fullest extent
  6  SIMPLICITY SCALE   — map findings from Very Basic → Genius across all axes
  7  TRACE STEPS        — forward and backward causal chain tracing
  8  DIMENSIONS & ANGLES — all types, all perspectives, all dimensional frames
  9  PATTERNS           — symbols, numerical, structural, temporal, spatial
  10 CODEX ANALYSER     — universal decoder → self-evolving memory
  11 ALL WEIGHTS        — every entity measured across all weight dimensions

Fixes vs JSX LearningEngine:
  - Step results persist to zeus.db (survive restarts)
  - Step 11 weights stored in pool.weights (JSX bug fix)
  - Error recovery per step — pipeline continues past failed steps
  - Context grows cumulatively across all 11 steps (not just last 5)
  - Threading: each step runs in the main thread (sequential, safe)
  - No closure/stale-state bugs (pure function per step)

Flask blueprint: learner_bp at /api/tartarus/learn/*

armv7l compatible: no f-strings, no walrus operator.
"""

from __future__ import print_function

import os
import sys
import json
import time
import uuid
import logging
import sqlite3
import threading
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, request, Response

log = logging.getLogger("zeus.tartarus.learner")

learner_bp = Blueprint("tartarus_learner", __name__)

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(ZEUS_DIR, "zeus.db")

# ---------------------------------------------------------------------------
# STEP DEFINITIONS
# ---------------------------------------------------------------------------

STEP_DEFS = [
    {
        "n": 1,
        "name": "SEARCH & SCRAPE",
        "desc": "Find all related and unrelated data. Categorise: Direct vs Indirect.",
        "icon": "cross_circle",
        "schema": json.dumps({
            "directlyRelated": [
                {"source": "string", "finding": "string",
                 "relevanceScore": 0.9, "dataType": "string"}
            ],
            "indirectlyRelated": [
                {"source": "string", "finding": "string",
                 "connectionPath": "string", "relevanceScore": 0.6}
            ],
            "totalSourcesFound": 0,
            "searchDepth": "string",
            "unexpectedDomains": ["string"],
        }),
    },
    {
        "n": 2,
        "name": "DEEP DIVE",
        "desc": "First digital byte mapping. What, Why, How, When, Where.",
        "icon": "nabla",
        "schema": json.dumps({
            "what": "string",
            "why": "string",
            "how": "string",
            "when": "string",
            "where": "string",
            "firstPrinciple": "string",
            "byteLevelMapping": "string",
            "intentMap": "string",
            "atomicComponents": ["string"],
        }),
    },
    {
        "n": 3,
        "name": "THOROUGH AUDIT",
        "desc": "Deep dive audits across all extracted data.",
        "icon": "tensor",
        "schema": json.dumps({
            "auditFindings": [
                {"area": "string",
                 "status": "verified|gap|contradiction|validated",
                 "detail": "string",
                 "correctionNeeded": "string"}
            ],
            "overallIntegrity": 0.8,
            "criticalGaps": ["string"],
            "auditSummary": "string",
            "verifiedFacts": ["string"],
        }),
    },
    {
        "n": 4,
        "name": "DEPTH = MAXIMUM",
        "desc": "Push every finding to its absolute deepest level.",
        "icon": "infinity",
        "schema": json.dumps({
            "depthLayers": [
                {"layer": 1, "finding": "string",
                 "deeperTruth": "string", "mathematicalRoot": "string"}
            ],
            "deepestPoint": "string",
            "bottomOfReality": "string",
            "depthScore": 0.9,
            "subAtomicFindings": ["string"],
        }),
    },
    {
        "n": 5,
        "name": "LENGTH = MAXIMUM",
        "desc": "Expand every thread to its fullest possible extent.",
        "icon": "sigma",
        "schema": json.dumps({
            "expandedThreads": [
                {"thread": "string", "fullExtent": "string",
                 "ultimateImplication": "string",
                 "reach": "local|regional|global|universal"}
            ],
            "longestChain": "string",
            "maxReachFindings": "string",
            "universalImplications": ["string"],
        }),
    },
    {
        "n": 6,
        "name": "SIMPLICITY SCALE",
        "desc": "Map all findings from Very Basic to Genius across all axes.",
        "icon": "lambda",
        "schema": json.dumps({
            "simplicityMapping": {
                "verySimple": "string",
                "simple": "string",
                "basic": "string",
                "hard": "string",
                "advanced": "string",
                "complex": "string",
                "veryComplex": "string",
                "mastery": "string",
                "genius": "string",
            },
            "practicalAxis": {"practical": "string", "nonPractical": "string"},
            "logicalAxis": {"logical": "string", "nonLogical": "string"},
            "theoreticalAxis": {"theoretical": "string", "nonTheoretical": "string"},
            "ethicalAxis": {"ethical": "string", "nonEthical": "string"},
            "physicalAxis": {"physical": "string", "nonPhysical": "string"},
        }),
    },
    {
        "n": 7,
        "name": "TRACE STEPS",
        "desc": "Forward and backward tracing of every causal chain.",
        "icon": "arrow_both",
        "schema": json.dumps({
            "forwardTrace": [
                {"step": 1, "event": "string",
                 "mathematicalTransition": "string"}
            ],
            "backwardTrace": [
                {"step": 1, "event": "string",
                 "mathematicalTransition": "string"}
            ],
            "origin": "string",
            "ultimateDestination": "string",
            "criticalJunctions": ["string"],
            "feedbackLoops": ["string"],
        }),
    },
    {
        "n": 8,
        "name": "DIMENSIONS & ANGLES",
        "desc": "All types, all perspectives, all dimensional frames.",
        "icon": "delta",
        "schema": json.dumps({
            "dimensions": [
                {"dimension": "string", "perspective": "string",
                 "uniqueInsight": "string", "mathematicalFrame": "string"}
            ],
            "mostRevealingAngle": "string",
            "hiddenDimension": "string",
            "dimensionalSynthesis": "string",
            "quantumFrame": "string",
            "topologicalFrame": "string",
        }),
    },
    {
        "n": 9,
        "name": "PATTERNS",
        "desc": "Symbols, numerical, alphabetical, structural, temporal, spatial.",
        "icon": "diamond",
        "schema": json.dumps({
            "numericalPatterns": [
                {"pattern": "string", "sequence": "string",
                 "formula": "string", "significance": "string"}
            ],
            "structuralPatterns": [
                {"pattern": "string", "topology": "string",
                 "recurrence": "string"}
            ],
            "temporalPatterns": [
                {"pattern": "string", "period": "string",
                 "equation": "string"}
            ],
            "symbolicPatterns": ["string"],
            "fractalDimension": "string",
            "masterPattern": "string",
        }),
    },
    {
        "n": 10,
        "name": "CODEX ANALYSER",
        "desc": "Universal decoder — self-evolving memory — feeds all phases.",
        "icon": "omega",
        "schema": json.dumps({
            "codexEntries": [
                {"entry": "string", "type": "string",
                 "decoded": "string", "significance": "string",
                 "crossReferences": ["string"]}
            ],
            "universalGrammar": "string",
            "encodingPrinciple": "string",
            "decodedTruth": "string",
            "selfEvolvingRule": "string",
        }),
    },
    {
        "n": 11,
        "name": "ALL WEIGHTS",
        "desc": "Every entity, concept, system measured across all weight dimensions.",
        "icon": "scales",
        "schema": json.dumps({
            "allWeights": [
                {
                    "entity": "string",
                    "tartarusScore": 0.8,
                    "complexity": 0.7,
                    "entropy": 0.6,
                    "connectivity": 0.5,
                    "temporality": 0.4,
                    "emergence": 0.9,
                    "criticality": 0.8,
                    "reversibility": 0.3,
                }
            ],
            "heaviestEntity": "string",
            "lightestEntity": "string",
            "weightDistribution": "string",
            "systemicBalance": 0.75,
        }),
    },
]


# ---------------------------------------------------------------------------
# DB HELPERS
# ---------------------------------------------------------------------------

def _db_connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=15)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn


def _init_learner_db():
    conn = _db_connect()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tartarus_learning_runs (
            run_id      TEXT PRIMARY KEY,
            query       TEXT NOT NULL,
            step_n      INTEGER NOT NULL,
            step_name   TEXT NOT NULL,
            result      TEXT NOT NULL,
            success     INTEGER DEFAULT 1,
            engine_used TEXT DEFAULT '',
            duration_ms REAL DEFAULT 0,
            ts          REAL NOT NULL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_tlr_query "
        "ON tartarus_learning_runs(query)"
    )
    conn.commit()
    conn.close()


_init_learner_db()


def _save_step_result(run_id, query, step_n, step_name,
                      result, success, engine, duration_ms):
    try:
        conn = _db_connect()
        conn.execute(
            "INSERT OR REPLACE INTO tartarus_learning_runs "
            "(run_id, query, step_n, step_name, result, success, "
            "engine_used, duration_ms, ts) VALUES (?,?,?,?,?,?,?,?,?)",
            (
                run_id, query, step_n, step_name,
                json.dumps(result, default=str),
                1 if success else 0,
                engine, duration_ms, time.time()
            )
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        log.warning("[tartarus_learner] DB save error: %s", exc)


# ---------------------------------------------------------------------------
# STEP RUNNER
# ---------------------------------------------------------------------------

def _run_step(step_def, query, all_results, context):
    """Run a single learning step. Returns (result, success, engine)."""
    from zeus_tartarus_core import tartarus_call

    n         = step_def["n"]
    name      = step_def["name"]
    schema    = step_def["schema"]

    # Build cumulative previous context (fixes JSX: all steps, not just last 5)
    prev_context = ""
    if all_results:
        pieces = []
        for prev_n, prev_r in sorted(all_results.items()):
            if isinstance(prev_r, dict) and "error" not in prev_r:
                snippet = json.dumps(prev_r, default=str)[:300]
                pieces.append("Step " + str(prev_n) + " findings: " + snippet)
        prev_context = "\n".join(pieces)

    if n == 1:
        prompt = (
            "SELF-LEARNING STEP 1 — SEARCH & SCRAPE: For the input "
            "\"" + query + "\", identify and categorise ALL possible "
            "data sources, findings and knowledge. Separate into directly "
            "related (same domain) and indirectly related (cross-domain, "
            "unexpected connections). Cast the widest possible net."
        )
    elif n == 2:
        prompt = (
            "SELF-LEARNING STEP 2 — DEEP DIVE: For \"" + query + "\", "
            "trace everything to its first digital byte of code or first "
            "mathematical principle. Answer: WHAT is it exactly? WHY does "
            "it exist? HOW does it work at the lowest level? WHEN does it "
            "occur or trigger? WHERE does it exist in the structure of "
            "reality? Previous context: " + prev_context[:400]
        )
    elif n == 3:
        prompt = (
            "SELF-LEARNING STEP 3 — THOROUGH AUDIT: Perform a deep audit "
            "of all findings for \"" + query + "\". Verify accuracy, find "
            "gaps, expose contradictions, validate mathematical soundness. "
            "Previous findings: " + prev_context[:500]
        )
    elif n == 4:
        prompt = (
            "SELF-LEARNING STEP 4 — DEPTH MAXIMUM: Push every finding "
            "about \"" + query + "\" to its absolute maximum depth. Go "
            "deeper than any standard analysis. Find the sub-structure "
            "beneath the sub-structure. Previous context: " + prev_context[:500]
        )
    elif n == 5:
        prompt = (
            "SELF-LEARNING STEP 5 — LENGTH MAXIMUM: Expand every thread "
            "about \"" + query + "\" to its fullest possible extent. Trace "
            "every implication to its end. Every cause to its ultimate "
            "effect. Every pattern to its furthest reach."
        )
    elif n == 6:
        prompt = (
            "SELF-LEARNING STEP 6 — SIMPLICITY SCALE: Map all findings "
            "about \"" + query + "\" across complexity spectrums: "
            "Simplicity (Very Simple to Genius), Practical/Non-practical, "
            "Logical/Non-logical, Theoretical/Non-theoretical, "
            "Ethical/Non-ethical, Physical/Non-physical. "
            "Context: " + prev_context[:400]
        )
    elif n == 7:
        prompt = (
            "SELF-LEARNING STEP 7 — TRACE STEPS: Trace all causal chains "
            "for \"" + query + "\" both FORWARDS (what leads from this) and "
            "BACKWARDS (what led to this). Map every step in both directions. "
            "Find feedback loops. Context: " + prev_context[:400]
        )
    elif n == 8:
        prompt = (
            "SELF-LEARNING STEP 8 — DIMENSIONS & ANGLES: Analyse "
            "\"" + query + "\" from ALL possible dimensional perspectives "
            "simultaneously: spatial, temporal, mathematical, psychological, "
            "quantum, fractal, topological, information-theoretic, "
            "thermodynamic, evolutionary, cultural, linguistic. "
            "Context: " + prev_context[:400]
        )
    elif n == 9:
        prompt = (
            "SELF-LEARNING STEP 9 — PATTERNS: Extract ALL pattern types "
            "from \"" + query + "\": numerical sequences, structural "
            "patterns, temporal cycles, symbolic codes, spatial fractals. "
            "Find the master pattern that unifies all others. "
            "Context: " + prev_context[:400]
        )
    elif n == 10:
        prompt = (
            "SELF-LEARNING STEP 10 — CODEX ANALYSER: Treat \"" + query + "\" "
            "as a codex — an encoded system of knowledge. Decode it at every "
            "level. Find the universal grammar underlying it. Extract the "
            "self-evolving rule that allows the codex to expand itself. "
            "Context: " + prev_context[:400]
        )
    elif n == 11:
        prompt = (
            "SELF-LEARNING STEP 11 — ALL WEIGHTS: Measure every entity, "
            "concept and system related to \"" + query + "\" across ALL "
            "weight dimensions: tartarusScore, complexity, entropy, "
            "connectivity, temporality, emergence, criticality, reversibility. "
            "Produce the complete weight map. Context: " + prev_context[:500]
        )
    else:
        prompt = (
            "SELF-LEARNING STEP " + str(n) + " — " + name + ": "
            "For \"" + query + "\", apply this analysis step. "
            "Context: " + prev_context[:400]
        )

    t0 = time.time()
    result = tartarus_call(
        prompt,
        schema_hint=schema,
        context=context,
        max_tokens=1800,
    )
    duration_ms = (time.time() - t0) * 1000.0

    success = "error" not in result
    engine  = result.get("_engine", "")
    return result, success, engine, duration_ms


# ---------------------------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------------------------

def run_learning_engine(query, steps=None, context=""):
    """
    Run the full 11-step (or subset) learning pipeline.
    Returns dict: {query, run_id, steps: {n: result}, synthesis, success}
    """
    from zeus_tartarus_core import TartarusMemory, compute_weights

    mem = TartarusMemory.get()
    mem.set_phase("learn", "active")
    mem.broadcast("learn", "ENGINE_START", query)

    run_id      = str(uuid.uuid4())
    all_results = OrderedDict()
    steps_to_run = steps or list(range(1, 12))

    for step_def in STEP_DEFS:
        n = step_def["n"]
        if n not in steps_to_run:
            continue

        mem.broadcast("learn", "STEP_" + str(n),
                      step_def["name"] + ": " + query)
        log.info("[tartarus_learner] step %d/%d: %s", n, 11, step_def["name"])

        result, success, engine, duration_ms = _run_step(
            step_def, query, all_results, context
        )
        all_results[n] = result

        # Save to DB
        _save_step_result(
            run_id, query, n, step_def["name"],
            result, success, engine, duration_ms
        )

        # Push step result into pool
        step_record = {
            "query":     query,
            "run_id":    run_id,
            "step_n":    n,
            "step_name": step_def["name"],
            "result":    result,
            "success":   success,
            "ts":        time.time(),
        }
        mem.push("learning_steps", step_record, source="learner")

        # Step-specific pool pushes
        if n == 9 and success:
            # Patterns from step 9
            for pat_type in ["numericalPatterns", "structuralPatterns",
                             "temporalPatterns"]:
                for pat in (result.get(pat_type) or []):
                    if isinstance(pat, dict):
                        mem.push("patterns", {
                            "pattern": pat.get("pattern", ""),
                            "description": pat.get("significance",
                                                    pat.get("topology", "")),
                            "mathematical_basis": pat.get("formula",
                                                          pat.get("equation", "")),
                            "source": "learner_step9",
                        }, source="learner")

        if n == 10 and success:
            # Codex entries from step 10
            for entry in (result.get("codexEntries") or []):
                mem.push("codex", entry, source="learner")

        if n == 11 and success:
            # FIXED: weights from step 11 NOW stored in pool.weights
            for w in (result.get("allWeights") or []):
                w["source"]    = "learner_step11"
                w["query"]     = query
                w["run_id"]    = run_id
                mem.push("weights", w, source="learner")

        # Broadcast progress
        status_str = "ok" if success else "FAILED"
        mem.broadcast(
            "learn",
            "STEP_DONE",
            "Step " + str(n) + " " + status_str + " (" +
            str(round(duration_ms)) + "ms)"
        )

    # Final synthesis — summarise all 11 steps
    synthesis = _synthesise_run(query, all_results, run_id)

    mem.set_phase("learn", "done")
    mem.broadcast("learn", "ENGINE_COMPLETE",
                  "All " + str(len(steps_to_run)) + " steps complete")

    return {
        "query":     query,
        "run_id":    run_id,
        "steps":     {str(k): v for k, v in all_results.items()},
        "synthesis": synthesis,
        "success":   True,
        "ts":        time.time(),
    }


def _synthesise_run(query, all_results, run_id):
    """Generate a final synthesis across all 11 step results."""
    from zeus_tartarus_core import TartarusMemory, tartarus_call

    mem = TartarusMemory.get()

    # Build compact summary of all steps
    step_summaries = []
    for n in sorted(all_results.keys()):
        r = all_results[n]
        if isinstance(r, dict) and "error" not in r:
            snippet = json.dumps(r, default=str)[:250]
            step_summaries.append("Step " + str(n) + ": " + snippet)

    combined = "\n".join(step_summaries)

    schema = json.dumps({
        "masterSynthesis": "string",
        "keyDiscoveries": ["string"],
        "unifiedModel": "string",
        "predictiveFormula": "string",
        "actionableConclusions": ["string"],
        "openQuestions": ["string"],
        "tartarusVerdict": "string",
    })

    prompt = (
        "LEARNING ENGINE FINAL SYNTHESIS: Integrate all 11 step findings "
        "for \"" + query + "\" into a single coherent model. "
        "All steps:\n" + combined[:2000]
    )

    result = tartarus_call(
        prompt,
        schema_hint=schema,
        context="",
        max_tokens=1500,
    )

    result["run_id"] = run_id
    result["query"]  = query
    result["ts"]     = time.time()

    mem.save_session(
        query, "learn_synthesis", result,
        engine=result.get("_engine", ""),
    )

    return result


# ---------------------------------------------------------------------------
# FLASK ROUTES
# ---------------------------------------------------------------------------

@learner_bp.route("/api/tartarus/learn", methods=["POST"])
def learn_route():
    data  = request.get_json(silent=True) or {}
    query = (data.get("query") or "").strip()
    steps = data.get("steps")  # optional list of step numbers
    if not query:
        return jsonify({"error": "query required"}), 400
    from zeus_tartarus_core import TartarusMemory
    ctx    = TartarusMemory.get().build_context()
    result = run_learning_engine(query, steps=steps, context=ctx)
    return jsonify(result)


@learner_bp.route("/api/tartarus/learn/steps", methods=["GET"])
def learn_step_defs():
    return jsonify({"steps": [
        {"n": s["n"], "name": s["name"], "desc": s["desc"]}
        for s in STEP_DEFS
    ]})


@learner_bp.route("/api/tartarus/learn/history", methods=["GET"])
def learn_history():
    limit = int(request.args.get("limit", 20))
    try:
        conn = _db_connect()
        rows = conn.execute(
            "SELECT run_id, query, step_n, step_name, success, "
            "engine_used, duration_ms, ts "
            "FROM tartarus_learning_runs ORDER BY ts DESC LIMIT ?",
            (limit,)
        ).fetchall()
        conn.close()
        return jsonify({
            "runs": [dict(r) for r in rows],
            "ts": time.time(),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@learner_bp.route("/api/tartarus/learn/run/<run_id>", methods=["GET"])
def learn_run_detail(run_id):
    try:
        conn = _db_connect()
        rows = conn.execute(
            "SELECT step_n, step_name, result, success, "
            "engine_used, duration_ms, ts "
            "FROM tartarus_learning_runs WHERE run_id=? ORDER BY step_n",
            (run_id,)
        ).fetchall()
        conn.close()
        steps = []
        for r in rows:
            d = dict(r)
            try:
                d["result"] = json.loads(d["result"])
            except Exception:
                pass
            steps.append(d)
        return jsonify({"run_id": run_id, "steps": steps, "ts": time.time()})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

def register(app):
    app.register_blueprint(learner_bp)
    log.info("[tartarus_learner] registered — /api/tartarus/learn")
