# The Zeus Project 2026 — Francois Nel
# zeus_auto_register.py — Auto-Discovery Blueprint Registration Engine
# Scans all Zeus modules · Resolves dependencies · Health-checks each blueprint
# Logic Engine integration · Identity registry sync · Conflict detection

import os
import re
import sys
import time
import json
import uuid
import logging
import inspect
import importlib
import threading
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

log = logging.getLogger("zeus.auto_register")

ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))

# ============================================================================
# BLUEPRINT DISCOVERY METADATA
# ============================================================================

@dataclass
class BlueprintMeta:
    module_name:    str
    bp_var:         str
    url_prefix:     str
    status:         str      = "pending"
    error:          str      = ""
    registered_at:  str      = ""
    health_status:  str      = "unknown"
    boot_order:     int      = 100
    version:        str      = "1.0"
    depends_on:     List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# KNOWN MODULE REGISTRY
# ============================================================================

# Explicit module→blueprint→prefix mapping with dependency order
# Boot order determines registration sequence (lower = earlier)
KNOWN_MODULES: List[Dict] = [
    # Core / foundation (boot first)
    {"module": "zeus_identity",           "bp": "identity_bp",       "prefix": "/api/identity",           "boot": 5,   "depends": []},
    {"module": "zeus_llm_router",         "bp": "llm_bp",            "prefix": "/api/llm",                "boot": 10,  "depends": ["zeus_identity"]},
    {"module": "genome_manager",          "bp": "genome_bp",         "prefix": "/api/genome/manager",     "boot": 15,  "depends": ["zeus_identity"]},
    {"module": "zeus_search",             "bp": "search_bp",         "prefix": "/api/search",             "boot": 20,  "depends": ["zeus_llm_router"]},
    {"module": "zeus_learner",            "bp": "learner_bp",        "prefix": "/api/learner",            "boot": 25,  "depends": ["zeus_search", "zeus_llm_router"]},
    {"module": "zeus_sandbox",            "bp": "sandbox_bp",        "prefix": "/api/sandbox",            "boot": 30,  "depends": []},
    {"module": "zeus_executor",           "bp": "executor_bp",       "prefix": "/api/executor",           "boot": 35,  "depends": []},
    {"module": "zeus_mutator",            "bp": "mutator_bp",        "prefix": "/api/mutator",            "boot": 38,  "depends": ["zeus_llm_router"]},
    {"module": "zeus_chat",               "bp": "chat_bp",           "prefix": "/api/chat",               "boot": 40,  "depends": ["zeus_llm_router", "zeus_mutator"]},
    {"module": "zeus_forge",              "bp": "forge_bp",          "prefix": "/api/forge",              "boot": 45,  "depends": ["zeus_llm_router"]},
    {"module": "zeus_blueprints",         "bp": "blueprints_bp",     "prefix": "/api/blueprints",         "boot": 55,  "depends": ["zeus_forge", "zeus_mutator"]},
    {"module": "zeus_apk_engine",         "bp": "apk_engine_bp",     "prefix": "/api/apk",                "boot": 60,  "depends": []},
    {"module": "zeus_apk_export",         "bp": "apk_export_bp",     "prefix": "/api/export",             "boot": 65,  "depends": ["zeus_blueprints", "zeus_apk_engine"]},
    {"module": "zeus_apk_builder_core",   "bp": "apk_builder_bp",    "prefix": "/api/apk/builder",        "boot": 68,  "depends": []},
    {"module": "zeus_self_evolution",     "bp": "evolution_bp",      "prefix": "/api/evolution",          "boot": 70,  "depends": ["zeus_sandbox", "zeus_forge"]},
    {"module": "zeus_recursive_learner",  "bp": "recursive_bp",      "prefix": "/api/recursive_learner",  "boot": 75,  "depends": ["zeus_learner"]},
    {"module": "zeus_learning_dashboard", "bp": "learning_bp",       "prefix": "/api/dashboard",          "boot": 80,  "depends": []},
    {"module": "zeus_nightly_scheduler",  "bp": "scheduler_bp",      "prefix": "/api/scheduler",          "boot": 90,  "depends": ["zeus_self_evolution", "zeus_mutator"]},
    {"module": "zeus_replication_engine", "bp": "replication_bp",    "prefix": "/api/replication",        "boot": 92,  "depends": []},
    {"module": "zeus_grok_bridge",        "bp": "bridge_bp",         "prefix": "/api/grok",               "boot": 95,  "depends": ["zeus_llm_router"]},
    {"module": "zeus_intelligent_router", "bp": "intelligent_router_bp","prefix": "/api/irouter",         "boot": 97,  "depends": ["zeus_llm_router"]},
    {"module": "zeus_prediction_engine",  "bp": "prediction_bp",     "prefix": "/api/prediction",         "boot": 98,  "depends": []},
    {"module": "zeus_upload",             "bp": "upload_bp",         "prefix": "/api/upload",             "boot": 50,  "depends": []},
    {"module": "logic_engine",            "bp": "logic_bp",          "prefix": "/api/logic",              "boot": 8,   "depends": []},
]

# URL prefix conflict detection
_PREFIX_BLACKLIST = {"/", "/api"}


# ============================================================================
# REGISTRATION ENGINE
# ============================================================================

class AutoRegistrationEngine:
    """
    Auto-discovers all Zeus blueprint modules and registers them in
    dependency order. Tracks registration status, detects conflicts,
    and syncs with the identity registry.
    """

    def __init__(self):
        self._lock            = threading.RLock()
        self._registered:     Dict[str, BlueprintMeta] = {}
        self._failed:         Dict[str, BlueprintMeta] = {}
        self._prefix_map:     Dict[str, str]            = {}   # prefix → module_name
        self._scan_log:       deque = deque(maxlen=200)
        self._total_scanned   = 0
        self._total_registered = 0

    def register_all(self, app, dry_run: bool = False) -> Dict:
        """
        Register all known Zeus modules in dependency order.
        Returns a summary report.
        """
        t0       = time.time()
        # Sort by boot order
        modules  = sorted(KNOWN_MODULES, key=lambda m: m["boot"])
        results  = {
            "registered": [], "failed": [], "skipped": [],
            "conflicts": [], "dry_run": dry_run,
        }

        for mod_info in modules:
            module_name = mod_info["module"]
            bp_var      = mod_info["bp"]
            prefix      = mod_info["prefix"]
            depends_on  = mod_info.get("depends", [])
            boot_order  = mod_info.get("boot", 100)

            # Check for prefix conflicts
            conflict = self._check_prefix_conflict(prefix, module_name)
            if conflict:
                results["conflicts"].append({
                    "module": module_name, "prefix": prefix, "conflict": conflict
                })
                # Still try to register — Flask will raise if truly conflicting

            if dry_run:
                results["registered"].append({"module": module_name, "prefix": prefix, "dry_run": True})
                continue

            meta = BlueprintMeta(
                module_name=module_name, bp_var=bp_var,
                url_prefix=prefix, boot_order=boot_order,
                depends_on=depends_on,
            )

            success = self._register_one(app, meta)
            if success:
                results["registered"].append(meta.to_dict())
            else:
                results["failed"].append(meta.to_dict())

        duration_ms = round((time.time() - t0) * 1000, 1)
        results["summary"] = {
            "total_modules":     len(modules),
            "registered_count":  len(results["registered"]),
            "failed_count":      len(results["failed"]),
            "conflict_count":    len(results["conflicts"]),
            "duration_ms":       duration_ms,
            "timestamp":         datetime.now(timezone.utc).isoformat(),
        }
        log.info(
            f"[AutoRegister] Registration complete: "
            f"{len(results['registered'])} registered, "
            f"{len(results['failed'])} failed in {duration_ms}ms"
        )
        return results

    def discover_blueprints(self) -> List[Dict]:
        """
        Dynamically scan the Zeus directory for any .py files
        that contain a Flask Blueprint variable not in the known list.
        """
        discovered  = []
        known_names = {m["module"] for m in KNOWN_MODULES}

        for fname in os.listdir(ZEUS_DIR):
            if not fname.endswith(".py"):
                continue
            module_name = fname[:-3]
            if module_name in known_names:
                continue
            if module_name.startswith("__") or module_name in ("app", "db_init"):
                continue

            fpath = os.path.join(ZEUS_DIR, fname)
            try:
                content = open(fpath).read()
                bps     = re.findall(r'(\w+_bp)\s*=\s*Blueprint\(', content)
                if bps:
                    discovered.append({
                        "module":     module_name,
                        "bp_vars":    bps,
                        "file":       fname,
                        "in_known":   False,
                        "suggestion": f'Add to KNOWN_MODULES: {{"module": "{module_name}", "bp": "{bps[0]}", "prefix": "/api/{module_name.replace("zeus_","")}", "boot": 99}}',
                    })
            except Exception:
                pass

        self._total_scanned += len(discovered)
        return discovered

    def get_registration_status(self) -> Dict:
        with self._lock:
            return {
                "registered":        [m.to_dict() for m in self._registered.values()],
                "failed":            [m.to_dict() for m in self._failed.values()],
                "total_registered":  self._total_registered,
                "total_scanned":     self._total_scanned,
                "prefix_map":        dict(self._prefix_map),
                "scan_log":          list(self._scan_log)[-20:],
            }

    def health_check_all(self, app) -> Dict:
        """
        Run a health check against each registered module's /health endpoint.
        Returns health status per module.
        """
        results  = {}
        with self._lock:
            registered = list(self._registered.values())

        with app.test_client() as client:
            for meta in registered:
                health_url = f"{meta.url_prefix}/health"
                try:
                    t0   = time.time()
                    resp = client.get(health_url)
                    ms   = round((time.time() - t0) * 1000, 1)
                    ok   = resp.status_code < 400
                    results[meta.module_name] = {
                        "status":    "ok" if ok else "degraded",
                        "http_code": resp.status_code,
                        "latency_ms": ms,
                        "url":       health_url,
                    }
                except Exception as e:
                    results[meta.module_name] = {
                        "status": "error", "error": str(e), "url": health_url
                    }
        return results

    # ---- Internal -------------------------------------------------------

    def _register_one(self, app, meta: BlueprintMeta) -> bool:
        """Register a single module blueprint. Returns True on success."""
        t0 = time.time()
        try:
            # Add ZEUS_DIR to sys.path if not already there
            if ZEUS_DIR not in sys.path:
                sys.path.insert(0, ZEUS_DIR)

            mod = importlib.import_module(meta.module_name)
            bp  = getattr(mod, meta.bp_var, None)

            if bp is None:
                # Try to find any Blueprint in the module
                for name, obj in inspect.getmembers(mod):
                    if hasattr(obj, "__class__") and obj.__class__.__name__ == "Blueprint":
                        bp = obj
                        meta.bp_var = name
                        break

            if bp is None:
                raise AttributeError(
                    f"Blueprint '{meta.bp_var}' not found in {meta.module_name}"
                )

            # Register with Flask
            app.register_blueprint(bp, url_prefix=meta.url_prefix)
            meta.status       = "registered"
            meta.registered_at = datetime.now(timezone.utc).isoformat()

            with self._lock:
                self._registered[meta.module_name] = meta
                self._prefix_map[meta.url_prefix]  = meta.module_name
                self._total_registered += 1

            ms = round((time.time() - t0) * 1000, 1)
            log.info(f"[AutoRegister] ✓ {meta.module_name} → {meta.url_prefix} ({ms}ms)")
            self._log_scan(meta.module_name, "registered", ms=ms)

            # Sync with identity registry
            self._sync_identity(meta, mod)
            return True

        except Exception as e:
            meta.status = "failed"
            meta.error  = str(e)[:300]
            with self._lock:
                self._failed[meta.module_name] = meta
            log.warning(f"[AutoRegister] ✗ {meta.module_name}: {e}")
            self._log_scan(meta.module_name, "failed", error=str(e)[:100])
            return False

    def _sync_identity(self, meta: BlueprintMeta, mod: Any) -> None:
        """Sync module registration with the identity registry."""
        try:
            from zeus_identity import register_self
            # Check if the module has its own register_self capability list
            caps_fn = getattr(mod, "_CAPABILITIES", None)
            caps    = caps_fn if isinstance(caps_fn, list) else []
            desc    = getattr(mod, "__doc__", "") or f"Zeus module: {meta.module_name}"
            register_self(
                module_name=meta.module_name,
                blueprint_var=meta.bp_var,
                url_prefix=meta.url_prefix,
                version=meta.version,
                description=str(desc)[:200].strip(),
                capabilities=caps,
                depends_on=meta.depends_on,
                boot_order=meta.boot_order,
            )
        except Exception:
            pass   # Identity sync is best-effort

    def _check_prefix_conflict(self, prefix: str, module_name: str) -> Optional[str]:
        with self._lock:
            existing = self._prefix_map.get(prefix)
        if existing and existing != module_name:
            return f"Prefix '{prefix}' already claimed by '{existing}'"
        if prefix in _PREFIX_BLACKLIST:
            return f"Prefix '{prefix}' is blacklisted"
        return None

    def _log_scan(self, module: str, status: str,
                   ms: float = 0, error: str = "") -> None:
        self._scan_log.append({
            "module": module, "status": status,
            "ms":     ms, "error": error,
            "ts":     datetime.now(timezone.utc).isoformat(),
        })


# ============================================================================
# SINGLETON
# ============================================================================

_ar_lock:     threading.RLock               = threading.RLock()
_ar_instance: Optional[AutoRegistrationEngine] = None


def get_auto_register() -> AutoRegistrationEngine:
    global _ar_instance
    with _ar_lock:
        if _ar_instance is None:
            _ar_instance = AutoRegistrationEngine()
        return _ar_instance


def auto_register_all(app, dry_run: bool = False) -> Dict:
    """
    Main entry point.
    Called by app.py to register all Zeus blueprints.
    """
    engine = get_auto_register()
    return engine.register_all(app, dry_run=dry_run)


def discover_unregistered() -> List[Dict]:
    """Find .py files with blueprints not in the known module list."""
    return get_auto_register().discover_blueprints()


# ============================================================================
# STANDALONE RUNNER
# ============================================================================

if __name__ == "__main__":
    import sys
    from flask import Flask as _Flask
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(levelname)s %(name)s — %(message)s"
    )
    _app = _Flask(__name__)
    print("\n=== Zeus Auto-Registration Engine ===\n")
    result = auto_register_all(_app)
    print(f"\nSummary:")
    print(f"  Registered : {result['summary']['registered_count']}")
    print(f"  Failed     : {result['summary']['failed_count']}")
    print(f"  Conflicts  : {result['summary']['conflict_count']}")
    print(f"  Duration   : {result['summary']['duration_ms']}ms")
    if result["failed"]:
        print("\nFailed modules:")
        for f in result["failed"]:
            print(f"  ✗ {f['module_name']}: {f['error']}")
    print("\nActive blueprints:")
    for bp_name in _app.blueprints:
        print(f"  ✓ {bp_name}")
    print("\n=== Discovering unregistered blueprints ===\n")
    unregistered = discover_unregistered()
    if unregistered:
        for u in unregistered:
            print(f"  [{u['file']}] bp_vars={u['bp_vars']}")
            print(f"    Suggestion: {u['suggestion']}")
    else:
        print("  No unregistered blueprint files found.")
    print("\n# The Zeus Project 2026 — Francois Nel\n")
