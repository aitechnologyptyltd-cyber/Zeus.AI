# The Zeus Project 2026 — Francois Nel
# zeus_apk_export.py — APK Export Engine
# Export APK analysis results · Package forge output for Android deployment
# Integrity checksums · Manifest generation · Multi-format export (zip/json/tar)
# Linked to blueprint engine · Feeds genome on export

import os
import io
import json
import uuid
import time
import hashlib
import logging
import zipfile
import tarfile
import threading
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from flask import Blueprint, jsonify, request, send_file

log = logging.getLogger("zeus.apk_export")

apk_export_bp = Blueprint("apk_export", __name__)

ZEUS_DIR   = os.path.dirname(os.path.abspath(__file__))
EXPORT_DIR = os.path.join(ZEUS_DIR, "exports")
os.makedirs(EXPORT_DIR, exist_ok=True)


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ExportJob:
    job_id:     str
    source:     str          # apk_path | analysis_id | blueprint_id
    export_fmt: str          # zip | tar | json
    status:     str          = "pending"
    output_path: str         = ""
    output_size: int         = 0
    sha256:      str         = ""
    created_at:  str         = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: str        = ""
    error:       str         = ""
    manifest:    Dict        = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# APK EXPORT ENGINE
# ============================================================================

class APKExportEngine:
    """
    Full APK export engine.
    Packages APK analysis results, forge outputs, and genome contributions
    into downloadable archives for Android deployment or archival.
    """

    def __init__(self):
        self._lock    = threading.RLock()
        self._jobs:   Dict[str, ExportJob] = {}
        self._recent: deque = deque(maxlen=100)
        self._total_exports = 0

    # ---- Public API ------------------------------------------------------

    def export_analysis(self, analysis_id: str,
                         fmt: str = "zip") -> ExportJob:
        """Export an APK analysis result."""
        job = ExportJob(
            job_id=uuid.uuid4().hex[:12],
            source=f"analysis:{analysis_id}",
            export_fmt=fmt,
        )
        self._jobs[job.job_id] = job

        try:
            analysis = self._get_analysis(analysis_id)
            if not analysis:
                job.status = "failed"
                job.error  = f"Analysis {analysis_id} not found"
                return job

            output_path = self._build_analysis_export(job, analysis, fmt)
            self._finalize_job(job, output_path)
        except Exception as e:
            job.status = "failed"
            job.error  = str(e)
            log.warning(f"[APKExport] Analysis export failed: {e}")

        return job

    def export_blueprint(self, blueprint_id: str,
                          fmt: str = "zip") -> ExportJob:
        """Export a blueprint + its forge output."""
        job = ExportJob(
            job_id=uuid.uuid4().hex[:12],
            source=f"blueprint:{blueprint_id}",
            export_fmt=fmt,
        )
        self._jobs[job.job_id] = job

        try:
            from zeus_blueprints import get_blueprint_engine
            bp = get_blueprint_engine().get(blueprint_id)
            if not bp:
                job.status = "failed"
                job.error  = f"Blueprint {blueprint_id} not found"
                return job

            output_path = self._build_blueprint_export(job, bp, fmt)
            self._finalize_job(job, output_path)
        except Exception as e:
            job.status = "failed"
            job.error  = str(e)

        return job

    def export_forge_output(self, forge_path: str,
                             module_name: str = "",
                             fmt: str = "zip") -> ExportJob:
        """Export raw forge output file."""
        job = ExportJob(
            job_id=uuid.uuid4().hex[:12],
            source=f"forge:{forge_path}",
            export_fmt=fmt,
        )
        self._jobs[job.job_id] = job

        if not os.path.isfile(forge_path):
            job.status = "failed"
            job.error  = f"File not found: {forge_path}"
            return job

        try:
            output_path = self._build_forge_export(job, forge_path, module_name, fmt)
            self._finalize_job(job, output_path)
        except Exception as e:
            job.status = "failed"
            job.error  = str(e)

        return job

    def get_job(self, job_id: str) -> Optional[ExportJob]:
        return self._jobs.get(job_id)

    def list_jobs(self, status: str = "", limit: int = 50) -> List[Dict]:
        with self._lock:
            jobs = list(self._jobs.values())
        if status:
            jobs = [j for j in jobs if j.status == status]
        jobs.sort(key=lambda j: j.created_at, reverse=True)
        return [j.to_dict() for j in jobs[:limit]]

    def list_exports(self) -> List[Dict]:
        """List all files in the exports directory."""
        files = []
        try:
            for fname in sorted(os.listdir(EXPORT_DIR), reverse=True):
                fpath = os.path.join(EXPORT_DIR, fname)
                if not os.path.isfile(fpath):
                    continue
                size = os.path.getsize(fpath)
                mtime = datetime.fromtimestamp(
                    os.path.getmtime(fpath), tz=timezone.utc
                ).isoformat()
                files.append({
                    "filename": fname,
                    "size_bytes": size,
                    "size_kb":   round(size / 1024, 1),
                    "modified":  mtime,
                    "download_url": f"/api/export/download/{fname}",
                })
        except Exception as e:
            log.warning(f"[APKExport] list_exports error: {e}")
        return files

    def delete_export(self, filename: str) -> bool:
        fpath = os.path.join(EXPORT_DIR, filename)
        if os.path.isfile(fpath) and os.path.dirname(fpath) == EXPORT_DIR:
            os.remove(fpath)
            return True
        return False

    def stats(self) -> Dict:
        with self._lock:
            by_status = {}
            for j in self._jobs.values():
                by_status[j.status] = by_status.get(j.status, 0) + 1
            export_files = [
                f for f in os.listdir(EXPORT_DIR)
                if os.path.isfile(os.path.join(EXPORT_DIR, f))
            ]
            total_size = sum(
                os.path.getsize(os.path.join(EXPORT_DIR, f))
                for f in export_files
            )
            return {
                "total_exports":     self._total_exports,
                "jobs_by_status":    by_status,
                "export_files":      len(export_files),
                "export_dir_kb":     round(total_size / 1024, 1),
            }

    # ---- Build helpers --------------------------------------------------

    def _build_analysis_export(self, job: ExportJob,
                                 analysis: Dict, fmt: str) -> str:
        ts   = int(time.time())
        name = f"apk_analysis_{job.job_id}_{ts}"

        if fmt == "json":
            out_path = os.path.join(EXPORT_DIR, f"{name}.json")
            with open(out_path, "w") as f:
                json.dump(analysis, f, indent=2, default=str)
            return out_path

        # Default: zip
        out_path = os.path.join(EXPORT_DIR, f"{name}.zip")
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            # Main analysis JSON
            zf.writestr("analysis.json",
                         json.dumps(analysis, indent=2, default=str))
            # Manifest
            manifest = self._build_manifest(job, analysis)
            zf.writestr("manifest.json",
                         json.dumps(manifest, indent=2, default=str))
            # README
            readme = self._build_readme("APK Analysis", analysis)
            zf.writestr("README.md", readme)

        job.manifest = manifest
        return out_path

    def _build_blueprint_export(self, job: ExportJob,
                                  bp: Dict, fmt: str) -> str:
        ts   = int(time.time())
        name = f"blueprint_{job.job_id}_{ts}"
        out_path = os.path.join(EXPORT_DIR, f"{name}.zip")

        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("blueprint.json", json.dumps(bp, indent=2, default=str))
            plan = bp.get("plan_json", {})
            if plan:
                zf.writestr("synthesis_plan.json",
                             json.dumps(plan, indent=2, default=str))
            # Result file
            result_path = bp.get("result_path", "")
            if result_path and os.path.isfile(result_path):
                zf.write(result_path, f"forge_output/{os.path.basename(result_path)}")
            # Manifest
            manifest = {
                "export_id":    job.job_id,
                "blueprint_id": bp.get("blueprint_id", ""),
                "goal":         bp.get("goal", ""),
                "quality":      bp.get("quality_score", 0),
                "exported_at":  datetime.now(timezone.utc).isoformat(),
                "project":      "The Zeus Project 2026",
                "architect":    "Francois Nel",
            }
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            zf.writestr("README.md", self._build_readme("Blueprint Export", bp))

        job.manifest = manifest
        return out_path

    def _build_forge_export(self, job: ExportJob, forge_path: str,
                              module_name: str, fmt: str) -> str:
        ts   = int(time.time())
        name = f"forge_{module_name or 'output'}_{job.job_id}_{ts}"

        if fmt == "tar":
            out_path = os.path.join(EXPORT_DIR, f"{name}.tar.gz")
            with tarfile.open(out_path, "w:gz") as tf:
                tf.add(forge_path, arcname=os.path.basename(forge_path))
            return out_path

        out_path = os.path.join(EXPORT_DIR, f"{name}.zip")
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(forge_path, os.path.basename(forge_path))
            # Compute SHA256 of the output
            data = open(forge_path, "rb").read()
            sha  = hashlib.sha256(data).hexdigest()
            manifest = {
                "export_id":   job.job_id,
                "module_name": module_name,
                "filename":    os.path.basename(forge_path),
                "sha256":      sha,
                "size_bytes":  len(data),
                "exported_at": datetime.now(timezone.utc).isoformat(),
                "project":     "The Zeus Project 2026",
            }
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))

        job.manifest = manifest
        return out_path

    def _build_manifest(self, job: ExportJob, data: Dict) -> Dict:
        return {
            "export_id":   job.job_id,
            "source":      job.source,
            "format":      job.export_fmt,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "summary":     {k: v for k, v in data.items()
                             if k in ("package_name","version_name","status","risk_score")},
            "project":     "The Zeus Project 2026",
            "architect":   "Francois Nel",
        }

    def _build_readme(self, title: str, data: Dict) -> str:
        lines = [
            f"# Zeus Export: {title}",
            f"",
            f"**Project:** The Zeus Project 2026",
            f"**Architect:** Francois Nel",
            f"**Exported:** {datetime.now(timezone.utc).isoformat()}",
            f"",
            f"## Contents",
            f"",
        ]
        for k, v in list(data.items())[:10]:
            if isinstance(v, (str, int, float, bool)):
                lines.append(f"- **{k}**: {v}")
        lines += ["", "---", "# The Zeus Project 2026 — Francois Nel"]
        return "\n".join(lines)

    def _finalize_job(self, job: ExportJob, output_path: str) -> None:
        if not output_path or not os.path.isfile(output_path):
            job.status = "failed"
            job.error  = "Output file not created"
            return
        data = open(output_path, "rb").read()
        job.output_path  = output_path
        job.output_size  = len(data)
        job.sha256       = hashlib.sha256(data).hexdigest()
        job.status       = "done"
        job.completed_at = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._total_exports += 1
            self._recent.append({"job_id": job.job_id, "path": output_path, "ts": time.time()})
        log.info(f"[APKExport] Export done: {output_path} ({len(data)} bytes)")

    def _get_analysis(self, analysis_id: str) -> Optional[Dict]:
        try:
            from db_init import get_db
            conn = get_db()
            row  = conn.execute(
                "SELECT * FROM apk_analysis WHERE job_id=?", (analysis_id,)
            ).fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            log.warning(f"[APKExport] get_analysis error: {e}")
            return None


# ============================================================================
# SINGLETON
# ============================================================================

_export_lock:     threading.RLock         = threading.RLock()
_export_instance: Optional[APKExportEngine] = None


def get_export_engine() -> APKExportEngine:
    global _export_instance
    with _export_lock:
        if _export_instance is None:
            _export_instance = APKExportEngine()
        return _export_instance


# ============================================================================
# FLASK ROUTES
# ============================================================================

@apk_export_bp.route("/api/export/health", methods=["GET"])
def export_health():
    return jsonify({
        "status":  "ok",
        "module":  "zeus_apk_export",
        "version": "2.0",
        "exports": len(get_export_engine().list_exports()),
    })


@apk_export_bp.route("/api/export/analysis/<analysis_id>", methods=["POST"])
def export_analysis(analysis_id: str):
    data = request.get_json(force=True, silent=True) or {}
    fmt  = data.get("format", "zip")
    job  = get_export_engine().export_analysis(analysis_id, fmt=fmt)
    code = 400 if job.status == "failed" else 200
    return jsonify(job.to_dict()), code


@apk_export_bp.route("/api/export/blueprint/<blueprint_id>", methods=["POST"])
def export_blueprint(blueprint_id: str):
    data = request.get_json(force=True, silent=True) or {}
    fmt  = data.get("format", "zip")
    job  = get_export_engine().export_blueprint(blueprint_id, fmt=fmt)
    return jsonify(job.to_dict())


@apk_export_bp.route("/api/export/forge", methods=["POST"])
def export_forge():
    """POST { "forge_path": str, "module_name": str, "format": str }"""
    data        = request.get_json(force=True, silent=True) or {}
    forge_path  = data.get("forge_path", "").strip()
    module_name = data.get("module_name", "")
    fmt         = data.get("format", "zip")
    if not forge_path:
        return jsonify({"error": "forge_path required"}), 400
    job = get_export_engine().export_forge_output(forge_path, module_name, fmt)
    return jsonify(job.to_dict())


@apk_export_bp.route("/api/export/job/<job_id>", methods=["GET"])
def export_job_status(job_id: str):
    job = get_export_engine().get_job(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job.to_dict())


@apk_export_bp.route("/api/export/download/<job_id>", methods=["GET"])
def export_download(job_id: str):
    """Download export by job_id or filename."""
    eng = get_export_engine()
    job = eng.get_job(job_id)
    if job and job.output_path and os.path.isfile(job.output_path):
        return send_file(
            job.output_path, as_attachment=True,
            download_name=os.path.basename(job.output_path),
        )
    # Try as filename
    fpath = os.path.join(EXPORT_DIR, job_id)
    if os.path.isfile(fpath):
        return send_file(fpath, as_attachment=True, download_name=job_id)
    return jsonify({"error": "Export file not found"}), 404


@apk_export_bp.route("/api/export/list", methods=["GET"])
def export_list():
    try:
        return jsonify({
            "exports": get_export_engine().list_exports(),
            "jobs":    get_export_engine().list_jobs(limit=20),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@apk_export_bp.route("/api/export/stats", methods=["GET"])
def export_stats():
    return jsonify(get_export_engine().stats())


@apk_export_bp.route("/api/export/delete/<filename>", methods=["DELETE", "POST"])
def export_delete(filename: str):
    ok = get_export_engine().delete_export(filename)
    return jsonify({"status": "ok" if ok else "not_found", "filename": filename})


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app) -> None:
    app.register_blueprint(apk_export_bp)
    log.info("[apk_export] ✓ Registered at /api/export")
    try:
        from zeus_identity import register_self
        register_self(
            module_name="zeus_apk_export",
            blueprint_var="apk_export_bp",
            url_prefix="/api/export",
            version="2.0",
            description="APK and blueprint export engine: zip/tar/json packaging, integrity checksums, download API",
            capabilities=[
                {"id": "export.analysis",  "endpoint": "/api/export/analysis",  "method": "POST", "tags": ["export", "apk"]},
                {"id": "export.blueprint", "endpoint": "/api/export/blueprint",  "method": "POST", "tags": ["export", "blueprint"]},
                {"id": "export.forge",     "endpoint": "/api/export/forge",      "method": "POST", "tags": ["export", "forge"]},
                {"id": "export.download",  "endpoint": "/api/export/download",   "method": "GET",  "tags": ["export", "download"]},
                {"id": "export.list",      "endpoint": "/api/export/list",       "method": "GET",  "tags": ["export"]},
                {"id": "export.health",    "endpoint": "/api/export/health",     "method": "GET",  "tags": ["health"]},
            ],
            depends_on=["zeus_blueprints", "zeus_apk_engine"],
            boot_order=70,
        )
    except Exception:
        pass


if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG)
    _app = _Flask(__name__)
    register(_app)
    _app.run(host="0.0.0.0", port=5020, debug=True, use_reloader=False)
