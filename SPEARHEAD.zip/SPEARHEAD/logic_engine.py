# The Zeus Project 2026 - Francois Nel
# logic_engine.py - Hyper-Intelligent Self-Evolving Logic & Reasoning Engine v2
# Meta-Reasoning | Dynamic Rule Generation | Self-Modification | Architectural Intelligence
# Deep Blueprint Planning | Synthesis Bridge | Knowledge Expansion | Pattern Critique
# 100% offline. No LLM calls. No external APIs. Pure intelligence.

import os
import re
import ast
import csv
import json
import math
import time
import uuid
import base64
import heapq
import logging
import hashlib
import tarfile
import zipfile
import struct
import shutil
import threading
import subprocess
import io
import sys
import copy
import itertools
from collections import defaultdict, Counter, deque, OrderedDict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Generator, Iterable, List, Optional, Set, Tuple, Union
from dataclasses import dataclass, field
from functools import lru_cache
from xml.etree import ElementTree as ET

from flask import Blueprint, request, jsonify

log = logging.getLogger("zeus.logic")
ZEUS_DIR = os.path.dirname(os.path.abspath(__file__))
logic_bp = Blueprint("logic", __name__)

# ============================================================================
# THREAD SAFETY & SINGLETON
# ============================================================================

_engine_lock = threading.RLock()
_engine_instance = None

def get_engine():
    global _engine_instance
    with _engine_lock:
        if _engine_instance is None:
            _engine_instance = LogicEngine()
            _engine_instance.boot()
        return _engine_instance


# ============================================================================
# CORE DATA STRUCTURES
# ============================================================================

@dataclass(eq=True, frozen=True)
class LogicFact:
    predicate: str
    args: Tuple[str, ...]
    confidence: float = 1.0
    source: str = "internal"
    timestamp: float = field(default_factory=time.time)
    negated: bool = False

    def __hash__(self):
        return hash((self.predicate, self.args, self.negated))

    def __eq__(self, other):
        if not isinstance(other, LogicFact):
            return False
        return (self.predicate == other.predicate and
                self.args == other.args and
                self.negated == other.negated)

    def to_str(self):
        neg = "NOT " if self.negated else ""
        args_str = ", ".join(self.args)
        return f"{neg}{self.predicate}({args_str})"


@dataclass(frozen=True)
class LogicRule:
    rule_id: str
    antecedents: Tuple
    consequent: Tuple
    weight: float = 1.0
    domain: str = "general"

    def matches_antecedents(self, fact_set, bindings):
        return _unify_antecedents(list(self.antecedents), list(fact_set), [bindings])


@dataclass(frozen=True)
class ConversionPath:
    source_format: str
    target_format: str
    steps: Tuple
    total_cost: float = 0.0
    estimated_fidelity: float = 1.0


@dataclass(frozen=True)
class ReasoningResult:
    query: str
    conclusions: Tuple
    reasoning_chain: Tuple
    confidence: float
    contradictions: Tuple
    abductive_hypotheses: Tuple
    duration_ms: float


@dataclass(frozen=True)
class BlueprintPlan:
    plan_id: str
    goal: str
    steps: Tuple
    dependency_graph: Dict
    estimated_duration_ms: float
    confidence: float
    created_at: float = field(default_factory=time.time)


@dataclass
class HierarchicalFact:
    subject: str
    relation: str
    object_: str
    confidence: float = 1.0
    source: str = "internal"
    metadata: Dict = field(default_factory=dict)

    def to_logic_fact(self):
        return LogicFact(
            predicate=self.relation,
            args=(self.subject, self.object_),
            confidence=self.confidence,
            source=self.source,
        )


@dataclass
class DynamicRule:
    rule_id: str
    antecedents: List
    consequent: Tuple
    weight: float = 1.0
    domain: str = "dynamic"
    generation_source: str = "self_modification"
    fire_count: int = 0
    test_pass_rate: float = 0.0
    created_at: float = field(default_factory=time.time)
    validated: bool = False

    def to_logic_rule(self):
        return LogicRule(
            rule_id=self.rule_id,
            antecedents=tuple((p, tuple(a), n) for p, a, n in self.antecedents),
            consequent=self.consequent,
            weight=self.weight,
            domain=self.domain,
        )


@dataclass
class ArchitecturalDecision:
    decision_id: str
    title: str
    status: str
    context: str
    decision: str
    consequences: List
    alternatives: List
    pattern_applied: Optional[str]
    confidence: float
    rationale: str


@dataclass
class SynthesisBlueprint:
    blueprint_id: str
    goal: str
    module_name: str
    module_type: str
    architecture_style: str
    layers: List
    interfaces: List
    dependencies: List
    data_flows: List
    design_patterns: List
    solid_compliance: Dict
    security_considerations: List
    scalability_patterns: List
    adrs: List
    synthesis_directives: List
    code_structure: Dict
    quality_gates: List
    test_plan: List
    confidence: float
    critique_score: float
    improvement_iterations: int
    created_at: float = field(default_factory=time.time)

    def to_dict(self):
        return {
            "blueprint_id":         self.blueprint_id,
            "goal":                 self.goal,
            "module_name":          self.module_name,
            "module_type":          self.module_type,
            "architecture_style":   self.architecture_style,
            "layers":               self.layers,
            "interfaces":           self.interfaces,
            "dependencies":         self.dependencies,
            "data_flows":           self.data_flows,
            "design_patterns":      self.design_patterns,
            "solid_compliance":     self.solid_compliance,
            "security_considerations": self.security_considerations,
            "scalability_patterns": self.scalability_patterns,
            "adrs": [
                {
                    "id": a.decision_id, "title": a.title, "status": a.status,
                    "context": a.context, "decision": a.decision,
                    "consequences": a.consequences, "alternatives": a.alternatives,
                    "pattern": a.pattern_applied, "confidence": a.confidence,
                    "rationale": a.rationale,
                }
                for a in self.adrs
            ],
            "synthesis_directives": self.synthesis_directives,
            "code_structure":       self.code_structure,
            "quality_gates":        self.quality_gates,
            "test_plan":            self.test_plan,
            "confidence":           self.confidence,
            "critique_score":       self.critique_score,
            "improvement_iterations": self.improvement_iterations,
            "created_at":           self.created_at,
        }


@dataclass
class PlanCritique:
    plan_id: str
    issues: List
    missing_concerns: List
    anti_patterns_detected: List
    solid_violations: List
    security_gaps: List
    overall_score: float
    recommended_patterns: List
    improvement_suggestions: List


# ============================================================================
# PROLOG-STYLE UNIFICATION ENGINE
# ============================================================================

_VAR_PATTERN = re.compile(r'^[A-Z_][A-Z0-9_]*$')

def _is_var(token):
    return bool(_VAR_PATTERN.match(token))

def _apply_bindings(args, bindings):
    return tuple(bindings.get(a, a) for a in args)

def _unify_args(pattern, ground, bindings):
    if len(pattern) != len(ground):
        return None
    new_bindings = dict(bindings)
    for p, g in zip(pattern, ground):
        if _is_var(p):
            if p in new_bindings:
                if new_bindings[p] != g:
                    return None
            else:
                if _occurs_check(p, g, new_bindings):
                    return None
                new_bindings[p] = g
        elif p != g:
            return None
    return new_bindings

def _occurs_check(var, term, bindings):
    if var == term:
        return True
    if _is_var(term) and term in bindings:
        return _occurs_check(var, bindings[term], bindings)
    return False

def _unify_antecedents(antecedents, facts, binding_list):
    if not antecedents:
        return binding_list
    pred, args, negated = antecedents[0]
    rest = antecedents[1:]
    results = []
    for bindings in binding_list:
        bound_args = _apply_bindings(args, bindings)
        matches = [f for f in facts
                   if f.predicate == pred and f.negated == negated and len(f.args) == len(bound_args)]
        for fact in matches:
            new_bindings = _unify_args(bound_args, fact.args, bindings)
            if new_bindings is not None:
                sub_results = _unify_antecedents(rest, facts, [new_bindings])
                results.extend(sub_results)
    return results

# ============================================================================
# PATTERN CLASSIFICATION
# ============================================================================

class PatternClassifier:
    LANG_SIGNATURES = {
        "python": [re.compile(r'\bdef\s+\w+\s*\('), re.compile(r'\bimport\s+\w+'),
                   re.compile(r'\bclass\s+\w+\s*[:\(]'), re.compile(r'\bif\s+__name__\s*==\s*["\']__main__["\']'),
                   re.compile(r'\bself\.\w+'), re.compile(r'\basync\s+def\s+'),
                   re.compile(r'\b@\w+\s*\n\s*def'), re.compile(r'\bwith\s+\w+\s+as\s+\w+')],
        "java": [re.compile(r'\bpublic\s+(class|interface|enum)\s+\w+'), re.compile(r'\bprivate\s+\w+\s+\w+\s*[;=\(]'),
                 re.compile(r'@Override'), re.compile(r'\bSystem\.out\.print'), re.compile(r'\bimport\s+java\.'),
                 re.compile(r'\bthrows\s+\w+'), re.compile(r'\bsynchronized\s+'), re.compile(r'\binstanceof\s+')],
        "kotlin": [re.compile(r'\bfun\s+\w+\s*\('), re.compile(r'\bval\s+\w+\s*[=:]'),
                   re.compile(r'\bvar\s+\w+\s*[=:]'), re.compile(r'\bdata\s+class\s+\w+'),
                   re.compile(r'\bobject\s+\w+'), re.compile(r'\blambda\s*\{'), re.compile(r'\bcoroutine\s+')],
        "javascript": [re.compile(r'\bconst\s+\w+\s*='), re.compile(r'\blet\s+\w+\s*='),
                       re.compile(r'=>\s*\{'), re.compile(r'\bconsole\.(log|error|warn)\('),
                       re.compile(r'\brequire\(["\']'), re.compile(r'\bexport\s+(default|const|function)'),
                       re.compile(r'\basync\s+(function|\(|\w+\s*=>)'), re.compile(r'\bawait\s+')],
        "typescript": [re.compile(r':\s*(string|number|boolean|any|void|never|unknown)\b'),
                       re.compile(r'\binterface\s+\w+\s*\{'), re.compile(r'\btype\s+\w+\s*='),
                       re.compile(r'<[A-Z]\w*>'), re.compile(r'\bgeneric\s*<'), re.compile(r'\bdecorator\s+')],
        "rust": [re.compile(r'\bfn\s+\w+\s*\('), re.compile(r'\blet\s+mut\s+\w+'), re.compile(r'\bimpl\s+\w+'),
                 re.compile(r'\buse\s+std::'), re.compile(r'\bmatch\s+\w+\s*\{'), re.compile(r'\bunsafe\s+\{'),
                 re.compile(r'\basync\s+fn\s+'), re.compile(r'\bmacro_rules!')],
        "go": [re.compile(r'\bfunc\s+\w+\s*\('), re.compile(r'\bpackage\s+\w+'), re.compile(r':='),
               re.compile(r'\bchan\b'), re.compile(r'\bdefer\s+'), re.compile(r'\binterface\{\}'),
               re.compile(r'\bgo\s+\w+\s*\(')],
        "c": [re.compile(r'#include\s*[<"][^>"]+[>"]'), re.compile(r'\bint\s+main\s*\('),
              re.compile(r'\bprintf\s*\('), re.compile(r'\bmalloc\s*\('), re.compile(r'\bstruct\s+\w+\s*\{'),
              re.compile(r'\bpointer\s*\*'), re.compile(r'\b#define\s+')],
        "cpp": [re.compile(r'\bstd::\w+'), re.compile(r'\btemplate\s*<'), re.compile(r'\bcout\s*<<'),
                re.compile(r'\bnamespace\s+\w+'), re.compile(r'\bclass\s+\w+\s*\{'),
                re.compile(r'\bvirtual\s+'), re.compile(r'\bconst_cast')],
        "sql": [re.compile(r'\bSELECT\b', re.IGNORECASE), re.compile(r'\bFROM\b', re.IGNORECASE),
                re.compile(r'\bINSERT\s+INTO\b', re.IGNORECASE), re.compile(r'\bCREATE\s+TABLE\b', re.IGNORECASE),
                re.compile(r'\bWHERE\b', re.IGNORECASE), re.compile(r'\bJOIN\b', re.IGNORECASE),
                re.compile(r'\bUNION\b', re.IGNORECASE)],
        "html": [re.compile(r'<!DOCTYPE\s+html', re.IGNORECASE), re.compile(r'<html[\s>]', re.IGNORECASE),
                 re.compile(r'<(div|span|p|a|h[1-6])\b'), re.compile(r'<script[^>]*>'),
                 re.compile(r'<style[^>]*>'), re.compile(r'<meta\s+')],
        "css": [re.compile(r'[.#][\w-]+\s*\{'), re.compile(r':\s*(px|em|rem|%|vh|vw)\b'),
                re.compile(r'@(media|keyframes|import)\b'), re.compile(r'animation:\s*'), re.compile(r'flex\s*:')],
        "json": [re.compile(r'^\s*[\{\[]'), re.compile(r'"[\w\-]+":\s*[\[\{"\d\-]'),
                 re.compile(r':\s*(true|false|null|[\d.]+)')],
        "yaml": [re.compile(r'^[\w\-]+:\s*\S', re.MULTILINE), re.compile(r'^\s*-\s+\w+', re.MULTILINE),
                 re.compile(r'^---', re.MULTILINE), re.compile(r'^\.\.\.$', re.MULTILINE)],
        "xml": [re.compile(r'<\?xml\s+version'), re.compile(r'<[\w:]+[^>]*/?>'),
                re.compile(r'xmlns\s*='), re.compile(r'CDATA')],
        "shell": [re.compile(r'^#!/(bin|usr/bin)/(bash|sh|zsh)', re.MULTILINE), re.compile(r'\$\{?\w+\}?'),
                  re.compile(r'\becho\s+'), re.compile(r'\bif\s+\[\s*'), re.compile(r'\bfor\s+\w+\s+in\s+')],
    }

    FORMAT_SIGNATURES = {
        "zip": b"PK\x03\x04", "gzip": b"\x1f\x8b", "bzip2": b"BZh", "xz": b"\xfd7zXZ",
        "elf": b"\x7fELF", "pe": b"MZ", "class": b"\xca\xfe\xba\xbe", "pdf": b"%PDF",
        "png": b"\x89PNG", "jpg": b"\xff\xd8\xff", "gif": b"GIF8", "mp3": b"ID3",
        "sqlite": b"SQLite format 3",
    }

    def classify_content(self, content, hint_ext=""):
        scores = defaultdict(float)
        if hint_ext:
            scores[hint_ext.lstrip(".").lower()] += 2.0
        for lang, patterns in self.LANG_SIGNATURES.items():
            hits = sum(1 for p in patterns if p.search(content))
            if hits:
                scores[lang] += hits * 0.8 / len(patterns)
        entropy = self._byte_entropy(content.encode("utf-8", errors="replace"))
        if entropy > 7.5:
            scores["binary"] += 1.5
        elif entropy < 3.0:
            scores["structured_data"] += 0.5
        tokens = re.findall(r'\w+', content)
        if tokens:
            freq = Counter(tokens)
            top10 = [w for w, _ in freq.most_common(10)]
            code_kw = {"def","class","import","return","function","var","let","const","public",
                       "private","fn","func","fun","void","int","async","await","try","catch","throw","interface"}
            scores["code"] += len(set(top10) & code_kw) * 0.25
            scores["token_diversity"] = len(set(tokens)) / max(len(tokens), 1)
        if content.count('\n') > 100:
            scores["large_code"] = 0.3
        total = sum(scores.values()) or 1.0
        return {k: round(v / total, 4) for k, v in sorted(scores.items(), key=lambda x: -x[1])}

    def classify_binary(self, data):
        result = {"format": "unknown", "confidence": 0.0, "details": {}}
        for fmt, magic in self.FORMAT_SIGNATURES.items():
            if data[:len(magic)] == magic:
                result["format"] = fmt
                result["confidence"] = 0.98
                break
        entropy = self._byte_entropy(data[:4096])
        result["entropy"] = round(entropy, 4)
        result["details"]["size_bytes"] = len(data)
        result["details"]["null_ratio"] = round(data.count(0) / max(len(data), 1), 4)
        result["details"]["printable_ratio"] = round(sum(1 for b in data if 0x20 <= b < 0x7f) / max(len(data), 1), 4)
        if entropy > 7.8:
            result["details"]["compressed_or_encrypted"] = True
        freq = Counter(data[:1024])
        total = max(len(data[:1024]), 1)
        result["details"]["byte_distribution"] = {
            "unique_bytes": len(freq),
            "entropy": round(-sum((c/total)*math.log2(c/total) for c in freq.values() if c), 4),
            "max_byte_freq": round(max(freq.values())/total, 4),
        }
        return result

    @staticmethod
    def _byte_entropy(data):
        if not data:
            return 0.0
        freq = Counter(data)
        total = len(data)
        return -sum((c/total)*math.log2(c/total) for c in freq.values() if c)

    def fingerprint_structure(self, content):
        lines = content.splitlines()
        branch_kw = re.compile(r'\b(if|elif|else|for|while|switch|case|catch|except|try|finally|with|match|when|guard|unless|async|await)\b')
        branches = sum(1 for l in lines if branch_kw.search(l))
        depths = [len(l) - len(l.lstrip(" \t")) for l in lines if l.strip()]
        max_depth = max(depths, default=0) // 4 if depths else 0
        func_pat = re.compile(r'\b(?:def|fun|func|function|fn)\s+(\w+)\s*\(')
        class_pat = re.compile(r'\b(?:class|struct|enum|interface)\s+(\w+)')
        import_pat = re.compile(r'\b(?:import|from|require|use|include|using)\s+[\w./"\']+')
        functions = func_pat.findall(content)
        classes = class_pat.findall(content)
        imports = import_pat.findall(content)
        coupling = len(imports) / max(len(functions) + len(classes) + 1, 1)
        comment_lines = sum(1 for l in lines if re.match(r'\s*(#|//|/\*|\*|<!--|--)', l))
        string_literals = len(re.findall(r'(["\'])((?:(?=(\\?))\3.)*?)\1', content))
        return {
            "line_count": len(lines), "branch_count": branches, "cyclomatic_proxy": branches + 1,
            "max_nesting_depth": max_depth, "function_count": len(functions), "class_count": len(classes),
            "import_count": len(imports), "coupling_score": round(coupling, 4),
            "comment_density": round(comment_lines / max(len(lines), 1), 4),
            "string_literal_count": string_literals, "functions": functions[:20], "classes": classes[:10],
        }


# ============================================================================
# SEMANTIC INDEX (TF-IDF)
# ============================================================================

class SemanticIndex:
    def __init__(self):
        self._lock = threading.RLock()
        self._docs = []
        self._tfidf_matrix = []
        self._idf = {}
        self._vocab = set()
        self._built = False
        threading.Thread(target=self._auto_refresh, daemon=True).start()

    def _tokenize(self, text):
        text = text.lower()
        tokens = re.findall(r'[a-z][a-z0-9_]{2,}', text)
        stopwords = {"the","and","for","are","but","not","you","all","can","had","her","was","one","our","out",
                     "day","get","has","him","his","how","its","may","new","now","own","see","two","who","did",
                     "use","way","than","also","each","from","this","that","they","with","have","will","your",
                     "more","been","what","when","were","very","should","would","could","just","only","same","such"}
        return [t for t in tokens if t not in stopwords and len(t) > 2]

    def build(self, docs):
        with self._lock:
            self._docs = docs
            tokenized = [self._tokenize(f"{t} {c}") for _, t, c in docs]
            df = defaultdict(int)
            for tokens in tokenized:
                for t in set(tokens):
                    df[t] += 1
            N = max(len(docs), 1)
            self._idf = {t: math.log((N+1)/(cnt+1))+1 for t, cnt in df.items()}
            self._vocab = set(self._idf.keys())
            self._tfidf_matrix = []
            for tokens in tokenized:
                tf = Counter(tokens)
                denom = max(len(tokens), 1)
                self._tfidf_matrix.append({t: (cnt/denom)*self._idf.get(t,1.0) for t,cnt in tf.items()})
            self._built = True

    def search(self, query, top_k=10):
        with self._lock:
            if not self._built or not self._docs:
                return []
            qtokens = self._tokenize(query)
            qtf = Counter(qtokens)
            denom = max(len(qtokens), 1)
            qvec = {t: (cnt/denom)*self._idf.get(t,1.0) for t,cnt in qtf.items() if t in self._vocab}
            if not qvec:
                return []
            qnorm = math.sqrt(sum(v*v for v in qvec.values()))
            if qnorm == 0:
                return []
            results = []
            for doc_vec, (rowid, topic, content) in zip(self._tfidf_matrix, self._docs):
                dot = sum(qvec.get(t,0)*v for t,v in doc_vec.items())
                dnorm = math.sqrt(sum(v*v for v in doc_vec.values()))
                cos = dot/(qnorm*dnorm) if dnorm else 0.0
                if cos > 0.01:
                    results.append((cos, rowid, topic, content[:200].replace("\n"," ")))
            results.sort(key=lambda x: -x[0])
            return results[:top_k]

    def rebuild_from_db(self):
        try:
            from db_init import get_db
            conn = get_db()
            rows = conn.execute("SELECT rowid, topic, content FROM knowledge ORDER BY rowid DESC LIMIT 5000").fetchall()
            conn.close()
            self.build([(r[0], r[1], r[2] or "") for r in rows])
            log.info(f"[SemanticIndex] Indexed {len(rows)} knowledge entries")
        except Exception as e:
            log.warning(f"[SemanticIndex] Rebuild failed: {e}")

    def _auto_refresh(self):
        while True:
            time.sleep(60)
            self.rebuild_from_db()

# ============================================================================
# ARCHITECTURAL KNOWLEDGE BASE
# ============================================================================

class ArchitecturalKnowledgeBase:
    CLEAN_ARCHITECTURE = {
        "name": "Clean Architecture", "author": "Robert C. Martin",
        "layers": [
            {"name":"Entities","level":0,"description":"Enterprise business rules; core domain objects with zero external deps.",
             "components":["Entity","ValueObject","DomainEvent","Aggregate"],
             "rules":["Must not depend on any outer layer","Contains only pure business logic","Framework-independent"],
             "code_patterns":["@Entity","frozen dataclass","equality on identity","no framework imports"]},
            {"name":"UseCases","level":1,"description":"Application-specific business rules.",
             "components":["UseCase","Interactor","Command","Query","ApplicationService"],
             "rules":["Depends only on Entities layer","Defines repository/gateway interfaces","Single responsibility"],
             "code_patterns":["interface InputPort","interface OutputPort","CQRS separation"]},
            {"name":"InterfaceAdapters","level":2,"description":"Converts data between use cases and external formats.",
             "components":["Controller","Presenter","ViewModel","Gateway","Repository"],
             "rules":["Implements interfaces defined by UseCases","Handles format conversion only; no business logic"],
             "code_patterns":["implements IRepository","DTO mapping","Mapper classes"]},
            {"name":"Frameworks","level":3,"description":"External frameworks, databases, UI.",
             "components":["WebFramework","Database","UI","ExternalAPI"],
             "rules":["Minimise code here; it is a plug-in layer"],
             "code_patterns":["Flask routes","SQLAlchemy models","Android Activities"]},
        ],
        "core_principle": "Dependency Rule: source code dependencies must always point inward.",
        "benefits": ["Testability","Framework independence","UI independence","Database independence"],
        "anti_patterns": [
            "Controller calling repository directly","Entity importing a framework class",
            "Business logic inside a Flask route","Skipping layers without ACL",
        ],
    }

    DDD_CONCEPTS = {
        "tactical_patterns": {
            "Entity": {"rules":["Unique identity","Mutable","Equality by id"],"hints":["has id field","equals on id only"]},
            "ValueObject": {"rules":["No identity","Immutable","Equality by value"],"hints":["frozen dataclass","no setters"]},
            "Aggregate": {"rules":["Root is single entry point","External refs to root only","Transactional boundary"],"hints":["AggregateRoot marker"]},
            "Repository": {"rules":["Interface in domain","Implementation in infrastructure"],"hints":["IXRepository interface","save/find/delete"]},
            "DomainService": {"rules":["Stateless","Pure domain logic"],"hints":["domain verb in service name"]},
            "DomainEvent": {"rules":["Immutable","Past tense name","Carries relevant data"],"hints":["XxxOccurred","XxxCreated"]},
            "Factory": {"rules":["Ensures valid state on creation"],"hints":["create()","build()","of()"]},
        },
        "strategic_patterns": {
            "BoundedContext": "Explicit semantic boundary for a domain model",
            "UbiquitousLanguage": "Shared vocabulary between domain experts and code",
            "ContextMap": "Explicit map of relationships between bounded contexts",
            "AnticorruptionLayer": "Translation layer shielding one context from another",
        },
    }

    SOLID_PRINCIPLES = {
        "SRP": {"name":"Single Responsibility Principle","definition":"A class should have one and only one reason to change.",
                "detection_signals":["class with >10 public methods from unrelated domains"],
                "solutions":["Extract class","Service decomposition","Separate concerns"],
                "zeus_note":"Each Zeus module owns exactly one domain concern."},
        "OCP": {"name":"Open/Closed Principle","definition":"Open for extension; closed for modification.",
                "detection_signals":["long if/elif chains on type","switch on class"],
                "solutions":["Strategy pattern","Plugin architecture"],
                "zeus_note":"Zeus modules are extensible without editing core engine code."},
        "LSP": {"name":"Liskov Substitution Principle","definition":"Subtypes must be substitutable for their base types.",
                "detection_signals":["isinstance checks in base-class code"],
                "solutions":["Redesign hierarchy","Composition over inheritance"],
                "zeus_note":"All Zeus module interfaces must be fully substitutable."},
        "ISP": {"name":"Interface Segregation Principle","definition":"Clients should not depend on interfaces they don't use.",
                "detection_signals":["fat interface with >8 methods"],
                "solutions":["Split interface into role interfaces"],
                "zeus_note":"Zeus blueprints expose only the API surface their consumers need."},
        "DIP": {"name":"Dependency Inversion Principle","definition":"Depend on abstractions, not concretions.",
                "detection_signals":["direct class instantiation inside business logic"],
                "solutions":["Constructor injection","Factory","Service locator"],
                "zeus_note":"Zeus engine dependencies are injected, never created inline."},
    }

    DESIGN_PATTERNS = {
        "creational": {
            "Singleton":  {"when":"Shared resource with one instance","zeus":"LogicEngine, GenomeDB singletons"},
            "Factory":    {"when":"Unknown concrete class at compile time","zeus":"Dynamic Zeus module loader"},
            "Builder":    {"when":"Complex object with many optional parts","zeus":"SynthesisBlueprint builder, APKBuilder"},
            "Prototype":  {"when":"Expensive creation; need variants","zeus":"Genome mutation clones base genome"},
            "AbstractFactory": {"when":"Families of related objects","zeus":"Platform-specific synthesis factories"},
        },
        "structural": {
            "Adapter":   {"when":"Incompatible interfaces","zeus":"ACL adapter between Zeus and external LLMs"},
            "Decorator": {"when":"Dynamic responsibility attachment","zeus":"Decorate synthesis results with security checks"},
            "Facade":    {"when":"Simplified interface to a complex subsystem","zeus":"LogicEngine is facade for all sub-engines"},
            "Proxy":     {"when":"Lazy init, access control, caching","zeus":"Lazy-loading proxy for heavyweight genome objects"},
            "Composite": {"when":"Tree structures treated uniformly","zeus":"Hierarchical plan steps, nested knowledge"},
            "Bridge":    {"when":"Decouple abstraction from implementation","zeus":"Synthesis abstraction over multiple LLM backends"},
        },
        "behavioral": {
            "Strategy":                {"when":"Multiple interchangeable algorithms","zeus":"Multiple synthesis strategies"},
            "Observer":                {"when":"One-to-many event notifications","zeus":"Zeus lifecycle event bus"},
            "Command":                 {"when":"Encapsulate requests; support undo/queue","zeus":"Genome mutation commands"},
            "Chain_of_Responsibility": {"when":"Multiple handlers for a request","zeus":"Zeus pipeline stages"},
            "Template_Method":         {"when":"Algorithm skeleton with variant steps","zeus":"Base synthesis template"},
            "State":                   {"when":"Behavior changes with internal state","zeus":"Zeus module lifecycle states"},
            "Iterator":                {"when":"Sequential traversal without exposing structure","zeus":"Knowledge base iteration"},
        },
    }

    SECURITY_PATTERNS = {
        "InputValidation":   {"rules":["Whitelist over blacklist","Validate type+length+format+range","Reject early"],"zeus":"All Flask route inputs validated"},
        "AuthN_AuthZ":       {"rules":["Authenticate then authorize","Least privilege"],"zeus":"Zeus endpoints use token-based auth"},
        "SecureDefaults":    {"rules":["Deny by default","Minimal permissions"],"zeus":"Unknown module requests denied"},
        "FailSecure":        {"rules":["On failure → secure state","Log failures","Generic errors to client"],"zeus":"Logic errors return safe 500"},
        "DataEncryption":    {"rules":["Encrypt at rest and in transit"],"zeus":"Genome and synthesis artifacts encrypted at rest"},
        "InjectionPrevention": {"rules":["Parameterised queries","ORM over raw SQL"],"zeus":"All DB ops use parameterised queries"},
        "RateLimiting":      {"rules":["Throttle expensive endpoints","Per-client limits"],"zeus":"Synthesis and reasoning endpoints rate-limited"},
    }

    SCALABILITY_PATTERNS = {
        "CQRS":          {"description":"Separate read and write models","zeus":"Separate read from write path"},
        "EventSourcing": {"description":"Store state as sequence of events","zeus":"Genome mutations stored as events"},
        "CircuitBreaker":{"description":"Prevent cascading failures on external calls","zeus":"LLM API calls wrapped in circuit breaker"},
        "Bulkhead":      {"description":"Isolate failures to prevent cascade","zeus":"Zeus modules in separate thread pools"},
        "Caching":       {"patterns":["Cache-aside","Write-through"],"zeus":"Cache classification and genome lookups"},
        "Backpressure":  {"description":"Signal producer to slow down when consumer overwhelmed","zeus":"Learning queue backpressure"},
    }

    ZEUS_PATTERNS = {
        "GenomeMutation":      {"rules":["Preserve fitness metrics","Track full lineage","Rollback on regression"],"anti":["Unbounded mutation","No fitness tracking"]},
        "SelfInstallation":    {"rules":["Verify deps before install","Atomic installation","Rollback on failure"],"anti":["Partial install"]},
        "OfflineFirstReasoning":{"rules":["No blocking external calls","Graceful LLM degradation","Local knowledge sufficient"],"anti":["Required external API"]},
        "KnowledgePersistence":{"rules":["SQLite WAL mode","Versioned knowledge entries","Merge without duplication"],"anti":["In-memory only"]},
        "ZeroTouchSynthesis":  {"rules":["Full blueprint before code generation","Quality gates block bad output","Self-critique before emit"],"anti":["Generate without blueprint"]},
    }

    def get_relevant_patterns(self, goal, context):
        g = goal.lower()
        result = {}
        if any(k in g for k in ("api","service","module","engine","system","server")):
            result["architecture"] = ["Clean Architecture","DDD"]
        if any(k in g for k in ("api","endpoint","route","auth","secure","web")):
            result["security"] = list(self.SECURITY_PATTERNS.keys())
        if any(k in g for k in ("scale","performance","cache","queue","load")):
            result["scalability"] = ["CQRS","Caching","CircuitBreaker","Bulkhead"]
        if any(k in g for k in ("plugin","extend","module","dynamic")):
            result["design_patterns"] = ["Strategy","Factory","Observer","Bridge"]
        if any(k in g for k in ("genome","mutate","evolve","dna")):
            result["zeus"] = ["GenomeMutation","KnowledgePersistence"]
        if any(k in g for k in ("synthesis","generate","build","code")):
            result.setdefault("design_patterns",[])
            result["design_patterns"] += ["Builder","Template_Method","Chain_of_Responsibility"]
        if any(k in g for k in ("learn","knowledge","expand","ingest")):
            result["zeus"] = result.get("zeus",[]) + ["KnowledgePersistence","OfflineFirstReasoning"]
        return result

    def get_solid_checklist(self, module_type):
        return {p: True for p in self.SOLID_PRINCIPLES}

    def get_anti_patterns_for_goal(self, goal):
        g = goal.lower()
        anti = list(self.CLEAN_ARCHITECTURE["anti_patterns"])
        for p in self.ZEUS_PATTERNS.values():
            anti.extend(p.get("anti", []))
        if "api" in g or "web" in g:
            anti += ["SQL injection risk","Unauthenticated endpoints","No rate limiting"]
        return list(dict.fromkeys(anti))


# ============================================================================
# HIERARCHICAL FACT STORE
# ============================================================================

class HierarchicalFactStore:
    def __init__(self):
        self._lock = threading.RLock()
        self._triples = []
        self._index = defaultdict(list)

    def add(self, fact):
        with self._lock:
            for existing in self._index[fact.subject]:
                if existing.relation == fact.relation and existing.object_ == fact.object_:
                    return
            self._triples.append(fact)
            self._index[fact.subject].append(fact)

    def add_many(self, facts):
        for f in facts:
            self.add(f)

    def get_all_objects(self, subject, relation, transitive=False):
        with self._lock:
            seen = set()
            queue = deque([subject])
            while queue:
                node = queue.popleft()
                for fact in self._index.get(node, []):
                    if fact.relation == relation and fact.object_ not in seen:
                        seen.add(fact.object_)
                        if transitive:
                            queue.append(fact.object_)
            return list(seen)

    def get_all_subjects(self, object_, relation):
        with self._lock:
            return [f.subject for f in self._triples if f.relation == relation and f.object_ == object_]

    def is_a(self, subject, class_, transitive=True):
        return class_ in self.get_all_objects(subject, "is_a", transitive)

    def to_logic_facts(self):
        with self._lock:
            return [f.to_logic_fact() for f in self._triples]

    def seed_zeus_taxonomy(self):
        taxonomy = [
            ("zeus_module","is_a","software_component"), ("logic_engine","is_a","zeus_module"),
            ("synthesis_engine","is_a","zeus_module"), ("genome_db","is_a","zeus_module"),
            ("knowledge_base","is_a","zeus_module"), ("apk_builder","is_a","zeus_module"),
            ("mutator","is_a","zeus_module"), ("synthesis_engine","depends_on","logic_engine"),
            ("synthesis_engine","depends_on","genome_db"), ("synthesis_engine","depends_on","knowledge_base"),
            ("mutator","depends_on","genome_db"), ("logic_engine","has_property","offline_capable"),
            ("logic_engine","has_property","self_modifying"), ("logic_engine","implements","clean_architecture"),
            ("logic_engine","implements","solid_principles"), ("zeus_system","part_of","android_device"),
            ("zeus_system","implements","flask_api"), ("zeus_system","has_property","armv7l_compatible"),
        ]
        self.add_many([HierarchicalFact(s, r, o, source="zeus_taxonomy") for s, r, o in taxonomy])

# ============================================================================
# ADVANCED REASONING ENGINE
# ============================================================================

class AdvancedReasoningEngine:
    BUILTIN_RULES = [
        # File & format
        LogicRule("file_type_inference",(("has_extension",("X","EXT"),False),("extension_category",("EXT","CAT"),False)),("file_category",("X","CAT")),0.9,"file"),
        LogicRule("convertible_pair",(("file_category",("X","CAT1"),False),("file_category",("Y","CAT2"),False),("conversion_supported",("CAT1","CAT2"),False)),("can_convert",("X","Y")),0.85,"conversion"),
        LogicRule("archive_recursive",(("file_category",("X","archive"),False),),("needs_recursive_processing",("X",)),0.99,"processing"),
        LogicRule("android_full_pipeline",(("file_category",("X","android"),False),),("run_apk_pipeline",("X",)),0.97,"processing"),
        LogicRule("jvm_genome_candidate",(("file_category",("X","jvm"),False),("high_confidence_source",("X",),False)),("genome_candidate",("X",)),0.82,"genome"),
        LogicRule("data_knowledge_candidate",(("file_category",("X","data"),False),),("knowledge_candidate",("X",)),0.88,"knowledge"),
        LogicRule("binary_executable_risk",(("file_category",("X","binary"),False),("file_entropy_high",("X",),False)),("possibly_encrypted_or_packed",("X",)),0.75,"security"),
        # Knowledge & trust
        LogicRule("knowledge_source_trust",(("source_type",("S","internal"),False),),("high_confidence_source",("S",)),0.95,"knowledge"),
        LogicRule("complex_logical_inference",(("has_property",("X","structured"),False),("has_property",("X","rich"),False)),("synthesis_enrichment_candidate",("X",)),0.91,"enrichment"),
        # Genome
        LogicRule("genome_stability",(("genome_age_days",("G","AGE"),False),("genome_used_count",("G","N"),False)),("stable_genome",("G",)),0.80,"genome"),
        LogicRule("synthesis_candidate",(("stable_genome",("G",),False),("knowledge_coverage",("G","HIGH"),False)),("synthesis_ready",("G",)),0.88,"synthesis"),
        LogicRule("synthesis_blueprint_ready",(("synthesis_ready",("G",),False),("architectural_patterns_applied",("G",),False)),("blueprint_generation_ready",("G",)),0.90,"synthesis"),
        # Code quality
        LogicRule("code_quality_low",(("cyclomatic_proxy_high",("X",),False),("comment_density_low",("X",),False)),("low_quality_code",("X",)),0.70,"code_quality"),
        LogicRule("code_quality_high",(("comment_density_high",("X",),False),("coupling_low",("X",),False)),("high_quality_code",("X",)),0.80,"code_quality"),
        LogicRule("deep_nesting_smell",(("max_nesting_depth_very_high",("X",),False),),("deep_nesting_code_smell",("X",)),0.78,"code_quality"),
        LogicRule("god_class_risk",(("class_method_count_high",("X",),False),("high_coupling_score",("X",),False)),("god_class_risk",("X",)),0.82,"code_quality"),
        LogicRule("needs_refactoring",(("low_quality_code",("X",),False),("god_class_risk",("X",),False)),("refactoring_required",("X",)),0.85,"code_quality"),
        # Architecture compliance
        LogicRule("clean_arch_violation_direct_db",(("is_controller",("X",),False),("calls_repository_directly",("X",),False)),("clean_arch_violation",("X",)),0.90,"architecture"),
        LogicRule("clean_arch_violation_entity_import",(("is_entity",("X",),False),("imports_framework",("X",),False)),("clean_arch_violation",("X",)),0.92,"architecture"),
        LogicRule("srp_violation",(("has_multiple_responsibilities",("X",),False),),("violates_srp",("X",)),0.87,"solid"),
        LogicRule("ocp_violation",(("has_type_switch",("X",),False),("modification_needed_for_extension",("X",),False)),("violates_ocp",("X",)),0.80,"solid"),
        LogicRule("dip_violation",(("has_direct_class_instantiation_in_logic",("X",),False),),("violates_dip",("X",)),0.82,"solid"),
        LogicRule("solid_compliant",(("high_quality_code",("X",),False),("coupling_low",("X",),False),("comment_density_high",("X",),False)),("solid_compliant_module",("X",)),0.75,"solid"),
        # Security
        LogicRule("exposed_endpoint_needs_auth",(("is_endpoint",("X",),False),("handles_sensitive_data",("X",),False)),("requires_authentication",("X",)),0.92,"security"),
        LogicRule("sql_injection_risk",(("uses_string_format_in_query",("X",),False),),("sql_injection_vulnerability",("X",)),0.88,"security"),
        LogicRule("no_rate_limiting_risk",(("is_endpoint",("X",),False),("no_rate_limit_configured",("X",),False)),("rate_limit_vulnerability",("X",)),0.72,"security"),
        LogicRule("secrets_in_code",(("has_hardcoded_credential",("X",),False),),("credential_exposure_risk",("X",)),0.95,"security"),
        LogicRule("security_posture_high",(("has_input_validation",("X",),False),("uses_parameterised_queries",("X",),False),("has_authentication",("X",),False)),("high_security_posture",("X",)),0.85,"security"),
        # DDD
        LogicRule("aggregate_root_candidate",(("has_domain_identity",("X",),False),("has_child_entities",("X",),False)),("aggregate_root_candidate",("X",)),0.80,"ddd"),
        LogicRule("value_object_candidate",(("has_no_identity",("X",),False),("is_immutable",("X",),False)),("value_object_candidate",("X",)),0.83,"ddd"),
        LogicRule("anemic_domain_model",(("domain_class_has_no_behaviour",("X",),False),),("anemic_domain_model_smell",("X",)),0.75,"ddd"),
        # Scalability
        LogicRule("cqrs_recommended",(("has_read_write_imbalance",("X",),False),),("cqrs_pattern_recommended",("X",)),0.78,"scalability"),
        LogicRule("caching_recommended",(("has_repeated_expensive_computations",("X",),False),),("caching_pattern_recommended",("X",)),0.82,"scalability"),
        LogicRule("circuit_breaker_needed",(("has_external_service_dependency",("X",),False),),("circuit_breaker_recommended",("X",)),0.85,"scalability"),
        LogicRule("event_sourcing_beneficial",(("requires_full_audit_trail",("X",),False),),("event_sourcing_recommended",("X",)),0.77,"scalability"),
        # Zeus-specific
        LogicRule("zeus_module_stable",(("zeus_module_booted",("M",),False),("zeus_module_no_errors",("M",),False)),("zeus_module_healthy",("M",)),0.90,"zeus"),
        LogicRule("zeus_self_modify_safe",(("proposed_rule_validated",("R",),False),("no_contradiction_introduced",("R",),False)),("safe_to_apply_rule",("R",)),0.88,"zeus"),
        LogicRule("knowledge_expansion_ready",(("new_synthesis_result_available",("S",),False),("result_quality_sufficient",("S",),False)),("trigger_knowledge_expansion",("S",)),0.82,"zeus"),
        LogicRule("synthesis_quality_gate_pass",(("blueprint_generation_ready",("G",),False),("no_clean_arch_violations",("G",),False),("high_security_posture",("G",),False)),("synthesis_quality_gate_passed",("G",)),0.88,"zeus"),
    ]

    def __init__(self):
        self._rules = list(self.BUILTIN_RULES)
        self._dynamic_rules = []
        self._rules_lock = threading.RLock()
        self._rule_fire_counts = defaultdict(int)

    def add_rule(self, rule):
        with self._rules_lock:
            if not any(r.rule_id == rule.rule_id for r in self._rules):
                self._rules.append(rule)

    def add_dynamic_rule(self, drule):
        with self._rules_lock:
            self._dynamic_rules.append(drule)
            self._rules.append(drule.to_logic_rule())

    def reason(self, initial_facts, domain_filter=None, max_depth=15):
        t0 = time.time()
        fact_set = set(initial_facts)
        derived = set()
        chain = []
        contradictions = []
        visited = set()
        with self._rules_lock:
            rules = [r for r in self._rules if domain_filter is None or r.domain == domain_filter]
        for depth in range(max_depth):
            new_this_round = []
            for rule in rules:
                for bindings in rule.matches_antecedents(fact_set, {}):
                    cpred, cargs_t = rule.consequent
                    cargs = _apply_bindings(cargs_t, bindings)
                    key = (cpred, cargs)
                    if key in visited:
                        continue
                    visited.add(key)
                    ant_confs = []
                    for apred, aargs_t, aneg in rule.antecedents:
                        aargs = _apply_bindings(aargs_t, bindings)
                        for f in fact_set:
                            if f.predicate == apred and f.args == aargs and f.negated == aneg:
                                ant_confs.append(f.confidence)
                                break
                    conf = (min(ant_confs) if ant_confs else 0.5) * rule.weight
                    new_fact = LogicFact(predicate=cpred, args=cargs, confidence=round(conf,4), source=f"rule:{rule.rule_id}")
                    neg = LogicFact(predicate=cpred, args=cargs, negated=True)
                    if neg in fact_set:
                        contradictions.append((new_fact, neg))
                        chain.append(f"CONTRADICTION: {new_fact.to_str()} vs negation")
                        continue
                    new_this_round.append(new_fact)
                    self._rule_fire_counts[rule.rule_id] += 1
                    chain.append(f"[d={depth}] {rule.rule_id} -> {new_fact.to_str()} (c={conf:.3f})")
            if not new_this_round:
                break
            for nf in new_this_round:
                fact_set.add(nf)
                derived.add(nf)
        abductive = self._abduce(fact_set, rules)
        duration_ms = (time.time() - t0) * 1000
        avg_conf = sum(f.confidence for f in derived) / len(derived) if derived else 0.0
        return ReasoningResult(
            query="; ".join(f.to_str() for f in initial_facts[:3]),
            conclusions=tuple(derived), reasoning_chain=tuple(chain),
            confidence=round(avg_conf,4), contradictions=tuple(contradictions),
            abductive_hypotheses=tuple(abductive), duration_ms=round(duration_ms,2),
        )

    def meta_reason(self):
        with self._rules_lock:
            rules = list(self._rules)
        domains = Counter(r.domain for r in rules)
        fired = {rid: cnt for rid, cnt in self._rule_fire_counts.items() if cnt > 0}
        never_fired = [r.rule_id for r in rules if self._rule_fire_counts[r.rule_id] == 0]
        consequent_map = defaultdict(list)
        for r in rules:
            consequent_map[r.consequent[0]].append(r.rule_id)
        conflicts = {pred: ids for pred, ids in consequent_map.items() if len(ids) > 2}
        all_consequents = {r.consequent[0] for r in rules}
        all_ant_preds = {a[0] for r in rules for a in r.antecedents}
        base_facts = {"has_extension","has_property","source_type","file_entropy_high","cyclomatic_proxy_high",
                      "comment_density_low","comment_density_high","coupling_low","genome_age_days","genome_used_count",
                      "knowledge_coverage","is_controller","is_entity","is_endpoint","handles_sensitive_data",
                      "has_domain_identity","has_child_entities","zeus_module_booted","zeus_module_no_errors",
                      "proposed_rule_validated","new_synthesis_result_available","result_quality_sufficient",
                      "architectural_patterns_applied"}
        orphans = sorted(all_ant_preds - all_consequents - base_facts)
        return {
            "total_rules": len(rules), "dynamic_rules": len(self._dynamic_rules),
            "domain_distribution": dict(domains), "fired_rules_count": len(fired),
            "never_fired_rules": never_fired[:20], "potential_conflicts": conflicts,
            "orphan_antecedent_predicates": orphans,
            "top_fired_rules": sorted(fired.items(), key=lambda x: -x[1])[:10],
        }

    def generate_shortcut_rule(self, observed_chain):
        if len(observed_chain) < 3:
            return None
        first_m = re.match(r'\[d=\d+\]\s+(\w+)\s+->\s+(\w+)\(([^)]*)\)', observed_chain[0])
        last_m  = re.match(r'\[d=\d+\]\s+(\w+)\s+->\s+(\w+)\(([^)]*)\)', observed_chain[-1])
        if not first_m or not last_m:
            return None
        mid_rule_id = first_m.group(1)
        final_pred  = last_m.group(2)
        final_args  = tuple(a.strip() for a in last_m.group(3).split(",") if a.strip())
        with self._rules_lock:
            src_rule = next((r for r in self._rules if r.rule_id == mid_rule_id), None)
        if src_rule is None:
            return None
        return DynamicRule(
            rule_id=f"shortcut_{mid_rule_id}_to_{final_pred}_{uuid.uuid4().hex[:6]}",
            antecedents=[(p, list(a), n) for p, a, n in src_rule.antecedents],
            consequent=(final_pred, final_args),
            weight=0.80, domain="dynamic_shortcut",
            generation_source=f"chain_compression:{mid_rule_id}→{final_pred}",
        )

    def detect_rule_gaps(self, fact_set, desired_conclusion):
        with self._rules_lock:
            rules = [r for r in self._rules if r.consequent[0] == desired_conclusion]
        gaps = []
        for rule in rules:
            missing = [f"{ap}({','.join(aa)})" for ap, aa, an in rule.antecedents
                       if not any(f.predicate == ap and f.negated == an for f in fact_set)]
            if missing:
                gaps.append(f"Rule '{rule.rule_id}' needs: {', '.join(missing)}")
        return gaps if gaps else [f"No rules found that conclude '{desired_conclusion}'"]

    def self_critique_result(self, result):
        issues = []
        if result.confidence < 0.5:
            issues.append({"severity":"warning","msg":"Low average confidence in conclusions"})
        if result.contradictions:
            issues.append({"severity":"error","msg":f"{len(result.contradictions)} contradiction(s) detected",
                           "details":[a.to_str() for a,_ in result.contradictions[:5]]})
        if len(result.conclusions) == 0 and len(result.abductive_hypotheses) > 0:
            issues.append({"severity":"info","msg":"No conclusions; abductive hypotheses indicate missing facts",
                           "hypotheses":[h.to_str() for h in result.abductive_hypotheses[:5]]})
        sec = [c for c in result.conclusions if "vulnerability" in c.predicate or "risk" in c.predicate]
        if sec:
            issues.append({"severity":"critical","msg":"Security concerns identified","items":[c.to_str() for c in sec]})
        return {"issues":issues,"issue_count":len(issues),"quality_score":round(max(0.0,1.0-len(issues)*0.15),4),
                "depth_used":len(result.reasoning_chain),"conclusions_count":len(result.conclusions),
                "hypotheses_count":len(result.abductive_hypotheses)}

    def get_rule_stats(self):
        with self._rules_lock:
            return [{"rule_id":r.rule_id,"domain":r.domain,"weight":r.weight,
                     "fire_count":self._rule_fire_counts.get(r.rule_id,0),
                     "antecedent_count":len(r.antecedents),
                     "is_dynamic":any(d.rule_id==r.rule_id for d in self._dynamic_rules)}
                    for r in self._rules]

    def _abduce(self, fact_set, rules):
        hypotheses = []
        for rule in rules:
            unsatisfied = [(ap,aa,an) for ap,aa,an in rule.antecedents
                           if not any(f.predicate==ap and f.negated==an for f in fact_set)]
            if len(unsatisfied) == 1:
                ap,aa,an = unsatisfied[0]
                hypotheses.append(LogicFact(predicate=ap,args=aa,confidence=rule.weight*0.5,
                                            source=f"abductive:{rule.rule_id}",negated=an))
            elif len(unsatisfied) == 2:
                for ap,aa,an in unsatisfied:
                    hypotheses.append(LogicFact(predicate=ap,args=aa,confidence=rule.weight*0.3,
                                                source=f"abductive_multi:{rule.rule_id}",negated=an))
        seen = set()
        unique = []
        for h in hypotheses:
            k = (h.predicate, h.args, h.negated)
            if k not in seen:
                seen.add(k)
                unique.append(h)
        return unique[:20]


ReasoningEngine = AdvancedReasoningEngine


# ============================================================================
# SELF-MODIFICATION ENGINE
# ============================================================================

class SelfModificationEngine:
    def __init__(self, reasoner):
        self._reasoner = reasoner
        self._lock = threading.RLock()
        self._modification_log = []
        self._pending_proposals = []
        self._rejected = []

    def propose_from_chain(self, result):
        chain = list(result.reasoning_chain)
        if len(chain) < 4:
            return None
        candidate = self._reasoner.generate_shortcut_rule(chain)
        if candidate:
            with self._lock:
                self._pending_proposals.append(candidate)
        return candidate

    def propose_from_cooccurrence(self, fact_sets, min_support=0.6):
        if not fact_sets:
            return []
        pred_pairs = Counter()
        for fs in fact_sets:
            preds = [f.predicate for f in fs if not f.negated]
            for a, b in itertools.combinations(sorted(set(preds)), 2):
                pred_pairs[(a,b)] += 1
        n = len(fact_sets)
        threshold = int(n * min_support)
        candidates = []
        for (a,b), cnt in pred_pairs.items():
            if cnt >= threshold:
                candidates.append(DynamicRule(
                    rule_id=f"cooccur_{a}_{b}_{uuid.uuid4().hex[:6]}",
                    antecedents=[(a,("X",),False)],
                    consequent=(f"likely_{b}",("X",)),
                    weight=round(cnt/n,3), domain="dynamic_cooccurrence",
                    generation_source=f"cooccurrence:support={cnt}/{n}",
                ))
        with self._lock:
            self._pending_proposals.extend(candidates)
        return candidates

    def validate_and_apply(self, drule, test_facts):
        if not drule.antecedents:
            return False, "Rule has no antecedents"
        if not drule.consequent or not drule.consequent[0]:
            return False, "Rule has no consequent"
        if drule.weight <= 0 or drule.weight > 1.0:
            return False, f"Invalid weight: {drule.weight}"
        test_set = set(test_facts)
        logic_rule = drule.to_logic_rule()
        bindings = logic_rule.matches_antecedents(test_set, {})
        if not bindings:
            drule.test_pass_rate = 0.0
            reason = "Rule does not fire on test facts"
            with self._lock:
                self._rejected.append((drule, reason))
            return False, reason
        cpred = drule.consequent[0]
        if any(f.predicate == cpred and f.negated for f in test_set):
            reason = f"Consequent '{cpred}' is negated in test facts"
            with self._lock:
                self._rejected.append((drule, reason))
            return False, reason
        with self._reasoner._rules_lock:
            existing = [r for r in self._reasoner._rules if r.consequent[0] == cpred and r.weight >= 0.9]
        if len(existing) >= 3:
            reason = f"Already have {len(existing)} strong rules for '{cpred}'"
            with self._lock:
                self._rejected.append((drule, reason))
            return False, reason
        drule.validated = True
        drule.test_pass_rate = 1.0
        self._reasoner.add_dynamic_rule(drule)
        with self._lock:
            self._modification_log.append({"action":"rule_applied","rule_id":drule.rule_id,
                                           "domain":drule.domain,"weight":drule.weight,
                                           "source":drule.generation_source,"timestamp":time.time()})
        log.info(f"[SelfModification] Applied rule: {drule.rule_id}")
        return True, "Rule validated and applied"

    def process_pending(self, test_facts=None):
        with self._lock:
            pending = list(self._pending_proposals)
            self._pending_proposals.clear()
        applied, rejected = [], []
        tf = test_facts or []
        for drule in pending:
            ok, reason = self.validate_and_apply(drule, tf)
            (applied if ok else rejected).append({"rule_id":drule.rule_id,"reason":reason})
        return {"processed":len(pending),"applied":applied,"rejected":rejected}

    def get_audit_log(self, limit=50):
        with self._lock:
            return list(reversed(self._modification_log[-limit:]))

    def stats(self):
        with self._lock:
            return {"total_applied":len(self._modification_log),
                    "pending_proposals":len(self._pending_proposals),
                    "rejected":len(self._rejected)}


# ============================================================================
# KNOWLEDGE EXPANSION ENGINE
# ============================================================================

class KnowledgeExpansionEngine:
    def __init__(self, reasoner, self_modifier):
        self._reasoner = reasoner
        self._modifier = self_modifier
        self._lock = threading.RLock()
        self._learned_patterns = deque(maxlen=500)
        self._synthesis_history = deque(maxlen=200)
        self._expansion_log = []

    def learn_from_synthesis_result(self, synthesis_result):
        learned = []
        module_name  = synthesis_result.get("module_name","unknown")
        module_type  = synthesis_result.get("module_type","module")
        patterns     = synthesis_result.get("design_patterns",[])
        quality      = synthesis_result.get("quality_score",0.0)
        with self._lock:
            self._synthesis_history.append({"module":module_name,"type":module_type,"patterns":patterns,"quality":quality,"ts":time.time()})
        if quality > 0.7:
            for pat in patterns:
                self._learned_patterns.append(f"pattern_{pat.lower().replace(' ','_')}_in_{module_type}")
                learned.append(f"High-quality {module_type} used {pat}")
        if len(self._synthesis_history) >= 5:
            recent = list(self._synthesis_history)[-10:]
            all_pattern_sets = []
            for entry in recent:
                if entry["quality"] > 0.6:
                    facts = {LogicFact(predicate="has_pattern",args=(entry["type"],p.lower().replace(" ","_")),source="learned")
                             for p in entry["patterns"]}
                    if facts:
                        all_pattern_sets.append(facts)
            if len(all_pattern_sets) >= 3:
                candidates = self._modifier.propose_from_cooccurrence(all_pattern_sets)
                if candidates:
                    learned.append(f"Proposed {len(candidates)} cooccurrence rule(s)")
        result = {"module":module_name,"learned_count":len(learned),"learned":learned,"total_patterns_seen":len(self._learned_patterns)}
        with self._lock:
            self._expansion_log.append({**result,"ts":time.time()})
        return result

    def learn_from_reasoning_session(self, result):
        if len(result.reasoning_chain) < 4:
            return None
        candidate = self._modifier.propose_from_chain(result)
        if candidate:
            with self._lock:
                self._expansion_log.append({"action":"chain_shortcut_proposed","rule_id":candidate.rule_id,
                                            "chain_length":len(result.reasoning_chain),"ts":time.time()})
        return candidate

    def get_pattern_frequency(self):
        with self._lock:
            return dict(Counter(self._learned_patterns))

    def stats(self):
        with self._lock:
            return {"learned_patterns":len(self._learned_patterns),
                    "synthesis_history_entries":len(self._synthesis_history),
                    "expansion_events":len(self._expansion_log),
                    "top_patterns":dict(Counter(self._learned_patterns).most_common(10))}

# ============================================================================
# UNIVERSAL FORMAT CONVERTER
# ============================================================================

class UniversalConverter:
    TRANSFORM_GRAPH = {
        ("json","yaml"):(0.10,0.99,"_json_to_yaml"),("yaml","json"):(0.10,0.99,"_yaml_to_json"),
        ("json","toml"):(0.20,0.95,"_json_to_toml"),("toml","json"):(0.20,0.95,"_toml_to_json"),
        ("json","csv"):(0.30,0.85,"_json_to_csv"),("csv","json"):(0.20,0.90,"_csv_to_json"),
        ("json","xml"):(0.30,0.90,"_json_to_xml"),("xml","json"):(0.40,0.85,"_xml_to_json"),
        ("csv","tsv"):(0.05,1.00,"_csv_to_tsv"),("tsv","csv"):(0.05,1.00,"_tsv_to_csv"),
        ("yaml","toml"):(0.30,0.92,"_yaml_to_toml"),("toml","yaml"):(0.30,0.92,"_toml_to_yaml"),
        ("xml","yaml"):(0.50,0.82,"_xml_to_yaml"),("yaml","xml"):(0.50,0.82,"_yaml_to_xml"),
        ("python","json"):(0.40,0.80,"_python_to_json"),("json","python"):(0.40,0.80,"_json_to_python"),
        ("python","kotlin"):(0.90,0.65,"_python_to_kotlin"),("python","javascript"):(0.70,0.72,"_python_to_javascript"),
        ("javascript","typescript"):(0.30,0.90,"_javascript_to_typescript"),("typescript","javascript"):(0.20,0.95,"_typescript_to_javascript"),
        ("java","kotlin"):(0.50,0.85,"_java_to_kotlin"),("kotlin","java"):(0.60,0.80,"_kotlin_to_java"),
        ("c","cpp"):(0.20,0.92,"_c_to_cpp"),("cpp","c"):(0.50,0.70,"_cpp_to_c"),
        ("shell","python"):(0.80,0.70,"_shell_to_python"),("python","shell"):(0.70,0.72,"_python_to_shell"),
        ("python","pseudo"):(0.30,0.88,"_python_to_pseudocode"),("java","pseudo"):(0.40,0.85,"_java_to_pseudocode"),
        ("kotlin","pseudo"):(0.40,0.85,"_kotlin_to_pseudocode"),("smali","pseudo"):(0.50,0.80,"_smali_to_pseudocode"),
        ("smali","java"):(0.80,0.72,"_smali_to_java"),("dex","smali"):(0.70,0.88,"_dex_to_smali"),
        ("python","markdown"):(0.40,0.82,"_code_to_markdown"),("java","markdown"):(0.40,0.82,"_code_to_markdown"),
        ("kotlin","markdown"):(0.40,0.82,"_code_to_markdown"),("javascript","markdown"):(0.40,0.82,"_code_to_markdown"),
        ("sql","markdown"):(0.30,0.88,"_sql_to_markdown"),("binary","hex"):(0.10,1.00,"_binary_to_hex"),
        ("binary","base64"):(0.10,1.00,"_binary_to_base64"),("binary","json"):(0.50,0.70,"_binary_to_json"),
        ("hex","binary"):(0.10,1.00,"_hex_to_binary"),("base64","binary"):(0.10,1.00,"_base64_to_binary"),
        ("zip","tar"):(0.60,0.95,"_zip_to_tar"),("tar","zip"):(0.60,0.95,"_tar_to_zip"),
        ("zip","json"):(0.40,0.88,"_archive_to_json_manifest"),("tar","json"):(0.40,0.88,"_archive_to_json_manifest"),
        ("pdf","text"):(0.50,0.80,"_pdf_to_text"),("text","markdown"):(0.20,0.90,"_text_to_markdown"),
        ("markdown","html"):(0.30,0.95,"_markdown_to_html"),("html","text"):(0.20,0.92,"_html_to_text"),
        ("html","markdown"):(0.40,0.88,"_html_to_markdown"),("sql","json"):(0.50,0.80,"_sql_schema_to_json"),
        ("json","sql"):(0.50,0.78,"_json_to_sql"),("ini","json"):(0.20,0.92,"_ini_to_json"),
        ("env","json"):(0.20,0.95,"_env_to_json"),("json","ini"):(0.30,0.88,"_json_to_ini"),
        ("json","env"):(0.30,0.90,"_json_to_env"),("text","json"):(0.60,0.65,"_text_to_json"),
        ("json","text"):(0.20,0.95,"_json_to_text"),("rust","pseudo"):(0.40,0.82,"_rust_to_pseudocode"),
        ("go","pseudo"):(0.40,0.82,"_go_to_pseudocode"),("cpp","pseudo"):(0.40,0.82,"_cpp_to_pseudocode"),
    }

    def __init__(self):
        self._adj = defaultdict(list)
        for (src,dst),(cost,fidelity,fn) in self.TRANSFORM_GRAPH.items():
            self._adj[src].append((dst,cost,fidelity,fn))

    def find_path(self, source, target):
        source, target = source.lower().lstrip("."), target.lower().lstrip(".")
        if source == target:
            return ConversionPath(source,target,(),0.0,1.0)
        heap = [(0.0,source,[],1.0)]
        visited = {}
        while heap:
            cost,node,path,fidelity = heapq.heappop(heap)
            if node in visited and visited[node] <= cost:
                continue
            visited[node] = cost
            if node == target:
                return ConversionPath(source,target,tuple(path),round(cost,4),round(fidelity,4))
            for neighbor,ec,ef,fn in self._adj.get(node,[]):
                nc = cost+ec
                nf = fidelity*ef
                np = path+[(node,neighbor,fn)]
                if neighbor not in visited or visited.get(neighbor,9999) > nc:
                    heapq.heappush(heap,(nc,neighbor,np,nf))
        return None

    def convert(self, content, source_fmt, target_fmt, options=None):
        options = options or {}
        source_fmt = source_fmt.lower().lstrip(".")
        target_fmt = target_fmt.lower().lstrip(".")
        path = self.find_path(source_fmt, target_fmt)
        if path is None:
            return {"success":False,"error":f"No conversion path: {source_fmt} -> {target_fmt}",
                    "available_targets":self._reachable_from(source_fmt)}
        current = content
        steps_executed = []
        warnings = []
        for from_fmt,to_fmt,fn_name in path.steps:
            fn = getattr(self,fn_name,None)
            if fn is None:
                warnings.append(f"Transformer {fn_name} missing; passthrough")
                steps_executed.append({"step":f"{from_fmt}->{to_fmt}","status":"passthrough"})
                continue
            try:
                current = fn(current,options)
                steps_executed.append({"step":f"{from_fmt}->{to_fmt}","status":"ok","fn":fn_name})
            except Exception as e:
                return {"success":False,"error":f"{fn_name} failed: {e}",
                        "partial_result":str(current)[:500] if current else None,"steps_executed":steps_executed}
        return {"success":True,"result":current if isinstance(current,str) else str(current),
                "source_format":source_fmt,"target_format":target_fmt,
                "steps_executed":steps_executed,"estimated_fidelity":path.estimated_fidelity,"warnings":warnings}

    def _reachable_from(self, source):
        visited = set()
        queue = deque([source])
        while queue:
            node = queue.popleft()
            if node in visited:
                continue
            visited.add(node)
            for neighbor,_,_,_ in self._adj.get(node,[]):
                queue.append(neighbor)
        visited.discard(source)
        return sorted(visited)

    # ---- All converter implementations ----------------------------------------

    def _json_to_yaml(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode())
        return self._dict_to_yaml(data,0)

    def _dict_to_yaml(self,obj,indent):
        pad="  "*indent
        lines=[]
        if isinstance(obj,dict):
            for k,v in obj.items():
                if isinstance(v,(dict,list)):
                    lines.append(f"{pad}{k}:")
                    lines.append(self._dict_to_yaml(v,indent+1))
                elif isinstance(v,str) and any(ch in v for ch in ':#{}\n'):
                    lines.append(f'{pad}{k}: "{v.replace(chr(92),chr(92)*2).replace(chr(34),chr(92)+chr(34))}"')
                elif v is None:
                    lines.append(f"{pad}{k}: null")
                elif isinstance(v,bool):
                    lines.append(f"{pad}{k}: {'true' if v else 'false'}")
                else:
                    lines.append(f"{pad}{k}: {v}")
        elif isinstance(obj,list):
            for item in obj:
                if isinstance(item,(dict,list)):
                    lines.append(f"{pad}-")
                    lines.append(self._dict_to_yaml(item,indent+1))
                else:
                    lines.append(f"{pad}- {item}")
        else:
            lines.append(f"{pad}{obj}")
        return "\n".join(lines)

    def _yaml_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        data=self._parse_yaml_simple(text)
        return json.dumps(data,indent=2,default=str)

    def _parse_yaml_simple(self,text):
        lines=[l for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
        if not lines:
            return {}
        def get_ind(l): return len(l)-len(l.lstrip())
        def parse_val(s):
            s=s.strip()
            if s in ("null","~",""): return None
            if s in ("true","yes","on"): return True
            if s in ("false","no","off"): return False
            if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")): return s[1:-1]
            try: return float(s) if "." in s else int(s)
            except: return s
        def parse_block(idx,base_ind):
            result={}; result_list=[]; is_list=lines[idx].lstrip().startswith("- ") if idx<len(lines) else False
            while idx<len(lines):
                line=lines[idx]; ind=get_ind(line)
                if ind<base_ind: break
                stripped=line.strip()
                if stripped.startswith("- "):
                    val_str=stripped[2:]
                    if ":" in val_str:
                        sub_obj,idx=parse_list_item(idx,ind)
                        result_list.append(sub_obj)
                    else:
                        result_list.append(parse_val(val_str)); idx+=1
                elif ":" in stripped:
                    ci=stripped.index(":"); key=stripped[:ci].strip(); val_str=stripped[ci+1:].strip()
                    if val_str:
                        result[key]=parse_val(val_str); idx+=1
                    else:
                        sub,idx=parse_nested(idx,ind); result[key]=sub
                else:
                    idx+=1
            return (result_list if is_list else result),idx
        def parse_list_item(idx,base_ind):
            sub={}; idx+=1
            while idx<len(lines):
                line=lines[idx]; ind=get_ind(line)
                if ind<=base_ind: break
                stripped=line.strip()
                if ":" in stripped:
                    ci=stripped.index(":"); key=stripped[:ci].strip(); val_str=stripped[ci+1:].strip()
                    if val_str: sub[key]=parse_val(val_str)
                    else:
                        nested,idx=parse_nested(idx,ind); sub[key]=nested; continue
                idx+=1
            return sub,idx
        def parse_nested(idx,base_ind):
            idx+=1
            if idx>=len(lines): return None,idx
            ni=get_ind(lines[idx])
            if ni<=base_ind: return None,idx
            if lines[idx].strip().startswith("- "):
                sub_list=[]; 
                while idx<len(lines):
                    line=lines[idx]; ind=get_ind(line)
                    if ind<=base_ind: break
                    stripped=line.strip()
                    if stripped.startswith("- "):
                        val_str=stripped[2:]
                        if ":" in val_str:
                            so,idx=parse_list_item(idx,ind); sub_list.append(so)
                        else:
                            sub_list.append(parse_val(val_str)); idx+=1
                    else:
                        idx+=1
                return sub_list,idx
            else:
                sub_dict={}
                while idx<len(lines):
                    line=lines[idx]; ind=get_ind(line)
                    if ind<=base_ind: break
                    stripped=line.strip()
                    if ":" in stripped:
                        ci=stripped.index(":"); key=stripped[:ci].strip(); val_str=stripped[ci+1:].strip()
                        if val_str:
                            sub_dict[key]=parse_val(val_str); idx+=1
                        else:
                            nested,idx=parse_nested(idx,ind); sub_dict[key]=nested
                    else:
                        idx+=1
                return sub_dict,idx
        try:
            data,_=parse_block(0,0)
            return data
        except:
            return {}

    def _json_to_toml(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode())
        return self._dict_to_toml(data,"")

    def _dict_to_toml(self,obj,prefix):
        if not isinstance(obj,dict): return str(obj)
        lines=[]; tables=[]
        for k,v in obj.items():
            fk=f"{prefix}.{k}" if prefix else k
            if isinstance(v,dict): tables.append((fk,v))
            elif isinstance(v,list) and v and all(isinstance(i,dict) for i in v):
                for item in v:
                    lines.append(f"\n[[{fk}]]")
                    for ik,iv in item.items():
                        if not isinstance(iv,(dict,list)): lines.append(f"{ik} = {self._toml_scalar(iv)}")
            elif isinstance(v,list): lines.append(f"{k} = [{', '.join(self._toml_scalar(i) for i in v)}]")
            else: lines.append(f"{k} = {self._toml_scalar(v)}")
        for tname,tdata in tables:
            lines.append(f"\n[{tname}]")
            for tk,tv in tdata.items():
                if not isinstance(tv,(dict,list)): lines.append(f"{tk} = {self._toml_scalar(tv)}")
        return "\n".join(lines)

    def _toml_scalar(self,v):
        if isinstance(v,bool): return "true" if v else "false"
        if isinstance(v,str): return f'"{v.replace(chr(92),chr(92)*2).replace(chr(34),chr(92)+chr(34)).replace(chr(10),"\\n")}"'
        if v is None: return '""'
        return str(v)

    def _toml_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        result={}; current_table=result
        for line in text.splitlines():
            line=line.strip()
            if not line or line.startswith("#"): continue
            if line.startswith("[[") and line.endswith("]]"):
                tn=line[2:-2]; keys=tn.split("."); obj=result
                for k in keys[:-1]:
                    if k not in obj: obj[k]={}
                    obj=obj[k]
                if keys[-1] not in obj: obj[keys[-1]]=[]
                ne={}; obj[keys[-1]].append(ne); current_table=ne
            elif line.startswith("[") and line.endswith("]"):
                tn=line[1:-1]; keys=tn.split("."); current_table=result
                for k in keys:
                    if k not in current_table: current_table[k]={}
                    current_table=current_table[k]
            elif "=" in line:
                k,_,v=line.partition("="); k=k.strip(); v=v.strip()
                if v.startswith('"') and v.endswith('"'): current_table[k]=v[1:-1].replace('\\"','"').replace('\\n','\n')
                elif v.startswith("'") and v.endswith("'"): current_table[k]=v[1:-1]
                elif v.lower()=="true": current_table[k]=True
                elif v.lower()=="false": current_table[k]=False
                elif v.startswith("[") and v.endswith("]"):
                    current_table[k]=[i.strip().strip("\"'") for i in v[1:-1].split(",") if i.strip()]
                else:
                    try: current_table[k]=float(v) if "." in v else int(v)
                    except: current_table[k]=v
        return json.dumps(result,indent=2,default=str)

    def _yaml_to_toml(self,c,o): return self._json_to_toml(self._yaml_to_json(c,o),o)
    def _toml_to_yaml(self,c,o): return self._json_to_yaml(self._toml_to_json(c,o),o)
    def _xml_to_yaml(self,c,o):  return self._json_to_yaml(self._xml_to_json(c,o),o)
    def _yaml_to_xml(self,c,o):  return self._json_to_xml(self._yaml_to_json(c,o),o)

    def _json_to_csv(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode())
        if isinstance(data,dict): data=[data]
        if not isinstance(data,list) or not data: return ""
        flat=[{k:json.dumps(v) if isinstance(v,(dict,list)) else str(v) for k,v in row.items()} for row in data if isinstance(row,dict)]
        if not flat: return ""
        headers=list(flat[0].keys())
        out=io.StringIO()
        csv.DictWriter(out,fieldnames=headers,extrasaction="ignore",quoting=csv.QUOTE_ALL).writeheader()
        csv.DictWriter(out,fieldnames=headers,extrasaction="ignore",quoting=csv.QUOTE_ALL).writerows(flat)
        return out.getvalue()

    def _csv_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        rows=[]
        for row in csv.DictReader(io.StringIO(text)):
            for k,v in row.items():
                try:
                    if v.lower() in ("true","false"): row[k]=v.lower()=="true"
                    elif v.lower() in ("null","none",""): row[k]=None
                    else:
                        try: row[k]=int(v)
                        except:
                            try: row[k]=float(v)
                            except: pass
                except: pass
            rows.append(row)
        return json.dumps(rows,indent=2,default=str)

    def _csv_to_tsv(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        out=io.StringIO()
        csv.writer(out,delimiter='\t').writerows(csv.reader(io.StringIO(text)))
        return out.getvalue()

    def _tsv_to_csv(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        out=io.StringIO()
        csv.writer(out).writerows(csv.reader(io.StringIO(text),delimiter='\t'))
        return out.getvalue()

    def _json_to_xml(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode())
        root=o.get("root_tag","root")
        return f'<?xml version="1.0" encoding="UTF-8"?>\n<{root}>\n{self._dict_to_xml_inner(data,1)}\n</{root}>'

    def _dict_to_xml_inner(self,obj,depth):
        pad="  "*depth; lines=[]
        if isinstance(obj,dict):
            for k,v in obj.items():
                sk=re.sub(r'[^a-zA-Z0-9_\-.]','_',str(k))
                if sk and sk[0].isdigit(): sk=f"_{sk}"
                if isinstance(v,(dict,list)):
                    lines.append(f"{pad}<{sk}>"); lines.append(self._dict_to_xml_inner(v,depth+1)); lines.append(f"{pad}</{sk}>")
                elif v is None: lines.append(f'{pad}<{sk} xsi:nil="true"/>')
                else:
                    esc=str(v).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                    lines.append(f"{pad}<{sk}>{esc}</{sk}>")
        elif isinstance(obj,list):
            for item in obj:
                lines.append(f"{pad}<item>"); lines.append(self._dict_to_xml_inner(item,depth+1)); lines.append(f"{pad}</item>")
        else:
            lines.append(f"{pad}{str(obj).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')}")
        return "\n".join(lines)

    def _xml_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        text=re.sub(r'<\?xml[^?]*\?>','',text)
        text=re.sub(r'<!--.*?-->','',text,flags=re.DOTALL)
        try:
            root=ET.fromstring(text.strip())
            def elem_to_dict(e):
                result={}
                if e.attrib: result["@attributes"]=dict(e.attrib)
                children=defaultdict(list)
                for child in e: children[child.tag].append(elem_to_dict(child))
                for tag,items in children.items(): result[tag]=items[0] if len(items)==1 else items
                if e.text and e.text.strip(): result["#text"]=e.text.strip()
                return result if result else (e.text or None)
            return json.dumps(elem_to_dict(root),indent=2,default=str)
        except:
            return json.dumps({"_raw":text[:500],"_error":"XML parse failed"},indent=2)

    def _python_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        extracted={}
        try:
            tree=ast.parse(text)
            for node in ast.walk(tree):
                if isinstance(node,ast.Assign):
                    for t in node.targets:
                        if isinstance(t,ast.Name):
                            try: extracted[t.id]=ast.literal_eval(node.value)
                            except: pass
                elif isinstance(node,ast.FunctionDef):
                    extracted[f"_function_{node.name}"]={"args":[a.arg for a in node.args.args],"lines":(node.end_lineno or node.lineno)-node.lineno}
                elif isinstance(node,ast.ClassDef):
                    extracted[f"_class_{node.name}"]={"methods":[n.name for n in node.body if isinstance(n,ast.FunctionDef)],"lines":(node.end_lineno or node.lineno)-node.lineno}
        except SyntaxError: pass
        return json.dumps(extracted,indent=2,default=str)

    def _json_to_python(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode())
        lines=["# Auto-generated by Zeus Logic Engine\n"]
        if isinstance(data,dict):
            for k,v in data.items():
                sk=re.sub(r'[^a-zA-Z0-9_]','_',str(k))
                if sk and sk[0].isdigit(): sk=f"_{sk}"
                lines.append(f"{sk} = {repr(v)}")
        else: lines.append(f"data = {repr(data)}")
        return "\n".join(lines)

    def _python_to_kotlin(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\bdef\s+(\w+)\s*\(([^)]*)\)\s*:',r'fun \1(\2): Any {',t)
        t=re.sub(r'\bclass\s+(\w+)\s*(\([^)]*\))?\s*:',r'class \1\2 {',t)
        t=re.sub(r'\bif\s+(.+?):',r'if (\1) {',t); t=re.sub(r'\belif\s+(.+?):',r'} else if (\1) {',t)
        t=re.sub(r'\belse\s*:',r'} else {',t); t=re.sub(r'\bfor\s+(\w+)\s+in\s+(.+?):',r'for (\1 in \2) {',t)
        t=re.sub(r'\bwhile\s+(.+?):',r'while (\1) {',t); t=re.sub(r'\bTrue\b','true',t)
        t=re.sub(r'\bFalse\b','false',t); t=re.sub(r'\bNone\b','null',t)
        t=re.sub(r'\bprint\(','println(',t); t=re.sub(r'\blen\((\w+)\)',r'\1.size',t)
        t=re.sub(r'#\s*(.*)',r'// \1',t)
        return "// Converted from Python by Zeus Logic Engine\n"+t

    def _python_to_javascript(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\bdef\s+(\w+)\s*\(([^)]*)\)\s*:',r'function \1(\2) {',t)
        t=re.sub(r'\bclass\s+(\w+)\s*:',r'class \1 {',t)
        t=re.sub(r'\bif\s+(.+?):',r'if (\1) {',t); t=re.sub(r'\belif\s+(.+?):',r'} else if (\1) {',t)
        t=re.sub(r'\belse\s*:',r'} else {',t)
        t=re.sub(r'\bfor\s+(\w+)\s+in\s+range\((\d+)\):',r'for (let \1 = 0; \1 < \2; \1++) {',t)
        t=re.sub(r'\bfor\s+(\w+)\s+in\s+(.+?):',r'for (const \1 of \2) {',t)
        t=re.sub(r'\bwhile\s+(.+?):',r'while (\1) {',t); t=re.sub(r'\bTrue\b','true',t)
        t=re.sub(r'\bFalse\b','false',t); t=re.sub(r'\bNone\b','null',t)
        t=re.sub(r'\bprint\(','console.log(',t); t=re.sub(r'\blen\((\w+)\)',r'\1.length',t)
        t=re.sub(r'\bself\.','this.',t); t=re.sub(r'#\s*(.*)',r'// \1',t)
        return "// Converted from Python by Zeus Logic Engine\n"+t

    def _annotate_ts_params(self,params):
        if not params.strip(): return params
        return ", ".join(f"{p.strip()}: any" if p.strip() and ":" not in p and "=" not in p else p.strip() for p in params.split(","))

    def _javascript_to_typescript(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\bfunction\s+(\w+)\s*\(([^)]*)\)',lambda m:f"function {m.group(1)}({self._annotate_ts_params(m.group(2))}): any",t)
        t=re.sub(r'const\s+(\w+)\s*=\s*\(([^)]*)\)\s*=>',lambda m:f"const {m.group(1)} = ({self._annotate_ts_params(m.group(2))}): any =>",t)
        t=re.sub(r'\bfunction\s+\*','async function*',t)
        return t

    def _typescript_to_javascript(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'(\w+)\s*:\s*[A-Za-z<>\[\]|&]+(?=\s*[,)=])',r'\1',t)
        t=re.sub(r'\)\s*:\s*[A-Za-z<>\[\]|&]+(?=\s*[\{=])',')',t)
        t=re.sub(r'\binterface\s+\w+\s*\{[^}]*\}','',t,flags=re.DOTALL)
        t=re.sub(r'\btype\s+\w+\s*=\s*[^;\n]+;?','',t)
        t=re.sub(r'<[A-Z]\w*(?:,\s*[A-Z]\w*)*>','',t)
        t=re.sub(r'as\s+\w+(?:\[\])?(?=\s*[,;)\]])','',t)
        return t

    def _java_to_kotlin(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\bpublic\s+(?:static\s+)?class\s+(\w+)',r'class \1',t)
        t=re.sub(r'\bprivate\s+final\s+(\w+)\s+(\w+)\s*;',r'val \2: \1',t)
        t=re.sub(r'\bprivate\s+(\w+)\s+(\w+)\s*;',r'var \2: \1',t)
        t=re.sub(r'\bpublic\s+void\s+(\w+)\s*\(',r'fun \1(',t)
        t=re.sub(r'\bpublic\s+(\w+)\s+(\w+)\s*\(([^)]*)\)',r'fun \2(\3): \1',t)
        t=re.sub(r'\bSystem\.out\.println\(','println(',t); t=re.sub(r'\bSystem\.out\.print\(','print(',t)
        t=re.sub(r'\bnew\s+ArrayList<[^>]*>\(\)','mutableListOf()',t)
        t=re.sub(r'\bnew\s+HashMap<[^>]*>\(\)','mutableMapOf()',t)
        for j,k in [(r'\bint\b','Int'),(r'\blong\b','Long'),(r'\bdouble\b','Double'),(r'\bfloat\b','Float'),
                    (r'\bboolean\b','Boolean'),(r'\bbyte\b','Byte'),(r'\bchar\b','Char'),(r'\bshort\b','Short'),(r'\bString\b','String')]:
            t=re.sub(j,k,t)
        return "// Converted from Java by Zeus Logic Engine\n"+t

    def _kotlin_to_java(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\bfun\s+(\w+)\s*\(([^)]*)\)\s*:\s*(\w+)',r'public \3 \1(\2)',t)
        t=re.sub(r'\bfun\s+(\w+)\s*\(([^)]*)\)',r'public void \1(\2)',t)
        t=re.sub(r'\bval\s+(\w+)\s*:\s*(\w+)',r'private final \2 \1',t)
        t=re.sub(r'\bvar\s+(\w+)\s*:\s*(\w+)',r'private \2 \1',t)
        t=re.sub(r'\bprintln\(','System.out.println(',t)
        for k,j in [(r'\bInt\b','int'),(r'\bLong\b','long'),(r'\bDouble\b','double'),(r'\bFloat\b','float'),
                    (r'\bBoolean\b','boolean'),(r'\bByte\b','byte'),(r'\bChar\b','char'),(r'\bShort\b','short')]:
            t=re.sub(k,j,t)
        return "// Converted from Kotlin by Zeus Logic Engine\n"+t

    def _c_to_cpp(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'#include\s*<stdio\.h>','#include <iostream>',t)
        t=re.sub(r'printf\s*\("([^"]+)\\n"\)',r'std::cout << "\1" << std::endl',t)
        t=re.sub(r'\bmalloc\(','std::malloc(',t); t=re.sub(r'\bfree\((\w+)\)',r'delete \1',t)
        t=re.sub(r'\bstruct\s+(\w+)\s*\{',r'class \1 {',t)
        return "// Converted from C by Zeus Logic Engine\n#include <iostream>\n"+t

    def _cpp_to_c(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'#include\s*<iostream>','#include <stdio.h>\n#include <stdlib.h>',t)
        t=re.sub(r'std::cout\s*<<\s*(.+?)\s*<<\s*std::endl',r'printf("%s\n", \1)',t)
        t=re.sub(r'std::string','char*',t); t=re.sub(r'\bstd::','',t)
        t=re.sub(r'\bclass\s+(\w+)\s*\{',r'struct \1 {',t)
        return "/* Converted from C++ by Zeus Logic Engine */\n"+t

    def _python_to_shell(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        lines=["#!/bin/bash","# Converted from Python by Zeus Logic Engine",""]
        for line in text.splitlines():
            s=line.strip()
            if not s or s.startswith('#'): lines.append(f"# {s}")
            elif s.startswith("print("):
                m=re.search(r'print\(["\'](.+?)["\']\)',s)
                lines.append(f'echo "{m.group(1) if m else s}"')
            elif s.startswith("os.system("):
                m=re.search(r'os\.system\(["\'](.+?)["\']\)',s)
                lines.append(m.group(1) if m else f"# {s}")
            elif s.startswith("import "): lines.append(f"# {s}")
            else: lines.append(f"# {s}")
        return "\n".join(lines)

    def _shell_to_python(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        lines=["#!/usr/bin/env python3","# Converted from Shell by Zeus Logic Engine","import os, subprocess, sys\n"]
        for line in text.splitlines():
            s=line.strip()
            if not s or s.startswith('#'): lines.append(f"# {s}")
            elif s.startswith("echo "): lines.append(f'print("{s[5:].strip(chr(34)+chr(39))}")')
            elif s.startswith("export "):
                kv=s[7:]; k,_,v=kv.partition("="); lines.append(f'os.environ["{k.strip()}"] = "{v.strip()}"')
            elif "|" in s or s.startswith("$("): lines.append(f'subprocess.run("{s}", shell=True)')
            else: lines.append(f'os.system("{s}")')
        return "\n".join(lines)

    def _python_to_pseudocode(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        pseudo=["PROCEDURE (converted from Python)\n"]; indent_stack=[0]
        for line in text.splitlines():
            s=line.strip()
            if not s or s.startswith('#'): continue
            ci=len(line)-len(line.lstrip())
            while len(indent_stack)>1 and ci<indent_stack[-1]:
                indent_stack.pop(); pseudo.append("  "*(len(indent_stack)-1)+"END")
            pad="  "*(len(indent_stack)-1)
            s=re.sub(r'\bdef\s+(\w+)\s*\(([^)]*)\)\s*:',r'FUNCTION \1(\2):',s)
            s=re.sub(r'\bclass\s+(\w+)\s*:',r'CLASS \1:',s); s=re.sub(r'\bif\s+(.+):',r'IF \1 THEN',s)
            s=re.sub(r'\belif\s+(.+):',r'ELSE IF \1 THEN',s); s=re.sub(r'\belse\s*:','ELSE',s)
            s=re.sub(r'\bfor\s+(\w+)\s+in\s+(.+):',r'FOR \1 IN \2 DO',s)
            s=re.sub(r'\bwhile\s+(.+):',r'WHILE \1 DO',s); s=re.sub(r'\breturn\s+(.+)',r'RETURN \1',s)
            s=re.sub(r'\bprint\((.+)\)',r'OUTPUT \1',s); s=re.sub(r'\byield\s+(.+)',r'YIELD \1',s)
            pseudo.append(f"{pad}{s}")
            if any(s.endswith(x) for x in (":", "THEN", "DO")): indent_stack.append(ci+4)
        return "\n".join(pseudo)

    def _java_to_pseudocode(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\b(public|private|protected|static|final|synchronized|volatile)\s+','',t)
        t=re.sub(r'\b(int|String|boolean|double|float|long|char|void|Object)\s+','',t)
        t=re.sub(r'System\.out\.println\((.+?)\)',r'OUTPUT \1',t)
        t=re.sub(r'//.*','',t); t=re.sub(r'/\*.*?\*/','',t,flags=re.DOTALL)
        return "PROCEDURE (converted from Java)\n"+t.strip()

    def _kotlin_to_pseudocode(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\b(fun|val|var|data class|object|companion|sealed|enum)\s+','',t)
        t=re.sub(r':\s*\w+(?:\?|\[\])*\b','',t)
        t=re.sub(r'println\((.+?)\)',r'OUTPUT \1',t); t=re.sub(r'//.*','',t)
        return "PROCEDURE (converted from Kotlin)\n"+t.strip()

    def _rust_to_pseudocode(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\bfn\s+(\w+)\s*\(([^)]*)\)\s*(?:->\s*\w+)?\s*\{',r'FUNCTION \1(\2):',t)
        t=re.sub(r'\blet\s+mut\s+(\w+)',r'VAR \1',t); t=re.sub(r'\blet\s+(\w+)',r'CONST \1',t)
        t=re.sub(r'\bprintln!\(','OUTPUT(',t); t=re.sub(r'//.*','',t)
        return "PROCEDURE (converted from Rust)\n"+t.strip()

    def _go_to_pseudocode(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\bfunc\s+(\w+)\s*\(([^)]*)\)\s*(?:\w+)?\s*\{',r'FUNCTION \1(\2):',t)
        t=re.sub(r':=','=',t); t=re.sub(r'\bfmt\.Println\(','OUTPUT(',t)
        t=re.sub(r'\bgo\s+(\w+)\s*\(',r'SPAWN \1(',t); t=re.sub(r'//.*','',t)
        return "PROCEDURE (converted from Go)\n"+t.strip()

    def _cpp_to_pseudocode(self,c,o):
        t=c if isinstance(c,str) else c.decode()
        t=re.sub(r'\b(int|void|bool|double|float|string|char|auto|const|static)\s+(\w+)\s*\(([^)]*)\)\s*\{',r'FUNCTION \2(\3):',t)
        t=re.sub(r'std::cout\s*<<\s*(.+?)\s*(?:<<\s*std::endl)?;',r'OUTPUT \1',t)
        t=re.sub(r'//.*','',t); t=re.sub(r'/\*.*?\*/','',t,flags=re.DOTALL); t=re.sub(r'\bstd::','',t)
        return "PROCEDURE (converted from C++)\n"+t.strip()

    def _smali_to_pseudocode(self,c,o):
        text=c if isinstance(c,str) else c.decode(); lines=[]
        for line in text.splitlines():
            s=line.strip()
            if s.startswith(".class"): lines.append(f"CLASS {s.split('/')[-1].rstrip(';')}")
            elif s.startswith(".method"): lines.append(f"  FUNCTION {s.split()[-1].split('(')[0]}()")
            elif s.startswith("invoke-"):
                t=re.search(r'->(\w+)\(',s); lines.append(f"    CALL {t.group(1) if t else 'unknown'}()")
            elif s.startswith(("iput","sput")): lines.append("    SET field")
            elif s.startswith(("iget","sget")): lines.append("    GET field")
            elif s.startswith("return"): lines.append("    RETURN")
            elif s.startswith("if-"): lines.append("    IF condition THEN")
        return "\n".join(lines)

    def _smali_to_java(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        cm=re.search(r'\.class\s+(?:public\s+)?(?:\w+\s+)*L([\w/$]+);',text)
        cn=(cm.group(1).split("/")[-1].replace("$",".") if cm else "DecompiledClass")
        fields=[f"    {fm.group(1) or 'private'} {self._smali_type_to_java(fm.group(3).strip())} {fm.group(2)};"
                for fm in re.compile(r'\.field\s+(public|private|protected)?\s*(\w+):(.+)').finditer(text)]
        methods=[f"    {m.group(1) or 'public'} void {m.group(2)}() {{\n        // Decompiled from Smali\n    }}"
                 for m in re.compile(r'\.method\s+(public|private|protected|static)?\s*(\w+)\s*\(.*?\).*?\.end method',re.DOTALL).finditer(text)]
        return f"// Decompiled from Smali by Zeus\npublic class {cn} {{\n\n"+"\n".join(fields)+("\n\n" if fields else "")+"\n\n".join(methods)+"\n}\n"

    def _smali_type_to_java(self,t):
        m={"V":"void","Z":"boolean","B":"byte","S":"short","C":"char","I":"int","J":"long","F":"float","D":"double"}
        if t in m: return m[t]
        if t.startswith("L") and t.endswith(";"): return t[1:-1].replace("/",".")
        if t.startswith("["): return self._smali_type_to_java(t[1:])+"[]"
        return "Object"

    def _dex_to_smali(self,c,o):
        path=c if isinstance(c,str) else c.decode()
        out_dir=path+"_smali_out"; os.makedirs(out_dir,exist_ok=True)
        try:
            r=subprocess.run(["baksmali","d",path,"-o",out_dir],capture_output=True,text=True,timeout=30)
            if r.returncode==0: return f"Smali extracted to: {out_dir}\n{r.stdout}"
        except (FileNotFoundError,subprocess.TimeoutExpired): pass
        return f"[DEX->Smali: baksmali not found. Path: {path}]"

    def _code_to_markdown(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        cls=PatternClassifier(); scores=cls.classify_content(text)
        lang=max(scores,key=scores.get) if scores else "code"; fp=cls.fingerprint_structure(text)
        lines=["# Code Documentation\n",
               f"**Language:** `{lang}` | **Lines:** {fp['line_count']} | **Functions:** {fp['function_count']} | **Classes:** {fp['class_count']} | **Cyclomatic:** {fp['cyclomatic_proxy']} | **Coupling:** {fp['coupling_score']}\n",
               "## Functions\n"]+[f"- `{fn}()`" for fn in fp["functions"][:15]]
        lines+=["## Classes\n"]+[f"- `{c}`" for c in fp["classes"][:10]]
        lines+=["## Source\n",f"```{lang}",text[:3000],"```"]
        return "\n".join(lines)

    def _sql_to_markdown(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        tables=re.findall(r'CREATE\s+TABLE\s+(\w+)\s*\(([^)]+)\)',text,re.IGNORECASE|re.DOTALL)
        lines=["# SQL Schema Documentation\n"]
        for tname,tdef in tables:
            lines.append(f"## Table: `{tname}`\n"); lines.append("| Column | Type | Constraints |"); lines.append("|--------|------|-------------|")
            for col in tdef.split(","):
                col=col.strip()
                if not col: continue
                parts=col.split()
                if parts and parts[0].upper() not in ("PRIMARY","FOREIGN","UNIQUE","INDEX","KEY","CONSTRAINT"):
                    lines.append(f"| `{parts[0]}` | `{parts[1] if len(parts)>1 else 'TEXT'}` | {' '.join(parts[2:]) if len(parts)>2 else ''} |")
            lines.append("")
        if not tables: lines+=["No CREATE TABLE statements found.\n","```sql\n"+text[:2000]+"\n```"]
        return "\n".join(lines)

    def _text_to_markdown(self,c,o):
        text=c if isinstance(c,str) else c.decode(); md=[]
        for line in text.splitlines():
            s=line.strip()
            if not s: md.append("")
            elif re.match(r'^[A-Z][A-Z\s]{4,}$',s): md.append(f"## {s.title()}")
            elif re.match(r'^\d+\.\s+',s): md.append(s)
            elif re.match(r'^[-*\u2022]\s+',s): md.append(f"- {s.lstrip('-* ')}")
            else: md.append(s)
        return "\n".join(md)

    def _markdown_to_html(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        for i in range(6,0,-1): text=re.sub(rf'^{"#"*i}\s+(.+)$',rf'<h{i}>\1</h{i}>',text,flags=re.MULTILINE)
        text=re.sub(r'\*\*\*(.+?)\*\*\*',r'<strong><em>\1</em></strong>',text)
        text=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',text); text=re.sub(r'\*(.+?)\*',r'<em>\1</em>',text)
        text=re.sub(r'`([^`]+)`',r'<code>\1</code>',text)
        text=re.sub(r'```(\w*)\n(.*?)```',lambda m:f'<pre><code class="{m.group(1)}">{m.group(2)}</code></pre>',text,flags=re.DOTALL)
        text=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',text)
        text=re.sub(r'(?m)^- (.+)$',r'<li>\1</li>',text)
        result=[f'<p>{p.strip()}</p>' if p.strip() and not p.strip().startswith('<') else p.strip() for p in re.split(r'\n{2,}',text)]
        return "<!DOCTYPE html>\n<html>\n<body>\n"+"\n".join(result)+"\n</body>\n</html>"

    def _html_to_text(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        text=re.sub(r'<(script|style)[^>]*>.*?</(script|style)>','',text,flags=re.DOTALL|re.IGNORECASE)
        text=re.sub(r'<(br|p|div|h[1-6]|li|tr)[^>]*>','\n',text,flags=re.IGNORECASE)
        text=re.sub(r'<[^>]+>','',text)
        for ent,repl in {"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"',"&#39;":"'","&nbsp;":" "}.items(): text=text.replace(ent,repl)
        return re.sub(r'\n{3,}','\n\n',text).strip()

    def _html_to_markdown(self,c,o): return self._text_to_markdown(self._html_to_text(c,o),o)

    def _pdf_to_text(self,c,o):
        path=c if isinstance(c,str) else c.decode()
        try:
            from pdfminer.high_level import extract_text
            return extract_text(path)
        except ImportError: pass
        try:
            r=subprocess.run(["pdftotext",path,"-"],capture_output=True,text=True,timeout=30)
            if r.returncode==0: return r.stdout
        except (FileNotFoundError,subprocess.TimeoutExpired): pass
        try:
            data=open(path,"rb").read()
            return "\n".join(c.decode("ascii",errors="replace") for c in re.findall(rb'[\x20-\x7e\n\t]{8,}',data)[:200])
        except: return "[PDF extraction failed]"

    def _binary_to_hex(self,c,o):
        data=c if isinstance(c,bytes) else c.encode(); width=o.get("hex_width",16); lines=[]
        for i in range(0,len(data),width):
            chunk=data[i:i+width]
            lines.append(f"{i:08x}  {' '.join(f'{b:02x}' for b in chunk):<{width*3}}  |{''.join(chr(b) if 0x20<=b<0x7f else '.' for b in chunk)}|")
        return "\n".join(lines)

    def _binary_to_base64(self,c,o): return base64.b64encode(c if isinstance(c,bytes) else c.encode()).decode("ascii")

    def _binary_to_json(self,c,o):
        data=c if isinstance(c,bytes) else c.encode()
        info=PatternClassifier().classify_binary(data)
        info["strings"]=[s.decode("ascii",errors="ignore") for s in re.findall(rb'[\x20-\x7e]{6,}',data)[:50]]
        info["hex_preview"]=data[:64].hex(); info["md5"]=hashlib.md5(data).hexdigest(); info["sha256"]=hashlib.sha256(data).hexdigest()
        return json.dumps(info,indent=2,default=str)

    def _hex_to_binary(self,c,o): return bytes.fromhex(re.sub(r'[^0-9a-fA-F]','',c if isinstance(c,str) else c.decode()))
    def _base64_to_binary(self,c,o): return base64.b64decode((c if isinstance(c,str) else c.decode()).strip())

    def _archive_to_json_manifest(self,c,o):
        path=c if isinstance(c,str) else c.decode(); manifest={"path":path,"entries":[]}
        try:
            if zipfile.is_zipfile(path):
                with zipfile.ZipFile(path,"r") as zf:
                    for info in zf.infolist():
                        manifest["entries"].append({"name":info.filename,"size":info.file_size,"compressed":info.compress_size,"ratio":round(info.compress_size/max(info.file_size,1),4),"crc":info.CRC})
                manifest["format"]="zip"
            elif tarfile.is_tarfile(path):
                with tarfile.open(path,"r:*") as tf:
                    for m in tf.getmembers():
                        manifest["entries"].append({"name":m.name,"size":m.size,"type":"dir" if m.isdir() else "file","mode":oct(m.mode)})
                manifest["format"]="tar"
        except Exception as e: manifest["error"]=str(e)
        return json.dumps(manifest,indent=2)

    def _zip_to_tar(self,c,o):
        path=c if isinstance(c,str) else c.decode(); buf=io.BytesIO()
        with zipfile.ZipFile(path,"r") as zf, tarfile.open(fileobj=buf,mode="w:gz") as tf:
            for name in zf.namelist():
                data=zf.read(name); info=tarfile.TarInfo(name=name); info.size=len(data); tf.addfile(info,io.BytesIO(data))
        return buf.getvalue()

    def _tar_to_zip(self,c,o):
        path=c if isinstance(c,str) else c.decode(); buf=io.BytesIO()
        with tarfile.open(path,"r:*") as tf, zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as zf:
            for member in tf.getmembers():
                if member.isfile():
                    f=tf.extractfile(member)
                    if f: zf.writestr(member.name,f.read())
        return buf.getvalue()

    def _sql_schema_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode(); tables={}
        for tm in re.finditer(r'CREATE\s+TABLE\s+(\w+)\s*\(([^)]+)\)',text,re.IGNORECASE|re.DOTALL):
            columns=[]
            for col in tm.group(2).split(","):
                col=col.strip(); parts=col.split()
                if parts and parts[0].upper() not in ("PRIMARY","FOREIGN","UNIQUE","INDEX","KEY","CONSTRAINT"):
                    columns.append({"name":parts[0],"type":parts[1] if len(parts)>1 else "TEXT","constraints":" ".join(parts[2:]) if len(parts)>2 else ""})
            tables[tm.group(1)]=columns
        return json.dumps({"schema":tables},indent=2)

    def _json_to_sql(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode())
        if isinstance(data,list) and data and isinstance(data[0],dict):
            table=o.get("table_name","imported_data"); cols=list(data[0].keys())
            lines=[f"CREATE TABLE {table} (","    id INTEGER PRIMARY KEY AUTOINCREMENT,"]
            for col in cols:
                v=data[0][col]; t="INTEGER" if isinstance(v,int) else "REAL" if isinstance(v,float) else "TEXT"
                lines.append(f"    {col} {t},")
            lines[-1]=lines[-1].rstrip(","); lines.append(");\n")
            for row in data[:500]:
                vals=", ".join(str(row.get(cc,"")) if isinstance(row.get(cc),(int,float)) else f"'{str(row.get(cc,'')).replace(chr(39),chr(39)*2)}'" for cc in cols)
                lines.append(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({vals});")
            return "\n".join(lines)
        return f"-- Cannot convert: unsupported structure\n-- {str(data)[:200]}"

    def _ini_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode(); result={}; section="__root__"
        for line in text.splitlines():
            line=line.strip()
            if not line or line.startswith(("#",";")): continue
            if line.startswith("[") and line.endswith("]"): section=line[1:-1]; result.setdefault(section,{})
            elif "=" in line:
                k,_,v=line.partition("="); result.setdefault(section,{})[k.strip()]=v.strip()
        if "__root__" in result and not result["__root__"]: del result["__root__"]
        return json.dumps(result,indent=2)

    def _env_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode(); result={}
        for line in text.splitlines():
            line=line.strip()
            if not line or line.startswith("#"): continue
            if "=" in line:
                k,_,v=line.partition("="); result[k.strip()]=v.strip().strip('"\'')
        return json.dumps(result,indent=2)

    def _json_to_ini(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode()); lines=[]
        if isinstance(data,dict):
            for section,vals in data.items():
                if isinstance(vals,dict): lines.append(f"[{section}]"); [lines.append(f"{k} = {v}") for k,v in vals.items()]; lines.append("")
                else: lines.append(f"{section} = {vals}")
        return "\n".join(lines)

    def _json_to_env(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode()); lines=["# Generated by Zeus Logic Engine"]
        def flatten(obj,prefix=""):
            if isinstance(obj,dict):
                for k,v in obj.items():
                    nk=f"{prefix}_{k}".upper().lstrip("_") if prefix else k.upper(); flatten(v,nk)
            elif isinstance(obj,list): lines.append(f"{prefix}={json.dumps(obj)}")
            else:
                vs=str(obj)
                if " " in vs or "=" in vs: vs=f'"{vs}"'
                lines.append(f"{prefix}={vs}")
        flatten(data); return "\n".join(lines)

    def _text_to_json(self,c,o):
        text=c if isinstance(c,str) else c.decode()
        try: return json.dumps(json.loads(text),indent=2)
        except: pass
        result={}
        for line in text.splitlines():
            line=line.strip()
            for sep in ["=",":","\t"]:
                if sep in line:
                    k,_,v=line.partition(sep)
                    if k.strip(): result[k.strip()]=v.strip()
                    break
        if not result: result={"content":text,"lines":len(text.splitlines()),"words":len(text.split())}
        return json.dumps(result,indent=2)

    def _json_to_text(self,c,o):
        data=json.loads(c if isinstance(c,str) else c.decode())
        def flatten(obj,prefix):
            lines=[]
            if isinstance(obj,dict):
                for k,v in obj.items(): lines.extend(flatten(v,f"{prefix}.{k}" if prefix else k))
            elif isinstance(obj,list):
                for i,item in enumerate(obj): lines.extend(flatten(item,f"{prefix}[{i}]"))
            else: lines.append(f"{prefix}: {obj}" if prefix else str(obj))
            return lines
        return "\n".join(flatten(data,""))

# ============================================================================
# SYNTHESIS BRIDGE
# ============================================================================

class SynthesisBridge:
    def __init__(self, arch_kb):
        self._kb = arch_kb

    def generate(self, goal, context, plan=None):
        bid = uuid.uuid4().hex[:16]
        module_name  = self._infer_module_name(goal)
        module_type  = self._infer_module_type(goal, context)
        arch_style   = self._infer_arch_style(goal, context)
        relevant     = self._kb.get_relevant_patterns(goal, context)
        solid        = self._kb.get_solid_checklist(module_type)
        layers       = self._build_layers(arch_style, module_type)
        interfaces   = self._build_interfaces(module_name, module_type, arch_style)
        deps         = self._build_dependencies(goal, context)
        flows        = self._build_data_flows(module_type, arch_style)
        dp           = list(set(itertools.chain.from_iterable(relevant.values())))
        sec          = list(self._kb.SECURITY_PATTERNS.keys()) if module_type in ("api","service","module","engine") else []
        scal         = relevant.get("scalability", [])
        adrs         = self._generate_adrs(goal, arch_style, module_type, dp)
        directives   = self._generate_directives(module_name, module_type, arch_style, layers, interfaces, dp, sec)
        code_struct  = self._generate_code_structure(module_name, module_type, arch_style, layers)
        gates        = self._generate_quality_gates(module_type, solid, sec)
        test_plan    = self._generate_test_plan(module_name, module_type, interfaces)
        confidence   = self._estimate_confidence(goal, layers, dp)
        critique_sc  = self._compute_critique_score(layers, dp, sec, solid)
        return SynthesisBlueprint(
            blueprint_id=bid, goal=goal, module_name=module_name, module_type=module_type,
            architecture_style=arch_style, layers=layers, interfaces=interfaces,
            dependencies=deps, data_flows=flows, design_patterns=dp, solid_compliance=solid,
            security_considerations=sec, scalability_patterns=scal, adrs=adrs,
            synthesis_directives=directives, code_structure=code_struct, quality_gates=gates,
            test_plan=test_plan, confidence=confidence, critique_score=critique_sc, improvement_iterations=0,
        )

    def improve(self, bp, critique):
        layers=list(bp.layers); dp=list(bp.design_patterns); sec=list(bp.security_considerations)
        directives=list(bp.synthesis_directives); gates=list(bp.quality_gates); adrs=list(bp.adrs)
        for pattern in critique.recommended_patterns:
            if pattern not in dp:
                dp.append(pattern); directives.append(f"Apply {pattern} pattern as recommended by critique")
        for gap in critique.security_gaps:
            directives.append(f"Address security gap: {gap}"); gates.append(f"Security gate: {gap} must be resolved")
        for issue in critique.issues:
            if issue.get("severity") in ("error","critical"):
                directives.insert(0,f"PRIORITY FIX: {issue.get('description','')}")
        for violation in critique.solid_violations:
            directives.append(f"Resolve SOLID violation: {violation}")
        for suggestion in critique.improvement_suggestions[:3]:
            adrs.append(ArchitecturalDecision(
                decision_id=f"adr_imp_{uuid.uuid4().hex[:6]}", title=f"Improvement: {suggestion[:60]}",
                status="accepted", context="Post-critique improvement", decision=suggestion,
                consequences=["Improved quality score"], alternatives=[], pattern_applied=None,
                confidence=0.75, rationale=f"Critique identified: {suggestion}",
            ))
        return SynthesisBlueprint(
            blueprint_id=bp.blueprint_id, goal=bp.goal, module_name=bp.module_name,
            module_type=bp.module_type, architecture_style=bp.architecture_style,
            layers=layers, interfaces=bp.interfaces, dependencies=bp.dependencies,
            data_flows=bp.data_flows, design_patterns=dp, solid_compliance=bp.solid_compliance,
            security_considerations=sec, scalability_patterns=bp.scalability_patterns,
            adrs=adrs, synthesis_directives=directives, code_structure=bp.code_structure,
            quality_gates=gates, test_plan=bp.test_plan,
            confidence=min(1.0,bp.confidence+0.05),
            critique_score=min(1.0,bp.critique_score+0.1*len(critique.recommended_patterns)),
            improvement_iterations=bp.improvement_iterations+1, created_at=bp.created_at,
        )

    def _infer_module_name(self, goal):
        words=re.findall(r'\b[A-Za-z]\w+\b',goal.strip())
        meaningful=[w for w in words if len(w)>3 and w.lower() not in
                    {"build","create","make","write","generate","for","with","that","this","into"}]
        return "_".join(w.lower() for w in meaningful[:3]) if meaningful else f"zeus_module_{uuid.uuid4().hex[:6]}"

    def _infer_module_type(self, goal, context):
        g=goal.lower()
        if any(k in g for k in ("api","endpoint","route","server","web")): return "api"
        if any(k in g for k in ("engine","processor","reasoner","analyser")): return "engine"
        if any(k in g for k in ("service","manager","handler","orchestrat")): return "service"
        if any(k in g for k in ("library","util","helper","tool")): return "library"
        return context.get("module_type","module")

    def _infer_arch_style(self, goal, context):
        g=goal.lower()
        if any(k in g for k in ("domain","aggregate","entity","bounded")): return "ddd"
        if any(k in g for k in ("hexagonal","port","adapter")): return "hexagonal"
        return context.get("architecture","clean")

    def _build_layers(self, arch_style, module_type):
        if arch_style in ("clean","hexagonal"):
            return [
                {"name":"Domain","level":0,"role":"core business logic","components":["Entity","ValueObject","DomainService","DomainEvent"],"dependencies":[],"rules":["No external imports"]},
                {"name":"Application","level":1,"role":"use case orchestration","components":["UseCase","Command","Query","ApplicationService"],"dependencies":["Domain"],"rules":["Depends only on Domain"]},
                {"name":"Infrastructure","level":2,"role":"technical concerns","components":["Repository","Gateway","Mapper","Adapter"],"dependencies":["Application","Domain"],"rules":["Implements Application interfaces"]},
                {"name":"Presentation","level":3,"role":"external surface","components":["Controller","Presenter","ViewModel","FlaskRoute"],"dependencies":["Application"],"rules":["Thin layer; delegates to Application"]},
            ]
        elif arch_style=="ddd":
            return [
                {"name":"DomainModel","level":0,"components":["Aggregate","Entity","ValueObject","DomainEvent","Repository"],"dependencies":[]},
                {"name":"ApplicationServices","level":1,"components":["ApplicationService","Saga","EventHandler"],"dependencies":["DomainModel"]},
                {"name":"InfrastructureServices","level":2,"components":["RepositoryImpl","EventBus","ExternalGateway"],"dependencies":["DomainModel","ApplicationServices"]},
                {"name":"UserInterface","level":3,"components":["APIController","DTOs","Serialisers"],"dependencies":["ApplicationServices"]},
            ]
        return [
            {"name":"Core","level":0,"components":["BusinessLogic","Models"],"dependencies":[]},
            {"name":"Service","level":1,"components":["ServiceLayer","UseCases"],"dependencies":["Core"]},
            {"name":"Adapter","level":2,"components":["RepositoryImpl","APIClient"],"dependencies":["Core","Service"]},
            {"name":"Interface","level":3,"components":["Controller","View"],"dependencies":["Service"]},
        ]

    def _build_interfaces(self, module_name, module_type, arch_style):
        mn=module_name.title().replace("_","")
        base=[
            {"name":f"I{mn}Repository","layer":"Application","methods":["find_by_id","save","delete","list_all"],"purpose":"Persistence abstraction"},
            {"name":f"I{mn}Service","layer":"Application","methods":["process","validate","execute"],"purpose":"Business operations"},
        ]
        if module_type in ("api","service"):
            base.append({"name":f"I{mn}Gateway","layer":"Infrastructure","methods":["send","receive","health_check"],"purpose":"External communication gateway"})
        return base

    def _build_dependencies(self, goal, context):
        deps=[
            {"name":"SQLiteDB","type":"infrastructure","required":True,"injection":"constructor","note":"WAL mode enabled"},
            {"name":"LoggingFramework","type":"cross_cutting","required":True,"injection":"static","note":"zeus.logger namespace"},
        ]
        g=goal.lower()
        if any(k in g for k in ("llm","claude","openrouter","ai")): deps.append({"name":"LLMGateway","type":"external","required":False,"injection":"constructor","note":"Circuit breaker required"})
        if any(k in g for k in ("flask","api","route","web")): deps.append({"name":"FlaskBlueprint","type":"framework","required":True,"injection":"module_register","note":"Register via app.py"})
        if any(k in g for k in ("genome","dna")): deps.append({"name":"GenomeDB","type":"zeus_core","required":True,"injection":"singleton_get","note":"Zeus genome subsystem"})
        if any(k in g for k in ("knowledge","learn")): deps.append({"name":"KnowledgeBase","type":"zeus_core","required":True,"injection":"singleton_get","note":"Zeus knowledge subsystem"})
        return deps

    def _build_data_flows(self, module_type, arch_style):
        flows=[
            {"flow_id":"main_request","name":"Request Processing","source":"Presentation","sink":"Infrastructure",
             "path":["Presentation","Application","Domain","Infrastructure"],"data_types":["RequestDTO","DomainObject","PersistenceEntity"],"transformation_points":["Controller→UseCase","UseCase→Repository"]},
            {"flow_id":"event_propagation","name":"Domain Event Propagation","source":"Domain","sink":"Application",
             "path":["Domain","Application"],"data_types":["DomainEvent"],"transformation_points":["Aggregate→EventBus","EventBus→EventHandler"]},
        ]
        if module_type=="engine":
            flows.append({"flow_id":"self_improvement","name":"Self-Improvement Loop","source":"Core","sink":"Core",
                          "path":["Core","KnowledgeExpansion","RuleModification","Core"],
                          "data_types":["ReasoningResult","DynamicRule","KnowledgeEntry"],
                          "transformation_points":["Result→Pattern","Pattern→Rule","Rule→RuleSet"]})
        return flows

    def _generate_adrs(self, goal, arch_style, module_type, patterns):
        adrs=[
            ArchitecturalDecision("adr_001_arch_style",f"Use {arch_style.upper()} architecture","accepted",
                f"Building {module_type} for: {goal[:100]}",
                f"Adopt {arch_style} architecture to enforce dependency rules and testability.",
                ["Clear layer boundaries","Framework independence","Higher initial setup cost"],
                ["Layered monolith","Script-style"],arch_style,0.88,
                "Zeus modules benefit from clean separation for self-modification safety."),
            ArchitecturalDecision("adr_002_offline_first","Offline-First reasoning","accepted",
                "Zeus runs on Android device with intermittent connectivity",
                "All core logic must operate fully offline; LLM is an optional enhancement.",
                ["Resilient to network loss","Local knowledge must be sufficient"],
                ["LLM-required architecture"],"OfflineFirstReasoning",0.95,
                "Zeus is deployed on armv7l Android; offline-first is non-negotiable."),
        ]
        if "Strategy" in patterns:
            adrs.append(ArchitecturalDecision("adr_003_strategy","Strategy pattern for interchangeable algorithms","accepted",
                "Multiple algorithm variants needed","Encapsulate algorithms behind Strategy interface for OCP compliance.",
                ["Easy algorithm addition","No modification of core"],["if/elif chain","Inheritance hierarchy"],
                "Strategy",0.82,"Supports OCP; allows runtime algorithm selection."))
        return adrs

    def _generate_directives(self, module_name, module_type, arch_style, layers, interfaces, patterns, security):
        directives=[
            f"MODULE_NAME: {module_name}",f"MODULE_TYPE: {module_type}",f"ARCHITECTURE: {arch_style}",
            f"LAYER_COUNT: {len(layers)}","DEPENDENCY_RULE: all imports must point inward toward Domain layer",
            "THREAD_SAFETY: use threading.RLock for all mutable shared state",
            "LOGGING: use logging.getLogger('zeus.{module_name}') pattern",
            "ERROR_HANDLING: all public methods wrapped in try/except with proper logging",
            "DATABASE: SQLite WAL mode; parameterised queries only; no raw string formatting in SQL",
        ]
        for iface in interfaces:
            directives.append(f"INTERFACE: implement {iface['name']} in Infrastructure layer with methods: {', '.join(iface['methods'])}")
        for pattern in patterns[:6]:
            directives.append(f"APPLY_PATTERN: {pattern}")
        if "InputValidation" in security:
            directives.append("SECURITY: validate all external inputs before processing")
        if "InjectionPrevention" in security:
            directives.append("SECURITY: parameterise all DB queries; never use string format for SQL")
        directives+=[
            "QUALITY: cyclomatic complexity per function <= 10",
            "QUALITY: comment density >= 15%",
            "QUALITY: each public method must have a docstring",
            "FLASK: register blueprint in register(app) function",
            "FLASK: all routes return jsonify(); no naked exceptions to client",
        ]
        return directives

    def _generate_code_structure(self, module_name, module_type, arch_style, layers):
        return {
            "file":f"{module_name}.py","top_section":"header comment + all imports",
            "sections":[
                {"name":"Thread Safety & Singleton","pattern":"_lock + _instance + get_X() factory"},
                {"name":"Data Structures","pattern":"@dataclass; frozen where possible"},
            ]+[{"name":l["name"],"pattern":f"class {l['name']}Impl: + interface contracts","components":l["components"]} for l in layers],
            "flask_section":{"blueprint":f"{module_name}_bp = Blueprint('{module_name}', __name__)",
                             "routes":["GET /health","GET /stats","POST /process"],"register_fn":"def register(app): app.register_blueprint(...)"},
            "main_section":"if __name__ == '__main__': standalone Flask runner",
            "naming_conventions":{"classes":"PascalCase","methods":"snake_case","constants":"UPPER_SNAKE_CASE","private":"_leading_underscore"},
        }

    def _generate_quality_gates(self, module_type, solid, security):
        gates=[
            "Gate 1: No circular imports","Gate 2: All public methods documented",
            "Gate 3: Thread safety verified on shared state","Gate 4: No hard-coded secrets or credentials",
            "Gate 5: All DB queries parameterised","Gate 6: Blueprint registers correctly via register(app)",
            "Gate 7: /health endpoint returns {status: ok} when ready",
        ]
        if solid.get("SRP"): gates.append("Gate 8: SOLID-SRP — each class has one reason to change")
        if solid.get("DIP"): gates.append("Gate 9: SOLID-DIP — no direct class instantiation in business logic")
        if "InputValidation" in security: gates.append("Gate 10: All Flask route inputs validated before use")
        if module_type=="engine":
            gates+=["Gate 11: Self-modification does not introduce contradicting rules",
                    "Gate 12: Offline reasoning produces results without network access"]
        return gates

    def _generate_test_plan(self, module_name, module_type, interfaces):
        plan=[
            {"test_id":"T01","type":"unit","target":"Domain layer","description":"Entity equality, ValueObject immutability, DomainEvent creation","priority":"high"},
            {"test_id":"T02","type":"unit","target":"Application use cases","description":"UseCase happy path and error paths with mock repositories","priority":"high"},
            {"test_id":"T03","type":"integration","target":"Infrastructure layer","description":"Repository CRUD against test SQLite DB","priority":"medium"},
            {"test_id":"T04","type":"integration","target":"Flask routes","description":f"POST /process, GET /health, GET /stats for {module_name}","priority":"high"},
            {"test_id":"T05","type":"property","target":"Thread safety","description":"Concurrent requests; verify no data races on shared state","priority":"medium"},
        ]
        for i,iface in enumerate(interfaces):
            plan.append({"test_id":f"T{10+i:02d}","type":"contract","target":iface["name"],"description":f"Verify all methods of {iface['name']} satisfy their contracts","priority":"high"})
        if module_type=="engine":
            plan.append({"test_id":"T20","type":"regression","target":"Self-modification safety","description":"Verify new rules do not introduce contradictions or degrade existing results","priority":"critical"})
        return plan

    def _estimate_confidence(self, goal, layers, patterns):
        base=0.65+min(len(layers)*0.04,0.12)+min(len(patterns)*0.02,0.10)
        if len(goal)>20: base+=0.05
        return round(min(base,0.95),4)

    def _compute_critique_score(self, layers, patterns, security, solid):
        score=(min(len(layers)/4,1.0)*0.25+min(len(patterns)/5,1.0)*0.25+
               min(len(security)/4,1.0)*0.25+sum(1 for v in solid.values() if v)/max(len(solid),1)*0.25)
        return round(score,4)


# ============================================================================
# ADVANCED BLUEPRINT PLANNER
# ============================================================================

class AdvancedBlueprintPlanner:
    STEP_TEMPLATES = {
        "analyze_file":             {"description":"Classify and fingerprint input file","estimated_ms":50,"dependencies":[],"outputs":["file_type","file_structure","confidence"]},
        "extract_knowledge":        {"description":"Extract knowledge from analyzed content","estimated_ms":200,"dependencies":["analyze_file"],"outputs":["knowledge_entries"]},
        "build_genome":             {"description":"Synthesize genome entry from extracted patterns","estimated_ms":150,"dependencies":["extract_knowledge"],"outputs":["genome_id"]},
        "convert_format":           {"description":"Transform content between formats","estimated_ms":100,"dependencies":["analyze_file"],"outputs":["converted_content"]},
        "run_synthesis":            {"description":"Execute synthesis engine on genome","estimated_ms":300,"dependencies":["build_genome","extract_knowledge"],"outputs":["synthesis_artifact"]},
        "semantic_search":          {"description":"Query knowledge base with TF-IDF semantic search","estimated_ms":30,"dependencies":[],"outputs":["search_results"]},
        "reason_about_facts":       {"description":"Forward-chain inference over fact set","estimated_ms":25,"dependencies":["analyze_file"],"outputs":["conclusions","contradictions","hypotheses"]},
        "blueprint_save":           {"description":"Persist blueprint plan to database","estimated_ms":20,"dependencies":["run_synthesis"],"outputs":["blueprint_id"]},
        "meta_reason":              {"description":"Analyse and critique the rule set itself","estimated_ms":40,"dependencies":[],"outputs":["rule_gaps","conflict_map","effectiveness_report"]},
        "apply_architectural_patterns": {"description":"Select and apply relevant architectural patterns","estimated_ms":60,"dependencies":["analyze_file"],"outputs":["patterns_applied","adr_list"]},
        "self_modification_cycle":  {"description":"Propose, validate, and apply new reasoning rules","estimated_ms":80,"dependencies":["reason_about_facts"],"outputs":["new_rules_applied","rejected_rules"]},
        "knowledge_expansion":      {"description":"Learn from synthesis results; expand rule base","estimated_ms":70,"dependencies":["run_synthesis"],"outputs":["learned_patterns","new_rule_candidates"]},
        "generate_synthesis_blueprint": {"description":"Generate rich synthesis blueprint for Synthesis Engine","estimated_ms":120,"dependencies":["apply_architectural_patterns","reason_about_facts"],"outputs":["synthesis_blueprint"]},
        "critique_and_improve":     {"description":"Critique the plan and produce an improved version","estimated_ms":90,"dependencies":["generate_synthesis_blueprint"],"outputs":["critique_report","improved_blueprint"]},
        "quality_gate_check":       {"description":"Run all quality gates before emitting final blueprint","estimated_ms":30,"dependencies":["critique_and_improve"],"outputs":["gate_results","gate_pass"]},
    }

    KEYWORD_STEP_MAP = [
        (("knowledge","learn","extract","ingest"),     "extract_knowledge"),
        (("genome","dna","mutate","evolve"),           "build_genome"),
        (("convert","transform","translate"),          "convert_format"),
        (("synthesis","synthesize","generate"),        "run_synthesis"),
        (("search","query","find","lookup"),           "semantic_search"),
        (("reason","infer","logic","conclude"),        "reason_about_facts"),
        (("blueprint","plan","save","persist"),        "blueprint_save"),
        (("architecture","pattern","design"),          "apply_architectural_patterns"),
        (("self","modify","rule","dynamic"),           "self_modification_cycle"),
        (("improve","critique","review"),              "critique_and_improve"),
        (("expand","grow","learn"),                    "knowledge_expansion"),
        (("meta","introspect"),                        "meta_reason"),
        (("quality","gate","verify"),                  "quality_gate_check"),
    ]

    def __init__(self, arch_kb, synthesis_bridge):
        self._kb = arch_kb
        self._bridge = synthesis_bridge

    def plan(self, goal, context=None):
        context=context or {}; plan_id=uuid.uuid4().hex[:12]
        selected=self._select_steps(goal,context); dep_graph=self._build_dependency_graph(selected)
        ordered=self._topological_sort(dep_graph,selected)
        total_ms=sum(self.STEP_TEMPLATES[s]["estimated_ms"] for s in ordered if s in self.STEP_TEMPLATES)
        step_list=[{"seq":i+1,"step":sn,"description":self.STEP_TEMPLATES.get(sn,{}).get("description",sn),
                    "estimated_ms":self.STEP_TEMPLATES.get(sn,{}).get("estimated_ms",100),
                    "dependencies":self.STEP_TEMPLATES.get(sn,{}).get("dependencies",[]),
                    "outputs":self.STEP_TEMPLATES.get(sn,{}).get("outputs",[]),"status":"pending"}
                   for i,sn in enumerate(ordered)]
        return BlueprintPlan(plan_id=plan_id,goal=goal,steps=tuple(step_list),
                             dependency_graph=dep_graph,estimated_duration_ms=total_ms,
                             confidence=self._estimate_plan_confidence(goal,ordered,context))

    def plan_to_dict(self, plan):
        return {"plan_id":plan.plan_id,"goal":plan.goal,"steps":list(plan.steps),
                "dependency_graph":plan.dependency_graph,"estimated_duration_ms":plan.estimated_duration_ms,
                "confidence":plan.confidence,"created_at":plan.created_at,"step_count":len(plan.steps)}

    def deep_plan(self, goal, context=None):
        context=context or {}
        bp=self._bridge.generate(goal,context)
        critique=self.critique_plan(bp)
        for _ in range(context.get("max_iterations",2)):
            if critique.overall_score>=0.80: break
            bp=self._bridge.improve(bp,critique)
            critique=self.critique_plan(bp)
        return bp

    def critique_plan(self, bp):
        issues=[]; missing=[]; anti=[]; solid_violations=[]; sec_gaps=[]; recommended=[]; suggestions=[]
        layer_names=[l["name"].lower() for l in bp.layers]
        if not any("domain" in n or "core" in n for n in layer_names):
            issues.append({"severity":"error","category":"architecture","description":"Missing domain/core layer","fix":"Add Domain layer as innermost ring"})
        if not any("infra" in n or "adapter" in n for n in layer_names):
            issues.append({"severity":"warning","category":"architecture","description":"Missing infrastructure/adapter layer","fix":"Add Infrastructure layer"})
        if len(bp.interfaces)<2: missing.append("Insufficient interface definitions"); recommended.append("Facade")
        if not bp.solid_compliance.get("SRP"): solid_violations.append("SRP not enforced"); suggestions.append("Extract responsibilities into separate classes")
        if not bp.solid_compliance.get("DIP"): solid_violations.append("DIP not enforced"); suggestions.append("Introduce dependency injection via constructor")
        if not bp.solid_compliance.get("OCP"): solid_violations.append("OCP not enforced"); suggestions.append("Apply Strategy or Observer pattern")
        required_sec={"InputValidation","InjectionPrevention","FailSecure"}
        for ms in required_sec-set(bp.security_considerations): sec_gaps.append(f"Missing security pattern: {ms}")
        arch_anti=self._kb.get_anti_patterns_for_goal(bp.goal)
        mentioned=[a for a in arch_anti if any(a.lower().split()[0] in d.lower() for d in bp.synthesis_directives)]
        if not mentioned: anti.extend(arch_anti[:3])
        if "Builder" not in bp.design_patterns and bp.module_type=="engine": recommended.append("Builder"); suggestions.append("Use Builder pattern for complex object construction")
        if "Observer" not in bp.design_patterns: recommended.append("Observer"); suggestions.append("Add Observer pattern for module lifecycle events")
        if "CircuitBreaker" not in bp.scalability_patterns: recommended.append("CircuitBreaker"); suggestions.append("Wrap external LLM calls in circuit breaker")
        if len(bp.adrs)<2: missing.append("Insufficient ADRs — document at least 2 key decisions")
        if len(bp.quality_gates)<5: missing.append("Quality gates insufficient")
        penalty=len(issues)*0.10+len(sec_gaps)*0.08+len(solid_violations)*0.06+len(anti)*0.04
        score=round(max(0.0,min(1.0,bp.critique_score-penalty+len(bp.design_patterns)*0.02)),4)
        return PlanCritique(plan_id=bp.blueprint_id,issues=issues,missing_concerns=missing,
                            anti_patterns_detected=anti,solid_violations=solid_violations,
                            security_gaps=sec_gaps,overall_score=score,
                            recommended_patterns=recommended,improvement_suggestions=suggestions)

    def _select_steps(self, goal, context):
        gl=goal.lower(); selected=["analyze_file"]
        for keywords,step in self.KEYWORD_STEP_MAP:
            if any(kw in gl for kw in keywords) and step not in selected:
                selected.append(step)
        if context.get("has_file") and "extract_knowledge" not in selected: selected.append("extract_knowledge")
        if "run_synthesis" in selected and "build_genome" not in selected: selected.append("build_genome")
        if "build_genome" in selected and "extract_knowledge" not in selected: selected.append("extract_knowledge")
        if "generate_synthesis_blueprint" in selected:
            if "apply_architectural_patterns" not in selected: selected.append("apply_architectural_patterns")
            if "reason_about_facts" not in selected: selected.append("reason_about_facts")
        if "critique_and_improve" in selected and "generate_synthesis_blueprint" not in selected:
            selected.append("generate_synthesis_blueprint")
        return selected

    def _build_dependency_graph(self, steps):
        return {step: [d for d in self.STEP_TEMPLATES.get(step,{}).get("dependencies",[]) if d in steps] for step in steps}

    def _topological_sort(self, graph, steps):
        in_degree={s:len(graph.get(s,[])) for s in steps}
        queue=deque(sorted(s for s,d in in_degree.items() if d==0)); result=[]
        while queue:
            node=queue.popleft(); result.append(node)
            for step in steps:
                if node in graph.get(step,[]):
                    in_degree[step]-=1
                    if in_degree[step]==0: queue.append(step)
        result.extend(s for s in steps if s not in result)
        return result

    def _estimate_plan_confidence(self, goal, steps, context):
        base=0.70+min(len(steps)*0.02,0.15)
        if context.get("has_file"): base+=0.05
        if context.get("known_format"): base+=0.05
        return round(min(base,0.97),4)


BlueprintPlanner = AdvancedBlueprintPlanner


# ============================================================================
# MAIN LOGIC ENGINE (Orchestrator)
# ============================================================================

class LogicEngine:
    def __init__(self):
        self._classifier    = PatternClassifier()
        self._semantic_idx  = SemanticIndex()
        self._reasoner      = AdvancedReasoningEngine()
        self._converter     = UniversalConverter()
        self._arch_kb       = ArchitecturalKnowledgeBase()
        self._fact_store    = HierarchicalFactStore()
        self._self_modifier = SelfModificationEngine(self._reasoner)
        self._knowledge_exp = KnowledgeExpansionEngine(self._reasoner, self._self_modifier)
        self._bridge        = SynthesisBridge(self._arch_kb)
        self._planner       = AdvancedBlueprintPlanner(self._arch_kb, self._bridge)
        self._ready         = False
        self._boot_lock     = threading.RLock()
        self._stats = {
            "boot_time_ms":None,"conversions":0,"reasoning_calls":0,"search_calls":0,
            "blueprint_plans":0,"deep_plans":0,"self_modifications":0,"knowledge_expansions":0,
            "rules_total":0,"uptime_seconds":0,
        }
        self._boot_time = time.time()

    def boot(self):
        with self._boot_lock:
            if self._ready: return
            t0=time.time()
            log.info("[LogicEngine] Booting v2 — self-evolving reasoning engine…")
            self._fact_store.seed_zeus_taxonomy()
            self._register_extension_facts()
            threading.Thread(target=self._semantic_idx.rebuild_from_db, daemon=True).start()
            self._ready=True; elapsed=round((time.time()-t0)*1000,2)
            self._stats["boot_time_ms"]=elapsed; self._stats["rules_total"]=len(self._reasoner._rules)
            log.info(f"[LogicEngine] Ready in {elapsed}ms | Rules: {self._stats['rules_total']} | Taxonomy facts: {len(self._fact_store._triples)}")

    def classify(self, content, hint_ext=""):
        scores=self._classifier.classify_content(content,hint_ext)
        structure=self._classifier.fingerprint_structure(content)
        return {"top_type":max(scores,key=scores.get) if scores else "unknown","classification":scores,"structure":structure}

    def reason(self, facts, domain_filter=None, max_depth=15, auto_learn=True):
        self._stats["reasoning_calls"]+=1
        result=self._reasoner.reason(facts,domain_filter,max_depth)
        if auto_learn and len(result.reasoning_chain)>=4:
            candidate=self._knowledge_exp.learn_from_reasoning_session(result)
            if candidate:
                ok,_=self._self_modifier.validate_and_apply(candidate,facts)
                if ok: self._stats["self_modifications"]+=1
        return result

    def plan(self, goal, context=None):
        self._stats["blueprint_plans"]+=1
        return self._planner.plan(goal,context or {})

    def deep_plan(self, goal, context=None):
        self._stats["deep_plans"]+=1
        return self._planner.deep_plan(goal,context or {})

    def learn_from_synthesis(self, synthesis_result):
        self._stats["knowledge_expansions"]+=1
        result=self._knowledge_exp.learn_from_synthesis_result(synthesis_result)
        pending=self._self_modifier.process_pending()
        if pending["applied"]: self._stats["self_modifications"]+=len(pending["applied"])
        return {**result,"rule_modifications":pending}

    def meta_reason(self):
        return self._reasoner.meta_reason()

    def get_fact_taxonomy(self, subject, relation=None):
        if relation:
            return {"subject":subject,"relation":relation,"objects":self._fact_store.get_all_objects(subject,relation,True)}
        with self._fact_store._lock:
            facts=self._fact_store._index.get(subject,[])
        return {"subject":subject,"facts":[{"relation":f.relation,"object":f.object_,"confidence":f.confidence} for f in facts]}

    def _register_extension_facts(self):
        EXT_CATEGORY={"py":"python","kt":"kotlin","java":"java","js":"javascript","ts":"typescript",
                      "rs":"rust","go":"go","c":"c","cpp":"cpp","sh":"shell","sql":"sql","json":"json",
                      "yaml":"yaml","xml":"xml","html":"html","css":"css","zip":"zip","tar":"tar","pdf":"pdf",
                      "apk":"android","jar":"jvm","class":"jvm","dex":"android","smali":"android",
                      "elf":"binary","so":"binary","exe":"binary","csv":"data","tsv":"data","parquet":"data",
                      "db":"data","md":"text","txt":"text","rst":"text","toml":"config","ini":"config",
                      "cfg":"config","env":"config"}
        for ext,category in EXT_CATEGORY.items():
            self._reasoner.add_rule(LogicRule(f"ext_{ext}_is_{category}",(("has_extension",("X",ext),False),),("extension_category",(ext,category)),1.0,"file"))
        CONVERSIONS=[("python","json"),("python","kotlin"),("python","javascript"),("json","yaml"),
                     ("json","xml"),("json","csv"),("json","toml"),("yaml","json"),("xml","json"),
                     ("csv","json"),("toml","json"),("java","kotlin"),("kotlin","java"),("c","cpp"),
                     ("cpp","c"),("javascript","typescript"),("typescript","javascript"),("shell","python"),
                     ("python","shell"),("binary","hex"),("binary","base64"),("zip","tar"),("tar","zip"),
                     ("markdown","html"),("html","text")]
        for src,dst in CONVERSIONS:
            self._reasoner.add_rule(LogicRule(f"can_convert_{src}_to_{dst}",(("file_category",("X",src),False),),("conversion_supported",(src,dst)),0.95,"conversion"))
        log.debug(f"[LogicEngine] Registered {len(EXT_CATEGORY)} extension facts, {len(CONVERSIONS)} conversion facts")

# ============================================================================
# FLASK ROUTES
# ============================================================================

@logic_bp.route("/health", methods=["GET"])
def logic_health():
    try:
        engine=get_engine()
        return jsonify({"status":"ok","module":"logic_engine","version":"2.0","ready":engine._ready,
                        "boot_ms":engine._stats.get("boot_time_ms"),"uptime_s":round(time.time()-engine._boot_time,1),
                        "calls":{"conversions":engine._stats.get("conversions",0),"reasoning":engine._stats.get("reasoning_calls",0),
                                 "searches":engine._stats.get("search_calls",0),"plans":engine._stats.get("blueprint_plans",0),
                                 "deep_plans":engine._stats.get("deep_plans",0),"self_modifications":engine._stats.get("self_modifications",0),
                                 "knowledge_expansions":engine._stats.get("knowledge_expansions",0)},
                        "rules_total":engine._stats.get("rules_total",0),"timestamp":datetime.utcnow().isoformat()+"Z"})
    except Exception as exc:
        return jsonify({"status":"error","error":str(exc)}), 500


@logic_bp.route("/stats", methods=["GET"])
def logic_stats():
    try:
        engine=get_engine()
        engine._stats["uptime_seconds"]=round(time.time()-engine._boot_time,1)
        engine._stats["rules_total"]=len(engine._reasoner._rules)
        rule_meta=engine._reasoner.meta_reason()
        return jsonify({"ready":engine._ready,"stats":engine._stats,
                        "self_modification":engine._self_modifier.stats(),
                        "knowledge_expansion":engine._knowledge_exp.stats(),
                        "rule_meta":{"total":rule_meta["total_rules"],"dynamic":rule_meta["dynamic_rules"],
                                     "domain_dist":rule_meta["domain_distribution"],
                                     "never_fired":len(rule_meta["never_fired_rules"]),
                                     "top_fired":rule_meta["top_fired_rules"][:5]}})
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/classify", methods=["POST"])
def logic_classify():
    data=request.get_json(force=True,silent=True) or {}
    content=data.get("content",""); hint_ext=data.get("hint_ext","")
    if not content:
        return jsonify({"error":"content field required"}), 400
    try:
        return jsonify(get_engine().classify(content,hint_ext))
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/search", methods=["POST"])
def logic_search():
    data=request.get_json(force=True,silent=True) or {}
    query=data.get("query",""); top_k=int(data.get("top_k",5))
    if not query:
        return jsonify({"error":"query field required"}), 400
    try:
        engine=get_engine()
        engine._stats["search_calls"]=engine._stats.get("search_calls",0)+1
        raw=engine._semantic_idx.search(query,top_k)
        return jsonify({"query":query,"results":[{"score":round(s,4),"rowid":r,"topic":t,"snippet":sn} for s,r,t,sn in raw],"count":len(raw)})
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/plan", methods=["POST"])
def logic_plan():
    """
    Dual-mode planning endpoint.

    Request body:
      {
        "goal":    "build a self-learning module",
        "context": {},           // optional
        "deep":    false         // true -> returns full SynthesisBlueprint
      }
    """
    data=request.get_json(force=True,silent=True) or {}
    goal=data.get("goal",""); context=data.get("context",{}); deep=bool(data.get("deep",False))
    if not goal:
        return jsonify({"error":"goal field required"}), 400
    try:
        engine=get_engine()
        engine._stats["blueprint_plans"]=engine._stats.get("blueprint_plans",0)+1
        if deep:
            engine._stats["deep_plans"]=engine._stats.get("deep_plans",0)+1
            bp=engine.deep_plan(goal,context)
            critique=engine._planner.critique_plan(bp)
            return jsonify({"mode":"deep","blueprint":bp.to_dict(),
                            "critique":{"overall_score":critique.overall_score,"issues":critique.issues,
                                        "missing_concerns":critique.missing_concerns,"solid_violations":critique.solid_violations,
                                        "security_gaps":critique.security_gaps,"recommended_patterns":critique.recommended_patterns,
                                        "improvement_suggestions":critique.improvement_suggestions}})
        else:
            return jsonify(engine._planner.plan_to_dict(engine.plan(goal,context)))
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/reason", methods=["POST"])
def logic_reason():
    """
    Forward-chain inference over a supplied fact set.

    Request body:
      {
        "facts": [{"predicate": "has_extension", "args": ["myfile", "py"]}],
        "domain_filter": "file",
        "max_depth":     15,
        "auto_learn":    true,
        "meta":          false
      }
    """
    data=request.get_json(force=True,silent=True) or {}
    facts_raw=data.get("facts"); domain=data.get("domain_filter",None)
    max_depth=int(data.get("max_depth",15)); auto_learn=bool(data.get("auto_learn",True))
    include_meta=bool(data.get("meta",False))
    if facts_raw is None:
        return jsonify({"error":"facts array required (can be empty list)"}), 400
    if not isinstance(facts_raw,list):
        return jsonify({"error":"facts must be an array"}), 400
    try:
        engine=get_engine()
        facts=[LogicFact(predicate=str(f.get("predicate","fact")),args=tuple(str(a) for a in f.get("args",[])),
                         confidence=float(f.get("confidence",1.0)),source=str(f.get("source","user")),
                         negated=bool(f.get("negated",False))) for f in facts_raw]
        result=engine.reason(facts,domain_filter=domain,max_depth=max_depth,auto_learn=auto_learn)
        critique=engine._reasoner.self_critique_result(result)
        response={"query":result.query,"conclusions":[c.to_str() for c in result.conclusions],
                  "reasoning_chain":list(result.reasoning_chain),"confidence":result.confidence,
                  "duration_ms":result.duration_ms,"contradictions":[(a.to_str(),b.to_str()) for a,b in result.contradictions],
                  "abductive_hypotheses":[h.to_str() for h in result.abductive_hypotheses],"critique":critique}
        if include_meta: response["meta"]=engine.meta_reason()
        return jsonify(response)
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/convert", methods=["POST"])
def logic_convert():
    """
    Universal format conversion.

    Request body:
      {
        "content":       "...",
        "source_format": "json",
        "target_format": "yaml",
        "options":       {}
      }
    """
    data=request.get_json(force=True,silent=True) or {}
    content=data.get("content",""); source_fmt=data.get("source_format","")
    target_fmt=data.get("target_format",""); options=data.get("options",{})
    if not content: return jsonify({"error":"content field required"}), 400
    if not source_fmt or not target_fmt: return jsonify({"error":"source_format and target_format required"}), 400
    try:
        engine=get_engine()
        engine._stats["conversions"]=engine._stats.get("conversions",0)+1
        return jsonify(engine._converter.convert(content,source_fmt,target_fmt,options))
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


# ---- New routes (no conflicts with existing) ---------------------------------

@logic_bp.route("/meta", methods=["GET"])
def logic_meta():
    try:
        return jsonify(get_engine().meta_reason())
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/self_modify", methods=["POST"])
def logic_self_modify():
    """
    Manually trigger a self-modification cycle.

    Request body:
      {"test_facts": [...], "process_pending": true}
    """
    data=request.get_json(force=True,silent=True) or {}
    raw_facts=data.get("test_facts",[]); do_process=bool(data.get("process_pending",True))
    try:
        engine=get_engine()
        test_facts=[LogicFact(predicate=str(f.get("predicate","fact")),args=tuple(str(a) for a in f.get("args",[])),
                              confidence=float(f.get("confidence",1.0)),source="self_modify_test") for f in raw_facts]
        result={"modifier_stats":engine._self_modifier.stats()}
        if do_process:
            outcome=engine._self_modifier.process_pending(test_facts or None)
            engine._stats["self_modifications"]+=len(outcome.get("applied",[]))
            result["process_result"]=outcome
        result["audit_log_recent"]=engine._self_modifier.get_audit_log(10)
        result["total_rules"]=len(engine._reasoner._rules)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/learn", methods=["POST"])
def logic_learn():
    """
    Feed a synthesis result back into the engine for knowledge expansion.

    Request body:
      {"synthesis_result": {"module_name":"...", "module_type":"...", "design_patterns":[...], "quality_score":0.9}}
    """
    data=request.get_json(force=True,silent=True) or {}
    result=data.get("synthesis_result",{})
    if not result: return jsonify({"error":"synthesis_result required"}), 400
    try:
        return jsonify(get_engine().learn_from_synthesis(result))
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/taxonomy", methods=["POST"])
def logic_taxonomy():
    """
    Query the hierarchical fact store.

    Request body:
      {"subject": "logic_engine", "relation": "is_a", "transitive": true}
    """
    data=request.get_json(force=True,silent=True) or {}
    subject=data.get("subject","")
    if not subject: return jsonify({"error":"subject field required"}), 400
    try:
        return jsonify(get_engine().get_fact_taxonomy(subject,data.get("relation",None)))
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


@logic_bp.route("/arch_knowledge", methods=["GET"])
def logic_arch_knowledge():
    """Return architectural knowledge base for a given category."""
    category=request.args.get("category","all")
    try:
        engine=get_engine(); kb=engine._arch_kb
        cats={"clean_architecture":kb.CLEAN_ARCHITECTURE,"ddd":kb.DDD_CONCEPTS,"solid":kb.SOLID_PRINCIPLES,
              "design_patterns":kb.DESIGN_PATTERNS,"security_patterns":kb.SECURITY_PATTERNS,
              "scalability_patterns":kb.SCALABILITY_PATTERNS,"zeus_patterns":kb.ZEUS_PATTERNS}
        if category=="all":
            return jsonify({k:list(v.keys()) if isinstance(v,dict) else v for k,v in cats.items()})
        if category not in cats: return jsonify({"error":f"Unknown category '{category}'","available":list(cats.keys())}), 400
        return jsonify({category:cats[category]})
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500


# ============================================================================
# MODULE REGISTRATION
# ============================================================================

def register(app):
    """Register logic_engine blueprint. Called by discover_and_register() in app.py."""
    app.register_blueprint(logic_bp, url_prefix="/api/logic")
    log.info("[logic_engine] ✓ Blueprint registered at /api/logic")
    log.info("[logic_engine]   Core routes : /health /stats /classify /search /plan /reason /convert")
    log.info("[logic_engine]   New routes  : /meta /self_modify /learn /taxonomy /arch_knowledge")


# ============================================================================
# STANDALONE ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    from flask import Flask as _Flask
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(levelname)s] %(name)s - %(message)s")
    _app = _Flask(__name__)
    register(_app)
    print("")
    print("  ⚡ logic_engine v2 — self-evolving reasoning engine")
    print("  Listening on http://0.0.0.0:5001")
    print("")
    print("  Core routes:")
    print("    curl http://localhost:5001/api/logic/health")
    print("    curl http://localhost:5001/api/logic/stats")
    print("    curl http://localhost:5001/api/logic/meta")
    print('    curl -X POST http://localhost:5001/api/logic/plan \\')
    print('         -H "Content-Type: application/json" \\')
    print('         -d \'{"goal":"build a self-learning genome engine","deep":true}\'')
    print('    curl -X POST http://localhost:5001/api/logic/learn \\')
    print('         -H "Content-Type: application/json" \\')
    print('         -d \'{"synthesis_result":{"module_name":"test","quality_score":0.9,"design_patterns":["Strategy"]}}\'')
    print("")
    _app.run(host="0.0.0.0", port=5001, debug=True, use_reloader=False, threaded=True)
