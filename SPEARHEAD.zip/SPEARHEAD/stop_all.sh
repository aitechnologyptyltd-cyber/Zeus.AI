#!/usr/bin/env bash
# The Zeus Project 2026 — Francois Nel
# stop_all.sh — Stop all Zeus processes

echo "[*] Stopping Zeus Hive Mind..."
pkill -f "wsgi_zeus:app"   2>/dev/null && echo "[✓] Zeus stopped"   || echo "[!] Zeus was not running"
rm -f /tmp/zeus_arch.pid
echo "[✓] All systems stopped"
