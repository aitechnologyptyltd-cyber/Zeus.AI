"""
wsgi_zeus.py — The Zeus Project 2026 — Francois Nel
WSGI entry point: Zeus Architecture + Firewall + Aegis + Hive Mind Bridge
Port 8080
"""

import sys
import os
import threading

ZEUS_ROOT   = os.path.dirname(os.path.abspath(__file__))
ZEUS_ARCH   = os.path.join(ZEUS_ROOT, "zeus_arch")
ZEUS_FW_DIR = os.path.join(ZEUS_ROOT, "zeus_firewall")

# zeus_arch first so its modules take priority
sys.path.insert(0, ZEUS_ROOT)
sys.path.insert(0, ZEUS_ARCH)
sys.path.insert(0, ZEUS_FW_DIR)

# Load .env file if present
_env = os.path.join(ZEUS_ROOT, ".env")
if os.path.isfile(_env):
    with open(_env) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())

# ── 1. Zeus Architecture ──────────────────────────────────────────────────────
from app import app, log, _boot_improvement_loop

# ── 2. GUARANTEE /master route (registered here so it always exists) ──────────
from flask import send_from_directory

@app.route("/master")
@app.route("/master.html")
def _master_dashboard():
    """Zeus Master Control Dashboard — guaranteed route"""
    # Try root/static first, then zeus_arch/static
    for d in [
        os.path.join(ZEUS_ROOT, "static"),
        os.path.join(ZEUS_ARCH, "static"),
    ]:
        f = os.path.join(d, "master.html")
        if os.path.isfile(f):
            return send_from_directory(d, "master.html")
    return "Dashboard not found — place master.html in /static/", 404

# ── 3. Zeus Firewall + Aegis ──────────────────────────────────────────────────
_orch = None
try:
    from zeus_firewall_v1 import ZeusFirewall
    from zeus_aegis_engine import attach_to_zeus_firewall, create_aegis_blueprint
    fw    = ZeusFirewall()
    _orch = attach_to_zeus_firewall(fw)
    _orch.start_autonomous(interval_seconds=60)
    before_req, after_req = fw.flask_middleware()
    app.before_request(before_req)
    app.after_request(after_req)
    try:
        aegis_bp = create_aegis_blueprint(_orch)
        app.register_blueprint(aegis_bp)
        log.info("[boot] ✓ Aegis-22 dashboard at /aegis")
    except Exception as e:
        log.warning("[boot] Aegis blueprint: %s", e)
    log.info("[boot] ✓ Zeus Firewall v1 active")
except Exception as e:
    log.warning("[boot] Firewall/Aegis (non-fatal): %s", e)

# ── 4. Hive Mind Bridge ───────────────────────────────────────────────────────
try:
    from zeus_hive_bridge import register_zeus_bridge
    register_zeus_bridge(app)
    log.info("[boot] ✓ Hive Mind Bridge → /api/hive/*")
except Exception as e:
    log.warning("[boot] Hive Mind Bridge (non-fatal): %s", e)

# ── 5. Boot improvement loop ──────────────────────────────────────────────────
_boot_improvement_loop()

log.info("[wsgi_zeus] ✓ Zeus v8.0 ready on port 8080")
log.info("[wsgi_zeus] ★ Master Dashboard → http://localhost:8080/master")

__all__ = ["app"]
