"""
zeus_geo_signing_tool.py
========================
Zeus GovInt — Document Signing Utility
Author: Francois Nel | The Zeus Project 2026

Standalone CLI tool to generate signed authorization documents for testing,
and to generate a real CA keypair for production use.

PRODUCTION USE:
  Generate a CA keypair once. The private key stays with the issuing
  authority (e.g. a designated signing officer). The public cert
  (CA_PUBLIC_CERT) is distributed to AuthorizationGate via
  GOVINT_CA_CERT_PATH. Every authorization document must then be signed
  with the CA private key before AuthorizationGate will accept it.

TEST/DEMO USE:
  Uses HMAC-SHA256 with GOVINT_TEST_SIGNING_SECRET env var. This path
  is clearly logged as DEMO MODE in AuthorizationGate and should never
  be relied on for a real deployment.
"""
from __future__ import annotations
import argparse, base64, hashlib, hmac, json, os, sys
from datetime import datetime, timedelta, timezone


def generate_ca_keypair(out_dir: str) -> None:
    """Generate an ECDSA P-256 keypair for document signing (production path)."""
    try:
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        import datetime as dt
    except ImportError:
        print("ERROR: 'cryptography' package required. Install with:")
        print("  pip install cryptography --break-system-packages")
        sys.exit(1)

    os.makedirs(out_dir, exist_ok=True)
    private_key = ec.generate_private_key(ec.SECP256R1())

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "ZA"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Zeus GovInt Issuing Authority"),
        x509.NameAttribute(NameOID.COMMON_NAME, "ZeusGovInt-CA"),
    ])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(dt.datetime.now(dt.timezone.utc))
        .not_valid_after(dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=3650))
        .sign(private_key, hashes.SHA256())
    )

    priv_path = os.path.join(out_dir, "ca_private_key.pem")
    cert_path = os.path.join(out_dir, "ca_public_cert.pem")

    with open(priv_path, "wb") as f:
        f.write(private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ))
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    os.chmod(priv_path, 0o600)
    print(f"✓ CA private key (KEEP SECRET): {priv_path}")
    print(f"✓ CA public cert (set as GOVINT_CA_CERT_PATH): {cert_path}")
    print("\nIMPORTANT: The private key must be held only by the designated")
    print("signing officer / issuing authority. Never deploy it alongside")
    print("the application server.")


def sign_document_ecdsa(doc_path: str, private_key_path: str, out_path: str) -> None:
    """Sign a document with the CA private key (production path)."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric.ec import ECDSA
    except ImportError:
        print("ERROR: 'cryptography' package required.")
        sys.exit(1)

    with open(doc_path, "rb") as f:
        doc_bytes = f.read()
    with open(private_key_path, "rb") as f:
        private_key = serialization.load_pem_private_key(f.read(), password=None)

    signature = private_key.sign(doc_bytes, ECDSA(hashes.SHA256()))
    sig_b64 = base64.b64encode(signature).decode()

    with open(out_path, "w") as f:
        json.dump({"document_path": doc_path, "signature_b64": sig_b64}, f, indent=2)
    print(f"✓ Signed. Signature written to: {out_path}")
    print(f"  signature_b64 = {sig_b64[:60]}...")


def sign_document_hmac_demo(doc_path: str, secret: str) -> str:
    """Demo-mode HMAC signing — NOT for production use."""
    with open(doc_path, "rb") as f:
        doc_bytes = f.read()
    doc_hash = hashlib.sha256(doc_bytes).digest()
    sig = hmac.new(secret.encode(), doc_hash, hashlib.sha256).digest()
    return base64.b64encode(sig).decode()


def build_sample_document(doc_type: str, target: str, case_number: str,
                           authority: str, authorized_by: str, out_path: str) -> str:
    """Builds a sample JSON authorization document for testing the pipeline."""
    doc = {
        "doc_type": doc_type,
        "issuing_authority": authority,
        "case_number": case_number,
        "target_identifier": target,
        "issued_utc": datetime.now(timezone.utc).isoformat(),
        "expires_utc": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
        "authorized_by": authorized_by,
    }
    with open(out_path, "w") as f:
        json.dump(doc, f, indent=2)
    return out_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Zeus GovInt document signing utility")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("generate-ca", help="Generate production CA keypair")
    p1.add_argument("--out", default="./ca_keys")

    p2 = sub.add_parser("sign", help="Sign a document with CA private key")
    p2.add_argument("--doc", required=True)
    p2.add_argument("--key", required=True)
    p2.add_argument("--out", default="./signature.json")

    p3 = sub.add_parser("build-sample", help="Build a sample document for testing")
    p3.add_argument("--doc-type", default="rica_court_order")
    p3.add_argument("--target", required=True)
    p3.add_argument("--case", required=True)
    p3.add_argument("--authority", default="South African Police Service")
    p3.add_argument("--authorized-by", required=True)
    p3.add_argument("--out", default="./sample_doc.json")

    args = parser.parse_args()

    if args.cmd == "generate-ca":
        generate_ca_keypair(args.out)
    elif args.cmd == "sign":
        sign_document_ecdsa(args.doc, args.key, args.out)
    elif args.cmd == "build-sample":
        path = build_sample_document(args.doc_type, args.target, args.case,
                                     args.authority, args.authorized_by, args.out)
        print(f"✓ Sample document written: {path}")
